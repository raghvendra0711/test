angular.module('CommonPlugins', [
])
        .directive("ngMobileClick", [function () {
            return function (scope, elem, attrs) {
                elem.bind("touchstart click", function (e) {
                    e.preventDefault();
                    e.stopPropagation();
                    scope.$apply(attrs["ngMobileClick"]);
                });
            }
        }])
        .directive('dirPlaceholder', function($timeout) {
            return {
                scope:  {
                            placeholder: '@dirPlaceholder',
                            model: '=ngModel'
                        },
                restrict: 'A',
                replace: false,
                require: 'ngModel',
                link: function(scope, elem, attrs) {

                    var mobileTooltip = elem.parent()[0].getElementsByClassName("mobile_tooltip");

                    $timeout(function() {

                        elem.next().html(scope.placeholder);
                        elem.next().css('color', '#AAA');

                        if (elem.val() !== '') {
                            elem.next().css('display', 'none');
                        }

                        elem.next().on('click', function() {
                                elem[0].focus();
                        });

                        elem.on('focus', function() {
                            elem.next().css('color', '#DDD');
                            if(mobileTooltip != null && mobileTooltip.length > 0){
                                 mobileTooltip[0].className = mobileTooltip[0].className.replace(" hidden_class","");
                            }
                        });

                        elem.on('blur', function() {
                            elem.next().css('color', '#AAA');
                            if(mobileTooltip != null && mobileTooltip.length > 0){
                                 mobileTooltip[0].className = mobileTooltip[0].className+" hidden_class";
                            }
                        });

                        scope.$watch('model', function(newValue) {
                            if (typeof newValue == 'undefined' || newValue == '') {
                                elem.next().css('display', 'inline');
                            }
                            else {
                                elem.next().css('display', 'none');
                            }
                        });

                        elem.on('input keyup keydown', function(){
                            if (elem.val() == '') {
                                elem.next().css('display', 'inline');
                            }
                            else {
                                elem.next().css('display', 'none');
                            }
                        });

                    }, 0);
                }
            };
        })
        .directive('stopccp', function(){
		    return {
		        scope: {},
		        link:function(scope,element){
		            element.on('cut copy paste', function (event) {
		              event.preventDefault();
		            });
		        }
		    };
		})
        .directive('dirFormTooltip', function($timeout, $window) {
            return {
                scope:  {
                            tooltipClassname: '@',
                            tooltipForClassname: '@'        //optional attribute
                        },
                restrict: 'A',
                replace: false,
                link: function(scope, elem, attrs) {

                    $timeout(function() {
                        var target_elem_nodes = elem[0].querySelectorAll('input,select,a');
                        var tooltip_node = elem[0].getElementsByClassName(scope.tooltipClassname);
                        var helpers = new $window.helpers();

                        if(  target_elem_nodes.length && tooltip_node ) {
                            var target_elem = angular.element(target_elem_nodes);
                            var target_tooltip = angular.element(tooltip_node[0]);

                            target_elem.bind('focus keyup', function(){
                                if( scope.tooltipForClassname ) {
                                    var classified_nodes = elem[0].querySelectorAll('input.'+scope.tooltipForClassname+',select.'+scope.tooltipForClassname+',a.'+scope.tooltipForClassname+',span.'+scope.tooltipForClassname+',div.'+scope.tooltipForClassname);
                                    if( classified_nodes.length ) {
                                        var tooltip_text = helpers.GetFormElemTooltipText(classified_nodes[0]);

                                        if( tooltip_text ) {
                                            target_tooltip.html(tooltip_text);
                                            target_tooltip.css('display', 'block');
                                        }
                                        else {
                                            target_tooltip.css('display', 'none');
                                        }
                                    }
                                    else {
                                        target_tooltip.css('display', 'none');
                                    }
                                }
                                else {
                                    target_tooltip.css('display', 'block');
                                }
                            });

                            target_elem.bind('blur', function(){
                                target_tooltip.css('display', 'none');
                            });
                        }
                    }, 0);
                }
            };
        })
        .directive('dirFocusInvalidForm', function ($timeout) {
            return {
                restrict: 'A',
                replace: false,
                scope:{},
                link: function (scope, elem) {
                    // set up event handler on the form element
                    elem.on('submit', function () {
                        focusInvalidElem();
                    });

                    elem.find('button').on('click', function () {
                        focusInvalidElem();
                    });

                    var focusInvalidElem = function() {
                        // find the first invalid element
                        var invalidElems = angular.element( elem[0].querySelector('.ng-invalid') );

                        if (invalidElems.length) {
                            $timeout( function() {
                                invalidElems[0].focus();
                            }, 100);
                        }
                    };
                }
            };
        })
        .directive('dirCarousel', function($timeout, $interval, HelperService, $rootScope,$compile) {
            return {
                scope: {
                    carousel_name: '@dirCarousel',
                    prev_active_class: '@prevActive',
                    prev_inactive_class: '@prevInactive',
                    next_active_class: '@nextActive',
                    next_inactive_class: '@nextInactive',
                    on_page_load:'@onPageLoad',
                    auto_scroll:'@autoScroll',
                    is_custom:'@isCustom',
                    show_all:'@showAll',
                    desktop_disabled:'@desktopDisabled'
                },
                restrict: 'A',
                replace: false,
                link: function(scope, elem, attrs) {
                	if(!(isDesktopDevice() && scope.desktop_disabled == 1)){
	                    var carousel = function() {
	                        var hf, move_unit, move_timeout, bullet_flag, scrolling_status,
	                            visible_portion, list_parent, list_elements, list_elements_size, list_elem_width,
	                            running_status, prev_limit, visible_list_elems, next_limit, prev_arrow, next_arrow, computedWidthVal,
	                            move_count,already_moved,emptyLis,liList;

	                        var self = this,
	                            hf = HelperService,
	                            running_status = 0,
	                            move_unit = 50;
	                            move_timeout = 10,
	                            bullet_flag = 0,
	                            scrolling_status = 1,
	                            blocksToMove=0,
	                            already_moved=0,extraLiBucket=[];
	                    var originalList=null;

	                        if (elem[0].getElementsByClassName('c_bullet').length !== 0) {
	                            bullet_flag = 1;

	                        }

	                        if(originalList == null){
	                            originalList = [];
	                            list_parent = elem[0].getElementsByClassName('c_list')[0];
	                            var objcopys = [];
	                            var objclones = [];
	                            for(var i=0;i<list_parent.children.length;i++){
	                                        objcopys[i] = list_parent.children[i];
	                                        objclones[i] = objcopys[i].cloneNode(true);
	                                    }
	                                    //append elements to the end of the list
	                                    for(var i=0;i<list_parent.children.length;i++){
	                                        originalList[i] = objclones[i];
	                                    }

	                        }

	                        var calculateBlocksToMove = function(visible_portion,list_elements){
	                            list_elements_size = list_elements.length;
	                            for(var i=0;i<list_elements_size;i++){
	                                if(list_elements[i].offsetWidth > 0){
	                                    blocksToMove = Math.round(visible_portion.offsetWidth/list_elements[i].offsetWidth);
	                                    break;
	                                }
	                            }
	                            return blocksToMove;
	                        }

	                        var reArrangeList = function(list_parent){
	                            var listChildren = list_parent.children.length;
	                            for(var i=0;i<listChildren;i++){
	                                list_parent.removeChild(list_parent.children[0]);
	                            }
	                            for(var i=0;i<listChildren;i++){
                                        if(typeof originalList[i] !=='undefined')
	                                list_parent.appendChild(originalList[i]);
	                            }
	                            var bullets = elem[0].getElementsByClassName('c_bullet');
	                            angular.element(bullets[0]).parent().find('a').removeClass('active');
	                            angular.element(bullets[0]).addClass('active');
	                            return list_parent;
	                        }

				var addEmptyLi = function(){
	                                //clear all empty lis
	                                emptyLis = list_parent.getElementsByClassName('c_list_item empty_li');
	                                var fullScheduleDiv = list_parent.getElementsByClassName('download_schedule_div');
	                                var emptyLisLength = emptyLis.length;
	                                if(emptyLis.length > 0){
	                                    for(var i=0;i<emptyLisLength;i++){
	                                        list_parent.removeChild(list_parent.getElementsByClassName('c_list_item empty_li')[0]);
	                                    }
	                                }
	                                list_parent = elem[0].getElementsByClassName('c_list')[0];
	                                list_elements = elem[0].getElementsByClassName('c_list_item');
	                                list_elements_size = list_elements.length;
	                                blocksToMove = calculateBlocksToMove(visible_portion,list_elements);
	                                var maxToShow = blocksToMove*5;

	                                /* show/hide batches depending on screen size if show_all != 1 */
	                                if(scope.show_all != 1){
	                                    for(var i=0;i<list_elements_size;i++){
	                                        var cIndex = list_elements[i].className.substring(list_elements[i].className.indexOf("c_index_")+8,list_elements[i].className.length);
	                                        if(cIndex > maxToShow){
	                                            list_elements[i].className = list_elements[i].className+" hidden_class";
	                                            angular.element(fullScheduleDiv).removeClass("hidden_class");
	                                        }else{
	                                            list_elements[i].className = list_elements[i].className.replace(" hidden_class","");
	                                            angular.element(fullScheduleDiv).addClass("hidden_class");
	                                        }

	                                    }
	                                }
	                                list_elements_size = list_elements.length;
	                                var aa = list_elements_size%blocksToMove;
	                                if(aa != 0){
	                                    var bb = blocksToMove-aa;
	                                    liList = [];
	                                    for(var i=0;i<bb;i++){
	                                        var li = document.createElement("li");
	                                        li.style.border = "none";
	                                        li.style.float = "left";
	                                        li.style.width = "370px";
	                                        li.style.marginRight = "30px";
	                                        li.className = "c_list_item c_index_"+(list_elements_size+i+1)+" empty_li";
	                                        liList[i] = li;
	                                    }
	                                    if(typeof list_parent.getElementsByClassName("download_schedule_div") != 'undefined' &&
	                                            list_parent.getElementsByClassName("download_schedule_div").length > 0){
	                                        if(list_elements_size < (blocksToMove*5)){
	                                            for(var i=0;i<bb;i++){
	                                                list_parent.insertBefore(liList[i],list_parent.getElementsByClassName("download_schedule_div")[0]);
	                                            }
	                                        }
	                                    }else{
	                                        for(var i=0;i<bb;i++){
	                                            list_parent.appendChild(liList[i]);
	                                        }
	                                    }
	                                }

					return list_parent;
				}

	                        this.iniit = function(){
	                            var firstEleIndex=0;
	                            setTimeout(function(){
	                                visible_portion = elem[0].getElementsByClassName('c_screen')[0];
	                                list_parent = elem[0].getElementsByClassName('c_list')[0];
	                                list_parent = reArrangeList(list_parent);
	                                list_parent = addEmptyLi();

	                                /*show/hide bullets on orientation change*/
	                                if(bullet_flag == 1){
	                                    var bullets = elem[0].getElementsByClassName('c_bullet');
	                                    var bulletsLen = bullets.length;
	                                    var maxBulletsToShow=0;
	                                    var visibleEles=0;
	                                    for(var i=0;i<list_parent.children.length;i++){
	                                        if(list_parent.children[i].className.indexOf("hidden_class")==-1){
	                                            visibleEles++;
	                                        }
	                                    }
	                                    if(visibleEles <= blocksToMove){
	                                        maxBulletsToShow = 0;
	                                    }else if((visibleEles % blocksToMove) == 0){
	                                        maxBulletsToShow = parseInt(visibleEles / blocksToMove);
	                                    }else{
	                                        maxBulletsToShow = parseInt(visibleEles / blocksToMove) + 1;
	                                    }

	                                    for(var i=0;i<maxBulletsToShow;i++){
	                                        angular.element(bullets[i]).removeClass("hidden_class");
	                                    }
	                                    for(var i=maxBulletsToShow;i<bulletsLen;i++){
	                                        angular.element(bullets[i]).addClass("hidden_class");
	                                    }

	                                }

	                                for(var i=0;i<list_parent.children.length;i++){
	                                    var clsName = list_parent.children[i].className;
	                                    if(clsName.indexOf('c_index_1')!=-1){
	                                        firstEleIndex=i;
	                                        break;
	                                    }
	                                }
	                                copiedObjs=[];
	                                clonedObjs=[];
	                                if(firstEleIndex!=0){
	                                    for(var i=0;i<firstEleIndex;i++){
	                                        copiedObjs[i] = list_parent.children[i];
	                                        clonedObjs[i] = copiedObjs[i].cloneNode(true);
	                                    }
	                                    //append elements to the end of the list
	                                    for(var i=0;i<firstEleIndex;i++){
	                                        list_parent.appendChild(clonedObjs[i]);
	                                    }
	                                    for(var i=0;i<firstEleIndex;i++){
	                                        list_parent.removeChild(copiedObjs[i]);
	                                    }
	                                    copiedObjs=[];
	                                    clonedObjs=[];

	                                    var bullets = elem[0].getElementsByClassName('c_bullet');
	                                    angular.element(bullets[0]).parent().find('a').removeClass('active');
	                                    angular.element(bullets[0]).addClass('active');
	                                }

	                            },0);
	                        }
	                        //this.iniit();
	                        if(typeof scope.is_custom != 'undefined' && scope.is_custom == 1){
	                            this.iniit();
	                        }

	                        $rootScope.$on('orientationChanged', function(isOrientationChanged){
	                            if(isOrientationChanged && typeof scope.is_custom != 'undefined' && scope.is_custom == 1){
	                                self.iniit();
	                            }
	                        });


	                        this.init = function() {
	                            visible_portion = elem[0].getElementsByClassName('c_screen')[0];
	                            list_parent = elem[0].getElementsByClassName('c_list')[0];
	                            list_elements = elem[0].getElementsByClassName('c_list_item');
	                            list_elements_size = list_elements.length;
	                            if(typeof scope.is_custom != 'undefined' && scope.is_custom == 1){
	                                blocksToMove = calculateBlocksToMove(visible_portion,list_elements);
	                            }else{
	                                blocksToMove = 1;
	                            }

	                            move_count = parseInt((list_elements_size/blocksToMove)+1);
	                            prev_arrow = elem[0].getElementsByClassName('c_prev')[0];
	                            next_arrow = elem[0].getElementsByClassName('c_next')[0];
	                            var computedStyle = window.getComputedStyle(angular.element(list_elements[0])[0]);
	                            computedWidthVal = parseInt(computedStyle.paddingRight) + parseInt(computedStyle.paddingLeft) + parseInt(computedStyle.marginRight) + parseInt(computedStyle.marginLeft);
	                            computedWidthVal = computedWidthVal * blocksToMove;
	                            list_elem_width = list_elements[0].offsetWidth * blocksToMove;

	                            prev_limit = list_parent.offsetLeft;
	                            visible_list_elems = (Math.floor(visible_portion.offsetWidth / list_elem_width) === 0) ? Math.round(visible_portion.offsetWidth / list_elem_width) : Math.floor(visible_portion.offsetWidth / list_elem_width);
	                            next_limit = list_elem_width * (visible_list_elems - list_elements.length) + list_parent.offsetLeft;

	                            //if( list_elements.length <= 1 || list_elements.length <= blocksToMove ) {
	                            if( list_elements.length <= 1 || list_elements.length <= blocksToMove) {
	                                angular.element(prev_arrow).removeClass(scope.prev_active_class).addClass(scope.prev_inactive_class);
	                                angular.element(next_arrow).removeClass(scope.next_active_class).addClass(scope.next_inactive_class);
	                            }
	                            if(typeof list_parent.getElementsByClassName("download_schedule_div") != 'undefined' &&
	                                    list_parent.getElementsByClassName("download_schedule_div").length > 0){
	                                list_parent.getElementsByClassName("download_schedule_div")[0].style.width = visible_portion.offsetWidth+'px';
	                            }


	                        };

	                        this.init();



	                        //count total number of batches
	                        var listparentchildrenlen = list_parent.children.length;
	                        var totalBatchesCount=0;
	                        for(var i=0;i<listparentchildrenlen;i++){
	                            var currEle = list_parent.children[i];
	                            if(currEle.className.indexOf("c_index")!=-1 && currEle.className.indexOf("empty_li")==-1){
	                                totalBatchesCount++;
	                            }
	                        }

	                        //show counter
	                        if(list_parent.children[0].className.indexOf("c_index")!=-1){
	                            var currEleIndex = list_parent.children[0].className.substring(list_parent.children[0].className.indexOf("c_index_")+8,list_parent.children[0].className.length);
	                            //alert(currEleIndex);
	                            if(typeof elem[0].getElementsByClassName("dirCarouselCounter") != 'undefined' && elem[0].getElementsByClassName("dirCarouselCounter").length > 0){
	                                elem[0].getElementsByClassName("dirCarouselCounter")[0].innerHTML = currEleIndex;
	                            }
	                        }

	                        var showCounter = function(){
	                            var listparentchildrenlen = list_parent.children.length;
	                            for(var i=0;i<listparentchildrenlen;i++){
	                                var currEle = list_parent.children[i];
	                                if(currEle.className.indexOf("c_index")!=-1 && currEle.className.indexOf("hidden_class")==-1 && currEle.className.indexOf("download_schedule_div")==-1){
	                                   if(typeof elem[0].getElementsByClassName("batches_counter_span")[0] != 'undefined')
	                                    elem[0].getElementsByClassName("batches_counter_span")[0].className = elem[0].getElementsByClassName("batches_counter_span")[0].className.replace(" hidden_class","");
	                                    if(typeof elem[0].getElementsByClassName("all_batches")[0] != 'undefined' && elem[0].getElementsByClassName("all_batches")[0].className.indexOf("hidden_class")==-1){
	                                        elem[0].getElementsByClassName("all_batches")[0].className = elem[0].getElementsByClassName("all_batches")[0].className+" hidden_class";
	                                    }
	                                    var currEleIndex = currEle.className.substring(currEle.className.indexOf("c_index_")+8,currEle.className.length);
	                                    if(typeof elem[0].getElementsByClassName("dirCarouselCounter") != 'undefined' && elem[0].getElementsByClassName("dirCarouselCounter").length > 0){
	                                        elem[0].getElementsByClassName("dirCarouselCounter")[0].innerHTML = currEleIndex;
	                                    }
	                                    break;
	                                }else if(currEle.className.indexOf("download_schedule_div")!=-1){
	                                    elem[0].getElementsByClassName("all_batches")[0].className = elem[0].getElementsByClassName("all_batches")[0].className.replace(" hidden_class","");
	                                    elem[0].getElementsByClassName("batches_counter_span")[0].className = elem[0].getElementsByClassName("batches_counter_span")[0].className+" hidden_class";
	                                    break;
	                                }
	                            }
	                        }

	                        var calculateHiddenElements = function(listEleLen){
	                            var hiddenEleCount=0;
	                            for(var i=0;i<listEleLen;i++){
	                                if(list_parent.children[i].className.indexOf("hidden_class")!=-1){
	                                        hiddenEleCount++;
	                                }
	                            }
	                            return hiddenEleCount;
	                        }

	                        var animateLeft = function(obj, from, to, limit) {

	                            running_status = 1;
	                            var copiedObjs = [];
	                            var clonedObjs = [];
	                            var hiddenEleCount=0;
	                            var listEleLen = list_elements.length;
	                            if(listEleLen <= blocksToMove && list_elements[0].className.indexOf("download_schedule_div")==-1){
	                                running_status = 0;
	                                return true;
	                            }

	                            //calculate all elements those are hidden
	                            hiddenEleCount = calculateHiddenElements(listEleLen);

	                            //first append and remove all hidden elements if any are present at the beginning of the list
	                            if((list_parent.children[0]).className.indexOf("hidden_class")!=-1 && hiddenEleCount > 0){
	                                for(var i=0;i<hiddenEleCount;i++){
	                                    if(list_parent.children[i].className.indexOf("hidden_class")!=-1){
	                                        copiedObjs[i] = list_parent.children[i];
	                                        clonedObjs[i] = copiedObjs[i].cloneNode(true);
	                                        list_parent.appendChild(clonedObjs[i]);
	                                    }
	                                }
	                                for(var i=0;i<hiddenEleCount;i++){
	                                    list_parent.removeChild(copiedObjs[i]);
	                                }
	                                copiedObjs = [];
	                                clonedObjs = [];
	                            }


	                            //if first visible element is download schedule div, copy and remove it
	                            if((list_parent.children[0]).className.indexOf("download_schedule_div")!=-1) {
	                                copiedObjs[0] = list_parent.getElementsByTagName("li")[0];
	                                clonedObjs[0] = copiedObjs[0].cloneNode(true);
	                                list_parent.appendChild(clonedObjs[0]);
	                            }
	                            //if first visible element is a normal div, do a normal copy and remove
	                            else{
	                                for(var i=0;i<blocksToMove;i++){
	                                    copiedObjs[i] = list_parent.children[i];
	                                    clonedObjs[i] = copiedObjs[i].cloneNode(true);
	                                }
	                                //append elements to the end of the list
	                                for(var i=0;i<blocksToMove;i++){
	                                    list_parent.appendChild(clonedObjs[i]);

	                                }
	                            }

	                            //move the list to show desired elements with transition
	                            list_parent.style.transition = "all .5s ease";
	                            list_parent.style.left = (-list_elem_width-computedWidthVal) + "px";

	                            $timeout(function(){
	                                running_status = 0;
	                                //remove all elements from clonedObjs and copiedObjs
	                                if((list_parent.children[0]).className.indexOf("download_schedule_div")!=-1) {
	                                    list_parent.removeChild(copiedObjs[0]);
	                                }else{
	                                    for(var i=0;i<blocksToMove;i++){
	                                        list_parent.removeChild(copiedObjs[i]);
	                                    }
	                                }
	                                //reset left to original 0 value
					list_parent.style.transition = "";
	                                list_parent.style.left = "0px";
	                                if(typeof scope.is_custom != 'undefined' && scope.is_custom == 1){
	                                    blocksToMove = calculateBlocksToMove(visible_portion,list_elements);
	                                }else{
	                                    blocksToMove = 1;
	                                }

					//show counter
	                                showCounter();

	                             },250);

	                            return true;
	                        };

	                        var animateRight = function(obj, from, to, limit) {
	                            running_status = 1;
	                            var copiedObjs = [];
	                            var clonedObjs = [];
	                            var lastEleIndex = angular.element(list_parent)[0].children.length - 1;
	                            var hiddenEleCount = 0;
	                            var listEleLen = lastEleIndex + 1;
	                            if(listEleLen <= blocksToMove){
	                               running_status = 0;
	                               return true;
	                           }
	                            //calculate all elements those are hidden
	                            hiddenEleCount = calculateHiddenElements(listEleLen);

	                            //first append and remove all hidden elements if any are present at the end of the list
	                            if((list_parent.children[lastEleIndex]).className.indexOf("hidden_class")!=-1 && hiddenEleCount > 0){
	                                for (var i = 0; i < hiddenEleCount; i++) {
	                                    copiedObjs[hiddenEleCount - (i + 1)] = list_parent.children[lastEleIndex];
	                                    clonedObjs[hiddenEleCount - (i + 1)] = copiedObjs[hiddenEleCount - (i + 1)].cloneNode(true);
	                                    list_parent.insertBefore(clonedObjs[hiddenEleCount - (i + 1)], list_parent.firstChild);
	                                }
	                                for (var i = 0; i < hiddenEleCount; i++) {
	                                    list_parent.removeChild(copiedObjs[i]);
	                                }
	                                copiedObjs = [];
	                                clonedObjs = [];
	                            }

	                            //if last visible element is download schedule div, copy and remove it
	                            if (list_parent.children[lastEleIndex].className.indexOf("download_schedule_div")!=-1) {
	                                var copiedObj = list_parent.children[lastEleIndex];
	                                var clonedObj = copiedObj.cloneNode(true);
	                                list_parent.insertBefore(clonedObj, list_parent.children[0]);
	                                list_parent.removeChild(copiedObj);
	                            }
	                            //if last visible element is a normal div, do a normal copy and remove
	                            else{
	                                for (var i = 0; i < blocksToMove; i++) {
	                                    copiedObjs[i] = list_parent.children[list_parent.children.length - (i + 1)];
	                                    clonedObjs[i] = copiedObjs[i].cloneNode(true);
	                                }
	                                //append elements to the end of the list
	                                for (var i = 0; i < blocksToMove; i++) {
	                                    list_parent.insertBefore(clonedObjs[i], list_parent.firstChild);
	                                }
	                                for (var i = 0; i < blocksToMove; i++) {
	                                    list_parent.removeChild(copiedObjs[i]);
	                                }
	                            }


	                            list_parent.style.left = (-list_elem_width - computedWidthVal) + "px";

	                            $timeout(function () {

	                                list_parent.style.transition = "all .5s ease";
	                                list_parent.style.left = "0px";
	                                if(typeof scope.is_custom != 'undefined' && scope.is_custom == 1){
	                                    blocksToMove = calculateBlocksToMove(visible_portion,list_elements);
	                                }else{
	                                    blocksToMove = 1;
	                                }
	                                //show counter
	                                showCounter();

	                            }, 300);

	                            $timeout(function () {
	                                list_parent.style.transition = "";
	                                running_status = 0;
	                            }, 700);
	                            return true;

	                        };

	                        //code for bullets initialization
	                        if (bullet_flag === 1) {
	                            var bullets = elem[0].getElementsByClassName('c_bullet');
	                            for (var i = 0; i < bullets.length; i++) {

	                                angular.element(bullets[i]).attr('c_index', i);
	                                if(i==0){
	                                    angular.element(bullets[i]).addClass('active');
	                                }

	                                angular.element(bullets[i]).on('click', function() {
	                                    self.init();
	                                    var index = parseInt(angular.element(this).attr('c_index'));
	                                    var prevIndexBullet = elem[0].getElementsByClassName('c_bullet active');
	                                    var prevIndex = angular.element(prevIndexBullet[0]).attr('c_index');
	                                    if (index == prevIndex) {
	                                        return;
	                                    } else if (index < prevIndex) {
	                                        blocksToMove = (prevIndex - index) * blocksToMove;
	                                        animateRight(list_parent, 0, 0, 0);
	                                        activateBullet(700, 'prev', prevIndex - index);
	                                    }
	                                    else if (index > prevIndex) {
	                                        blocksToMove = (index - prevIndex) * blocksToMove;
	                                        animateLeft(list_parent, 0, 0, 0);
	                                        activateBullet(700, 'next', index - prevIndex);
	                                    }

	                                });
	                            }

	                            var activateBullet = function(timeout,movementType,step) {
	                                if (!timeout) {
	                                    timeout = 700;
	                                }
	                                setTimeout(function() {
	                                    var curIndex = 0;
	                                    var bulletList = angular.element(bullets[0]).parent().children();
	                                    var visibleEleIndex = 0;
	                                    var listparentChildrenlength = list_parent.children.length;

	                                    for(var i=0;i<listparentChildrenlength;i++){
	                                        if(list_parent.children[i].className.indexOf("hidden_class")==-1 &&
	                                                list_parent.children[i].className.indexOf("empty_li")==-1 &&
	                                                list_parent.children[i].className.indexOf("download_schedule_div")==-1){
	                                            visibleEleIndex =  list_parent.children[i].className.substring(list_parent.children[i].className.indexOf("c_index_")+8,list_elements[i].className.length);
	                                            break;
	                                        }else if(list_parent.children[i].className.indexOf("hidden_class")==-1 &&
	                                                list_parent.children[i].className.indexOf("empty_li")==-1 &&
	                                                list_parent.children[i].className.indexOf("download_schedule_div")!=-1){
	                                            visibleEleIndex =  bulletList.length-1;
	                                            break;
	                                        }
	                                    }
	                                    angular.element(bullets[0]).parent().find('a').removeClass('active');
	                                    if(list_parent.children[i].className.indexOf("download_schedule_div")!=-1){
	                                        angular.element(bullets[bullets.length - 1]).addClass('active');
	                                    }else{
	                                        if(blocksToMove == 1){
	                                            angular.element(bullets[visibleEleIndex - 1]).addClass('active');
	                                        }else{
	                                            var toActivateIndex = parseInt(visibleEleIndex / blocksToMove);
	                                            angular.element(bullets[toActivateIndex]).addClass('active');
	                                        }
	                                    }

	                                }, timeout);
	                            };
	                        }

	                        var showPreviousBlock = function() {

	                            self.init();

	                            //if(running_status == 1 || list_elements.length <= blocksToMove) {
	                            if(running_status == 1) {
	                                return false;
	                            }
	                            var from = list_parent.offsetLeft;
	                            var to = list_parent.offsetLeft + list_elem_width;
	                            var rv = animateRight(list_parent, from, to, prev_limit);
	                            if (rv !== false && bullet_flag === 1) {
	                                var timeout = (Math.ceil(list_elem_width / move_unit) * move_timeout) + 50;
	                                activateBullet(700,'prev',1);
	                            }
	                        };

	                        var showNextBlock = function() {

	                            self.init();
	                            //if(running_status == 1 || list_elements.length <= visible_list_elems) {
	                            if(running_status == 1) {
	                                return false;
	                            }
	                            var from = list_parent.offsetLeft;
	                            var to = list_parent.offsetLeft - list_elem_width;
	                            blocksToMove = calculateBlocksToMove(visible_portion,list_elements);
	                            var rv = animateLeft(list_parent, from, to, next_limit);
	                            if (rv !== false && bullet_flag === 1) {
	                                var timeout = (Math.ceil(list_elem_width / move_unit) * move_timeout) + 50;
	                                activateBullet(700,'next',1);
	                            }
	                        };

	                        angular.element(prev_arrow).on('click', function() {
	                            showPreviousBlock();
	                        });

	                        angular.element(next_arrow).on('click', function() {
	                            showNextBlock();
	                        });

	                        hf.$(visible_portion).onSwipeLeft(function() {
	                            showNextBlock();
	                        });

	                        hf.$(visible_portion).onSwipeRight(function() {
	                            var bullets = elem[0].getElementsByClassName('c_bullet');
	                            var bulletList = angular.element(bullets[0]).parent().children();
                                if(bulletList.length != undefined && bulletList.length > 0)
	                            showPreviousBlock();
	                        });

	                        elem.on('mouseover', function() {
	                            scrolling_status = 0;
	                        });

	                        elem.on('mouseleave', function() {
	                            scrolling_status = 1;
	                        });

	                        if( scope.auto_scroll == 1 ) {
	                            $interval(function() {
	                                if(scrolling_status) {
	                                    angular.element(next_arrow).triggerHandler('click');
	                                }
	                            }, 3000);
	                        }
	                    };

	                    var carouselObj = null;
	                    if(scope.on_page_load == 1) {
	                        carouselObj = new carousel();
	                    }
	                    else {
	                        $timeout(function() {
	                            carouselObj = new carousel();
	                        }, 0);
	                    }
	                }
	            }
            };
        })
        // Dynamic carousel - re render based on the trigger parmeter change
        .directive('dirCarouselDynamic', function($timeout, $interval, HelperService, $rootScope,$compile) {
            return {
                scope: {
                    carousel_name: '@dirCarousel',
                    prev_active_class: '@prevActive',
                    prev_inactive_class: '@prevInactive',
                    next_active_class: '@nextActive',
                    next_inactive_class: '@nextInactive',
                    on_page_load:'@onPageLoad',
                    auto_scroll:'@autoScroll',
                    is_custom:'@isCustom',
                    show_all:'@showAll',
                    desktop_disabled:'@desktopDisabled',
                    trigger:'=',
                },
                restrict: 'A',
                replace: false,
                link: function(scope, elem, attrs) {
                    var navigationEventFlag = false;
                    var triggerCarousel = function () {
                        if(elem[0].getElementsByClassName('c_list_item').length == 0) {
                            return;
                        }

                        if(!(isDesktopDevice() && scope.desktop_disabled == 1)) {
                            var carousel = function () {
                                var hf, move_unit, move_timeout, bullet_flag, scrolling_status,
                                    visible_portion, list_parent, list_elements, list_elements_size, list_elem_width,
                                    running_status, prev_limit, visible_list_elems, next_limit, prev_arrow, next_arrow, computedWidthVal,
                                    move_count, already_moved, emptyLis, liList;

                                var self = this,
                                    hf = HelperService,
                                    running_status = 0,
                                    move_unit = 50;
                                move_timeout = 10,
                                    bullet_flag = 0,
                                    scrolling_status = 1,
                                    blocksToMove = 0,
                                    already_moved = 0, extraLiBucket = [];
                                var originalList = null;

                                if (elem[0].getElementsByClassName('c_bullet').length !== 0) {
                                    bullet_flag = 1;

                                }

                                if (originalList == null) {
                                    originalList = [];
                                    list_parent = elem[0].getElementsByClassName('c_list')[0];
                                    var objcopys = [];
                                    var objclones = [];
                                    for (var i = 0; i < list_parent.children.length; i++) {
                                        objcopys[i] = list_parent.children[i];
                                        objclones[i] = objcopys[i].cloneNode(true);
                                    }
                                    //append elements to the end of the list
                                    for (var i = 0; i < list_parent.children.length; i++) {
                                        originalList[i] = objclones[i];
                                    }

                                }

                                var calculateBlocksToMove = function (visible_portion, list_elements) {
                                    list_elements_size = list_elements.length;
                                    for (var i = 0; i < list_elements_size; i++) {
                                        if (list_elements[i].offsetWidth > 0) {
                                            blocksToMove = Math.round(visible_portion.offsetWidth / list_elements[i].offsetWidth);
                                            break;
                                        }
                                    }
                                    return blocksToMove;
                                }

                                var reArrangeList = function (list_parent) {
                                    var listChildren = list_parent.children.length;
                                    for (var i = 0; i < listChildren; i++) {
                                        list_parent.removeChild(list_parent.children[0]);
                                    }
                                    for (var i = 0; i < listChildren; i++) {
                                        list_parent.appendChild(originalList[i]);
                                    }
                                    var bullets = elem[0].getElementsByClassName('c_bullet');
                                    angular.element(bullets[0]).parent().find('a').removeClass('active');
                                    angular.element(bullets[0]).addClass('active');
                                    return list_parent;
                                }

                                var addEmptyLi = function () {
                                    //clear all empty lis
                                    emptyLis = list_parent.getElementsByClassName('c_list_item empty_li');
                                    var fullScheduleDiv = list_parent.getElementsByClassName('download_schedule_div');
                                    var emptyLisLength = emptyLis.length;
                                    if (emptyLis.length > 0) {
                                        for (var i = 0; i < emptyLisLength; i++) {
                                            list_parent.removeChild(list_parent.getElementsByClassName('c_list_item empty_li')[0]);
                                        }
                                    }
                                    list_parent = elem[0].getElementsByClassName('c_list')[0];
                                    list_elements = elem[0].getElementsByClassName('c_list_item');
                                    list_elements_size = list_elements.length;
                                    blocksToMove = calculateBlocksToMove(visible_portion, list_elements);
                                    var maxToShow = blocksToMove * 5;

                                    /* show/hide batches depending on screen size if show_all != 1 */
                                    if (scope.show_all != 1) {
                                        for (var i = 0; i < list_elements_size; i++) {
                                            var cIndex = list_elements[i].className.substring(list_elements[i].className.indexOf("c_index_") + 8, list_elements[i].className.length);
                                            if (cIndex > maxToShow) {
                                                list_elements[i].className = list_elements[i].className + " hidden_class";
                                                angular.element(fullScheduleDiv).removeClass("hidden_class");
                                            } else {
                                                list_elements[i].className = list_elements[i].className.replace(" hidden_class", "");
                                                angular.element(fullScheduleDiv).addClass("hidden_class");
                                            }

                                        }
                                    }
                                    list_elements_size = list_elements.length;
                                    var aa = list_elements_size % blocksToMove;
                                    if (aa != 0) {
                                        var bb = blocksToMove - aa;
                                        liList = [];
                                        for (var i = 0; i < bb; i++) {
                                            var li = document.createElement("li");
                                            li.style.border = "none";
                                            li.style.float = "left";
                                            li.style.width = "370px";
                                            li.style.marginRight = "30px";
                                            li.className = "c_list_item c_index_" + (list_elements_size + i + 1) + " empty_li";
                                            liList[i] = li;
                                        }
                                        if (typeof list_parent.getElementsByClassName("download_schedule_div") != 'undefined' &&
                                            list_parent.getElementsByClassName("download_schedule_div").length > 0) {
                                            if (list_elements_size < (blocksToMove * 5)) {
                                                for (var i = 0; i < bb; i++) {
                                                    list_parent.insertBefore(liList[i], list_parent.getElementsByClassName("download_schedule_div")[0]);
                                                }
                                            }
                                        } else {
                                            for (var i = 0; i < bb; i++) {
                                                list_parent.appendChild(liList[i]);
                                            }
                                        }
                                    }

                                    return list_parent;
                                }

                                this.iniit = function () {
                                    var firstEleIndex = 0;
                                    setTimeout(function () {
                                        visible_portion = elem[0].getElementsByClassName('c_screen')[0];
                                        list_parent = elem[0].getElementsByClassName('c_list')[0];
                                        list_parent = reArrangeList(list_parent);
                                        list_parent = addEmptyLi();

                                        /*show/hide bullets on orientation change*/
                                        if (bullet_flag == 1) {
                                            var bullets = elem[0].getElementsByClassName('c_bullet');
                                            var bulletsLen = bullets.length;
                                            var maxBulletsToShow = 0;
                                            var visibleEles = 0;
                                            for (var i = 0; i < list_parent.children.length; i++) {
                                                if (list_parent.children[i].className.indexOf("hidden_class") == -1) {
                                                    visibleEles++;
                                                }
                                            }
                                            if (visibleEles <= blocksToMove) {
                                                maxBulletsToShow = 0;
                                            } else if ((visibleEles % blocksToMove) == 0) {
                                                maxBulletsToShow = parseInt(visibleEles / blocksToMove);
                                            } else {
                                                maxBulletsToShow = parseInt(visibleEles / blocksToMove) + 1;
                                            }

                                            for (var i = 0; i < maxBulletsToShow; i++) {
                                                angular.element(bullets[i]).removeClass("hidden_class");
                                            }
                                            for (var i = maxBulletsToShow; i < bulletsLen; i++) {
                                                angular.element(bullets[i]).addClass("hidden_class");
                                            }

                                        }

                                        for (var i = 0; i < list_parent.children.length; i++) {
                                            var clsName = list_parent.children[i].className;
                                            if (clsName.indexOf('c_index_1') != -1) {
                                                firstEleIndex = i;
                                                break;
                                            }
                                        }
                                        copiedObjs = [];
                                        clonedObjs = [];
                                        if (firstEleIndex != 0) {
                                            for (var i = 0; i < firstEleIndex; i++) {
                                                copiedObjs[i] = list_parent.children[i];
                                                clonedObjs[i] = copiedObjs[i].cloneNode(true);
                                            }
                                            //append elements to the end of the list
                                            for (var i = 0; i < firstEleIndex; i++) {
                                                list_parent.appendChild(clonedObjs[i]);
                                            }
                                            for (var i = 0; i < firstEleIndex; i++) {
                                                list_parent.removeChild(copiedObjs[i]);
                                            }
                                            copiedObjs = [];
                                            clonedObjs = [];

                                            var bullets = elem[0].getElementsByClassName('c_bullet');
                                            angular.element(bullets[0]).parent().find('a').removeClass('active');
                                            angular.element(bullets[0]).addClass('active');
                                        }

                                    }, 0);
                                }
                                //this.iniit();
                                if (typeof scope.is_custom != 'undefined' && scope.is_custom == 1) {
                                    this.iniit();
                                }

                                $rootScope.$on('orientationChanged', function (isOrientationChanged) {
                                    if (isOrientationChanged && typeof scope.is_custom != 'undefined' && scope.is_custom == 1) {
                                        self.iniit();
                                    }
                                });


                                this.init = function () {
                                    visible_portion = elem[0].getElementsByClassName('c_screen')[0];
                                    list_parent = elem[0].getElementsByClassName('c_list')[0];
                                    list_elements = elem[0].getElementsByClassName('c_list_item');
                                    list_elements_size = list_elements.length;
                                    if (typeof scope.is_custom != 'undefined' && scope.is_custom == 1) {
                                        blocksToMove = calculateBlocksToMove(visible_portion, list_elements);
                                    } else {
                                        blocksToMove = 1;
                                    }

                                    move_count = parseInt((list_elements_size / blocksToMove) + 1);
                                    prev_arrow = elem[0].getElementsByClassName('c_prev')[0];
                                    next_arrow = elem[0].getElementsByClassName('c_next')[0];
                                    var computedStyle = window.getComputedStyle(angular.element(list_elements[0])[0]);
                                    computedWidthVal = parseInt(computedStyle.paddingRight) + parseInt(computedStyle.paddingLeft) + parseInt(computedStyle.marginRight) + parseInt(computedStyle.marginLeft);
                                    computedWidthVal = computedWidthVal * blocksToMove;
                                    list_elem_width = list_elements[0].offsetWidth * blocksToMove;

                                    prev_limit = list_parent.offsetLeft;
                                    visible_list_elems = (Math.floor(visible_portion.offsetWidth / list_elem_width) === 0) ? Math.round(visible_portion.offsetWidth / list_elem_width) : Math.floor(visible_portion.offsetWidth / list_elem_width);
                                    next_limit = list_elem_width * (visible_list_elems - list_elements.length) + list_parent.offsetLeft;

                                    //if( list_elements.length <= 1 || list_elements.length <= blocksToMove ) {
                                    if (list_elements.length <= 1 || list_elements.length <= blocksToMove) {
                                        angular.element(prev_arrow).removeClass(scope.prev_active_class).addClass(scope.prev_inactive_class);
                                        angular.element(next_arrow).removeClass(scope.next_active_class).addClass(scope.next_inactive_class);
                                    }
                                    if (typeof list_parent.getElementsByClassName("download_schedule_div") != 'undefined' &&
                                        list_parent.getElementsByClassName("download_schedule_div").length > 0) {
                                        list_parent.getElementsByClassName("download_schedule_div")[0].style.width = visible_portion.offsetWidth + 'px';
                                    }


                                };

                                this.init();



                                //count total number of batches
                                var listparentchildrenlen = list_parent.children.length;
                                var totalBatchesCount = 0;
                                for (var i = 0; i < listparentchildrenlen; i++) {
                                    var currEle = list_parent.children[i];
                                    if (currEle.className.indexOf("c_index") != -1 && currEle.className.indexOf("empty_li") == -1) {
                                        totalBatchesCount++;
                                    }
                                }

                                //show counter
                                if (list_parent.children[0].className.indexOf("c_index") != -1) {
                                    var currEleIndex = list_parent.children[0].className.substring(list_parent.children[0].className.indexOf("c_index_") + 8, list_parent.children[0].className.length);
                                    //alert(currEleIndex);
                                    if (typeof elem[0].getElementsByClassName("dirCarouselCounter") != 'undefined' && elem[0].getElementsByClassName("dirCarouselCounter").length > 0) {
                                        elem[0].getElementsByClassName("dirCarouselCounter")[0].innerHTML = currEleIndex;
                                    }
                                }

                                var showCounter = function () {
                                    var listparentchildrenlen = list_parent.children.length;
                                    for (var i = 0; i < listparentchildrenlen; i++) {
                                        var currEle = list_parent.children[i];
                                        if (currEle.className.indexOf("c_index") != -1 && currEle.className.indexOf("hidden_class") == -1 && currEle.className.indexOf("download_schedule_div") == -1) {
                                            if (typeof elem[0].getElementsByClassName("batches_counter_span")[0] != 'undefined')
                                                elem[0].getElementsByClassName("batches_counter_span")[0].className = elem[0].getElementsByClassName("batches_counter_span")[0].className.replace(" hidden_class", "");
                                            if (typeof elem[0].getElementsByClassName("all_batches")[0] != 'undefined' && elem[0].getElementsByClassName("all_batches")[0].className.indexOf("hidden_class") == -1) {
                                                elem[0].getElementsByClassName("all_batches")[0].className = elem[0].getElementsByClassName("all_batches")[0].className + " hidden_class";
                                            }
                                            var currEleIndex = currEle.className.substring(currEle.className.indexOf("c_index_") + 8, currEle.className.length);
                                            if (typeof elem[0].getElementsByClassName("dirCarouselCounter") != 'undefined' && elem[0].getElementsByClassName("dirCarouselCounter").length > 0) {
                                                elem[0].getElementsByClassName("dirCarouselCounter")[0].innerHTML = currEleIndex;
                                            }
                                            break;
                                        } else if (currEle.className.indexOf("download_schedule_div") != -1) {
                                            elem[0].getElementsByClassName("all_batches")[0].className = elem[0].getElementsByClassName("all_batches")[0].className.replace(" hidden_class", "");
                                            elem[0].getElementsByClassName("batches_counter_span")[0].className = elem[0].getElementsByClassName("batches_counter_span")[0].className + " hidden_class";
                                            break;
                                        }
                                    }
                                }

                                var calculateHiddenElements = function (listEleLen) {
                                    var hiddenEleCount = 0;
                                    for (var i = 0; i < listEleLen; i++) {
                                        if (list_parent.children[i].className.indexOf("hidden_class") != -1) {
                                            hiddenEleCount++;
                                        }
                                    }
                                    return hiddenEleCount;
                                }

                                var animateLeft = function (obj, from, to, limit) {

                                    running_status = 1;
                                    var copiedObjs = [];
                                    var clonedObjs = [];
                                    var hiddenEleCount = 0;
                                    var listEleLen = list_elements.length;
                                    if (listEleLen <= blocksToMove && list_elements[0].className.indexOf("download_schedule_div") == -1) {
                                        running_status = 0;
                                        return true;
                                    }

                                    //calculate all elements those are hidden
                                    hiddenEleCount = calculateHiddenElements(listEleLen);

                                    //first append and remove all hidden elements if any are present at the beginning of the list
                                    if ((list_parent.children[0]).className.indexOf("hidden_class") != -1 && hiddenEleCount > 0) {
                                        for (var i = 0; i < hiddenEleCount; i++) {
                                            if (list_parent.children[i].className.indexOf("hidden_class") != -1) {
                                                copiedObjs[i] = list_parent.children[i];
                                                clonedObjs[i] = copiedObjs[i].cloneNode(true);
                                                list_parent.appendChild(clonedObjs[i]);
                                            }
                                        }
                                        for (var i = 0; i < hiddenEleCount; i++) {
                                            list_parent.removeChild(copiedObjs[i]);
                                        }
                                        copiedObjs = [];
                                        clonedObjs = [];
                                    }


                                    //if first visible element is download schedule div, copy and remove it
                                    if ((list_parent.children[0]).className.indexOf("download_schedule_div") != -1) {
                                        copiedObjs[0] = list_parent.getElementsByTagName("li")[0];
                                        clonedObjs[0] = copiedObjs[0].cloneNode(true);
                                        list_parent.appendChild(clonedObjs[0]);
                                    }
                                    //if first visible element is a normal div, do a normal copy and remove
                                    else {
                                        for (var i = 0; i < blocksToMove; i++) {
                                            copiedObjs[i] = list_parent.children[i];
                                            clonedObjs[i] = copiedObjs[i].cloneNode(true);
                                        }
                                        //append elements to the end of the list
                                        for (var i = 0; i < blocksToMove; i++) {
                                            list_parent.appendChild(clonedObjs[i]);

                                        }
                                    }

                                    //move the list to show desired elements with transition
                                    list_parent.style.transition = "all .5s ease";
                                    list_parent.style.left = (-list_elem_width - computedWidthVal) + "px";

                                    $timeout(function () {
                                        running_status = 0;
                                        //remove all elements from clonedObjs and copiedObjs
                                        if ((list_parent.children[0]).className.indexOf("download_schedule_div") != -1) {
                                            list_parent.removeChild(copiedObjs[0]);
                                        } else {
                                            for (var i = 0; i < blocksToMove; i++) {
                                                list_parent.removeChild(copiedObjs[i]);
                                            }
                                        }
                                        //reset left to original 0 value
                                        list_parent.style.transition = "";
                                        list_parent.style.left = "0px";
                                        if (typeof scope.is_custom != 'undefined' && scope.is_custom == 1) {
                                            blocksToMove = calculateBlocksToMove(visible_portion, list_elements);
                                        } else {
                                            blocksToMove = 1;
                                        }

                                        //show counter
                                        showCounter();

                                    }, 250);

                                    return true;
                                };

                                var animateRight = function (obj, from, to, limit) {
                                    running_status = 1;
                                    var copiedObjs = [];
                                    var clonedObjs = [];
                                    var lastEleIndex = angular.element(list_parent)[0].children.length - 1;
                                    var hiddenEleCount = 0;
                                    var listEleLen = lastEleIndex + 1;
                                    if (listEleLen <= blocksToMove) {
                                        running_status = 0;
                                        return true;
                                    }
                                    //calculate all elements those are hidden
                                    hiddenEleCount = calculateHiddenElements(listEleLen);

                                    //first append and remove all hidden elements if any are present at the end of the list
                                    if ((list_parent.children[lastEleIndex]).className.indexOf("hidden_class") != -1 && hiddenEleCount > 0) {
                                        for (var i = 0; i < hiddenEleCount; i++) {
                                            copiedObjs[hiddenEleCount - (i + 1)] = list_parent.children[lastEleIndex];
                                            clonedObjs[hiddenEleCount - (i + 1)] = copiedObjs[hiddenEleCount - (i + 1)].cloneNode(true);
                                            list_parent.insertBefore(clonedObjs[hiddenEleCount - (i + 1)], list_parent.firstChild);
                                        }
                                        for (var i = 0; i < hiddenEleCount; i++) {
                                            list_parent.removeChild(copiedObjs[i]);
                                        }
                                        copiedObjs = [];
                                        clonedObjs = [];
                                    }

                                    //if last visible element is download schedule div, copy and remove it
                                    if (list_parent.children[lastEleIndex].className.indexOf("download_schedule_div") != -1) {
                                        var copiedObj = list_parent.children[lastEleIndex];
                                        var clonedObj = copiedObj.cloneNode(true);
                                        list_parent.insertBefore(clonedObj, list_parent.children[0]);
                                        list_parent.removeChild(copiedObj);
                                    }
                                    //if last visible element is a normal div, do a normal copy and remove
                                    else {
                                        for (var i = 0; i < blocksToMove; i++) {
                                            copiedObjs[i] = list_parent.children[list_parent.children.length - (i + 1)];
                                            clonedObjs[i] = copiedObjs[i].cloneNode(true);
                                        }
                                        //append elements to the end of the list
                                        for (var i = 0; i < blocksToMove; i++) {
                                            list_parent.insertBefore(clonedObjs[i], list_parent.firstChild);
                                        }
                                        for (var i = 0; i < blocksToMove; i++) {
                                            list_parent.removeChild(copiedObjs[i]);
                                        }
                                    }


                                    list_parent.style.left = (-list_elem_width - computedWidthVal) + "px";

                                    $timeout(function () {

                                        list_parent.style.transition = "all .5s ease";
                                        list_parent.style.left = "0px";
                                        if (typeof scope.is_custom != 'undefined' && scope.is_custom == 1) {
                                            blocksToMove = calculateBlocksToMove(visible_portion, list_elements);
                                        } else {
                                            blocksToMove = 1;
                                        }
                                        //show counter
                                        showCounter();

                                    }, 300);

                                    $timeout(function () {
                                        list_parent.style.transition = "";
                                        running_status = 0;
                                    }, 700);
                                    return true;

                                };

                                //code for bullets initialization
                                if (bullet_flag === 1) {
                                    var bullets = elem[0].getElementsByClassName('c_bullet');
                                    for (var i = 0; i < bullets.length; i++) {

                                        angular.element(bullets[i]).attr('c_index', i);
                                        if (i == 0) {
                                            angular.element(bullets[i]).addClass('active');
                                        }

                                        angular.element(bullets[i]).on('click', function () {
                                            self.init();
                                            var index = parseInt(angular.element(this).attr('c_index'));
                                            var prevIndexBullet = elem[0].getElementsByClassName('c_bullet active');
                                            var prevIndex = angular.element(prevIndexBullet[0]).attr('c_index');
                                            if (index == prevIndex) {
                                                return;
                                            } else if (index < prevIndex) {
                                                blocksToMove = (prevIndex - index) * blocksToMove;
                                                animateRight(list_parent, 0, 0, 0);
                                                activateBullet(700, 'prev', prevIndex - index);
                                            } else if (index > prevIndex) {
                                                blocksToMove = (index - prevIndex) * blocksToMove;
                                                animateLeft(list_parent, 0, 0, 0);
                                                activateBullet(700, 'next', index - prevIndex);
                                            }

                                        });
                                    }

                                    var activateBullet = function (timeout, movementType, step) {
                                        if (!timeout) {
                                            timeout = 700;
                                        }
                                        setTimeout(function () {
                                            var curIndex = 0;
                                            var bulletList = angular.element(bullets[0]).parent().children();
                                            var visibleEleIndex = 0;
                                            var listparentChildrenlength = list_parent.children.length;

                                            for (var i = 0; i < listparentChildrenlength; i++) {
                                                if (list_parent.children[i].className.indexOf("hidden_class") == -1 &&
                                                    list_parent.children[i].className.indexOf("empty_li") == -1 &&
                                                    list_parent.children[i].className.indexOf("download_schedule_div") == -1) {
                                                    visibleEleIndex = list_parent.children[i].className.substring(list_parent.children[i].className.indexOf("c_index_") + 8, list_elements[i].className.length);
                                                    break;
                                                } else if (list_parent.children[i].className.indexOf("hidden_class") == -1 &&
                                                    list_parent.children[i].className.indexOf("empty_li") == -1 &&
                                                    list_parent.children[i].className.indexOf("download_schedule_div") != -1) {
                                                    visibleEleIndex = bulletList.length - 1;
                                                    break;
                                                }
                                            }
                                            angular.element(bullets[0]).parent().find('a').removeClass('active');
                                            if (list_parent.children[i].className.indexOf("download_schedule_div") != -1) {
                                                angular.element(bullets[bullets.length - 1]).addClass('active');
                                            } else {
                                                if (blocksToMove == 1) {
                                                    angular.element(bullets[visibleEleIndex - 1]).addClass('active');
                                                } else {
                                                    var toActivateIndex = parseInt(visibleEleIndex / blocksToMove);
                                                    angular.element(bullets[toActivateIndex]).addClass('active');
                                                }
                                            }

                                        }, timeout);
                                    };
                                }

                                var showPreviousBlock = function () {

                                    self.init();

                                    //if(running_status == 1 || list_elements.length <= blocksToMove) {
                                    if (running_status == 1) {
                                        return false;
                                    }
                                    var from = list_parent.offsetLeft;
                                    var to = list_parent.offsetLeft + list_elem_width;
                                    var rv = animateRight(list_parent, from, to, prev_limit);
                                    if (rv !== false && bullet_flag === 1) {
                                        var timeout = (Math.ceil(list_elem_width / move_unit) * move_timeout) + 50;
                                        activateBullet(700, 'prev', 1);
                                    }
                                };

                                var showNextBlock = function () {

                                    self.init();
                                    //if(running_status == 1 || list_elements.length <= visible_list_elems) {
                                    if (running_status == 1) {
                                        return false;
                                    }
                                    var from = list_parent.offsetLeft;
                                    var to = list_parent.offsetLeft - list_elem_width;
                                    blocksToMove = calculateBlocksToMove(visible_portion, list_elements);
                                    var rv = animateLeft(list_parent, from, to, next_limit);
                                    if (rv !== false && bullet_flag === 1) {
                                        var timeout = (Math.ceil(list_elem_width / move_unit) * move_timeout) + 50;
                                        activateBullet(700, 'next', 1);
                                    }
                                };

                                // Prevent multiple event
                                if (!navigationEventFlag) {
                                    angular.element(prev_arrow).on('click', function () {
                                        showPreviousBlock();
                                    });

                                    angular.element(next_arrow).on('click', function () {
                                        showNextBlock();
                                    });
                                    navigationEventFlag = true;
                                }

                                hf.$(visible_portion).onSwipeLeft(function () {
                                    showNextBlock();
                                });

                                hf.$(visible_portion).onSwipeRight(function () {
                                    var bullets = elem[0].getElementsByClassName('c_bullet');
                                    var bulletList = angular.element(bullets[0]).parent().children();
                                    if (bulletList.length != undefined && bulletList.length > 0)
                                        showPreviousBlock();
                                });

                                elem.on('mouseover', function () {
                                    scrolling_status = 0;
                                });

                                elem.on('mouseleave', function () {
                                    scrolling_status = 1;
                                });

                                if (scope.auto_scroll == 1) {
                                    $interval(function () {
                                        if (scrolling_status) {
                                            angular.element(next_arrow).triggerHandler('click');
                                        }
                                    }, 3000);
                                }
                            };

                            var carouselObj = null;
                            if (scope.on_page_load == 1) {
                                carouselObj = new carousel();
                            } else {
                                $timeout(function () {
                                    carouselObj = new carousel();
                                }, 0);
                            }
                        }
                    }

                    triggerCarousel();

                    scope.$watch('trigger', function(newValue, oldValue) {
                        setTimeout(function() {
                            triggerCarousel();
                        }, 500)
                    });
	            }
            };
        })

        .directive('dirSlCarousel',function(HelperService,$rootScope,$timeout,$window){
            return {
              link: function(scope, element, attrs){
                     var carouselScreen, carouselList, carouselItems, carouselItemWidth, carouselItemsLength, carouselItemsVisible,
                             carouselItemsLength, carouselPrevBtn, carouselNxtBtn, maxSlides, currentSlide,hf = HelperService,isSliding;
                    var initCarousel = function(){
                        carouselScreen = element[0].getElementsByClassName('c_screen')[0];
                        carouselList = element[0].getElementsByClassName('c_list')[0];
                        carouselPrevBtn = element[0].getElementsByClassName('c_prev')[0];
                        carouselNxtBtn = element[0].getElementsByClassName('c_next')[0];
                        carouselItems = angular.element(carouselList).children();
                        carouselItemWidth = carouselItems[0].offsetWidth;
                        carouselItemsLength = carouselItems.length;
                        carouselItemsVisible = calculateBlocksToMove(carouselScreen,carouselItems,carouselItemsLength);
                        maxSlides = (carouselItemsLength%carouselItemsVisible)==0?(carouselItemsLength/carouselItemsVisible):(parseInt(carouselItemsLength/carouselItemsVisible)+1);
                        currentSlide = 0;
                        carouselList.style.position = "relative";
                        addTransitionStyle(carouselList,"0.3s");
                        addTransformStyle(carouselList,0);
                        carouselList.style.width = "6000px";
                        isSliding=0;
                        angular.element(carouselPrevBtn).on('click',function(){
                           slideRight();
                        });
                        angular.element(carouselNxtBtn).on('click',function(){
                             slideLeft();
                        });
                        hf.$(carouselScreen).onSwipeLeft(function() {
                             slideLeft();
                        });
                        hf.$(carouselScreen).onSwipeRight(function() {
                             slideRight();
                        });
                        getCurrentTransformVal();
                        addEmptyLis(carouselList);
                    }
                    
                    var addEmptyLis = function(carouselList){
                        carouselItems = angular.element(carouselList).children();
                        carouselItemsLength = carouselItems.length;
                        carouselItemsVisible = calculateBlocksToMove(carouselScreen,carouselItems,carouselItemsLength);
                        var aa = carouselItemsLength%carouselItemsVisible;
                        if(aa != 0){
                            var bb = carouselItemsVisible-aa;
                            var liList = [];
                            for(var i=0;i<bb;i++){
                                var li = document.createElement("li");
                                li.style.border = "none";
                                li.style.float = "left";
                                li.style.width = carouselItemWidth+"px";
                                li.className = "c_list_item c_index_"+(carouselItemsLength+i+1)+" empty_li";
                                liList[i] = li;
                            }
                            for(var i=0;i<bb;i++){
                                carouselList.appendChild(liList[i]);
                            }
                        }
                    }

                    var removeEmptyLis = function(carouselList){
                        var carouselItemsAll = angular.element(carouselList).children();
                        for(var i=0;i<carouselItemsAll.length;i++){
                            var carouselItemObj = carouselItemsAll[i];
                            if(carouselItemObj.className.indexOf("empty_li")!=-1){
                                carouselList.removeChild(carouselItemsAll[i]);
                            }
                        }
                    }
                    var calculateBlocksToMove = function(carouselScreen,carouselItems,carouselItemsLength){
                        var citemstomove = 0;
                        for(var i=0;i<carouselItemsLength;i++){
                            if(carouselItems[i].offsetWidth > 0){
                                citemstomove = Math.floor(carouselScreen.offsetWidth/carouselItems[i].offsetWidth);
                                break;
                            }
                        }
                        return citemstomove;
                    }
                    var addTransitionStyle = function(carouselList,transformVal){
                        carouselList.style.transition = "0.3s";
                        carouselList.style.setProperty("-webkit-transition", transformVal);
                        carouselList.style.setProperty("-moz-transition", transformVal);
                        carouselList.style.setProperty("-ms-transition", transformVal);
                        carouselList.style.setProperty("-o-transition", transformVal);
                    }
                    var addTransformStyle = function(carouselList,presentTransformVal){
                        carouselList.style.transform = "translate3d("+presentTransformVal+"px, 0px, 0px)";
                        carouselList.style.setProperty("-webkit-transform", "translate3d("+presentTransformVal+"px, 0px, 0px)");
                        carouselList.style.setProperty("-moz-transform", "translate3d("+presentTransformVal+"px, 0px, 0px)");
                        carouselList.style.setProperty("-ms-transform", "translate3d("+presentTransformVal+"px, 0px, 0px)");
                        carouselList.style.setProperty("-o-transform", "translate3d("+presentTransformVal+"px, 0px, 0px)");
                    }
                    var slideLeft = function(){
                        if(isSliding == 0){
                            isSliding = 1;
                            carouselItems = angular.element(carouselList).children();
                            carouselItemWidth = carouselItems[0].offsetWidth;
                            carouselItemsLength = carouselItems.length;
                            var presentTransformVal = getCurrentTransformVal();
                            if(currentSlide < maxSlides-1){
                                presentTransformVal = presentTransformVal-(carouselItemsVisible*carouselItemWidth);
                                addTransitionStyle(carouselList,"0.3s");
                                addTransformStyle(carouselList,presentTransformVal);
                                currentSlide++;
                                isSliding=0;
                            }else{
                                currentSlide=0;
                                var copiedObjs = [];
                                var clonedObjs = [];
                                for(var i=0;i<carouselItemsLength;i++){
                                    copiedObjs[i] = carouselList.children[i];
                                    clonedObjs[i] = copiedObjs[i].cloneNode(true);
                                }
                                //append elements to the end of the list
                                for(var i=0;i<carouselItemsLength;i++){
                                    carouselList.appendChild(clonedObjs[i]);
                                }
                                presentTransformVal = presentTransformVal-(carouselItemsVisible*carouselItemWidth);
                                addTransitionStyle(carouselList,"0.3");
                                addTransformStyle(carouselList,presentTransformVal);
                                $timeout(function(){
                                    for(var i=0;i<carouselItemsLength;i++){
                                        carouselList.removeChild(copiedObjs[i]);
                                    }
                                    addTransitionStyle(carouselList,"");
                                    addTransformStyle(carouselList,0);
                                    currentSlide = 0;
                                    isSliding=0;
                                },300);
                            }
                        }
                    }

                    var slideRight = function(){
                        if(isSliding == 0){
                            isSliding = 1;
                            carouselItems = angular.element(carouselList).children();
                            carouselItemWidth = carouselItems[0].offsetWidth;
                            carouselItemsLength = carouselItems.length;
                            var presentTransformVal = getCurrentTransformVal();
                            if(currentSlide == 0){
                                var copiedObjs = [], clonedObjs = [];
                                for(var i=0;i<carouselItemsLength;i++){
                                    copiedObjs[i] = carouselList.children[carouselItemsLength - (i + 1)];
                                    clonedObjs[i] = copiedObjs[i].cloneNode(true);
                                }
                                addTransitionStyle(carouselList,"");
                                //append elements to the end of the list
                                for(var i=0;i<clonedObjs.length;i++){
                                    carouselList.insertBefore(clonedObjs[i], carouselList.firstChild);
                                }
                                presentTransformVal = getCurrentTransformVal()-(carouselItemWidth*(carouselItemsLength));
                                addTransformStyle(carouselList,presentTransformVal);
                                setTimeout(function(){
                                    presentTransformVal = getCurrentTransformVal()+(carouselItemWidth*carouselItemsVisible);
                                    addTransitionStyle(carouselList,"0.3s");
                                    addTransformStyle(carouselList,presentTransformVal);
                                    for(var i=0;i<carouselItemsLength;i++){
                                        carouselList.removeChild(copiedObjs[i]);
                                    }
                                    currentSlide = maxSlides-1;
                                    isSliding=0;
                                },200);

                            }else{
                                if(currentSlide <= maxSlides){
                                    presentTransformVal = presentTransformVal+(carouselItemsVisible*carouselItemWidth);
                                    addTransitionStyle(carouselList,"0.3s");
                                    addTransformStyle(carouselList,presentTransformVal);
                                    currentSlide--;
                                    isSliding=0;
                                }
                            }
                        }
                    }

                    var getCurrentTransformVal = function(){
                        var transformStr = carouselList.style.transform;
                        var modifiedTransformStr = transformStr.substring(transformStr.indexOf("3d(")+3,transformStr.indexOf(",",transformStr.indexOf("3d(")));
                        modifiedTransformStr = modifiedTransformStr.replace("px","");
                        modifiedTransformStr = parseInt(modifiedTransformStr);
                        return modifiedTransformStr;
                    }
                    initCarousel();

                    $rootScope.$on('orientationChanged', function(isOrientationChanged){
                        if(isOrientationChanged){
                            isSliding=1;
                            $timeout(function(){
                                removeEmptyLis(carouselList);
                                addEmptyLis(carouselList);
                                addTransitionStyle(carouselList,"");
                                addTransformStyle(carouselList,0);
                                carouselItems = angular.element(carouselList).children();
                                carouselItemsLength = carouselItems.length;
                                carouselItemsVisible = calculateBlocksToMove(carouselScreen,carouselItems,carouselItemsLength);
                                maxSlides = (carouselItemsLength%carouselItemsVisible)==0?(carouselItemsLength/carouselItemsVisible):(parseInt(carouselItemsLength/carouselItemsVisible)+1);
                                currentSlide = 0;
                                isSliding=0;
                            },300);
                        }
                    });


                }
            }
        })
		.directive('dirDreamStories', function($window, $interval, HelperService, $q, $rootScope,$timeout) {
		            return {
		                scope: {
		                    prev_active_class: '@prevActive',
		                    prev_inactive_class: '@prevInactive',
		                    next_active_class: '@nextActive',
		                    next_inactive_class: '@nextInactive',
		                    on_page_load:'@onPageLoad',
		                    auto_scroll:'@autoScroll',
		                    arrow_events:'@arrowEvents',
		                    stop_scroll_on_click:'@stopScrollOnClick',
		                    page_name:'@pageName',
                            move_slow:'@moveSlow'
		                },
		                restrict: 'A',
		                replace: false,
		                link: function(scope, elem, attrs) {

		                    var carousel = function() {
		                        var hf, move_unit, move_timeout, scrolling_status,
		                            visible_portion, list_parent, list_elements, list_elem_width,
		                            running_status, prev_limit, visible_list_elems, next_limit, prev_arrow,
		                            next_arrow, dependents, cal_index;
		                        var self = this,
		                            hf = HelperService,
		                            running_status = 0,
		                            move_unit = 40,
		                            move_timeout = 20,
		                            select_index = 1;

		                        this.init = function() {
		                        	$timeout(function() {
		                        		scope.auto_scroll_init = 0;

		                        		if(scope.auto_scroll == 1)
		                        			scope.auto_scroll_init = ($rootScope.mobWidthFlag == 1 || $rootScope.hybridWidthFlag == 1)? 0 : 1;
		                        		move_timeout = $rootScope.mobWidthFlag == 1 ? 15 : move_timeout;
		                        		if(scope.auto_scroll_init == 0)
		                                	scope.scrolling_status = 0;
		                                else
		                                	scope.scrolling_status = 1;
		                            });
		                            visible_portion = elem[0].getElementsByClassName('c_screen')[0];
		                            list_parent = elem[0].getElementsByClassName('c_list')[0];
		                            list_elements = elem[0].getElementsByClassName('c_list_item');
		                            prev_arrow = elem[0].getElementsByClassName('c_prev')[0];
		                            next_arrow = elem[0].getElementsByClassName('c_next')[0];
		                            dependents = elem[0].getElementsByClassName('c_dependent')[0];
		                            list_elem_width = list_elements[0].offsetWidth;

		                            prev_limit = list_parent.offsetLeft;
		                            visible_list_elems = (Math.floor(visible_portion.offsetWidth / list_elem_width) === 0) ? Math.round(visible_portion.offsetWidth / list_elem_width) : Math.floor(visible_portion.offsetWidth / list_elem_width);
		                            next_limit = list_elem_width * (visible_list_elems - list_elements.length) + list_parent.offsetLeft;

		                            cal_index = list_elements.length > 5 ? 1 : parseInt(list_elements.length/2);
		                            select_index = cal_index;
		                            select_index = ($rootScope.hybridWidthFlag) ? 1 : cal_index;
		                            if($rootScope.hybridWidthFlag)
		                            move_timeout = list_elements.length < 4 ? 2 : move_timeout;

		                            if( list_elements.length <= 1 || list_elements.length <= visible_list_elems ) {
		                                angular.element(prev_arrow).removeClass(scope.prev_active_class).addClass(scope.prev_inactive_class);
		                                angular.element(next_arrow).removeClass(scope.next_active_class).addClass(scope.next_inactive_class);
		                            }
		                        };

		                        this.init();

		                        this.styleSelectedStory = function(pAction) {
		                            var selected_position = angular.element(list_elements[select_index]).attr('c_pos');
		                            if(pAction == 'removeClass') {
		                                angular.element(elem[0].getElementsByClassName('c_story')).removeClass('selected_stories');
		                                angular.element(dependents.querySelectorAll('[c_pos]')).css({'display':'none'});
		                            } else if(pAction == 'addClass') {
                                                if(list_elements[select_index]) {
                                                    angular.element(list_elements[select_index].getElementsByClassName('c_story')[0]).addClass('selected_stories');
                                                    angular.element(dependents.querySelector('[c_pos="'+selected_position+'"]')).css({'display':'block'});
                                                }
		                            }
		                        };

		                        self.styleSelectedStory('removeClass');
		                        self.styleSelectedStory('addClass');

		                        var animateLeft = function(obj, from, to, limit, deferred, pDoNotStyle) {
		                            if(!deferred){
		                                deferred = $q.defer();
		                            }
		                            running_status = 1;
		                            if (from === to) {
		                                var firstElement = list_elements[0];
		                                var clonedElement = firstElement.cloneNode(true);
		                                obj.appendChild(clonedElement);
		                                obj.removeChild(firstElement);

		                                running_status = 0;
		                                obj.style.left = (from + list_elem_width) + "px";
		                                if(pDoNotStyle !== true){
											self.styleSelectedStory('removeClass');
		                                    self.styleSelectedStory('addClass');
		                                }
		                                deferred.resolve(pDoNotStyle);
		                                return deferred.promise;
		                            }
		                            else {
		                                var box = obj;
		                                var unit = ((from - to) < move_unit) ? (from - to) : move_unit;
		                                box.style.left = from + "px";

		                                setTimeout(function() {
		                                    animateLeft(obj, from - unit, to, limit, deferred, pDoNotStyle);
		                                }, move_timeout);
		                            }

		                            return deferred.promise;
		                        };

		                        var animateRight = function(obj, from, to, limit, deferred, pDoNotStyle) {
		                            if(!deferred){
		                                deferred = $q.defer();
		                            }

		                            if(running_status == 0) {
		                                var lastElement = list_elements[list_elements.length - 1];
		                                var clonedElement = lastElement.cloneNode(true);
		                                obj.insertBefore(clonedElement, obj.firstChild);
		                                obj.removeChild(lastElement);
		                                obj.style.left = (from - list_elem_width) + "px";
		                                from = from - list_elem_width;
		                                to = to - list_elem_width;
		                            }

		                            running_status = 1;
		                            if (from === to) {
		                                running_status = 0;
		                                obj.style.left = from + "px";
		                                if(pDoNotStyle !== true) {
											self.styleSelectedStory('removeClass');
		                                    self.styleSelectedStory('addClass');
		                                }
		                                deferred.resolve(pDoNotStyle);
		                                return deferred.promise;
		                            }
		                            else {
		                                var box = obj;
		                                var unit = ((to - from) < move_unit) ? (to - from) : move_unit;
		                                box.style.left = from + "px";

		                                setTimeout(function() {
		                                    animateRight(obj, from + unit, to, null, deferred, pDoNotStyle);
		                                }, move_timeout);
		                            }

		                            return deferred.promise;
		                        };

		                        var showPreviousBlock = function(pDoNotStyle) {
		                            self.init();
		                            if(running_status == 1) {
		                                return false;
		                            }
		                            var from = list_parent.offsetLeft;
		                            var to = list_parent.offsetLeft + list_elem_width;
		                            var promise = animateRight(list_parent, from, to, prev_limit, null, pDoNotStyle).then(function(){});
		                            return promise;
		                        };

		                        var showNextBlock = function(pDoNotStyle) {
		                            self.init();
		                            if(running_status == 1) {
		                                return false;
		                            }
		                            var from = list_parent.offsetLeft;
		                            var to = list_parent.offsetLeft - list_elem_width;
		                            var promise = animateLeft(list_parent, from, to, next_limit, null, pDoNotStyle).then(function(){});
		                            return promise;
		                        };

		                        var closestCallback = function() {
		                            if(this.getAttribute && this.getAttribute('c_pos')) {
		                                return this;
		                            }
		                        };
		                        scope.leftClick = false;
		                        angular.element(prev_arrow).on('click', function() {
		                            if(scope.arrow_events == 1 && !scope.leftClick){
		                                var ga = new gaEventsTracker();
		                                ga.gaFireInteractiveEvents('Category_advisor_scroll_left', scope.page_name);
		                                scope.leftClick = true;
		                            }
		                            showPreviousBlock();
		                        });
		                        scope.rightClick = 0;
		                        angular.element(next_arrow).on('click', function() {
		                            if(scope.arrow_events == 1 && scope.rightClick == 1){
                                        var ga = new gaEventsTracker();
                                        ga.gaFireInteractiveEvents('Category_advisor_scroll_right', scope.page_name);
                                        scope.rightClick++;
                                    } else {
                                        scope.rightClick++;
                                    }
		                            showNextBlock();
		                        });

		                        elem.on('mouseover', function() {
		                        	scope.scrolling_status = 0;
		                        });

		                        elem.on('mouseleave', function() {
		                        	scope.scrolling_status = 1;
		                        });

		                        elem.on('touchend', function() {
		                        	$timeout(function() {
		                        		if(scope.auto_scroll_init)
		                        			scope.scrolling_status = 1;
		                        	}, 2000);
		                        });

		                        if(typeof scope.move_slow != 'undefined' && scope.move_slow == 1 ) {
		                            $interval(function() {
		                                if(scope.scrolling_status && scope.auto_scroll_init == 1) {
                                            $timeout(function () {
		                                    angular.element(next_arrow).triggerHandler('click');
                                        }, 10);
		                                }
		                            }, 10000);
		                        } else {
                                    $interval(function() {
                                        if(scope.scrolling_status  && scope.auto_scroll_init == 1) {
                                            $timeout(function () {
                                            angular.element(next_arrow).triggerHandler('click');
                                        }, 10);
                                        }
                                    }, 3000);
                                }

		                        angular.element(visible_portion).on('click', function(pEvt) {
		                            if(scope.stop_scroll_on_click == undefined || scope.stop_scroll_on_click != 1){
		                                self.init();
    		                            var target_elem = hf.$(pEvt.target).closest(closestCallback);
    		                            if(!target_elem) {
    		                                return false;
    		                            }
    		                            var index = parseInt(angular.element(target_elem.elem()).attr('c_pos'));
                                            for(var i=0;i<list_elements.length;i++) {
    		                                if(list_elements[i].getAttribute('c_pos') == index) {
    		                                    var list_position = i;
    		                                    break;
    		                                }
    		                            }

    		                            if(list_position < select_index) {
    		                                var diff = select_index - list_position;
    		                                var promises = [];
    		                                for(var i=0;i<diff;i++) {
    		                                    if(i===0) {
    		                                        promises[i] = showPreviousBlock(true);
    		                                    } else {
    		                                        promises[i] = promises[i-1].then(showPreviousBlock);
    		                                    }
    		                                }
    		                                $q.all(promises).then(function() {
    		                                    self.styleSelectedStory('removeClass');
    		                                    self.styleSelectedStory('addClass');
    		                                });
    		                            } else if(list_position > select_index) {
    		                                var diff = list_position - select_index;
    		                                var promises = [];
    		                                for(var i=0;i<diff;i++) {
    		                                    if(i===0) {
    		                                        promises[i] = showNextBlock(true);
    		                                    } else {
    		                                        promises[i] = promises[i-1].then(showNextBlock);
    		                                    }
    		                                }
    		                                $q.all(promises).then(function() {
    		                                    self.styleSelectedStory('removeClass');
    		                                    self.styleSelectedStory('addClass');
    		                                });
    		                            }
    		                        }
		                        });

		                        hf.$(visible_portion).onSwipeLeft(function() {
		                            var items = elem[0].getElementsByClassName('c_list_item');
		                            if(items.length != undefined && items.length > 1)
		                                showNextBlock();
		                        });

		                        hf.$(visible_portion).onSwipeRight(function() {
		                            var items = elem[0].getElementsByClassName('c_list_item');
		                            if(items.length != undefined && items.length > 1)
                                        showPreviousBlock();
		                        });

		                        hf.$(dependents).onSwipeLeft(function() {
		                            var items = elem[0].getElementsByClassName('c_list_item');
		                            if(items.length != undefined && items.length > 1)
                                        showNextBlock();
		                        });

		                        hf.$(dependents).onSwipeRight(function() {
		                            var items = elem[0].getElementsByClassName('c_list_item');
		                            if(items.length != undefined && items.length > 1)
                                        showPreviousBlock();
		                        });
		                    };

		                    var carouselObj = null;
		                    angular.element($window).on('load', function() {
		                        carouselObj = new carousel();
		                    });

		                    $rootScope.$on('orientationChanged', function(pEvt, pVal) {
		                        if(pVal && carouselObj) {
		                            carouselObj.init();
		                            carouselObj.styleSelectedStory('removeClass');
		                            carouselObj.styleSelectedStory('addClass');

		                        }
		                    });
		                }
		            };
		})
        .directive('scrollPosition', function($window) {
            return {
                scope: {
                    scrollVal: '=scrollPage',
                    showStickyHeader: '=showStickyHeader',
                    defaultHeight: '=defaultHeight',
                    isStickyFlag: '='
                },
                link: function(scope, element, attrs) {
                    var windowEl = angular.element($window);
                    var handler = function() {
                        scope.scrollVal = window.pageYOffset;
                        if (window.pageYOffset > scope.defaultHeight) {
                            scope.showStickyHeader = {'display': 'block'};
                            scope.isStickyFlag = 1;

                        } else {
                            scope.showStickyHeader = {'display': 'none'};
                            scope.isStickyFlag = 0;
                        }
                    }
                    windowEl.on('scroll', scope.$apply.bind(scope, handler));
                    handler();
                }
            };
        })
        .directive('customCheckbox', function() {
            return{
                scope: {
                },
                link: function(scope, element, attrs) {
                    element.on('click', function() {
                        if (element.hasClass("default_img")) {
                            element.removeClass("default_img");
                            element.addClass("selected_img");
                        } else {
                            element.addClass("default_img");
                            element.removeClass("selected_img");
                        }

                    });
                }
            }
        })
        .directive('dirCustomRadioBtns', function() {
            return{
                scope: {
                    radioClass:'@',
                    radioChecked:'@',
                    radioUnchecked:'@'
                },
                link: function(scope, element, attrs) {
                    var radio_btns = element[0].getElementsByClassName(scope.radioClass);

                    angular.element(radio_btns).on('click', function() {
                        var targetElem = angular.element(this);

                        //if button is unchecked, remove all checked buttons and check current button
                        if (targetElem.hasClass(scope.radioUnchecked)) {
                            angular.element(radio_btns).removeClass(scope.radioChecked);
                            angular.element(radio_btns).addClass(scope.radioUnchecked);
                            targetElem.removeClass(scope.radioUnchecked);
                            targetElem.addClass(scope.radioChecked);
                        } else {
                            targetElem.addClass(scope.radioUnchecked);
                            targetElem.removeClass(scope.radioChecked);
                        }
                    });
                }
            }
        })
        .directive('dirFormSubmit', function() {
            return {
                scope: {
                    formId: '@dirFormSubmit',
                    formData: '@'
                },
                restrict: 'A',
                replace: false,
                link: function(scope, elem, attrs) {
                    elem.on('click', function() {
                        var formObj = document.getElementById(scope.formId);
                        if(formObj){
                            scope.formData = eval('(' + scope.formData + ')');
                            for (param in scope.formData) {
                                var input = document.createElement('input');
                                input.type = 'hidden';
                                input.name = param;
                                input.value = scope.formData[param];
                                formObj.appendChild(input);
                            }
                            formObj.submit();
                        }
                    });
                }
            };
        })
        .directive('stopEvent', function() {
            return {
                restrict: 'A',
                replace: false,
                link: function(scope, element, attr) {
                    var evt = attr.stopEvent || 'click';
                    element.bind(evt, function(e) {
                        e.stopPropagation();
                    });
                }
            };
        })
        .directive("closeOnEscape", function($document) {
            return {
                scope: {
                    closeFn: '&closeOnEscape'
                },
                link: function(scope) {
                    $document.on("keyup", function(event) {
                        if (event.keyCode === 27) {
                            scope.$apply(function() {
                                scope.closeFn();
                            });
                        }
                    });
                }
            };
        })
        .directive('dirAccordion', function($timeout) {
            return {
                scope: {
                    activeHeadClass: '@accHeadClass',
                    arrowUpClass: '@accArrowUp',
                    arrowDownClass: '@accArrowDown',
                    activeShadeClass: '@activeShadeClass',
                    inactiveShadeClass: '@inactiveShadeClass',
                    autoScrollLimit: '@autoScrollLimit',
                    enableScroll: '@enableScroll',
                    keepFirstClosed:'='
                },
                restrict: 'A',
                replace: false,
                link: function(scope, elem, attrs) {
                    var scrollLimit = 40;/* 40 is sticky banner height */
                    if(typeof scope.autoScrollLimit != 'undefined') {
                        scrollLimit = scope.autoScrollLimit;
                    }
                    //firing timeout so that directive executes after dom is ready
                    $timeout(function() {

                        var height_arr = new Array();
                        var acc_dropdown_temp = elem.children();
                        var acc_dropdown = new Array();

                        //for( prop in acc_dropdown_temp )
                        for (var i = 0; i < acc_dropdown_temp.length; i++) {
                            if (angular.element(acc_dropdown_temp[i]).hasClass('acc-exclude')) {
                                continue;
                            }
                            //this plugin assumes that the each accordion element will have 2 children, one containing the heading and the other the content.
                            acc_dropdown.push(angular.element(acc_dropdown_temp[i]).children()[0]);
                            acc_dropdown.push(angular.element(acc_dropdown_temp[i]).children()[1]);
                        }

                        var move_unit = 50,
                                move_timeout = 20;

                        var init_accordion = function() {

                            for (var i = 1; i < acc_dropdown.length; i += 2) {
                                angular.element(acc_dropdown[i]).css('padding', '0');
                                angular.element(acc_dropdown[i]).css('margin', '0');
                                angular.element(acc_dropdown[i]).css('overflow', 'hidden');
                                angular.element(acc_dropdown[i]).attr('a_index', (i - 1) / 2);
                                height_arr.push(acc_dropdown[i].offsetHeight);
                                //keepFirstClosed = 1 is used to keep first one closed by default
                                if( (typeof scope.keepFirstClosed !='undefined' && scope.keepFirstClosed == 1)) { //this will execute if keepFirstClosed = 1 or element is not the first one
                                // if( (typeof scope.keepFirstClosed !='undefined' && scope.keepFirstClosed == 1) || i > 1 ) { //this will execute if keepFirstClosed = 1 or element is not the first one
                                    angular.element(acc_dropdown[i]).css('height', '0');
                                    angular.element(acc_dropdown[i]).removeClass('acc-active');
                                    if (!!scope.activeHeadClass)
                                        angular.element(acc_dropdown[i - 1]).removeClass(scope.activeHeadClass);

                                    if (!!scope.arrowUpClass && !!scope.arrowDownClass)
                                        angular.element(acc_dropdown[i - 1].getElementsByClassName('acc-arrow')[0]).removeClass(scope.arrowUpClass).addClass(scope.arrowDownClass);

                                }
                                // else {//this will execute if element is the first one
                                //     if (!!scope.activeHeadClass)
                                //         angular.element(acc_dropdown[i - 1]).addClass(scope.activeHeadClass);

                                //     if (!!scope.arrowUpClass && !!scope.arrowDownClass)
                                //         angular.element(acc_dropdown[i - 1].getElementsByClassName('acc-arrow')[0]).removeClass(scope.arrowDownClass).addClass(scope.arrowUpClass);
                                // }

                                if( i == 1 ) {      //always keep class acc-active for first element
                                    angular.element(acc_dropdown[i]).addClass('acc-active');
                                }
                            }
                        }();

                        var divHeight = function(ele) {
                            var x = 0;
                            while (ele) {
                                x += ele.offsetTop;
                                ele = ele.offsetParent;
                            }
                            return x;
                        };

                        var slideAction = function(elemObj){
                            var parentObj = elemObj.parentNode;
                            var heightDiff = (divHeight(parentObj)-window.pageYOffset-scrollLimit);
                            var pageYOffset = window.pageYOffset;
                            if(heightDiff >= 150){
                                window.scrollBy(0,150);
                                if(pageYOffset == window.pageYOffset) {
                                    return false;
                                }
                                setTimeout(function(){slideAction(elemObj,heightDiff);},10);
                            }else if(150 >= heightDiff && heightDiff >= 100){
                                window.scrollBy(0,100);
                                if(pageYOffset == window.pageYOffset) {
                                    return false;
                                }
                                setTimeout(function(){slideAction(elemObj,heightDiff);},10);
                            }else if(100 >= heightDiff && heightDiff >= 60){
                                window.scrollBy(0,60);
                                if(pageYOffset == window.pageYOffset) {
                                    return false;
                                }
                                setTimeout(function(){slideAction(elemObj,heightDiff);},10);
                            }else{
                                window.scrollBy(0,(divHeight(parentObj)-window.pageYOffset)-scrollLimit);
                                return false;
                            }
                            return true;
                        };

                        var animateDown = function(elemObj, fromHeight, toHeight) {
//                            if (fromHeight === toHeight) {
//                                elemObj.style.height = 'auto';
//                                return false;
//                            }
//                            else {
//                                var unit = ((toHeight - fromHeight) < move_unit) ? (toHeight - fromHeight) : move_unit;
//                                elemObj.style.height = fromHeight + 'px';
//                                setTimeout(function() {
//                                    animateDown(elemObj, fromHeight + unit, toHeight);
//                                }, move_timeout);
//                            }
//
//                            return true;

                            elemObj.style.height = 'auto';
                            if(typeof scope.enableScroll == 'undefined' || scope.enableScroll == 1) {
                                setTimeout(function(){
                                    slideAction(elemObj);
                                },50);
                            }
                            return false;
                        };

                        var animateUp = function(elemObj, height) {
//                            if (height === 0) {
//                                elemObj.style.height = height + 'px';
//                                return false;
//                            }
//                            else {
//                                var unit = (height < move_unit) ? height : move_unit;
//                                elemObj.style.height = height + 'px';
//                                setTimeout(function() {
//                                    animateUp(elemObj, height - unit);
//                                }, move_timeout);
//                            }
//
//                            return true;

                            elemObj.style.height = '0';
                                return false;
                        };

                        var showElement = function(newElem, oldElem) {
                            var new_elem_height = height_arr[angular.element(newElem).attr('a_index')];
                            if( newElem === oldElem && ( newElem.style.height === '0' || newElem.style.height === '0px' ) ) {
                                animateDown(newElem, newElem.offsetHeight, new_elem_height);
                            }
                            else if( newElem === oldElem && ( newElem.style.height !== '0' || newElem.style.height !== '0px' ) ) {
                                animateUp(oldElem, oldElem.offsetHeight);
                            }
                            else {
                                animateUp(oldElem, oldElem.offsetHeight);
                                animateDown(newElem, newElem.offsetHeight, new_elem_height);
                            }
                        };

                        for (var i = 0; i < acc_dropdown.length; i+=2) {

                        angular.element(acc_dropdown[i]).on('click', function(e) {

                            if (angular.element(this).parent().hasClass('acc-exclude'))
                                return;

                            var new_elem = angular.element(this).parent().children()[1],
                                    new_elem_head = angular.element(this)[0],
                                    old_elem = angular.element(this).parent().parent()[0].getElementsByClassName('acc-active')[0],
                                    old_elem_head = angular.element(old_elem).parent().children()[0];

                            if (angular.element(new_elem).hasClass('acc-active')) {
                                //return;
                            }

                            if (!!scope.activeHeadClass) {
                                if( new_elem === old_elem && angular.element(new_elem_head).hasClass(scope.activeHeadClass) ) {
                                    angular.element(new_elem_head).removeClass(scope.activeHeadClass);
                                }
                                else if( new_elem === old_elem && !angular.element(new_elem_head).hasClass(scope.activeHeadClass) ) {
                                    angular.element(new_elem_head).addClass(scope.activeHeadClass);
                                }
                                else {
                                    angular.element(old_elem_head).removeClass(scope.activeHeadClass);
                                    angular.element(new_elem_head).addClass(scope.activeHeadClass);
                                }
                            }

                            if (!!scope.arrowUpClass && !!scope.arrowDownClass) {
                                if( new_elem === old_elem && angular.element(new_elem_head.getElementsByClassName('acc-arrow')[0]).hasClass(scope.arrowDownClass) ) {
                                    angular.element(new_elem_head.getElementsByClassName('acc-arrow')[0]).removeClass(scope.arrowDownClass).addClass(scope.arrowUpClass);
                                }
                                else if( new_elem === old_elem && !angular.element(new_elem_head.getElementsByClassName('acc-arrow')[0]).hasClass(scope.arrowUpClass) ) {
                                    angular.element(new_elem_head.getElementsByClassName('acc-arrow')[0]).removeClass(scope.arrowUpClass).addClass(scope.arrowDownClass);
                                }
                                else {
                                    angular.element(new_elem_head.getElementsByClassName('acc-arrow')[0]).removeClass(scope.arrowDownClass).addClass(scope.arrowUpClass);
                                    angular.element(old_elem_head.getElementsByClassName('acc-arrow')[0]).removeClass(scope.arrowUpClass).addClass(scope.arrowDownClass);
                                }
                            }

                            angular.element(old_elem).removeClass('acc-active');
                            angular.element(new_elem).addClass('acc-active');

                            showElement(new_elem, old_elem);

                            if(scope.activeShadeClass != '' && scope.inactiveShadeClass != '') {
                                var liMembers = angular.element(this).parent().parent().children();
                                if(old_elem != new_elem) {
                                    for(var count = 0; count < liMembers.length; count++) {
                                        var currentLi = angular.element(liMembers[count]).children()[0];
                                        angular.element(currentLi).removeClass(scope.activeShadeClass).addClass(scope.inactiveShadeClass);
                                    }
                                }
                                var classedElement = angular.element(this);
                                if(classedElement.hasClass(scope.inactiveShadeClass)) {
                                    classedElement.removeClass(scope.inactiveShadeClass).addClass(scope.activeShadeClass);
                                } else if(classedElement.hasClass(scope.activeShadeClass)) {
                                    classedElement.removeClass(scope.activeShadeClass).addClass(scope.inactiveShadeClass);
                                }
                            }
                        });
                        }
                    }, 100);
                }
            };
        }).directive('dirMultiAccordion', function($timeout) {
    return {
        scope: {
            acc_levels: "@accLevels",
            compile_acc:"=compileAcc",
            compile_check:"=compileCheck",
            enableScroll: '@enableScroll',
        },
        restrict: 'A',
        replace: false,
        link: function(scope, elem, attrs) {
            //firing timeout so that directive executes after dom is ready
            $timeout(function() {

                if (parseInt(scope.acc_levels) < 2)
                    return;

                var setupAccordion = function(accObj, level) {

                    var acc_obj = angular.element(accObj);
                    var acc_dropdown_temp = acc_obj.children();
                    var acc_dropdown = new Array();
                    var arrowUpClass = acc_obj.attr('acc-arrow-up');
                    var arrowDownClass = acc_obj.attr('acc-arrow-down');

                    //for( prop in acc_dropdown_temp )
                    for (var i = 0; i < acc_dropdown_temp.length; i++) {
                        if (angular.element(acc_dropdown_temp[i]).hasClass('acc-exclude')) {
                            continue;
                        }
                        //this plugin assumes that the each accordion element will have 2 children, one containing the heading and the other the content.
                        acc_dropdown.push(angular.element(acc_dropdown_temp[i]).children()[0]);
                        acc_dropdown.push(angular.element(acc_dropdown_temp[i]).children()[1]);
                    }

                    var move_unit = 500,
                        move_timeout = 100;
                    var init_accordion = function() {

                        for (var i = 1; i < acc_dropdown.length; i += 2) {
                            angular.element(acc_dropdown[i]).css('padding', '0');
                            angular.element(acc_dropdown[i]).css('margin', '0');
                            angular.element(acc_dropdown[i]).css('overflow', 'hidden');
                            angular.element(acc_dropdown[i]).attr('a_index', (i - 1) / 2);
                            angular.element(acc_dropdown[i]).attr('a_height', acc_dropdown[i].offsetHeight);

                            //acc-close-first = 1 is used to keep first one closed by default
                            if( acc_obj.attr("acc-close-first") == 1 || i > 1 ) { //this will execute if attribute acc-close-first = 1 or element is not the first one
                                angular.element(acc_dropdown[i]).css('height', '0');
                                angular.element(acc_dropdown[i]).removeClass('acc-active');
                                angular.element(acc_dropdown[i]).attr('acc-level', level);
                                if (!!scope.activeHeadClass)
                                    angular.element(acc_dropdown[i - 1]).removeClass(scope.activeHeadClass);

                                if (!!arrowUpClass && !!arrowDownClass)
                                    angular.element(acc_dropdown[i - 1].getElementsByClassName('acc-arrow')[0]).removeClass(arrowUpClass).addClass(arrowDownClass);
                            } else {//this will execute if element is the first one
                                angular.element(acc_dropdown[i]).attr('acc-level', level);
                                if (!!scope.activeHeadClass)
                                    angular.element(acc_dropdown[i - 1]).addClass(scope.activeHeadClass);

                                if (!!arrowUpClass && !!arrowDownClass)
                                    angular.element(acc_dropdown[i - 1].getElementsByClassName('acc-arrow')[0]).removeClass(arrowDownClass).addClass(arrowUpClass);
                            }

                            if( i == 1 ) {      //always keep acc-active class in first element
                                angular.element(acc_dropdown[i]).addClass('acc-active');
                            }
                        }
                    }();

                    var divHeight = function(ele) {
                            var x = 0;
                            while (ele) {
                                x += ele.offsetTop;
                                ele = ele.offsetParent;
                            }
                            return x;
                        };

                    var slideAction = function(elemObj){
                            var heightDiff = (divHeight(elemObj)-window.scrollY)-80;
                            if(heightDiff >= 150){
                                window.scrollBy(0,150);
                                setTimeout(function(){slideAction(elemObj,heightDiff);},10);
                            }else if(150 >= heightDiff && heightDiff >= 100){
                                window.scrollBy(0,100);
                                setTimeout(function(){slideAction(elemObj,heightDiff);},10);
                            }else if(100 >= heightDiff && heightDiff >= 50){
                                window.scrollBy(0,50);
                                setTimeout(function(){slideAction(elemObj,heightDiff);},10);
                            }else{
                                window.scrollBy(0,(divHeight(elemObj)-window.scrollY)-80);
                                return false;
                            }
                            return true;
                        };

                    var animateDown = function(elemObj, fromHeight, toHeight) {
//                        if (fromHeight === toHeight) {
//                            elemObj.style.height = fromHeight + 'px';
//                            return false;
//                        }
//                        else {
//                            var unit = ((toHeight - fromHeight) < move_unit) ? (toHeight - fromHeight) : move_unit;
//                            elemObj.style.height = fromHeight + 'px';
//                            setTimeout(function() {
//                                animateDown(elemObj, fromHeight + unit, toHeight);
//                            }, move_timeout);
//                        }
//
//                        return true;
                            elemObj.style.height = 'auto';
                            if(typeof scope.enableScroll == 'undefined' || scope.enableScroll == 1) {
                                setTimeout(function(){
                                    slideAction(elemObj);
                                },50);
                            }
                            return false;
                    };

                    var animateUp = function(elemObj, height, limit) {
//                        if (height === 0) {
//                            elemObj.style.height = height + 'px';
//                            return false;
//                        }
//                        else if (limit !== null && height === limit) {
//                            elemObj.style.height = height + 'px';
//                            return false;
//                        }
//                        else {
//                            var unit = (height < move_unit) ? height : move_unit;
//                            elemObj.style.height = height + 'px';
//                            setTimeout(function() {
//                                animateUp(elemObj, height - unit, limit);
//                            }, move_timeout);
//                        }
//
//                        return true;
elemObj.style.height = '0';
                                return false;
                    };

                    var showElement = function(newElem, oldElem) {
                        var new_elem_height = parseInt(angular.element(newElem).attr('a_height'));

                        if( newElem === oldElem && ( newElem.style.height === '0' || newElem.style.height === '0px' ) ) {
                            animateDown(newElem, newElem.offsetHeight, new_elem_height);
                        }
                        else if( newElem === oldElem && ( newElem.style.height !== '0' && newElem.style.height !== '0px' ) ) {
                            animateUp(oldElem, oldElem.offsetHeight);
                        }
                        else {
                            animateDown(newElem, newElem.offsetHeight, new_elem_height);
                            animateUp(oldElem, oldElem.offsetHeight, null);
                        }

                        var curr_level = angular.element(newElem).attr('acc-level');

                        for (var i = 1; i < curr_level; i++) {
                            var new_parent_elem = angular.element(newElem).parent().parent();
                            new_parent_elem.css('height', 'auto');
                        }

                        angular.element(oldElem).attr('a_height', oldElem.offsetHeight);
                    };

                    for (var i = 0; i < acc_dropdown.length; i+=2) {

                    //acc_obj.children().on('click', function() {
                    angular.element(acc_dropdown[i]).on('click', function() {

                        if (angular.element(this).parent().hasClass('acc-exclude'))
                            return;

                        var new_elem = angular.element(this).parent().children()[1],
                                new_elem_head = angular.element(this).parent().children()[0];

                        var old_elem = angular.element(this).parent().parent()[0].getElementsByClassName('acc-active');

                        //find active element inside the same level accordion
                        for (var i = 0; i < old_elem.length; i++) {
                            if (angular.element(old_elem[i]).attr('acc-level') == level) {
                                old_elem = old_elem[i];
                                break;
                            }
                        }

                        var old_elem_head = angular.element(old_elem).parent().children()[0];

                        if (angular.element(new_elem).hasClass('acc-active')) {
                            //return;
                        }

                        if (!!scope.activeHeadClass) {
                            if( new_elem === old_elem && angular.element(new_elem_head).hasClass(scope.activeHeadClass) ) {
                                angular.element(new_elem_head).removeClass(scope.activeHeadClass);
                            }
                            else if( new_elem === old_elem && !angular.element(new_elem_head).hasClass(scope.activeHeadClass) ) {
                                angular.element(new_elem_head).addClass(scope.activeHeadClass);
                            }
                            else {
                                angular.element(old_elem_head).removeClass(scope.activeHeadClass);
                                angular.element(new_elem_head).addClass(scope.activeHeadClass);
                            }
                        }

                        if (!!arrowUpClass && !!arrowDownClass) {
                            if( new_elem === old_elem && angular.element(new_elem_head.getElementsByClassName('acc-arrow')[0]).hasClass(arrowDownClass) ) {
                                angular.element(new_elem_head.getElementsByClassName('acc-arrow')[0]).removeClass(arrowDownClass).addClass(arrowUpClass);
                            }
                            else if( new_elem === old_elem && !angular.element(new_elem_head.getElementsByClassName('acc-arrow')[0]).hasClass(arrowUpClass) ) {
                                angular.element(new_elem_head.getElementsByClassName('acc-arrow')[0]).removeClass(arrowUpClass).addClass(arrowDownClass);
                            }
                            else {
                                angular.element(new_elem_head.getElementsByClassName('acc-arrow')[0]).removeClass(arrowDownClass).addClass(arrowUpClass);
                                angular.element(old_elem_head.getElementsByClassName('acc-arrow')[0]).removeClass(arrowUpClass).addClass(arrowDownClass);
                            }
                        }

                        angular.element(old_elem).removeClass('acc-active');
                        angular.element(new_elem).addClass('acc-active');

                        showElement(new_elem, old_elem);
                    });
                    }
                };



                if(scope.compile_check == 1){
                    scope.$watch('compile_acc', function(newValue, oldValue) {
                        if (newValue == 1){
                            var levels = parseInt(scope.acc_levels);
                            var acc_arr = new Array();

                            for (i = 0; i < levels; i++) {
                                if (i === levels - 1) {
                                    var temp_acc = new Array(elem[0]);
                                }
                                else {
                                    var temp_acc = elem[0].querySelectorAll('[multi-acc-level="' + (levels - i) + '"]');
                                }
                                acc_arr.push(temp_acc);

                                for (var j = 0; j < temp_acc.length; j++) {
                                    setupAccordion(temp_acc[j], (levels - i));
                                }
                            }
                        }

                    }, true);
                }else{
                    var levels = parseInt(scope.acc_levels);
                    var acc_arr = new Array();

                    for (i = 0; i < levels; i++) {
                        if (i === levels - 1) {
                            var temp_acc = new Array(elem[0]);
                        }
                        else {
                            var temp_acc = elem[0].querySelectorAll('[multi-acc-level="' + (levels - i) + '"]');
                        }
                        acc_arr.push(temp_acc);

                        for (var j = 0; j < temp_acc.length; j++) {
                            setupAccordion(temp_acc[j], (levels - i));
                        }
                    }
                }


            }, 100);
        }
    };
})
        .directive('slideAnimation', function() {
            return {
                scope: {
                    slideMaxHeight: "@slideMaxHeight",
                    slideMinHeight: "@slideMinHeight",
                    slideSectionName: "@slideSectionName",
                    slideCollapsedClass: "@slideCollapsedClass",
                    slideExpandedClass: "@slideExpandedClass",
                    slideIndependentSection: "@slideIndependentSection",
                    slideSectionCollapse: "@slideSectionCollapse",
					moveUnit: "@moveUnit",
					slideMobVar:"=slideMobVar",
					mobMinHeight:"@mobMinHeight"
                },
                restrict: 'A',
                replace: false,
                link: function(scope, elem, attrs) {
					if(typeof scope.moveUnit == 'undefined')
					var move_unit = parseInt('50');
					else
					var move_unit = parseInt(scope.moveUnit);
                    elem.on('click', function(event) {
                        event.preventDefault();
						if(scope.slideMobVar == 1){
							var mobMinHeight = parseInt(scope.mobMinHeight);
							var par = elem.parent().parent().parent()[0];
							if(par.style.height == "auto"){
								par.style.height = mobMinHeight+"px";
								elem[0].className = elem[0].className.replace(scope.slideExpandedClass, scope.slideCollapsedClass);
							}else{
								par.style.height = "auto";
								elem[0].className = elem[0].className.replace(scope.slideCollapsedClass, scope.slideExpandedClass);
							}
						}else{
							var maxHeight = parseInt(scope.slideMaxHeight);
							var minHeight = parseInt(scope.slideMinHeight);

							if (scope.slideIndependentSection == "") {
								var parentDivObj = elem[0].parentNode;
								for (var i = 0; i < 5; i++) {
									if (parentDivObj.className.indexOf(scope.slideSectionName) != -1) {
										break;
									} else {
										parentDivObj = (parentDivObj).parentNode;
									}
								}
							} else {
								var parentDivObj = document.getElementsByClassName(scope.slideIndependentSection)[0];
							}
							if (parentDivObj.offsetHeight >= maxHeight) {
								animateUp(parentDivObj, maxHeight, minHeight);
								elem[0].className = elem[0].className.replace(scope.slideExpandedClass, scope.slideCollapsedClass);
								parentDivObj.className = parentDivObj.className + " " + scope.slideSectionCollapse;
							} else {
								animateDown(parentDivObj, minHeight, maxHeight);
								elem[0].className = elem[0].className.replace(scope.slideCollapsedClass, scope.slideExpandedClass);
								parentDivObj.className = parentDivObj.className.replace(scope.slideSectionCollapse, "");
							}
						}
                    });


                    var move_timeout = 10;

                    var animateDown = function(elemObj, fromHeight, toHeight) {
                        if (fromHeight === toHeight) {
                            elemObj.style.height = fromHeight + 'px';
                            return false;
                        }
                        else {
                            var unit = ((toHeight - fromHeight) < move_unit) ? (toHeight - fromHeight) : move_unit;
                            elemObj.style.height = fromHeight + 'px';
                            setTimeout(function() {
                                animateDown(elemObj, fromHeight + unit, toHeight);
                            }, move_timeout);
                        }

                        return true;
                    };

                    var animateUp = function(elemObj, height, limit) {
                        if (height === 0) {
                            elemObj.style.height = height + 'px';
                            return false;
                        }
                        else if (limit !== null && height === limit) {
                            elemObj.style.height = height + 'px';
                            return false;
                        }
                        else {
                            var unit = (height < move_unit) ? height : move_unit;
                            elemObj.style.height = height + 'px';
                            setTimeout(function() {
                                animateUp(elemObj, height - unit, limit);
                            }, move_timeout);
                        }

                        return true;
                    };
                }
            }
        })
        .directive('scrollLink', function() {
            return {
                scope: {
                    scrollTo: '@scrollTo',
                    offsetHeight: '@offsetHeight'
                },
                restrict: 'A',
                replace: false,
                link: function(scope, elem, attrs) {
                    elem.on('click', function(event) {
                        event.preventDefault();
                        if( scroll_running_status == 1 ) {
                            return false;
                        }
                        var scrollToObj = document.getElementsByClassName(scope.scrollTo)[0];
						if(typeof scrollToObj != 'undefined'){
							var mmyht = divHeight(scrollToObj) - parseInt(scope.offsetHeight);
							if (window.pageYOffset < mmyht){
								scrollDownAnimation(scrollToObj,scope.offsetHeight);
							}else if (window.pageYOffset > mmyht){
								scrollUpAnimation(scrollToObj,scope.offsetHeight);
							}
						}else{
							return false;
						}
                    });

                    var scrollDownAnimation = function(scrollToObj,htt) {
						var myht = divHeight(scrollToObj) - parseInt(htt);
                        scroll_running_status = 1;
                        var moveBy = 500;
                        var winPageYOffset = Math.ceil(window.pageYOffset);

                        if (winPageYOffset >= myht || ((window.innerHeight + winPageYOffset) >= document.body.offsetHeight) ) {     //if scrolled to reqd element or end of page reached
                            scroll_running_status = 0;
                            return false;
                        } else {

							if (150 < (myht - winPageYOffset) && (myht - winPageYOffset) <= 500) {
								moveBy = 150;
							}
							if (50 < (myht - winPageYOffset) && (myht - winPageYOffset) <= 150) {
								moveBy = 50;
							}
							if (0 < (myht - winPageYOffset) && (myht - winPageYOffset) <= 50) {
								moveBy = (myht - winPageYOffset);
							}

                            window.scrollBy(0, moveBy);
                            setTimeout(function() {
                                scrollDownAnimation(scrollToObj,htt);
                            }, 50);
                        }
                    }

                    var scrollUpAnimation = function(scrollToObj,htt) {
						var myht = divHeight(scrollToObj) - parseInt(htt);
                        scroll_running_status = 1;
                        var moveBy = -500;
                        if (window.pageYOffset <= myht ) {
                            scroll_running_status = 0;
                            return false;
                        } else {

							if (150 < (window.pageYOffset - myht) && (window.pageYOffset - myht) <= 500) {
								moveBy = -150;
							}
							if (50 < (window.pageYOffset - myht) && (window.pageYOffset - myht) <= 150) {
								moveBy = -50;
							}
							if (0 < (window.pageYOffset - myht) && (window.pageYOffset - myht) <= 50) {
								moveBy = -(window.pageYOffset - myht);
							}

                            window.scrollBy(0, moveBy);
                            setTimeout(function() {
                                scrollUpAnimation(scrollToObj,htt);
                            }, 50);
                        }
                    }

                    var divHeight = function(ele) {
                        var x = 0;
                        while (ele) {
                            x += ele.offsetTop;
                            ele = ele.offsetParent;
                        }
                        return x;
                    }
                }
            };
        })
        .directive('stickyElement', function($window) {
            return {
                scope: {
                    topPostion: '@topPostion',
                    stickyStyle: '=stickyStyle',
                    techMasterStyle: '=techMasterStyle',
                    offsetHeight: '@offsetHeight',
                    displayHeight: '@displayHeight',
                    stickyComponentDisplay: '=stickyComponentDisplay'
                },
                restrict: 'A',
                replace: false,
                link: function(scope, elem, attrs) {
                    var windowEl = angular.element($window);
                    var divHeight = function(ele) {
                        var x = 0;
                        while (ele) {
                            x += ele.offsetTop;
                            ele = ele.offsetParent;
                        }
                        return x;
                    }
                    var minHeight = elem[0].offsetTop + elem[0].parentNode.offsetTop;
                    //                    check offers banner is available or not
                    var offerBaner = document.getElementsByClassName('festive_offer_block');
                    if (offerBaner != 'undefined' && offerBaner.length > 0) {
                        var banerHght = document.getElementsByClassName('festive_offer_block')[0].clientHeight;
                        minHeight = minHeight+parseInt(banerHght);
                    }
                    var handler = function() {
                        if (window.pageYOffset > minHeight ) {
                        //if (window.pageYOffset > minHeight - parseInt(scope.offsetHeight)) {
                            scope.stickyStyle = {'position': 'fixed', 'top': '0px', 'z-index': '2'};
                            scope.techMasterStyle = {'position': 'fixed', 'top': '0px', 'z-index': '2'};
                            //scope.stickyStyle = {'position': 'fixed', 'top': scope.topPostion + 'px', 'z-index': '2'};
                            scope.stickyComponentDisplay = {'display':'inline-block'};
                        } else {
                            scope.stickyStyle = {};
                            scope.techMasterStyle = {'position': 'fixed', 'top': '-100px','z-index': '0'}
                            scope.stickyComponentDisplay = {'display':'none'};
                        }

                        if( !!scope.displayHeight ) {
                            if( window.pageYOffset > scope.displayHeight ) {
                                scope.stickyStyle['display'] = 'block';
                            }
                            else {
                                scope.stickyStyle['display'] = 'none';
                            }
                        }
                    }
                    windowEl.on('scroll', scope.$apply.bind(scope, handler));
                    handler();
                }
            };
        })
        .directive('dirPhnCodesSelect', function($timeout, LocService, $cookies) {
            return {
                scope: {
                    inputId: '@inputId'
                },
                restrict: 'A',
                replace: false,
                link: function(scope, elem, attrs) {

                    $timeout(function() {

                        var countryData = LocService.getAppCountryData();
                        var selected_country = LocService.getCurrentCountry();
                        var phn_code = (!!selected_country) ? selected_country.phnCode : '';

                        if (countryData === null) {
                            LocService.getCountryData().then(function(data) {
                                countryData = data;

                                //set current country using cookie
                                LocService.setCurrentCountry(null, JSON.parse($cookies.locatori9).country_id);

                                //get current country
                                selected_country = LocService.getCurrentCountry();

                                var phn_code = selected_country.phnCode;

                                document.getElementById(scope.inputId).value = "+"+phn_code+"-";
                                if( document.getElementById('phn_'+selected_country.id) ) {
                                    document.getElementById('phn_'+selected_country.id).selected = 'selected';
                                }
                            });
                        }

                        document.getElementById(scope.inputId).value = "+"+phn_code+"-";

                        if( document.getElementById('phn_'+selected_country.id) ) {
                            document.getElementById('phn_'+selected_country.id).selected = 'selected';
                        }

                        elem.on('change', function() {
                            var phn_code = angular.element(this.options[this.selectedIndex]).attr('phn-code');
                            document.getElementById(scope.inputId).focus();
                            document.getElementById(scope.inputId).value = "+"+phn_code+"-";
                        });
                    }, 0);

                }
            };
        })
        .directive('dirLink', function($timeout) {
            return {
                scope: {
                    new_url: '@dirLink',
                    new_url_scope:'=dirLinkScope'
                },
                restrict: 'A',
                replace: false,
                link: function(scope, elem, attrs) {

                    $timeout(function() {
                        elem.on('click', function() {
                            if(typeof scope.new_url != 'undefined' && scope.new_url != ''){
                                window.location.href = scope.new_url;
                            }else if(typeof scope.new_url_scope != 'undefined' && scope.new_url_scope != ''){
                                window.location.href = scope.new_url_scope;
                            }

                        });
                    }, 0);

                }
            };
})
        .directive('dirBackButton', function() {
            return {
                scope: {
                },
                restrict: 'A',
                replace: false,
                link: function(scope, elem, attrs) {
                    elem.on('click', function() {
                        window.history.back();
                    });
                }
            };
})
.directive('escAction',function(){
	return{
		scope:{
			showStatus:'=showStatus'
		},
		restrict: 'A',
		replace: false,
		link: function(scope,element,attrs){
			element.on('keydown',function(event){
				if(event.keyCode == 27){
				var eleStyle = (angular.element(angular.element(element[0].querySelector('header .login_outer'))[0]))[0];
					if(eleStyle.style.display == 'block'){
						scope.showStatus = false;
						scope.$apply();
					}
				}
			});
		}
	};
})
.directive('lazyLoadImg',function(){
	return{
		restrict: 'A',
		replace: false,
		link: function(scope,element,attrs){
                    	if(typeof isIE != 'undefined' && isIE != ''){
                                var lazyLoad = function(){
					var imgObjArr = element.find('img');
					var imgObjArrLen = imgObjArr.length;
					for(var i=0;i<imgObjArrLen;i++){
						var imgObj = angular.element(imgObjArr[i])[0];
						if(typeof angular.element(imgObjArr[i])[0].attributes['data-src'] != 'undefined' && angular.element(imgObjArr[i])[0].attributes['data-src'] != ''){
							angular.element(imgObjArr[i])[0].src = angular.element(imgObjArr[i])[0].attributes['data-src']['nodeValue'];
							angular.element(imgObjArr[i])[0].removeAttribute("data-src");
						}
                        // if(typeof angular.element(imgObjArr[i])[0].attributes['data-lazy'] != 'undefined' && angular.element(imgObjArr[i])[0].attributes['data-lazy'] != ''){
                        //     angular.element(imgObjArr[i])[0].src = angular.element(imgObjArr[i])[0].attributes['data-lazy']['nodeValue'];
                        //     angular.element(imgObjArr[i])[0].removeAttribute("data-lazy");
                        // }

					}
				};
			}else{
                            var lazyLoad = function(){
                                        var imgObjArr = element.find('img');
					var imgObjArrLen = imgObjArr.length;
					for(var i=0;i<imgObjArrLen;i++){
                                                var hideFromMobile = 0;
						var imgObj = angular.element(imgObjArr[i])[0];
						if(imgObj.hasAttribute('show-on-mobile') && imgObj.getAttribute('show-on-mobile') == '0' && isMobileDevice == 1) {
                                                    hideFromMobile = 1;
                                                }
						if(typeof angular.element(imgObjArr[i])[0]['dataset']['src']!= 'undefined' && angular.element(imgObjArr[i])[0]['dataset']['src'] != '' && hideFromMobile == 0){

								angular.element(imgObjArr[i])[0]['src'] = angular.element(imgObjArr[i])[0]['dataset']['src'];
								angular.element(imgObjArr[i])[0].removeAttribute("data-src");
						}
                        //   if(typeof angular.element(imgObjArr[i])[0]['dataset']['lazy']!= 'undefined' && angular.element(imgObjArr[i])[0]['dataset']['lazy'] != ''){

                        //         angular.element(imgObjArr[i])[0]['src'] = angular.element(imgObjArr[i])[0]['dataset']['lazy'];
                        //         angular.element(imgObjArr[i])[0].removeAttribute("data-lazy");

                        // }

					}
				};
			}

                        if(document.readyState === 'complete') {
                            lazyLoad();
                        } else {
                            window.addEventListener('load', lazyLoad);
                        }


		}
	};
})
.directive('loadMoreOnScroll',function(){
	return {

		restrict: 'A',
		replace: false,
		link: function(scope,element,attrs){

            angular.element(document).bind('scroll', function() {
                if ((window.pageYOffset) > (angular.element(element)[0].offsetTop)-700) {
                    scope.$apply(attrs.loadMoreOnScroll);
                }
            });
		}
    };
})
.directive('scrollPosition2', function($window) {
	return {
		scope:{
			scrollClass:"@scrollClass"
		},
		link: function(scope, element, attrs) {

			var windowEl = angular.element($window);
			var handler = function() {

				if (window.pageYOffset > 0) {


						var dropDownContainers = document.getElementsByClassName("dropdown-container");
						var dropDownLen = dropDownContainers.length;
						for(var i=0;i<dropDownLen;i++){
							dropDownContainers[i].style.top = "55px";
							dropDownContainers[i].style.position = "fixed";
						}



						if(typeof attrs.innerpage == 'undefined'){
							if((element[0].className).indexOf(scope.scrollClass) == -1)
								element[0].className = element[0].className+" "+scope.scrollClass;
							document.getElementsByClassName("logo_normal")[0].style.display = 'none';
							document.getElementsByClassName("logo_white")[0].style.display = 'block';
							document.getElementsByClassName("search_nav")[0].style.display = 'block';
							document.getElementsByClassName("enterprise_li")[1].className = document.getElementsByClassName("enterprise_li")[0].className+" hidden";
						}
				} else {
					if(typeof attrs.innerpage == 'undefined'){
						element[0].className = element[0].className.replace(scope.scrollClass,"");
						document.getElementsByClassName("logo_normal")[0].style.display = 'block';
						document.getElementsByClassName("logo_white")[0].style.display = 'none';
						document.getElementsByClassName("search_nav")[0].style.display = 'none';
						document.getElementsByClassName("enterprise_li")[1].className = document.getElementsByClassName("enterprise_li")[0].className.replace("hidden","");
					}
				}



			}
			windowEl.on('scroll', scope.$apply.bind(scope, handler));
			handler();
		}
	};
})
.directive ('scrollSearchSticky', function ($window) {
    return {
        link: function (scope, element, attrs) {
            var windowEl = angular.element($window);
            var currentScrollPosition = window.pageYOffset;
            var promise = 0;
            var handler = function () {
                if (currentScrollPosition > window.pageYOffset) {
                    if (window.pageYOffset > 200) {
                        var searchBar = document.getElementsByClassName("sticky-search");
                        if (searchBar[0].style.display == "none" || searchBar[0].style.display == "") {
                            searchBar[0].style.display = 'block';
                            searchBar[0].style.position = 'fixed';
                            searchBar[0].style['z-index'] = 1;
                            if (promise == 1) {
                                promise = 0;
                                var counter = -50;
                                var interVal = setInterval(
                                        function () {
                                            counter += 2;
                                            searchBar[0].style.top = counter + "px";
                                            if (counter >= -5) {
                                                clearInterval(interVal);
                                            }
                                        }, 1);
                            }
                        }
                    } else {
                        var searchBar = document.getElementsByClassName("sticky-search");
                        if (searchBar[0].style.display == "block" || searchBar[0].style.display == "") {
                            searchBar[0].style.display = 'none';
                            searchBar[0].style.position = '';
                            searchBar[0].style.top = '';
                        }
                        promise = 1;
                    }
                    currentScrollPosition = window.pageYOffset;
                } else {
                    currentScrollPosition = window.pageYOffset;
                    var searchBar = document.getElementsByClassName("sticky-search");
                    if (searchBar[0].style.display == "block" || searchBar[0].style.display == "") {
                        searchBar[0].style.display = 'none';
                        searchBar[0].style.position = '';
                        searchBar[0].style.top = '';
                    }
                    promise = 1;
                }
            }
            windowEl.on('scroll', scope.$apply.bind(scope, handler));
            handler();
        }
    };
})
.directive('customPhoneField', function($window) {
            return {
                scope: {

                },
                link: function(scope, element, attrs) {
                    angular.element(element).on('focus',function(){
						var paddingVal = element.parent().children()[1].offsetWidth;
						angular.element(element)[0].style.paddingLeft = (paddingVal+4)+"px";
					});
                }
            };
        })
.directive('clipText', function($window) {
            return {
                scope: {

                },
                link: function(scope, element, attrs) {
					var containerDiv = element.find("div");
					var viewMoreLink = element[0].getElementsByClassName("view_more")[0];
					var viewLessLink = element[0].getElementsByClassName("view_less")[0];

					viewLessLink.style.display = "none";

					angular.element(viewMoreLink).on('click',function($event){
						$event.preventDefault();
						angular.element(containerDiv)[0].className="";

						viewMoreLink.style.display = "none";
						viewLessLink.style.display = "inline-block";
					});
					angular.element(viewLessLink).on('click',function($event){
						$event.preventDefault();
						angular.element(containerDiv)[0].className="seo_txt_container";
						viewLessLink.style.display = "none";
						viewMoreLink.style.display = "inline-block";
					});

                }
            };
})
.directive('dirOrientationChange', function($window, $rootScope) {
            return {
                restrict: 'A',
                replace: false,
                link: function(scope, elem, attrs) {
                    angular.element($window).bind('orientationchange', function () {
                        $rootScope.mobWidthFlag = (window.screen.width < $rootScope.minWidthThreshold && window.innerWidth < $rootScope.minWidthThreshold) ? 1 : 0;
                        $rootScope.hybridWidthFlag = ((!isIOs && window.screen.width < $rootScope.minWidthThresholdHybrid) || (isIOs && window.innerWidth < $rootScope.minWidthThresholdHybrid)) ? 1 : 0;
                        if($rootScope.isOrientationChanged == 0){
                            $rootScope.isOrientationChanged = 1;
                        }else{
                            $rootScope.isOrientationChanged = 0;
                        }
                        //alert(22222222222);
                        $rootScope.$emit('orientationChanged', true);
                    });
                }
            };
})
.directive('dirOuterClick', function($document) {
  return {
    restrict: 'A',
    scope:{
        unique_name: '@dirOuterClick',
        to_hide: '@toHideElemId'
    },
    link: function(scope,element) {
        var ua = navigator.userAgent,
        event = (ua.match(/iPad/i)) ? "touchstart" : "click";

        if( !(ua.match(/iPad/i)) ) {
            return;
        }

        element.data(scope.unique_name, 1);

        angular.element($document[0].body).on(event,function(e) {
        var insideElement =  angular.element(e.target).inheritedData(scope.unique_name);
        if (insideElement) {
            //do nothing
        }
        else {
            angular.element(document.getElementById(scope.to_hide)).css('display', 'none');
        }
      });
    }
  }
})
.directive('dirClassInterval', function($interval) {
    return {
        restrict: 'A',
        scope: {
            class_name:'@dirClassInterval'
        },
        link: function(scope, elem) {
            var children = elem.children();
            var total_children = children.length;
            var count = 1;

            $interval(function() {
                ++count;
                var new_class_index = (count % total_children === 0) ? (total_children -1) : (count % total_children) - 1;
                var old_class_index = (new_class_index === 0) ? (total_children -1) : (new_class_index - 1);
                angular.element(children[old_class_index]).removeClass(scope.class_name);
                angular.element(children[new_class_index]).addClass(scope.class_name);
            }, 3000, 0, false);
        }
    };
})
.directive('stickyFormElement', function($window) {
            return {
                scope: {
                   isIpad:'=isIpad'
                },
                restrict: 'A',
                replace: false,
                link: function(scope, elem, attrs) {
                    var windowEl = angular.element($window);
                    var divHeight = function(ele) {
                        var x = 0;
                        while (ele) {
                            x += ele.offsetTop;
                            ele = ele.offsetParent;
                        }
                        return x;
                    }
                    var formObj;

                    var handler = function(){};

                    if(user_params.pageCategory == 'lvc-pass_index'){

                        var formObj = document.getElementsByClassName("form_wrapper")[0];
                        var columnDist = divHeight(formObj);
                        var lastObj = document.getElementsByClassName("aces_banner");
                        if(typeof lastObj === 'undefined' || lastObj.length == 0){
                            lastObj = document.getElementsByTagName("footer");
                        }
                        lastObj = lastObj[0];

                        handler = function(){
                            var lastObjHt = divHeight(lastObj);
                            if((window.scrollY) > (lastObjHt-formObj.offsetHeight)-50){

                                if(window.scrollY > lastObjHt+lastObj.offsetHeight){
                                    formObj.style.top = '';
                                    formObj.style.position = '';
                                    formObj.style.width='';
                                }else{
                                    formObj.style.top = (((lastObjHt-formObj.offsetHeight)-50)-(window.scrollY))+'px';
                                    formObj.style.position = 'fixed';
                                    formObj.style.width='246px';
                                }
                            }else{
                                if(window.scrollY > (columnDist-10)){
                                    formObj.style.top = '10px';
                                    formObj.style.position = 'fixed';
                                    formObj.style.width='246px';
                                }else{
                                    formObj.style.top = '';
                                    formObj.style.position = '';
                                    formObj.style.width='';
                                }
                            }

                        }
                    }else{
                        var formClientH = 0;
                        var formObj = document.getElementsByClassName("form_wrapper")[1];
                        var minHeight = elem[0].offsetTop;

                        var columnObj = document.getElementsByClassName("our_training_experts")[0];
                        var mainSection = document.getElementsByClassName("course-details-container")[0];
                        var mainSectionObj = null;
                        var mainSectionHt = 0;
                        if(typeof mainSection != 'undefined'){
                            mainSectionObj = mainSection.getElementsByClassName("col-lg-12")[0];
                            mainSectionHt = mainSectionObj.offsetHeight;
                        }

                        if( typeof columnObj === 'undefined' ) {
                            return;
                        }

                        var columnHt = columnObj.offsetHeight;
                        var columnDist = divHeight(columnObj);

                        var cloneObj = document.getElementsByClassName('drop_query_clone')[0];
                        var offset = 0;
                        handler = function() {

                            var formHt = 0;
                            if(typeof formObj != 'undefined'){
                                formHt = formObj.offsetHeight;
                            }
                            if(typeof mainSection != 'undefined') {
                                if (window.scrollY > (columnDist+formHt) && mainSectionHt > (columnHt+formHt)){
                                    offset+=10;
                                    cloneObj.style.height = formHt+'px';
                                    //formObj.style.top = ((columnDist+formHt)-offset)+'px';
                                    var coulmnObjChildren = columnObj.children;
                                    var recentlyViewedObj = coulmnObjChildren[coulmnObjChildren.length-1];

                                    var mainSectionChildren = mainSectionObj.children;
                                    var reviewsSectionObj = mainSectionChildren[mainSectionChildren.length-1];

                                    if(window.scrollY > (divHeight(recentlyViewedObj)+recentlyViewedObj.offsetHeight)-20){

                                        if(window.scrollY > ((divHeight(reviewsSectionObj)+reviewsSectionObj.offsetHeight)-(formHt+50))){
                                            formObj.style.top = ((divHeight(reviewsSectionObj)-window.scrollY)+80)+'px';
                                            formObj.style.position = 'fixed';
                                            formObj.style.width='246px';
                                        }else{
                                            formObj.style.top = '50px';
                                            formObj.style.position = 'fixed';
                                            formObj.style.width='246px';
                                        }
                                    }else{
                                        formObj.style.top = ((divHeight(recentlyViewedObj)-window.scrollY)+recentlyViewedObj.offsetHeight)+'px';
                                        formObj.style.position = 'fixed';
                                        formObj.style.width='246px';
                                    }

                                }else{
                                    cloneObj.style.height = '0';
                                    formObj.style.top = '';
                                    formObj.style.position = '';
                                    formObj.style.width='246px';
                                }
                            }

                        }
                    }

                    if(isIpad == 0 && typeof formObj != 'undefined'){
                        windowEl.on('scroll', scope.$apply.bind(scope, handler));
                        handler();
                    }
                }
            };
        })
        .directive('changeClassOnScroll', function($window) {
            return {
                scope: {
                    new_class : '@changeClassOnScroll'
                },
                restrict: 'A',
                replace: false,
                link: function(scope, elem) {
                    angular.element($window).on('load', function() {
                        var windowObj = angular.element($window);
                        var bodyContainerObj = document.getElementById('body_content');
                        var threshold_flag = false;

                        var getHeight = function(pElem) {
                            return parseInt(pElem.offsetHeight);
                        };

                        var handleClassChange = function() {

                            if( window.pageYOffset > getHeight(elem[0]) && !threshold_flag ) {
                                elem.addClass(scope.new_class);
                            }
                            else {
                                elem.removeClass(scope.new_class);
                            }

                            var bottom_threshold = ( bodyContainerObj.offsetHeight - window.pageYOffset <= parseInt(elem[0].offsetHeight) + 200 );

                            if( elem.hasClass(scope.new_class) && bottom_threshold ) {
                                elem.removeClass(scope.new_class);
                                threshold_flag = true;
                            }
                            else if( !bottom_threshold ) {
                                threshold_flag = false;
                            }
                        };

                        handleClassChange();    //for onload

                        windowObj.on('scroll', function() {
                            handleClassChange();
                        });
                    });
                }
            };
        })
        .directive('stickyAfterElementScroll', function($window) {
            return {
                scope: {
                    mainElement : '@stickyAfterElementScroll',
                    percent : '@scrollPercent'
                },
                restrict: 'A',
                replace: false,
                link: function(scope, elem) {
                    angular.element($window).on('load', function() {
                        var scopePercent = 0;

                        if(scope.percent) {
                            scopePercent = scope.percent;
                        }

                        var windowObj = angular.element($window);
                        var screenHeight = window.innerHeight;
                        var mainElem = document.getElementById(scope.mainElement);
                        var bodyObj = document.getElementById('body_content');

                        if(!mainElem.offsetHeight) {
                            return;
                        }

                        var makeSticky = function() {
                            var bottomFixed = (screenHeight * 0.2 ) + 'px';
                            elem.css({"bottom":bottomFixed, "position":"fixed"});
                        };

                        var removeSticky = function() {
                            elem.css({"bottom":"", "position":""});
                        };

                        var setElementStyle = function() {
                            var elemScrolled = window.pageYOffset - mainElem.offsetTop;
                            var percentScrolled = (elemScrolled/mainElem.offsetHeight) * 100;
                            if ( percentScrolled > scopePercent && window.pageYOffset < ( bodyObj.offsetHeight - screenHeight ) ) {
                                makeSticky();
                            }
                            else {
                                removeSticky();
                            }
                        };

                        if( mainElem.offsetHeight <= screenHeight ) {  //always show elem if mainElem is smaller than screen
                            makeSticky();
                        } else {
                            removeSticky();
                            windowObj.on('scroll', setElementStyle);
                        }

                        setElementStyle();
                    });
                }
            };
        })
        .directive('dirPagination', function($http) {
            return {
                scope: {
                    apiUrl:'@',
                    apiParams:'=',
                    pageSize:'@',
                    startPage:'@',          //pages start from 0
                    paginationData:'=',
                    paginationErr:'=',
                    additionalSkip:'@'
                },
                restrict: 'A',
                replace: false,
                link: function(scope, elem) {
                    var reqParams = {}, currPage = 0, saturatedFlag = 0;
                    var elemHtml = elem.html();

                    if( !scope.paginationData || scope.paginationData.constructor !== Array ) {
                        scope.paginationData = new Array();
                    }

                    if(!scope.pageSize || !scope.apiUrl) {
                        return;
                    }

                    if(scope.apiParams && typeof scope.apiParams === 'object') {
                        reqParams = scope.apiParams;
                    }

                    if( currPage === 0 && scope.startPage ) {
                        currPage = parseInt(scope.startPage);
                    }

                    elem.on('click', function() {
                        if( saturatedFlag === 1 ) {
                            return false;
                        }

                        elem[0].disabled = true;
                        reqParams['additionalSkip'] = scope.additionalSkip;
                        reqParams['pageSize'] = scope.pageSize;
                        reqParams['currPage'] = currPage;

                        elem.html("Loading...");

                        $http.get( scope.apiUrl, { params:reqParams, cache:true } )
                        .success(function(data) {
                            if( data.status == 'success' ) {
                                if( typeof data.content !== 'undefined' ) {
                                    currPage = parseInt(currPage) + 1;

                                    for( var prop in data.content ) {
                                        scope.paginationData.push(data.content[prop]);
                                    }
                                }

                                if( typeof data.content !== 'undefined' && parseInt(data.content.length) < scope.pageSize ) {
                                    saturatedFlag = 1;
                                    elem.html("That's all");
                                } else {
                                    elem.html(elemHtml);
                                }

                                elem[0].disabled = false;
                            }
                            else {
                                scope.paginationErr = 'Some error occurred. Please try again later.';
                                elem[0].disabled = false;
                                elem.html(elemHtml);
                            }
                        })
                        .error(function() {
                            scope.paginationErr = 'Some error occurred. Please try again later.';
                            elem[0].disabled = false;
                            elem.html(elemHtml);
                        });
                    });
                }
            };
        })
.directive('specialsBanner', function($interval) {
    return {
        restrict: 'A',
        scope: {
            selectedTrainingType:"=selectedTrainingType"
        },
        link: function(scope, elem) {
            var closeBtnObj = (angular.element(elem)[0]).getElementsByClassName("banner_close")[0];
            var bannerObj = (angular.element(elem)[0]).getElementsByClassName("specials_banner")[0];
            var bannerCollapsedStrip = (angular.element(elem)[0]).getElementsByClassName("specials_banner_collapse")[0];
            var bannerCarouselBtn = (angular.element(elem)[0]).getElementsByClassName("banner_btn");
            var bannerCarouselDot = (angular.element(elem)[0]).getElementsByClassName("banner_dot");
            var bannerItems = (angular.element(elem)[0]).getElementsByClassName("banner_items");

            var activeCount=0;
            var olOffers = [];
            var clOffers = [];
            var stopSlide=0;


            var getOLOffers = function(bannerItems){
                for(var i=0;i<bannerItems.length;i++){
                    //console.log(angular.element(bannerItems[i])[0].dataset);
                    var data = angular.element(bannerItems[i])[0].dataset;
                    if(typeof data.trainingType != 'undefined'){
                        var str = data.trainingType;
                        angular.element(bannerItems[i])[0].setAttribute('data-tt',getTrainingTypeStr(str));
                    }else{
                         angular.element(bannerItems[i])[0].setAttribute('data-tt','generic');

                    }
                }
            }

            function getTrainingTypeStr(strData){
                    var str = strData;
                    var res = str.split(",");
                    if(res.length < 3){
                        if(res.length == 1 && (res.indexOf("1")!=-1 || res.indexOf("3")!=-1)){
                                return "ilt";
                        }else if(res.length == 1 && res.indexOf("2")!=-1){
                                return "osl";
                        }else if(res.length == 2 && res.indexOf("2")!=-1){
                                return "generic";
                        }else if(res.length == 2 && res.indexOf("2")==-1){
                                return "ilt";
                        }
                    }else{
                            return "generic";
                    }
            }

            function getTrainingTypeDivs(bannerItems){
                    var tmpDivList = [];
                    for(var i=0;i<bannerItems.length;i++){
                            var tType = angular.element(bannerItems)[i].dataset.tt;
                            if(scope.selectedTrainingType == ''){
                                tmpDivList.push(angular.element(bannerItems)[i]);
                            }else if(tType == scope.selectedTrainingType){
                                tmpDivList.push(angular.element(bannerItems)[i]);
                            }else if(tType == 'generic'){
                                tmpDivList.push(angular.element(bannerItems)[i]);
                            }

                    }

                    return tmpDivList;
            }

            var currentActiveDot = 0;

            function getCurrentActiveDot(){
                for(var i=0;i<bannerCarouselDot.length;i++){
                    var clsName = angular.element(bannerCarouselDot[i])[0].className;
                    if(clsName.indexOf("active")!=-1){
                        currentActiveDot = i;
                        break;
                    }
                }
            }
            getCurrentActiveDot();
            getOLOffers(bannerItems);

            angular.element(closeBtnObj).on('click',function(event){
                event.preventDefault();
                angular.element(bannerObj).addClass("hidden_class");
                angular.element(bannerCollapsedStrip).removeClass("hidden_class");
            });
            angular.element(bannerCollapsedStrip).on('click',function(event){
                event.preventDefault();
                angular.element(bannerObj).removeClass("hidden_class");
                angular.element(bannerCollapsedStrip).addClass("hidden_class");
            });
            var currentSelected = 0;
            var nxtSelected = 0;

            angular.element(bannerCarouselBtn).on('click',function(event){
                event.preventDefault();
                var typeData = angular.element(this)[0].dataset.type;
                carouselBtnAction(typeData);
            });


            angular.element(bannerCarouselDot).on('click',function(event){
                event.preventDefault();
                var indexData = angular.element(this)[0].dataset.index;
                if(indexData > currentActiveDot){
                    var diff = indexData - currentActiveDot;
                    for(var i=0;i<diff;i++)
                        carouselBtnAction('nxt');
                }else if(indexData < currentActiveDot){
                    var diff = currentActiveDot - indexData;
                    for(var i=0;i<diff;i++)
                        carouselBtnAction('prev');
                }

                //currentActiveDot=indexData;

            });

            if( bannerObj ) {
            scope.$watch('selectedTrainingType', function(newval){
                var tmpDivsList = getTrainingTypeDivs(bannerItems);
                if(tmpDivsList.length == 0){
                    bannerObj.style.display = "none";
                    document.getElementsByClassName("key-feature-offers")[0].style.display ='none';
                }else{
                    bannerObj.style.display = "block";
                    document.getElementsByClassName("key-feature-offers")[0].style.display ='block';
                }
                for(var i=0;i<bannerCarouselDot.length;i++){
                    if(tmpDivsList.length > 1){
                        angular.element(bannerCarouselDot[i]).removeClass("active");
                        angular.element(bannerCarouselDot[i]).removeClass("hidden_class");
                       if(i>tmpDivsList.length-1){
                           angular.element(bannerCarouselDot[i]).addClass("hidden_class");
                           angular.element(bannerCarouselDot[i])[0].setAttribute('data-index','-1');
                       }else{
                           angular.element(bannerCarouselDot[i])[0].setAttribute('data-index',i);
                       }
                    }else{
                        angular.element(bannerCarouselDot[i]).addClass("hidden_class");
                        angular.element(bannerCarouselDot[i])[0].setAttribute('data-index','-1');
                    }

                }
                currentSelected = 0;
                nxtSelected = 0;
                currentActiveDot = 0;

                for(var i=0;i<bannerItems.length;i++){
                    if(angular.element(bannerItems[i])[0].className.indexOf("hidden_class") == -1)
                        angular.element(bannerItems[currentSelected]).addClass("hidden_class");
                }
                angular.element(tmpDivsList[nxtSelected]).removeClass("hidden_class");
                if(tmpDivsList.length > 1){
                    angular.element(bannerCarouselDot[currentActiveDot]).removeClass("hidden_class");
                    angular.element(bannerCarouselDot[currentActiveDot]).addClass("active");
                    angular.element(bannerCarouselBtn).removeClass("hidden_class");
                }else{
                    angular.element(bannerCarouselBtn).addClass("hidden_class");
                }

            }, true);
            }

            function carouselBtnAction(typeData){
                var tmpDivsList = getTrainingTypeDivs(bannerItems);
                angular.element(bannerCarouselDot[currentActiveDot]).removeClass("active");

                for(var i=0;i<tmpDivsList.length;i++){
                    var clsName = angular.element(tmpDivsList[i])[0].className;
                    if(clsName.indexOf("hidden_class") == -1){
                        currentSelected = i;
                        if(typeData == 'prev'){
                            if(currentSelected > 0){
                                nxtSelected = currentSelected-1;
                            }else{
                                nxtSelected = tmpDivsList.length-1;
                            }
                        }else if(typeData == 'nxt'){
                            if(currentSelected < tmpDivsList.length-1){
                                nxtSelected = currentSelected+1;
                            }else{
                                nxtSelected = 0;
                            }
                        }
                        currentActiveDot = nxtSelected;
                        break;
                    }
                }
                angular.element(tmpDivsList[currentSelected]).addClass("hidden_class");
                angular.element(tmpDivsList[nxtSelected]).removeClass("hidden_class")
                angular.element(bannerCarouselDot[currentActiveDot]).addClass("active");

            }

            (angular.element(elem)).on('mouseover',function(){
               stopSlide=1;
            }).on('mouseout',function(){
                stopSlide=0;
            });

            $interval(function(){
                if(stopSlide==0)
                    angular.element((elem[0]).getElementsByClassName("banner_btn")[1]).triggerHandler('click');

            },3000);

        }
    };
})
.directive('newWindowButton', function($window) {
    return {
        restrict: 'A',
        scope: {
            openUrl:"@openUrl"
        },
        link: function(scope, elem,attrs) {

            angular.element(elem).on('click',function(event){
                event.preventDefault();
                window.open(scope.openUrl,'_blank', 'location=yes,height=570,width=520,scrollbars=yes,status=yes');
            });
        }
    };
})
.directive('twitterTextShare', function($window) {
    return {
        restrict: 'A',
        link: function(scope, elem,attrs) {
            var text = "", selObj = null;
            var twitterSpan = (elem[0]).getElementsByClassName("twitter-highlight");
            var openUrl = "";
            var url = twitterSpan[0].getAttribute('data-url');
            angular.element($window).on('mouseup',function(event){
                event.preventDefault();

                if (window.getSelection) {
                    selObj = window.getSelection();
                    text = selObj.toString();
                } else {
                    return false;
                }

                if( selObj.rangeCount ) {
                    var startCont = selObj.getRangeAt(0).startContainer;
                    var endCont = selObj.getRangeAt(0).endContainer;

                    if( !closest(startCont) || !closest(endCont) ) {
                        hideTwitterIcon();
                        return false;
                    }
                } else {
                    return false;
                }

                var coordinates = getSelectionCoords();
                var x = coordinates.x;
                var y = coordinates.y-7;
                if(text.length > 1){
                    if((text.length) > 95){
                        text = text.substring(0,95);
                        text = text+"...";
                    }
                    showTwitterIcon(x,y);
                    openUrl = "https://www.twitter.com/share?text="+text+"&url="+url+"&via=simplilearn";
                }else{
                    hideTwitterIcon();
                }

            });

            angular.element(twitterSpan).on('click',function(){
                window.open(openUrl,'_blank', 'location=yes,height=570,width=520,scrollbars=yes,status=yes');
            });

            angular.element($window).on('scroll',function(){
                hideTwitterIcon();
                clearSelection();
            });

            var showTwitterIcon = function(x,y) {
                twitterSpan[0].style.position = "fixed";
                twitterSpan[0].style.top = y+"px";
                twitterSpan[0].style.left = x+"px";
                twitterSpan[0].style.display = 'inline-block';
            };

            var hideTwitterIcon = function() {
                twitterSpan[0].style.position = "";
                twitterSpan[0].style.top = "";
                twitterSpan[0].style.left = "";
                twitterSpan[0].style.display = 'none';
            };

            var clearSelection = function() {
                if (window.getSelection) {
                    window.getSelection().removeAllRanges();
                } else if (document.selection) {
                    document.selection.empty();
                }
            };

            var closest = function(el) {
                while (el) {
                    if ( el.id === attrs.id ) {
                        return true;
                    }

                    el = el.parentNode;
                }

                return false;
            };

            var getSelectionCoords =function() {
                var sel = null, range, rects, rect;
                var x = 0, y = 0;
                if (window.getSelection) {
                    sel = window.getSelection();
                    if (sel.rangeCount) {
                        range = sel.getRangeAt(0).cloneRange();
                        if (range.getClientRects) {
                            range.collapse(false);
                            rects = range.getClientRects();
                            if (rects.length > 0) {
                                rect = range.getClientRects()[0];
                                x = rect.right;
                                y = rect.top;
                            }
                        }
                        if (x == 0 && y == 0) {
                            var span = document.createElement("span");
                            if (span.getClientRects) {
                                span.appendChild( document.createTextNode("\u200b") );
                                range.insertNode(span);
                                rect = span.getClientRects()[0];
                                x = rect.right;
                                y = rect.top;
                                var spanParent = span.parentNode;
                                spanParent.removeChild(span);
                                spanParent.normalize();
                            }
                        }
                    }
                }
                return { x: x, y: y};
            };
        }
    };
})
.directive('dirHideBodyClick', function(HelperService) {
    return {
        restrict: 'A',
        scope: {
            invokerClass:"@",
            containerClass:"@",
            callbackFn:'&'
        },
        link: function(scope) {
            var hf = HelperService;

            var closestCallback = function() {
                if ( (scope.invokerClass && hf.$(this).hasClass(scope.invokerClass) )
                     || (scope.containerClass && hf.$(this).hasClass(scope.containerClass)) ) {
                     return true;
                }
            };

            hf.$(document).onHybridClick(function(e) {
                var validClick = hf.$(e.target).closest(closestCallback);

                if( (!validClick) ) {
                    scope.$apply(function() {
                        scope.callbackFn();
                        e.stopPropagation();
                    });
                }
            });
        }
    };
})
.directive('dirAnyDynamicHtml', function ($compile) {
  return {
    restrict: 'EA',
    replace: true,
    link: function (scope, ele, attrs) {
        scope.$watch(attrs.dirAnyDynamicHtml, function(html) {
          ele.html(html);
          $compile(ele.contents())(scope);
        });
    }
  };
})

.directive('dirWindowOnload', function () {
  return {
    restrict: 'A',
    scope:{dirWindowOnload:'&'},
    link: function (scope, ele, attrs) {
        angular.element(document).ready(function() {
            scope.dirWindowOnload();
        });
    }
  };
})
.directive('dirConstructJw', function($rootScope) {
    return {
        restrict: 'A',
        link: function (scope, ele, attrs) {
            var divId = attrs.dirConstructJw;
            if( !divId ) {
                console.log('Error in dirConstructJw : jwplayer divId empty');
                return false;
            }

            if (!jwplayer(divId).setup) {
                console.log('Error in dirConstructJw : jwplayer setup error');
                return false;
            }

            var width = attrs.plWidth;
            var height = attrs.plHeight;

            if( !width || !height ) {
                width = 682;
                height = 384;
            }

            $rootScope.jwplayerObj = jwplayer(divId).setup({
                file: attrs.vidUrl,
                image: attrs.vidImg,
                base: staticUrl + 'core/js/jwplayer/',
                width: width,
                height: height,
                startparam: 'start',
                fallback: false,
                icons: true
            });
        }
    };
})
.directive('dirDiagHov', function($timeout, HelperService, $rootScope) {        //enables diagonal navigation ability in menu
    return {
        restrict: 'A',
        scope:{
            level: '@',
            showFn: '&dirDiagHov'
        },
        link: function (scope, ele, attrs) {
          angular.element(document).ready(function() {

            var hf = HelperService, isTouchDevice = false;

            var init = function() {
                hf.dataStorage('m_oldx', 0);
                hf.dataStorage('m_oldy', 0);
                hf.dataStorage('m_timeoutId', null);
                hf.dataStorage('m_timeoutEnable', false);
                hf.dataStorage('m_timeoutDelay', 500);
            }();

            var isDelayReqd = function(e, data) {
                var delay = false;                              //default we load immediately

                if (e.pageX > data.m_oldx && e.pageY > data.m_oldy) {         //bottom-right direction
                    delay = true;
		}
		else if (e.pageX > data.m_oldx && e.pageY < data.m_oldy) {    //top-right direction
                    delay = true;
		}

                hf.dataStorage('m_oldx', e.pageX);
                hf.dataStorage('m_oldy', e.pageY);
                return delay;
            };

            var checkSubCategoryLoad = function(e, delay, data) {
                var activeElement = e.target || e.srcElement;
		if(!delay) {                            //load without delay
                    showSubCategory(activeElement);
                    return true;
		}
		if(data.m_timeoutEnable) {              //Ignore if already load triggered with setTimeout, otherwise it'll overwrite
                    return true;
		}

		hf.dataStorage('m_timeoutEnable', true);
		var timeoutID = $timeout(function () {
                    showSubCategory(activeElement);
                }, data.m_timeoutDelay);

		hf.dataStorage('m_timeoutId', timeoutID);
            };

            var isParent = function() {
                if( hf.$(this).elem() == ele[0] ) {
                    return true;
                }
            };

            var showSubCategory = function(activeElement) {
                if(activeElement && (activeElement == ele[0] || hf.$(activeElement).closest(isParent)) )  {
                    scope.$apply(function() {
                        scope.showFn();
                    });
                }

                var data = hf.dataStorage();

                if(data.m_timeoutId){
                    $timeout.cancel(data.m_timeoutId);
                    hf.dataStorage('m_timeoutId', null);
                    hf.dataStorage('m_timeoutEnable', false);
                }
            };

            ele.on('touchstart', function() {
                isTouchDevice = true;
            });

            hf.$(ele[0]).onHybridClick(function(e) {   //for touch based devices
                // Toggle level active class
                var menuDom = e.target;
                if(scope.level == 2 && angular.element(menuDom).hasClass("menu_arrow")) {
                    menuDom = e.target.parentElement;
                }
                var levelActiveClass = "active_level_" + scope.level;
                var currentActiveSatus = angular.element(menuDom).hasClass(levelActiveClass);
                var existingDom = document.getElementsByClassName(levelActiveClass);
                angular.element(existingDom).removeClass(levelActiveClass);
                if(!currentActiveSatus) {
                    angular.element(menuDom).addClass(levelActiveClass);
                }
                var overlapEl=document.getElementById('overlap-id');
                if(overlapEl){
                    var overlapClasslist=overlapEl.classList;
                    if(overlapClasslist)
                    overlapClasslist.remove('overlap-cls');
                }
                
                e.preventDefault();
                if(isTouchDevice === true || isIpad) {
                    if((!$rootScope.mobWidthFlag && !$rootScope.hybridWidthFlag)) {
                        e.preventDefault();
                    }

                    e.stopPropagation();
                    ele.off('mousemove');
                    scope.$apply(function() {
                        scope.showFn();
                    });
                }
            });
            // Diagonal mouse event delay
            var mouseEventDelayFlag = true;
            setInterval(function() {
                mouseEventDelayFlag = true;
            }, 50);
            ele.on('mousemove', function(e) {
                e.stopPropagation();
                e.preventDefault();
                if(mouseEventDelayFlag) {
                    var data = hf.dataStorage();
                    var delay = isDelayReqd(e, data);       //check for diagonal mouse movement
                    // If not diagonal move change menu
                    if(!delay) {
                        checkSubCategoryLoad(e, delay, data);
                    }
                    mouseEventDelayFlag = false;
                }

            });
          });
        }
    };
})
.directive('dirLazyHov', function($timeout, HelperService, $window) {       //displays menu contents on hover with a delay
    return {
        restrict: 'A',
        scope:{
            showFn: '&dirLazyHov',
            hideFn:'&hideMenu',
            isVisible:'@visibility',
            direction:'@'
        },
        link: function (scope, ele, attrs) {

          angular.element(document).ready(function() {

            var hf = HelperService,
                initDelay = 150,
                activeFlag = false;         //active flag is used to prevent opening the menu contents when a user's cursor passes over the menu

            var direction = scope.direction;

            var init = function() {
                hf.dataStorage('mm_oldx', 0);
                hf.dataStorage('mm_oldy', 0);
                hf.dataStorage('mm_keepActive', false);
            }();

            var isDelayReqd = function(e, data) {
                var delay = false;                              //default we load immediately

                if(!direction) {
                    //do nothing
                }
                else if (direction.indexOf('b-r') !== -1 && e.pageY > data.mm_oldy && e.pageX >= data.mm_oldx) {         //bottom-right direction
                    delay = true;
		}
                else if (direction.indexOf('b-l') !== -1 && e.pageY > data.mm_oldy && e.pageX <= data.mm_oldx) {         //bottom-left direction
                    delay = true;
		}

                hf.dataStorage('mm_oldx', e.pageX);
                hf.dataStorage('mm_oldy', e.pageY);

                return delay;
            };

            ele.on('mouseleave', function() {
                var data = hf.dataStorage();
                activeFlag = false;                 //onmouseleave mark activeFlag as false
                if(data.mm_keepActive) {            //if delay is required , do not hide
                    return;
                }
                scope.$apply(function() {
                    scope.hideFn();
                });
            });

            ele.on('touchstart', function() {   //for touch based devices
                ele.off('mousemove');
                ele.off('mouseleave');
                scope.$apply(function() {
                    if(!scope.$eval(scope.isVisible)) {
                        scope.showFn();
                    } else {
                        scope.hideFn();
                    }
                });
            });

            ele.on('mousemove', function(e) {
                e.stopPropagation();

                var data = hf.dataStorage();

                var keepActive = isDelayReqd(e, data);      //check for diagonal mouse movement
                hf.dataStorage('mm_keepActive', keepActive);
                activeFlag = true;                 //onmousemove mark activeFlag as true

                if(keepActive) {
                    return;
                }
                $timeout(function(){
                    if(activeFlag) {//display menu contents only if mouse leave has not been fired in the timeout period
                        scope.$apply(function() {
                            scope.showFn();
                        });
                    }
                }, initDelay);
            });
          });
        }
    };
})
        .directive('cloudSearchResultData', function ($http) {
            return {
                restrict: 'A',
                scope: {
                    cloudSearchResultData: '&',
                    sActClass: '='
                },
                link: function (scope, ele, attrs) {
                    angular.element(document).ready(function () {
                        scope.cloudSearchResultData();
                    });

                }
            };
        })
.directive('lecturePageStickyChapters', function ($window) {
    return {
        scope: {
            isIpad: '=isIpad'
        },
        restrict: 'A',
        replace: false,
        link: function (scope, elem, attrs) {
            var windowEl = angular.element($window);
            var divHeight = function (ele) {
                var x = 0;
                while (ele) {
                    x += ele.offsetTop;
                    ele = ele.offsetParent;
                }
                return x;
            }

            var formObj = document.getElementsByClassName("left_container")[0];
            var divHgt = divHeight(formObj);
            var minHeight = 55//document.getElementsByClassName("left_course_details")[0].offsetTop;
            var middleHgt = document.getElementsByClassName("mid_container")[0];

            windowEl.on('scroll', function () {
                if(middleHgt.offsetHeight>formObj.offsetHeight-minHeight){
                    if((window.pageYOffset+formObj.offsetHeight-minHeight) > (middleHgt.offsetHeight)) {
                        formObj.style.position = 'absolute';
                        formObj.style.bottom = '0px';
                        formObj.style.top = '';
                        angular.element(document.getElementsByClassName('mid_container')).addClass('mid_fixed_cont');
                    }else if ((window.pageYOffset) > (divHgt-minHeight)) {
                        angular.element(document.getElementsByClassName('mid_container')).addClass('mid_fixed_cont');
                        formObj.style.position = 'fixed';
                        formObj.style.bottom = '';
                        formObj.style.top = '55px';
                    }else{
                        formObj.style.position = '';
                        formObj.style.bottom = '';
                        formObj.style.top = '';
                        angular.element(document.getElementsByClassName('mid_container')).removeClass('mid_fixed_cont');
                    }
                }
            });
        }
    };
})
.directive('dirHybridClick', function () {
    return {
        restrict: 'A',
        scope: {
            clickFn: '&dirHybridClick'
        },
        link: function (scope, ele) {
            var fireAction = function() {
                scope.$apply(function() {
                    scope.clickFn();
                });
            };

            ele.on('click', function() {
                fireAction();
            });

            ele.on('touchstart', function() {   //for touch based devices
                ele.off('click');
                fireAction();
            });
        }
    };
})
.directive('dirMouseleave', function () {
    return {
        restrict: 'A',
        scope: {
            leaveFn: '&dirMouseleave'
        },
        link: function (scope, ele) {
            ele.on('mouseleave', function() {
                scope.$apply(function() {
                    scope.leaveFn();
                });
            });

            ele.on('touchstart', function() {   //for touch based devices
                ele.off('mouseleave');
            });
        }
    };
})
.directive('dirTrigger', function ($window) {
    return {
        restrict: 'A',
        link: function (scope, ele, attrs) {
            angular.element(document).ready(function(){
                if(attrs.dirTrigger == 1) {
                    ele.triggerHandler(attrs.triggerevt);
                }
            });
        }
    };
})
.directive('lecturePageStickyResources',function($window){
    return{
        scope: {
            isIpad: '=isIpad'
        },
        restrict: 'A',
        replace: false,
        link: function (scope, elem, attrs) {
            var windowEl = angular.element($window);
            var divHeight = function (ele) {
                var x = 0;
                while (ele) {
                    x += ele.offsetTop;
                    ele = ele.offsetParent;
                }
                return x;
            }

            var formObj = document.getElementsByClassName("right_container_r")[0];
            var divHgt = divHeight(formObj);
            var minHeight = 55//document.getElementsByClassName("left_course_details")[0].offsetTop;
            var middleHgt = document.getElementsByClassName("mid_container")[0];

            windowEl.on('scroll', function () {
                if((window.pageYOffset+formObj.offsetHeight-minHeight) > (middleHgt.offsetHeight)) {
                    formObj.style.position = 'absolute';
                    formObj.style.bottom = '0px';
                    formObj.style.top = '';
                    formObj.style.borderLeft = '1px solid #e7e7e7';
                }else if ((window.pageYOffset) > (divHgt-minHeight)) {
                    formObj.style.position = 'fixed';
                    formObj.style.bottom = '';
                    formObj.style.top = '55px';
                    formObj.style.borderLeft = '1px solid #e7e7e7';
                }else{
                    formObj.style.position = '';
                    formObj.style.bottom = '';
                    formObj.style.top = '';
                    formObj.style.borderLeft = '';
                }
            });
        }
    }
})
.directive('dirAddIframe', function($window, $compile) {
    return {
        restrict: 'A',
        replace: false,
        link: function(scope, ele, attrs) {
            $window.addEventListener('load', function() {
                var props = angular.fromJson(attrs.dirAddIframe);
                var iframe = document.createElement('iframe');
                for(var prop in props) {
                    iframe.setAttribute(prop, props[prop]);
                }
                ele.append(iframe);
                $compile(ele.contents())(scope);
            });
        }
    };
})
.directive('dirYoutubeEmbed', function ($http, YoutubeApiService) {
    return {
        restrict: 'A',
        scope:{
            vidStatus:'=',
            onStateChange:'&'
        },
        link: function (scope, ele, attrs) {
            if( !document.getElementsByTagName('script') || document.getElementsByTagName('script')[0].src != "https://www.youtube.com/iframe_api" ) {
                var tag = document.createElement('script');

                tag.src = "https://www.youtube.com/iframe_api";
                var firstScriptTag = document.getElementsByTagName('script')[0];
                firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
            }

            var onPlayerReady = function() {
                if(typeof attrs.vidStatus !== 'undefined') {
                    scope.$watch('vidStatus', function(newVal, oldVal) {
                        if( newVal === oldVal ) {
                            return;
                        }
                        else if(newVal === 'play') {
                            player.playVideo();
                        } else if(newVal === 'pause') {
                            player.pauseVideo();
                        } else if(newVal === 'stop') {
                            player.stopVideo();
                        }
                    });
                }
            };

            var onPlayerStateChange = function(pData) {
                scope.onStateChange({state:pData});
            };

            var onPlayerError = function() {
                $http.get(baseApiUrl+'?method=logYoutubeError', {params:{source:ele[0].src}});        //log if error occurred
            };

            var player;
            var playerEvents =  {'onReady': onPlayerReady, 'onError': onPlayerError};

            if(typeof attrs.onStateChange !== 'undefined') {
                playerEvents['onStateChange'] = onPlayerStateChange;
            }

            YoutubeApiService.onReady(function() {
                player = new YT.Player(ele[0], {
                    events:playerEvents
                });
            });
        }
    };
})
.directive('dirStickyFooter', function($window,$rootScope) {
    return {
        restrict: 'A',
        link: function (scope, ele, attrs) {
            $window.addEventListener('load', function() {
                var windowEl = angular.element($window);
                var threshold = 50;

                if( window.pageYOffset > threshold ) {
                    ele.addClass(attrs.dirStickyFooter);
                }

                windowEl.on('scroll', function () {
                    if (window.pageYOffset > threshold) {          //considering 50px as the threshold limit after which footer can be shown
                        if( (typeof $rootScope.isSemBundle != 'undefined' && $rootScope.isSemBundle && typeof $rootScope.templateId != 'undefined' && $rootScope.templateId == 2 )) {
                            ele.addClass(attrs.dirStickyFooter); 
                            ele.addClass('float-chat-visible');
                        } else {
                           ele.addClass(attrs.dirStickyFooter);  
                        }
                    } else {
                        ele.removeClass(attrs.dirStickyFooter);
                    }
                });
            });
        }
    };
})
        .directive('linkedinWindow', function () {
            return {
                restrict: 'A',
                scope: {
                    postUrl: '@',
                },
                link: function (scope, ele, attrs) {
                    ele.on('click', function () {
                        window.open(attrs.postUrl, '', 'width=477,height=401');
                    });
                }
            }
        })
.directive('dirMobileTooltip', function() {
            return {
               scope:true,
                restrict: 'A',
                replace: false,
                link: function(scope, elem, attrs) {
                    elem.on('focus', function() {
                        if(!isDesktopDevice()){
                            var parentObj = angular.element(elem).parent();
                            parentObj = parentObj[0];
                            var toolTipObj = parentObj.getElementsByClassName("mobile_tooltip");
                            toolTipObj[0].style.display = "block";
                        }

                    });
                    elem.on('blur', function() {
                        if(!isDesktopDevice()){
                            var parentObj = angular.element(elem).parent();
                            parentObj = parentObj[0];
                            var toolTipObj = parentObj.getElementsByClassName("mobile_tooltip");
                            toolTipObj[0].style.display = "";
                        }
                    });
                }
            };
})
.directive('dirSwipeTouch', function() {
            return {
               scope:{
                   callbackFn:'&'
               },
                restrict: 'A',
                replace: false,
                link: function(scope, elem, attrs) {
                    var touchStarted = false, // detect if a touch event is sarted
                    currX = 0,
                    currY = 0,
                    cachedX = 0,
                    cachedY = 0;

                    var getPointerEvent = function(event) {
                                        return event;
                                    };

                    elem.on('touchstart mousedown', function(e) {
                        e.preventDefault();
                        var pointer = getPointerEvent(e);
                        cachedX = currX = pointer.pageX;
                        cachedY = currY = pointer.pageY;
                        touchStarted = true;

                        // detecting if after 200ms the finger is still in the same position
                        setTimeout(function (){
                            if ((cachedX === currX) && !touchStarted && (cachedY === currY)) {
                                //tap event
                                scope.$apply(function() {
                                    scope.callbackFn();
                                });
                            }
                        },200);
                    });
                    elem.on('touchend mouseup touchcancel', function(e) {
                        e.preventDefault();
                        // here we can consider finished the touch event
                        touchStarted = false;

                    });
                    elem.on('touchmove mousemove', function(e) {
                        e.preventDefault();
                        var pointer = getPointerEvent(e);
                        currX = pointer.pageX;
                        currY = pointer.pageY;
                        if(touchStarted) {
                             // here you are swiping
                             scope.$apply(function() {
                                scope.callbackFn();
                            });

                        }
                    });

                }
            };
})
        .directive('topLevelAccordion', function() {
            return {
                scope: {
                    enableScroll: '@enableScroll',
                },
                restrict: 'A',
                replace: false,
                link: function(scope, elem, attrs) {
                    var mainObj = elem.parent();
                    var doc = mainObj[0].getElementsByClassName('plus_minus');
                    var scrollLimit = 50;/* 50 is sticky banner height */

                    var divHeight = function(ele) {
                        var x = 0;
                        while (ele) {
                            x += ele.offsetTop;
                            ele = ele.offsetParent;
                        }
                        return x;
                    };

                    var slideAction = function(elemObj) {
                        if(typeof scope.enableScroll !== 'undefined' || scope.enableScroll == 0) {
                                return true;
                        }
                        var parentObj = elemObj.parentNode;
                        var heightDiff = (divHeight(parentObj) - window.pageYOffset - scrollLimit);
                        var pageYOffset = window.pageYOffset;
                        if (heightDiff >= 150) {
                            window.scrollBy(0, 150);
                            if (pageYOffset == window.pageYOffset) {
                                return false;
                            }
                            setTimeout(function() {
                                slideAction(elemObj, heightDiff);
                            }, 10);
                        } else if (150 >= heightDiff && heightDiff >= 100) {
                            window.scrollBy(0, 100);
                            if (pageYOffset == window.pageYOffset) {
                                return false;
                            }
                            setTimeout(function() {
                                slideAction(elemObj, heightDiff);
                            }, 10);
                        } else if (100 >= heightDiff && heightDiff >= 60) {
                            window.scrollBy(0, 60);
                            if (pageYOffset == window.pageYOffset) {
                                return false;
                            }
                            setTimeout(function() {
                                slideAction(elemObj, heightDiff);
                            }, 10);
                        } else {
                            window.scrollBy(0, (divHeight(parentObj) - window.pageYOffset) - scrollLimit);
                            return false;
                        }
                        return true;
                    };
                    var showFirstLevel = function(obj) {
                        var ul = angular.element(obj).find('ul');
                        var f_s = 0;
                        var f_t = 0;
                        for (var i = 0; i < ul.length; i++) {
                            var ulParent = angular.element(ul[i]).parent();
                            var chilLenght = ul[i].children.length;

                            if (angular.element(ul[i]).hasClass('top_level_cls') && f_t == 0) {
                                var accdTitle = ulParent[0].querySelector('div.accord-head a');
                                angular.element(accdTitle).removeClass('expand').addClass('collapse');
                                angular.element(ul[i]).removeClass('acc_height').addClass('acc_height_auto');
                                f_t = 1;
                            } else if (angular.element(ul[i]).hasClass('sub_level_cls') && f_s == 0 && chilLenght > 0) {
                                var accdTitle = ulParent[0].getElementsByClassName('acc-arrow');
                                angular.element(accdTitle[0]).removeClass('plus').addClass('minus');
                                angular.element(ul[i]).removeClass('acc_height').addClass('acc_height_auto')
                                f_s = 1;
                            } else if (angular.element(ul[i]).hasClass('low_level_cls') && chilLenght > 0) {
                                var accdTitle = ulParent[0].getElementsByClassName('acc-arrow');
                                angular.element(accdTitle[0]).removeClass('plus').addClass('minus');
                                angular.element(ul[i]).removeClass('acc_height').addClass('acc_height_auto');
                                return;
                            }
                        }
                    };
                    if (attrs.level == 1) {
                        //showFirstLevel(elem);
                    }

                    var closeSubCls = function(eleObj) {
                        if (eleObj.length > 0) {
                            for (var i = 0; i < eleObj.length; i++) {
                                if (angular.element(eleObj[i]).hasClass('minus') || angular.element(eleObj[i]).hasClass('plus')) {
                                    angular.element(eleObj[i]).removeClass('minus').addClass('plus');
                                }

                            }
                        }
                    }

                    elem.on('click', function() {

                        if (angular.element(this.getElementsByClassName('t_plus_minus')).hasClass('collapse')) {
                            angular.element(this.getElementsByClassName('acc_height_auto')).removeClass('acc_height_auto').addClass('acc_height');
                            angular.element(this.getElementsByClassName('t_plus_minus')).removeClass('collapse').addClass('expand');
                            closeSubCls(doc);
                            return;
                        } else {
                            angular.element(document.getElementsByClassName('acc_height_auto')).removeClass('acc_height_auto').addClass('acc_height');
                            angular.element(document.getElementsByClassName('t_plus_minus')).removeClass('collapse').addClass('expand');
                            closeSubCls(doc);
                        }
                        slideAction(this.getElementsByClassName('t_plus_minus')[0]);
                        showFirstLevel(this);
                    });

                    //find all sublevels of accordion
                    var subLevelObj = angular.element(elem)[0].querySelectorAll("div.sub_level");
                    angular.element(subLevelObj).bind("click", function(e) {
                        e.stopImmediatePropagation();

                        var parentDiv = angular.element(this).parent().find('ul');
                        var subLevel = angular.element(angular.element(parentDiv[0]).find('li'));
                        var lowLevel = subLevel[0].querySelector('span.acc-arrow');
                        var lowLevelUl = subLevel[0].querySelector('ul.low_level_cls');

                        var elemCls = angular.element(angular.element(this)[0].querySelector('span.plus_minus'));
                        if (elemCls.hasClass('minus')) {
                            elemCls.removeClass('minus').addClass('plus');
                        } else {
                            slideAction(this);
                            var closeAllLis = angular.element(subLevelObj).parent();
                            for (var k = 0; k < closeAllLis.length; k++) {
                                angular.element(closeAllLis[k].getElementsByClassName('acc_height_auto')).removeClass('acc_height_auto').addClass('acc_height');
                                angular.element(closeAllLis[k].getElementsByClassName('plus_minus')).removeClass('minus').addClass('plus');
                            }
                            elemCls.removeClass('plus').addClass('minus');
                        }


                        var subL = 1;
                        for (var j = 0; j < parentDiv.length; j++) {
                            if (angular.element(parentDiv[j]).hasClass('sub_level_cls')) {
                                if (angular.element(parentDiv[j]).hasClass('acc_height_auto') && subL == 1) {
                                    angular.element(parentDiv[j]).removeClass('acc_height_auto').addClass('acc_height');
                                    if (angular.element(lowLevel).hasClass('plus')) {
                                        angular.element(lowLevel).removeClass('plus').addClass('minus');
                                    } else if (angular.element(lowLevel).hasClass('minus')) {
                                        angular.element(lowLevel).removeClass('minus').addClass('plus');
                                    }
                                    if (angular.element(lowLevelUl).hasClass('low_level_cls')) {
                                        angular.element(lowLevelUl).removeClass('acc_height_auto').addClass('acc_height');
                                    }
                                    break;
                                } else if (angular.element(parentDiv[j]).hasClass('acc_height') && subL == 1) {
                                    angular.element(parentDiv[j]).removeClass('acc_height').addClass('acc_height_auto');
                                    if (angular.element(lowLevel).hasClass('plus')) {
                                        angular.element(lowLevel).removeClass('plus').addClass('minus');
                                    } else if (angular.element(lowLevel).hasClass('minus')) {
                                        angular.element(lowLevel).removeClass('minus').addClass('plus');
                                    }
                                    if (angular.element(lowLevelUl).hasClass('low_level_cls')) {
                                        angular.element(lowLevelUl).removeClass('acc_height').addClass('acc_height_auto');
                                    }
                                    break;
                                }
                            }
                        }
                        return;
                    });

                    //third level accordion
                    var lowLevelObj = angular.element(elem)[0].querySelectorAll("div.low_level");
                    angular.element(lowLevelObj).bind("click", function(e) {
                        e.stopImmediatePropagation();
                        var parentDiv = angular.element(this).parent();
                        var ul = parentDiv[0].querySelector('ul.low_level_cls');
                        var ulLenght = angular.element(ul)[0].children.length;

                        if (angular.element(angular.element(this).children()[0]).hasClass('minus') && ulLenght > 0) {
                            angular.element(angular.element(this).children()[0]).removeClass('minus').addClass('plus');
                            angular.element(ul).removeClass('acc_height_auto').addClass('acc_height');
                        } else if (ulLenght > 0) {
                            var allLis = angular.element(this).parent().parent().children();
                            for (var li = 0; li < allLis.length; li++) {
                                var mCls = angular.element(allLis[li].querySelectorAll('span.plus_minus'));
                                var hCls = angular.element(allLis[li].querySelectorAll('ul.acc_height_auto'));
                                if (mCls.hasClass('minus')) {
                                    mCls.removeClass('minus').addClass('plus');
                                    hCls.removeClass('acc_height_auto').addClass('acc_height');
                                }
                            }
                            slideAction(this);
                            angular.element(angular.element(this).children()[0]).removeClass('plus').addClass('minus');
                            angular.element(ul).removeClass('acc_height').addClass('acc_height_auto');
                        }
                        return;
                    });
                }
            };
        })
        .directive('dirAddbIframe', function($compile) {
            return {
                restrict: 'A',
                replace: false,
                link: function(scope, ele, attrs) {
                    var props = angular.fromJson(attrs.dirAddbIframe);
                    var iframe = document.createElement('iframe');
                    for (var prop in props) {
                        iframe.setAttribute(prop, props[prop]);
                    }
                    ele.append(iframe);
                    $compile(ele.contents())(scope);
                }
            };
        })
.directive('stickyMenu', function ($window) {
    return {
        scope: {
            topPostion: '@topPostion',
            stickyStyle: '=stickyStyle',
            offsetHeight: '@offsetHeight',
            displayHeight: '@displayHeight',
            stickyComponentDisplay: '=stickyComponentDisplay'
        },
        restrict: 'A',
        replace: false,
        link: function (scope, elem, attrs) {
            var windowEl = angular.element($window);
            var divHeight = function (ele) {
                var x = 0;
                while (ele) {
                    x += ele.offsetTop;
                    ele = ele.offsetParent;
                }
                return x;
            }
            var minHeight = elem[0].offsetTop;

            var handler = function () {
                if (window.pageYOffset > minHeight - parseInt(scope.offsetHeight)) {
                    angular.element(elem).addClass('menu-fixed');
                    scope.stickyComponentDisplay = {'display': 'inline-block'};
                } else {
                    angular.element(elem).removeClass('menu-fixed');
                    scope.stickyComponentDisplay = {'display': 'none'};
                }

                if (!!scope.displayHeight) {
                    if (window.pageYOffset > scope.displayHeight) {
                        scope.stickyStyle['display'] = 'block';
                    } else {
                        scope.stickyStyle['display'] = 'none';
                    }
                }
            }
            windowEl.on('scroll', scope.$apply.bind(scope, handler));
            handler();
        }
    };
})
        .directive('dirSearchLoadMore', function($window,$timeout) {
            return {
                restrict: 'A',
                replace: false,
                link: function(scope, element, attrs) {
                   var temp = false;
                   var loadCnt = 1;
                   var loadMore = function (el) {
                        var top = el.offsetTop;
                        var height = el.offsetHeight;

                        while (el.offsetParent) {
                            el = el.offsetParent;
                            top += el.offsetTop;
                        }
                        if(top == 0){
                            return false;
                        }
                        return (
                                top >= window.pageYOffset &&
                                (top + height) <= (window.pageYOffset + window.innerHeight)
                                );
                    }
                    angular.element($window).bind('scroll', function() {
                        scope.listCnt = attrs.searchListCount;
                        var status = loadMore(element[0]);
                        if (status) {
                            if (loadCnt < 6 && temp === true) {
                                temp = false;
                                $timeout(function() {
                                    scope.$apply(attrs.dirSearchLoadMore);
                                });
                                loadCnt++;
                            }
                        }
                    });
                    scope.$watch('listCnt',function(){
                        temp = true;
                    });
                }
            };
        })
    .directive('dirEmailTagging', function() {
        return {
            scope: true,
            restrict: 'EA',
            link: function(scope, elem, attr) {
                var emailList = [];
                var noVal = 1;
                elem.on('keydown',function(e){
                    if (e.keyCode === 13){
                        e.preventDefault();
                    }
                    var activeEle = angular.element(document.activeElement);
                    var parentElement = elem[0].children[0];
                    noVal = 1;
                    if(activeEle.hasClass('referee_mails') && e.keyCode == 8 && angular.element(parentElement.lastElementChild)[0].children[0].value){
                        noVal = 0;
                    }
                });
                elem.on('keyup click', function(e) {
                    var activeEle = angular.element(document.activeElement);
                    var new_email = scope.referee_mails;
                    if(new_email){
                        new_email = new_email.replace(/[,;]+$/,'');
                    }
                    var ele = document.getElementsByClassName(e.target.className);
                    var parentElement = elem[0].children[0];
                    var liList = parentElement.children;
                    var lastLi = liList.length >= 2 ? liList.length - 1 : 0;
                    if (angular.element(ele).hasClass('remove')) {
                        var emailIdToRemove = ele[0].getAttribute("data-email-id");
                        var existingEmailList = scope.email_list;
                        if(existingEmailList.length==0){
                            existingEmailList=document.getElementsByClassName('email_list')[0].innerHTML;
                        }
                        if(existingEmailList.length > 0 ){
                            var existingEmailListArr = existingEmailList.split(',');
                            var indexToRemove = existingEmailListArr.indexOf(emailIdToRemove);
                            if(indexToRemove > -1){
                                existingEmailListArr.splice(indexToRemove,1);
                                emailList=existingEmailListArr;
                                scope.email_list = existingEmailListArr.join(',');
                                scope.$apply();
                            }
                        }
                        //console.log(scope.email_list);
                        parentElement.removeChild(ele[0].parentNode);
                    } else if (e.keyCode == 8 && lastLi > 0 && (activeEle.hasClass('referee_mails')) && noVal) { //backspace
                        rMail = angular.element(liList[lastLi - 1]).find('b');
                        rMail = rMail[0].innerText;
                        if (validEmail(rMail) && emailList.length > -1) {
                            emailList.splice(emailList.indexOf(rMail), 1);
                            scope.email_list = emailList.join(',');
                            scope.$apply();
                        }
                        parentElement.removeChild(liList[lastLi - 1]);
                    } else if (e.keyCode == 188 || e.keyCode == 186 || e.keyCode == 32 || e.keyCode == 13 || e.keyCode == 27) {
                        if (typeof new_email != 'undefined' && !new_email) {
                            return;
                        }
                        var liCls = 'e_invalid';
                        var a = 1;
                        /*if(scope.email_list && scope.email_list.length> 0){
                                    var existingEmailList = scope.email_list;
                                    var existingEmailListArr = existingEmailList.split(',');
                                    emailList=existingEmailListArr;
                        }else{
                                var existingEmailList=document.getElementsByClassName('email_list')[0].innerHTML;
                                if(existingEmailList.length){
                                   var existingEmailListArr = existingEmailList.split(',');
                                   emailList=existingEmailListArr; 
                                }
                        }*/
                        if(typeof document.getElementsByClassName('email_list')[0] !=="undefined"){
                            var existingEmailList=document.getElementsByClassName('email_list')[0].innerHTML;
                            if(existingEmailList.length){
                               var existingEmailListArr = existingEmailList.split(',');
                               emailList=existingEmailListArr;
                            }
                        }
                        if (validEmail(new_email)) {
                            if (duplicateCheck(emailList, new_email)) {
                                a = 0;
                            } else if (validDomain(new_email)) {
                                liCls = 'e_valid';
                                
                                emailList.push(new_email);
                                scope.email_list = emailList.join(',');
                                scope.$apply();
                            }else{
                                a = 0;
                            }
                        }
                        if (a && typeof new_email !=="undefined") {
                            var n = Date.now();
                            var newLi = document.createElement("li");
                            newLi.className = liCls;
                            newLi.innerHTML = "<b>" + new_email + "</b><span class='remove " + n + "' data-email-id="+new_email+">X</span>";
                            insertAfter(liList[lastLi], newLi);
                        }
                        angular.element(parentElement.lastElementChild)[0].children[0].value = '';
                        angular.element(parentElement.lastElementChild)[0].children[0].removeAttribute('style');
                    }else{
                        angular.element(parentElement.lastElementChild)[0].children[0].focus();
                        if(new_email && new_email.length>19 && activeEle.hasClass('referee_mails')){
                            var _l = new_email.length+1;
                            activeEle.css({'width':(_l*10)+'px'});
                        }
                    }
                        var _tmp = scope.pEList;
                        scope.pEList = liList.length > 1 ? 1 : 0;
                        if (_tmp !== scope.pEList) {
                            scope.$apply();
                        }
                });

                var validEmail = function(email) {
                    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                    return re.test(email);
                };

                var validDomain = function(email) {
                    var r = true;
                    var domains = ['simplilearn.com', 'test.com'];
                    var splitEmail = email.split('@');
                    if (typeof splitEmail[1] != 'undefined' && splitEmail[1]) {
                        domains.forEach(function(value) {
                            if (value === splitEmail[1]) {
                                r = false;
                                return;
                            }
                        });
                    }
                    return r;
                };

                var duplicateCheck = function(emailArray, email) {
                    if (!emailArray.length) {
                        return false;
                    }
                    var r = false;
                    emailArray.forEach(function(value) {
                        if (value === email) {
                            r = true;
                            return;
                        }
                    });
                    return r;
                };

                var insertAfter = function(referenceNode, newNode) {
                    referenceNode.parentNode.insertBefore(newNode, referenceNode);
                };
            }
        };
    })
        .directive('validNumber', function () {
            return {
                require: '?ngModel',
                link: function (scope, element, attrs, ngModelCtrl) {
                    if (!ngModelCtrl) {
                        return;
                    }

                    ngModelCtrl.$parsers.push(function (val) {
                        if (angular.isUndefined(val)) {
                            var val = '';
                        }

                        var clean = val.replace(/[^-0-9\.]/g, '');
                        var negativeCheck = clean.split('-');
                        var decimalCheck = clean.split('.');
                        if (!angular.isUndefined(negativeCheck[1])) {
                            negativeCheck[1] = negativeCheck[1].slice(0, negativeCheck[1].length);
                            clean = negativeCheck[0] + '-' + negativeCheck[1];
                            if (negativeCheck[0].length > 0) {
                                clean = negativeCheck[0];
                            }

                        }

                        if (!angular.isUndefined(decimalCheck[1])) {
                            decimalCheck[1] = decimalCheck[1].slice(0, 2);
                            clean = decimalCheck[0] + '.' + decimalCheck[1];
                        }

                        if (val !== clean) {
                            ngModelCtrl.$setViewValue(clean);
                            ngModelCtrl.$render();
                        }
                        return clean;
                    });

                    element.bind('keypress', function (event) {
                        if (event.keyCode === 32) {
                            event.preventDefault();
                        }
                    });
                }
            };
        })

        .directive('validNumberOnly', function () {
            return {
                require: '?ngModel',
                link: function (scope, element, attrs, ngModelCtrl) {
                    if (!ngModelCtrl) {
                        return;
                    }

                    ngModelCtrl.$parsers.push(function (val) {
                        if (angular.isUndefined(val)) {
                            var val = '';
                        }

                        var clean = val.replace(/[^0-9]/g, '');
                        var negativeCheck = clean.split('-');
                        var decimalCheck = clean.split('.');
                        if (!angular.isUndefined(negativeCheck[1])) {
                            negativeCheck[1] = negativeCheck[1].slice(0, negativeCheck[1].length);
                            clean = negativeCheck[0] + '-' + negativeCheck[1];
                            if (negativeCheck[0].length > 0) {
                                clean = negativeCheck[0];
                            }

                        }

                        if (!angular.isUndefined(decimalCheck[1])) {
                            decimalCheck[1] = decimalCheck[1].slice(0, 2);
                            clean = decimalCheck[0] + '.' + decimalCheck[1];
                        }

                        if (val !== clean) {
                            ngModelCtrl.$setViewValue(clean);
                            ngModelCtrl.$render();
                        }
                        return clean;
                    });

                    element.bind('keypress', function (event) {
                        if (event.keyCode === 32) {
                            event.preventDefault();
                        }
                    });
                }
            };
        })
        .directive('scrollLinkWithActive', function() {
            return {
                scope: {
                    scrollTo: '@scrollTo',
                    offsetHeight: '@offsetHeight'
                },
                restrict: 'A',
                replace: false,
                link: function(scope, elem, attrs) {
                    elem.on('click', function(event) {
                        event.preventDefault();
                        if( scroll_running_status == 1 ) {
                            return false;
                        }
                        var scrollToObj = document.getElementsByClassName(scope.scrollTo)[0];
						if(typeof scrollToObj != 'undefined'){
							var mmyht = divHeight(scrollToObj) - parseInt(scope.offsetHeight);
							if (window.pageYOffset < mmyht){
								scrollDownAnimation(scrollToObj,scope.offsetHeight);
							}else if (window.pageYOffset > mmyht){
								scrollUpAnimation(scrollToObj,scope.offsetHeight);
							}
						}else{
							return false;
						}
                    });

                    var scrollDownAnimation = function(scrollToObj,htt) {
						var myht = divHeight(scrollToObj) - parseInt(htt);
                        scroll_running_status = 1;
                        var moveBy = 500;
                        var winPageYOffset = Math.ceil(window.pageYOffset);

                        if (winPageYOffset >= myht || ((window.innerHeight + winPageYOffset) >= document.body.offsetHeight) ) {     //if scrolled to reqd element or end of page reached
                            scroll_running_status = 0;
                            return false;
                        } else {

							if (150 < (myht - winPageYOffset) && (myht - winPageYOffset) <= 500) {
								moveBy = 150;
							}
							if (50 < (myht - winPageYOffset) && (myht - winPageYOffset) <= 150) {
								moveBy = 50;
							}
							if (0 < (myht - winPageYOffset) && (myht - winPageYOffset) <= 50) {
								moveBy = (myht - winPageYOffset);
							}

                            window.scrollBy(0, moveBy);
                            setTimeout(function() {
                                scrollDownAnimation(scrollToObj,htt);
                            }, 50);
                        }
                    }

                    var scrollUpAnimation = function(scrollToObj,htt) {
						var myht = divHeight(scrollToObj) - parseInt(htt);
                        scroll_running_status = 1;
                        var moveBy = -500;
                        if (window.pageYOffset <= myht ) {
                            scroll_running_status = 0;
                            return false;
                        } else {

							if (150 < (window.pageYOffset - myht) && (window.pageYOffset - myht) <= 500) {
								moveBy = -150;
							}
							if (50 < (window.pageYOffset - myht) && (window.pageYOffset - myht) <= 150) {
								moveBy = -50;
							}
							if (0 < (window.pageYOffset - myht) && (window.pageYOffset - myht) <= 50) {
								moveBy = -(window.pageYOffset - myht);
							}

                            window.scrollBy(0, moveBy);
                            setTimeout(function() {
                                scrollUpAnimation(scrollToObj,htt);
                            }, 50);
                        }
                    }

                    var divHeight = function(ele) {
                        var x = 0;
                        while (ele) {
                            x += ele.offsetTop;
                            ele = ele.offsetParent;
                        }
                        return x;
                    }


                    // check if the element is on viewport start
                    var elementInViewport = function (el) {
                        var top = el.offsetTop;
                        var left = el.offsetLeft;
                        var width = el.offsetWidth;
                        var height = ((el.offsetHeight) - 55);
                        while (el.offsetParent) {
                            el = el.offsetParent;
                            top += el.offsetTop;
                            left += el.offsetLeft;
                        }
                        return (
                                top < (window.pageYOffset + window.innerHeight) &&
                                left < (window.pageXOffset + window.innerWidth) &&
                                (top + height) > window.pageYOffset &&
                                (left + width) > window.pageXOffset
                                );
                    }
                    // check if the element is on viewport end
                    var checkOfset = function (elem, bodyTop) {
                        if (elem !== undefined) {
                            var elem_ofset = (parseInt(elem.getBoundingClientRect().top) - 55) - (parseInt(bodyTop) + 50);
                        }
                        return elem_ofset;
                    }

                    var contentIsInViewport = function (elem, bodyTop) {
                        return parseInt(Math.abs(bodyTop)) >= parseInt(checkOfset(elem, bodyTop)) && elementInViewport(elem);
                    }

                    var menu_elem = document.getElementById(scope.scrollTo);
                    var content_elem = document.getElementsByClassName(scope.scrollTo)[0];
                    scope.$watch(
                            function (scope) {
                                var body_top = document.body.getBoundingClientRect().top;
                                if (contentIsInViewport(content_elem, body_top) && content_elem != null && !angular.isUndefined(content_elem)) {
                                    if (menu_elem != null && !angular.isUndefined(menu_elem)) {
                                        menu_elem.classList.add("active");
                                    }
                                } else {
                                    if (menu_elem != null && !angular.isUndefined(menu_elem)) {
                                        menu_elem.classList.remove("active");
                                    }
                                }

                            }
                    );


                }
            };
        })
        /**
         * Override email validation
         * Add ng-sl-email-validation="1" attribute in the input field
         * or input type should be email
         */
        .directive('type', function() {
            //var EMAIL_REGEXP = /^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-]{2,}$/;
            var EMAIL_REGEXP = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return {
                require: '?ngModel',
                priority: 1,
                link: function (scope, dom, attrs, ngModel) {

                    // Init mailcheck libray
                    var mailcheckLibDom = document.getElementById('mailcheck-js');
                    if(!mailcheckLibDom) {
                        window.onload = function() {
                            mailcheckLibDom = document.createElement("script");
                            mailcheckLibDom.type = "text/javascript";
                            mailcheckLibDom.id = "mailcheck-js";
                            mailcheckLibDom.src = "https://www.simplilearn.com/ice9/js/mailcheck.js";
                            if(!document.getElementById('mailcheck-js')) {
                                document.body.appendChild(mailcheckLibDom);
                            }
                        }
                    }

                    if ((typeof attrs.type == 'string' && attrs.type.toLowerCase() == 'email' || dom.attr('ng-sl-email-validation') == 1) && ngModel && ngModel.$parsers) {
                        var hasSuggesion = !(typeof attrs.suggestion == 'string' && attrs.suggestion.toLowerCase() == '0');

                        // Define global function for reset suggession box
                        if(typeof window.MailcheckDirective == 'undefined') {
                            window.MailcheckDirective = {};
                            window.MailcheckDirective.resetSuggessionBox = function() {
                                // Clear email suggession box
                                var suggessionDoms = document.querySelectorAll(".suggestion-box");
                                for(var si in suggessionDoms) {
                                    var val = suggessionDoms[si];
                                    val.innerText = '';
                                }
                            }
                        }

                        // Email suggestion dom - on blur //
                        var suggestionDom = null;
                        if(hasSuggesion) {
                            dom.bind('blur', function (e) {
                                if(hasSuggesion && suggestionDom) {
                                    // Suggest email. Mailcheck will available only after the library load
                                    if(typeof Mailcheck != "undefined" && Mailcheck) {
                                        Mailcheck.run({
                                          email: ngModel.$viewValue,
                                          suggested: function(suggestion) {
                                            suggestionDom.innerHTML = "Did you mean <a href='' data-email=''>"+suggestion.full+"</a> ?";
                                          },
                                          empty: function() {
                                            suggestionDom.innerHTML = "";
                                          }
                                        });
                                    }
                                }
                            });

                            var parentDom = dom[0].parentElement;
                            if (parentDom.querySelector(".suggestion-box")) {
                                var suggestionDom = parentDom.querySelector(".suggestion-box");
                            } else {
                                var suggestionDom = document.createElement("span");
                                suggestionDom.className = 'suggestion-box';
                                // Click event
                                suggestionDom.addEventListener("click", function(e) {
                                    e.preventDefault();
                                    if(this.querySelector("a")) {
                                        var value = this.querySelector("a").innerText;
                                        ngModel.$setViewValue(value);
                                        ngModel.$render();
                                        scope.$apply();
                                        suggestionDom.innerHTML = "";
                                        validateEmail();
                                    }
                                });
                                parentDom.appendChild(suggestionDom);
                            }
                        }

                        var validateEmail = function() {
                            if (!EMAIL_REGEXP.test(ngModel.$viewValue)) {
                                if(ngModel.$dirty) {
                                    ngModel.$setValidity("email", false);
                                }
                            } else {
                                ngModel.$setValidity("email", true);
                                ngModel.$setValidity("required", true);
                            }
                            return ngModel.$viewValue || undefined;
                        }
                        // Reset existing validation
                        ngModel.$parsers = [];
                        // Add custom validation
                        ngModel.$parsers.push(validateEmail);
                    }
                }
            }
        })
        .directive('dirSemSlCarousel', function (HelperService, $rootScope, $timeout, $window) {
            return {
                scope: {
                    sem_mobile_template: '@semMobileTemplate',
                    is_sem_mobile_course_page: '@isSemMobileCoursePage',
                    disable_slide: '@disableSlide',
                    mobile_slide:'@mobileSlide',
                },
                link: function (scope, element, attrs) {
                    var carouselScreen, carouselList, carouselItems, carouselItemWidth, carouselItemsLength, carouselItemsVisible,
                            carouselItemsLength, carouselPrevBtn, carouselNxtBtn, maxSlides, currentSlide, hf = HelperService, isSliding, templateId, enableSlideDefault;
                    var initCarousel = function () {
                        carouselScreen = element[0].getElementsByClassName('c_screen')[0];
                        carouselList = element[0].getElementsByClassName('c_list')[0];
                        carouselPrevBtn = element[0].getElementsByClassName('c_prev')[0];
                        carouselNxtBtn = element[0].getElementsByClassName('c_next')[0];
                        carouselItems = angular.element(carouselList).children();
                        carouselItemWidth = carouselItems[0].offsetWidth;
                        carouselItemsLength = carouselItems.length;
                        carouselItemsVisible = calculateBlocksToMove(carouselScreen, carouselItems, carouselItemsLength);
                        maxSlides = (carouselItemsLength % carouselItemsVisible) == 0 ? (carouselItemsLength / carouselItemsVisible) : (parseInt(carouselItemsLength / carouselItemsVisible) + 1);
                        currentSlide = 0;
                        carouselList.style.position = "relative";
                        addTransitionStyle(carouselList, "0.3s");
                        addTransformStyle(carouselList, 0);
                        carouselList.style.width = "6000px";
                        isSliding = 0;
                        enableSlideDefault = true;
                        angular.element(carouselPrevBtn).on('click', function () {
                            enableSlideDefault = isSilderEnabled();
                            if (enableSlideDefault) {
                                slideRight();
                            }
                        });
                        angular.element(carouselNxtBtn).on('click', function () {
                            enableSlideDefault = isSilderEnabled();
                            if (enableSlideDefault) {
                                slideLeft();
                            }
                        });
                        hf.$(carouselScreen).onSwipeLeft(function ($event) {
                            var currentTarget = $event.target;
                            enableSlideDefault = isSilderEnabled();
                            if (enableSlideDefault && scope.is_sem_mobile_course_page == 1 && scope.sem_mobile_template == 1 && $rootScope.isSemMobile && (currentTarget.closest('li'))) {
                                var currentUl = currentTarget.closest('li').parentNode;
                                var parentNode = currentUl.parentNode;
                                var currentIndex = currentSlide + 1 ;
                                var bulletElms = parentNode.getElementsByClassName('c_bullet_mobile');
                                if (currentIndex >= bulletElms.length) {
                                    currentIndex = 0;
                                }
                                var c_bullet_mobile_cls = 'c_bullet_mobile_' + (currentIndex);
                                for (var i = 0; i < bulletElms.length; i++) {
                                    if (bulletElms[i].classList.contains('active'))
                                        bulletElms[i].classList.remove('active');
                                }
                                if (typeof parentNode.getElementsByClassName(c_bullet_mobile_cls)[0] !== "undefined" && parentNode.getElementsByClassName(c_bullet_mobile_cls)[0] !== null)
                                    parentNode.getElementsByClassName(c_bullet_mobile_cls)[0].classList.add('active');
                                slideLeft();
                            } else if (enableSlideDefault && scope.is_sem_mobile_course_page == 0) {
                                slideLeft();
                            }
                        });
                        hf.$(carouselScreen).onSwipeRight(function ($event) {
                            var currentTarget = $event.target;
                            enableSlideDefault = isSilderEnabled();
                            if (enableSlideDefault && scope.is_sem_mobile_course_page == 1 && scope.sem_mobile_template == 1 && $rootScope.isSemMobile && (currentTarget.closest('li'))) {
                                var currentUl = currentTarget.closest('li').parentNode;
                                var parentNode = currentUl.parentNode;
                                var bulletElms = parentNode.getElementsByClassName('c_bullet_mobile');
                                var currentIndex = currentSlide -1;
                                if (currentIndex < 0 ) {
                                    currentIndex = parseInt(bulletElms.length)-1;
                                }
                                var c_bullet_mobile_cls = 'c_bullet_mobile_' + (currentIndex);
                                var bulletElms = parentNode.getElementsByClassName('c_bullet_mobile');
                                for (var i = 0; i < bulletElms.length; i++) {
                                    if (bulletElms[i].classList.contains('active'))
                                        bulletElms[i].classList.remove('active');
                                }
                                if (typeof parentNode.getElementsByClassName(c_bullet_mobile_cls)[0] !== "undefined" && parentNode.getElementsByClassName(c_bullet_mobile_cls)[0] !== null)
                                    parentNode.getElementsByClassName(c_bullet_mobile_cls)[0].classList.add('active');
                                slideRight();
                            } else if (enableSlideDefault && scope.is_sem_mobile_course_page == 0) {
                                slideRight();
                            }

                        });

                        //getCurrentTransformVal();
                        //addEmptyLis(carouselList);
                    }

                    var addEmptyLis = function(carouselList){
                        carouselItems = angular.element(carouselList).children();
                        carouselItemsLength = carouselItems.length;
                        carouselItemsVisible = calculateBlocksToMove(carouselScreen,carouselItems,carouselItemsLength);
                        var aa = carouselItemsLength%carouselItemsVisible;
                        if(aa != 0){
                            var bb = carouselItemsVisible-aa;
                            var liList = [];
                            for(var i=0;i<bb;i++){
                                var li = document.createElement("li");
                                li.style.border = "none";
                                li.style.float = "left";
                                li.style.width = carouselItemWidth+"px";
                                li.className = "c_list_item c_index_"+(carouselItemsLength+i+1)+" empty_li";
                                liList[i] = li;
                            }
                            for(var i=0;i<bb;i++){
                                carouselList.appendChild(liList[i]);
                            }
                        }
                    }

                    var removeEmptyLis = function(carouselList){
                        var carouselItemsAll = angular.element(carouselList).children();
                        for(var i=0;i<carouselItemsAll.length;i++){
                            var carouselItemObj = carouselItemsAll[i];
                            if(carouselItemObj.className.indexOf("empty_li")!=-1){
                                carouselList.removeChild(carouselItemsAll[i]);
                            }
                        }
                    }
                    var calculateBlocksToMove = function(carouselScreen,carouselItems,carouselItemsLength){
                        var citemstomove = 0;
                        for(var i=0;i<carouselItemsLength;i++){
                            if(carouselItems[i].offsetWidth > 0){
                                citemstomove = Math.floor(carouselScreen.offsetWidth/carouselItems[i].offsetWidth);
                                break;
                            }
                        }
                        return citemstomove;
                    }
                    var addTransitionStyle = function(carouselList,transformVal){
                        carouselList.style.transition = "0.3s";
                        carouselList.style.setProperty("-webkit-transition", transformVal);
                        carouselList.style.setProperty("-moz-transition", transformVal);
                        carouselList.style.setProperty("-ms-transition", transformVal);
                        carouselList.style.setProperty("-o-transition", transformVal);
                    }
                    var addTransformStyle = function(carouselList,presentTransformVal){
                        carouselList.style.transform = "translate3d("+presentTransformVal+"px, 0px, 0px)";
                        carouselList.style.setProperty("-webkit-transform", "translate3d("+presentTransformVal+"px, 0px, 0px)");
                        carouselList.style.setProperty("-moz-transform", "translate3d("+presentTransformVal+"px, 0px, 0px)");
                        carouselList.style.setProperty("-ms-transform", "translate3d("+presentTransformVal+"px, 0px, 0px)");
                        carouselList.style.setProperty("-o-transform", "translate3d("+presentTransformVal+"px, 0px, 0px)");
                    }
                    var slideLeft = function(){
                        if(isSliding == 0){
                            isSliding = 1;
                            carouselItems = angular.element(carouselList).children();
                            carouselItemWidth = carouselItems[0].offsetWidth;
                            carouselItemsLength = carouselItems.length;
                            var presentTransformVal = getCurrentTransformVal();
                            if(currentSlide < maxSlides-1){
                                presentTransformVal = presentTransformVal-(carouselItemsVisible*carouselItemWidth);
                                addTransitionStyle(carouselList,"0.3s");
                                addTransformStyle(carouselList,presentTransformVal);
                                currentSlide++;
                                isSliding=0;
                            }else{
                                presentTransformVal = presentTransformVal-(carouselItemsVisible*carouselItemWidth);
                                addTransitionStyle(carouselList,"0.3");
                                addTransformStyle(carouselList,presentTransformVal);
                                addTransitionStyle(carouselList,"");
                                addTransformStyle(carouselList,0);
                                currentSlide = 0;
                                isSliding=0;
//                                $timeout(function(){
//                                    addTransitionStyle(carouselList,"");
//                                    addTransformStyle(carouselList,0);
//                                    currentSlide = 0;
//                                    isSliding=0;
//                                },10);
                            }
                        }
                    }

                    var slideRight = function(){

                        if(isSliding == 0){
                            isSliding = 1;
                            carouselItems = angular.element(carouselList).children();
                            carouselItemWidth = carouselItems[0].offsetWidth;
                            carouselItemsLength = carouselItems.length;
                            var presentTransformVal = getCurrentTransformVal();
                            if(currentSlide == 0){
                                addTransitionStyle(carouselList,"");
                                presentTransformVal = getCurrentTransformVal()-(carouselItemWidth*(carouselItemsLength));
                                addTransformStyle(carouselList,presentTransformVal);
                                presentTransformVal = getCurrentTransformVal()+(carouselItemWidth*carouselItemsVisible);
                                addTransitionStyle(carouselList,"0.5s");
                                addTransformStyle(carouselList,presentTransformVal);
                                currentSlide = maxSlides-1;
                                isSliding=0;
                            }else{
                                if(currentSlide <= maxSlides){
                                    presentTransformVal = presentTransformVal+(carouselItemsVisible*carouselItemWidth);
                                    addTransitionStyle(carouselList,"0.3s");
                                    addTransformStyle(carouselList,presentTransformVal);
                                    currentSlide--;
                                    isSliding=0;
                                }
                            }
                        }
                    }

                    var getCurrentTransformVal = function(){
                        var transformStr = carouselList.style.transform;
                        var modifiedTransformStr = transformStr.substring(transformStr.indexOf("3d(")+3,transformStr.indexOf(",",transformStr.indexOf("3d(")));
                        modifiedTransformStr = modifiedTransformStr.replace("px","");
                        modifiedTransformStr = parseInt(modifiedTransformStr);
                        return modifiedTransformStr;
                    }
                    var isSilderEnabled=function(){
                        var enableSlideDefault=true;
                        if (typeof scope.disable_slide !== "undefined" && parseInt(scope.disable_slide) > 0) {
                            enableSlideDefault=false;
                        }
                        if (typeof scope.mobile_slide !== "undefined" && parseInt(scope.mobile_slide) > 0) {
                            enableSlideDefault=true;
                        }
                        return enableSlideDefault;
                    }
                    initCarousel();

                    $rootScope.$on('orientationChanged', function(isOrientationChanged){
                        if(isOrientationChanged){
                            isSliding=1;
                            $timeout(function(){
                                removeEmptyLis(carouselList);
                                addEmptyLis(carouselList);
                                addTransitionStyle(carouselList,"");
                                addTransformStyle(carouselList,0);
                                carouselItems = angular.element(carouselList).children();
                                carouselItemsLength = carouselItems.length;
                                carouselItemsVisible = calculateBlocksToMove(carouselScreen,carouselItems,carouselItemsLength);
                                maxSlides = (carouselItemsLength%carouselItemsVisible)==0?(carouselItemsLength/carouselItemsVisible):(parseInt(carouselItemsLength/carouselItemsVisible)+1);
                                currentSlide = 0;
                                isSliding=0;
                            },300);
                        }
                    });


                }
            }
        })
        .directive('dirHomePageCarousel',function(HelperService,$rootScope,$timeout,$window){
            return {
                scope: {
                    is_mobile: '@isMobile',
                    enable_nav_on_mobile:'@enableNavOnMobile',
                    is_mom_program : '@isMomProgram'
                },
              link: function(scope, element, attrs){
                     var carouselScreen, carouselList, carouselItems, carouselItemWidth, carouselItemsLength, carouselItemsVisible,currentSlideId,
                             carouselItemsLength, carouselPrevBtn, carouselNxtBtn, maxSlides, currentSlide,hf = HelperService,isSliding,isMomAdvisorClick;
                    var initCarousel = function(){
                        carouselScreen = element[0].getElementsByClassName('c_screen')[0];
                        carouselList = element[0].getElementsByClassName('c_list')[0];
                        carouselPrevBtn = element[0].getElementsByClassName('c_prev')[0];
                        carouselNxtBtn = element[0].getElementsByClassName('c_next')[0];
                        carouselItems = angular.element(carouselList).children();
                        carouselItemWidth = carouselItems[0].offsetWidth;
                        carouselItemsLength = carouselItems.length;
                        carouselItemsVisible = calculateBlocksToMove(carouselScreen,carouselItems,carouselItemsLength);
                        maxSlides = (carouselItemsLength%carouselItemsVisible)==0?(carouselItemsLength/carouselItemsVisible):(parseInt(carouselItemsLength/carouselItemsVisible)+1);
                        currentSlide = 0;
                        updateStepInfoData();
                        if(document.getElementById("c_slide_"+parseInt(currentSlide)))
                        $rootScope.currentSlideId=document.getElementById("c_slide_"+parseInt(currentSlide)).getAttribute("data-slide-id");
                        carouselList.style.position = "relative";
                        addTransitionStyle(carouselList,"0.3s");
                        addTransformStyle(carouselList,0);
                        carouselList.style.width = "6000px";
                        isSliding=0;
                        isMomAdvisorClick=false;
                        angular.element(carouselPrevBtn).on('click',function($event){
                           isMomAdvisorClick=true;
                           slideRight($event);
                        });
                        angular.element(carouselNxtBtn).on('click',function($event){
                            isMomAdvisorClick=true;
                            slideLeft($event);
                        });
                        hf.$(carouselScreen).onSwipeLeft(function($event) {
                            isMomAdvisorClick=false;
                             if (parseInt(scope.is_mobile) > 0 && parseInt(scope.enable_nav_on_mobile) > 0) {
                                var currentTarget = $event.target;
                                if (currentTarget.closest('li') != null) {
                                    var currentUl = currentTarget.closest('li').parentNode;
                                    var parentNode = currentUl.closest(".c_carousel");
                                    var parentNodeId = parentNode.getAttribute('id');
                                    var parentObj = document.getElementById(parentNodeId);
                                    var bulletElms = parentObj.getElementsByClassName('c_bullet_mobile_hg');
                                    var currentIndex = currentSlide + 1;
                                    if (currentIndex >= bulletElms.length) {
                                        currentIndex = 0;
                                    }
                                    var c_bullet_mobile_cls = 'c_bullet_mobile_hg_' + (currentIndex);
                                    for (var i = 0; i < bulletElms.length; i++) {
                                        if (bulletElms[i].classList.contains('active'))
                                            bulletElms[i].classList.remove('active');
                                        if (bulletElms[i].classList.contains('active-view-more-course-advisor'))
                                            bulletElms[i].classList.remove('active-view-more-course-advisor');
                                    }
                                    if (typeof parentObj.getElementsByClassName(c_bullet_mobile_cls)[0] !== "undefined" && parentObj.getElementsByClassName(c_bullet_mobile_cls)[0] !== null)
                                        parentObj.getElementsByClassName(c_bullet_mobile_cls)[0].classList.add('active');
                                  slideLeft($event);
                                }
                            } else {
                                slideLeft($event);
                            }
                             
                        });
                        hf.$(carouselScreen).onSwipeRight(function($event) {
                            isMomAdvisorClick=false;
                            if (parseInt(scope.is_mobile) > 0 && parseInt(scope.enable_nav_on_mobile) > 0) {
                                var currentTarget = $event.target;
                                if (currentTarget.closest('li') != null) {
                                    var currentUl = currentTarget.closest('li').parentNode;
                                    var parentNode = currentUl.closest(".c_carousel");
                                    var parentNodeId = parentNode.getAttribute('id');
                                    var parentObj = document.getElementById(parentNodeId);
                                    var bulletElms = parentObj.getElementsByClassName('c_bullet_mobile_hg');
                                    var currentIndex = currentSlide - 1;
                                    if (currentIndex < 0) {
                                        currentIndex = parseInt(bulletElms.length) - 1;
                                    }
                                    var c_bullet_mobile_cls = 'c_bullet_mobile_hg_' + (currentIndex);
                                    for (var i = 0; i < bulletElms.length; i++) {
                                        if (bulletElms[i].classList.contains('active'))
                                            bulletElms[i].classList.remove('active');
                                        if (bulletElms[i].classList.contains('active-view-more-course-advisor'))
                                            bulletElms[i].classList.remove('active-view-more-course-advisor');
                                    }
                                    if (typeof parentObj.getElementsByClassName(c_bullet_mobile_cls)[0] !== "undefined" && parentObj.getElementsByClassName(c_bullet_mobile_cls)[0] !== null)
                                        parentObj.getElementsByClassName(c_bullet_mobile_cls)[0].classList.add('active');
                                    slideRight($event);
                                }

                            } else {
                                slideRight($event);
                            }
                        });
                        getCurrentTransformVal();
                        addEmptyLis(carouselList);
                        $timeout(function () {
                            navigationBulletHandleOnOrientationChange();

                        }, 100);
                    }
                    
                    var updateStepInfoData = function() {
                        angular.element(element[0]).attr('data-current-slide', currentSlide+1);
                    }

                    var addEmptyLis = function(carouselList){
                        carouselItems = angular.element(carouselList).children();
                        carouselItemsLength = carouselItems.length;
                        carouselItemsVisible = calculateBlocksToMove(carouselScreen,carouselItems,carouselItemsLength);
                        var aa = carouselItemsLength%carouselItemsVisible;
                        if(aa != 0){
                            var bb = carouselItemsVisible-aa;
                            var liList = [];
                            for(var i=0;i<bb;i++){
                                var li = document.createElement("li");
                                li.style.border = "none";
                                li.style.float = "left";
                                li.style.width = carouselItemWidth+"px";
                                li.className = "c_list_item c_index_"+(carouselItemsLength+i+1)+" empty_li";
                                liList[i] = li;
                            }
                            for(var i=0;i<bb;i++){
                                carouselList.appendChild(liList[i]);
                            }
                        }
                    }

                    var removeEmptyLis = function(carouselList){
                        var carouselItemsAll = angular.element(carouselList).children();
                        for(var i=0;i<carouselItemsAll.length;i++){
                            var carouselItemObj = carouselItemsAll[i];
                            if(carouselItemObj.className.indexOf("empty_li")!=-1){
                                carouselList.removeChild(carouselItemsAll[i]);
                            }
                        }
                    }
                    var calculateBlocksToMove = function(carouselScreen,carouselItems,carouselItemsLength){
                        var citemstomove = 0;
                        for(var i=0;i<carouselItemsLength;i++){
                            if(carouselItems[i].offsetWidth > 0){
                                citemstomove = Math.floor(carouselScreen.offsetWidth/carouselItems[i].offsetWidth);
                                break;
                            }
                        }
                        return citemstomove;
                    }
                    var addTransitionStyle = function(carouselList,transformVal){
                        carouselList.style.transition = "0.3s";
                        carouselList.style.setProperty("-webkit-transition", transformVal);
                        carouselList.style.setProperty("-moz-transition", transformVal);
                        carouselList.style.setProperty("-ms-transition", transformVal);
                        carouselList.style.setProperty("-o-transition", transformVal);
                    }
                    var addTransformStyle = function(carouselList,presentTransformVal){
                        carouselList.style.transform = "translate3d("+presentTransformVal+"px, 0px, 0px)";
                        carouselList.style.setProperty("-webkit-transform", "translate3d("+presentTransformVal+"px, 0px, 0px)");
                        carouselList.style.setProperty("-moz-transform", "translate3d("+presentTransformVal+"px, 0px, 0px)");
                        carouselList.style.setProperty("-ms-transform", "translate3d("+presentTransformVal+"px, 0px, 0px)");
                        carouselList.style.setProperty("-o-transform", "translate3d("+presentTransformVal+"px, 0px, 0px)");
                    }
                    var bulletTransition=function(slide,event){
                        var currentTarget = event.currentTarget;
                        var parentNode=currentTarget.parentNode;
                        var parentNodeId=parentNode.getAttribute('id');
                        var parentObj=document.getElementById(parentNodeId);
                        if(parentObj !=null && parentObj.getElementsByClassName("view-more-btn")){
                                var parentElm= parentObj.getElementsByClassName("view-more-btn")[0];
                                var childElmLength=parseInt(parentElm.children.length);
                                var currentBulletIndex,nextBulletIndex=0;
                                var nextElemToHighLight='';
                                for(var i=0;i<childElmLength;i++){
                                    var childElm=parentElm.children[i];
                                    if (childElm.classList.contains('active')) {
                                    if (slide == 'left') {
                                        nextBulletIndex = parseInt(i) + 1;
                                        parentElm.children[i].classList.remove('active');
                                        if (parentElm.children[i].classList.contains('active-view-more-course-advisor'))
                                            parentElm.children[i].classList.remove('active-view-more-course-advisor');
                                        if (parseInt(nextBulletIndex) < childElmLength) {
                                            parentElm.children[nextBulletIndex].classList.add('active');
                                        } else {
                                            nextBulletIndex = 0;
                                            parentElm.children[nextBulletIndex].classList.add('active');
                                        }
                                    }
                                    if (slide == 'right') {
                                        nextBulletIndex = parseInt(i) > 0 ? parseInt(i) - 1:parseInt(childElmLength)-1;
                                        if (parseInt(nextBulletIndex) < childElmLength) {
                                            parentElm.children[i].classList.remove('active');
                                             if (parentElm.children[i].classList.contains('active-view-more-course-advisor'))
                                            parentElm.children[i].classList.remove('active-view-more-course-advisor');
                                            parentElm.children[nextBulletIndex].classList.add('active');
                                        } 
                                    }

                                    break;
                                }
                                }
                            }
                    }

                    var slideLeft = function(event){
                        if(isSliding == 0){
                            isSliding = 1;
                            carouselItems = angular.element(carouselList).children();
                            carouselItemWidth = carouselItems[0].offsetWidth;
                            carouselItemsLength = carouselItems.length;
                            var presentTransformVal = getCurrentTransformVal();
                            if(currentSlide < maxSlides-1){
                                presentTransformVal = presentTransformVal-(carouselItemsVisible*carouselItemWidth);
                                addTransitionStyle(carouselList,"0.3s");
                                addTransformStyle(carouselList,presentTransformVal);
                                currentSlide++;
                                isSliding=0;
                                updateStepInfoData();
                            }else{
                                currentSlide=0;
                                var copiedObjs = [];
                                var clonedObjs = [];
                                for(var i=0;i<carouselItemsLength;i++){
                                    copiedObjs[i] = carouselList.children[i];
                                    clonedObjs[i] = copiedObjs[i].cloneNode(true);
                                }
                                //append elements to the end of the list
                                for(var i=0;i<carouselItemsLength;i++){
                                    carouselList.appendChild(clonedObjs[i]);
                                }
                                presentTransformVal = presentTransformVal-(carouselItemsVisible*carouselItemWidth);
                                addTransitionStyle(carouselList,"0.3");
                                addTransformStyle(carouselList,presentTransformVal);
                                $timeout(function(){
                                    for(var i=0;i<carouselItemsLength;i++){
                                        carouselList.removeChild(copiedObjs[i]);
                                    }
                                    addTransitionStyle(carouselList,"");
                                    addTransformStyle(carouselList,0);
                                    currentSlide = 0;
                                    isSliding=0;
                                    updateStepInfoData();
                                },300);
                            }
                            if(document.getElementById("c_slide_"+parseInt(currentSlide)))
                            currentSlideId=document.getElementById("c_slide_"+parseInt(currentSlide)).getAttribute("data-slide-id");
                            $rootScope.currentSlideId=currentSlideId;
                            if(parseInt(scope.is_mobile) === 0 && parseInt(scope.enable_nav_on_mobile) === 0){
                                bulletTransition('left',event);
                            }
                            if(parseInt(scope.is_mom_program) && isMomAdvisorClick){
                                bulletTransition('left',event);
                            }
                        }
                    }

                    var slideRight = function(event){
                        if(isSliding == 0){
                            isSliding = 1;
                            carouselItems = angular.element(carouselList).children();
                            carouselItemWidth = carouselItems[0].offsetWidth;
                            carouselItemsLength = carouselItems.length;
                            var presentTransformVal = getCurrentTransformVal();
                            if(currentSlide == 0){
                                var copiedObjs = [], clonedObjs = [];
                                for(var i=0;i<carouselItemsLength;i++){
                                    copiedObjs[i] = carouselList.children[carouselItemsLength - (i + 1)];
                                    clonedObjs[i] = copiedObjs[i].cloneNode(true);
                                }
                                addTransitionStyle(carouselList,"");
                                //append elements to the end of the list
                                for(var i=0;i<clonedObjs.length;i++){
                                    carouselList.insertBefore(clonedObjs[i], carouselList.firstChild);
                                }
                                presentTransformVal = getCurrentTransformVal()-(carouselItemWidth*(carouselItemsLength));
                                addTransformStyle(carouselList,presentTransformVal);
                                setTimeout(function(){
                                    presentTransformVal = getCurrentTransformVal()+(carouselItemWidth*carouselItemsVisible);
                                    addTransitionStyle(carouselList,"0.3s");
                                    addTransformStyle(carouselList,presentTransformVal);
                                    for(var i=0;i<carouselItemsLength;i++){
                                        carouselList.removeChild(copiedObjs[i]);
                                    }
                                    currentSlide = maxSlides-1;
                                    isSliding=0;
                                    updateStepInfoData();
                                },200);

                            }else{
                                if(currentSlide <= maxSlides){
                                    presentTransformVal = presentTransformVal+(carouselItemsVisible*carouselItemWidth);
                                    addTransitionStyle(carouselList,"0.3s");
                                    addTransformStyle(carouselList,presentTransformVal);
                                    currentSlide--;
                                    isSliding=0;
                                }
                                updateStepInfoData();
                            }
                            if(document.getElementById("c_slide_"+parseInt(currentSlide)))
                            currentSlideId=document.getElementById("c_slide_"+parseInt(currentSlide)).getAttribute("data-slide-id");
                            $rootScope.currentSlideId=currentSlideId;
                            if(parseInt(scope.is_mobile) === 0 && parseInt(scope.enable_nav_on_mobile) === 0){
                               bulletTransition('right',event);
                           }
                           if(parseInt(scope.is_mom_program) && isMomAdvisorClick){
                               bulletTransition('right',event);
                           }
                        }
                    }

                    var getCurrentTransformVal = function(){
                        var transformStr = carouselList.style.transform;
                        var modifiedTransformStr = transformStr.substring(transformStr.indexOf("3d(")+3,transformStr.indexOf(",",transformStr.indexOf("3d(")));
                        modifiedTransformStr = modifiedTransformStr.replace("px","");
                        modifiedTransformStr = parseInt(modifiedTransformStr);
                        return modifiedTransformStr;
                    }
                    var resetNavigationBullet = function () {
                        try {
                            var bulletElms = document.getElementsByClassName('c_bullet_mobile_hg');
                            if (bulletElms.length > 0) {
                                var bulletIndex = 0;
                                var c_bullet_mobile_cls = 'c_bullet_mobile_hg_' + (bulletIndex);
                                for (var i = 0; i < bulletElms.length; i++) {
                                    if (bulletElms[i].classList.contains('active'))
                                        bulletElms[i].classList.remove('active');
                                }
                                if (typeof document.getElementsByClassName(c_bullet_mobile_cls)[0] !== "undefined" && document.getElementsByClassName(c_bullet_mobile_cls)[0] !== null)
                                    document.getElementsByClassName(c_bullet_mobile_cls)[0].classList.add('active');
                            }
                        }
                        catch (e) {}
                    }
                    var navigationBulletHandleOnOrientationChange = function () {
                        var parentObj = document.getElementById('happy-graduates-carousel');
                        try {
                            if (parentObj !== null) {
                                var viewMoreBtn = parentObj.getElementsByClassName("view-more-btn");
                                if (viewMoreBtn !== null) {
                                    var viewMoreObj = viewMoreBtn[0];
                                    if (viewMoreObj !== null && typeof viewMoreObj !== "undefined") {
                                        if (window.matchMedia("(orientation: landscape)").matches) {
                                            viewMoreObj.classList.add('hide');
                                        }
                                        if (window.matchMedia("(orientation: portrait)").matches) {
                                            viewMoreObj.classList.remove('hide');
                                        }
                                    }
                                }
                            }
                        } catch (e) {}
                    }
                    initCarousel();
                    $rootScope.$on('orientationChanged', function(isOrientationChanged){
                        if(isOrientationChanged){
                            isSliding=1;
                            $timeout(function(){
                                removeEmptyLis(carouselList);
                                addEmptyLis(carouselList);
                                addTransitionStyle(carouselList,"");
                                addTransformStyle(carouselList,0);
                                carouselItems = angular.element(carouselList).children();
                                carouselItemsLength = carouselItems.length;
                                carouselItemsVisible = calculateBlocksToMove(carouselScreen,carouselItems,carouselItemsLength);
                                maxSlides = (carouselItemsLength%carouselItemsVisible)==0?(carouselItemsLength/carouselItemsVisible):(parseInt(carouselItemsLength/carouselItemsVisible)+1);
                                currentSlide = 0;
                                isSliding=0;
                                resetNavigationBullet();
                                navigationBulletHandleOnOrientationChange();
                                updateStepInfoData();
                            },300);
                        }
                    });
                }
            }
        })
        .directive('dirUserCookieConsent', function (HelperService, $rootScope, $window) {
            return {
                scope: {
                },
                link: function (scope, element, attrs) {
                    var consentButton, consentContainer;
                    var initUserCookieConsent = function () {
                        $rootScope.isgdprCookieSet = false;
                        var isGdprCookieExist = checkIfGdprCookieExist();
                        var euContainer = document.getElementsByClassName('eu-container')[0];
                        if (typeof isGdprCookieExist !== "undefined" && isGdprCookieExist) {
                            $rootScope.isgdprCookieSet = true;
                            euContainer.remove();
                            var atpElem = document.getElementById('eu_sticky_visible');
                            if (atpElem) {
                                var atpElemClasslist = atpElem.classList;
                                if (atpElemClasslist)
                                    atpElemClasslist.remove('eu_sticky_visible');
                            }
                        } else {
                            euContainer.classList.remove("hide");
                        }

                        consentButton = element[0].getElementsByClassName('gdpr-user-cookie-consent')[0];
                        angular.element(consentButton).on('click', function ($event) {
                            var cname = user_params.gdprCookieName;
                            var cvalue = 1;
                            var d = new Date();
                            d.setTime(d.getTime() + (3600 * 1000 * 24 * 365));
                            var expires = "expires=" + d.toUTCString();
                            document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/;domain=.simplilearn.com;SameSite=Lax;";
                            euContainer.remove();
                            var atpElem = document.getElementById('eu_sticky_visible');
                            if (atpElem) {
                                var atpElemClasslist = atpElem.classList;
                                if (atpElemClasslist)
                                    atpElemClasslist.remove('eu_sticky_visible');
                            }
                        });
                    }
                    var checkIfGdprCookieExist = function () {
                        var c_name = user_params.gdprCookieName;
                        var i, x, y, ARRcookies = document.cookie.split(";");
                        for (i = 0; i < ARRcookies.length; i++) {
                            x = ARRcookies[i].substr(0, ARRcookies[i].indexOf("="));
                            y = ARRcookies[i].substr(ARRcookies[i].indexOf("=") + 1);
                            x = x.replace(/^\s+|\s+$/g, "");
                            if (x == c_name) {
                                return unescape(y);
                            }
                        }
                    }
                    initUserCookieConsent();
                }
            }
        })