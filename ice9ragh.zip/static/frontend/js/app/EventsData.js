function gaEventsTracker() {

    this.overAllFunnelString = 'overall funnel';
    this.classRoomFunnelString = 'classroom funnel';
    this.onlineFunnelString = 'online funnel';
    this.noWorkshopFoundFunnel = 'No Workshop Found';
    this.invalidCoupon = 'Cart Page';

    this.eventsRedmine1094 = {
        'flyouthover': {'category': "Navigation", 'action': "Flyout hover", 'labelRequired': true, 'noninteractiveness': true},
        'flyoutclick': {'category': "Navigation", 'action': "Flyout Popular Course clicked", 'labelRequired': true, 'noninteractiveness': false},
        'flyoutMasterProgclick': {'category': "Navigation", 'action': "Click on Masters Program in Megamenu", 'labelRequired': true, 'noninteractiveness': false},
        'flyoutcatclick': {'category': "Navigation", 'action': "Flyout category button clicked", 'labelRequired': true, 'noninteractiveness': false},
        'frsmenuhover': {'category': "Navigation", 'action': "Resources - Top Bar hover", 'labelRequired': true, 'noninteractiveness': true},
        'resourcesclick': {'category': "Navigation", 'action': "Resources - Top Bar content clicked", 'labelRequired': true, 'noninteractiveness': false},
        'logoclick': {'category': "Navigation", 'action': "Simplilearn Logo", 'labelRequired': true, 'noninteractiveness': false},
        'headercorporatelinkclick': {'category': "Navigation", 'action': "Corporate Training - Top Bar", 'labelRequired': true, 'noninteractiveness': false},
        'headerinstructorlinkclick': {'category': "Navigation", 'action': "Become an instructor - Top Bar", 'labelRequired': true, 'noninteractiveness': false},
        'searchinitiated': {'category': "Navigation", 'action': "Search Initiated", 'labelRequired': true, 'noninteractiveness': true},
        'Search_tab_header': {'category': "Navigation", 'action': "Search Finished", 'labelRequired': true, 'noninteractiveness': false},
        'resourcescatclick': {'category': "Navigation", 'action': "Resources - Top Bar category clicked", 'labelRequired': true, 'noninteractiveness': false},
        'peopleAlsoViewedSectionClicked': {'category': "Navigation", 'action': "User clicks on People also viewed section", 'labelRequired': true, 'noninteractiveness': false},
        'homepagejumpto': {'category': "Home Page", 'action': "Quick Link", 'labelRequired': true, 'noninteractiveness': false},
        'mastercardclick': {'category': "Home Page", 'action': "Master Course Card Click", 'labelRequired': true, 'noninteractiveness': false},
        'viewmoretestimonials': {'category': "Engagement", 'action': "View More Testimonials", 'labelRequired': true, 'noninteractiveness': false},
        'alumniprofilevisit': {'category': "Engagement", 'action': "Alumni Profile Clicked", 'labelRequired': true, 'noninteractiveness': false},
        'Category_advisor_social_click': {'category': "Engagement", 'action': "Category Advisor Profile Clicked", 'labelRequired': true, 'noninteractiveness': false},
        'mobileapplinkclick': {'category': "Engagement", 'action': "Mobile AppStore Visit", 'labelRequired': true, 'noninteractiveness': false},
        'inmedialinkclick': {'category': "Engagement", 'action': "Media coverage", 'labelRequired': true, 'noninteractiveness': false},
        'Re_WebFooter': {'category': "Navigation", 'action': "Refer & Earn - Footer", 'labelRequired': true, 'noninteractiveness': false},
        'mobileapplinkfooter': {'category': "Engagement", 'action': "Mobile AppStore Visit - Footer", 'labelRequired': true, 'noninteractiveness': false},
        'crosseventscountrychangesuccess': {'category': "Engagement", 'action': "Country Change", 'labelRequired': true, 'noninteractiveness': false},
        'helpandsupportfooter': {'category': "Navigation", 'action': "Help & Support", 'labelRequired': true, 'noninteractiveness': false},
        'leadformclicked': {'category': "Lead Capture", 'action': "Lead form Clicked", 'labelRequired': true, 'noninteractiveness': false},
        'crosseventslivechattry': {'category': "Lead Capture", 'action': "Lead form Clicked", 'labelRequired': true, 'noninteractiveness': true},
        'leads_form_filled': {'category': "Lead Capture", 'action': "Lead process Initiated", 'labelRequired': true, 'noninteractiveness': false},
        'leadcapturequeryform': {'category': "Lead Capture", 'action': "Lead Submitted", 'labelRequired': true, 'noninteractiveness': false},
        'leadcaptureconvenientsched': {'category': "Lead Capture", 'action': "Lead Submitted", 'labelRequired': true, 'labelValue': 'Convenient Schedule', 'noninteractiveness': false},
        'leadcapturefail': {'category': "Lead Capture", 'action': "Lead Submit Failure", 'labelRequired': true, 'noninteractiveness': false},
        'leadinitiatepreview': {'category': "Lead Capture", 'action': "Lead process Initiated", 'labelRequired': true, 'noninteractiveness': false},
        'leadsubmittedpreview': {'category': "Lead Capture", 'action': "Lead Submitted", 'labelRequired': true, 'noninteractiveness': false},
        'introvideoclick': {'category': "Engagement", 'action': "Introduction video clicked", 'labelRequired': true, 'noninteractiveness': false},
        'introvideowatched': {'category': "Engagement", 'action': "Introduction Video watched", 'labelRequired': true, 'noninteractiveness': false},
        'previewvideowatched': {'category': "Engagement", 'action': "Course Preview Video watched", 'labelRequired': true, 'noninteractiveness': false},
        'introvideoclosed': {'category': "Engagement", 'action': "Introduction video closed", 'labelRequired': true, 'noninteractiveness': false},
        'custtestimonialarrowclick': {'category': "Engagement", 'action': "Customer testimonials arrows click", 'labelRequired': true, 'noninteractiveness': true},
        'mastercardarrowclick': {'category': "Engagement", 'action': "Master Course Card arrows click", 'labelRequired': true, 'noninteractiveness': true},
        'categorycourseclick': {'category': "Navigation", 'action': "Course Card Click", 'labelRequired': true, 'noninteractiveness': false},
        'viewmorecoursesclick': {'category': "Navigation", 'action': "View More Popular Courses", 'labelRequired': true, 'noninteractiveness': false},
        'Category_partner_click': {'category': "Engagement", 'action': "Course Partner profile clicked", 'labelRequired': true, 'noninteractiveness': false},
        'coursestickyheader': {'category': "Engagement", 'action': "Course details sticky header", 'labelRequired': true, 'noninteractiveness': false},
        'viewclassschedule': {'category': "Engagement", 'action': "View class schedule", 'labelRequired': true, 'noninteractiveness': false},
        'downloadschedule': {'category': "Engagement", 'action': "Download class schedule", 'labelRequired': true, 'noninteractiveness': false},
        'showmorereviews': {'category': "Engagement", 'action': "View More Reviewer Profiles", 'labelRequired': true, 'noninteractiveness': false},
        'reviewerprofileclick': {'category': "Engagement", 'action': "Reviewer profile clicked", 'labelRequired': true, 'noninteractiveness': false},
        'chapternameclick': {'category': "Engagement", 'action': "Chapter name clicked", 'labelRequired': true, 'noninteractiveness': false},
        'enroll_online': {'category': "Payment", 'action': "Enroll for OSL", 'labelRequired': true, 'noninteractiveness': false},
        'enroll_lvc': {'category': "Payment", 'action': "Enroll for LVC", 'labelRequired': true, 'noninteractiveness': false},
        'enroll_classroom': {'category': "Payment", 'action': "Enroll for Classroom", 'labelRequired': true, 'noninteractiveness': false},
        'subslearningpathClick': {'category': "Engagement", 'action': "Course option selected - master Learning path", 'labelRequired': true, 'noninteractiveness': false},
        'jobassistclick': {'category': "Navigation", 'action': "Job Assist", 'labelRequired': true, 'noninteractiveness': false},
        'fpt_link_course': {'category': "Navigation", 'action': "Free Practice Test", 'labelRequired': true, 'noninteractiveness': false},
        'fptleadinitiated': {'category': "FPT - Lead Capture", 'action': "Lead process Initiated", 'labelRequired': true, 'noninteractiveness': false},
        'fptleadsubmitted': {'category': "FPT - Lead Capture", 'action': "Lead Submitted", 'labelRequired': true, 'noninteractiveness': false},
        'fptquestionsubmitted': {'category': "FPT - Lead Capture", 'action': "FPT-Question#", 'labelRequired': true, 'noninteractiveness': false},
        'crosseventsloginopen': {'category': "Engagement", 'action': "Login Top Header clicked", 'labelRequired': true, 'noninteractiveness': false},
        'loginsignupinitiated': {'category': "Engagement", 'action': "Login/Sign in process Initiated", 'labelRequired': true, 'noninteractiveness': false},
        'autologin': {'category': "Engagement", 'action': "Auto Login from cookie", 'labelRequired': true, 'noninteractiveness': false},
        'loginsignupsubmitted': {'category': "Engagement", 'action': "Login/Sign in credentials Submitted", 'labelRequired': true, 'noninteractiveness': false},
        'linkedinloginclick': {'category': "Engagement", 'action': "Login/Sign in Linkedin button clicked", 'labelRequired': true, 'noninteractiveness': false},
        'searchloadmore': {'category': "Engagement", 'action': "Loading more results", 'labelRequired': true, 'noninteractiveness': false},
        'searchclearfilters': {'category': "Engagement", 'action': "Clear all filters", 'labelRequired': true, 'noninteractiveness': false},
        'searchcatfilter': {'category': "Engagement", 'action': "Apply Category filter", 'labelRequired': true, 'noninteractiveness': false},
        'searchresourcefilter': {'category': "Engagement", 'action': "Apply Free Resource filter", 'labelRequired': true, 'noninteractiveness': false},
        'paymentSuccessLvcPass': {'category': "Payment", 'action': "Payment Confirmed", 'labelRequired': true, 'noninteractiveness': false},
        'paymentSuccessCourse': {'category': "Payment", 'action': "Payment Confirmed", 'labelRequired': true, 'noninteractiveness': false},
        'enrollBundle': {'category': "Payment", 'action': "Enroll Master Course", 'labelRequired': true, 'noninteractiveness': false},
        'paymentSuccessBundle': {'category': "Payment", 'action': "Payment Confirmed", 'labelRequired': true, 'noninteractiveness': false},
        'coursepagewatchcoursepreview': {'category': "Engagement", 'action': "Course preview video click", 'labelRequired': true, 'noninteractiveness': false},
        'coursepageclosecoursepreview': {'category': "Engagement", 'action': "Course preview video closed", 'labelRequired': true, 'noninteractiveness': false},
        'breadcrumclick': {'category': "Navigation", 'action': "Bread crumb", 'labelRequired': true, 'noninteractiveness': false},
        'bundlestickyClick' : {'category': "Engagement", 'action':"Master Program details sticky header", 'labelRequired': true, 'noninteractiveness': true},
        'faqclickedopen' : {'category': "Engagement", 'action':"FAQ questions clicked open", 'labelRequired': true, 'noninteractiveness': true},
        'cdclickedopen' : {'category': "Engagement", 'action':"Course Description questions clicked open", 'labelRequired': true, 'noninteractiveness': true},
        'mdclickedopen' : {'category': "Engagement", 'action':"Master Program Description questions clicked open", 'labelRequired': true, 'noninteractiveness': true},
        'eacclickedopen' : {'category': "Engagement", 'action':"Exam and Certification questions clicked open", 'labelRequired': true, 'noninteractiveness': true},
        'jasubmitprofile' : {'category': "Job Assist - Engagement", 'action':"Submit profile", 'labelRequired': true, 'noninteractiveness': true},
        'corpclientstories' : {'category': "Engagement", 'action':"Client Stories - Arrow Click", 'labelRequired': true, 'noninteractiveness': true},
        'corpcourseclick' : {'category': "Navigation", 'action':"Course Card Click", 'labelRequired': true, 'noninteractiveness': true},
        'offerbannerclosed' : {'category': "Engagement", 'action':"Offer banner closed", 'labelRequired': true, 'noninteractiveness': true},
        'offerbannerclick' : {'category': "Engagement", 'action':"Offer banner clicked to show offer pop up", 'labelRequired': true, 'noninteractiveness': true},
        'offerstripclick' : {'category': "Engagement", 'action':"Offer strip clicked when banner is hidden", 'labelRequired': true, 'noninteractiveness': true},
        'offerpopupclosed' : {'category': "Engagement", 'action':"Offer pop up closed", 'labelRequired': true, 'noninteractiveness': true},
        'atpleadformclick' : {'category': "Lead Capture", 'action':"Lead form Clicked", 'labelRequired': true, 'noninteractiveness': true},
        'atpleadprocessinit' : {'category': "Lead Capture", 'action':"Lead process Initiated", 'labelRequired': true, 'noninteractiveness': true},
        'atpleadsubmit' : {'category': "Lead Capture", 'action':"Lead Submitted", 'labelRequired': true, 'noninteractiveness': true},
        'atpintrovideoclick' : {'category': "Engagement", 'action':"Introduction video clicked", 'labelRequired': true, 'noninteractiveness': true},
        'atpstickyheader' : {'category': "Engagement", 'action':"ATP Page sticky header", 'labelRequired': true, 'noninteractiveness': true},
        'atptestimonialsarrow' : {'category': "Engagement", 'action':"Customer testimonials arrows click", 'labelRequired': true, 'noninteractiveness': true},
        'clickoncoursecontenttab' : {'category': "Engagement", 'action':"Click on Course Content tab", 'labelRequired': true, 'noninteractiveness': true},
        'gsaleadformclick' : {'category': "Lead Capture", 'action':"Lead form Clicked", 'labelRequired': true, 'noninteractiveness': true},
        'gsaleadprocessinit' : {'category': "Lead Capture", 'action':"Lead process Initiated", 'labelRequired': true, 'noninteractiveness': true},
        'gsaleadsubmit' : {'category': "Lead Capture", 'action':"Lead Submitted", 'labelRequired': true, 'noninteractiveness': true},
        'masterProgramEmiKnowMore': {'category': "Engagement", 'action': "EMI - Know more clicked", 'labelRequired': true, 'noninteractiveness': false},
        'masterProgramEmiEnroll': {'category': "Payment", 'action': "EMI - Enroll now clicked ", 'labelRequired': true, 'noninteractiveness': false},



        'homepageflyout': {'category': "Home Page", 'action': "Flyout", 'labelRequired': true, 'noninteractiveness': false},
        'homepagesearch': {'category': "Home Page", 'action': "Search", 'labelRequired': true, 'noninteractiveness': false},
        'homepagepopularcourseclick': {'category': "Home Page", 'action': "Popular Course Click", 'labelRequired': true, 'noninteractiveness': false},
        'homepagepopularcourseverticalclick': {'category': "Home Page", 'action': "Popular Course Vertical Click", 'labelRequired': true, 'noninteractiveness': true},
        'homepageselecttrainingtype': {'category': "Home Page", 'action': "Select Training Type", 'labelRequired': true, 'noninteractiveness': false},
        'courselistpageselectcourse': {'category': "Course List Page", 'action': "Select Course", 'labelRequired': true, 'noninteractiveness': false},
        'courselistpagequeryformsubmit': {'category': "Course List Page", 'action': "Query Form Submit", 'labelRequired': true, 'noninteractiveness': false},
        'coursepagegenerictrain': {'category': "Course Page Generic", 'action': "Select Training Type", 'labelRequired': true, 'noninteractiveness': false},
        'coursepagegenericcourseintro': {'category': "Course Page Generic", 'action': "View Course Intro", 'labelRequired': true, 'noninteractiveness': true},
        'coursepagegenericviewothertrain': {'category': "Course Page Generic", 'action': "View Other Training Type", 'labelRequired': false, 'noninteractiveness': true},
        'coursepagegenericcoursepreview': {'category': "Course Page Generic", 'action': "Course Preview Try", 'labelRequired': false, 'noninteractiveness': true},
        'coursepagegenericcoursepreviewsuccess': {'category': "Course Page Generic", 'action': "Course Preview Success", 'labelRequired': false, 'noninteractiveness': false},
        'coursepagegenericcitytraining': {'category': "Course Page Generic", 'action': "Choose City Training Page", 'labelRequired': true, 'noninteractiveness': false},
        'coursepagegenericqueryformsubmit': {'category': "Course Page Generic", 'action': "Query Form Submit", 'labelRequired': false, 'noninteractiveness': false},
        'coursepagegenericcorporatetry': {'category': "Course Page Generic", 'action': "Corporate_Lead Try", 'labelRequired': false, 'noninteractiveness': true},
        'coursepagegenericcorporatesuccess': {'category': "Course Page Generic", 'action': "Corporate_Lead Success", 'labelRequired': false, 'noninteractiveness': false},
        'coursepageonlinetrain': {'category': "Course Page OSL", 'action': "Choose ILT as Training Type", 'labelRequired': false, 'noninteractiveness': true},
        'coursepageonlinecourseintro': {'category': "Course Page OSL", 'action': "View Course Intro", 'labelRequired': true, 'noninteractiveness': true},
        'coursepageonlineviewothertrain': {'category': "Course Page OSL", 'action': "View Other Training Type", 'labelRequired': false, 'noninteractiveness': true},
        'coursepageonlinecoursepreview': {'category': "Course Page OSL", 'action': "Course Preview Try", 'labelRequired': false, 'noninteractiveness': true},
        'coursepageonlinecoursepreviewsuccess': {'category': "Course Page OSL", 'action': "Course Preview Success", 'labelRequired': false, 'noninteractiveness': false},
        'coursepageonlinecitytraining': {'category': "Course Page OSL", 'action': "Choose City Training Page", 'labelRequired': true, 'noninteractiveness': false},
        'coursepageonlinequeryformsubmit': {'category': "Course Page OSL", 'action': "Query Form Submit", 'labelRequired': false, 'noninteractiveness': false},
        'coursepageonlineenroll': {'category': "Course Page OSL", 'action': "Enroll", 'labelRequired': false, 'noninteractiveness': false},
        'coursepageonlinecorporatetry': {'category': "Course Page OSL", 'action': "Corporate_Lead Try", 'labelRequired': false, 'noninteractiveness': true},
        'coursepageonlinecorporatesuccess': {'category': "Course Page OSL", 'action': "Corporate_Lead Success", 'labelRequired': false, 'noninteractiveness': false},
        'coursepageclassroomcourseintro': {'category': "Course Page ILT", 'action': "View Course Intro", 'labelRequired': true, 'noninteractiveness': true},
        'coursepageclassroomviewothertrain': {'category': "Course Page ILT", 'action': "View Other Training Type", 'labelRequired': false, 'noninteractiveness': true},
        'coursepageclassroomtrain': {'category': "Course Page ILT", 'action': "Choose OSL as Training Type", 'labelRequired': false, 'noninteractiveness': true},
        'coursepageclassroomcoursepreview': {'category': "Course Page ILT", 'action': "Course Preview Try", 'labelRequired': false, 'noninteractiveness': true},
        'coursepageclassroomcoursepreviewsuccess': {'category': "Course Page ILT", 'action': "Course Preview Success", 'labelRequired': false, 'noninteractiveness': false},
        'coursepageclassroomenroll': {'category': "Course Page ILT", 'action': "Enroll", 'labelRequired': false, 'noninteractiveness': false},
        'coursepageclassroomcorporatetry': {'category': "Course Page ILT", 'action': "Corporate_Lead Try", 'labelRequired': false, 'noninteractiveness': true},
        'coursepageclassroomcorporatesuccess': {'category': "Course Page ILT", 'action': "Corporate_Lead Success", 'labelRequired': false, 'noninteractiveness': false},
        'coursepageiltchangecitytry': {'category': "Course Page ILT", 'action': "Change City Try", 'labelRequired': false, 'noninteractiveness': true},
        'coursepageiltchangecitysuccess': {'category': "Course Page ILT", 'action': "Change City Success", 'labelRequired': true, 'noninteractiveness': true},
        'coursepageclassroomcitytraining': {'category': "Course Page ILT", 'action': "Choose City Training Page", 'labelRequired': true, 'noninteractiveness': false},
        'coursepageclassroomqueryformsubmit': {'category': "Course Page ILT", 'action': "Query Form Submit", 'labelRequired': false, 'noninteractiveness': false},
        'coursepageconvenienttry': {'category': "Course Page ILT", 'action': "Convenient Schedule Try", 'labelRequired': false, 'noninteractiveness': true},
        'coursepageconvenientsubmit': {'category': "Course Page ILT", 'action': "Convenient Schedule Submit", 'labelRequired': false, 'noninteractiveness': false},
        'coursepagecorporateleadcapture': {'category': "Lead Capture", 'action': "Lead Submitted", 'labelRequired': true, 'noninteractiveness': false},
        'cartpagecoupontry': {'category': "Cart Page", 'action': "Coupon Try", 'labelRequired': true, 'noninteractiveness': true},
        'cartpagecouponsuccess': {'category': "Cart Page", 'action': "Coupon Success", 'labelRequired': true, 'noninteractiveness': true},
        'cartpagecouponfail': {'category': "Cart Page", 'action': "Coupon Fail", 'labelRequired': true, 'noninteractiveness': true},
        'cartpageproceedtopay': {'category': "Cart Page", 'action': "Proceed to Pay Click", 'labelRequired': true, 'noninteractiveness': false},
        'crosseventsrequestcallbacktry': {'category': "Request a Call Back", 'action': "Try", 'labelRequired': false, 'noninteractiveness': true},
        'crosseventsrequestcallbacksuccess': {'category': "Request a Call Back", 'action': "Success", 'labelRequired': false, 'noninteractiveness': false},
        'crosseventsloginattempt': {'category': "Login", 'action': "Login Attempt", 'labelRequired': true, 'noninteractiveness': true},
        'crosseventsloginsuccess': {'category': "Login", 'action': "Login Success", 'labelRequired': true, 'noninteractiveness': false},
        'crosseventsloginfailure': {'category': "Login", 'action': "Login Failure", 'labelRequired': true, 'noninteractiveness': true},
        'crosseventsloginsignupclick': {'category': "Login", 'action': "Sign Up Click", 'labelRequired': false, 'noninteractiveness': true},
        'crosseventsloginsignupattempt': {'category': "Login", 'action': "Sign Up Attempt", 'labelRequired': true, 'noninteractiveness': true},
        'crosseventsloginsignupsuccess': {'category': "Login", 'action': "Sign Up Success", 'labelRequired': true, 'noninteractiveness': false},
        'crosseventsloginsignupfailure': {'category': "Login", 'action': "Sign Up Failure", 'labelRequired': true, 'noninteractiveness': true},
        'crosseventscountrychangetry': {'category': "Country_Change", 'action': "Try", 'labelRequired': true, 'noninteractiveness': true},
        'crosseventssearchattempt': {'category': "Search", 'action': "Attempt", 'labelRequired': true, 'noninteractiveness': true},
        'crosseventssearchlist': {'category': "Search", 'action': "List", 'labelRequired': true, 'noninteractiveness': false},
        'crosseventssearchclickresult': {'category': "Search", 'action': "Click_Result", 'labelRequired': true, 'noninteractiveness': false},
        'crosseventssearchnoresult': {'category': "Search", 'action': "No_Result", 'labelRequired': true, 'noninteractiveness': true},
        'leadcapturerequestcall': {'category': "Lead Capture", 'action': "Lead Submitted", 'labelRequired': true, 'labelValue': 'Request A Call', 'noninteractiveness': false},
        'leadcapturecoursepreview': {'category': "Lead Capture", 'action': "Lead Submitted", 'labelRequired': true, 'noninteractiveness': false},        'leadcaptureworkshopnotavail': {'category': "Lead Capture", 'action': "Lead Submitted", 'labelRequired': true, 'labelValue': 'Workshop Not Available', 'noninteractiveness': false},
        'leadcapturereferearnreferrer': {'category': "Lead Capture", 'action': "Lead Submitted", 'labelRequired': true, 'noninteractiveness': false},
        'leadcapturereferearnreferee': {'category': "Lead Capture", 'action': "Lead Submitted", 'labelRequired': true, 'noninteractiveness': false},
        'footercorporatelinkclick': {'category': "Footer", 'action': "Corporate", 'labelRequired': false, 'noninteractiveness': false},
        'corporatewebsiteleadcapture': {'category': "Lead Capture", 'action': "Lead Submitted", 'labelRequired': true, 'noninteractiveness': false},
        'corporatehomepageclick': {'category': "Header B2b", 'action': "Home", 'labelRequired': false, 'noninteractiveness': true},
        'corporateclientspageclick': {'category': "Header B2b", 'action': "Customers", 'labelRequired': false, 'noninteractiveness': true},
        'corporatecoursepageclick': {'category': "Header B2b", 'action': "Courses", 'labelRequired': false, 'noninteractiveness': true},
        'corporatecompetencypageclick': {'category': "Header B2b", 'action': "Why Simplilearn", 'labelRequired': false, 'noninteractiveness': true},
        'corporateleadtry': {'category': "Request Cust Quote B2b", 'action': "Try", 'labelRequired': true, 'noninteractiveness': true},
        'corporateleadsuccess': {'category': "Request Cust Quote B2b", 'action': "Success", 'labelRequired': true, 'noninteractiveness': false},
        'corporatehomeleadersclick': {'category': "b2b Home", 'action': "Loved By Leader", 'labelRequired': false, 'noninteractiveness': true},
        'corporatehomeexpertsclick': {'category': "b2b Home", 'action': "Experts in", 'labelRequired': false, 'noninteractiveness': false},
        'corporatecoursebusinesslabelclick': {'category': "B2b Course Page", 'action': "Business Category Show Detail", 'labelRequired': true, 'noninteractiveness': true},
        'corporatecoursetechlabelclick': {'category': "B2b Course Page", 'action': "Technology  Category  Show Detail", 'labelRequired': true, 'noninteractiveness': true},
        'corporatecoursebusinesscourseclick': {'category': "B2b Course Page", 'action': "Business Category Course Click", 'labelRequired': true, 'noninteractiveness': true},
        'corporatecoursetechcourseclick': {'category': "B2b Course Page", 'action': "Technology  Category  Course Click", 'labelRequired': true, 'noninteractiveness': true},
        'corporatecoursebusinesslabelclose': {'category': "B2b Course Page", 'action': "Business Category Close Detail", 'labelRequired': true, 'noninteractiveness': true},
        'corporatecoursetechlabelclose': {'category': "B2b Course Page", 'action': "Technology Category Close Detail", 'labelRequired': true, 'noninteractiveness': true},
        'corporateclientsreviewscrollright': {'category': "B2b Customer Page", 'action': "Reviews - Scroll Right", 'labelRequired': false, 'noninteractiveness': true},
        'corporateclientsreviewscrollleft': {'category': "B2b Customer Page", 'action': "Reviews - Scroll Left", 'labelRequired': false, 'noninteractiveness': true},
        'corporateclientsindustryindexclick': {'category': "B2b Customer Page", 'action': "Click Industry Alphabet", 'labelRequired': true, 'noninteractiveness': true},
        'frsArticleCommentsClick': {'category': "Free Resource - Articles", 'action': "Click Comment at Top", 'labelRequired': false, 'noninteractiveness': true},
        'frsArticleCommentsTry': {'category': "Free Resource - Articles", 'action': "Comments Try", 'labelRequired': false, 'noninteractiveness': true},
        'frsArticleCommentsSuccess': {'category': "Free Resource - Articles", 'action': "Comments Success", 'labelRequired': false, 'noninteractiveness': false},
        'frsShareTry': {'category': "Free Resource", 'action': "Share Try", 'labelRequired': true, 'noninteractiveness': true},
        'frsArticleAuthorProfileClick': {'category': "Free Resource - Articles", 'action': "Author Profile Click", 'labelRequired': true, 'noninteractiveness': true},
        'frsArticleCourseImageClick': {'category': "Free Resource - Articles", 'action': "Related Courses Click - Image", 'labelRequired': true, 'noninteractiveness': false},
        'frsArticleCourseDetailsClick': {'category': "Free Resource - Articles", 'action': "Related Courses Click - More Details", 'labelRequired': true, 'noninteractiveness': false},
        'frsArticleCourseNavClick': {'category': "Free Resource - Articles", 'action': "Related Course Click - Scroll", 'labelRequired': true, 'noninteractiveness': true},
        'frsEbookCourseImageClick': {'category': "Free Resource - Ebooks", 'action': "Related Courses Click - Image", 'labelRequired': true, 'noninteractiveness': false},
        'frsEbookCourseDetailsClick': {'category': "Free Resource - Ebooks", 'action': "Related Courses Click - More Details", 'labelRequired': true, 'noninteractiveness': false},
        'frsEbookCourseNavClick': {'category': "Free Resource - Ebooks", 'action': "Related Course Click - Scroll", 'labelRequired': true, 'noninteractiveness': true},
        'frsWebinarCourseImageClick': {'category': "Free Resource - Webinars", 'action': "Related Courses Click - Image", 'labelRequired': true, 'noninteractiveness': false},
        'frsWebinarCourseDetailsClick': {'category': "Free Resource - Webinars", 'action': "Related Courses Click - More Details", 'labelRequired': true, 'noninteractiveness': false},
        'frsWebinarCourseNavClick': {'category': "Free Resource - Webinars", 'action': "Related Course Click - Scroll", 'labelRequired': true, 'noninteractiveness': true},
        'frsVideoCourseImageClick': {'category': "Free Resource - Videos", 'action': "Related Courses Click - Image", 'labelRequired': true, 'noninteractiveness': false},
        'frsVideoCourseDetailsClick': {'category': "Free Resource - Videos", 'action': "Related Courses Click - More Details", 'labelRequired': true, 'noninteractiveness': false},
        'frsVideoCourseNavClick': {'category': "Free Resource - Videos", 'action': "Related Course Click - Scroll", 'labelRequired': true, 'noninteractiveness': true},
        'frsArticleWebinarClick': {'category': "Free Resource - Articles", 'action': "Webinar Click - Link", 'labelRequired': true, 'noninteractiveness': false},
        'frsArticleEbookClick': {'category': "Free Resource - Articles", 'action': "Ebook Click - Link", 'labelRequired': true, 'noninteractiveness': false},
        'frsArticlePopularTagClick': {'category': "Free Resource - Articles", 'action': "Popular Tag click", 'labelRequired': true, 'noninteractiveness': false},
        'frsArticleRelatedArticleSideClick': {'category': "Free Resource - Articles", 'action': "Related Article Click -From Side", 'labelRequired': true, 'noninteractiveness': false},
        'frsArticleRelatedArticleBottomClick': {'category': "Free Resource - Articles", 'action': "Related Article Click -From Bottom", 'labelRequired': true, 'noninteractiveness': false},
        'frsEbookWebinarClick': {'category': "Free Resource - Ebooks", 'action': "Webinar Click - Link", 'labelRequired': true, 'noninteractiveness': false},
        'frsEbookEbookClick': {'category': "Free Resource - Ebooks", 'action': "Ebook Click - Link", 'labelRequired': true, 'noninteractiveness': false},
        'frsEbookPopularTagClick': {'category': "Free Resource - Ebooks", 'action': "Popular Tag click", 'labelRequired': true, 'noninteractiveness': false},
        'frsEbookRelatedArticleSideClick': {'category': "Free Resource - Ebooks", 'action': "Related Article Click -From Side", 'labelRequired': true, 'noninteractiveness': false},
        'frsWebinarWebinarClick': {'category': "Free Resource - Webinars", 'action': "Webinar Click - Link", 'labelRequired': true, 'noninteractiveness': false},
        'frsWebinarEbookClick': {'category': "Free Resource - Webinars", 'action': "Ebook Click - Link", 'labelRequired': true, 'noninteractiveness': false},
        'frsWebinarPopularTagClick': {'category': "Free Resource - Webinars", 'action': "Popular Tag click", 'labelRequired': true, 'noninteractiveness': false},
        'frsWebinarRelatedArticleSideClick': {'category': "Free Resource - Webinars", 'action': "Related Article Click -From Side", 'labelRequired': true, 'noninteractiveness': false},
        'frsVideoWebinarClick': {'category': "Free Resource - Videos", 'action': "Webinar Click - Link", 'labelRequired': true, 'noninteractiveness': false},
        'frsVideoEbookClick': {'category': "Free Resource - Videos", 'action': "Ebook Click - Link", 'labelRequired': true, 'noninteractiveness': false},
        'frsVideoPopularTagClick': {'category': "Free Resource - Videos", 'action': "Popular Tag click", 'labelRequired': true, 'noninteractiveness': false},
        'frsVideoRelatedArticleSideClick': {'category': "Free Resource - Videos", 'action': "Related Article Click -From Side", 'labelRequired': true, 'noninteractiveness': false},
        'frsWebinarListRegisterTry': {'category': "Webinar List Page", 'action': "Register Try", 'labelRequired': true, 'noninteractiveness': true},
        'frsWebinarListRegisterSuccess': {'category': "Webinar List Page", 'action': "Register Success", 'labelRequired': true, 'noninteractiveness': false},
        'frsWebinarDtlRegisterSuccess': {'category': "Webinar Page", 'action': "Register Success", 'labelRequired': true, 'noninteractiveness': false},
        'frsWebinarLeadCapture': {'category': "Lead Capture", 'action': "Lead Submitted", 'labelRequired': true, 'noninteractiveness': false},
        'frsEbookDtlRegisterSuccess': {'category': "Ebook Page", 'action': "Download Success", 'labelRequired': true, 'noninteractiveness': false},
        'frsEbookLeadCapture': {'category': "Lead Capture", 'action': "Lead Submitted", 'labelRequired': true, 'noninteractiveness': false},
        'lvcpassCatFilter': {'category': "LVC_Pass", 'action': "Filter", 'labelRequired': true, 'noninteractiveness': true},
        'lvcpassKeyFeature': {'category': "LVC_Pass", 'action': "Key_features", 'labelRequired': true, 'noninteractiveness': true},
        'lvcpassTermsOfUse': {'category': "LVC_Pass", 'action': "Open Terms of use", 'labelRequired': true, 'noninteractiveness': true},
        'lvcpassPurchase': {'category': "LVC_Pass", 'action': "Purchase", 'labelRequired': true, 'noninteractiveness': true},
        'lvcpassLead': {'category': "LVC_Pass", 'action': "Lead", 'labelRequired': true, 'noninteractiveness': false},
        'subsHomePageClick' : {'category': "Home Page", 'action':"Subscription Click", 'labelRequired': true, 'noninteractiveness': false},
        'subsHomePageScroll' : {'category': "Home Page", 'action':"Subscription Scroll", 'labelRequired': true, 'noninteractiveness': false},
        'subsCourseListPage' : {'category': "Course List Page", 'action':"Subscription Click", 'labelRequired': true, 'noninteractiveness': false},
        'subsCoursePage' : {'category': "Course Page OSL", 'action':"Subscription Click", 'labelRequired': true, 'noninteractiveness': false},
        'subsSubscriptionPageStartTrial' : {'category': gaPageCategory, 'action':"Start Free Trial", 'labelRequired': true, 'noninteractiveness': false},
        'subsCourseExpand' : {'category': gaPageCategory, 'action':"Expand Course", 'labelRequired': true, 'noninteractiveness': true},
        'subskeyfeaturesClick' : {'category': gaPageCategory, 'action':"Key Features Click", 'labelRequired': true, 'noninteractiveness': true},
        'subsabouttheprogramClick' : {'category': gaPageCategory, 'action':"About Subscription Click", 'labelRequired': true, 'noninteractiveness': true},
        'subsreviewsClick' : {'category': gaPageCategory, 'action':"Click Reviews", 'labelRequired': true, 'noninteractiveness': true},
        'subsLead' : {'category': gaPageCategory, 'action':"Query Submit", 'labelRequired': true, 'noninteractiveness': true},
        'subsCartProceed' : {'category': "Subscription Cart", 'action':"Proceed to pay", 'labelRequired': false, 'noninteractiveness': true},
        'subsCartPopup' : {'category': "Subscription Cart", 'action':"Cart Message Popup", 'labelRequired': true, 'noninteractiveness': false},
        'subsCartPopupClick' : {'category': "Subscription Cart", 'action':"Cart Message Popup - Click", 'labelRequired': true, 'noninteractiveness': true},
        'subsCartFnlLand' : {'category': "Subscription Funnel", 'action':"Subscription Cart", 'labelRequired': true, 'noninteractiveness': true},
        'subsTyFunnelLand' : {'category': "Subscription Funnel", 'action':"Subscription Thank You Page", 'labelRequired': true, 'noninteractiveness': true},
        'subsCartFnlPayToProceedMsg' : {'category': "Subscription Funnel Without Free Trial", 'action':"Cart Message - Pay Now Opened", 'labelRequired': true, 'noninteractiveness': true},
        'subsCartFnlPayToProceedAct' : {'category': "Subscription Funnel Without Free Trial", 'action':"Cart Message - Subscribe Now", 'labelRequired': true, 'noninteractiveness': true},
        'subsTyFnlPaid' : {'category': "Subscription Funnel Without Free Trial", 'action':"Subscription Thank You Page", 'labelRequired': true, 'noninteractiveness': true},
        'subsTyFnlFree' : {'category': "Subscription Funnel - Free Trial", 'action':"Subscription Thank You Page", 'labelRequired': true, 'noninteractiveness': true},
        'frscoldleadformpop' : {'category': "FRS_Cold_lead", 'action':"Lead_Pop_up", 'labelRequired': true, 'noninteractiveness': true},
        'frscoldleadformpopsubmit' : {'category': "FRS_Cold_lead", 'action':"Lead_submission", 'labelRequired': true, 'noninteractiveness': true},
        'searchpagefilterclick' : {'category': "Search_result_filter", 'action':"none", 'labelRequired': true, 'noninteractiveness': true},
        'searchpagefeedclick' : {'category': "Search_result_selection", 'action':"none", 'labelRequired': true, 'noninteractiveness': true},
        'LecturePage_Watch_Course_Video' : {'category': "Lecture Page", 'action':"Watch Course Video", 'labelRequired': false, 'noninteractiveness':true},
        'LecturePage_View_Course_Detail' : {'category': "Lecture Page", 'action':"View Course Detail", 'labelRequired': true, 'noninteractiveness':false},
        'LecturePage_Click_Related_Course' : {'category': "Lecture Page", 'action':"Click Related Course", 'labelRequired': true, 'noninteractiveness':false},
        'LecturePage_Click_Webinar' : {'category': "Lecture Page", 'action':"Click Webinar", 'labelRequired': true, 'noninteractiveness':false},
        'LecturePage_Click_Related_Article' : {'category': "Lecture Page", 'action':"Click Related Article", 'labelRequired': true, 'noninteractiveness':false},
        'LecturePage_Click_Other_Chapter' : {'category': "Lecture Page", 'action':"Click Other Chapter", 'labelRequired': true, 'noninteractiveness':false},
        'LecturePage_Scroll_Related_Course' : {'category': "Lecture Page", 'action':"Scroll Related Course", 'labelRequired': true, 'noninteractiveness':true},
        'LecturePage_Scroll_Learner_Review' : {'category': "Lecture Page", 'action':"Scroll Learner Review", 'labelRequired': true, 'noninteractiveness':true},
        'LecturePage_Scroll_Webinar' : {'category': "Lecture Page", 'action':"Scroll Webinar", 'labelRequired': true, 'noninteractiveness':true},
        'LecturePage_Scroll_Related_Article' : {'category': "Lecture Page", 'action':"Scroll Related Article", 'labelRequired': true, 'noninteractiveness':true},
        'LecturePage_Click_Reviewer_Prfile' : {'category': "Lecture Page", 'action':"Click Reviewer Prfile", 'labelRequired': true, 'noninteractiveness':true},
        'LecturePage_Expand_Topic' : {'category': "Lecture Page", 'action':"Expand Topic", 'labelRequired': true, 'noninteractiveness':true},
        'LecturePage_Collapse_Topic' : {'category': "Lecture Page", 'action':"Collapse Topic", 'labelRequired': true, 'noninteractiveness':true},
        'LecturePage_Is_it_helpful' : {'category': "Lecture Page", 'action':"Is it helpful", 'labelRequired': true, 'noninteractiveness':true},
        'LecturePage_View_Topic_Video' : {'category': "Lecture Page", 'action':"View Topic Video", 'labelRequired': true, 'noninteractiveness':true},
        'LecturePage_Click_Course_Detail_from_Video' : {'category': "Lecture Page", 'action':"Click Course Detail from Video", 'labelRequired': true, 'noninteractiveness':false},
        'LecturePage_transcript_click_icon':{'category': "Course Preview Page", 'action':"Click on transcript icon", 'labelRequired': false, 'noninteractiveness':false},
        'LecturePage_transcript_popup':{'category': "Course Preview Page", 'action':"Transcript Popup close", 'labelRequired': false, 'noninteractiveness':false},
        'CoursePreview_LectPage_accordian_open':{'category': "Course Preview Page", 'action':"Lecture Page accordian open", 'labelRequired': true, 'noninteractiveness':false},
        'onloadSubsPageType':{'category': "Subscription_funnel", 'action':"Page load", 'labelRequired': true, 'noninteractiveness':true},
        'onloadBundlePageType':{'category': "Bundle_funnel", 'action':"Page load", 'labelRequired': true, 'noninteractiveness':true},
        'startFreeTrail':{'category': "Subscription_funnel", 'action':"Start free trial", 'labelRequired': true, 'noninteractiveness':false},
        'proceedToPayPal':{'category': "Subscription_funnel", 'action':"Proceed to pay with Paypal", 'labelRequired': true, 'noninteractiveness':false},
        'changeSubsMPlan':{'category': "Subscription Page", 'action':"change to annual plan", 'labelRequired': true, 'noninteractiveness':false},
        'changeSubsAPlan':{'category': "Subscription Page", 'action':"change to monthly plan", 'labelRequired': true, 'noninteractiveness':false},
        'lvcFireOnload':{'category': "lvcpass_funnel", 'action':"Page load", 'labelRequired': true, 'noninteractiveness':true},
        'OnPorceedClick':{'category': "lvcpass_funnel", 'action':"Add to cart", 'labelRequired': true, 'noninteractiveness':false},
        'OnPorceedBundleClick':{'category': "Bundle_funnel", 'action':" Proceed to payment page", 'labelRequired': true, 'noninteractiveness':false},
        'OnPorceedLvcPassClick':{'category': "lvcpass_funnel", 'action':"Proceed to payment page", 'labelRequired': true, 'noninteractiveness':false},
        'paymentSuccesssubc':{'category': "Subscription_funnel", 'action':"Successful enrollment", 'labelRequired': true, 'noninteractiveness':false},
        'coursePageABTestingHover' : {'category': "ab testing", 'action':"onhover", 'labelRequired': false, 'noninteractiveness':false},
        'coursePageABTestingClick' : {'category': "ab testing", 'action':"onclickspecialoffer", 'labelRequired': false, 'noninteractiveness':false},
        'cCallClose' : {'category': "Click 2 Call US", 'action':"Popup Close", 'labelRequired': true, 'noninteractiveness':false},
        'cCallLogged' : {'category': "Click 2 Call US", 'action':"Popup open loggedin user", 'labelRequired': true, 'noninteractiveness':false},
        'cCallNotLogged' : {'category': "Click 2 Call US", 'action':"Popup open not loggedin user", 'labelRequired': true, 'noninteractiveness':false},
        'cCallBtn' : {'category': "Click 2 Call US", 'action':"Clicked on Call Btn", 'labelRequired': true, 'noninteractiveness':false},
        'course_agenda' : {'category': "Course Agenda", 'action':"click on download", 'labelRequired': true, 'noninteractiveness':true},
        'no_cost_emi' : {'category': "no cost emi popup", 'action':"Lead form Clicked", 'labelRequired': true, 'noninteractiveness':true},
        'ec_council_notify_me': {'category': "Course Page EC Council", 'action': "click on Notify Me", 'labelRequired': true, 'noninteractiveness': true},
        'pre_run': {'category': "Course Page Generic", 'action': "click on pre run video", 'labelRequired': false, 'noninteractiveness': true},
        'flexi_pass': {'category': "Course Page Generic", 'action': "click on flexi pass video", 'labelRequired': false, 'noninteractiveness': true},
        'CoursePreviewIntrovideoClick': {'category': "Course Page Generic", 'action': "click on course preview from intro video", 'labelRequired': true, 'noninteractiveness': false},
        'RE_view_TC': {'category': "RE_view_TC", 'action': "user clicks on the T&C link", 'labelRequired': false, 'noninteractiveness': false},
        'rf_social_channel': {'category': "R&E_initiated_Referral_via_social_channel", 'action': "social sharing option", 'labelRequired': true, 'noninteractiveness': false},
        'Referral_via_Email_Import_Click': {'category': "R&E_initiates_Referral_via_Email", 'action': "clicks on email import", 'labelRequired': true, 'noninteractiveness': false},
        'Referral_via_Email_Import_Submit': {'category': "R&E_initiates_Referral_via_Email", 'action': "clicks on submit while using email import", 'labelRequired': true, 'noninteractiveness': false},
        'RE_CopyLink': {'category': "R&E_CopyLink", 'action': "Click on Copy Link", 'labelRequired': false, 'noninteractiveness': false},
        'Re_ini_Email': {'category': "R&E_initiates_Referral_via_Email", 'action': "User attempts to enter email addresses", 'labelRequired': false, 'noninteractiveness': false},
        'Re_comp_Email': {'category': "R&E_completes_Referral_via_Email", 'action': "The user completes inviting friends via email", 'labelRequired': false, 'noninteractiveness': false},
        'Re_initiated_Login': {'category': "R&E_initiated_Login", 'action': "Initiated email login", 'labelRequired': false, 'noninteractiveness': false},
        'Re_submit_Email': {'category': "R&E_submit_Email", 'action': "Submitted email login", 'labelRequired': true, 'noninteractiveness': false},
        'FreePracticeTest': {'category': "Free Practice Test", 'action': "FPT Name", 'labelRequired': true, 'noninteractiveness': false},
        'Cp_contact_us_Click': {'category': "Enterprise_Enroll_Card", 'action': "User clicks on Contact Us", 'labelRequired': true, 'noninteractiveness': false},
        'Cp_Enterprise_Form_Open': {'category': "Enterprise_Enroll_Card", 'action': "Enterprise form pop up opens", 'labelRequired': true, 'noninteractiveness': false},
        'Cp_LearnersRangePricing_OSL_Modal_Open': {'category': "CP B2b Learners Range Pricing Modal for OSL", 'action': "CP B2b Learners Range Pricing Modal Open", 'labelRequired': true, 'noninteractiveness': false},
        'Cp_LearnersRangePricing_LVC_Modal_Open': {'category': "CP B2b Learners Range Pricing Modal for LVC", 'action': "CP B2b Learners Range Pricing Modal Open", 'labelRequired': true, 'noninteractiveness': false},
        'Cp_User_Fills_Marketo_Form': {'category': "Enterprise_Enroll_Card", 'action': "User initiates filling the marketo form", 'labelRequired': true, 'noninteractiveness': false},
        'Cp_User_Submits_Marketo_Form': {'category': "Enterprise_Enroll_Card", 'action': "User submits the marketo form", 'labelRequired': true, 'noninteractiveness': false},
        'Cp_User_Clicks_Enterprise_Tab': {'category': "Course Page B2B Query Drop", 'action': "User clicks on Enterprise Tab", 'labelRequired': true, 'noninteractiveness': false},
        'Cp_User_Fills_Enterprise_Form': {'category': "Course Page B2B Query Drop", 'action': "User initiates filling the enterprise form", 'labelRequired': true, 'noninteractiveness': false},
        'Cp_User_Submits_Enterprise_Form': {'category': "Course Page B2B Query Drop", 'action': "User submits the enterprise form", 'labelRequired': true, 'noninteractiveness': false},
        'Course_callus_click': {'category': "Course Page Mobile Sticky footer", 'action': "Click on Call Us button", 'labelRequired': true, 'noninteractiveness': false},
        'Course_chat_click': {'category': "Course Page Mobile Sticky footer", 'action': "Click on Chat button", 'labelRequired': true, 'noninteractiveness': false},
        'Course_query_click': {'category': "Course Page Mobile Sticky footer", 'action': "Click on Query button", 'labelRequired': true, 'noninteractiveness': false},
        'Category_video_click': {'category': "Category Page", 'action': "Video Clicked to view", 'labelRequired': true, 'noninteractiveness': false},
        'Category_modal_closed': {'category': "Category Page", 'action': "Video modal closed", 'labelRequired': true, 'noninteractiveness': false},
        'Category_advisor_scroll_left': {'category': "Category Page", 'action': "Course Advisor Section Scrolled Left", 'labelRequired': true, 'noninteractiveness': false},
        'Category_advisor_scroll_right': {'category': "Category Page", 'action': "Course Advisor Section Scrolled Right", 'labelRequired': true, 'noninteractiveness': false},
        'Category_alumni_social_click': {'category': "Category Page", 'action': "User views Alumnus LinkedIn Profile", 'labelRequired': true, 'noninteractiveness': false},
        'Category_individuals_tab_click': {'category': "Category Page", 'action': "User clicks on For Individuals tab to see form", 'labelRequired': true, 'noninteractiveness': false},
        'Category_business_tab_click': {'category': "Category Page", 'action': "User clicks on For Business tab to see form", 'labelRequired': true, 'noninteractiveness': false},
        'Category_form_filled': {'category': "Category Page", 'action': "User intiates the step of filling Individuals form", 'labelRequired': true, 'noninteractiveness': false},
        'Category_course_card_click': {'category': "Category Page", 'action': "Course Card clicked", 'labelRequired': true, 'noninteractiveness': false},
        'Category_master_program_click': {'category': "Category Page", 'action': "Masters Program card clicked", 'labelRequired': true, 'noninteractiveness': false},

        'SemCoursePageTabViewMoreClick':{'category': "Engagement", 'action': "User clicks on View More in the course tabs", 'labelRequired': true, 'noninteractiveness': true},
        'SemCoursePageTabClick':{'category': "Engagement", 'action': "User clicks on course tabs", 'labelRequired': true, 'noninteractiveness': true},
        'SemCourseTestimonialClick':{'category': "Engagement", 'action': "User clicks Testimonials", 'labelRequired': true, 'noninteractiveness': true},
        'SemCourseShowMoreReviews': {'category': "Engagement", 'action': "User clicks View all Testimonials", 'labelRequired': true, 'noninteractiveness': true},
        'SemCourseForm2LeadSubmit': {'category': "Lead Capture", 'action': "Lead Submitted", 'labelRequired': true, 'noninteractiveness': true},
        'SemCourseForm2Click': {'category': "Lead Capture", 'action': "Lead form Clicked", 'labelRequired': true, 'noninteractiveness': true},
        'SemCourseTestimonialReadMore':{'category': "Engagement", 'action': "Read more of Testimonial clicked", 'labelRequired': true, 'noninteractiveness': true},
        'SemBundleShowMoreCourseInLearningPath':{'category': "Engagement", 'action': "Show More Courses Link clicked", 'labelRequired': true, 'noninteractiveness': true},
        'SemBundleShowLessCourseInLearningPath':{'category': "Engagement", 'action': "Show Less Courses Link clicked", 'labelRequired': true, 'noninteractiveness': true},
        'SemCourseAdvisoryExplore':{'category': "Engagement", 'action': "User explores course advisor section", 'labelRequired': true, 'noninteractiveness': false},
        
         //Home Page Ga Events
        'homepageQuickLinkClick':{'category': "Navigation", 'action': "Quick Link", 'labelRequired': true, 'noninteractiveness': false},
        'homepageExploreAll':{'category': "Navigation",     'action': "Explore all Courses clicked", 'labelRequired': true, 'noninteractiveness': false},
        'homepageCourseToogle':{'category': "Engagement",   'action': "Course Toggle clicked", 'labelRequired': true, 'noninteractiveness': false},
        'homepageWhatsNewClick':{'category': "Engagement",  'action': "Whats new section clicked", 'labelRequired': true, 'noninteractiveness': false},
        'homepageCorporateLearnMoreClick':{'category': "Navigation", 'action': "Corporate Training - Learn More clicked", 'labelRequired': true, 'noninteractiveness': false},
        'dobubleNavClickedGeneric':{'category': "Navigation", 'action': "Double Nav clicked", 'labelRequired': true, 'noninteractiveness': false},
        'homepageMasterCardClick':{'category': "Navigation", 'action': "Master Course Card Click", 'labelRequired': true, 'noninteractiveness': false},
        'myCourseClickGeneric':{'category': "Engagement", 'action': "My courses clicked", 'labelRequired': true, 'noninteractiveness': false},
        'onLogoutClickGeneric':{'category': "Engagement", 'action': "Logout clicked", 'labelRequired': true, 'noninteractiveness': false},

        //GSA Page Ga Events
         'gsapageViewMoreTestimonials': {'category': "Navigation", 'action': "View More Testimonials", 'labelRequired': true, 'noninteractiveness': false},
        //GDPR Optin Checkbox Ga Events
         'gdprOptinCheckboxChecked':{'category': "Engagement", 'action': "Click on Consent check box", 'labelRequired': true, 'noninteractiveness': false},

         //Master no cost emi Ga events
         'masterNoCostEmiTabClick' : {'category': "no cost emi popup", 'action': "Tab clicked", 'labelRequired': true, 'noninteractiveness': false},

         'sl_eng_category_faq_view_more_clicked': {'category': "Engagement", 'action': "View more FAQ Questions clicked", 'labelRequired': true, 'noninteractiveness': false},
    };

    this.init = function () {
        var overAllFunnelTrigger = this.logicForOverAllFunnelTrigger();
        if (overAllFunnelTrigger.trigger == true) {
            this.triggerOverAllFunnel(overAllFunnelTrigger);
        }
        var classRoomFunnelTrigger = this.logicForClassRoomFunnelTrigger();
        if (classRoomFunnelTrigger.trigger == true) {
            this.triggerClassRoomFunnel(classRoomFunnelTrigger);
        }
        var onlineFunnelTrigger = this.logicForOnlineFunnelTrigger();
        if (onlineFunnelTrigger.trigger == true) {
            this.triggerOnlineFunnel(onlineFunnelTrigger);
        }
        this.gaFireOnCoursePage();
        this.gaFireOnCoursePageNoWorkshop();
        this.gaFireOnCourseListSearchTagDetect();
        this.fireDataLayerAdElement();
    }
    this.logicForOverAllFunnelTrigger = function () {
        var args = new Array();
        args.isArray = false;
        args.trigger = false;

        if (user_params.overAllDataIsArrayForGa == true) {
            var argumentArray = user_params.overAllDataForGa;
            args = this.forEachInFunnelTriggers(argumentArray, args, 'overAllPage');
            console.log(args);
            args.isArray = true;
        } else {
            args.funnelAction = user_params.overAllPageActionForGa;
            args.label = user_params.overAllPageLabelForGa;
            args.value = user_params.overAllPageValueForGa;
            if (args.funnelAction != '' || args.label != '' || args.value != '') {
                args.trigger = true;
            }
        }
        return args;
    }
    this.logicForClassRoomFunnelTrigger = function () {
        var args = new Array();
        args.isArray = false;
        args.trigger = false;

        if (user_params.classRoomDataIsArrayForGa == true) {
            var argumentArray = user_params.classRoomDataForGa;
            args = this.forEachInFunnelTriggers(argumentArray, args, 'classRoomPage');
            args.isArray = true;
        } else {
            args.funnelAction = user_params.classRoomPageActionForGa;
            args.label = user_params.classRoomPageLabelForGa;
            args.value = user_params.classRoomPageValueForGa;
            if (args.funnelAction != '' || args.label != '' || args.value != '') {
                args.trigger = true;
            }
        }
        return args;
    }
    this.logicForOnlineFunnelTrigger = function () {
        var args = new Array();
        args.isArray = false;
        args.trigger = false;

        if (user_params.onlineDataIsArrayForGa == true) {
            var argumentArray = user_params.onlineDataForGa;
            args = this.forEachInFunnelTriggers(argumentArray, args, 'onlinePage');
            args.isArray = true;
        } else {
            args.funnelAction = user_params.onlinePageActionForGa;
            args.label = user_params.onlinePageLabelForGa;
            args.value = user_params.onlinePageValueForGa;
            if (args.funnelAction != '' || args.label != '' || args.value != '') {
                args.trigger = true;
            }
        }
        return args;
    }
    this.gaEventsFireForError = function () {
        var args = new Array();
        args.trigger = true;
        args.funnelString = 'Error';
        args.funnelAction = user_params.codeForGa;
        args.label = user_params.referralUrl;
        args.value = user_params.message;
        this.triggerCustomFunnel(args);
    }
    this.gaFireOnCoursePage = function () {
        if (user_params.genericCoursePageStringForGa) {
            if (window.location.hash != '#/ilt' && window.location.hash != '#/osl') {
                var args = new Array();
                args.trigger = true;
                args.funnelString = this.overAllFunnelString;
                args.funnelAction = user_params.genericCoursePageStringForGa;
                args.label = user_params.codeForGa;
                args.value = 'send-url';
                this.triggerCustomFunnel(args);
            }
        }
    }
    this.gaFireOnCoursePageNoWorkshop = function () {
        if (user_params.noWorkshopFoundFunnelActivate) {
            var args = new Array();
            args.trigger = true;
            args.funnelString = this.noWorkshopFoundFunnel;
            args.funnelAction = user_params.noWorkshopFoundAction;
            args.label = user_params.noWorkshopFoundLabel;
            args.value = '';
            this.triggerCustomFunnel(args);
        }
    }
    this.gaFireOnCoursePageNoWorkshopFormSubmit = function () {
        var args = new Array();
        args.trigger = true;
        args.funnelString = this.noWorkshopFoundFunnel;
        args.funnelAction = 'Form Submit';
        args.label = user_params.noWorkshopFoundLabel;
        args.value = '';
        args.noninteractiveness = false;
        this.triggerCustomFunnel(args);
    }
    this.gaFireOnCourseListSearchTagDetect = function () {
        var keyword = user_params.gaTagForPage;
        if (user_params.overAllPageLabelForGa == 'search') {
            if (document.getElementsByClassName('list_li').length > 0) {
                this.gaFireInteractiveEvents('crosseventssearchlist', keyword);
            } else {
                this.gaFireInteractiveEvents('crosseventssearchnoresult', keyword);
            }
        }
    }
    this.gaFireOnCourseListSearchTagCounter = function (rank) {

        var keyword = user_params.gaTagForPage;
        if (user_params.overAllPageLabelForGa == 'search') {
            this.gaFireInteractiveEvents('crosseventssearchclickresult', keyword + ' | ' + rank);
        }
    }
    this.gaFireOnCartPageInvalidCouponSubmit = function (invalidCouponLabel) {
        this.gaFireOnCartPageInvalidCouponSubmit(invalidCouponLabel);
    }
    this.gaFireInteractiveEvents = function (keyInRedmineArray, label) {
        this.gaFireInteractiveEvents(keyInRedmineArray, label);
    }
    this.gaFireOnCartProceedClick = function () {
        if (typeof user_params.overAllDataForGa[0] != 'undefined' && typeof user_params.overAllDataForGa[0]['overAllPageActionForGa'] != 'undefined' && typeof user_params.overAllDataForGa[0]['overAllPageLabelForGa'] != 'undefined' && user_params.overAllDataForGa[0]['overAllPageActionForGa'] == 'Cart Page') {
            this.gaFireInteractiveEvents('cartpageproceedtopay', user_params.overAllDataForGa[0]['overAllPageLabelForGa']);
        }
    }
    this.triggerOverAllFunnel = function (args) {
        if (args.trigger) {
            temp = new Array();
            if (args.isArray) {
                for (var i = 0; typeof args[i] != 'undefined'; i++) {
                    if (!isNaN(args[i].value) && (args[i].value === 0 || args[i].value > 0)) {
                        var value = args[i].value;
                    } else {
                        var value = 0;
                    }
                    temp.push(['_trackEvent', this.overAllFunnelString, args[i].funnelAction, args[i].label, value, true]);
                    _gaq.push(['_trackEvent', this.overAllFunnelString, args[i].funnelAction, args[i].label, value, true]);
                }
            } else {
                if (!isNaN(args.value) && (args.value === 0 || args.value > 0)) {
                    var value = args.value;
                } else {
                    var value = 0;
                }
                temp.push(['_trackEvent', this.overAllFunnelString, args.funnelAction, args.label, value, true]);
                _gaq.push(['_trackEvent', this.overAllFunnelString, args.funnelAction, args.label, value, true]);
            }
            if (printGaInConsole) {
                console.log(temp);
            }
        }
    }
    this.triggerCustomFunnel = function (args) {
        if (args.trigger) {
            temp = new Array();
            if (args.isArray) {
                for (var i = 0; typeof args[i] != 'undefined'; i++) {
                    if (!isNaN(args[i].value) && (args[i].value === 0 || args[i].value > 0)) {
                        var value = args[i].value;
                    } else {
                        var value = 0;
                    }
                    var noninteractiveness = true;
                    if (typeof args[i].noninteractiveness != 'undefined' && (args[i].noninteractiveness == true || args[i].noninteractiveness == false)) {
                        noninteractiveness = args[i].noninteractiveness;
                    }
                    _gaq.push(['_trackEvent', args[i].funnelString, args[i].funnelAction, args[i].label, value, noninteractiveness]);
                    temp.push(['_trackEvent', args[i].funnelString, args[i].funnelAction, args[i].label, value, noninteractiveness]);
                }
            } else {
                if(args.value == 'send-url'){
                    var value = document.URL;
                }
                else if (!isNaN(args.value) && (args.value === 0 || args.value > 0)) {
                    var value = args.value;
                } else {
                    var value = 0;
                }
                var noninteractiveness = true;
                if (typeof args.noninteractiveness != 'undefined' && (args.noninteractiveness == true || args.noninteractiveness == false)) {
                    noninteractiveness = args.noninteractiveness;
                }
                temp.push(['_trackEvent', args.funnelString, args.funnelAction, args.label, value, noninteractiveness]);
                _gaq.push(['_trackEvent', args.funnelString, args.funnelAction, args.label, value, noninteractiveness]);
            }
            if (printGaInConsole) {
                console.log(temp);
            }
        }
    }
    this.triggerClassRoomFunnel = function (args) {
        if (args.trigger) {
            tempClass = new Array();
            if (args.isArray) {
                for (var i = 0; typeof args[i] != 'undefined'; i++) {
                    if (!isNaN(args[i].value) && (args[i].value === 0 || args[i].value > 0)) {
                        var value = args[i].value;
                    } else {
                        var value = 0;
                    }
                    _gaq.push(['_trackEvent', this.classRoomFunnelString, args[i].funnelAction, args[i].label, value, true]);
                    tempClass.push(['_trackEvent', this.classRoomFunnelString, args[i].funnelAction, args[i].label, value, true]);
                }
            } else {
                if (!isNaN(args.value) && (args.value === 0 || args.value > 0)) {
                    var value = args.value;
                } else {
                    var value = 0;
                }
                tempClass.push(['_trackEvent', this.classRoomFunnelString, args.funnelAction, args.label, value, true]);
                _gaq.push(['_trackEvent', this.classRoomFunnelString, args.funnelAction, args.label, value, true]);
            }
            if (printGaInConsole) {
                console.log(tempClass);
            }
        }
    }
    this.triggerOnlineFunnel = function (args) {
        if (typeof args.trigger != 'undefined' && args.trigger) {
            tempOnline = new Array();
            if (typeof args.isArray != 'undefined' && args.isArray) {
                for (var i = 0; typeof args[i] != 'undefined'; i++) {
                    if (!isNaN(args[i].value) && (args[i].value === 0 || args[i].value > 0)) {
                        var value = args[i].value;
                    } else {
                        var value = 0;
                    }
                    _gaq.push(['_trackEvent', this.onlineFunnelString, args[i].funnelAction, args[i].label, value, true]);
                    tempOnline.push(['_trackEvent', this.onlineFunnelString, args[i].funnelAction, args[i].label, value, true]);
                }
            } else {
                if (!isNaN(args.value) && (args.value === 0 || args.value > 0)) {
                    var value = args.value;
                } else {
                    var value = 0;
                }

                tempOnline.push(['_trackEvent', this.onlineFunnelString, args.funnelAction, args.label, value, true]);
                _gaq.push(['_trackEvent', this.onlineFunnelString, args.funnelAction, args.label, value, true]);
            }
            if (printGaInConsole) {
                console.log(tempOnline);
            }
        }
    }
    this.eventsOverallOnTrainingType = function (courseType) {
        var args = new Array();
        args.trigger = true;
        args.funnelAction = 'Training Type';
        args.label = courseType;
        args.value = '';
        this.triggerOverAllFunnel(args);
    }

    this.eventsClassRoomOnTrainingType = function () {
        var args = new Array();
        args.trigger = true;
        args.funnelAction = 'Course Page';
        args.label = course_name;
        args.value = '';
        this.triggerClassRoomFunnel(args);
    }

    this.eventsOnlineOnTrainingType = function () {
        if(gaPageCategory == ''){
            var args = new Array();
            args.trigger = true;
            args.funnelAction = 'Course Page';
            args.label = course_name;
            args.value = '';
            this.triggerOnlineFunnel(args);
        }
    }

    this.gaFireOnCartPageInvalidCouponSubmit = function (invalidCouponLabel) {

        var args = new Array();
        args.trigger = true;
        args.funnelString = this.invalidCoupon;
        args.funnelAction = 'Invalid Coupon';
        args.label = invalidCouponLabel;
        args.value = '';
        this.triggerCustomFunnel(args);
    }

    this.gaFireInteractiveEvents = function (keyInRedmineArray, label, action) {
        var args = new Array();
        args.trigger = true;
        if(typeof this.eventsRedmine1094[keyInRedmineArray] === "undefined" || !this.eventsRedmine1094[keyInRedmineArray]) {
            console.warn("SL:Warn - gaFireInteractiveEvents > undefined eventsRedmine1094", keyInRedmineArray);
            return;
        }
        args.funnelString = this.eventsRedmine1094[keyInRedmineArray].category;
        if(typeof action != "undefined") {
            args.funnelAction = action;
        } else {
            args.funnelAction = this.eventsRedmine1094[keyInRedmineArray].action;
        }
        args.label = '';
        if (this.eventsRedmine1094[keyInRedmineArray].labelRequired == true) {
            if (typeof this.eventsRedmine1094[keyInRedmineArray].labelValue != 'undefined') {
                label = this.eventsRedmine1094[keyInRedmineArray].labelValue;
            }
            if (typeof label == 'undefined') {
                if (printGaInConsole) {
                    console.log('label not proper for ' + keyInRedmineArray);
                }
            }
            args.label = label;
        }

        if (this.eventsRedmine1094[keyInRedmineArray].labelRequired == false && typeof label != 'undefined') {
            if (printGaInConsole) {
                console.log('label not proper for ' + keyInRedmineArray);
            }
        }
        args.value = '';
        args.noninteractiveness = this.eventsRedmine1094[keyInRedmineArray].noninteractiveness;
        this.triggerCustomFunnel(args);
    }

    this.forEachInFunnelTriggers = function (argumentArray, args, keyString) {

        for (var i = 0; typeof argumentArray[i] != 'undefined'; i++) {

            var temp = new Array();
            if (typeof argumentArray[i][keyString + 'ActionForGa'] != 'undefined') {
                args.trigger = true;
                temp['funnelAction'] = argumentArray[i][keyString + 'ActionForGa'];
            } else {
                temp['funnelAction'] = '';
            }

            if (typeof argumentArray[i][keyString + 'LabelForGa'] != 'undefined') {
                args.trigger = true;
                temp['label'] = argumentArray[i][keyString + 'LabelForGa'];
            } else {
                temp['label'] = '';
            }

            if (typeof argumentArray[i][keyString + 'ValueForGa'] != 'undefined') {
                args.trigger = true;
                temp['value'] = argumentArray[i][keyString + 'ValueForGa'];
            } else {
                temp['value'] = '';
            }

            args.push(temp);
        }
        return args;
    }

    this.fireDataLayerAdElement = function () {
        if (typeof user_params.adElementData != 'undefined' && user_params.adElementData.length > 0) {

            setTimeout(function () {
                timeoutForAdElement = 0;
                var adElementPushToDataLayer = function (adData, timeout) {
                    if (typeof dataLayer == 'undefined') {
                        dataLayer = [];
                    }
                    setTimeout(function() {
                        if(printGaInConsole) {
                            console.log(adData);
                        }
                        dataLayer.push(adData);
                    }, timeout);
                }
                for (adData in user_params.adElementData) {
                    if (user_params.adElementDataCoursePage) {
                        if (window.location.hash == '#/ilt') {
                            var adElementTrainingType = 'classroom';
                        } else if (window.location.hash == '#/osl') {
                            var adElementTrainingType = 'online';
                        } else {
                            var adElementTrainingType = 'either';
                        }
                    }
                    if (typeof user_params.adElementData[adData].event != 'undefined' && typeof user_params.adElementData[adData].depth != 'undefined') {
                        var temp = new Object();
                        for (key in user_params.adElementData[adData]) {
                            temp[key] = user_params.adElementData[adData][key];
                        }
                        if (user_params.adElementDataCoursePage) {
                            temp.trainingType = adElementTrainingType;
                        }
                        adElementPushToDataLayer(temp, timeoutForAdElement);
                        timeoutForAdElement +=500;
                    }
                }
                ;
            }
            , 5000
                    );
        }
    }
}
