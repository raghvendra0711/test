angular.module('Simplilearn')
.controller('LvcPassController', function($sce, $http, $interval,$timeout, $rootScope,$window, $scope){    
    var self = this;
    
    self.paginationRequestParams = {},

    self.pagedCourses = new Array(),
    self.currentLabelId = 0,
    self.showLoadMore = 1,
    self.catChangedFlag = 0;
    self.catChangeErr = '';
    self.pauseTimer = 0;
    self.tabIndexCount=0;
    self.isCatRequestPending=0;
    self.showBatchesDiv = 0;
    self.getBatchesRequestPending = 0;
    self.batchesArr = {};
    self.currentCourseBatch = {};
    self.maxBatchCount=4;
    self.batchViewMoreVisible=1;
    self.countryName = '';
    self.topErrMsg ='';
    self.batchesStatusMsg = "Loading...";
    self.baseUrl = baseUrl;
    self.helpers = new helpers();
    self.loadMoreCoursesApiUrl = '';
    
    var passId = null,
    pageSize = 10;
    
    self.initData = function(pPassId, pPageSize, pShowLoadMore) {
        passId = pPassId;
        pageSize = pPageSize;
        self.showLoadMore = pShowLoadMore;
        self.currentLabelId = '{"key":"0","value":"All Categories"}';
        var currentLabel = JSON.parse(self.currentLabelId);
        self.paginationRequestParams['pass_id'] = passId;
        self.paginationRequestParams['label_id'] = currentLabel.key;
        var urlObj = self.helpers.makeValidApiUrl('loadPassCourses');
        self.loadMoreCoursesApiUrl = urlObj.url;
        
        if(isMobile != 1){
            var timerId = $interval(function() {
                if(self.pauseTimer == 0){
                    self.changeTab(self.tabIndexCount);
                    if(self.tabIndexCount < 3){
                        self.tabIndexCount++;
                    }else{
                        self.tabIndexCount = 0;
                    }
                }

            }, 3000);
        }else{
            self.tabIndexCount = -1;
        }
        
        var locatorCookie = getCookieByName('locatori9');
	var locatorCookieObj = JSON.parse(locatorCookie);
        self.countryName = locatorCookieObj.country_name;
        self.topErrMsg = 'The pass is not available in your country';
        if(self.baseUrl.charAt(self.baseUrl.length-1) == '/'){
            self.baseUrl = self.baseUrl.substring(0,self.baseUrl.length-1);
        }
        
        document.onkeydown = function (event) {
            if(event.keyCode == 27 && self.lvcVideoDisplayStatus.display!='none'){
                self.lvcVideoDisplayStatus.display='none';
                lvcVid.stop();
                document.getElementById("lvc_vid_div").innerHTML = "";
            }
        };
        self.ga.gaOnloadLvc();
    };
    
    $scope.$watch('hybridWidthFlag', function(newValue) {
        var benefitsUl = (document.getElementsByClassName("benifits_wrap big_font")[0]).getElementsByTagName("ul");
        var liObjs = benefitsUl[0].getElementsByTagName("li");
        var liObjsLen = liObjs.length;
        
        if (newValue == 1) {
            self.pauseTimer = 1;
            for(var i=0;i<liObjsLen;i++){
                liObjs[i].className = liObjs[i].className.replace("lvc_active_btn");
                liObjs[i].className = liObjs[i].className.replace(" ","");
                var divObj = liObjs[i].getElementsByTagName("div");
                divObj[0].className = "benifit_panel height_transition hidden_cls";
            }
            
        } else {
            self.pauseTimer = 0;
            for(var i=0;i<liObjsLen;i++){
                liObjs[i].className = liObjs[i].className.replace("lvc_active_btn");
                liObjs[i].className = liObjs[i].className.replace(" ","");
                var divObj = liObjs[i].getElementsByTagName("div");
                divObj[0].className = "benifit_panel opacity_transition with-opacity";
            }
            
        }
    });
    
    self.to_trusted = function(pHtml) {
        return $sce.trustAsHtml(pHtml);
    };
    
    self.initCategory = function(pKey, pVal) {
        self.currentLabelId = '{"key":"'+pKey+'","value":"'+pVal+'"}';
        var currentLabel = JSON.parse(self.currentLabelId);
        self.paginationRequestParams['label_id'] = currentLabel.key;
    };
    
    self.catChangeAction = function() {
        self.currentLabelId = JSON.parse(self.currentLabelId);
        var reqParams = {};
        self.paginationRequestParams['label_id'] = self.currentLabelId.key;
        
        reqParams['additionalSkip'] = 0;
        reqParams['pageSize'] = pageSize;
        reqParams['currPage'] = 0;
        reqParams['pass_id'] = passId;
        reqParams['label_id'] = self.currentLabelId.key;
        
        var loadMoreCopy = self.showLoadMore;
        self.showLoadMore = 0;
        self.isCatRequestPending=1;
        self.catChangeErr = '';
        self.ga.gaFireEventsGeneric('lvcpassCatFilter',self.currentLabelId.value);
        var urlObj = self.helpers.makeValidApiUrl('loadPassCourses');
        $http.get( urlObj.url, { params:reqParams, cache:urlObj.cached } )
        .success(function(data) {
            self.isCatRequestPending=0;
            if( data.status == 'success' && typeof data.content !== 'undefined' ) {
                self.catChangedFlag = 1;
                self.pagedCourses = new Array();
        
                for( var prop in data.content ) {
                    self.pagedCourses.push(data.content[prop]);
                }
                
                if( data.content.length < pageSize ) {
                    self.showLoadMore = 0;
                } else {
                    self.showLoadMore = 1;                        
                }
            }
            else {
                self.showLoadMore = loadMoreCopy;
                self.catChangeErr = 'Some error occurred. Please try again later.';
                hideCatChangeErr();
            }
        })
        .error(function() {
            self.showLoadMore = loadMoreCopy;
            self.catChangeErr = 'Some error occurred. Please try again later.';                        
            hideCatChangeErr();
        });
        self.currentLabelId = JSON.stringify(self.currentLabelId);
    };
    
    var hideCatChangeErr = function() {
        $timeout(function(){
            self.catChangeErr = '';
        },3000);
    };
    var batchDivObj = null;
    self.getBatches = function(e,pCourseId) {
        e.preventDefault();
        self.getBatchesRequestPending = 1;
        self.batchesStatusMsg = "Loading...";
        self.maxBatchCount=4;
        if(typeof self.batchesArr[pCourseId] == 'undefined'){
            self.batchesArr[pCourseId] = [];
        }   
        
        if( !self.batchesArr[pCourseId]['show'] ) {
            self.hideBatches();
            self.batchesArr[pCourseId]['show']=true;
        } else {
            self.hideBatches();
        }
        
        self.currentCourseBatch = {};
        var reqParams = {};
        var linkObj;
        if(typeof e.srcElement !='undefined'){
            linkObj = e.srcElement;
        }else{
            linkObj = e.target;
        }
        self.showBatchesDiv = 1;
        reqParams['pass_id'] = passId;
        reqParams['course_id'] = pCourseId;
        //if(typeof self.batchesArr[pCourseId]['content'] == 'undefined'){
            $http.get( baseApiUrl + '?method=loadLvcPassWorkshops', { params:reqParams } )
            .success(function(data) {
                self.getBatchesRequestPending = 0;
                if( data.status == 'success' && typeof data.content !== 'undefined' && data.content != '' ) {
                    self.batchesArr[pCourseId]['content'] = data.content;
                    self.currentCourseBatch = data.content;
                }
                else {
                    self.getBatchesRequestPending = 1;
                    self.batchesStatusMsg = "Some error occurred. Please try again later.";
                }
            })
            .error(function() {
                self.getBatchesRequestPending = 1;
                    self.batchesStatusMsg = "Some error occurred. Please try again later.";
            });
        //}else{
        //    self.getBatchesRequestPending = 0;
        //    self.currentCourseBatch = self.batchesArr[pCourseId]['content'];
        //}
    };
    
    self.hideBatches = function(){
        self.showBatchesDiv = 0;
        for(var prop in self.batchesArr){
            self.batchesArr[prop]['show']=false;
        }
        self.batchViewMoreVisible = 1;
    }
    
    self.changeTab = function(index){
        var parentUlObj = document.getElementsByClassName("benifits_wrap big_font")[0].getElementsByTagName("ul")[0];
        var liObjs = angular.element(parentUlObj)[0].getElementsByTagName("li");
        var liLength = liObjs.length;
        if(isMobile != 1 && $rootScope.hybridWidthFlag!=1){
            
            for(var i=0;i<liLength;i++){
                liObjs[i].className = liObjs[i].className.replace("lvc_active_btn","");
                liObjs[i].className = liObjs[i].className.replace(" ","");
                var divObj = liObjs[i].getElementsByTagName("div");

                divObj[0].className = "benifit_panel opacity_transition with-opacity";

            }
            liObjs[index].className = liObjs[index].className+" lvc_active_btn";
            var selectedDiv = liObjs[index].getElementsByTagName("div");
            selectedDiv[0].className = selectedDiv[0].className.replace("with-opacity","");
            selectedDiv[0].className = selectedDiv[0].className+" no-opacity";
            self.tabIndexCount = index;
        }else{
            
            if(self.tabIndexCount != index){
                for(var i=0;i<liLength;i++){
                    liObjs[i].className = liObjs[i].className.replace("active_lvc_btn","");
                    liObjs[i].className = liObjs[i].className.replace(" ","");
                    var divObj = liObjs[i].getElementsByTagName("div");

                    divObj[0].className = "benifit_panel height_transition hidden_cls";

                }
                liObjs[index].className = liObjs[index].className+" active_lvc_btn";
                var selectedDiv = liObjs[index].getElementsByTagName("div");
                selectedDiv[0].className = selectedDiv[0].className.replace("hidden_cls","");
                setTimeout(function(){selectedDiv[0].className = selectedDiv[0].className+" with-height";},50);

                self.tabIndexCount = index;
            }else{
                liObjs[index].className = liObjs[index].className.replace("active_lvc_btn","");
                liObjs[index].className = liObjs[index].className.replace(" ","");
                var divObj = liObjs[index].getElementsByTagName("div");
                divObj[0].className = "benifit_panel height_transition hidden_cls";
                
                self.tabIndexCount = -1;
            }
            
            
        }
    }
    
    self.hoverTab = function($event,hoverType){
        var linkObj;
        if(typeof $event.srcElement !='undefined'){
            linkObj = $event.srcElement;
        }else{
            linkObj = $event.target;
        }
        var divObj = linkObj.getElementsByTagName("div");
        if(typeof divObj[0] != 'undefined' && divObj[0].className.indexOf("no-opacity")==-1){
            if(hoverType == 1){
                linkObj.className = linkObj.className+" lvc_active_btn";
            }else{
                linkObj.className = linkObj.className.replace("lvc_active_btn","");
                linkObj.className = linkObj.className.replace(" ","");
            }
        }
        
    }
    
    self.lvcVideoDisplayStatus={'display':'none'};
    var lvcVid = null;
    
    self.showLvcVideo = function($event){
	$event.preventDefault();
        $scope.$broadcast('showHowLvcWorks', true);
    };
        
        self.openCourseAgenda = function($event,url){
            $event.preventDefault();
            window.open(url);
        }
        
        self.downloadSchedule = function($event,startDate,endDate,countryId){
            $event.preventDefault();
            $http.get( baseApiUrl + '?method=getWorkshopScheduleCsv', { params:{startDate:startDate,endDate:endDate,countryId:countryId} } )
            .success(function(data) {
                if(data == null || typeof data.message == 'undefined'){
                    window.location = baseApiUrl + '?method=getWorkshopScheduleCsv&startDate='+startDate+'&endDate='+endDate+'&countryId='+countryId;
                }else{
                    self.downloadScheduleErr = data.message;
                }
            })
            .error(function() {
                self.downloadScheduleErr = "Some error occurred. Please try again later.";
            });
        }
        
         var gaForLVCPass = function() {
            var ga = new gaEventsTracker();

            this.gaFireEventsGeneric = function(pGaKey, pGaLabel) {
                ga.gaFireInteractiveEvents(pGaKey, pGaLabel); 
            };
            this.gaOnloadLvc = function(){
                ga.gaFireInteractiveEvents('lvcFireOnload','lvc pass');
            }
            this.gaOnProceed = function(){
                ga.gaFireInteractiveEvents('OnPorceedClick','lvc pass');
            }
         };

         self.ga = new gaForLVCPass();
});