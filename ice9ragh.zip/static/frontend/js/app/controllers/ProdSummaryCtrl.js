angular.module('Simplilearn')
.controller('ProdSummaryCtrl', function(){
    
    this.currentFeature = 0;
    
    this.currentCategory = null;    //initialized using ng-init
    this.minCategoryId = null;      //initialized using ng-init
    this.maxCategoryId = null;      //initialized using ng-init
    
    this.currentCourse = null;
    
    this.setCurrentFeature = function(feature){
        if( feature === this.currentFeature ) {
            this.currentFeature = 0;
        }
        else {
            this.currentFeature = feature;
        }
    };
    
    this.isCurrentFeature = function(feature) {
        return this.currentFeature !== null && this.currentFeature === feature;
    };
    
    this.setCurrentCategory = function(category){
        this.currentCategory = category;
    };
    
    this.incrementCurrentCategory = function(){
        if( this.maxCategoryId !== null && this.currentCategory !== null && this.currentCategory !== this.maxCategoryId ) {
            this.setCurrentCategory(++this.currentCategory);
        }
        else {
            this.setCurrentCategory(this.minCategoryId);
        }
    };
    
    this.decrementCurrentCategory = function(){
        if( this.minCategoryId !== null && this.currentCategory !== null && this.currentCategory !== this.minCategoryId )
            this.setCurrentCategory(--this.currentCategory);
        else {
            this.setCurrentCategory(this.maxCategoryId);
        }
    };
    
    this.isCurrentCategory = function(category) {
        return this.currentCategory !== null && this.currentCategory === category;
    };
    
    this.setCurrentCourse = function(course){
        this.currentCourse = course;
    };
    
    this.isCurrentCourse = function(course) {
        return this.currentCourse !== null && this.currentCourse === course;
    };
})
;

