angular.module('Simplilearn')
        .controller('CaldonHomeCtrl', function ($http, $scope, $location, $document, PostReqService) {
            $scope.segmentName = 'All Segments';
            $scope.categoryId = 0;
            $scope.menuFocus = 0;
            $scope.baseUrl = baseUrl;
            $scope.baseApiUrlNocache = baseApiUrlNocache;
            $scope.siteBaseApiUrlNocache = siteBaseApiUrlNocache;
            $scope.segmentLists = output.data.segments;
            $scope.filter = output.data.filter;
            $scope.page = 2;
            $scope.total_page_number = output.data.total_page_number;
            var self = this;
            // console.log("segmentLists "+ output);
            webengage.onReady(function () {
                WebTracking.eventReq.triggerEvent({
                    event_id: "sl_frs_eng_user_lands_on_frs_homepage",
                    event_data: {
                        'sl_page_type': 'frs homepage'
                    }
                });

            });
            var paramsDetail = {
                filter: $scope.filter,
                method: 'loadFrsSegments'
            }
            PostReqService.sendPostRequest(siteBaseApiUrlNocache + '?method=loadFrsSegments', paramsDetail)
                    .then(function (output) {
                        $scope.segments = output.data;
                        // console.log("segments "+$scope.segments);         
                    });
            this.CallMoreSegements = function () {

                if ($scope.total_page_number < $scope.page) {
                    var paramsDetail = {
                        filter: $scope.filter,
                        p: $scope.page,
                        isMore: 1,
                        method: 'getFrsHomePageApi'
                    }
                    PostReqService.sendPostRequest($scope.baseApiUrlNocache, paramsDetail)
                            .then(function (output) {
                                var more = new Array(output.data.data.segments);
                                if (more[0].content.length > 0) {
                                    $scope.segmentLists.push.apply($scope.segmentLists, more);
                                }
                            });
                }
            }
            this.CallMoreSegements();
            $scope.FilterArticles = function (val) {
                return $scope.filter === val;
            };
            $scope.toggled = function (isopen) {
            }
            $scope.createFilterUrl = function (url, thisObj) {
                var test = decodeURIComponent(url);
                var decodedUrl = decodeURI(test);
                if ($scope.filter === 'latest') {
                    thisObj.seoUrl = $scope.baseUrl + decodeURI(decodedUrl) + '/' + $scope.filter;
                } else {
                    thisObj.seoUrl = $scope.baseUrl + decodeURI(decodedUrl);
                }
            }
            $scope.ViewMore = function () {
                var paramsDetail = {
                    filter: $scope.filter,
                    p: $scope.page,
                    method: 'getFrsHomePageApi'
                }
                var eventObj = {
                    'eventType': 'homeviewmoreClicked',
                };
                CaldonGA.triggerEvent.gagInitiate(eventObj);
                PostReqService.sendPostRequest($scope.baseApiUrlNocache, paramsDetail)
                        .then(function (output) {
                            $scope.page++;
                            $scope.segmentLists.push.apply($scope.segmentLists, output.data.data.segments);
                            self.CallMoreSegements();
                        });

            };

            $scope.makeurl = function (val, id, thisObj) {
                if (val) {
                    var title = val.toLowerCase();
                    thisObj.urlVal = $scope.baseUrl + 'resources/' + title.replace(/\s+/g, '-') + '/' + $scope.filter;
                }
            };
            $scope.latestUrl = function (val, thisObj) {
                thisObj.latestUrl = $scope.baseUrl + 'resources/' + val;
            };
            $scope.popularUrl = function (val, thisObj) {
                thisObj.popularUrl = $scope.baseUrl + 'resources/' + val;
            };

            $scope.triggerMoreGAEvent = function (segment) {
                var eventObj = {
                    'eventType': 'homeviewmoreSegmentClicked',
                    'label': segment
                };
                CaldonGA.triggerEvent.gagInitiate(eventObj);

            };

            $scope.triggerRightScrollEvent = function (segment) {
                var eventObj = {
                    'eventType': 'homeScrollSegment',
                    'label': segment
                };
                CaldonGA.triggerEvent.gagInitiate(eventObj);

            };

            window.addEventListener('scroll', function () {

            }, false);

        })
        .directive('calDirSlCarousel', function (HelperService, $rootScope, $timeout, $window) {
            return {
                link: function (scope, element, attrs) {
                    $timeout(function () {


                        var carouselScreen, carouselList, carouselItems, carouselItemWidth, carouselItemsLength, carouselItemsVisible,
                                carouselItemsLength, carouselPrevBtn, carouselNxtBtn, maxSlides, currentSlide, hf = HelperService, isSliding;

                        var initCarousel = function () {
                            carouselScreen = element[0].getElementsByClassName('c_screen')[0];
                            carouselList = element[0].getElementsByClassName('c_list')[0];
                            carouselPrevBtn = element[0].getElementsByClassName('c_prev')[0];
                            carouselNxtBtn = element[0].getElementsByClassName('c_next')[0];
                            carouselItems = angular.element(carouselList).children();
                            carouselItemWidth = carouselItems[0].offsetWidth;
                            carouselItemHeight = carouselItems[0].offsetHeight;
                            carouselItemsLength = carouselItems.length;
                            carouselItemsVisible = calculateBlocksToMove(carouselScreen, carouselItems, carouselItemsLength);
                            maxSlides = (carouselItemsLength % carouselItemsVisible) == 0 ? (carouselItemsLength / carouselItemsVisible) : (parseInt(carouselItemsLength / carouselItemsVisible) + 1);
                            currentSlide = 0;
                            carouselList.style.position = "relative";
                            addTransitionStyle(carouselList, "0.3s");
                            addTransformStyle(carouselList, 0);
                            // carouselList.style.width = (carouselItemsLength*carouselItemWidth)+"px";
                            carouselList.style.width = "10000px";
                            isSliding = 0;
                            angular.element(carouselPrevBtn).on('click', function () {
                                slideRight();
                            });
                            angular.element(carouselNxtBtn).on('click', function () {
                                slideLeft();
                            });
                            if (!$rootScope.mobWidthFlag) {
                                hf.$(carouselScreen).onSwipeLeft(function () {
                                    slideLeft();
                                });
                                hf.$(carouselScreen).onSwipeRight(function () {
                                    slideRight();
                                });
                            }
                            getCurrentTransformVal();
                            addEmptyLis(carouselList);
                        }

                        var addEmptyLis = function (carouselList) {
                            carouselItems = angular.element(carouselList).children();
                            carouselItemsLength = carouselItems.length;
                            carouselItemsVisible = calculateBlocksToMove(carouselScreen, carouselItems, carouselItemsLength);
                            var aa = carouselItemsLength % carouselItemsVisible;
                            if (aa != 0) {
                                var bb = carouselItemsVisible - aa;
                                var liList = [];
                                for (var i = 0; i < bb; i++) {
                                    var li = document.createElement("li");
                                    li.style.border = "none";
                                    li.style.float = "left";
                                    li.style.width = carouselItemWidth + "px";
                                    li.style.height = carouselItemHeight + "px";
                                    li.className = "c_list_item c_index_" + (carouselItemsLength + i + 1) + " empty_li";
                                    liList[i] = li;
                                }
                                for (var i = 0; i < bb; i++) {
                                    carouselList.appendChild(liList[i]);
                                }
                            }
                        }

                        var removeEmptyLis = function (carouselList) {
                            var carouselItemsAll = angular.element(carouselList).children();
                            for (var i = 0; i < carouselItemsAll.length; i++) {
                                var carouselItemObj = carouselItemsAll[i];
                                if (carouselItemObj.className.indexOf("empty_li") != -1) {
                                    carouselList.removeChild(carouselItemsAll[i]);
                                }
                            }
                        }
                        var calculateBlocksToMove = function (carouselScreen, carouselItems, carouselItemsLength) {
                            var citemstomove = 0;
                            for (var i = 0; i < carouselItemsLength; i++) {
                                if (carouselItems[i].offsetWidth > 0) {
                                    citemstomove = Math.round(carouselScreen.offsetWidth / carouselItems[i].offsetWidth);
                                    break;
                                }
                            }
                            return citemstomove;
                        }
                        var addTransitionStyle = function (carouselList, transformVal) {
                            carouselList.style.transition = "0.3s";
                            carouselList.style.setProperty("-webkit-transition", transformVal);
                            carouselList.style.setProperty("-moz-transition", transformVal);
                            carouselList.style.setProperty("-ms-transition", transformVal);
                            carouselList.style.setProperty("-o-transition", transformVal);
                        }
                        var addTransformStyle = function (carouselList, presentTransformVal) {
                            carouselList.style.transform = "translate3d(" + presentTransformVal + "px, 0px, 0px)";
                            carouselList.style.setProperty("-webkit-transform", "translate3d(" + presentTransformVal + "px, 0px, 0px)");
                            carouselList.style.setProperty("-moz-transform", "translate3d(" + presentTransformVal + "px, 0px, 0px)");
                            carouselList.style.setProperty("-ms-transform", "translate3d(" + presentTransformVal + "px, 0px, 0px)");
                            carouselList.style.setProperty("-o-transform", "translate3d(" + presentTransformVal + "px, 0px, 0px)");
                        }
                        var slideLeft = function () {
                            if (isSliding == 0) {
                                isSliding = 1;
                                carouselItems = angular.element(carouselList).children();
                                carouselItemWidth = carouselItems[0].offsetWidth;
                                carouselItemsLength = carouselItems.length;
                                var presentTransformVal = getCurrentTransformVal();
                                if (currentSlide < maxSlides - 1) {
                                    presentTransformVal = presentTransformVal - (carouselItemsVisible * carouselItemWidth);
                                    addTransitionStyle(carouselList, "0.3s");
                                    addTransformStyle(carouselList, presentTransformVal);
                                    currentSlide++;
                                    isSliding = 0;
                                } else {
                                    currentSlide = 0;
                                    var copiedObjs = [];
                                    var clonedObjs = [];
                                    for (var i = 0; i < carouselItemsLength; i++) {
                                        copiedObjs[i] = carouselList.children[i];
                                        clonedObjs[i] = copiedObjs[i].cloneNode(true);
                                    }
                                    //append elements to the end of the list
                                    for (var i = 0; i < carouselItemsLength; i++) {
                                        carouselList.appendChild(clonedObjs[i]);
                                    }
                                    presentTransformVal = presentTransformVal - (carouselItemsVisible * carouselItemWidth);
                                    addTransitionStyle(carouselList, "0.3");
                                    addTransformStyle(carouselList, presentTransformVal);
                                    $timeout(function () {
                                        for (var i = 0; i < carouselItemsLength; i++) {
                                            carouselList.removeChild(copiedObjs[i]);
                                        }
                                        addTransitionStyle(carouselList, "");
                                        addTransformStyle(carouselList, 0);
                                        currentSlide = 0;
                                        isSliding = 0;
                                    }, 300);
                                }
                            }
                        }

                        var slideRight = function () {
                            if (isSliding == 0) {
                                isSliding = 1;
                                carouselItems = angular.element(carouselList).children();
                                carouselItemWidth = carouselItems[0].offsetWidth;
                                carouselItemsLength = carouselItems.length;
                                var presentTransformVal = getCurrentTransformVal();
                                if (currentSlide == 0) {
                                    var copiedObjs = [], clonedObjs = [];
                                    for (var i = 0; i < carouselItemsLength; i++) {
                                        copiedObjs[i] = carouselList.children[carouselItemsLength - (i + 1)];
                                        clonedObjs[i] = copiedObjs[i].cloneNode(true);
                                    }
                                    addTransitionStyle(carouselList, "");
                                    //append elements to the end of the list
                                    for (var i = 0; i < clonedObjs.length; i++) {
                                        carouselList.insertBefore(clonedObjs[i], carouselList.firstChild);
                                    }
                                    presentTransformVal = getCurrentTransformVal() - (carouselItemWidth * (carouselItemsLength));
                                    addTransformStyle(carouselList, presentTransformVal);
                                    setTimeout(function () {
                                        presentTransformVal = getCurrentTransformVal() + (carouselItemWidth * carouselItemsVisible);
                                        addTransitionStyle(carouselList, "0.3s");
                                        addTransformStyle(carouselList, presentTransformVal);
                                        for (var i = 0; i < carouselItemsLength; i++) {
                                            carouselList.removeChild(copiedObjs[i]);
                                        }
                                        currentSlide = maxSlides - 1;
                                        isSliding = 0;
                                    }, 200);

                                } else {
                                    if (currentSlide <= maxSlides) {
                                        presentTransformVal = presentTransformVal + (carouselItemsVisible * carouselItemWidth);
                                        addTransitionStyle(carouselList, "0.3s");
                                        addTransformStyle(carouselList, presentTransformVal);
                                        currentSlide--;
                                        isSliding = 0;
                                    }
                                }
                            }
                        }

                        var getCurrentTransformVal = function () {
                            var transformStr = carouselList.style.transform;
                            var modifiedTransformStr = transformStr.substring(transformStr.indexOf("3d(") + 3, transformStr.indexOf(",", transformStr.indexOf("3d(")));
                            modifiedTransformStr = modifiedTransformStr.replace("px", "");
                            modifiedTransformStr = parseInt(modifiedTransformStr);
                            return modifiedTransformStr;
                        }
                        initCarousel();

                        $rootScope.$on('orientationChanged', function (isOrientationChanged) {
                            if (isOrientationChanged) {
                                isSliding = 1;
                                $timeout(function () {
                                    removeEmptyLis(carouselList);
                                    addEmptyLis(carouselList);
                                    addTransitionStyle(carouselList, "");
                                    addTransformStyle(carouselList, 0);
                                    carouselItems = angular.element(carouselList).children();
                                    carouselItemsLength = carouselItems.length;
                                    carouselItemsVisible = calculateBlocksToMove(carouselScreen, carouselItems, carouselItemsLength);
                                    maxSlides = (carouselItemsLength % carouselItemsVisible) == 0 ? (carouselItemsLength / carouselItemsVisible) : (parseInt(carouselItemsLength / carouselItemsVisible) + 1);
                                    currentSlide = 0;
                                    isSliding = 0;
                                }, 300);
                            }
                        });
                    }, 300);

                }
            }
        });
