angular.module('Simplilearn')
.controller('StayUpdatedCtrl', function($scope, $http){
    
    $scope.email = '';
    $scope.helpers = new helpers();

    $scope.submitForm = function(form) {
        
        if (!form.$valid) {
            return $scope.helpers.FormNotValid(form);
        }
                
        $http.get(baseApiUrl + "?method=newsLetterFormSubmit",
                {params:
                            {email: $scope.email}
                }
        ).success(function(data) {
            if (data.status == "Success") {
                $scope.email = "";
                $scope.stayUpdatedForm.$setPristine();
                $scope.stayUpdatedStatusMsg = "Your subscription has been confirmed. Happy learning!";
                $scope.stayUpdatedStatusClass = "success_text";
            } else {
                $scope.stayUpdatedStatusMsg = "Some error occurred. Please try again later.";
                $scope.stayUpdatedStatusClass = "error_text";
            }
        }).error(function() {
            $scope.stayUpdatedStatusMsg = "Some error occurred. Please try again later.";
            $scope.stayUpdatedStatusClass = "error_text";
        });
    };
    
});