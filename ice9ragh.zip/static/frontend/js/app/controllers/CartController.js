angular.module('Simplilearn')
.controller('CartCtrl', function($http, $timeout, LocService, $cookies, $window,$scope,$rootScope, PaymentEventService) {

    var default_last_label = {
        'name' : 'Project Management',
        'url' : 'project-management'
    };

    this.lastLabel = default_last_label;
    this.personName = '';
    this.email = '';
    this.phone = '';
    this.coupon = '';
    this.serviceTax = '';
    this.grandTotal = '';
    this.grandTotalActual='';
    this.cartData = new Array();
    this.numOfItems = 0;
    this.showInfoMsg = 0;
    this.countryData = null;
    this.selected_country = null;
    this.helpers = new helpers();
    this.invalidCouponMessageDisplay = 'none';
    this.couponApplied = false;
    this.isRequestPending = 0;
    this.updateErrMsg = null;
    this.isIpad = isIpad;
    this.baseUrl = baseUrl;
    this.couponTxt = '';
    this.couponDiscount=0;
    this.couponCurrency='';
    this.otherCouponTxt='';
    this.otherCouponError=false;
    $scope.otherCouponApply=false;
    this.offerCoupons = [];
    this.classroomExists = 0;
    this.subsExistsData = {};
    this.freeTrialUsedData = {'freeTrialUsed':1};
    this.subsName = '';
    this.isAffirm = false;

    var self = this;
    var Math = window.Math;
    var isPaymentConflictVisible = false;

    this.initialize = function(couponCode,couponDiscount,couponCurrency) {
        self.couponTxt = couponCode;
        self.couponDiscount=couponDiscount;
        self.couponCurrency=couponCurrency;
        $timeout(function(){
            self.showInfoMsg = 0;
        }, 5000);

        LocService.getCountryData().then(function(data) {
            self.countryData = data;

            //set current country using cookie
            LocService.setCurrentCountry(null, JSON.parse($cookies.locatori9).country_id);

            //get current country
            self.selected_country = LocService.getCurrentCountry();

            //this.personPhone = '+'+this.selected_country.phnCode+'-';
        });
    };

    this.init_CartDetails = function( pCourseId, pBatchId, pAccessDays, pQty, pUnitPrice, pTotPrice, pTrainingType ) {
        var new_data = {"courseId":pCourseId, "batchId":pBatchId, "accessDays":pAccessDays, "qty":pQty, "unitPrice":pUnitPrice, "totPrice":pTotPrice, "trainingTypeId":pTrainingType,
                        "showDetailsFlag":0, "detailsLabel":"details"};
        this.cartData.push(new_data);

        this.numOfItems = getNumberOfCartItems();

//        updateCartCookieVal();
    };

    this.createOffersBlock = function(code,desc,validTill,savedAmount){
        var offerObj = {'code':code,'desc':desc,'validTill':validTill,'savedAmount':savedAmount};
        self.offerCoupons.push(offerObj);
    }

    this.removeCoupon = function(pEvent) {
        self.isRequestPending = 1;
        $http
            .post(baseUrlAjax+"cart/remove-coupon")
            .success(function(data){
                self.couponApplied = false;
                self.invalidCouponMessageDisplay = 'none';
                self.coupon = '';
                self.couponTxt = '';
                updateCartData(data.cart, false);
                self.isRequestPending = 0;
            })
            .error(function() {
                self.isRequestPending = 0;
            });
        if (pEvent) {
            if( typeof pEvent.preventDefault !== 'undefined' ) {
                pEvent.preventDefault();
            }
            else {
                pEvent.returnValue  = false;
            }
        }
    }

    this.applyCoupon = function($event, pIsKeyboardEvent, pCoupon) {
                if( typeof pCoupon !== 'undefined') {
                    var coupon = angular.copy(pCoupon);
                }
                else {
                    var coupon = angular.copy(self.coupon);
                }
		if( typeof $event.keyCode === 'undefined' ||
                        (!$event.keyCode && !this.isIpad && pIsKeyboardEvent) ||
                        (!$event.keyCode && !pIsKeyboardEvent) ||
                        $event.keyCode == 13 )
                {
                        if( typeof $event.preventDefault !== 'undefined' ) {
                                $event.preventDefault();
                        }
                        else {
                            $event.returnValue  = false;
                        }

                        self.invalidCouponMessageDisplay = 'none';
			if(coupon == ''){
                            return false;
			}else{
                            $scope.gaCartControllerJs.gaCouponTry(coupon);
                            self.isRequestPending = 1;
				$http
				.post(baseUrlAjax+"cart/apply-coupon", {"code":coupon})
				.success(function(data){
					if (data.status == 'success'){
                                            self.couponTxt = coupon;
                                            $scope.gaCartControllerJs.gaCouponSuccess(coupon);
						self.couponApplied = true;
						self.invalidCouponMessageDisplay = 'none';
						updateCartData(data.cart);
                                                self.isRequestPending = 0;
                                                $rootScope.toggleModalDisplay('cart_offer_pop','none',$event);
                                                self.couponDiscount=data.cart.general.totalDiscount;
                                                self.couponCurrency=data.cart.general.currency;
					} else {
                                                self.isRequestPending = 0;
                                                var gaObj = new gaEventsTracker();
                                                gaObj.gaFireOnCartPageInvalidCouponSubmit(data.messages);
                                            $scope.gaCartControllerJs.gaCouponFail(data.messages);
                                            if(self.otherCouponTxt != ''){
                                                self.otherCouponError=true;
                                                $scope.otherCouponApply=false;
                                                $rootScope.toggleModalDisplay('cart_offer_pop','block',$event);
                                            }else{
                                                self.couponApplied = false;
						self.invalidCouponMessageDisplay = 'block';
                                            }

					}
				})
                                .error(function() {
                                    self.isRequestPending = 0;
                                    if(self.otherCouponTxt != ''){
                                        self.otherCouponError=true;
                                        $scope.otherCouponApply=false;
                                        $rootScope.toggleModalDisplay('cart_offer_pop','block',$event);
                                    }
                                });
			}
		}
    };

    this.submitForm = function(form, pEvent,gaPassName,gaBundleName) {
        setFormVars(gaPassName,gaBundleName);
        return true;
        if( typeof pEvent.preventDefault !== 'undefined' ) {
            pEvent.preventDefault();
        }
        else {
            pEvent.returnValue  = false;
        }

        if (!form.$valid) {
            return this.helpers.FormNotValid(form);
        }

        var index = 0;
        for(var prop in self.cartData) {
            if(self.cartData[prop]) {
                index = prop;
                break;
            }
        }

        sendUpdateRequest(index, 0, 1, pEvent,gaPassName,gaBundleName);
    };

    var setFormVars = function(gaPassName,gaBundleName) {
        this.phone = $rootScope.queryPhoneCode+this.phone;
	$rootScope.queryPhoneCode = "";
        if(gaPassName!=''){
            $scope.gaCartControllerJs.gaCartLVC(gaPassName);
        }
        if(gaBundleName!=''){
            $scope.gaCartControllerJs.gaCartBundle(gaBundleName);
        }
        document.getElementById('cartForm').submit();
    };

	$scope.$watch(angular.bind(this, function() {
        return this.phone;
    }), function(newValue) {
		if(isNaN(newValue)){
			$scope.cartForm.cartPhone.$setValidity('required', false);
		}else if(newValue.length > 10){
			$scope.cartForm.cartPhone.$setValidity('required', false);
		}

	});

	$scope.$watch(angular.bind(this, function() {
        return this.coupon;
    }), function(newValue) {
		if(newValue == ''){
			self.invalidCouponMessageDisplay = 'none';
		}

	});

        $scope.$watch(angular.bind(this, function() {
            return this.otherCouponTxt;
        }), function(newValue) {
            if(typeof newValue != 'undefined' && newValue != ''){
                $scope.otherCouponApply=true;
            }else{
                $scope.otherCouponApply=false;
            }
        });

    this.changeAccessDays = function( pIndex, pDays ) {
        if(typeof this.cartData[pIndex]['accessDays'] !== 'undefined' && !!this.cartData[pIndex]['accessDays'] && this.cartData[pIndex]['accessDays'] == pDays) {
            return false;
        }
        sendUpdateRequest( pIndex, pDays, 0, 0 );
    };

    this.changeQty = function( pIndex ) {

			if(self.cartData[pIndex].qty != '' && self.cartData[pIndex].qty > 0 && !isNaN(self.cartData[pIndex].qty)){
				self.cartData[pIndex].qty = parseInt(self.cartData[pIndex].qty);
				sendUpdateRequest( pIndex, null, 0, 0 );
			}else{
				self.cartData[pIndex].qty = '';
				return false;
			}



    };

    this.checkQty = function( pIndex ) {
        if(!self.cartData[pIndex].qty) {
            self.cartData[pIndex].qty = 1;
            sendUpdateRequest( pIndex, null, 0, 0 );
        }
    };

    this.removeItem = function( pIndex ) {
        self.isRequestPending = 1;
        $http.get(baseUrlAjax+"cart/remove-cart-item",
                        {
                            params: {
                                        "itemId":self.cartData[pIndex].courseId,
                                        "batchId":self.cartData[pIndex].batchId,
                                        "accessDays":self.cartData[pIndex].accessDays,
                                        "trainingTypeId":self.cartData[pIndex].trainingTypeId
                                    }
                        }
                )
                .success(function(data){
                    if( !data || !data.cart ) {
                        self.updateErrMsg = 'Some error occurred. Please try again.';
                        removeUpdateErrMsg();
                        self.isRequestPending = 0;
                        return;
                    }
                    self.cartData[pIndex] = null;
                    self.numOfItems = getNumberOfCartItems();
                    if(data.cart) {
                        updateCartData(data.cart);
                    }
//                    updateCartCookieVal();
                    self.isRequestPending = 0;

                    if(!self.numOfItems && typeof data.primary_label !== 'undefined' && data.primary_label.name) {
                        self.lastLabel = data.primary_label;
                        self.lastLabel.url = self.lastLabel.url.replace(/^\/+/,"");      //remove slashes from beginning of url
                    }
                    
                    var eventData = PaymentEventService.getItemAttributeByIndex(pIndex);
                    var commonData = WebTracking.eventReq.getDataFromUserParams(['sl_page_type', 'sl_product_price_symbol', 'sl_order_id', 'sl_currency']);
                    for(var key in commonData) {
                        eventData[key] = commonData[key];
                    }
                    WebTracking.eventReq.triggerEvent({event_id: "sl_pay_user_removes_item_from_cart", event_data: eventData});
                })
                .error(function(data){
                    console.log('error');
                    self.isRequestPending = 0;
                });
    };

    var sendUpdateRequest = function( pIndex, pDays, pFormSubmitFlag, pMainEvent,gaPassName,gaBundleName ) {
        self.isRequestPending = 1;
        $http.get(baseUrlAjax+"cart/update-cart-item",
                        {
                            params: {
                                        "itemId":self.cartData[pIndex].courseId,
                                        "batchId":self.cartData[pIndex].batchId,
                                        "trainingTypeId":self.cartData[pIndex].trainingTypeId,
                                        "accessDays":self.cartData[pIndex].accessDays,
                                        "newAccessDays":(pDays === null) ? self.cartData[pIndex].accessDays : pDays,
                                        "quantity":self.cartData[pIndex].qty,
                                        "email":self.email,
                                        "phone":self.phone,
                                        "personName":self.personName,
                                        "proceedFlag":pFormSubmitFlag
                                    }
                        }
                )
                .success(function(data){
                    var rv = updateCartData(data);
                    self.isRequestPending = 0;

                    if( !rv ) {
                        self.updateErrMsg = 'Some error occurred. Please try again.';
                        removeUpdateErrMsg();
                    }

                    if( pFormSubmitFlag === 1 && rv ) {
                        if( data.general.userAlreadySubscribed ) {
                            self.subsExistsData = data.general.userAlreadySubscribed;
                            $rootScope.toggleModalDisplay('js_sub_exists_pop','block',null);
                            preventDefaultEvent(pMainEvent);
                            $scope.gaCartControllerJs.gaFireEventsGeneric('subsCartPopup', self.subsExistsData.title);
                            if( self.subsExistsData.state == 'freeTrialExpired' ) {
                                $scope.gaCartControllerJs.gaFireEventsGeneric('subsCartFnlPayToProceedMsg', self.subsName);
                            }
                        } else {
                            setFormVars(gaPassName,gaBundleName);
                        }
                    }
                    else if( pFormSubmitFlag === 1 && !!pMainEvent && !rv ) {
                        preventDefaultEvent(pMainEvent);
                    }

                    if(data && data.status == 'failed' && data.msg) {
                        self.updateErrMsg = data.msg;
                    }
                })
                .error(function(data){
                    console.log('error');
                    self.isRequestPending = 0;
                    self.updateErrMsg = 'Some error occurred. Please try again.';
                    removeUpdateErrMsg();
                    if( pFormSubmitFlag === 1 && !!pMainEvent ) {
                        preventDefaultEvent(pMainEvent);
                    }
                });
    };

    var preventDefaultEvent = function(pMainEvent) {
        if( typeof pMainEvent.preventDefault !== 'undefined' ) {
                pMainEvent.preventDefault();
        }
        else {
            pMainEvent.returnValue  = false;
        }
    };

    var removeUpdateErrMsg = function() {
        $timeout(function(){
            self.updateErrMsg = 0;
        }, 5000);
    };

    var updateCartData = function(data, callRemoveCoupon) {
        if (typeof callRemoveCoupon == 'undefined') {
            callRemoveCoupon = true;
        }
        if(!data || ( typeof data.general == 'undefined' )) {
            return false;
        }

        //self.personName = (!data.general.person_name) ? self.personName : data.general.person_name;
        //self.email = (!data.general.email) ? self.email : data.general.email;
        //self.phone = (!data.general.phone) ? self.phone : data.general.phone;

                if (callRemoveCoupon && !data.general.coupon) {
                    self.removeCoupon();
                } else {
                    self.coupon = data.general.coupon;
                }

		self.serviceTax	= data.general.service_tax;
		self.grandTotal = data.general.grand_total;
                self.grandTotalActual = parseFloat(Math.round(data.general.grand_total_actual * 100) / 100).toFixed(2);
        //incrementPrice(removeCommas(self.serviceTax), removeCommas(data.general.service_tax), null, 'serviceTax', data.general.service_tax);
        //incrementPrice(removeCommas(self.grandTotal), removeCommas(data.general.grand_total), null, 'grandTotal', data.general.grand_total);

        if(typeof data[0] === 'undefined' || !data[0]) {
            return true;
        }
        var isOslExistInCart = false;
        for( var prop in self.cartData ) {
            if( !self.cartData[prop] ) {
                continue;
            }
            if(self.isAffirm){
                if(self.cartData[prop].trainingTypeId == 2){
                    var checkString = 'b';
                    var cId = self.cartData[prop].courseId;
                    if(cId.indexOf('b') == -1){
                        isOslExistInCart = true;
                        console.log(self.cartData[prop].trainingTypeId);
                    }
                }
            }
            if( self.cartData[prop].courseId == data[0].course_id ) {
                if( data[0].hasOwnProperty('batch_id') && data[0].batch_id == self.cartData[prop].batchId ) {
                    self.cartData[prop].qty = data[0].qty;
					self.cartData[prop].unitPrice = data[0].display_unit_price;
					self.cartData[prop].totPrice = data[0].display_total_price;
                    //incrementPrice(removeCommas(self.cartData[prop].unitPrice), removeCommas(data[0].price), prop, 'unitPrice', data[0].price);
                    //incrementPrice(removeCommas(self.cartData[prop].totPrice), removeCommas(data[0].total_price), prop, 'totPrice', data[0].total_price);
                    break;
                }
                else if( data[0].hasOwnProperty('access_days') && self.cartData[prop].accessDays && self.cartData[prop].trainingTypeId == data[0].trainingType_id ) {
                    self.cartData[prop].qty = data[0].qty;
                    self.cartData[prop].accessDays = data[0].access_days;
					self.cartData[prop].unitPrice = data[0].display_unit_price;
					self.cartData[prop].totPrice = data[0].display_total_price;
                    //incrementPrice(removeCommas(self.cartData[prop].unitPrice), removeCommas(data[0].price), prop, 'unitPrice', data[0].price);
                    //incrementPrice(removeCommas(self.cartData[prop].totPrice), removeCommas(data[0].total_price), prop, 'totPrice', data[0].total_price);
                    break;
                }
            }
        }
        if(data.general.is_affirm){
            if(document.getElementById("affirm-not-applicable")){
                document.getElementById("affirm-not-applicable").innerHTML = "";
            }
        }
//        if(self.isAffirm && typeof isOslExistInCart !=="undefined" && !isOslExistInCart){
//            document.getElementById("affirm-not-applicable").innerHTML = "";
//        }

//        updateCartCookieVal();

        self.offerCoupons = [];
        var offerLength = (data['general']['offers']).length;
        for(var i=0;i<offerLength;i++){
            var offerObj = data['general']['offers'][i];
            self.offerCoupons.push({'code':offerObj.code,'desc':offerObj.desc,'validTill':offerObj.validity,'savedAmount':offerObj.saveAmt});
        }
        self.couponDiscount = data['general']['totalDiscount'];
        return true;
    };

    this.toggleDetails = function( pIndex ) {
        if( self.cartData[pIndex].showDetailsFlag === 0 ) {
            self.cartData[pIndex].showDetailsFlag = 1;
            self.cartData[pIndex].detailsLabel = 'hide details';
        }
        else {
            self.cartData[pIndex].showDetailsFlag = 0;
            self.cartData[pIndex].detailsLabel = 'details';
        }
        var eventData = PaymentEventService.getItemAttributeByIndex(pIndex);
        var commonData = WebTracking.eventReq.getDataFromUserParams(['sl_page_type', 'sl_product_price_symbol', 'sl_order_id', 'sl_currency', 'sl_page_type']);
        for (var key in commonData) {
            eventData[key] = commonData[key];
        }
        WebTracking.eventReq.triggerEvent({event_id: "sl_pay_user_clicks_on_details_in_cart", event_data: eventData});
    };

    var incrementPrice = function(from, to, index, key, actualVal) {/*
        var obj = null;

        if( index !== null ) {
            obj = self.cartData[index];
        }
        else {
            obj = self;
        }

        obj[key] = removeCommas(obj[key]);

        if( from < to ) {
            $incr = 75;
        }
        else if( from > to ) {
            $incr = -75;
        }
        else {
            obj[key] = actualVal;
            return;
        }

        var interval = 50;
        var limit = 2000;
        var time_cnt = 0;

        var timerId = $interval(function(){
            time_cnt += interval;

            obj[key] += $incr;

            if( time_cnt >= limit || obj[key] === to || Math.abs(obj[key] - to) < Math.abs($incr) ) {
                obj[key] = actualVal;
                $interval.cancel(timerId);
            }
        }, interval);*/
    };

    var removeCommas = function(str) {
        if(!str || (typeof str !== "string") ) {
            return 0;
        }

        str = str.replace( /\,/g, '' );
        str = parseInt( str, 10 );

        return str;
    };

    this.validatePhone = function() {

        var regexph = /^\+\d{1,4}-?\d{5,10}$/;

        if( this.phone.match(regexph) == null ) {
            return false;
        }
        else {
            return true;
        }
    };

    var updateCartCookieVal = function() {
        var cart_count = 0;

        for( var prop in self.cartData ) {
            if( self.cartData[prop] ) {
                cart_count += parseInt(self.cartData[prop].qty);
            }
        }

        document.cookie = "cart_items="+cart_count+";path="+baseUrl+';SameSite=Lax';
    };


    var getNumberOfCartItems = function() {
        var item_count = 0;
        self.classroomExists = 0;

        for( var prop in self.cartData ) {
            if( self.cartData[prop] ) {
                item_count++;

                self.classroomExists = (self.cartData[prop]['batchId']) ? 1 : self.classroomExists;
            }
        }

        return item_count;
    };

    this.setPaymentConflictVisibility = function(pVal) {
        isPaymentConflictVisible = pVal;
    };

    this.isPaymentConflictVisible = function() {
        return isPaymentConflictVisible;
    };

    this.purgeAndAddToCart = function( pItemId, pBatchId, pAccessDays, pPaymentType ) {
        self.isRequestPending = 1;
        $http
            .get(baseUrlAjax+"cart/purge-cart-and-add-item",
            {
                params:{'itemId':pItemId, 'batchId':pBatchId, 'accessDays':pAccessDays, 'paymentType':pPaymentType, 'phone':self.phone, 'personName':self.personName, 'email':self.email}
            })
            .success(function(data){
                self.isRequestPending = 0;
                self.setPaymentConflictVisibility(false);
                if(data && data.status == 'success' && data.redirectUrl) {
                    window.location = data.redirectUrl;
                } else {
                    if(data && data.status == 'failure' && data.msg) {
                        self.updateErrMsg = data.msg;
                        removeUpdateErrMsg();
                    } else {
                        self.updateErrMsg = 'Some error occurred. Please try again.';
                        removeUpdateErrMsg();
                    }
                }
            })
            .error(function() {
                self.isRequestPending = 0;
                self.updateErrMsg = 'Some error occurred. Please try again.';
                removeUpdateErrMsg();
            });
    };

    //called from a separate controller scope
    this.openLiveChat = function( pUrl ) {
        _ss_track.api.live_chat_click();
    };

    this.init_liveChat = function() {
        setTimeout(function(){ //methinks required not...
                    var head= document.getElementsByTagName('head')[0];
                    var script= document.createElement('script');
                    script.type= 'text/javascript';
                    script.src= 'https://server.iad.liveperson.net/hc/24435859/?cmd=mTagRepstate&site=24435859&buttonID=13&divID=lpButDivID-1316506592981&bt=1&c=1';
                    script.async = true;
                    head.appendChild(script);
        }, 10000);
    };
    this.logoClick = function (frontendUrl) {
        var eventData = WebTracking.eventReq.getDataFromUserParams(['sl_event_time','sl_page_type','sl_user_type','sl_utm_src','sl_user_email_hash']);
        eventData['sl_destination_link'] = frontendUrl || '';
        eventData['sl_destination_page_type'] = 'home';
        WebTracking.eventReq.triggerEvent({
            event_id: "sl_nav_user_clicks_on_simplilearn_logo",
            event_data: eventData,
        });
    };
    var gaClassForCartPage = function() {
        var ga = new gaEventsTracker();
        this.gaCouponTry = function(name) {
            ga.gaFireInteractiveEvents('cartpagecoupontry', name);
        }
        this.gaCouponSuccess = function(name) {
            ga.gaFireInteractiveEvents('cartpagecouponsuccess', name);
        }
        this.gaCouponFail = function(nameWithFailReason) {
            ga.gaFireInteractiveEvents('cartpagecouponfail', nameWithFailReason);
        }
        this.gaCartProceedToPay = function() {
            ga.gaFireOnCartProceedClick();
        }
        this.gaFireEventsGeneric = function(pGaKey, pGaLabel) {
            ga.gaFireInteractiveEvents(pGaKey, pGaLabel);
        };

        this.gaCartLVC = function(cName){
           ga.gaFireInteractiveEvents('OnPorceedLvcPassClick', cName);
        }

        this.gaCartBundle = function (cName) {
            ga.gaFireInteractiveEvents('OnPorceedBundleClick', cName);
        }
    };
    $scope.gaCartControllerJs = new gaClassForCartPage();

    this.applyOffers = function(coupon,pEvent){
        self.applyCoupon(pEvent,0, coupon);
    }        
});