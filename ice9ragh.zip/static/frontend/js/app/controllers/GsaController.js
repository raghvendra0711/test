angular.module('Simplilearn')
.controller('GsaController', function ($scope,$document ,$rootScope) {

            $scope.downloadCourseList = function ($event) {
                WebTracking.setUserParams('sl_lead_button_text', 'DOWNLOAD COURSE LIST');
                WebTracking.setUserParams('sl_site_module', "GSA_Brochure");
                var eventData = WebTracking.eventReq.getDataFromUserParams(['sl_lead_button_text', 'sl_lead_type', 'sl_page_type', 'sl_site_module', 'sl_user_type']);
                WebTracking.eventReq.triggerEvent({
                    event_id: "sl_lead_module_initiated",
                    event_data: eventData
                });
                if ($rootScope.isLeadSubmitted) {
                    $rootScope.downloadBrochureCourseList();
                    return false;
                }
                $rootScope.toggleModalDisplay('gsa-brochure-form', 'block', $event);
            }
            $scope.moduleInitiate = function ($siteModule = '') {
                WebTracking.setUserParams('sl_lead_button_text', 'REQUEST MORE INFORMATION');
                WebTracking.setUserParams('sl_site_module', $siteModule);
                var eventData = WebTracking.eventReq.getDataFromUserParams(['sl_lead_button_text', 'sl_lead_type', 'sl_page_type', 'sl_site_module', 'sl_user_type']);
                WebTracking.eventReq.triggerEvent({
                    event_id: "sl_lead_module_initiated",
                    event_data: eventData
                });
            }
            this.onFormClose = function (){
                var eventData = WebTracking.eventReq.getDataFromUserParams(['sl_site_module', 'sl_user_type', 'sl_lead_type', 'sl_page_type']);
                WebTracking.eventReq.triggerEvent({
                    event_id: "sl_lead_form_closed",
                    event_data: eventData
                });
            }
     
            $rootScope.downloadBrochureCourseList = function () {
                if (typeof user_params.COURSE_LIST_DOC_URL == "string") {
                    var name = user_params.COURSE_LIST_DOC_URL.split('?')[0];
                    name = name.split('/')[name.split('/').length - 1];
                    var link = document.createElement('a');
                    link.href = user_params.COURSE_LIST_DOC_URL;
                    link.download = name;
                    link.dispatchEvent(new MouseEvent('click'));
                }
            };
    
    
            (function () {
                if (sl_page_type == 'gsa page') {
                    if (document.referrer == "") {
                        WebTracking.setUserParams('sl_user_type', "b2b");
                    }
                    webengage.onReady(function () {
                        WebTracking.eventReq.triggerEvent({
                            event_id: "sl_eng_web_page_viewed",
                            common: "product"
                        });
                    });
                }
            })();

        });

