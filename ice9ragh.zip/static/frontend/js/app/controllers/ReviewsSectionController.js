angular.module('Simplilearn')
.controller('ReviewsSectionController', function($scope) {

	this.currentReviewType = '0';
        this.showMoreRs = 0;

        this.reviewsLimit = 0;
        this.totalReviews = 0;
        this.reviewsVisible = 0;
        this.viewMoreFlag = 1;

        this.init = function(pReviewsLimit, pTotalReviews) {
            this.reviewsLimit = pReviewsLimit;
            this.totalReviews = pTotalReviews;
            this.reviewsVisible = pReviewsLimit;
        };

	this.setReviewType = function(rvwType) {
            this.currentReviewType = rvwType;//@review no return statement
        };

        this.isCurrentReviewType = function(rvwType) {
            if (this.currentReviewType === null) {
                return false;
            }

            var rvw_types = rvwType.split('|');
            var validity = rvw_types.indexOf(this.currentReviewType);

            return validity !== -1;
        };

        this.showMoreReviews = function ($event) {
            $event.preventDefault();
            WebTracking.eventReq.triggerEvent({
                event_id : "sl_eng_product_reviews_view_more_clicked",
                common : "product",
            });
            $scope.gaMReviewsCtrlJs.gaFireGeneral('showmorereviews', user_params.user_id + ' || ' + document.URL);
            var reviewsToShow = this.totalReviews - this.reviewsVisible;
            this.reviewsVisible += (reviewsToShow > this.reviewsLimit) ? this.reviewsLimit : reviewsToShow;
            this.viewMoreFlag = (this.reviewsVisible == this.totalReviews) ? 0 : 1;
        };

        this.showLessReviews = function ($event) {
            $event.preventDefault();
            this.reviewsVisible = this.reviewsLimit;
            this.viewMoreFlag = 1;
        };

        this.isReviewVisible = function(pIndex) {
            if(pIndex <= this.reviewsVisible) {
                return 1;
            } else {
                return 0;
            }
        };

        this.linkedinClick = function() {
            $scope.gaMReviewsCtrlJs.gaFireGeneral('reviewerprofileclick', user_params.user_id + ' || ' + document.URL + ' || linkedin');
        };

        var gaClassForReviews = function() {
            var ga = new gaEventsTracker();
            this.gaFireGeneral = function(cat, label) {
                if (typeof label !== 'undefined' && label) {
                    ga.gaFireInteractiveEvents(cat, label);
                } else {
                    ga.gaFireInteractiveEvents(cat);
                }
            }
        }

        $scope.gaMReviewsCtrlJs = new gaClassForReviews();
});
