angular.module('Simplilearn')
.controller('FreeTrialController', function($scope, $http, LocService, $interval, $location, $rootScope, $timeout, $compile, PostReqService) {
    $scope.showFreeTrialPopup = false;
    $scope.contactMe = 1;
    $scope.agreeClicked = 0;
    var initUserHash = function() {
        // Get user information
        var userWatch = $rootScope.$watch('userInfo', function(newValue, oldValue) {
            var user = (newValue && newValue.email)?newValue:oldValue;
            if(user && user.email && typeof user == 'object') {
                $scope.ftUserEmail = user.email || $scope.email;
                $scope.ftUserPhone = user.phone || $scope.phone;
                // $scope.phoneCode = user.phoneCode || $scope.phoneCode;
                userWatch(); // stop listen
            }
        });
    }

    this.initFreeTrial = function() {
        initUserHash();
        if(document.getElementById("frmOnlineCourses") != null)
            document.getElementById("frmOnlineCourses").addEventListener('submit', frmOnlineCoursesSubmit);
        if(document.getElementById("frmLvcPassCourses") != null)
            document.getElementById("frmLvcPassCourses").addEventListener('submit', frmOnlineCoursesSubmit);
        if(document.getElementById("frmOnlineBundles") != null)
            document.getElementById("frmOnlineBundles").addEventListener('submit', frmOnlineCoursesSubmit);
        if(document.getElementById("sticky-enroll-btn") != null) {
            var btns = ['sticky-enroll-btn', 'bundle-enroll-btn'];
            for( var elem in btns ) {
                var btnElem = document.getElementById(btns[elem]);
                if(btnElem != null) {
                    btnElem.addEventListener('click', function(event) {
                        var submitId = angular.element(event.target).attr("data-submit");
                        if(submitId) {
                            var formObj = document.getElementById(submitId);
                            var elems = formObj.getElementsByTagName("button");
                            if(typeof elems[0] != 'undefined')
                                elems[0].click();
                             return false;
                        }
                    });
                }
            }

        }
    }

            $scope.setParamsBeforeSubmit = function ($event) {
                
                if ($scope.freeTrialForm.$invalid || $scope.contactMe===false) {
                    $event.preventDefault();
                    if ($scope.freeTrialForm.ftUserEmail.$invalid) {
                        $scope.freeTrialForm.ftUserEmail.$setViewValue($scope.freeTrialForm.ftUserEmail.$viewValue);
                    }
                    if ($scope.freeTrialForm.ftUserPhone.$invalid) {
                        $scope.freeTrialForm.ftUserPhone.$setViewValue($scope.freeTrialForm.ftUserPhone.$viewValue);
                    }
                    return;
                } else {
                    var phoneCodeDom = document.getElementById('free-trail-phone-coutnry-code');
                    var selectedOption = phoneCodeDom[phoneCodeDom.selectedIndex];
                    $scope.phoneCountryCode = angular.element(selectedOption).attr('data-country-code') || '';
                    document.freeTrialForm.submit();
                }

            }

    $rootScope.$watch('countryList', function(newValue) {
        if(newValue) {
            setTimeout(function() {
                if(typeof $rootScope.queryPhoneCode == 'string') {
                    // if(typeof  $scope.phoneCode == 'undefined')
                        $scope.phoneCode = $rootScope.queryPhoneCode;
                        $scope.$apply();
                }
            }, 100)
        }
    })

    this.hideFreeTrialPopup = function() {
        $scope.showFreeTrialPopup = false;
    }

    var frmOnlineCoursesSubmit = function(event) {
        var elems = event.target.getElementsByTagName("input");
        var free_trialElems = document.getElementsByName('free_trial');
        var data = {};
        if(typeof free_trialElems != 'undefined' && free_trialElems.length > 0){
            for( var elemsFT in free_trialElems ) {
                if(typeof free_trialElems[elemsFT].value != 'undefined' && free_trialElems[elemsFT].value == 1) {
                       for( var elem in elems ) {
                            if(!isNaN(elem) && typeof data[elems[elem].name] == 'undefined') {
                                data[elems[elem].name] = elems[elem].value;
                                var cln = elems[elem].cloneNode(true);
                                document.getElementById('free_trial_info').appendChild(cln);
                            }
                        }
                        event.preventDefault();
                        setTimeout(function() {
                            $scope.$apply(function () {
                                $scope.showFreeTrialPopup = true;
                            });
                        }, 8);
                }
            }
        }
    }

    $scope.$watch('ftUserPhone', function(newValue, oldValue) {
        if(typeof $scope.freeTrialForm != 'undefined') {
            if(isNaN(newValue)){
                $scope.freeTrialForm.ftUserPhone.$setValidity('required', false);
            }else if(newValue.length > 10){
                $scope.freeTrialForm.ftUserPhone.$setValidity('required', false);
            } else {
                $scope.freeTrialForm.ftUserPhone.$setValidity('required', true);
            }
        }
    });
    this.addRemoveClassInBody = function(val){
            var class_name = 'popup_open_body';
             if(val == 1){
                 document.body.classList.add(class_name);
             } else {
                 document.body.classList.remove(class_name);
             }
        };
    $scope.toggleContactMe = function(){//@review rename function to toggleContactMe: Done
		$scope.agreeClicked = 1;
		if($scope.contactMe == 0){
			$scope.contactMe = 1;
		}else{
			$scope.contactMe = 0;
		}
                //@review should use return statement
	}


})