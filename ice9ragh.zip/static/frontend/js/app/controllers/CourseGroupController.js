angular.module('Simplilearn')
.controller('CourseGroupCtrl', function(){

    var currentGroup = null;
    
    this.setCurrGroup = function( pGrpName ) {
        currentGroup = pGrpName;
    };
    
    this.isCurrGroup = function( pGrpName ) {
        return currentGroup !== null && currentGroup === pGrpName;
    }
});

