/* global companyInfo */

angular.module('Simplilearn')
        .controller('agencyCompanyDetailCtrl', ['LocService', '$cookies', 'PostReqService', '$scope', '$timeout', '$http', '$location', '$window', 'ScopeService','$rootScope', function (LocService, $cookies, PostReqService, $scope, $timeout, $http, $location, $window, ScopeService, $rootScope) {
                $scope.baseUrl = baseUrl;
                $scope.baseApiUrlNocache = baseApiUrlNocache;
                $scope.learnerCount = '';
                $scope.companyListData = [];
                $scope.countryData = [];
                $scope.customerName = '';
                $scope.email = '';
                $scope.companyConfirmEmail = '';
                $scope.phone = '';
                $scope.cartEmprty = false;
                $scope.agencyName = {'agency_id':''};
                $scope.agencyMgrEmail = '';
                $scope.lmsUrlDomain = '.' + lmsDomain;
                $scope.agencyData = {};
                $scope.helpers = new helpers();
                $scope.isManager = false;
                $scope.saveError = false;
                $scope.lmsUrlSaved = '';
                $scope.checkoutInView = false;
                $scope.invalidLearnerLimit = false;
                $scope.domainErr = false;
                $scope.domainList = [];
                $scope.goBackToCart = function () {
                    var redirectURL = $scope.baseUrl + 'cart-b2b';
                    $window.location.href = redirectURL;
                };
                $scope.gid = '';

                    function isElementInViewport (el) {

                        //special bonus for those using jQuery
                        if (typeof jQuery === "function" && el instanceof jQuery) {
                            el = el[0];
                        }

                        var rect = el.getBoundingClientRect();
                        return (
                            rect.top >= 0 &&
                            rect.left >= 0 &&
                            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) && /*or $(window).height() */
                            rect.right <= (window.innerWidth || document.documentElement.clientWidth) /*or $(window).width() */
                        );
                    }

                    $scope.setScroll = function () {
                        window.onscroll = function changeClass(){
                            var el=document.getElementById('stickyCheckout');
                            if(!isElementInViewport(el) && !$scope.cartEmprty){
                                document.getElementById('stickyCheckout').classList.add('sticky-footer-invisible');

                            } else {
                                document.getElementById('stickyCheckout').classList.remove('sticky-footer-invisible');
                            }
                            var scrollPosY = window.pageYOffset | document.body.scrollTop;
                            if(scrollPosY > 100) {
                                //$scope.cartFooterClass=true;
                                document.getElementById('stickyCheckout').classList.add('sticky-footer-wpp');
                            }
                            else{
                                document.getElementById('stickyCheckout').classList.remove('sticky-footer-wpp');

                            }
                        }
                    }

                $scope.toggleLearnerType = function (learnerType) {
                    var paramsArr = {'customer_type': learnerType};
                    PostReqService.sendPostRequest(baseUrlAjax+"cart-b2b/update-cart-cusomter-type", paramsArr)
                    .then(function (response) {
                        if (response.data.status == 'success'){
                            if(learnerType == 'individual'){
                                var grandTotal = response.data.pricing_data.grand_total;
                                var totalAmount = response.data.pricing_data.total;
                                var serviceTaxRate = response.data.pricing_data.service_tax_rate;
                                var serviceTax = response.data.pricing_data.service_tax;
                                var quantity = 1;
                                angular.forEach(response.data.pricing_data, function(value, key) {
                                    if(key !== 'grand_total'){
                                        angular.element(document.getElementById('price_'+key)).html(value);
                                        angular.element(document.getElementById('learner_count_'+key)).val(quantity);
                                        if(response.data.pricing_data.display_discount_percent){
                                            var discount_percent = response.data.pricing_data.display_discount_percent + '% off';
                                            angular.element(document.getElementById('disccart_'+key)).html(discount_percent);
                                        }
                                    }
                                    $scope.numberdisabled = true;
                                });
                                $scope.learnerCount = true;
                                angular.element(document.getElementsByClassName('cart_grand_total')).html(grandTotal);
                                angular.element(document.getElementsByClassName('total-amount')).html(totalAmount);
                                angular.element(document.getElementsByClassName('service_tax_rate')).html(serviceTaxRate);
                                angular.element(document.getElementsByClassName('service_tax')).html(serviceTax);
                            }else{
                                $scope.learnerCount = false;
                                $scope.numberdisabled = false;
                            }
                        } else {
                            return false;
                        }
                    });
                };
                $scope.remove = function(id) {
                    var elem = document.getElementById(id);
                    return elem.parentNode.removeChild(elem);
                }
                $scope.removeItemFormCart = function (itemKey) {
                    var paramsArr = {'item_key':itemKey};
                    PostReqService.sendPostRequest(baseUrlAjax+"cart-b2b/remove-item", paramsArr)
                    .then(function (response) {
                        if (response.data.status == 'success'){
                            var grandTotal = response.data.pricing_data.grand_total;
                            var totalAmount = response.data.pricing_data.total;
                            var serviceTaxRate = response.data.pricing_data.service_tax_rate;
                            var serviceTax = response.data.pricing_data.service_tax;
                            if(grandTotal === 0){
                                grandTotal += '.00';
                                $scope.cartEmprty = true;
                            }else{
                                $scope.cartEmprty = false;
                            }
                            $scope.remove(itemKey);
                            angular.element(document.getElementsByClassName('cart_grand_total')).html(grandTotal);
                            angular.element(document.getElementsByClassName('total-amount')).html(totalAmount);
                            angular.element(document.getElementsByClassName('service_tax_rate')).html(serviceTaxRate);
                            angular.element(document.getElementsByClassName('service_tax')).html(serviceTax);
                        } else {
                            $scope.isValidResponse = false;
                        }
                    });
                };

                $scope.getAgencyInfo = function () {
                    if(typeof $scope.agencyName != 'undefined' && typeof $scope.agencyName.agency_id != 'undefined'){
                        var agency = $scope.agencyData[$scope.agencyName.agency_id];
                        if(Array.isArray(agency.domain) && agency.domain){
                            $scope.domainList = [];
                            for(i in agency.domain){
                                $scope.domainList.push(agency.domain[i]['name']);
                            }
                            $scope.companyDetailForm.email.$setValidity("email", true);
                            $scope.domainErr  = false;

                        }
                        if(agency.gid != null && agency.gid != ''){
                            $scope.gid = agency.gid;
                            $scope.agencyMgrEmail = agency.manager_email;
                            $scope.agencyError = false;
                        } else {
                            $scope.gid = '';
                            $scope.agencyMgrEmail = '';
                            $scope.companySfAccId = '';
                            if($scope.lmsUrlSaved != ''){
                                $scope.lmsUrl = $scope.lmsUrlSaved.replace($scope.lmsUrlDomain,'');
                                $scope.lmsUrlSaved = '';
                            }
                            $scope.saveError = false;
                            $scope.agencyError = true;
                        }
                        var agencyUrl = agency.lms_url;
                        $scope.lmsUrl = agencyUrl.replace($scope.lmsUrlDomain,'');
                        $scope.companySfAccId = agency.companySfAccId;
                        $scope.mgrError  = false;
                    }

                };


                $scope.updateLearnCount = function (itemKey) {
                    var learnerCount = angular.element(document.getElementById('learner_count_'+itemKey)).val();
                    if(isNaN(learnerCount) || learnerCount <= 0){
                        $scope.invalidLearnerLimit = true;
                        return false;
                    }
                    $scope.invalidLearnerLimit = false;
                    var paramsArr = {'item_key':itemKey,'learner_count':learnerCount };
                    PostReqService.sendPostRequest(baseUrlAjax+"cart-b2b/update-item-count", paramsArr)
                    .then(function (response) {
                        if (response.data.status == 'success'){
                            var grandTotal = response.data.pricing_data.grand_total;
                            var totalAmount = response.data.pricing_data.total;
                            var serviceTaxRate = response.data.pricing_data.service_tax_rate;
                            var serviceTax = response.data.pricing_data.service_tax;
                            var itemPrice = response.data.pricing_data.display_unit_price;
                            angular.element(document.getElementById('price_'+itemKey)).html(itemPrice);
                            angular.element(document.getElementsByClassName('cart_grand_total')).html(grandTotal);
                            angular.element(document.getElementsByClassName('total-amount')).html(totalAmount);
                            angular.element(document.getElementsByClassName('service_tax_rate')).html(serviceTaxRate);
                            angular.element(document.getElementsByClassName('service_tax')).html(serviceTax);
                            if(response.data.pricing_data.display_discount_percent){
                                var discount_percent = response.data.pricing_data.display_discount_percent + '% off';
                                angular.element(document.getElementById('disccart_'+itemKey)).html(discount_percent);
                            }
                        } else {
                            $scope.isValidResponse = false;
                        }
                    });
                };

                 $scope.onBackKeyDown  = function(){
                    window.history.go(-1);
                 }

                 $scope.filterValue = function($event){//alert($event.which);
                    if($event.which != 8 && isNaN(String.fromCharCode($event.which))){
                        $event.preventDefault();
                    }
                };

                $scope.qtyValue = function($event,itemKey){
                    var learnerCount = angular.element(document.getElementById('learner_count_'+itemKey)).val();
                    //alert(learnerCount);
                    if($event.which !=8 && $event.which !=0){
                        if( (!learnerCount && $event.which == 48) || isNaN(String.fromCharCode($event.which))){
                            $event.preventDefault();
                        }
                    }
                };

                $scope.getCompanyList = function (email, personName, phone, agency_id, agency_name, isManager, lms_url) {
                    var myinterval = setInterval(function(){
                        if(typeof $rootScope.queryPhoneCode != 'undefined' && $rootScope.queryPhoneCode != 'null' && $rootScope.queryPhoneCode != null){
                            $scope.phoneCode = $rootScope.queryPhoneCode;
                            clearInterval(myinterval);
                        }
                    }, 1000);
                    $scope.isManager = (isManager == 1) ? true : false;
                    $scope.customerName = personName;
                    $scope.email = email;
                    $scope.companyConfirmEmail = email;
                    $scope.phone = phone;
                    var timeStampInMs = window.performance && window.performance.now && window.performance.timing && window.performance.timing.navigationStart ? window.performance.now() + window.performance.timing.navigationStart : Date.now();

                    $http
                    .get(baseUrlAjax+"cart-b2b/get-agency-list?time="+timeStampInMs)
                        .success(function(response){
                            if (response.status == 'success'){
                                $scope.agencyCount = response.company_list.agencyCount;
                                var i = 0;
                                angular.forEach(response.company_list.agencyData, function (value,key) {
                                    if(key && value){
                                        $scope.agencyData[key] = value;
                                    }
                                });
                                angular.forEach(response.company_list.agencies, function (value,key) {
                                    if(key >= 0 && value){
                                        $scope.companyListData.push({'agency_id':value[0],'agency_name':value[1]});
                                        i++;
                                        if(i == $scope.agencyCount){
                                            if(agency_id != ''){
                                                $scope.agencyName = {'agency_id':agency_id, 'agency_name': agency_name};
                                                $scope.lmsUrlSaved = lms_url;
                                                $scope.getAgencyInfo();
                                            }
                                            else if($scope.agencyCount == 1){
                                                $scope.agencyName = $scope.companyListData[0];
                                                $scope.getAgencyInfo();
                                            }
                                        }

                                    }
                                });


                            }
                        })
                        .error(function(){
                           return false;
                        });
                };

                $scope.matchEmail = function () {
                    if($scope.isManager && $scope.agencyMgrEmail != '' && $scope.email!='' && $scope.agencyMgrEmail != $scope.email){
                        $scope.companyDetailForm.email.$setValidity("email", false);
                        $scope.mgrError  = true;
                        return false;
                    } else{
                         $scope.companyDetailForm.email.$setValidity("email", true);
                         $scope.mgrError  = false;
                         return true;
                    }
                };
                //Proceed To Payment.
                $scope.proceddToSsvc = function (form) {
                    if(typeof $scope.agencyName == 'undefined' || $scope.agencyName == 0){
                        $scope.agencyNameClass = 'error_field';
                    } else {
                        var agency = $scope.agencyData[$scope.agencyName.agency_id];
                        if (typeof agency.gid !== 'undefined' && agency.gid !== null && agency.gid !== '') {
                            $scope.gid = agency.gid
                            $scope.agencyError = false;
                            $scope.agencyNameClass = '';
                        } else {
                            $scope.saveError = false;
                            $scope.agencyError = true;
                            return false;
                        }
                    }
                    if (!form.$valid || $scope.agencyNameClass != '') {
                        return $scope.helpers.FormNotValid(form);
                    }
                    if(!$scope.matchEmail()){
                        return $scope.helpers.FormNotValid(form);
                    }
                    if(typeof $scope.lmsUrl != 'undefined'){
                        var n = $scope.lmsUrl.search($scope.lmsUrlDomain);
                    } else {
                        $scope.lmsUrl = '';
                    }
                    var lmsUrl = '';
                    if($scope.lmsUrl != ''){
                        if(n == -1)
                            lmsUrl = $scope.lmsUrl + $scope.lmsUrlDomain;
                        else
                            lmsUrl = $scope.lmsUrl;
                    }

                    if (Array.isArray($scope.domainList)) {
                        var emailDomain = $scope.email.split('@');
                        if (emailDomain[1] && $scope.domainList.indexOf(emailDomain[1]) === -1) {
                            var domainFlag = 0
                            for (var domain of $scope.domainList) {
                                if (domain.indexOf(".") === -1) {
                                    if (emailDomain[1].indexOf(domain) !== -1) {
                                        domainFlag = 1;
                                        break;
                                    }
                                }
                            }
                            if (domainFlag === 0) {
                                $scope.companyDetailForm.email.$setValidity("email", false);
                                $scope.saveError = false;
                                $scope.domainErr = true;
                                return false;
                            }
                        }
                    }

                    var agency = $scope.agencyName;
                    var customerName = $scope.customerName;
                    var email = $scope.email;
                    var phone = $scope.phone;
                    var phoneCode = $scope.phoneCode;
                    var agencyMgrEmail = $scope.agencyMgrEmail;
                    var paramsArr = {
                        'gid': $scope.gid,
                        'companySfAccId': $scope.companySfAccId,
                        'agencyName': typeof agency.agency_name != 'undefined' ? agency.agency_name : '',
                        'agencyId': typeof agency.agency_id != 'undefined' ? agency.agency_id : '',
                        'customerName': customerName,
                        'email': email,
                        'phone': phone,
                        'phoneCode': phoneCode,
                        'lmsUrl': httpProtocol + '//' + lmsUrl,
                        'lmsManagerEmail': agencyMgrEmail
                    };
                    $scope.saveError = false;
                    PostReqService.sendPostRequest(baseUrlAjax+"cart-b2b/update-cart-learners", paramsArr)
                    .then(function (response) {
                        if (response.data.status == 'success'){
                            $window.location.href = response.data.ssvc;
                        } else {
                            $scope.isValidResponse = false;
                            $scope.saveError = true;
                        }
                    });
                };

                 LocService.getCountryData().then(function(data) {
                    $scope.countryData = data;
                    LocService.setCurrentCountry(null, JSON.parse($cookies.locatori9).country_id);
                    $scope.selected_country = LocService.getCurrentCountry();
                    $scope.queryCountryId = $scope.selected_country.id;
                    $scope.queryPhoneCode = "+"+$scope.selected_country.phnCode+"-";
                    $scope.cookie_country_name = $scope.selected_country.name;
                    $scope.countryDataHeaderDropDown = $scope.countryData;
                });

            }]);
