angular.module('Simplilearn')
    .controller('ScholarshipProgramCtrl', function ($scope, $http) {
      $scope.helpers = new helpers();
      $scope.STEP = 1;
      $scope.SUBMIT = null;
      $scope.YourMialId = null;
      $scope.FirstName = null;
      $scope.City = null;
      $scope.LastName = null;
      $scope.State = null;
      $scope.DateOfBirth = null;
      $scope.ZipCode = null;
      $scope.MailingAddress = null;
      $scope.Phone = null;
      $scope.IntendedDegreeType = null;
      $scope.CurrentCollege = null;
      $scope.HearAboutUs = null;
      $scope.CollegeEmail = null;
      $scope.CurrentMajor = null;
      $scope.CapabilityDescription = null;
      $scope.CapabilityDescribeLater = null;
      $scope.BigDataCheck = null;
      $scope.DigitalMarketingCheck = null;
      $scope.ProjectManagementCheck = null;
      $scope.StudentTnC = true;
      $scope.StudentEmail = null;
      $scope.scholarShipSubmitted = false;
      $scope.popupStatusMsg = '';
      $scope.popupStatus = null;
      $scope.CollegeGradYear = null;
      $scope.termsCond = 0;
      $scope.termsCondToggle = function() {
                $scope.termsCond = $scope.termsCond == 1 ? 0 : 1;
       };
      this.stepSubmit = function () {
        if ($scope.STEP == 3) {
          $scope.STEP = 1;
          this.formSubmit();
        } else {
          $scope.STEP++;
        }
        return false;
      }
      this.stepBack = function () {
        if ($scope.STEP > 1) {
          $scope.STEP--;
        }
        return false;
      }
      
      $scope.initfunc = function(){
        //Getting Location Data
        $http.post(baseApiUrl + '?method=getLocationList&country=United States').then(function (data) {
            if(data.data.status == 'success'){ 
              $scope.country_data = data.data.data;
          }
        });  
        
        $http.post(baseApiUrl + '?method=getCollegeList').then(function (data) {
            if(data.data.status == 'success'){ 
              $scope.college_data = data.data.data;
          }
        });
        
      }
      
      this.formSubmit = function (type_scholarship) { 
        if($scope.apply_now_form.$invalid){
	  return $scope.helpers.FormNotValid($scope.apply_now_form);
	
	}
        
        var date_input = new Date($scope.DateOfBirth);
        var curr_date = new Date();
        if(date_input > curr_date){
          var element = document.getElementById("dateofbirth");
          element.classList.add("error");
	  return $scope.helpers.FormNotValid($scope.apply_now_form);
	}  
        
        if(type_scholarship == 'simplilearn'){
           if( !$scope.BigDataCheck && !$scope.DigitalMarketingCheck && !$scope.ProjectManagementCheck) {
               //alert("Please select atleast one course");
               return $scope.helpers.FormNotValid($scope.apply_now_form);
           } 
        }
        $http.post(baseApiUrl + '?method=postScholarshipApplication',
            {
              FirstName: $scope.FirstName,
              LastName: $scope.LastName,
              CollegeEmail: $scope.CollegeEmail,
              DateOfBirth: $scope.DateOfBirth,
              Phone: $scope.Phone,
              City: $scope.City,
              State: $scope.State,
              ZipCode: $scope.ZipCode,
              MailingAddress: $scope.MailingAddress,
              IntendedDegreeType: $scope.IntendedDegreeType,
              CurrentCollege: $scope.CurrentCollege,
              CollegeGradYear : $scope.CollegeGradYear,
              CurrentMajor: $scope.CurrentMajor,
              CapabilityDescription: ($scope.CapabilityDescribeLater == true) ? null : $scope.CapabilityDescription,
              CapabilityDescribeLater:$scope.CapabilityDescribeLater,
              HearAboutUsOptions : $scope.HearAboutUsOptions,
              HearAboutUs : $scope.HearAboutUs,
              BigDataCheck: $scope.BigDataCheck,
              DigitalMarketingCheck: $scope.DigitalMarketingCheck,
              ProjectManagementCheck: $scope.ProjectManagementCheck,
              TypeScholarship:type_scholarship,
              PageURL :window.location.href,
              processed:0,
              verified:0,
              approved:0
            }).then(function (data) {
               if(data.data.status == 'success'){
                   $scope.SUBMIT = 'success';
               }else{
                   $scope.SUBMIT = 'fail';
               }
            var elmnt = document.getElementById("apply_form");
            $scope.scrollToCustom(0, elmnt.offsetTop, 50);
        });
        
        //$scope.SUBMIT = 'success';
      }
      $scope.enrollStudent = function () {
        if (this.studentEnrollmentForm.$invalid) {
          return this.helpers.FormNotValid(this.studentEnrollmentForm);
        }
        var data = {
              course_id: course_id,
              scholarship: user_params.scholarship,
              StudentEmail: this.StudentEmail,
              ambassador_code: ambassador_code
            };
        $http.post(baseApiUrl + '?method=postStudentEnrollment', data).then(function(d) {
//              return;
              $scope.scholarShipSubmitted = true;
              $scope.popupStatusMsg = d.data.message;
              $scope.popupStatus = d.data.status;
            });
      }
      
      $scope.scrollToCustom = function (element, to, duration) {
                if (duration <= 0) return;
                var difference = to - element;
                var perTick = difference / duration * 10;

                setTimeout(function() {
                    element = element + perTick;
                    window.scrollTo(0,element);
                    if (element === to) return;
                    $scope.scrollToCustom(element, to, duration - 10);
                }, 10);
    };
    
    this.apply_now_click = function(){ 
                var elmnt1 = document.getElementById("apply_form");
                $scope.scrollToCustom(0, elmnt1.offsetTop, 500);
    };
      
      this.hideAllModal = function () {
      var modalObjs = document.getElementsByClassName('popup_country_wrapper');
      var modalLen = modalObjs.length;
      for(var i=0;i<modalLen;i++){
        if(modalObjs[i].style.display =='block'){
          modalObjs[i].style.display = 'none';
        }
      }
      var bodyObj = document.getElementsByTagName('body')[0];
      bodyObj.className = bodyObj.className.replace("body_fixed","");
    }
    });