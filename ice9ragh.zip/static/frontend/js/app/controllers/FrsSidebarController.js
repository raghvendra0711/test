angular.module('Simplilearn')
.controller('FrsSidebarController', function(){
    
    var self = this;
    
    var gaForFrsSidebar = function() {
       var ga = new gaEventsTracker();

       this.gaEventsCourseNav = function(pListPage, pPosition) {
           if( pListPage == 'articles' ) {
                ga.gaFireInteractiveEvents('frsArticleCourseNavClick', pPosition);
           } else if( pListPage == 'ebooks' ) {
                ga.gaFireInteractiveEvents('frsEbookCourseNavClick', pPosition);               
           } else if( pListPage == 'upcoming-webinar' ) {
                ga.gaFireInteractiveEvents('frsWebinarCourseNavClick', pPosition);               
           } else if( pListPage == 'videos' ) {
                ga.gaFireInteractiveEvents('frsVideoCourseNavClick', pPosition);               
           }
       };
       
       this.gaEventsCourseImgClick = function(pListPage, pPosition) {
           if( pListPage == 'articles' ) {
                ga.gaFireInteractiveEvents('frsArticleCourseImageClick', pPosition);
           } else if( pListPage == 'ebooks' ) {
                ga.gaFireInteractiveEvents('frsEbookCourseImageClick', pPosition);               
           } else if( pListPage == 'upcoming-webinar' ) {
                ga.gaFireInteractiveEvents('frsWebinarCourseImageClick', pPosition);               
           } else if( pListPage == 'videos' ) {
                ga.gaFireInteractiveEvents('frsVideoCourseImageClick', pPosition);               
           }
       };
       
       this.gaEventsCourseDtlClick = function(pListPage, pPosition) {
           if( pListPage == 'articles' ) {
                ga.gaFireInteractiveEvents('frsArticleCourseDetailsClick', pPosition);
           } else if( pListPage == 'ebooks' ) {
                ga.gaFireInteractiveEvents('frsEbookCourseDetailsClick', pPosition);               
           } else if( pListPage == 'upcoming-webinar' ) {
                ga.gaFireInteractiveEvents('frsWebinarCourseDetailsClick', pPosition);               
           } else if( pListPage == 'videos' ) {
                ga.gaFireInteractiveEvents('frsVideoCourseDetailsClick', pPosition);               
           }
       };
       
       this.gaEbookClick = function(pListPage, pPosition) {
           if( pListPage == 'articles' ) {
                ga.gaFireInteractiveEvents('frsArticleEbookClick', pPosition);
           } else if( pListPage == 'ebooks' ) {
                ga.gaFireInteractiveEvents('frsEbookEbookClick', pPosition);               
           } else if( pListPage == 'upcoming-webinar' ) {
                ga.gaFireInteractiveEvents('frsWebinarEbookClick', pPosition);               
           } else if( pListPage == 'videos' ) {
                ga.gaFireInteractiveEvents('frsVideoEbookClick', pPosition);               
           }
       };
       
       this.gaWebinarClick = function(pListPage, pPosition) {
           if( pListPage == 'articles' ) {
                ga.gaFireInteractiveEvents('frsArticleWebinarClick', pPosition);
           } else if( pListPage == 'ebooks' ) {
                ga.gaFireInteractiveEvents('frsEbookWebinarClick', pPosition);               
           } else if( pListPage == 'upcoming-webinar' ) {
                ga.gaFireInteractiveEvents('frsWebinarWebinarClick', pPosition);               
           } else if( pListPage == 'videos' ) {
                ga.gaFireInteractiveEvents('frsVideoWebinarClick', pPosition);               
           }
       };
       
       this.gaPopTagClick = function(pListPage, pPosition) {
           if( pListPage == 'articles' ) {
                ga.gaFireInteractiveEvents('frsArticlePopularTagClick', pPosition);
           } else if( pListPage == 'ebooks' ) {
                ga.gaFireInteractiveEvents('frsEbookPopularTagClick', pPosition);               
           } else if( pListPage == 'upcoming-webinar' ) {
                ga.gaFireInteractiveEvents('frsWebinarPopularTagClick', pPosition);               
           } else if( pListPage == 'videos' ) {
                ga.gaFireInteractiveEvents('frsVideoPopularTagClick', pPosition);               
           }
       };
       
       this.gaArticleClick = function(pListPage, pPosition) {
           if( pListPage == 'articles' ) {
                ga.gaFireInteractiveEvents('frsArticleRelatedArticleSideClick', pPosition);
           } else if( pListPage == 'ebooks' ) {
                ga.gaFireInteractiveEvents('frsEbookRelatedArticleSideClick', pPosition);               
           } else if( pListPage == 'upcoming-webinar' ) {
                ga.gaFireInteractiveEvents('frsWebinarRelatedArticleSideClick', pPosition);               
           } else if( pListPage == 'videos' ) {
                ga.gaFireInteractiveEvents('frsVideoRelatedArticleSideClick', pPosition);               
           }
       };
    };
    
    self.ga = new gaForFrsSidebar();
});