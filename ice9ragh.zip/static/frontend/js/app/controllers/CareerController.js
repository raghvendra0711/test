angular.module('Simplilearn')
.controller('CareerController', function(){
    this.constructVidPlayer = function(divId, vidUrl, vidImg) {
		jwplayer(divId).setup({
			file: vidUrl,
			image: vidImg,
			base: staticUrl + 'core/js/jwplayer/',
			width: 655,
			height: 385,
			startparam: 'start',
			//skin: staticUrl + 'core/js/jwplayer/skin_base64_new.xml',
			fallback: false,
			icons: true
		})

		return true;
	};
});