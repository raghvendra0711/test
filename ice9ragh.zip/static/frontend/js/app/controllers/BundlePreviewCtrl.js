angular.module('Simplilearn')
.controller('BundlePreviewCtrl', function(CpService, $scope, $cookies) {

	this.coursePreviewData = null;
	this.Math = window.Math;
        this.sectionName = "Modules Included";
        this.showDetailsFlag = 0;
        this.accordionStatus = 0;
        this.ga;
        $scope.stickyComponentDisplay = {'display':'none'};
        $scope.bundlePreviewClicked=0;
        $scope.courseId ;
	var self = this;



        $scope.$watch(function () { return self.accordionStatus; }, function(newVal){
            if( newVal === 1 ) {
                self.showDetailsFlag = 0;
            }
        });

        this.handleBundlePreviewClick = function(courseId,courseName,bundleId,bundleName,$event){

            if($scope.bundlePreviewClicked==0){
                var bundleList = document.getElementsByClassName("bundle_preview_container");
                for(var i=0;i<bundleList.length;i++){
                    var bundleObj = bundleList[i];
                    var angularEle = angular.element(bundleObj);
                   if(angularEle.scope().bundlePreviewClicked == 1){
                        angularEle.scope().bundlePreviewClicked = 0;
                    }
                }
                $scope.bundlePreviewClicked=1;
                $scope.courseId = courseId;
                user_params.course_id = courseId;
                user_params.course_name = courseName;
                user_params.bundle_id = bundleId;
                user_params.bundle_name = bundleName;
                self.ga.gaFireEventsGeneric('subsCourseExpand',courseName);
            }else{
                $scope.bundlePreviewClicked=0;
            }

        }

        this.handleVideoLinkClick = function(elearningId, lessons, lessonObj, sectionId) {
            return CpService.handleVideoLinkClick(elearningId, lessons, lessonObj, sectionId, $cookies[user_params.enterpriseCountCookieName]);
        };

        this.hidePreview = function(){
           return CpService.hidePreview();
        };

        this.getSectionIframeSrc = function(){
          return CpService.getIframeSrc();
        };

        this.showPreviewStatus = function(){
            return CpService.getShowPreviewStatus();
        };

        this.setShowDetails = function() {
            this.showDetailsFlag = ( this.showDetailsFlag === 1 ) ? 0 : 1;
        };

        this.shouldShowDetails = function() {
            return this.showDetailsFlag;
        };

        var gaForLVCPass = function() {
            var ga = new gaEventsTracker();

            this.gaFireEventsGeneric = function(pGaKey, pGaLabel) {
                ga.gaFireInteractiveEvents(pGaKey, pGaLabel);
            };
         };

         self.ga = new gaForLVCPass();
});
