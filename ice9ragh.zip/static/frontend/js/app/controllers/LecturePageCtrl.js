angular.module('Simplilearn')
        .controller('LecturePageCtrl', function ($scope, $http, $rootScope, $window,CpService, $timeout,PostReqService, $cookies) {
            $scope.display = {display: 'block'};
            $scope.LPLike = 0;
            $scope.LPDislike = 0;
            $scope.LPChapid = 0;
            $scope.LPCid = 0;
            $scope.showVideo = 0;
            $scope.mobileView = 1;
            $scope.showMobileLink = 0;
            $scope.showCrsPrev = 1;
            $scope.divCounterForLecturePage = '';
            $scope.videoState = '';
            $rootScope.lecturePage = 1;
            $scope.stopPopup = 0;
            $scope.popupIdentifier = "popup-modal-lecture";
            $scope.popuptimerCount = 30000;
            $scope.lectureCoursePreviewTitle = '';
            $scope.elearningId='';
            $scope.lessons='';
            $scope.lessonObj='';
            $scope.sectionId='';
            $scope.isFromELearning='';
            $scope.url='';
            $scope.videoType='';
           
            var w = angular.element($window);
            w.bind('resize', function () {
                $rootScope.setSizeFlags();
            })
            $rootScope.$watch('mobWidthFlag', function (n, o) {
                if ($rootScope.mobWidthFlag) {
                    $scope.showMobileLink = 1;
                } else {
                    $scope.showMobileLink = 0;
                }
            })
                                   
            init = function(){
                   var cname = "lecture_popup_cookie";
                   var isLecturePopupViewed= getCookie(cname);
                   if((typeof user_params.disablePopUp =='undefined' || user_params.disablePopUp == 0)&&(typeof isLecturePopupViewed === "undefined" || parseInt(isLecturePopupViewed) === 0 || user_params.primary_course_id != parseInt(isLecturePopupViewed))){
                    $timeout(function(){
                        var elm = document.getElementById("popup-modal-lecture");
                        if(elm){
                            elm.classList.add("lecture-page-pop-disp");
                        }
                    },30000);  
                   }                        
            }

            $scope.baseValues = function (chapid, cid) {
                $scope.LPChapid = chapid;
                $scope.LPCid = cid;
            };
            playLecturePageVideo = function () {
                $scope.showVideo = 1;
                $scope.showCrsPrev = 1;
                $scope.videoState = '';
            }

            $scope.showTranscriptCentreSection = function () {
                var elem = angular.element(document.getElementsByClassName('lecture_fancy_box_close'));
                setTimeout(function() {
                    elem[0].click();
                }, 0);
            }

            $scope.videoComplete = function (pState) {
                if(pState && pState.data == YT.PlayerState.ENDED) {
                    $scope.showCrsPrev = 0;
                    $scope.$apply();
                }
            }

            $scope.hidePreview = function () {
                $scope.showVideo = 0;
                $scope.videoState = 'pause';
            };
            
            $scope.closePopupLect = function (course_id) {
                document.getElementById('popup-modal-lecture').style.display = 'none';
                var cname = 'lecture_popup_cookie';
                var cvalue = course_id;
                var exdays =365;
                setCookie(cname, cvalue, exdays);
            };
                        
            $scope.goToCourseLect = function($event,course_id){ 
                  var cname = 'lecture_popup_cookie';
                  var cvalue = course_id;
                  var exdays =365;
                  setCookie(cname, cvalue, exdays);
            };
     
             // new js 
            
             $scope.closeModalUp = function () {
                var displayStyle = null;
                $scope.stopPopup = 1;
                clearTimeout($scope.popuptimer);
                $scope.popuptimer = null;
                angular.element(document.body).removeClass("modal-open");
                var elem = document.getElementById("popup-modal-lecture");
                if (elem.currentStyle) {
                    displayStyle = elem.currentStyle.display;
                } else if (window.getComputedStyle) {
                    displayStyle = window.getComputedStyle(elem, null).getPropertyValue("display");
                }
                if (displayStyle.localeCompare($scope.displayStyle) == 0) {
                    document.getElementById("popup-modal-lecture").style.display = "none";
                }
                //console.log("Popup closed");

            }
            
            $scope.loadPopup = function () {
                angular.element(document.body).addClass("modal-open");
                document.getElementById($scope.popupIdentifier).style.display = "block";
                return;
            }
            $scope.popMinimize = function(){
                    angular.element(document.getElementsByClassName('popup-body')).addClass("minimizedPopup");
            }
           
            $scope.stopPopUpModal = function (title) {
                var displayStyle = null;
                $scope.stopPopup = 1;
                clearTimeout($scope.popuptimer);
                $scope.popuptimer = null;
                angular.element(document.body).removeClass("modal-open");
                var elem = document.getElementById("popup-modal-lecture");
                if (elem.currentStyle) {
                    displayStyle = elem.currentStyle.display;
                } else if (window.getComputedStyle) {
                    displayStyle = window.getComputedStyle(elem, null).getPropertyValue("display");
                }
                if (displayStyle.localeCompare($scope.displayStyle) == 0) {
                    document.getElementById("popup-modal-lecture").style.display = "none";
                }
                if ($scope.stopSmallPopUp !== 1) {
                    console.log("Popup Closed On User Request");
                    document.getElementById('side-popup').style.display = 'block';
                    $timeout(function(){
                        document.getElementById('side-popup').style.bottom = '10px';
                    },500);
                }
                var type = $scope.type;
                var title = title;
                if(type = 'ebook'){
                    type = 'new course popup';
                    title = $scope.title_link;
                }
                if($scope.isFirstTime == true){
                    var eventObj = {
                        'eventType': 'detailViewPersistentPopSeen',
                        'label': user_params.user_id + ' || ' + type + ' || ' + document.URL + ' || '+ title
                    };
                }else{
                    var eventObj = {
                        'eventType': 'detailViewPersistentPopupCancel',
                        'label': user_params.user_id + ' || ' + type + ' || from persistent popup' + ' || ' + document.URL + ' || '+ title
                    };
                }
                CaldonGA.triggerEvent.gagInitiate(eventObj);

            };
            
            
             // end new js 
            
            
            $scope.resumeVideo = function (isFromElearning) {
                if(isFromElearning) {
                    angular.element(document.getElementsByClassName('special-video-iframe')).attr('src', angular.element(document.getElementsByClassName('special-video-iframe')).attr('src'));
                    $rootScope.showHideDivsLP(0, 1);
                } else {
                    var centreButtons = document.getElementsByClassName('centre_view_transcript');
                    var relevantCentre = centreButtons[$scope.divCounterForLecturePage];
                    var closeBtn = document.getElementsByClassName('lecture_fancy_box_close')[0];
                    closeBtn.click();
                    relevantCentre.click();
                }
            }

            $scope.likeCount = function (type) {
                var cookieVal = 'LPliked_' + $scope.LPCid + '_' + $scope.LPChapid;
                var likeCheck = 'LPliked_1_' + $scope.LPCid + '_' + $scope.LPChapid;
                var unlikeCheck = 'LPliked_0_' + $scope.LPCid + '_' + $scope.LPChapid;
                if (!getCookie(cookieVal)) {
                    if (type == 1) {
                        var likeParams = {'method':'lecturePageCount','type':'like','chap_id':$scope.LPChapid,'course_id':$scope.LPCid};
                        PostReqService.sendPostRequest(baseApiUrlNocache,likeParams);
                        $scope.LPLike++;
                        $scope.likedClass = 'active-icon';
                        setCookie(likeCheck, 1, 365);
                    } else if (type == 0) {
                        var unlikeParams = {'method':'lecturePageCount','type':'unlike','chap_id':$scope.LPChapid,'course_id':$scope.LPCid};
                        PostReqService.sendPostRequest(baseApiUrlNocache,unlikeParams);
                        $scope.LPDislike++;
                        $scope.dislikeClass = 'active-icon';
                        setCookie(unlikeCheck, 1, 365);
                    }
                    setCookie(cookieVal, 1, 365);
                }
            }

            setCookie = function (cname, cvalue, exdays) {
                var d = new Date();
                d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
                var expires = "expires=" + d.toUTCString();
                document.cookie = cname + "=" + cvalue + "; " + expires+';SameSite=Lax;';
            }
            getCookie = function (cname) {
                var name = cname + "=";
                var ca = document.cookie.split(';');
                for (var i = 0; i < ca.length; i++) {
                    var c = ca[i];
                    while (c.charAt(0) == ' ')
                        c = c.substring(1);
                    if (c.indexOf(name) == 0)
                        return c.substring(name.length, c.length);
                }
                return "";
            }

            $scope.expandChapList = function (val) {
                angular.element(document.getElementsByClassName('lecture_page_mview')).removeClass('lecture_page_mview')
                status = status != '' ? status : val;
                if (status == 1) {
                    $scope.mobileView = 1;
                    status = 0;
                } else if (status == 0) {
                    $scope.mobileView = 0;
                    status = 1;
                }
            }

            var gaForLecturePage = function () {
                var ga = new gaEventsTracker();

                this.LecturePage_Watch_Course_Video = function () {
                    ga.gaFireInteractiveEvents('LecturePage_Watch_Course_Video');
                }
                this.LecturePage_View_Course_Detail = function (val) {
                    ga.gaFireInteractiveEvents('LecturePage_View_Course_Detail', val);
                }
                this.LecturePage_Click_Related_Course = function (val) {
                    ga.gaFireInteractiveEvents('LecturePage_Click_Related_Course', val);
                }
                this.LecturePage_Click_Webinar = function (val) {
                    ga.gaFireInteractiveEvents('LecturePage_Click_Webinar', val);
                }
                this.LecturePage_Click_Related_Article = function (val) {
                    ga.gaFireInteractiveEvents('LecturePage_Click_Related_Article', val);
                }
                this.LecturePage_Click_Other_Chapter = function (val) {
                    ga.gaFireInteractiveEvents('LecturePage_Click_Other_Chapter', val);
                }
                this.LecturePage_Scroll_Related_Course = function (val) {
                    ga.gaFireInteractiveEvents('LecturePage_Scroll_Related_Course', val);
                }
                this.LecturePage_Scroll_Learner_Review = function (val) {
                    ga.gaFireInteractiveEvents('LecturePage_Scroll_Learner_Review', val);
                }
                this.LecturePage_Scroll_Webinar = function (val) {
                    ga.gaFireInteractiveEvents('LecturePage_Scroll_Webinar', val);
                }
                this.LecturePage_Scroll_Related_Article = function (val) {
                    ga.gaFireInteractiveEvents('LecturePage_Scroll_Related_Article', val);
                }
                this.LecturePage_Click_Reviewer_Prfile = function (val) {
                    ga.gaFireInteractiveEvents('LecturePage_Click_Reviewer_Prfile', val);
                }
                this.LecturePage_Expand_Topic = function (val) {
                    ga.gaFireInteractiveEvents('LecturePage_Expand_Topic', val);
                }
                this.LecturePage_Collapse_Topic = function (val) {
                    ga.gaFireInteractiveEvents('LecturePage_Collapse_Topic', val);
                }
                this.LecturePage_Is_it_helpful = function (val) {
                    ga.gaFireInteractiveEvents('LecturePage_Is_it_helpful', val);
                }
                this.LecturePage_View_Topic_Video = function (val) {
                    ga.gaFireInteractiveEvents('LecturePage_View_Topic_Video', val);
                }
                this.LecturePage_Click_Course_Detail_from_Video = function (val) {
                    ga.gaFireInteractiveEvents('LecturePage_Click_Course_Detail_from_Video', val);
                }

            }

            $scope.lecturePageGa = new gaForLecturePage();

            $scope.onEscape = function (block) {
                if (block == 1) {
                    $scope.hidePreview();
                }
            }

            $scope.clickCentreCourseLinks = function () {
                angular.element(document.getElementsByClassName('centre_course_nav')).on('click', function () {
                    angular.element(document.getElementsByClassName('lhs_course_btn'))[0].click();
                })
            }
            $scope.clickCentreCourseLinks();

            $scope.setLecturePreviewTitle = function (title, counter) {
                $scope.lectureCoursePreviewTitle = title;
                $scope.divCounterForLecturePage = counter;
            }

            setTimeout(function () {
                var likeCheck = 'LPliked_1_' + $scope.LPCid + '_' + $scope.LPChapid;
                var unlikeCheck = 'LPliked_0_' + $scope.LPCid + '_' + $scope.LPChapid;
                if (getCookie(likeCheck)) {
                    $scope.likedClass = 'active-icon';
                } else if (getCookie(unlikeCheck)) {
                    $scope.dislikeClass = 'active-icon';
                }

                $http.get(baseApiUrlNocache + "?method=lecturePageLikes&chap_id=" + $scope.LPChapid + "&course_id=" + $scope.LPCid)
                        .success(function (data, status) {
                            if (data != false) {
                                $scope.LPLike = data['likes'];
                                $scope.LPDislike = data['unlikes'];
                            } else {
                                $scope.LPLike = 0;
                                $scope.LPDislike = 0;
                            }
                        })
            }, 1000);

            $scope.setVideoParams = function(elearningId, lessons, lessonObj, sectionId, isFromELearning, url, videoType) {
                $scope.elearningId = elearningId;
                $scope.lessons = lessons;
                $scope.lessonObj = lessonObj;
                $scope.sectionId = sectionId;
                $scope.isFromELearning = isFromELearning;
                $scope.url = url;
                $scope.videoType = videoType;
                $scope.playLectureVideo();
            }
            $scope.playLectureVideo = function() {
                $timeout(function() {
                    return CpService.handleVideoLinkClick($scope.elearningId, $scope.lessons, $scope.lessonObj, $scope.sectionId, $scope.isFromELearning, $scope.url, $scope.videoType, $cookies[user_params.enterpriseCountCookieName]);
                });
            }
                init();
        });