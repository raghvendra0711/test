angular.module('Simplilearn')
.controller('HeaderController', function($scope,$rootScope, $http,LocService,$cookies,$location,$timeout,PostReqService,$compile) {
	$scope.scroll=0;
	$scope.headerHeight = 2;
	$scope.showStickyHeader = {'display':'none'};
	$scope.showStatus = false;
	$scope.headerFormsStyle = {'display':'none'};
	$scope.loginFormStyle = {'display':'none'};
	$rootScope.registerFormStyle = {'display':'none'};
	$scope.loginFormHeadingStyle = {'display':'none'};
	$scope.registerFormHeadingStyle = {'display':'none'};
	$scope.showPlaceholder = false;
	$scope.showCountryDropDown = false;
	$scope.act_chng_cntry = "";
	$scope.fl_city_lst = "";
	$scope.loggedOut = {'display':'none'};
	$scope.loggedIn = {'display':'none'};
	$scope.usrListStyle={'display':'none'};
	$scope.showAutoCompleteDiv = {'display':'none'};
    $scope.searchResults = [];
	$scope.showCountryList = false;
	$scope.isStickyFlag = 0;
	$scope.countryData = null;
        $scope.currentCountry = null;
	$scope.countryFormData = null;
        $scope.countryFormDataMob = null;
        $scope.isMobileMenuVisible = false;
	$scope.helpers = new helpers();
        $scope.delayedCountryListCreated = false;
        $scope.countryDataHeaderDropDown = {};
        $scope.isSearchVisible = 0;
        $scope.showStatus = true;
        $scope.noteClass = false;
        $scope.linkedinMsg = 'Sign in';
        $scope.linkedinErrMsg = '';
        $scope.linkedErrClass = '';
        $scope.showCrossBtn = true;
        $scope.forgotPassSpin = false;
        $scope.cart_count = 0;
        var timeoutId = null;
        $rootScope.searchIsSearchVisible = false;
        $scope.cart_count = '';
        $scope.isEuro = user_params.isEuro;
	$scope.headerInit = function(supportNoDail,supportNo) {
            if(typeof supportNo !='undefined' && supportNo !=''){
                $rootScope.supportNo = supportNo;
                $rootScope.supportNoDail = supportNoDail;
            }
            if($cookies[user_params.ssoCookieName]){
                $rootScope.isLoggedIn = true;
            }

            $rootScope.lms_url = ($cookies['lms_url']) ? $cookies['lms_url'] : baseLmsUrl;

            if( !!$location.path() ) {
                var path = $location.path();
                path = path.substr(path.indexOf('/')+1);

                setTimeout(function(){
                    if(path == 'signup' && $rootScope.isLoggedIn != true){
                       angular.element(document.getElementById('registerBtn')).triggerHandler('click');
                    }else if(path == 'login' && $rootScope.isLoggedIn != true){
                        angular.element(document.getElementById('login_btn')).triggerHandler('click');
                    }
                },1000);

            }

            if ($rootScope.isLoggedIn == true) {
                $rootScope.gaHeaderControllerJs.gaFireOnAutoLogin();
                // Get user information
                if(typeof user_params.user_id == 'undefined'){
                    PostReqService.getUserData(function(user) {
                        if(user !== null && typeof user == 'object') {
                            user_params.user_id = user.id;
                            user_params.email = user.email;
                        }
                    });
                }
                $scope.loggedIn = {'display': 'inline-block'};
                PostReqService.initFreeTrialCookie();
            } else {
                $scope.loggedOut = {'display': 'inline-block'};
            }



            if(user_params.isB2b == 1){
                if($cookies[user_params.cartCountCookieb2b] && $cookies[user_params.sessionCookie]) {
                    $scope.cart_count = $cookies[user_params.cartCountCookieb2b] > 0 ? $cookies[user_params.cartCountCookieb2b] : '';
                }
            }else{
                if($cookies[user_params.cartCountCookie] && $cookies[user_params.sessionCookie]) {
                    $scope.cart_count = $cookies[user_params.cartCountCookie] > 0 ? $cookies[user_params.cartCountCookie] : '';
                }
            }
            setTimeout(function(){
                    loadLoginHtml();
                    checkFreeTrial();
            },2000);
            checkFreeTrial();
        }

        var checkFreeTrial= function(){
          var free_trial = ($cookies[user_params.ftCookieName]) ? $cookies[user_params.ftCookieName] : false;
          var utm_source_block_ft = user_params.ftUtmBlocked.split(',');
          var utmcsr = getParameterByName('utm_source');
          var atpParam = getParameterByName(user_params.ftATPParam);
          if((typeof free_trial != 'undefined' && free_trial && free_trial != '') || (utmcsr!='' && utm_source_block_ft.indexOf(utmcsr.toLowerCase()) > -1) || (atpParam!='')) {
            var btns = document.getElementsByClassName( 'enroll-btn' );
            var ftVals = document.getElementsByName( 'free_trial' );
            var enrollText = 'Enroll Now';
            [].slice.call( btns ).forEach(function ( elem ) {
                elem.innerHTML = enrollText;
            });
            [].slice.call( ftVals ).forEach(function ( elem ) {
                elem.value = 0;
            });
            if(document.getElementById('sticky-enroll-btn')) {
                document.getElementById('sticky-enroll-btn').innerHTML = enrollText;
            }
          }
        }

        $scope.init_enterprise = function(val) {
            if($cookies[user_params.enterpriseCountCookieName] == undefined || $cookies[user_params.enterpriseCountCookieName] == ''){
                if(val != '' ){
                    setEntpCookie(val);
                }
            } else {
                var entp = $cookies[user_params.enterpriseCountCookieName];
                entp = entp.split('|^|');
                var companyData = val.split('|^|');
                if(entp[0] != '' && companyData[0] != '' && entp[0] != companyData[0]){
                    setEntpCookie(val);
                }
                // if(entp != undefined && entp.length > 0 && entp[2] != ''){
                //     var urlVal = window.location.href;
                //     urlVal = urlVal.toLowerCase();
                //     var n = urlVal.search(entp[0]);
                //     if(n == -1){
                //         var urlMore = urlVal.search(baseUrl.replace(/^\/|\/$/g, ''));
                //         //console.log(entp[2],entp[2] + '/'+urlVal.substring(urlMore + baseUrl.length - 1));
                //         window.location.href = entp[2] + '/'+urlVal.substring(urlMore + baseUrl.length-1);
                //     }
                // }
            }
        }
        var loadLoginHtml = function(){
            var urlObj = $scope.helpers.makeValidApiUrl('loginForm');
            var paramsArr = {};
            $http.get(urlObj.url+"&country="+ipCountryIdValue, paramsArr)
            .success(function (response) {
                if(response && typeof response !='undefined' && response != ''){
                    angular.element(document.getElementById('login-register')).html(response);
                    $compile(angular.element(document.getElementById('login-register')).contents())($scope);
                    setTimeout(function(){
                        var userLogin = document.getElementById('login-name');
                        if(userLogin){
                            userLogin.addEventListener("keyup", function(){
                                $rootScope.gaHeaderControllerJs.gaFireOnInitiate('login');
                            });
                        }
                        var userRegister = document.getElementById('register-name');
                        if(userRegister){
                            userRegister.addEventListener("keyup", function(){
                                $rootScope.gaHeaderControllerJs.gaFireOnInitiate('register');
                            });
                        }
                    },2000);

                }
            });
        }
        var setEntpCookie = function(val){
            var date = new Date();
                    date.setTime(date.getTime() + (90 * 24 * 60 * 60 * 1000));
                    document.cookie = user_params.enterpriseCountCookieName+'=' + val + '; expires=' + date.toGMTString() + '; path=/;domain=.simplilearn.com;SameSite=Lax;';
        }

            $scope.showLogin = function($event) {
                if($event) {
                    $event.preventDefault();
                }
                $scope.clearLinkedinMsg();
                $rootScope.regStatusMsg = ""
                $rootScope.regStatusClass = "";
                $rootScope.regSuccessMsg = "";
                $rootScope.regSuccessClass = "";
                $scope.showStatus = true;
                $scope.noteClass = false;
                $scope.loginClass = 'login-section-page';
                $scope.linkedinMsg = 'Sign in';
                $scope.loginFormStyle = {'display': 'inline-block'};
                $rootScope.registerFormStyle = {'display': 'none'};
				$scope.loginFormHeadingStyle = {'display':'block'};
				$scope.registerFormHeadingStyle = {'display':'none'};
                $scope.headerFormsStyle = {'display': 'block'};
                $scope.loginRegFormStyle = {'display': 'block'};
                $scope.forgotPwdStyle = {'display': 'none'};
                $scope.showCrossBtn = true;
                //@review missing return statement
            }
            $scope.clearLinkedinMsg = function(){
                $scope.linkedinErrMsg = '';
                $scope.linkedErrClass = '';
            }
            var gaForHeader = function() {
                var ga = new gaEventsTracker();
                this.hoveredOnFlag = true;

                this.gaFireOnCountryChangeSuccess = function(changeToCountry) {
                    ga.gaFireInteractiveEvents('crosseventscountrychangesuccess', user_params.user_id + ' || ' + document.URL + ' || ' + $scope.currentCountry.name  + ' || ' + changeToCountry);
                }

                this.changeHoverFlag = function() {
                    if(this.hoveredOnFlag == false) {
                        this.hoveredOnFlag = true;
                    } else {
                        this.hoveredOnFlag = false;
                    }
                }

                this.gaFireOnCorporateTrainingClick = function($event) {
                    ga.gaFireInteractiveEvents('headercorporatelinkclick', user_params.user_id + ' || ' + document.URL + ' || ' + $event.target.href);
                }
                this.gaFireOnBeInstructorClick = function($event) {
                    ga.gaFireInteractiveEvents('headerinstructorlinkclick', user_params.user_id + ' || ' + document.URL + ' || ' + $event.target.href);
                }

                this.gaFireOnLoginTabOpen = function() {
                    $rootScope.currentLoginOpenTab = 'login';
                    ga.gaFireInteractiveEvents('crosseventsloginopen', document.URL);
                    WebTracking.eventReq.triggerEvent({
                        event_id: "sl_user_clicks_on_Login",
                        common: "product",
                    });
                }
                this.gaFireOnSignupTabOpen = function() {
                    $rootScope.currentLoginOpenTab = 'signup';
                    ga.gaFireInteractiveEvents('crosseventsloginsignupclick');
                }
                var eventStatus = {'login':false,'register':false};
                this.gaFireOnInitiate = function(form) {
                    if(!eventStatus[form]) {
                        ga.gaFireInteractiveEvents('loginsignupinitiated', document.URL + ' || ' + form);
                        eventStatus[form] = true;
                    }
                }
                this.gaFireOnAutoLogin = function() {
                    ga.gaFireInteractiveEvents('autologin', document.URL);
                }
                this.gaFireOnLoginSignupAttempt = function(type) {
                    if(type == 'linkedin')
                        ga.gaFireInteractiveEvents('linkedinloginclick', document.URL + ' || ' + type);
                    else
                        ga.gaFireInteractiveEvents('loginsignupsubmitted', document.URL + ' || ' + type);
                }

                this.gaFireOnLoginSignupSuccess = function(type) {
                    if($rootScope.currentLoginOpenTab == 'signup') {
                        ga.gaFireInteractiveEvents('crosseventsloginsignupsuccess', type);
                    } else if($rootScope.currentLoginOpenTab == 'login') {
                        ga.gaFireInteractiveEvents('crosseventsloginsuccess', type);
                    }
                }
                this.gaFireOnLoginSignupFailure = function(type) {
                    if($rootScope.currentLoginOpenTab == 'signup') {
                        ga.gaFireInteractiveEvents('crosseventsloginsignupfailure', type);
                    } else if($rootScope.currentLoginOpenTab == 'login') {
                        ga.gaFireInteractiveEvents('crosseventsloginfailure', type);
                    }
                }
                this.gaFireMyCourseClick = function () {
                    ga.gaFireInteractiveEvents('myCourseClickGeneric', user_params.user_id + ' || ' + document.URL);
                    var eventData = WebTracking.eventReq.getDataFromUserParams(['sl_product_id', 'sl_product_name','sl_product_category','sl_product_category_id','sl_event_time','sl_page_type','sl_user_type','sl_product_training_type','sl_product_type','']);
                    WebTracking.eventReq.triggerEvent({
                        event_id: "sl_user_clicks_on_my_courses",
                        event_data: eventData,
                    });
                }
                this.gaFireOnLogoutClick = function () {
                    ga.gaFireInteractiveEvents('onLogoutClickGeneric', user_params.user_id + ' || ' + document.URL);
                    var eventData = WebTracking.eventReq.getDataFromUserParams(['sl_product_id', 'sl_product_name','sl_product_category','sl_product_category_id','sl_event_time','sl_page_type','sl_user_type','sl_product_training_type','sl_product_type','']);
                    WebTracking.eventReq.triggerEvent({
                        event_id: "sl_user_logs_out",
                        event_data: eventData,
                    });
                }
                this.gaRequestMoreInfoClick = function (siteModule) {
                    ga.gaFireInteractiveEvents('gsaleadformclick', user_params.user_id + ' || ' + document.URL + ' || ' + siteModule);
                }
                this.gaViewMoreTestimonials = function($event) {
                    ga.gaFireInteractiveEvents('gsapageViewMoreTestimonials', user_params.user_id + ' || ' + document.URL + ' || ' + $event.target.href);
                }
            }
            $rootScope.gaHeaderControllerJs = new gaForHeader();


            $scope.closeLogin = function($event) {
                if(typeof $event !='undefined' && $event != null)
                    $event.preventDefault();

                $scope.showStatus = false;
                $rootScope.isCpClicked = 0;
                //@review missing return statement
            }
            $scope.$watch('showStatus', function(newValue) {
                if (newValue == false) {
                    $scope.loginFormStyle = {'display': 'none'};
                    $rootScope.registerFormStyle = {'display': 'none'};
					$scope.loginFormHeadingStyle = {'display':'none'};
					$scope.registerFormHeadingStyle = {'display':'none'};
                    $scope.headerFormsStyle = {'display': 'none'};
                    $scope.forgotPwdStyle = {'display': 'none'};
                }
                //@review missing else
            });
            $scope.showRegister = function($event) {
                if($scope.delayedCountryListCreated == false) {
                    $scope.countryDataHeaderDropDown = $scope.countryData;
                    $scope.delayedCountryListCreated = true;
                }
                $event.preventDefault();
                $scope.clearLinkedinMsg();
                $scope.showStatus = true;
                $rootScope.regSuccessMsg = "";
                $rootScope.registerFormStyle = {'display': 'inline-block'};
                $scope.loginFormStyle = {'display': 'none'};
                $scope.headerFormsStyle = {'display': 'block'};
				$scope.loginFormHeadingStyle = {'display':'none'};
				$scope.registerFormHeadingStyle = {'display':'block'};
				$scope.forgotPwdStyle = {'display': 'none'};
				$scope.loginRegFormStyle = {'display': 'block'};
				$rootScope.regStatusMsg = ""
				$rootScope.regStatusClass = "";
                                $rootScope.regSuccessMsg = "";
                                $rootScope.regSuccessClass = "";
                                $scope.loginClass = '';
                                $scope.linkedinMsg = 'Sign up';
                                $scope.noteClass = true;
				if(typeof $event.srcElement == 'undefined'){
					var targetEle = $event.target;
				}else{
					var targetEle = $event.srcElement;
				}

				(angular.element(targetEle).parent().parent().parent().parent())[0].focus();
                                $scope.showCrossBtn = true;
                //@review missing return statement
            }

            $scope.setSearchVisibility = function(pVal) {
                if(!pVal) {
                    timeoutId = $timeout(function() {
                        $scope.isSearchVisible = pVal;
                    }, 200);
                } else {
                    $scope.isSearchVisible = pVal;
                    if(timeoutId) {
                        $timeout.cancel(timeoutId);
                        timeoutId = null;
                    }
                }
            };

            $scope.shCntryDrpDwnFunc = function() {
                $scope.showCountryDropDown = true;
                $scope.act_chng_cntry = "active";
                //@review missing return statement
                if($scope.delayedCountryListCreated == false) {
                    $scope.countryDataHeaderDropDown = $scope.countryData;
                    $scope.delayedCountryListCreated = true;
            }
            }
            $scope.hdCntryDrpDwnFunc = function() {
                $scope.showCountryDropDown = false;
                $scope.fl_city_lst = "";
                $scope.act_chng_cntry = "";
                $rootScope.gaHeaderControllerJs.changeHoverFlag();
            }
            $scope.shUsrListFunc = function() {
                $scope.usrListStyle = {'display': 'block'};
                //@review missing return statement
            }
            $scope.hdUsrListFunc = function() {
                $scope.usrListStyle = {'display': 'none'};
                //@review missing return statement
            }
			$scope.toggleUsrAccList = function($event){
				$event.preventDefault();
				if($scope.usrListStyle.display == 'block'){
					$scope.usrListStyle = {'display': 'none'};
				}else{
					$scope.usrListStyle = {'display': 'block'};
				}
			}
            $scope.shFlCityLst = function() {
                $scope.fl_city_lst = "display:inline-block";
                $scope.showCountryList = false;
                //@review missing return statement
            }
            $scope.shForgtPwd = function($event) {
                $event.preventDefault();
                $scope.forgotPwdStyle = {'display': 'block'};
                $scope.loginFormStyle = {'display': 'none'};
                $rootScope.registerFormStyle = {'display': 'none'};
                $scope.loginRegFormStyle = {'display': 'none'};
                $scope.headerFormsStyle = {'display': 'block'};
                $scope.showCrossBtn = false;
                $scope.forgotPwdClass = '';
                $scope.forgotPwdMsg = '';
				(angular.element($event.srcElement).parent().parent().parent().parent())[0].focus();
                //@review missing return statement
            }
            $scope.logoutUser = function($event) {
                $event.preventDefault();
                var logoutParams = {'method': 'signout'};
                PostReqService.sendPostRequest(baseApiUrlNocache, logoutParams)
                        .then(function(data) {
                            if (data == null) {
                            } else {
                                //Below is the fix for help-and-support page.
                                if (typeof user_params.pageCategory != 'undefined' && user_params.pageCategory == 'help-and-support_createticket') {
                                    window.location.reload();
                                }
                                $rootScope.isLoggedIn = false;
                            }          
                        });
            }

            $scope.toggleMobileMenu = function() {
                if( $scope.isMobileMenuVisible === false ) {
                    $scope.isMobileMenuVisible = true;
                    if($scope.delayedCountryListCreated == false) {
                        $scope.countryDataHeaderDropDown = $scope.countryData;
                        $scope.delayedCountryListCreated = true;
                }
                }
                else {
                    $scope.isMobileMenuVisible = false;
                }
            };

            $rootScope.$watch('isLoggedIn', function(newValue) {
                if (newValue == true) {
                    $scope.loggedIn = {'display': 'inline-block'};
                    $scope.loggedOut = {'display': 'none'};
                    $scope.loginFormStyle = {'display': 'none'};
                    $rootScope.registerFormStyle = {'display': 'none'};
                    $scope.headerFormsStyle = {'display': 'none'};
                } else {
                    $scope.loggedOut = {'display': 'inline-block'};
                    $scope.loggedIn = {'display': 'none'};
                    $scope.loginFormStyle = {'display': 'none'};
                    $rootScope.registerFormStyle = {'display': 'none'};
                    $scope.headerFormsStyle = {'display': 'none'};
                    $scope.usrListStyle={'display':'none'};
                }
                //@review missing return statement
            });

            $scope.submitForgotPwdForm = function(form) {
                if (form.$invalid) {
                    return $scope.helpers.FormNotValid(form);
                }
                $scope.forgotPassSpin = true;
                var passParams = {'method': 'forgotPwd', 'email': $scope.forgotPwdEmail};
                PostReqService.sendPostRequest(baseApiUrlNocache, passParams)
                        .then(function(data, status, header, config) {
                            if (data == null) {
                                $scope.forgotPwdClass = "error";
                                $scope.forgotPwdMsg = "Some error occured. Please try again later.";
                                $scope.forgotPassSpin = false;
                            } else if (data.data.data.type == 'success') {
                                $scope.forgotPwdEmail = "";
                                $scope.forgotPwdClass = "success_text";
                                $scope.forgotPwdMsg = data.data.data.msg;
                                $scope.forgotPwdForm.$setPristine();
                                setTimeout(function() {
                                    $scope.showStatus = false;
                                    $scope.$apply();
                                }, 2000);
                            } else {
                                $scope.forgotPwdClass = "error";
                                $scope.forgotPwdMsg = data.data.data.msg;
                            }
                            $scope.forgotPassSpin = false;
                        });
                //@review missing return statement in async trigger
            };

            $scope.init_CountryData = function(pCountryId) {
                setTimeout(function(){
                    LocService.getCountryData().then(function(data) {
                        $scope.countryData = data;

                        LocService.setCurrentCountry(null, pCountryId);
                        $scope.currentCountry = LocService.getCurrentCountry();
                        $scope.mobCountry = $scope.currentCountry;
                    });
                },2000);

                return true;
            };

            $scope.updateMobCntry = function(){
                document.getElementById('countryId').value = $scope.mobCountry.id;
                document.getElementById('locationFormMob').submit();
            };

            $scope.submitCountry = function(pCountry) {
                $rootScope.gaHeaderControllerJs.gaFireOnCountryChangeSuccess(pCountry.name);
                $scope.countryFormData = {"countryId": pCountry.id};
            }

            $scope.toggleCountry = function(){
                if($scope.showCountryDropDown){
                    $scope.hdCntryDrpDwnFunc();
                }else{
                    $scope.shCntryDrpDwnFunc();
                }
            }

			$rootScope.stickyHeaderSearchVisible = 0;
			$rootScope.stickyHeaderSearchDisplay = {'display':'none'};

			$rootScope.innerPageHeaderSearch = 0;
			$rootScope.innerPageHeaderSearchDisplay = {'display':'none'};

			$rootScope.toggleStickyHeaderSearch = function($event){
				$event.preventDefault();
				if($rootScope.stickyHeaderSearchVisible == 0){
					$rootScope.stickyHeaderSearchVisible = 1;
					$rootScope.stickyHeaderSearchDisplay = {'display':'block'};
				}else{
					$rootScope.stickyHeaderSearchVisible = 0;
					$rootScope.stickyHeaderSearchDisplay = {'display':'none'};
				}
			}

			$rootScope.toggleInnerPageHeaderSearch = function($event){
				$event.preventDefault();
				if($rootScope.innerPageHeaderSearch == 0){
					$rootScope.innerPageHeaderSearch = 1;
					$rootScope.innerPageHeaderSearchDisplay = {'display':'block'};
				}else{
					$rootScope.innerPageHeaderSearch = 0;
					$rootScope.innerPageHeaderSearchDisplay = {'display':'none'};
				}
			}

                        // fire login popup if not login
                        var full_current_url = window.location.pathname.split( '/' );

                        $scope.jobAssistLoginCheck = function(){
                            if(angular.isUndefined($cookies[user_params.ssoCookieName])){
                                $scope.gaHeaderControllerJs.gaFireOnLoginTabOpen();
                                $scope.showLogin();
                            }
                        };

//                        if(full_current_url.indexOf('job-assist') !== -1) {
//                            $timeout(function () {
//                                $scope.jobAssistLoginCheck();
//                            }, 2000);
//                        };

                        //call this function from other controller - JobAssistController
                          $rootScope.$on("loginPopup", function(){
                                $scope.jobAssistLoginCheck();
                          });

                        window.onpageshow = function (event) {
                            if (event.persisted) {
                                window.location.reload()
                            }
                        };




        })
        .controller('LoginFormController', function($scope, $rootScope, LoginService, PostReqService) {
            $scope.userName = '';
            $scope.userPwd = '';
            $scope.requestSent = false;
            $scope.buttonText = 'Log In';
            $scope.submitLogin = function() {
				if($scope.loginForm.$invalid){
					if(typeof $scope.loginForm.userName.$viewValue == 'undefined' || $scope.loginForm.userName.$viewValue == "")
						$scope.loginForm.userName.$setViewValue($scope.loginForm.userName.$viewValue);
					if(typeof $scope.loginForm.userPwd.$viewValue == 'undefined' || $scope.loginForm.userPwd.$viewValue == "")
						$scope.loginForm.userPwd.$setViewValue($scope.loginForm.userPwd.$viewValue);

					$scope.loginStatusMsg = "Oops! Please ensure all fields are valid.";
					$scope.loginStatusClass = "error oops-error hidden";
					return false;
				}else{
                                    $scope.buttonText = 'Authenticating...';
                                    $scope.requestSent = true;
                                    $rootScope.gaHeaderControllerJs.gaFireOnLoginSignupAttempt('email');

                                        LoginService.login($scope.userName, $scope.userPwd)
                                        .then(function(response){
                                            var data = response.data;
                                            if (data.status == 'error') {
						$scope.loginStatusMsg = data.msg; //"Oops! Please ensure username/password is valid."
                                                $rootScope.gaHeaderControllerJs.gaFireOnLoginSignupFailure('email | ' + $scope.loginStatusMsg);
						$scope.loginStatusClass = "error";
						if (typeof user_params.pageCategory != 'undefined' && user_params.pageCategory == 'help-and-support_index') {
//                                                    notifyHelpAndSupport();
						}
                                            } else {
                                                $rootScope.gaHeaderControllerJs.gaFireOnLoginSignupSuccess('email');
						user_params.email = $scope.userName;
						user_params.user_id = data.data.id;
						$rootScope.isLoggedIn = true;
                                                $rootScope.lms_url = (data.lms_url !== undefined) ? data.lms_url : baseLmsUrl;
                                                $rootScope.$emit('isLoggedIn', true);
                                                PostReqService.initFreeTrialCookie();
//Below is the fix for help-and-support page.
                                                if (typeof user_params.pageCategory != 'undefined' && (user_params.pageCategory == 'help-and-support_index' || user_params.pageCategory == 'help-and-support_salesforce-support-form')) {
						  window.location.reload();
						}
                                                else if (window.refurl != 'undefined' && typeof window.refurl == 'object') {
                                                    if (typeof window.refurl.host != 'undefined' && window.refurl.host != '' && typeof window.refurl.source != 'undefined' && window.refurl.source != '') {
                                                        if (window.refurl.host == 'community.simplilearn.com') {
                                                            window.location.href = window.refurl.source;        //after success signup redirect to community page
                                                        } else if (window.refurl.host == 'lms.simplilearn.com') {
                                                            window.location.href = window.refurl.source;        //after success signup redirect to lms page
                                                        }
                                                    }
                                                }

                                            }
                                $scope.requestSent = false;
                                $scope.buttonText = 'Log In';
                                        });

				}
            };

            $scope.$parent.$watch('loginFormStyle', function(newValue) {
                if (typeof newValue != 'undefined' && newValue.display == 'none') {
                    $scope.loginForm.$setPristine();
                    $scope.userName = '';
                    $scope.userPwd = '';
                    $scope.loginStatusClass = '';
                    $scope.loginStatusMsg = '';
                }
            });

    /*
    $scope.$watch('userName', function(newValue) {
        var email_rgx = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

        if( !email_rgx.test(newValue) ){
            $scope.loginForm.userName.$setValidity('email', false);
        }
        else {
            $scope.loginForm.userName.$setValidity('email', true);
        }
    });
    */


        }).controller('RegisterFormController', function($scope,$rootScope,$cookies, HashLogicService, $timeout,PostReqService) {

    $scope.callingCode = "+91-";
    $scope.city = typeof $cookies.locatori9 != "undefined" && $cookies.locatori9 ? JSON.parse($cookies.locatori9).name: '';
    $scope.userCountry = 34;
    $scope.contactNum = "";
    $scope.firstName = "";
    $scope.lastName = "";
	$scope.agreeClicked=0;
	$scope.helpers = new helpers();
        $scope.termsnConditions = 0;

        $scope.$watch(function() {
            return $rootScope.queryPhoneCode;
          }, function(newVal) {
            if(typeof newVal != 'undefined' && newVal != ''){
                $scope.callingCode = $rootScope.queryPhoneCode;
            }
          }, true);

    $scope.submitRegistration = function() {
                $scope.agreeClicked=1;
		if($scope.regForm.$invalid){

			$rootScope.regStatusMsg = "Oops! Please ensure all fields are valid."
            $rootScope.regStatusClass = "error hidden";
			return $scope.helpers.FormNotValid($scope.regForm);
		}else if($scope.termsnConditions == 0 && $scope.agreeClicked == 1){
			return false;
		}else{
			var user_name = $scope.userName;
			if (user_name.indexOf(" ") != -1) {
				var parts = user_name.split(" ");
				$scope.firstName = parts[0];
				$scope.lastName = parts[1]; //@review missing index not handled
			} else {
				$scope.firstName = user_name;

			}
                        $rootScope.gaHeaderControllerJs.gaFireOnLoginSignupAttempt('email');
                        var hashPass = HashLogicService.hashLogic($scope.password);
                        var signUpParams = {
                            method: 'signUp',
                            callingCode: $scope.callingCode,
                            city: $scope.city,
                            countryInfo: $scope.userCountry,
                            email: $scope.userEmail,
                            firstName: $scope.firstName,
                            formSource: 0,
                            isSubsNewsletter: 0,
                            lastName: $scope.lastName,
                            lead_source_string: document.URL,
                            phoneNum: $rootScope.queryPhoneCode + $scope.contactNum,
                            userPassword: hashPass,
                            emailAuth: 1,
                            utm_source: 'direct',
                            auto_login: 'Y'
                        };
                        PostReqService.sendPostRequest(baseApiUrlNocache,signUpParams)
                        .then(function(data, status, header, config) {
                            if(data == null){
                                $rootScope.regStatusMsg = "Some error occurred. Please try again later.";
                                $rootScope.gaHeaderControllerJs.gaFireOnLoginSignupFailure('email | ' + $rootScope.regStatusMsg);
                                $rootScope.regStatusClass = "error";
                            }else if(data.data.status == "success"){
                                    $rootScope.gaHeaderControllerJs.gaFireOnLoginSignupSuccess('email');
                                    $rootScope.regSuccessMsg = "Your registration is successful. Happy learning!";
                                    $rootScope.regSuccessClass = "success_text";
                                    $scope.$parent.loginRegFormStyle = {'display': 'none'};
									$rootScope.registerFormStyle = {'display': 'none'};
                                    $scope.regForm.$setPristine();
                                    (document.getElementsByClassName("log-reg-form")[0]).focus();
                                    user_params.email = $scope.userEmail;
                                    user_params.user_id = data.data.data.id;
                                    var cpClickedState = $rootScope.isCpClicked;
                                    PostReqService.initFreeTrialCookie();
                                    $timeout(function () {
                                        $rootScope.isCpClicked = cpClickedState;
                                        $rootScope.isLoggedIn = true;
                                        $rootScope.$emit('isLoggedIn', true);
                                        $scope.$parent.showStatus = false;
                                    }, 1500);
                                    if (typeof user_params.pageCategory != 'undefined' && (user_params.pageCategory == 'help-and-support_createticket' || user_params.pageCategory == 'help-and-support_index')) {
                                        window.location.reload();
                                    }
                                    else if (window.refurl != 'undefined' && typeof window.refurl == 'object') {
                                        if (typeof window.refurl.host != 'undefined' && window.refurl.host != '' && typeof window.refurl.source != 'undefined' && window.refurl.source != '') {
                                            if (window.refurl.host == 'community.simplilearn.com') {
                                                window.location.href = window.refurl.source;        //after success signup redirect to community page
                                            } else if (window.refurl.host == 'lms.simplilearn.com') {
                                                window.location.href = window.refurl.source;        //after success signup redirect to lms page
                                            } else if (window.refurl.host != 'www.simplilearn.com' && window.refurl.source.indexOf('/ice9/frontend/public') < 0) {
                                                window.location.href = window.refurl.source;        //after success signup redirect to local page
                                            }
                                        }
                                    }
                                    $scope.contactNum = "";
                                    $scope.userName = "";
                                    $scope.userEmail = "";
                                    $scope.password = "";
                                    $scope.confPassword = "";
				}else if(data.data.status == "error"){

					$rootScope.regStatusMsg = data.data.msg;
                                        $rootScope.gaHeaderControllerJs.gaFireOnLoginSignupFailure('email | ' + data.data.msg);
					$rootScope.regStatusClass = "error";
				}else{
					$rootScope.regStatusMsg = "Some error occurred. Please try again later!";
                                    $rootScope.gaHeaderControllerJs.gaFireOnLoginSignupFailure('email | ' + $rootScope.regStatusMsg);
					$rootScope.regStatusClass = "error";
				}
			});
		}
    };

    var onLoginFailure = function() {
        $rootScope.gaHeaderControllerJs.gaFireOnLoginSignupFailure('email | auto-login after registration failed');
        $timeout(function(){
            $rootScope.regSuccessMsg = '';
            $scope.$parent.showLogin();
        }, 1500);
    };

    $scope.agreeToTnC = function() {
		$scope.agreeClicked=1;
        if ($scope.termsnConditions == 1)
            $scope.termsnConditions = 0;
        else //@review missing curly braces
            $scope.termsnConditions = 1;
        //@review missing return statement
    }

    $scope.$watch('confPassword', function(newPwd) {
        if (newPwd != $scope.password) {
            $scope.regForm.confPassword.$setValidity('conf-pwd', false);
        }
        else {
            $scope.regForm.confPassword.$setValidity('conf-pwd', true);
        }
    });

    $scope.$watch('password', function(newPwd) {
        if (newPwd != $scope.confPassword && $scope.confPassword) {
            $scope.regForm.confPassword.$setValidity('conf-pwd', false);
        }
        else {
            $scope.regForm.confPassword.$setValidity('conf-pwd', true);
        }

        if (newPwd && ( newPwd.length < 8 || newPwd.match(/\d+/g) == null || newPwd.match(/[A-Z]/g) == null  ) ) {
            $scope.regForm.password.$setValidity('pwd', false);
        }
        else {
            $scope.regForm.password.$setValidity('pwd', true);
        }
    });

    $scope.$watch('termsnConditions', function(newValue) {
        if (newValue != 1) {
            $scope.regForm.termsnConditions.$setValidity('required', false);
        }
        //@review missing else
    });

    $scope.$watch('contactNum', function(newValue) {

		if(isNaN(newValue)){
			//$scope.regForm.contactNum.$setValidity('required', false);
			$scope.regForm.contactNum.$setValidity('phone', false);
		}
                else if( newValue.length < 7 ) {
                    $scope.regForm.contactNum.$setValidity('phone', false);
                }
                else {
			$scope.regForm.contactNum.$setValidity('phone', true);
                }
    });

    /*
    $scope.$watch('userEmail', function(newValue) {
        var email_rgx = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

        if( !email_rgx.test(newValue) ){
            $scope.regForm.userEmail.$setValidity('email', false);
        }
        else {
            $scope.regForm.userEmail.$setValidity('email', true);
        }
    }); */

    $scope.$parent.$watch('loginFormStyle', function(newValue) {
        if (typeof newValue != 'undefined' && newValue.display == 'none') {
            $scope.regForm.$setPristine();
            $rootScope.regStatusClass = "";
            $rootScope.regStatusMsg = "";
            $scope.agreeClicked=0;
            $scope.userName = "";
            $scope.contactNum = "";
            $scope.userEmail="";
            $scope.password="";
            $scope.confPassword="";
        }
    });

});

