angular.module('Simplilearn')
.controller('OnlineAccessDaysController', function($scope) {

	this.selectedOnlineAccessDays = null;
	this.init = function(accDays){
		this.selectedOnlineAccessDays = accDays;
	}
        var gaForLVCPass = function() {
            var ga = new gaEventsTracker();

            this.gaFireEventsGeneric = function(pGaKey, pGaLabel) {
                ga.gaFireInteractiveEvents(pGaKey, pGaLabel); 
            };
         };

        this.ga = new gaForLVCPass();
        this.updateAccessDays = function(){
        	document.getElementById("accessDays").value = this.selectedOnlineAccessDays ;
        }
});
