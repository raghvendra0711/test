angular.module('Simplilearn')
.config(function($locationProvider) {
    var links = document.getElementsByTagName('a');
            for (var i = 0; i < links.length; i++) {
                if (links[i].getAttribute('target') != '_blank') {
                    if(links[i].getAttribute('href') && links[i].getAttribute('href').charAt(0) !== '#'){
                        links[i].setAttribute("target", "_self");
                    }
                }
            }
        $locationProvider.html5Mode( true ).hashPrefix('!');
})
.controller('CoursePageCtrl', function(YoutubeApiService, $document,$scope, $http, LocService, $interval, $location, $rootScope,CorporateLeadService, $timeout, $compile, PostReqService, FormsAjax, LeadService) {
    $scope.helpers = new helpers();
    $scope.forms_from_ajax = null;
    $scope.lvc_disc = 0;
    $scope.osl_disc = 0;
    $scope.lvc_price = 0;
    $scope.osl_price = 0;
    $scope.cls_price = 0;
    $scope.striked_lvc_price = 0;
    $scope.striked_osl_price = 0;
    $scope.striked_cls_price = 0;
    $scope.countryId = 0;
    $scope.formPlace = 0;
    $rootScope.webEventFiredformId = 0;
    $scope.cSiteModuleCustom = '';
    $scope.cSiteModule = '';
    var youtubePlayerObj={};
    $scope.templateTitle='';
    user_params.referrer = (document.referrer)? document.referrer: '';
    
    this.init = function () {
        (function() {
                try {
            LeadService.createAutoLead();
        } catch (e) {
            console.error("SL:Error auto lead failed", e);
        }
            })();
        
        user_params.referrer = (document.referrer)? document.referrer: '';
        webengage.onReady(function (data) {

            var url_string = window.location.href;
            var url = new URL(url_string);
            var source = url.searchParams.get("referrer");
            var eventId = '';
            var eventData = {};
            switch (source) {
                case 'home':
                    eventId = "sl_nav_user_clicks_on_product_card_on_homepage";
                    eventData = {
                        'sl_page_type': 'home',
                    };
                    break;

                case 'popular-category':
                    eventId = "sl_nav_popular_course_on_category_page_clicked";
                    eventData = {
                        'sl_page_type': 'course list',
                    };

                    break;
                case 'product-category':
                    eventId = "sl_nav_product_on_category_page_clicked";
                    eventData = {
                        'sl_page_type': 'course list',
                    };
                    break;
                case 'search':
                    eventId = "sl_search_user_clicks_on_a_search_result";
                    break;
            }
            if (eventId=="sl_search_user_clicks_on_a_search_result") {
               var eventInfo=WebTracking.eventReq.getDataFromUserParams(['sl_product_id', 'sl_product_name','sl_product_category','sl_product_category_id','sl_product_type','sl_product_image','sl_event_time','sl_page_type','sl_user_type']);   
                eventInfo.sl_search_term = getParameterByName('tag')||'';
                eventInfo.sl_page_type = 'search page';
                WebTracking.eventReq.triggerEvent({
                    event_id: eventId,
                    event_data: eventInfo,
                });
            }
            else if(eventId!="sl_search_user_clicks_on_a_search_result" && eventId ){
                WebTracking.eventReq.triggerEvent({
                    event_id: eventId,
                    event_data: eventData,
                    common: "product",
                });
            }
        });
    }
    $scope.intiateLeadEmi = function () {
        var siteModule = 'no cost emi popup';
        WebTracking.eventReq.triggerEvent({
            event_id: "sl_lead_module_initiated",
            event_data: {
                'sl_lead_button_text': 'Learn More',
                'sl_lead_type': 'b2c',
                'sl_site_module': siteModule,
            },
            common: "product",
            user_attributes: ['sl_lead_type']
        });
        var ga = new gaEventsTracker();
        ga.gaFireInteractiveEvents('no_cost_emi', user_params.user_id + ' || ' + document.URL + ' || ' + user_params.sl_product_name);
    }

    $scope.goToEmiTabs = function(){
        angular.element(document.getElementById('courseemipopup')).scope().goToEmiTabs();
    }

    $scope.productViewed = function () {
        produtPageViewedEvent();
    }
            
    this.pageViewed = function () {
        user_params.sl_user_type = (document.referrer)?'b2c':'b2b';
        webengage.onReady(function (data) {
        WebTracking.eventReq.triggerEvent({
            event_id: "sl_eng_web_page_viewed",
            event_data: {},
            common: "product"
        });
        });
    }
    this.setTemplateTitle = function(title, siteModule){
        $scope.templateTitle=title;
        if(typeof siteModule !== 'undefined' && siteModule) {
            $scope.cSiteModuleCustom = siteModule;
        } else {
            $scope.cSiteModuleCustom = '';
        }
    };
    this.setSiteModule = function(siteModule) {
        $scope.cSiteModule = siteModule;        
    }
    this.setHash = function(path) {
        $location.hash(path);
        WebTracking.eventReq.triggerEvent({
          event_id : "sl_eng_page_sticky_top_nav_show_section_change",
          event_data: {
            'sl_product_page_section' : path
          },
          common : "product"
        });
        $scope.gCPCJ.gaFireEventsGeneric('coursestickyheader',  user_params.course_name + ' || ' + path);
    }
    var aacWatch = $rootScope.$watch('fireAacCookie', function(newValue, oldValue) {
        if(newValue == 1) {
            $rootScope.fireAacCookie = 0;
            self.showDiscountValuesCourse($scope.countryId);
        }
    });
    $scope.breadcrumEvent = function($event,productType,url,name,id) {
        var gotoLink = ''
        if(typeof $event != 'undefined')
            gotoLink = $event.target.parentNode.href;
        var ga = new gaEventsTracker();
        ga.gaFireInteractiveEvents('breadcrumclick', user_params.user_id + ' || ' + document.URL + ' || ' + gotoLink);
        if (name||productType=='home') {
            breadcrumEvent(productType, gotoLink, name, id);
        }        
    }
    $scope.contactEnterpriseFormAjax = function () {
        var elem = document.getElementById('enterprise_form_ajax');
        if (elem !== undefined && elem !== null && elem.innerHTML === "") {
            var all_forms = JSON.parse(user_params.forms_ajax_load);
            var ent_form_json = JSON.stringify({'enterprise_form_ajax': all_forms['enterprise_form_ajax']});
            FormsAjax.loadFormviaAjaxSL(ent_form_json, $scope);
        }

    }

    $scope.downloadAgendaUrlinit = function(agendaUrl){
        $rootScope.submitCourseAgendaPopUp = agendaUrl;
    }

    this.setOslPriceCourse = function(price_osl,fin_osl_price){
       $scope.osl_price = price_osl;
       $scope.fin_osl_price  = fin_osl_price;


    }

    this.setLvcPriceCourse = function(price_lvc,fin_lvc_price ){
       $scope.lvc_price = price_lvc;
       $scope.fin_lvc_price  = fin_lvc_price;
    }

    this.setClsPriceCourse = function(price_cls,fin_cls_price){
       $scope.cls_price = price_cls;
       $scope.fin_cls_price = fin_cls_price;
    }

    this.setEmiPriceCourse = function(fin_emi_price,emi_curr){
        $scope.fin_emi_price = fin_emi_price;
        $scope.emi_curr = emi_curr;
    }

    this.getNoCostEmiIndiaPrice = function(price,courseId,trainingType,isExam){
        let amount = typeof price != undefined && parseInt(price) > 0 ? parseInt(price) : 0;
        const REMOVED_COURSES_EXCEPTION = user_params.sl_removed_course_exception.split(',');
        const REMOVED_CLASSROOM_EXCEPTION = user_params.sl_removed_bundle_exception.split(',');
        if (
            ( ( isExam == 'false'
                && trainingType != "classroom"
            ) || (
                REMOVED_COURSES_EXCEPTION.indexOf(courseId) > -1
            ) || (
                REMOVED_CLASSROOM_EXCEPTION.indexOf(courseId) > -1
            )
            )
            && 
            amount >= user_params.sl_no_cost_emi_india_price_limit 
        ) {
            let emi = Math.floor(amount/12);
            return emi;
        }

        return 0;
    }

    $scope.enrollMaster = function() {
        if(document.getElementsByClassName("btn-master-purchase").length > 0) {
            document.getElementsByClassName("btn-master-purchase")[0].click();
        }
    }
    this.showDiscountValuesCourse = function(country_id){
        $scope.countryId = country_id;
        var code = getCookieByName('aac');
        if(code){
          $http.get(baseApiUrl + "?method=getCouponsdicountDetails",
            { params: {
                    "aac": code,
                    "sep_tt_dic_val" : 1,
                    "courseId": user_params.course_id,
                    "country_id":country_id
                }
            })
            .then(function(response) {
                if (typeof response.status !== 'undefined' && typeof response.data !== 'undefined' && response.status == 200) {
                    var result = response.data;
                    if(result.status == 'success'){
                      $scope.lvc_disc =  result.data.lvc;
                      $scope.osl_disc =  result.data.osl;
                      $scope.cls_disc =  result.data.cls;
                      $scope.fin_osl_price = Math.floor($scope.osl_price - ($scope.osl_price*($scope.osl_disc/100)));
                      $scope.fin_lvc_price = Math.floor($scope.lvc_price - ($scope.lvc_price*($scope.lvc_disc/100)));
                      $scope.fin_cls_price = Math.floor($scope.cls_price - ($scope.cls_price*($scope.cls_disc/100)));

                      //emi only for india
                      if(country_id == 6){
                        var arry = [$scope.fin_osl_price, $scope.fin_lvc_price, $scope.fin_cls_price];
                        var smallestPrice = Math.min.apply(Math, arry.filter(Number));
                        
                        /* As per current requirement not to show on course pages */
                        $scope.fin_emi_price = 0;
                        // $scope.fin_emi_price = self.getNoCostEmiIndiaPrice(smallestPrice,user_params.course_id,user_params.sl_product_training_type,user_params.sl_product_is_exam);
                        if($scope.fin_emi_price <= 0){
                            if(document.querySelector('.no-cost') != null){
                                document.querySelector('.no-cost').classList.add('hide');
                                document.querySelector('.has-cost-popup').classList.remove('no-cost-popup');
                            }
                        }else{
                            if(document.querySelector('.no-cost') != null){
                                document.querySelector('.no-cost').classList.remove('hide');
                                document.querySelector('.has-cost-popup').classList.add('no-cost-popup');
                            }
                        }
                      }
                     // Update Affirm Amount After Coupon Apply
                     if(typeof document.getElementsByClassName("affirm-as-low-as") !=="undefined"){
                         var elem = document.getElementsByClassName("affirm-as-low-as");
                         if(elem &&  $scope.fin_cls_price){
                            for(var i =0 ;i<elem.length;i++){
                                var discountAmount = parseFloat($scope.fin_cls_price)* 100;
                                if(elem[i].hasAttribute('data-amount')){
                                    elem[i].setAttribute('data-amount',discountAmount);
                                    
                                }
                            }
                            if(typeof affirm !=="undefined"){
                                try{
                                    affirm.ui.refresh();
                                }catch(err){
                                    console.info("Affirm is not loaded");
                                }
                                
                            }
                         }
                     }
                    }
                }
            });
        }
    }
    // auto coupon apply by url hash

// Below code is not required in this Controller as we are already using autoApplyCoupon function
//    var aacListener = $rootScope.$on('aac', function(event, value) {
//        //New Coupon to be added in aac Cookie
//        addCouponCodesToAACCookie(value);
//
//        aacListener();// stop listen
//    });

    // scrollToHash
    var hashTagListener = $rootScope.$on('hashTag', function(event, scrollHash) {
        if(scrollHash) {
            $timeout(function() {
                var button = document.getElementsByClassName(scrollHash + '-button')[0];
                if(button) {
                    button.click();

                    //Check for jump to section
                    var elem_content = document.getElementById(scrollHash + '-content');
                    if(elem_content){
                     var alreadyOpen = elem_content.style.height == 'auto' ? 1 : 0;
                     if(!alreadyOpen) {
                      button.click();
                     }
                    }
                }
            }, 300);
        }
        hashTagListener();// stop listen
    });

    $scope.popupTnC = true;
    $scope.popupName = '';
    $scope.popupEmail = '';
    $scope.popupUserPhone = '';
    var cpc = this;

    //For notify me Popup show on click. There is a controller for the same below.
    $scope.shownotifyLeadPopup = function(){
        $rootScope.shownotifyMePopUP = true;
    }

    this.loadFormsviaAjax = function(){
      $scope.form_data = null;
      FormsAjax.loadFormviaAjaxSL(user_params.forms_ajax_load,$scope);
    }

    $scope.submitCoursePagePopup = function () {
        if ($scope.coursePagePopup.$invalid) {
          return $scope.helpers.FormNotValid($scope.coursePagePopup);
        }
        var obj3 = {
          name: $scope.coursePagePopup.popupName.$viewValue,
          email: $scope.coursePagePopup.popupEmail.$viewValue,
          phone: $rootScope.popupPhoneCode + $scope.coursePagePopup.popupUserPhone.$viewValue,
          queryTxt: "Details provided in course page popup",
          query: "Details provided in course page popup",
          agreeToContact: $scope.coursePagePopup.popupTnC.$viewValue,
          queryTyp: 'course-page-popup',
          courseId: user_params.course_id,
          courseName: user_params.course_name
        };
        obj3['customerType'] = 'B2C';
        obj3['leadTrainingType'] = 'classroom';
        obj3['leadSourceString'] = document.URL;
        obj3['tagName'] = 'course-page-popup';
        obj3['leadSource'] = fetchUTMSource();
        obj3['type'] = 'course-page-popup';
        obj3['productTypeId'] = user_params.productTypeId;
        obj3['billingTypeId'] = user_params.billingTypeId;
        obj3['method'] = 'saveCallback';
        obj3['GCLID'] = getGCLID();
        PostReqService.sendPostRequest(baseApiUrlNocache, obj3)
            .then(function (data) {
              if (data != null) {
                if (data.data.status == 'Success') {
//                  $rootScope.gaCommonLeadCaptures.gaFireLeadCapture('leadcaptureworkshopnotavail');
                  $scope.popupStatusMsg = "We have received your information. We will get back to you soon.";
                  $scope.popupName = '';
                  $scope.popupEmail = '';
                  $scope.popupUserPhone = '';
                  document.cookie = 'cppf=course-page-popup-filled;SameSite=Lax';
                } else {
                  $scope.popupStatusMsg = "There was some problem, please try again.";
                }
              }
              $scope.popupStatusDisplay = true;
              $scope.popupStatus = data.data.status;
			  setTimeout(cpc.hideAllModal, 5000)
            });
      }

    this.autoApplyCoupon = function() {
        if( !!$location.hash() ) {
            var path = $location.hash();
            var hash = path.substr(path.indexOf('/')+1).split('=');
            if (hash[0] == 'aac') {
               addCouponCodesToAACCookie(hash[1]);
              }
            }
        }

  this.showScholarshipPopup = function () {
      if (!!$location.path()) {
        var path = $location.path();
        var hash = path.substr(path.indexOf('/') + 1).split('=');
        if (hash[0] == 'schl' && countryCode == 'US') {
          user_params.scholarship = hash[1];
          $http.get(baseApiUrl + '?method=getScholarshipEnrollModal&schl=' + hash[1]+'&course_id='+course_id).then(function (data) {
            if (data.data == '"error"') {
              return;
            }
            var popup = $compile(data.data.replace("\n", ""))($scope);
            $scope.course_name_schl = user_params.course_name;
            document.querySelector('#body_content').parentNode.appendChild(angular.element(popup)[0]);
          });
        }
      }
    }

    this.getWorkshopData = function (outcome, cityPage, https, showTxNote, titleString) {
         var ttInfo = JSON.parse(user_params.forms_ajax_load);
            ttInfo = ttInfo.ttfc || null;
          if(typeof ttInfo != 'undefined' && ttInfo != parseInt(user_params.training_type_classroom)) {
            setTimeout(function () {
            var paramsArr = {'course_id': user_params.course_id, 'cityPage':cityPage,
            'showTxNote':showTxNote,cityId:locator_data.city_id};
            //, 'titleString':titleString,'description':document.querySelector('meta[name=description]').getAttribute("content"),'https':https,'canonical': document.querySelector("link[rel='canonical']").getAttribute("href")
            //console.log(paramsArr);
            PostReqService.sendGetRequest(baseUrlAjax+"course/course-workshops", paramsArr)
            .then(function (response) {
                if(response && typeof response.data !='undefined'){
                    angular.element(document.getElementById('course-workshops')).html(response.data);
                    $compile(angular.element(document.getElementById('course-workshops')).contents())($scope);
                }
            });
        }, 4000);
        }
    }

    this.scheduleLeadPopup = function () {
      setTimeout(function () {
        var allmodals = document.getElementsByClassName('popup_country_wrapper');
        for (var i = 0; i < allmodals.length; i++) {
          if (allmodals[i].style.display == 'block') {
//            console.log('another popup is visible.');
            return;
          }
        }
        if (['input', 'select', 'textarea'].find(function(e){
          return e == document.activeElement.tagName.toLowerCase()
        })) {
//          console.log('user filling up form.');
          return;
        }
        if (document.cookie.indexOf("course-page-popup-filled") > -1) {
//          console.log(document.cookie.indexOf("course-page-popup-filled"),"User already filled up popup");
          return;
        }
        $scope.popupTnC = true;
        $rootScope.popupPhoneCode ='+'+ $rootScope.currentCountry.phnCode+'-';
        $scope.popupStatusDisplay = false;
        $http.get(baseApiUrl + '?method=getCoursePageLeadPopup').then(function (data) {
          var popup = $compile(data.data.replace("\n", ""))($scope);
          document.querySelector('#body_content').parentNode.appendChild(angular.element(popup)[0]);
        });
      }, 40000);
    }
    this.hideAllModal = function () {
      var modalObjs = document.getElementsByClassName('popup_country_wrapper');
      var modalLen = modalObjs.length;
      for(var i=0;i<modalLen;i++){
        if(modalObjs[i].style.display =='block'){
          modalObjs[i].style.display = 'none';
        }
      }
      var bodyObj = document.getElementsByTagName('body')[0];
      bodyObj.className = bodyObj.className.replace("body_fixed","");
    }

    this.statesDisplayStatus = {'display': 'none'};
    this.selectedCountry = null;
    this.countries = null;
    this.changeLocCountries = null;
    this.selectChangeLocCountry = null;
	this.selectChangeLocCity = null;
    this.selectChangeLocCities = null;
    this.stickyTrainingTypeDisplay = {'display':'none'};
	this.genericPageDisplayStatus = {'display':'block'};
	this.topOslButtonDisplay = {'display':'block'};
	this.topIltButtonDisplay = {'display':'block'};
	this.leadFormDisplay = {'display':'block'};
    this.lvcVideoDisplayStatus = {'display': 'none'};
    this.selectedTrainingType = "";
    this.corporateText = 'Interested in training your team?';
    $scope.stickyComponentDisplay = {'display': 'none'};
    $scope.headerSelectText = "Select Training Type";
    $scope.courseAdviseDirectorString = "course-advisor-wrapper";
    this.totalOffersCount = 0;
    this.olOffersCount = 0;
    this.clOffersCount = 0;
    this.setLetUsKnowTrigger = 0;
    $scope.bundlePreviewClicked = 0;
    this.isCrsVideoVisible = 0;
    this.videoState = '';

    this.isBatchInfoVisible = 0;
    this.classroomFormData = {};
    this.onlineFormData = {};
    this.lvcPassFormData = {};

    var seoExpDesc = '';
    var cityHashFlag = 0;
    var indexCityHashFlag = 0;
    var seoCityData = {};
    this.seoCurrentCity = '';
    //var showReviews = {};
    $scope.totalBatchesToShow = 5;

    this.abtVideos = {};
    this.vidStatus = {};
    this.randomCourseDir = 1;

    /** start - intro video **/
    this.introVideo = null;
    this.introPlayer = null;
    this.introVideoInit = function(type) {
        YoutubeApiService.onReady(function () {
            var player;
            var playerId = 'courseIntroVideo';
            var playButtonId = 'play-button-intro-main';

                var popupDom = document.querySelector('#courseIntroVideoPopup iframe');
                if(!popupDom) {
                    return ;
                }
                initIntroVideoPopupStatus = true;
                popupDom.setAttribute('id', 'courseIntroVideoPopupIframe');
                playerId = 'courseIntroVideoPopupIframe';
                playButtonId = 'play-button-intro-popup';

            player = new YT.Player(playerId, {
                events: {
                    'onStateChange': onPlayerStateChange
                }
            });
            youtubePlayerObj=player;
            self.introVideo = document.getElementById(playerId);
            if(!self.introVideoOverlayStatus){
                self.playVideo(self.introVideo);
            }
            var videoState = null;
            function onPlayerStateChange(event) {
                self.introPlayer = event.target;
                // Reply button
                if(videoState == null) {
                    $timeout(function () {
                       var playButton = document.getElementById(playButtonId);
                       playButton.addEventListener("click", function() {
//                           console.log('Video play', self.introVideoOverlayStatus);
                           self.introAnnotation = true;
                           self.playVideo(self.introVideo);
                           self.hideIntrovideoOverlay();
                       });
                   });
                }
                videoState = event;

                // On complete
                $timeout(function () {
                    // console.log(videoState.data);
                    if (videoState.data == YT.PlayerState.ENDED) {
                        //console.log("End");
                        self.stopVideo();
                        self.showIntrovideoOverlay(self.introVideo);
                        $scope.gCPCJ.gaFireOnCoursePage('introvideowatched', user_params.user_id + ' || ' + document.URL + ' || introvideo ||' + user_params.course_name);

                    }
                }, 100);
            }
        });
    }

    this.initIntroVideo = function() {
        self.introVideoInit('main');
    }

    this.initIntroVideoPopup = function() {
        self.introVideoInit('popup');
    }

    this.showCoursePreview = function(type) {
        type = type || 'base';
        ga = new gaEventsTracker();
        ga.gaFireInteractiveEvents('CoursePreviewIntrovideoClick', type);

        //self.hideIntrovideoOverlay();
        self.hideCrsVideo();
        //self.pauseVideo(self.introVideo);

        $timeout(function() {
            var button = document.getElementsByClassName('course-preview-button')[0];
            if(button) {
                button.click();
            }
        }, 0);
    }

    this.stopVideo = function(domObj) {
        //console.log('stopVideo')
        if(self.introPlayer && self.introPlayer.stopVideo) {
            self.introPlayer.stopVideo();
        } else if(domObj && domObj.contentWindow) {
            domObj.contentWindow.postMessage('{"event":"command","func":"stopVideo","args":""}', '*');
        }
    }

    this.pauseVideo = function(domObj) {
        //console.log('pauseVideo')
        if(self.introPlayer && self.introPlayer.pauseVideo) {
            self.introPlayer.pauseVideo();
        } else if(domObj && domObj.contentWindow) {
            domObj.contentWindow.postMessage('{"event":"command","func":"pauseVideo","args":""}', '*');
        }
    }

    this.playVideo = function(domObj) {
        //console.log('playVideo')
        if(self.introPlayer && self.introPlayer.playVideo) {
            self.introPlayer.playVideo();
        } else if(domObj && domObj.contentWindow) {
            domObj.contentWindow.postMessage('{"event":"command","func":"playVideo","args":""}', '*');
        }
    }

    this.introVideoOverlayStatus = false;
    this.showIntrovideoOverlay = function() {
        this.introVideoOverlayStatus = true;
        document.querySelector('#courseIntroVideoMobOverlay').style.display = 'block';
    }

    this.hideIntrovideoOverlay = function() {
        this.introVideoOverlayStatus = false;
        document.querySelector('#courseIntroVideoMobOverlay').style.display = 'none';
    }
    /** end - intro video **/

    this.playAbtCrs = function(type){
        this.abtVideos[type] = 1;
        this.vidStatus[type] = '';
        if (type == 1) {
            $scope.gCPCJ.gaFireEventsGeneric('pre_run');
        } else if (type == 2) {
            $scope.gCPCJ.gaFireEventsGeneric('flexi_pass');
        }
    }
    this.hideAbtCrs = function(type){
        this.abtVideos = {};
        this.vidStatus[type] = 'stop';
    }
    this.toggleBatchDisplay = function() {
        this.isBatchInfoVisible = (this.isBatchInfoVisible) ? 0 : 1;
    };
    this.showBatchDisplay = function() {
        this.isBatchInfoVisible = 1;
        WebTracking.eventReq.triggerEvent({
          event_id : "sl_eng_class_info_clicked",
          common : "product"
        });
        $scope.gCPCJ.gaFireOnCoursePage('viewclassschedule', user_params.user_id + ' || ' + document.URL);
    };
    this.intiateLeadFPT = function (btnText) {
      var siteModule='fpt-paper-cold';
      if(typeof user_params.sl_override_site_module !=="undefined" && user_params.sl_override_site_module){
          siteModule=user_params.sl_override_site_module;
      }
      WebTracking.eventReq.triggerEvent({
          event_id : "sl_lead_module_initiated",
          event_data: {
            'sl_lead_button_text' : btnText || '',
            'sl_lead_type' : 'b2c',
            'sl_site_module' : siteModule,
          },
          common : "product",
          user_attributes: ['sl_lead_type']
      });
    }
    this.gaOnFAQ = function (title, accordionId) {
        var isAccordionOpen = checkIfAccordionIsOpen(accordionId);
        if (isAccordionOpen) {
            WebTracking.eventReq.triggerEvent({
                event_id: "sl_eng_product_faq_question_explored",
                event_data: {
                    'sl_product_faq_question': title || '',
                },
                common: "product",
            });
            $scope.gCPCJ.gaFireOnCoursePage('faqclickedopen', user_params.user_id + ' || ' + document.URL + ' || ' + user_params.course_name + ' || ' + title);
        }
    };
    this.gaOnCD = function (title, accordionId) {
        var isAccordionOpen = checkIfAccordionIsOpen(accordionId);
        if (isAccordionOpen) {
            WebTracking.eventReq.triggerEvent({
                event_id: "sl_eng_product_description_explored",
                event_data: {
                    'sl_product_description_question': title,
                },
                common: "product",
            });
            $scope.gCPCJ.gaFireOnCoursePage('cdclickedopen', user_params.user_id + ' || ' + document.URL + ' || ' + user_params.course_name + ' || ' + title);
        }
    };
    this.wbEngOnMBG = function(){
          WebTracking.eventReq.triggerEvent({
          event_id : "sl_eng_money_back_guarantee_explored",
          common : "product",
      });
    };
    this.wbEngproductRatingClick = function(){
          WebTracking.eventReq.triggerEvent({
          event_id : "sl_eng_product_ratings_clicked",
          common : "product",
      });
    };
    this.wbEngOnExamAndCertfExplored = function (title, accordionId) {
        var isAccordionOpen = checkIfAccordionIsOpen(accordionId);
        if (isAccordionOpen) {
            WebTracking.eventReq.triggerEvent({
                event_id: "sl_eng_product_exam_question_explored",
                event_data: {
                    'sl_product_exam_question': title,
                },
                common: "product",
            });
            $scope.gCPCJ.gaFireOnCoursePage('faqclickedopen', user_params.user_id + ' || ' + document.URL + ' || ' + user_params.course_name + ' || ' + title);
        }
    };
    this.gaOnEAC = function(title){
        $scope.gCPCJ.gaFireOnCoursePage('eacclickedopen', user_params.user_id + ' || ' + document.URL + ' || ' + user_params.course_name + ' || ' + title);
    };
    this.hideBatchDisplay = function() {
      WebTracking.eventReq.triggerEvent({
        event_id : "sl_eng_class_info_popup_closed",
        common : "product"
      });
      this.isBatchInfoVisible = 0;
    };

    this.exploreWorkshops = function (cObj) {
        try {
            var courseData = {};
            if (typeof cObj != 'undefined' && cObj.length > 0 && typeof user_params.pageCategory && user_params.pageCategory == 'bundle_index') {
                courseData = JSON.parse(cObj);
            }
            WebTracking.eventReq.triggerEvent({
                event_id: "sl_eng_class_info_carousal_explored",
                event_data: courseData,
                common: "product",
            });
        } catch (err) {
            console.error('SL:Error', err);
        }

    };

    this.initSeoCityExp = function(pSeoExpDesc, pCityHashFlag, pIndexCityHashFlag) {
        cityHashFlag = pCityHashFlag;
        indexCityHashFlag = pIndexCityHashFlag;
        seoExpDesc = pSeoExpDesc;
        seoCityData = JSON.parse(user_params.seoExpCityData);

        $scope.$watch(function(){ return location.hash }, function (value) {
            if(value) {
                value = value.substr(value.indexOf('/')+1);
            } else {
                self.seoCurrentCity = '';
            }

            if(value && indexCityHashFlag && self.seoCurrentCity != value) {
                var metaRobotsElem = document.querySelector('meta[name="robots"]');
                if(metaRobotsElem) {
                    metaRobotsElem.setAttribute('content', 'index');
                }
            }

            if(!value && indexCityHashFlag && self.seoCurrentCity != value) {
                var metaRobotsElem = document.querySelector('meta[name="robots"]');
                if(metaRobotsElem) {
                    metaRobotsElem.setAttribute('content', 'noindex');
                }
            }

            if(value && cityHashFlag && self.seoCurrentCity != value) {
                self.seoCurrentCity = value;
                updateSeoCityData();
                window.scroll(0, 0);
            }
        });
    };

    var updateSeoCityData = function() {
        if(!(seoCityData[self.seoCurrentCity] && seoCityData[self.seoCurrentCity]['h1Tag']) ) {
            return;
        }

        self.h1Text = seoCityData[self.seoCurrentCity]['h1Tag'];
        self.aboutCityHead = 'About ' + seoCityData[self.seoCurrentCity]['city_name'];
        self.aboutCity = seoCityData[self.seoCurrentCity]['about_city'];

        var metaDescTag = new Array();
        metaDescTag.push(document.querySelector('meta[name=description]'));
        metaDescTag.push(document.querySelector('meta[property="og:description"]'));
        metaDescTag.push(document.querySelector('meta[name="twitter:description"]'));
        for(var i=0; i < metaDescTag.length; i++) {
            if(metaDescTag[i]) {
                metaDescTag[i].setAttribute('content', seoCityData[self.seoCurrentCity]['metaDescription']);
            }
        }

        var canonicalElem = document.querySelector('link[rel="canonical"]');
        if(canonicalElem) {
            canonicalElem.setAttribute('href', seoCityData[self.seoCurrentCity]['canonical']);
        }

        var metaUrlTags = new Array();
        metaUrlTags.push(document.querySelector('meta[property="og:url"]'));
        metaUrlTags.push(document.querySelector('meta[name="twitter:url"]'));
        for(var i=0; i < metaUrlTags.length; i++) {
            if(metaUrlTags[i]) {
                metaUrlTags[i].setAttribute('content', seoCityData[self.seoCurrentCity]['canonical']);
            }
        }

        var titleElem = document.querySelector('title');
        if(titleElem) {
            titleElem.innerHTML = seoCityData[self.seoCurrentCity]['metaTitle'];
        }

        var metaTitleTags = new Array();
        metaTitleTags.push(document.querySelector('meta[property="og:title"]'));
        metaTitleTags.push(document.querySelector('meta[name="twitter:title"]'));
        for(var i=0; i < metaTitleTags.length; i++) {
            if(metaTitleTags[i]) {
                metaTitleTags[i].setAttribute('content', seoCityData[self.seoCurrentCity]['metaTitle']);
            }
        }
    };

    var self = this;
    dwnldSchedule = function($event,startDate,endDate,countryId,courseId){
        $scope.$apply(function(){
            self.downloadSchedule($event,startDate,endDate,countryId,courseId);
        });
    }
    this.downloadSchedule = function($event,startDate,endDate,countryId,courseId,cObj){
        $event.preventDefault();        
        var courseData = {};
        if (typeof cObj != 'undefined' && cObj.length > 0 && typeof user_params.pageCategory && user_params.pageCategory == 'bundle_index') {
            courseData = JSON.parse(cObj);
        }
        WebTracking.eventReq.triggerEvent({
            event_id : "sl_eng_class_info_downloaded",
            event_data: courseData,
            common : "product",
        });
        $scope.gCPCJ.gaFireOnCoursePage('downloadschedule', user_params.user_id + ' || ' + document.URL);
        $http.get(baseApiUrl + '?method=getWorkshopScheduleCsv', {params: {startDate: startDate, endDate: endDate, countryId: countryId,courseId:courseId,'isPdf':1}})
                .success(function (data) {
                    if (data == null || typeof data.message == 'undefined') {
                        window.location = baseApiUrl + '?method=getWorkshopScheduleCsv&startDate=' + startDate + '&endDate=' + endDate + '&countryId=' + countryId+ '&courseId=' + courseId+ '&isPdf=1';
                    } else {
                        this.downloadScheduleErr = data.message;
                    }
                })
                .error(function () {
                    this.downloadScheduleErr = "Some error occurred. Please try again later.";
                });
    };

    this.submitClassroomForm = function(pCourseId, pWorkshopId, pTrainingType) {
        var pageSource = window.location.href;
        this.classroomFormData = {"itemId":pCourseId, "batchId":pWorkshopId, 'trainingTypeId':pTrainingType,'pageSource':pageSource,'campaignData':encodeURIComponent(JSON.stringify(getCampaignDetails()))};
    };

    this.submitOnlineForm = function(pCourseId, pAccessDays, pTrainingType) {
        var pageSource = window.location.href;
        this.onlineFormData = {"itemId":pCourseId, "accessDays":pAccessDays, 'trainingTypeId':pTrainingType,'pageSource':pageSource,'campaignData':encodeURIComponent(JSON.stringify(getCampaignDetails()))};
    };

    this.submitLvcPassForm = function(pCourseId, pAccessDays, pTrainingType) {
        var pageSource = window.location.href;
        this.lvcPassFormData = {"itemId":pCourseId, "accessDays":pAccessDays, 'trainingTypeId':pTrainingType,'pageSource':pageSource,'campaignData':encodeURIComponent(JSON.stringify(getCampaignDetails()))};
    };
    this.submitLvcPassB2bForm = function(companyId,productId, productTypeId, accessDays,trainingTypeId,b2bCountryId,b2bPricingId) {
        var pageSource = window.location.href;
        this.lvcPassB2bFormData = {"company_id": companyId,"product_id": productId, "product_type_id": productTypeId, 'accessDays': accessDays, 
                    'trainingTypeId': trainingTypeId,'b2b_country_id': b2bCountryId,'b2b_pricing_id': b2bPricingId,'pageSource': pageSource};
    };
    this.submitOnlinePassB2bForm = function(companyId,productId, productTypeId, accessDays,trainingTypeId,b2bCountryId,b2bPricingId) {
        var pageSource = window.location.href;
        this.onlineB2bFormData = {"company_id": companyId,"product_id": productId, "product_type_id": productTypeId, 'accessDays': accessDays, 
                    'trainingTypeId': trainingTypeId,'b2b_country_id': b2bCountryId,'b2b_pricing_id': b2bPricingId,'pageSource': pageSource};
    };

    var displayAllBundleCoursesFlag = 0;
    this.bundleCourseCount = null;

    var reviewExpandStateStruct = {};


	$scope.$watch('stickyComponentDisplay',function(newVal){
		if(newVal.display == 'none'){
			self.stickyTrainingTypeDisplay = {'display':'none'};
		}
	});
        $scope.$watch('lvc_disc',function(newValue, oldValue){
            if(typeof newValue !=="undefined" && parseInt(newValue) > 0 && $scope.fin_lvc_price)
            {
                var elm = document.getElementsByClassName("affirm-promotional-message");
                if(elm.length){
                    for(var i = 0;i < elm.length;i++){
                         elm[i].setAttribute("data-amount",$scope.fin_lvc_price)
                    }
                }
            }
	});
    this.setLetUsKnowFormOpen = function() {
        this.setLetUsKnowTrigger = 1;
        if ($rootScope.convSuccMsg) {
            $rootScope.adjustDivHeight = {'height': '440px'};
        }
        $rootScope.convSuccMsg = 0;
    }

    this.init_getLocationData = function(){
        if (typeof coursePageLocationData !== 'undefined') {
            self.changeLocCountries = coursePageLocationData;
            //self.setChangeLocCountry(self.changeLocCountries[0]);
			var countryListLength = self.changeLocCountries.length;
			//console.log(self.changeLocCountries);
			var locatorCookie = getCookieByName('locatori9');
			var locatorCookieObj = JSON.parse(locatorCookie);
			var locCountryId = locatorCookieObj.country_id;
			for(var i=0;i<countryListLength;i++){
				var cid = self.changeLocCountries[i].id;
				cid = cid.substring(cid.indexOf('-')+1);
				if(cid == locCountryId){
					self.selectChangeLocCountry = self.changeLocCountries[i];
					self.setChangeLocCountry();
				}
			}
        }
    };

    this.hiddenBatchesCount = 0;
    this.batchesCountSpan = true;
    this.toggleBatchClass = "view";
    this.classroomTrainingTypeStyle = {'display': 'block'};
    this.lvcTrainingTypeStyle = {'display': 'block'};
    this.classroomDisplay = 1;
    this.lvcDisplay = 1;
    this.slectedClassroomButton = {'display': 'none'};
    this.classroomButton = {'display': 'block'};
    this.slectedOnlineButton = {'display': 'none'};
    this.onlineButton = {'display': 'block'};
    this.classroomButtonBkgnd = "inactive";
    this.onlineButtonBkgnd = "inactive";

    this.filterCheckClasses = "remember_me selected_img";

    this.classroomStatus = {'show': false, 'batchCountShow': false, 'showAll': false};
    this.lvcStatus = {'show': false, 'batchCountShow': false, 'showAll': false};

    this.setReviewExpandState = function(pId, pVal,pRId) {
        reviewExpandStateStruct[pId] = pVal;
        if(parseInt(pVal) && parseInt(pRId) && typeof user_params.sl_product_review_user_details !=="undefined"){
                var slUserReviewsArr= user_params.sl_product_review_user_details;
                if(typeof slUserReviewsArr[pRId] !=="undefined" && slUserReviewsArr[pRId]){
                    var slProductReviewUserDetails=slUserReviewsArr[pRId];
                    WebTracking.eventReq.triggerEvent({
                        event_id : "sl_eng_product_reviews_read_more_clicked",
                        event_data: {
                        'sl_product_review_user_details' : slProductReviewUserDetails || '',
                        },
                        common : "product",
                    });
                }
        }
    };
    this.wEngProductReviewUserProfileClick = function(pRId){
           if(parseInt(pRId) && typeof user_params.sl_product_review_user_details !=="undefined"){
                var slUserReviewsArr= user_params.sl_product_review_user_details;
                if(typeof slUserReviewsArr[pRId] !=="undefined" && slUserReviewsArr[pRId]){
                    var slProductReviewUserDetails=slUserReviewsArr[pRId];
                     WebTracking.eventReq.triggerEvent({
                        event_id : "sl_eng_product_user_profile_clicked",
                        event_data: {
                        'sl_product_review_user_details' : slProductReviewUserDetails || '',
                        },
                        common : "product",
                    });
                }
        }
    };
    this.getReviewExpandState = function(pId) {
        if( typeof reviewExpandStateStruct[pId] === 'undefined' ) {
            reviewExpandStateStruct[pId] = 0;
        }

        return reviewExpandStateStruct[pId];
    };

    this.getCountryModalStatus = function() {
        return LocService.getChangeCountryModalStatus();
    };

    this.setCountryModalStatus = function(statusVal,$event) {
		this.changeLocCityInvalid  = false;
		this.changeLocCountryInvalid  = false;
        LocService.setChangeCountryModalStatus(statusVal);
        $rootScope.toggleModalDisplay('choose_loc_pop',statusVal,$event);
        var timerId = $interval(function() {
            if( self.countries !== null ) {
                setSelectedCountry();
                $interval.cancel(timerId);
            }
        }, 100);
    };

    var setSelectedCountry = function() {
        var currentCountry = LocService.getCurrentCountry();

        if( self.selectedCountry === null && currentCountry !== null ) {
            for( var prop in self.countries ) {
                if( self.countries[prop]['id'] == currentCountry.id ) {
                    self.selectedCountry = self.countries[prop];
                    break;
                }
            }
        }

        if( self.selectedCountry === null ) {
            self.selectedCountry = self.countries[0];
        }
        self.selectChangeLocCountry = self.selectedCountry;
		self.setChangeLocCountry();
        //self.setChangeLocCountry(self.selectedCountry);
    };

    this.toggleCountryList = function($event) {
        $event.preventDefault();
        if (LocService.showCountryList.display == 'block')
            LocService.showCountryList.display = 'none';
        else
            LocService.showCountryList.display = 'block';
		LocService.showCityList.display = 'none';
    }

	this.toggleCityList = function($event) {
        $event.preventDefault();
        if (LocService.showCityList.display == 'block')
            LocService.showCityList.display = 'none';
        else
            LocService.showCityList.display = 'block';
		LocService.showCountryList.display = 'none';
    }

    this.countryListDisplay = LocService.showCountryList;
    this.cityListDisplay = LocService.showCityList;

    this.setChangeLocCountry = function() {
		var citiesData;
		var countryObj = self.selectChangeLocCountry;
		if(typeof countryObj != 'undefined' && countryObj != null){
			self.changeLocCountryInvalid  = false;
			if(typeof countryObj.cities[0] == 'undefined'){
				citiesData = {"0":{"id":countryObj.cities['id'],"name":countryObj.cities['name'],"course_id":countryObj.cities['course_id']}};
			}else{
				citiesData = countryObj.cities;
			}

		}else{
			citiesData = {"0":{"id":"","name":"Select City","course_id":""}};
		}
		self.changeLocCityInvalid  = false;
		self.selectChangeLocCities = citiesData;
		self.selectChangeLocCity = {"id":'',"name":'Select City',"course_id":''};

		LocService.showCountryList.display = 'none';

    }

    this.changeLocCityInvalid = false;
	this.changeLocCountryInvalid = false;
	this.changeLocation = function(currentCountry, currentCity){
        if(self.selectChangeLocCountry == null){
            self.changeLocCountryInvalid = true;
            return false;
        }else if(self.selectChangeLocCity == null || typeof self.selectChangeLocCity.id == 'undefined' || self.selectChangeLocCity.id == '' || self.selectChangeLocCity.id == null){
            self.changeLocCityInvalid = true;
            return false;
        }

        $scope.gCPCJ.gaFireOnCoursePageChangeCitySuccess(currentCountry + '-' + currentCity, self.selectChangeLocCountry.name +  '-' + self.selectChangeLocCity.name);
        var href = window.location.pathname;
        href = href + "?cityId="+self.selectChangeLocCity.id+'&redirect=pdpPage';
        var ua = navigator.userAgent.toLowerCase();
        if (isIpad != 0 || (ua.indexOf('safari') != -1 && ua.indexOf('chrome') == -1)) { //Remove redirection in case of safari and ipad
            href = href.replace('&redirect=pdpPage', '');
        }
        if (location.hash) {
            href = href + location.hash;
        }
        window.location.href = href;
    }

    this.showAllCities = function(stateObj) {
        self.allCities = stateObj.cities;
    }

    this.changeCityLoc = function(cityObj) {
        self.locFormData = {"countryId":this.selectedCountry.id,"cityId":cityObj.id,"cityName":cityObj.name};
        //LocService.changeLocCity(cityObj);
    }

	this.toggleStickyTrainingTypeSelect = function(){
		if(self.stickyTrainingTypeDisplay.display == 'none'){
			self.stickyTrainingTypeDisplay = {'display':'block'};
			setTimeout(function(){document.getElementsByClassName("dropdown_sticky_tr_a")[0].focus();},200);
		}
		else
			self.stickyTrainingTypeDisplay = {'display':'none'};
	}

    this.displayAllBundleCourses = function() {
        return displayAllBundleCoursesFlag;
    };

    this.toggleBundleCourseList = function() {
        if( displayAllBundleCoursesFlag === 1 ) {
            displayAllBundleCoursesFlag = 0;
            //window.scrollTo(0, 400);
        }
        else {
            displayAllBundleCoursesFlag = 1;
        }
    };

    this.showCrsVideo = function() {
        this.isCrsVideoVisible = 1;
        this.videoState = '';
        self.initIntroVideo();
        WebTracking.eventReq.triggerEvent({
          event_id : "sl_eng_intro_video_clicked",
          common : "product"
        });
        $scope.gCPCJ.gaFireOnCoursePage('introvideoclick', user_params.user_id + ' || ' + document.URL + ' || ' + user_params.course_name);
    };

    this.hideCrsVideo = function($event) {
        if(typeof $event != 'undefined')
            $event.stopPropagation();
        this.isCrsVideoVisible = 0;
        this.videoState = 'stop';
        var videoDurationPlayedInSec = typeof youtubePlayerObj !=="undefined" && typeof youtubePlayerObj.j !=="undefined" && typeof youtubePlayerObj.j.currentTime !=="undefined" ? Math.round(youtubePlayerObj.j.currentTime) : 0;
        WebTracking.eventReq.triggerEvent({
          event_id : "sl_eng_intro_video_closed",
          event_data: {
                  'sl_intro_watched_duration' : videoDurationPlayedInSec || 0,
                },
          common : "product"
        });
        $scope.gCPCJ.gaFireOnCoursePage('introvideoclosed', user_params.user_id + ' || ' + document.URL + ' || ' + user_params.course_name);
    };

    self.setCorporateLeadFormStatus = function( pStatus ) {
        CorporateLeadService.setLeadFormStatus( pStatus );
    };

        var gaClassForCoursePage = function() {

            var ga = new gaEventsTracker();
            //gaFireOnCityTrainingPage
            this.gFOCTP = function(fromCity, cityToGo) {
                var currentPageType = this.gaGetCurrentPageType();
                var string = fromCity + ' || ' + cityToGo;
                if(currentPageType == 'generic') {
                    ga.gaFireInteractiveEvents('coursepagegenericcitytraining', string);
                } else if(currentPageType == 'classroom') {
                        ga.gaFireInteractiveEvents('coursepageclassroomcitytraining', string);
                } else if(currentPageType == 'online') {
                    ga.gaFireInteractiveEvents('coursepageonlinecitytraining', string);
                }
            }

            this.gaFireOnCoursePage = function(cat, label) {
                if (typeof label !== 'undefined' && label) {
                    ga.gaFireInteractiveEvents(cat, label);
                } else {
                    ga.gaFireInteractiveEvents(cat);
                }
            }

            this.gaFireOnCourseIntro = function(location) {
                var currentPageType = this.gaGetCurrentPageType();

                if(currentPageType == 'generic') {
                    ga.gaFireInteractiveEvents('coursepagegenericcourseintro', location);
                } else if(currentPageType == 'classroom') {
                        ga.gaFireInteractiveEvents('coursepageclassroomcourseintro', location);
                } else if(currentPageType == 'online') {
                    ga.gaFireInteractiveEvents('coursepageonlinecourseintro', location);
                }
            }


            this.gaFireGenCoursePageTrainSelect = function(switchToTraining) {
                var label = '';
                if(switchToTraining == 'ilt') {
                    label = 'classroom';
                } else if(switchToTraining == 'osl') {
                    label = 'osl';
                }

                var currentPageType = this.gaGetCurrentPageType();

                if(currentPageType == 'generic') {
                    ga.gaFireInteractiveEvents('coursepagegenerictrain', label);
                } else if(currentPageType == 'classroom') {
                    if(switchToTraining == 'osl') {
                        ga.gaFireInteractiveEvents('coursepageclassroomtrain');
                    }
                } else if(currentPageType == 'online') {
                    if(switchToTraining == 'ilt') {
                        ga.gaFireInteractiveEvents('coursepageonlinetrain');
                    }
                }
            }

            this.gaGetCurrentPageType = function() {
                var path = $location.path();
                path = path.substr(path.indexOf('/')+1);
                var returnType = 'generic';
                if(path == 'ilt') {
                    returnType = 'classroom';
                } else if (path == 'osl') {
                    returnType = 'online';
                }
                return returnType;
            }

            this.gaFireCourseAgendaClick = function() {
                ga.gaFireInteractiveEvents('leadformclicked',user_params.user_id + ' || ' + document.URL  + ' || ' + user_params.course_name+ ' || course agenda');
            }

            this.fireEnrollClick = function(type) {
              ga.gaFireInteractiveEvents(type,user_params.user_id + ' || ' + document.URL);
              if( typeof type != 'undefined' && type == 'enroll_online') {
                WebTracking.eventReq.triggerEvent({
                  event_id : "sl_pay_enroll_button_clicked_osl",
                  common : "product"
                });
              }
              if( typeof type != 'undefined' && type == 'enroll_lvc') {
                WebTracking.eventReq.triggerEvent({
                  event_id : "sl_pay_enroll_button_clicked_lvc",
                  common : "product"
                });
              }
              if( typeof type != 'undefined' && type == 'enroll_classroom'){
                 WebTracking.eventReq.triggerEvent({
                  event_id : "sl_pay_enroll_button_clicked_classroom",
                  common : "product"
                });
              }
            }

            this.gaFireCoursePageQuerySubmit = function() {
                var currentPageType = this.gaGetCurrentPageType();

                if(currentPageType == 'generic') {
                    ga.gaFireInteractiveEvents('coursepagegenericqueryformsubmit');
                } else if(currentPageType == 'classroom') {
                    ga.gaFireInteractiveEvents('coursepageclassroomqueryformsubmit');
                } else if(currentPageType == 'online') {
                    ga.gaFireInteractiveEvents('coursepageonlinequeryformsubmit');
                }
            }
            //gaFireCoursePagePreviewTry
            this.gFCPPT = function(lesson) {
                var currentPageType = this.gaGetCurrentPageType();
                // ga.gaFireInteractiveEvents('leadformclicked',user_params.user_id + ' || ' + document.URL + ' || course preview || '+user_params.course_name + ' || '+lesson + ' || '+currentPageType);
            }

            this.gaFireOnCoursePageViewOtherTrain = function(currentLocation, selectedLocation) {
                var currentPageType = this.gaGetCurrentPageType();

                if(currentPageType == 'generic') {
                    ga.gaFireInteractiveEvents('coursepagegenericviewothertrain');
                } else if(currentPageType == 'classroom') {
                    ga.gaFireInteractiveEvents('coursepageclassroomviewothertrain');
                } else if(currentPageType == 'online') {
                    ga.gaFireInteractiveEvents('coursepageonlineviewothertrain');
                }
            }

            this.gaFireOnCourseEnroll = function() {
                var currentPageType = this.gaGetCurrentPageType();
                if(currentPageType == 'classroom') {
                    ga.gaFireInteractiveEvents('coursepageclassroomenroll');
                } else if(currentPageType == 'online') {
                    ga.gaFireInteractiveEvents('coursepageonlineenroll');
                }
            }



            this.gaFireFPTClick = function($event) {
                ga.gaFireInteractiveEvents('fpt_link_course',user_params.user_id + ' || ' + document.URL + ' || ' + $event.target.href);
            }

            this.fireProgramAlsoViewedSection = function(gotoLink, type, name) {
              WebTracking.eventReq.triggerEvent({
                event_id : "sl_nav_people_also_bought_courses_clicked",
                event_data: {
                  'sl_destination_link' : gotoLink || '',
                  'sl_destination_product_type' : type || '',
                  'sl_destination_product_name' : name || '',
                },
                common : "product",
              });
                ga.gaFireInteractiveEvents('peopleAlsoViewedSectionClicked',user_params.user_id + ' || ' + document.URL + ' || ' + gotoLink);
            }


            this.gaFireOnCourseConvenientTry = function() {
                ga.gaFireInteractiveEvents('coursepageconvenienttry');
            }

            this.gaFireOnCourseConvenientSubmit = function() {
                ga.gaFireInteractiveEvents('coursepageconvenientsubmit');
            }

            this.gaFireOnCoursePageChangeCityTry = function() {
                ga.gaFireInteractiveEvents('coursepageiltchangecitytry');
            }

            this.gaFireOnCoursePageChangeCitySuccess = function(currentLocation, selectedLocation) {
                ga.gaFireInteractiveEvents('coursepageiltchangecitysuccess', currentLocation + ' || ' + selectedLocation);
            }

            this.gaFireOnCoursePageCorporateTry = function() {
                var currentPageType = this.gaGetCurrentPageType();

                if(currentPageType == 'generic') {
                    ga.gaFireInteractiveEvents('coursepagegenericcorporatetry');
                } else if(currentPageType == 'classroom') {
                    ga.gaFireInteractiveEvents('coursepageclassroomcorporatetry');
                } else if(currentPageType == 'online') {
                    ga.gaFireInteractiveEvents('coursepageonlinecorporatetry');
                }
            };

            this.gaFireOnCoursePageCorporateSuccess = function() {
                var currentPageType = this.gaGetCurrentPageType();

                if(currentPageType == 'generic') {
                    ga.gaFireInteractiveEvents('coursepagegenericcorporatesuccess');
                } else if(currentPageType == 'classroom') {
                    ga.gaFireInteractiveEvents('coursepageclassroomcorporatesuccess');
                } else if(currentPageType == 'online') {
                    ga.gaFireInteractiveEvents('coursepageonlinecorporatesuccess');
                }
            };

            this.gaFireEventsGeneric = function(pGaKey, pGaLabel) {
                ga.gaFireInteractiveEvents(pGaKey, user_params.user_id + ' || ' + document.URL + ' || ' + pGaLabel);
            };

            this.gaOnloadPageType = function(type,name){
                if(type === 'oneTime'){
                    ga.gaFireInteractiveEvents('onloadBundlePageType',name);
                }else if(type === 'subscription' ){
                    ga.gaFireInteractiveEvents('onloadSubsPageType',name);
                }
            }

            this.gaOnEnroll = function(){
                    ga.gaFireInteractiveEvents('enrollBundle',user_params.user_id + ' || ' + document.URL);
                    var trainingType = user_params.sl_product_training_type || '';
                    if(trainingType == 'osl') {
                        WebTracking.eventReq.triggerEvent({
                            event_id: "sl_pay_enroll_button_clicked_osl",
                            common: "product"
                        });
                    }
                    if(trainingType == 'lvc') {
                        WebTracking.eventReq.triggerEvent({
                            event_id: "sl_pay_enroll_button_clicked_lvc",
                            common: "product"
                        });
                    }
                    if(trainingType == 'classroom') {
                        WebTracking.eventReq.triggerEvent({
                            event_id: "sl_pay_enroll_button_clicked_classroom",
                            common: "product"
                        });
                    }
            }

            this.gaBuyThisItem = function(type,name){
                if(type === 'oneTime'){
                    ga.gaFireInteractiveEvents('buyThisBundle',name);
                }else if(type === 'subscription' ){
                    ga.gaFireInteractiveEvents('startFreeTrail',name);
                }
            }
            this.gaGdprOptInCheckbox = function($event,cname,sitemodule) {
                if (isEuro && $event.target.checked){
                    var pGaKey="gdprOptinCheckboxChecked";
                    var pGaLabel= user_params.user_id + ' || ' + cname + ' || ' + sitemodule;
                    ga.gaFireInteractiveEvents(pGaKey, pGaLabel);
                }
            };
        };

        $scope.gCPCJ = new gaClassForCoursePage();

//        this.setReviewsStatus = function($event, no, val) {
//            $event.preventDefault();
//            showReviews[no] = val;
//        }
//
//        this.getReviewStatus = function(id) {
//            if (typeof showReviews[id] != 'undefined') {
//                return showReviews[id];
//            }
//            return 0;
//        }

        this.setCourseDir = function() {
            var courseDirs = document.getElementsByClassName('course-directors-div'),
            countCourseDirs = courseDirs.length;
            var randomNum = this.getRandomInt(1,countCourseDirs);
            this.randomCourseDir = randomNum;
        }
        this.getCourseDir = function() {
            return this.randomCourseDir;
        }

        this.getRandomInt = function(min, max) {
            return Math.floor(Math.random() * max) + min;
          }
          this.disMarketoFrm = 0;
            this.showMarketoForm = function(val, event, type,btnText,place) {
                if (typeof event != 'undefined' && event) {
                    if (event.target.classList.contains('popup_country_wrapper')) {
                    }else{
                        return;
                    }
                }
                if (typeof place !== 'undefined') {
                    $rootScope.webEventFiredformId = place;
                }
                this.disMarketoFrm = val;
                var label = '';
                if(val == 1){
                    if(type == 'course')
                        label += 'B2b_query_course_page';
                    else if(type == 'dt-page')
                        label += 'DT_QueryBox';
                    else
                        label += 'B2b_query_course_page';
                    if(user_params.sl_page_type === 'corp train page') {
                        if(typeof $scope.cSiteModuleCustom === "string" && $scope.cSiteModuleCustom.length > 0) {
                            label = $scope.cSiteModuleCustom;                        
                        } else if(typeof $scope.cSiteModule === "string" && $scope.cSiteModule.length > 0) {
                            label = $scope.cSiteModule;                        
                        }
                    }
                    if(user_params.sl_page_type === 'corp train page' && typeof btnText == 'undefined' || !btnText && $scope.templateTitle) {
                        btnText = $scope.templateTitle;
                    }
                    WebTracking.setUserParams("sl_site_module", label);
                    WebTracking.eventReq.triggerEvent({
                      event_id : "sl_lead_module_initiated",
                      event_data: {
                        'sl_lead_button_text' : btnText || '',
                        'sl_lead_type' : 'b2b',
                        'sl_site_module' : label,
                      },
                      common : "product",
                      user_attributes: ['sl_lead_type']
                    });
                    var label = user_params.user_id + ' || ' + document.URL + ' || ' + user_params.course_name + ' || ' +label;
                    $scope.gCPCJ.gaFireOnCoursePage('leadformclicked',label);
                }

                if(val == 0){

                    if (type == 'dt-page') {
                        label += 'DT_QueryBox';
                    } else {
                        label = 'B2b_query_course_page';
                    }
                    if(user_params.sl_page_type === 'corp train page') { 
                        if(typeof $scope.cSiteModuleCustom === "string" && $scope.cSiteModuleCustom.length > 0) {
                            label = $scope.cSiteModuleCustom;                        
                        } else if(typeof $scope.cSiteModule === "string" && $scope.cSiteModule.length > 0) {
                            label = $scope.cSiteModule;                        
                        }
                    }
                    WebTracking.eventReq.triggerEvent({
                      event_id : "sl_lead_form_closed",
                      event_data: {
                        'sl_lead_type' : 'b2b',
                        'sl_site_module' : label,
                      },
                      common : "product",
                      user_attributes: ['sl_lead_type']
                    });
                }
            };

        this.pricingRangeLearnersModal = 0;
        this.showPricingRangeLearners = function(val, event) {
            this.pricingRangeLearnersModal = val;
            if(val == 1){
                $scope.gCPCJ.gaFireOnCoursePage('Cp_LearnersRangePricing_OSL_Modal_Open',user_params.course_name + ' || ' + document.URL);
            }
        };
        this.pricingRangeLvcModal = 0;
        this.showPricingRangeLvc = function(val, event) {
            this.pricingRangeLvcModal = val;
            if(val == 1){
                $scope.gCPCJ.gaFireOnCoursePage('Cp_LearnersRangePricing_LVC_Modal_Open',user_params.course_name + ' || ' + document.URL);
            }
        };
        this.addRemoveClassInBody = function(val){
            var class_name = 'popup_open_body';
             if(val == 1){
                 //Add Class in Body
                 document.body.classList.add(class_name);
             } else {
                 //Remove Class in Body
                 document.body.classList.remove(class_name);
             }
        };
})
.controller('CoursePageClassroomCtrl',function($scope, $timeout){
    $scope.cityFilter = false;
    $scope.version = new Date().getTime();
    $scope.filterBatch = [];

    // Object equal check
    var isEquivalent = function(a, b) {
        var aProps = Object.getOwnPropertyNames(a);
        var bProps = Object.getOwnPropertyNames(b);
        if (aProps.length != bProps.length) {
            return false;
        }
        for (var i = 0; i < aProps.length; i++) {
            var propName = aProps[i];
            if (a[propName] !== b[propName]) {
                return false;
            }
        }
        return true;
    }

    $scope.initClass = function(cityPageId) {
        $scope.filterBatch = $scope.batches;
        $timeout(function () {
            if(cityPageId) {
                $scope.city = cityPageId;
            } else {
                // Set default city
                var locatorCookie = getCookieByName('locatori9');
                var locatorCookieObj = JSON.parse(locatorCookie);
                var cityId = locatorCookieObj.default_city_id_new || null;
                if(locatorCookie) {
                    var userCityId = locatorCookieObj.city_id;
                    if($scope.cityList) {
                        for(ci in $scope.cityList) {
                            if(userCityId == $scope.cityList[ci].id) {
                                cityId = userCityId;
                            }
                        }
                    }
                }

                var cityClassFlag = false;
                if(cityId) {
                    if($scope.cityList) {
                        for(ci in $scope.cityList) {
                            if(cityId == $scope.cityList[ci].id) {
                                cityClassFlag = true;
                            }
                        }
                    }
                }

                if(cityClassFlag) {
                    $scope.city = cityId;
                } else {
                    $scope.city = Object.keys($scope.cityList)[0];
                }
            }
        },100);
    }

    $scope.$watch('city', function(newValue, oldValue) {
       console.log("Loaded");
        var filterBatch = [];
        if(newValue) {
            for(i in $scope.batches) {
                var batch = $scope.batches[i];
                if(batch && batch.city_id == $scope.city) {
                    filterBatch.push(batch);
                }
            }
        } else {
            filterBatch = $scope.batches;
        }

        // Re render carousal
        if(!isEquivalent(filterBatch, $scope.filterBatch)) {
            angular.element(document.querySelectorAll('#classroom-carousal .c_list_item')).remove();
            $timeout(function () {
                $scope.filterBatch = filterBatch;
                $scope.trigger = new Date().getTime();
            },10);
        }
        });
})

.controller('CoursePageOnlyClassroomCtrl',function($scope, $timeout,$document,PostReqService,$compile){
    $scope.cityFilter = false;
    $scope.version = new Date().getTime();
    $scope.filterBatch = [];
    $scope.trainerPopUp = [];
    $scope.popUpOpen = 0;
    $scope.viewMoreClicked = 0;
    $scope.isCoursePageOnlyClassroom=false;
    this.classroomFormData = {};
    $scope.setClassRoomFlag=function(isCoursePageOnlyClassroom){
        if(isCoursePageOnlyClassroom)
        $scope.isCoursePageOnlyClassroom=true;
    }
    angular.element($document).ready(function () {
         if($scope.isCoursePageOnlyClassroom){
             $scope.loadTemplate();
              
         }
    });
   
    $scope.loadTemplate = function () {
                var classPartialTemplateData={classroom_trainerinfo_popup:{}};
                var paramObj={};
                paramObj['template_params']=JSON.stringify(classPartialTemplateData);
                paramObj['template_page']='classroomtrainerinfo';
                PostReqService.sendPostRequest(baseApiUrlNocache + '?method=loadTemplatesThroughAjax', paramObj)
                        .then(function (data) {
                            if (data != null && data.data.status == 'success') {
                               this.form_data = data.data.data;
                               angular.forEach(this.form_data, function (value, index) {
                                    var elem = document.getElementById(index);
                                    if (elem !== undefined && elem !== null && elem.innerHTML === "") {
                                        angular.element(elem).html(value);
                                        $compile(angular.element(elem).contents())($scope);
                                    }
                                })
                            }
                        });
    }
    this.submitClassroomForm = function(pCourseId, pWorkshopId, pTrainingType) {
        var pageSource = window.location.href;
        this.classroomFormData = {"itemId":pCourseId, "batchId":pWorkshopId, 'trainingTypeId':pTrainingType,'pageSource':pageSource,'campaignData':encodeURIComponent(JSON.stringify(getCampaignDetails()))};
    };
    $scope.detailsDisplayClose = function(div_id) {
        var elem = document.getElementById(div_id);
        elem.classList.add("hide_with_height");

    }

    $scope.detailsbuttontoggle = function(div_id) {
        var elem = document.getElementById(div_id);
        (elem.classList.contains('hide_with_height')) ? elem.classList.remove("hide_with_height") : elem.classList.add("hide_with_height");
    }

    $scope.initFuncnewCRdesign = function(city_name_first){
       //All hide class
       $scope.hideAllElementsByClassName('details_section_batch');
       $scope.city = city_name_first;
    }

    $scope.hideAllElementsByClassName = function (cls_name) {
        var myClasses = document.querySelectorAll('.'+cls_name);
        for (i = 0; i < myClasses.length; i++) {
            myClasses[i].classList.add("hide_with_height");
        }
    }
    $scope.loadPopupTrainerDetails = function(trainerData){
       $scope.trainerPopUp = trainerData;
       if(trainerData){
         $scope.popUpOpen = 1;
         document.getElementById('trainer_details_popup').style.display = 'block';
       }
    }

    $scope.closePopupTrainerDetails = function(){
       $scope.trainerPopUp = [];
       $scope.popUpOpen = 0;
       document.getElementById('trainer_details_popup').style.display = 'none';
    }
})

.controller('NoWorkshopFoundController',function($scope, $rootScope,PostReqService){
	$scope.formSubmittedStyle = {'display':'none'};
	$scope.queryAgree = 1;
	$scope.helpers = new helpers();
	$scope.queryFormDivStyle = {'display':'block'};
	$scope.querySuccessDivStyle = {'display':'none'};
	$scope.queryAgree = 1;
        var PHONE_MAX_LENGTH = 15;

	$scope.agreeQueryForm = function($event){
		//$event.preventDefault();
		$scope.agreeClicked = 1;
		if($scope.queryAgree == 1)
			$scope.queryAgree = 0;//@review should use null
		else
			$scope.queryAgree = 1;
                    //@review should use return statement
	}

            $scope.submitNoWorkshopForm = function(form, dataArr) {
                if (form.$invalid) {
                    $scope.queryStatusMsg = "Oops! Please ensure all fields are valid."
                    $scope.queryStatusClass = "error_msg hidden";
                    if ($scope.queryAgree == 0 && $scope.agreeClicked == 1) {
                        return false;
                    }
                    return $scope.helpers.FormNotValid(form);
                } else if ($scope.queryAgree == 0 && $scope.agreeClicked == 1) {
                    return false;
                }

                var paramsArr = {name: $scope.queryName, email: $scope.queryEmail, phone: $rootScope.queryPhoneCode + $scope.queryPhone, queryTxt: $scope.queryTxt, query: $scope.queryTxt, agreeToContact: $scope.queryAgree, queryTyp: 'no_workshop_found', agreeToRcvUpdate: 0, batchDate: ''};

                var obj3 = {};
                for (var attrname in paramsArr) {
                    obj3[attrname] = paramsArr[attrname];
                }
                for (var attrname in dataArr) {
                    obj3[attrname] = dataArr[attrname];
                }
                var locatorCookie = getCookieByName('locatori9');
                var locatorCookieObj = JSON.parse(locatorCookie);
                obj3['countryId'] = locatorCookieObj.country_id;
                obj3['countryName'] = $scope.currentCountry.name;
                obj3['cityId'] = locatorCookieObj.city_id;
                obj3['cityName'] = locatorCookieObj.name;
                obj3['method'] = 'saveNoWorkshopFoundData';
                PostReqService.sendPostRequest(baseApiUrlNocache, obj3)
                        .then(function(response) {
                            var data = response.data;
                            if (data.status == "Success") {
                                var gaEventObj = new gaEventsTracker();
                                gaEventObj.gaFireOnCoursePageNoWorkshopFormSubmit();
                                obj3['customerType'] = 'B2C';
                                obj3['leadTrainingType'] = 'classroom';
                                obj3['leadSourceString'] = document.URL;
                                obj3['tagName'] = 'WorkshopNotAvailable';
                                obj3['leadSource'] = fetchUTMSource();
                                obj3['type'] = 'no_workshop';
                                obj3['productTypeId'] = user_params.productTypeId;
                                obj3['billingTypeId'] = user_params.billingTypeId;
                                obj3['method'] = 'saveCallback';
                                obj3['GCLID'] = getGCLID();
                                PostReqService.sendPostRequest(baseApiUrlNocache, obj3).then(function(data) {
                                    if (data != null) {
                                        if (data.data.status == 'Success') {
                                            setUpDataLayer('leadCapture', 'noWorkshopFound', {'leadId': data.data.result.key});
                                            $rootScope.gaCommonLeadCaptures.gaFireLeadCapture('leadcaptureworkshopnotavail');
                                            $scope.queryFormDivStyle = {'display': 'none'};
                                            $scope.querySuccessDivStyle = {'display': 'block'};
                                            $scope.queryTxt = "";
                                            $scope.queryName = "";
                                            $scope.queryEmail = "";
                                            $scope.queryPhone = "";
                                        } else if (typeof data.data.msg != 'undefined' && data.data.msg != '') {
                                            $scope.queryStatusMsg = data.data.msg;
                                        }
                                    } else {
                                        $scope.queryStatusMsg = data.data.msg;
                                    }
                                });
                            } else {
                                $scope.queryStatusMsg = "Some error occurred. Please try again later."
                                $scope.queryStatusClass = "error_msg";
                            }
                        });
            }
	$scope.$watch('queryPhone', function(newValue) {
		if(isNaN(newValue)){
			$scope.noWorkshopForm.queryPhone.$setValidity('required', false);
		}else if(newValue.length > PHONE_MAX_LENGTH){
			$scope.noWorkshopForm.queryPhone.$setValidity('required', false);
		}

	});



})
.controller('ConvenientScheduleController',function($scope,LocService,$rootScope,PostReqService){
	$scope.formSubmittedStyle = {'display':'none'};

	$scope.helpers = new helpers();
	$scope.queryFormDivStyle = {'display':'block'};
	$scope.querySuccessDivStyle = {'display':'none'};
	$scope.agreeEmailClicked = 1;
	$scope.agreePhnClicked = 1;
	$scope.emailAgreeCheck = 1;
	$scope.phnAgreeCheck = 1;

	$scope.personName = '';
	$scope.personEmail = '';
	$scope.personPhone = '';
	$scope.batchDate = '';
	$scope.$watch(function() {
	  return $rootScope.resetMsgs;
	}, function(newVal) {
	  if(newVal == 1){
		$scope.queryStatusMsg = ""
		$scope.queryStatusClass = "";
	  }
	});

	var validateDate = function (testdate) {
		var date_regex = /^(0[1-9]|1[0-2])\/(0[1-9]|1\d|2\d|3[01])\/(20)\d{2}$/ ;
		return date_regex.test(testdate);
	}


	$scope.setUpdatesAgreeCheck = function($event){
		//$event.preventDefault();
		$scope.agreeClicked = 1;
		if($scope.emailAgreeCheck == 1)
			$scope.emailAgreeCheck = 0;//@review should use null
		else
			$scope.emailAgreeCheck = 1;
                    //@review should use return statement
	}

	$scope.setPhnAgreeCheck = function($event){
		//$event.preventDefault();
		if($scope.phnAgreeCheck == 1)
			$scope.phnAgreeCheck = 0;//@review should use null
		else
			$scope.phnAgreeCheck = 1;
                    //@review should use return statement
	}

	$scope.$watch('batchDate',function(newVal){
		if(validateDate($scope.batchDate) == false){
			$scope.convschedForm.batchDate.$invalid = true;
		}else{
			$scope.convschedForm.batchDate.$invalid = false;
		}
	});

	$scope.$watch(
                function() {
                    if(typeof $scope.cpg != 'undefined' && typeof $scope.cpg.setLetUsKnowTrigger != 'undefined') {
                        return $scope.cpg.setLetUsKnowTrigger;
                    } else {
                        return false;
                    }
                },function(newVal){
                    if(newVal) {
                        LocService.getCountryData().then(function(data) {
                            $scope.countryDataStatic = data;
                        });
                    }
	});


            $scope.submitConvenientScheduleForm = function(form, dataArr) {
                if (form.$invalid) {
                    $scope.queryStatusMsg = "Oops! Please ensure all fields are valid."
                    $scope.queryStatusClass = "error hidden";
                    $rootScope.adjustDivHeight = {'height':'470px'};
                    return $scope.helpers.FormNotValid(form);
                } else if ($scope.emailAgreeCheck == 0 && $scope.agreeClicked == 1) {
                    return false;
                } else if (validateDate($scope.batchDate) == false) {
                    return false;
                }

                var paramsArr = {name: $scope.personName, email: $scope.personEmail, phone: $rootScope.queryPhoneCode + $scope.personPhone, batchDate: $scope.batchDate, agreeToContact: $scope.phnAgreeCheck, agreeToRcvUpdate: $scope.emailAgreeCheck, queryTyp: 'no_convenient_sch'};
                $scope.gCPCJ.gaFireOnCourseConvenientSubmit();
                var obj3 = {};
                for (var attrname in paramsArr) {
                    obj3[attrname] = paramsArr[attrname];
                }
                for (var attrname in dataArr) {
                    obj3[attrname] = dataArr[attrname];
                }
                var locatorCookie = getCookieByName('locatori9');
                var locatorCookieObj = JSON.parse(locatorCookie);

                obj3['countryId'] = locatorCookieObj.country_id;
                obj3['countryName'] = $scope.currentCountry.name;
                obj3['cityId'] = locatorCookieObj.city_id;
                obj3['cityName'] = locatorCookieObj.name;
                obj3['method'] = 'saveNoWorkshopFoundData';
                $rootScope.resetMsgs = 0;
                PostReqService.sendPostRequest(baseApiUrlNocache, obj3)
                        .then(function(response) {
                            var data = response.data;
                            if (data.status == "Success") {
                                obj3['customerType'] = 'B2C';
                                obj3['leadTrainingType'] = 'classroom';
                                obj3['leadSourceString'] = document.URL;
                                obj3['tagName'] = 'schedule';
                                obj3['leadSource'] = fetchUTMSource();
                                obj3['type'] = 'schedule';
                                obj3['productTypeId'] = user_params.productTypeId;
                                obj3['billingTypeId'] = user_params.billingTypeId;
                                obj3['method'] = 'saveCallback';
                                obj3['GCLID'] = getGCLID();
                                PostReqService.sendPostRequest(baseApiUrlNocache, obj3)
                                        .then(function(data) {
                                            if (data != null) {
                                                if (data.data.status == 'Success') {
                                                    setUpDataLayer('leadCapture', 'noWorkshopFound', {'leadId': data.data.result.key});
                                                    $rootScope.gaCommonLeadCaptures.gaFireLeadCapture('leadcaptureworkshopnotavail');
                                                    form.$setPristine();
                                                    $scope.queryStatusMsg = "Your details has been successfully submitted. Our customer support team will get in touch with you soon."
                                                    $scope.queryStatusClass = "success_text";
                                                    $rootScope.convSuccMsg = 1;
                                                    $scope.personName = "";
                                                    $scope.personEmail = "";
                                                    $scope.personPhone = "";
                                                    $scope.batchDate = "";
                                                    $rootScope.convSuccMsg = 1;
                                                    $rootScope.adjustDivHeight = {'height':'215px'};
                                                } else if (typeof data.data.msg != 'undefined' && data.data.msg != '') {
                                                    $scope.queryStatusMsg = data.data.msg;
                                                }
                                            } else {
                                                if (typeof data.data.msg != 'undefined' && data.data.msg != '') {
                                                    $scope.queryStatusMsg = data.data.msg;
                                                }
                                            }
                                        });
                            } else {
                                $scope.queryStatusMsg = "Some error occurred. Please try again later."
                                $scope.queryStatusClass = "error";
                            }
                        });
            }


})

.controller('CourseAgendaCtrl', function (LocService,$scope, $rootScope, PostReqService, $cookies, $timeout, LeadService) {
     self = this;
     $rootScope.showCourseAgenda = false;
     $scope.isAagreeCheckDirty = false;
     $scope.cAgreeCheck = false;
     $scope.submitAgendaUrl = '';
     $scope.isEuro = user_params.isEuro;
     $scope.hasValidation = true;
     var PHONE_MAX_LENGTH = 15;
     $scope.submitCourseAgendaPopUp= function (agendaUrl, btnText) {
        var siteModule = 'course agenda';
        WebTracking.eventReq.triggerEvent({
            event_id: "sl_lead_module_initiated",
            event_data: {
                'sl_lead_button_text': btnText || '',
                'sl_lead_type': 'b2c',
                'sl_site_module': siteModule,
            },
            common: "product",
            user_attributes: ['sl_lead_type']
        });
        agendaUrl = $rootScope.submitCourseAgendaPopUp;
        $scope.submitAgendaUrl = agendaUrl;
        //    var agendaCookie = getCookieByName('_cpruid');
        var agendaCookie = getCookieByName('_user_ld_info');
        var agendaLeadCreated=false;
        if(typeof agendaCookie !=="undefined"){
            var courseId=user_params.course_id;
            courseId='c'+courseId;
            var cookieCourseIds = agendaCookie.split(',');
            if(cookieCourseIds.indexOf(courseId) !==-1){
                agendaLeadCreated=true;
            }
        }
        if (!$scope.isEuro) {
            if ($cookies[user_params.enterpriseCountCookieName] == undefined || $cookies[user_params.enterpriseCountCookieName] == '') {
                 if(LeadService.isSkipPopup(siteModule)){
                     if(agendaCookie){
                         $scope.submitAgendaLead($scope.submitAgendaUrl, agendaLeadCreated, true);
                     }
                     else{
                         $scope.submitAgendaLead($scope.submitAgendaUrl,false,true);
                     }
                 }
                 else
                     $rootScope.showCourseAgenda = true;
            }
            
             
             
             else {
                 if(LeadService.isSkipPopup(siteModule)){
                    if(agendaCookie){
                        $scope.submitAgendaLead($scope.submitAgendaUrl, agendaLeadCreated, true);
                    }
                    else{
                        $scope.submitAgendaLead($scope.submitAgendaUrl,false,true);
                    }
                }
                else{
                    window.open($scope.submitAgendaUrl, '_blank');
                }               
        }
    }
        // if country is euro and not b2b portal
        if($scope.isEuro /* && ($cookies[user_params.enterpriseCountCookieName] == undefined || $cookies[user_params.enterpriseCountCookieName] == '')*/) {
            var optinSet = typeof getCookieByName(user_params.OPTIN_COOKIE) != 'undefined' ? true : false;
            var optin = getCookieByName(user_params.OPTIN_COOKIE) == 1 ? true : false;
                    if (LeadService.isSkipPopup(siteModule)) {
                        if ((optin == true) || agendaCookie || !optinSet) {      
                     $scope.submitAgendaLead($scope.submitAgendaUrl, agendaLeadCreated, true);
                        } 
                        else
                            window.open($scope.submitAgendaUrl, '_blank');
                    }
                    else {
                        if ($cookies[user_params.enterpriseCountCookieName]) {
                            window.open($scope.submitAgendaUrl, '_blank');
                        } else {
                            if ((optin == true) || !optinSet) {
                                $rootScope.showCourseAgenda = true;
                            } else {
                                window.open($scope.submitAgendaUrl, '_blank');
                            }
                        }
                    }
          }
    }

    this.previewLeadForm = {
        phone : { error: 'Please enter a valid phone number' },
        email : { error: 'Please enter a valid email' },
        cAgreeCheck : { error: 'Please accept the agreement' }
    };
    var leadInitiated = false;
    $scope.intiateLead = function () {
        if (!leadInitiated) {
            WebTracking.eventReq.triggerEvent({
                event_id : "sl_lead_user_initiated_lead_form",
                event_data: {
                  'sl_lead_type' : 'b2c',
                  'sl_site_module' : 'course agenda',
                },
                common : "product",
                user_attributes: ['sl_lead_type']
            });
            leadInitiated = true;
        }
    }

    $scope.submitAgendaLead = function (agendaUrl, fetchFromDwnAgenda, isValidate, isFormSubmit) {
        isFormSubmit = (typeof isFormSubmit == 'undefined') ? false : isFormSubmit;
        var siteModule = 'course agenda';
        $scope.isAagreeCheckDirty = true;
        $scope.previewLeadForm.registerStatus = false;
        var userEmail = '';
        var userPhone = '';
        var userName = '';
        if (isValidate) {

        } else {
            if ($scope.hasValidation) {
                userEmail = $scope.previewLeadForm.email.$modelValue;
                userPhone = $scope.queryPhoneCode + $scope.previewLeadForm.phone.$modelValue;
                userName = $scope.previewLeadForm.email.$modelValue;
                if ($scope.previewLeadForm.$invalid) {
                    if ($scope.previewLeadForm.email.$invalid) {
                        $scope.previewLeadForm.email.$setViewValue($scope.previewLeadForm.email.$viewValue);
                    }
                    if ($scope.previewLeadForm.phone.$invalid) {
                        $scope.previewLeadForm.phone.$setViewValue($scope.previewLeadForm.phone.$viewValue);
                    }
                    return;
                }
                if (!$scope.cAgreeCheck) {
                    return;
                }
            }
        }
        if (document.getElementById("agenda_lead")) {
            document.getElementById("agenda_lead").disabled = true;
        }
        if (user_params.isEuro) {
                setCookie(user_params.OPTIN_COOKIE, 0, 90);           
        }

        window.open($scope.submitAgendaUrl, '_blank');        
        var optin = getCookieByName(user_params.OPTIN_COOKIE) == 1 ? true : false;
        if (user_params.isEuro && !optin && !LeadService.isSkipPopup(siteModule) && !$scope.cAgreeCheck) { 
            $scope.disableAgendLeadPopup();
            return;
        }

//         if (!$scope.hasValidation ) {
//              $rootScope.showCourseAgenda = false;
//              $scope.hideAgendLeadPopup();
//              return;
//         }
//         if(!userEmail){
//             return;
//         }/*

        /*
         * Old Params
         * var obj3 = {
         name: userName,
         email: userEmail,
         phone: userPhone,
         queryTxt: "Downloaded Course Agenda",
         query: "Downloaded Course Agenda",
         agreeToContact: $scope.cAgreeCheck,
         queryTyp: 'course-agenda-popup',
         courseId: user_params.course_id,
         courseName: user_params.course_name
         };
         obj3['customerType'] = 'B2C';
         obj3['leadTrainingType'] = 'Not Sure';
         obj3['leadSourceString'] = document.URL;
         obj3['tagName'] = 'course agenda';
         obj3['leadSource'] = fetchUTMSource();
         obj3['type'] = 'course agenda';
         obj3['productTypeId'] = user_params.productTypeId;
         obj3['billingTypeId'] = user_params.billingTypeId;
         obj3['method'] = 'saveCallback';
         obj3['GCLID'] = getGCLID();
         obj3['fetchData'] = $rootScope.isLoggedIn ? 1 : 0;
         obj3['fetch_from_cpr_uid'] = false;
         obj3['save_cpr'] = 1;
         if (!$rootScope.isLoggedIn) {
         if (fetchFromCpr)
         obj3['fetch_from_cpr_uid'] = fetchFromCpr;
         }
         */
        if (fetchFromDwnAgenda === false || fetchFromDwnAgenda === null) {
            if (document.getElementById("course_agenda_popup")) {
                var elm = document.getElementById("course_agenda_popup");
                elm.style.pointerEvents = "none";
            } 
            webengage.onReady(function () {
                var siteModule = 'course agenda';
                var dwnAgendaCookieCIds = getCookieByName('_user_ld_info');
                if ((typeof dwnAgendaCookieCIds !== "undefined" && dwnAgendaCookieCIds) || LeadService.isSkipPopup(siteModule)) {
                    var userInfo = [];
                    if(typeof webengage.state != 'undefined' && typeof webengage.state.getForever != 'undefined'){
                        userInfo = webengage.state.getForever().uattr;
                        userEmail = userInfo.we_email;
                        userPhone = userInfo.we_phone;
                    }
                }
                var webEngageLeadParams = [];
                if (typeof webengage.state != 'undefined' && typeof webengage.state.getForever != 'undefined') {
                    webEngageLeadParams = webengage.state.getForever().uattr;
                }
                var eventData = {
                    'sl_lead_type': 'b2c',
                    'sl_site_module': siteModule,
                    'sl_user_email': userEmail,
                    'sl_user_phone': userPhone || '',
                    'sl_email_opt_in': true,
                    'sl_sms_opt_in': true,
                    'sl_call_opt_in':true
                }
                if (typeof webEngageLeadParams !== "undefined" && typeof webEngageLeadParams['we_first_name'] !== "undefined" && webEngageLeadParams['we_first_name']) {
                    eventData.sl_user_first_name = webEngageLeadParams['we_first_name'];
                }
                if (typeof webEngageLeadParams !== "undefined" && typeof webEngageLeadParams['we_last_name'] !== "undefined" && webEngageLeadParams['we_last_name']) {
                    eventData.sl_user_last_name = webEngageLeadParams['we_last_name'];
                }
                WebTracking.eventReq.triggerEvent({
                    event_id: "sl_lead_user_submitted_lead_form",
                    event_data: eventData,
                    common: "product",
                    user_attributes: ['sl_lead_type', 'sl_event_time', 'sl_user_email', 'sl_user_phone','sl_call_opt_in'],
                });
                var obj3 = {
                    sl_user_first_name: userName,
                    sl_user_last_name: userName,
                    queryTxt: "Downloaded Course Agenda",
                    sl_user_message: "Downloaded Course Agenda",
                    sl_product_id: user_params.course_id,
                    sl_product_name: user_params.course_name
                };
                obj3['sl_user_type'] = 'B2C';
                obj3['leadTrainingType'] = 'Not Sure';
                obj3['leadSourceString'] = document.URL;
                obj3['sl_utm_src'] = fetchUTMSource();
                obj3['b2cQueryType'] = 'course agenda';
                obj3['productTypeId'] = user_params.productTypeId;
                obj3['billingTypeId'] = user_params.billingTypeId;
                obj3['GCLID'] = getGCLID();
                obj3['fetchData'] = $rootScope.isLoggedIn ? 1 : 0;
//        if(!$rootScope.isLoggedIn){
//            if(fetchFromDwnAgenda)
//                obj3['fetch_from_cpr_uid'] = fetchFromCpr;
//        }
                var locatorCookie = getCookieByName('locatori9');
                var locatorCookieObj = JSON.parse(locatorCookie);
                obj3['countryId'] = locatorCookieObj.country_id;
                obj3['countryName'] = locatorCookieObj.country_name.replace(/\+/g, ' ');
                ;
                obj3['cityId'] = locatorCookieObj.city_id;
                obj3['cityName'] = locatorCookieObj.name;

                // lead prefil info
//        var inputData = {
//            email: userEmail,
//            phone: $scope.previewLeadForm.phone.$viewValue,
//            phoneCode: $scope.queryPhoneCode
//        };
//        var prefilInfo = getPrefilledInfo(inputData, $rootScope.userInfo);
//        obj3['prefilled_source'] = prefilInfo.prefilled_source
//        obj3['prefillled_data'] = prefilInfo.prefillled_data
//        obj3['prefilled_modified'] = prefilInfo.prefilled_modified
                obj3['lead_uid'] = generateLeadId(LeadService.getLeadEmail(userEmail));
                obj3['autoLead'] = isFormSubmit ? 0 : 1;
                var webEngageLeadFormParams = WebTracking.eventReq.eventParam.event_data;
                var finalB2CParamArr = PostReqService.prepareB2CLeadParameters(obj3, webEngageLeadFormParams);
                $scope.gCPCJ.gaFireOnCoursePage('leadcapturequeryform', user_params.user_id + ' || ' + document.URL + ' || ' + user_params.course_name + ' || course agenda');
                var applicationContentType = 'json';
                PostReqService.sendPostRequest(leadApiGatewayEndpoint, finalB2CParamArr, applicationContentType)
                        .then(function (data) {
                            if (document.getElementById("agenda_lead")) {
                                document.getElementById("agenda_lead").disabled = false;
                            }
                            if (document.getElementById("course_agenda_popup")) {
                                var elm = document.getElementById("course_agenda_popup");
                                elm.style.pointerEvents = "";
                            }
                            if (data != null) {
                                if (data.status == 200 && data.data.status == "success") {
                                    // Update user hash
                                    var user = $rootScope.userInfo || {};
                                    user.email = userEmail || user.email;
                                    user.phone = $scope.previewLeadForm.phone.$viewValue || user.phone;
                                    user.phoneCode = $scope.queryPhoneCode || user.phoneCode;
                                    PostReqService.getHashUser(function (userData) {
                                        if (userData != null){
                                        if (userData.email == userEmail) {
                                            LeadService.setSkipPopup();
                                        }
                                        }
                                    })
                                    PostReqService.setUserHash(user);
                                    var dACId = 'c' + user_params.course_id;
                                    if (dwnAgendaCookieCIds) {
                                        var dwnAgendaCookieCIdArr = dwnAgendaCookieCIds.split(",");
                                        var courseId = 'c' + user_params.course_id;
                                        dwnAgendaCookieCIdArr.push(courseId);
                                         dACId = dwnAgendaCookieCIdArr.join(",");
                                    }                                  
                                    LeadService.setUserLeadCookie(user_params.course_id,dACId);                                                  
                                    $rootScope.isPreviewLeadCreated = true;
                                } else {
                                    $scope.popupStatusMsg = "There was some problem, please try again.";
                                    $scope.gCPCJ.gaFireOnCoursePage('leadcapturefail', user_params.user_id + ' || ' + document.URL + ' || course agenda');
                                }
                            }
                            $rootScope.showCourseAgenda = false;
                            
                        });
                      
            });
            $scope.previewLeadForm.$setPristine();
            $scope.email = '';
            $scope.phone = '';
            self.prefillUserInfo();  
        }


    }

    this.init = function() {
        $scope.isAagreeCheckDirty = false;
        $timeout(function() {
            LocService.getCountryData().then(function(data) {
                $scope.countryData = data;
                LocService.setCurrentCountry(null, JSON.parse($cookies.locatori9).country_id);
                $scope.selected_country = LocService.getCurrentCountry();
                $scope.cookie_country_name = $scope.selected_country.name;
                $scope.countryDataHeaderDropDown = $scope.countryData;
            });
        }, 2000);
         this.prefillUserInfo();  
    };
    this.prefillUserInfo = function() {
        PostReqService.getHashUser(function (user) {
            if(user && typeof user == 'object') {
                if(!(user.email_subscription_status==0 && user.email_dnc_status==1)){
                $scope.email = user.email || $scope.email;
                $scope.phone = user.phone || $scope.phone;
                setTimeout(function () {
                                    if (user.phoneCode) {
                                        $scope.queryPhoneCode = user.phoneCode;
                                        $scope.$apply()
                                    }
                        }, 100);
                    }
            }
        });
        
    }
    $scope.$watch('cAgreeCheck', function(newValue, oldValue) {
        $scope.hasValidation = !$scope.isEuro || ($scope.cAgreeCheck && $scope.isEuro);
    });
    /*$scope.$watch('email', function(newValue) {
        var email_rgx = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        if( !email_rgx.test(newValue) ){
            $scope.previewLeadForm.email.$setValidity('email', false);
        }
        else {
            $scope.previewLeadForm.email.$setValidity('email', true);
        }
    });*/

    $scope.$watch('phone', function(newValue, oldValue) {
        if ($scope.hasValidation) {
            if (isNaN(newValue)) {
                // console.log($scope.hasValidation);
                $scope.previewLeadForm.phone.$setValidity('phone', false);
            } else if (newValue.length > PHONE_MAX_LENGTH) {
                $scope.previewLeadForm.phone.$setValidity('phone', false);
            } else {
                $scope.previewLeadForm.phone.$setValidity('phone', true);
            }
        }
    });
    $scope.agreeCheck = function() {
        $scope.cAgreeCheck=!$scope.cAgreeCheck;
        $scope.isAagreeCheckDirty = true;
    }

    $scope.hideAgendLeadPopup = function(){
        WebTracking.eventReq.triggerEvent({
            event_id : "sl_lead_form_closed",
            event_data: {
              'sl_lead_type' : 'b2c',
              'sl_site_module' : 'course agenda',
            },
            common : "product",
            user_attributes: ['sl_lead_type']
        });
        $rootScope.showCourseAgenda = false;      
    }

    $scope.disableAgendLeadPopup = function(){
        $rootScope.showCourseAgenda = false;
    }

    var setCookie = function(cname, cvalue, exdays, path) {
        path = path || "/";
        var d = new Date();
        d.setTime(d.getTime() + (exdays*24*60*60*1000));
        var expires = "expires="+ d.toUTCString();
        document.cookie = cname + "=" + cvalue + "; " + expires +";path="+path+";SameSite=Lax";
    }
    this.init();
})

.controller('ECCouncilNotifyMeCtrl', function (LocService,$scope, $rootScope, PostReqService, $cookies, $timeout) {
    var PHONE_MAX_LENGTH = 15;
    this.notifyLeadForm = {
        phone : { error: 'Please enter a valid phone number' },
        email : { error: 'Please enter a valid email' },
        cAgreeCheck : { error: 'Please accept the agreement' }
    };
    $scope.submitNotifyMeLead = function (fetchFromCpr,isValidate) {
        $scope.isAagreeCheckDirty = true;
        //$scope.notifyLeadForm.registerStatus = false;
        var userEmail = '';
        var userPhone = '';
        var userName = '';
        if(isValidate){

        }else{
            userEmail = $scope.notifyLeadForm.email.$modelValue;
            userPhone = $scope.queryPhoneCode + $scope.notifyLeadForm.phone.$modelValue;
            userName = $scope.notifyLeadForm.email.$modelValue;
            if($scope.notifyLeadForm.$invalid) {
                if($scope.notifyLeadForm.email.$invalid) {
                    $scope.notifyLeadForm.email.$setViewValue($scope.notifyLeadForm.email.$viewValue);
                }
                if($scope.notifyLeadForm.phone.$invalid) {
                    $scope.notifyLeadForm.phone.$setViewValue($scope.previewLeadForm.phone.$viewValue);
                }
                return;
            }
            if(!$scope.cAgreeCheck) {
                return;
            }
        }
        var obj3 = {
          name: userName,
          email: userEmail,
          phone: userPhone,
          queryTxt: "User clicked Notify Me",
          query: "User clicked Notify Me",
          agreeToContact: $scope.cAgreeCheck,
          queryTyp: 'notify-me-popup',
          courseId: user_params.course_id,
          courseName: user_params.course_name
        };
        obj3['customerType'] = 'B2C';
        obj3['leadTrainingType'] = 'Not Sure';
        obj3['leadSourceString'] = document.URL;
        obj3['tagName'] = 'Notify_me';
        obj3['leadSource'] = fetchUTMSource();
        obj3['type'] = 'Notify me';
        obj3['productTypeId'] = user_params.productTypeId;
        obj3['billingTypeId'] = user_params.billingTypeId;
        obj3['method'] = 'saveCallback';
        obj3['GCLID'] = getGCLID();
        obj3['fetchData'] = $rootScope.isLoggedIn ? 1 : 0;
        obj3['fetch_from_cpr_uid'] = false;
        obj3['save_cpr'] = 1;
        if(!$rootScope.isLoggedIn){
            if(fetchFromCpr)
                obj3['fetch_from_cpr_uid'] = fetchFromCpr;
        }
        PostReqService.sendPostRequest(baseApiUrlNocache, obj3)
            .then(function (data) {
               $scope.notifyMeFormSubmitStatus = true;
              if (data != null) {
                if (data.data.status == 'Success') {

                    // Update user hash
                    var user = $rootScope.userInfo || {};
                    user.email = userEmail || user.email;
                    user.phone = $scope.notifyLeadForm.phone.$viewValue || user.phone;
                    user.phoneCode = $scope.queryPhoneCode || user.phoneCode;
                    PostReqService.setUserHash(user);

                    $scope.notifyMepopupStatusMsg = "A Simplilearn representative will get back to you soon.";
                } else {
                  $scope.notifyMepopupStatusMsg = "There was some problem, please try again.";
                }
              }

            });
    }

    this.init = function() {
        self = this;
        $rootScope.shownotifyMePopUP = false;
        $scope.isAagreeCheckDirty = false;
        $scope.cAgreeCheck = false;
        $scope.isAagreeCheckDirty = false;
        $scope.notifyMeFormSubmitStatus = false;
        LocService.getCountryData().then(function(data) {
            $scope.countryData = data;
            LocService.setCurrentCountry(null, JSON.parse($cookies.locatori9).country_id);
            $scope.selected_country = LocService.getCurrentCountry();
            $scope.cookie_country_name = $scope.selected_country.name;
            $scope.countryDataHeaderDropDown = $scope.countryData;
        });

        // Get user information
        var userWatch = $rootScope.$watch('userInfo', function(newValue, oldValue) {
            var user = (newValue && newValue.email)?newValue:oldValue;
            if(user && user.email && typeof user == 'object') {
                $scope.email = user.email || $scope.email;
                $scope.phone = user.phone || $scope.phone;
                userWatch(); // stop listen
            }
        });
    };

    /*$scope.$watch('email', function(newValue) {
        var email_rgx = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        if( !email_rgx.test(newValue) ){
            $scope.notifyLeadForm.email.$setValidity('email', false);
        }
        else {
            $scope.notifyLeadForm.email.$setValidity('email', true);
        }
    });*/

    $scope.$watch('phone', function(newValue, oldValue) {
        if(isNaN(newValue)){
            $scope.notifyLeadForm.phone.$setValidity('phone', false);
        }else if(newValue.length > PHONE_MAX_LENGTH){
            $scope.notifyLeadForm.phone.$setValidity('phone', false);
        } else {
            $scope.notifyLeadForm.phone.$setValidity('phone', true);
        }
    });

    $scope.agreeCheck = function() {
        $scope.cAgreeCheck=!$scope.cAgreeCheck;
        $scope.isAagreeCheckDirty = true;
    }

    $scope.hidenotifyLeadPopup = function(){
        $rootScope.shownotifyMePopUP = false;
    }

    var setCookie = function(cname, cvalue, exdays, path) {
        path = path || "/";
        var d = new Date();
        d.setTime(d.getTime() + (exdays*24*60*60*1000));
        var expires = "expires="+ d.toUTCString();
        document.cookie = cname + "=" + cvalue + "; " + expires +";path="+path+";SameSite=Lax";
    }
})
.filter('floor', function() {
    return function(input) {
        return Math.floor(input);
    };
});
