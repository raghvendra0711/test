angular.module('Simplilearn')
        .controller('IntegratedStepFormController', function($scope,$interval) {
            $scope.helpers = new helpers();
            
            $scope.init_form = function (seconds){
                $scope.seconds = seconds;
                $scope.expired = 0;
                $scope.countdown();
            } 
           
            $scope.submitStepIndegratedForm = function () {
                if ($scope.indegratedForm.$invalid) {
                    return $scope.helpers.FormNotValid($scope.indegratedForm);
                } else if ($scope.seconds <= 0) {
                    alert("Form Expired. Please try again.");
                } else {
                    document.getElementById('indegratedForm-step').submit();
                }
            }
           
            $scope.countdown = function() {
              if ($scope.seconds <= 0) return;
              $scope.countdownInterval = $interval(function() {
                if ($scope.seconds <= 0) {
                  //Disable Submit button 
                  $scope.expired = 1;
                }
                $scope.seconds--;
              }, 1000);
            };

            $scope.stop = function() {
               $interval.cancel($scope.countdownInterval);
            };
            
})