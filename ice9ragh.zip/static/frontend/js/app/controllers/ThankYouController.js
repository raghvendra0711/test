angular.module('Simplilearn')
.controller('ThankYouCtrl', function($http, PaymentEventService) {
    
    this.infoYesFlag = 1;
    this.issueYesFlag = 0;
    this.clickedRating = 0;
    this.rating = 0;
    this.remarks = '';
    this.showForm = 1;
    this.infoMsg = '';
    this.infoClass = '';
    this.rating_err_flag = 0;
    this.subsName = '';
    var email, orderId, authToken;
    
    this.helpers = new helpers();
    
    var self = this;
    document.cookie = "cart_items=0;path="+baseUrl+';SameSite=Lax;';
    
    this.initVars = function(pEmail, pOrderId, pToken) {
        email = pEmail;
        orderId = pOrderId;
        authToken = pToken;
    };

    this.setInfoYesFlag = function( pVal ) {
        this.infoYesFlag = pVal;
    };
    
    this.setIssueYesFlag = function( pVal ) {
        this.issueYesFlag = pVal;
    };
    
    this.setRating = function( pVal, pEventName ) {
        if( pEventName === 'mouseover' ) {
            this.rating = pVal;
        }
        else if( pEventName === 'mouseout' ) {
            this.rating = this.clickedRating;
        }
        else if( pEventName === 'click' ) {
            this.rating = pVal;
            this.clickedRating = pVal;
            
            if( pVal === 0 ) {
                this.rating_err_flag = 0;
            }
        }
    };
    
    this.submitForm = function(form) {
        if (!form.$valid) {
            return self.helpers.FormNotValid(form);
        }
        
        if( this.rating === 0 ) {
            this.rating_err_flag = 1;
            return;
        }

        $http.get(baseApiUrl+'?method=saveCartFeedback',
                            { params: {
                                        'infoYesFlag':self.infoYesFlag,
                                        'issueYesFlag':self.issueYesFlag,
                                        'rating':self.rating,
                                        'remarks':self.remarks,
                                        'email':email,
                                        'orderId':orderId,
                                        'authToken':authToken
                                      }
                            }
                ).success(function(data) {
                    if (data.status === "Success") {
                        resetFormData();
                        form.$setPristine();
                        self.infoMsg = "Thank you for your feedback";
                        self.infoClass = "success_text";
                    } else {
                        if( !!data && !!data.msg ) {
                            self.infoMsg = data.msg;
                            self.infoClass = "error_text";
                        }
                        else {
                            self.infoMsg = "Some error occurred. Please try again later.";
                            self.infoClass = "error_text";
                        }
                    }
                }).error(function() {
                    self.infoMsg = "Some error occurred. Please try again later.";
                    self.infoClass = "error_text";
                });
    };
    
    var resetFormData = function() {
        self.infoYesFlag = 1;
        self.issueYesFlag = 0;
        self.rating = 0;
        self.remarks = '';
        self.showForm = 0;
    };
    
    this.redirectToNewPage = function(url){
        window.open(url,'_blank');
    };
    
    this.generateGA = function(countryName){
       self.ga.gaFireEventsGeneric('lvcpassPurchase',countryName);
    }
    
    var gaForLVCPass = function() {
        var ga = new gaEventsTracker();

        this.gaFireEventsGeneric = function(pGaKey, pGaLabel) {
            ga.gaFireInteractiveEvents(pGaKey, pGaLabel); 
        };
     };
    this.gaForPaymentConfirm = function (eventKey, index) {
        var eventData = PaymentEventService.getItemAttributeByIndex(index);
        var eventLabel=user_params.user_id + ' || ' + eventData.sl_product_type + ' || ' + eventData.sl_product_name;
        self.ga.gaFireEventsGeneric(eventKey, eventLabel);
        
        /*if(typeof webengage.state == 'undefined') {
            webengage.onReady(triggerEvent);
        } else {
            triggerEvent();
        }*/
        
        /*function triggerEvent() {
            var commonData = WebTracking.eventReq.getDataFromUserParams(['sl_page_type', 'sl_order_id', 'sl_currency', 'sl_cart_items', 'sl_final_cart_value', 'sl_product_price_symbol','sl_user_products_bought']);
            var eventData = PaymentEventService.getItemAttributeByIndex(index);
            for (var key in commonData) {
                eventData[key] = commonData[key];
            }
            var userAttributes = [];
            var slUserType = WebTracking.eventReq.getDataFromUserParams(["sl_user_type"]);
                if (slUserType && typeof (slUserType)){
                    eventData.sl_user_type = slUserType['sl_user_type'];
                }
            WebTracking.eventReq.triggerEvent({event_id: "sl_pay_user_makes_payment", event_data: eventData, user_attributes: userAttributes});
        }*/
     }

     self.ga = new gaForLVCPass();

});