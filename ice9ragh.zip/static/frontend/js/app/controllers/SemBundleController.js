angular.module('Simplilearn')
        .controller('SemBundleController', function ($scope, $rootScope, $http, YoutubeApiService, $timeout, PostReqService, LocService, $cookies, LeadService) {
            $scope.helpers = new helpers();
            $scope.isCrsVideoVisible = 0;
            $scope.videoState = '';
            $scope.defVideoState = '';
            $scope.integratedFormDisplayStatus = 0;
            $scope.videoUrl = '';
            var self = this;
            $scope.hasValidation = true;
            $scope.isEuro=user_params.isEuro;
            $rootScope.isSemBundle = true;
            var crsPreview = {};
            $scope.primaryCrs = {};
            $scope.primaryCrs[1] = 1;
            var showReviews = {};
            $scope.coursePreview = {};
            $scope.crsAboutC = {};
            $scope.crsAboutM = {};
            $scope.crsClassroomS = {};
            /** start - intro video **/
            $scope.introVideo = null;
            $scope.introPlayer = null;
            var PHONE_MAX_LENGTH = 15;

            $scope.showBundleAgenda = false;
            $scope.cAgreeCheck = false;
            $scope.learningPathExpand = false;
            $scope.learningPathShowMoreLabel = 'Show all courses';
            $rootScope.isSemBundle=true;
            this.init = function () {
                $scope.isAagreeCheckDirty = false;
            };

            // add phone country code
            LocService.getCountryData().then(function (data) {
                $scope.countryData = data;
                LocService.setCurrentCountry(null, JSON.parse($cookies.locatori9).country_id);
                $scope.selected_country = LocService.getCurrentCountry();
                $scope.queryCountryId = $scope.selected_country.id;
                $scope.queryPhoneCode = "+" + $scope.selected_country.phnCode + "-";
                $scope.inQueryPhoneCode = "+" + $scope.selected_country.phnCode + "-";
                $scope.cookie_country_name = $scope.selected_country.name;
                $scope.countryDataHeaderDropDown = $scope.countryData;
            });

            $scope.introVideoInit = function () {
                YoutubeApiService.onReady(function () {
                    var player;
                    var playerId = 'courseIntroVideo';
                    var playButtonId = 'play-button-intro-main';

                    var popupDom = document.querySelector('#courseIntroVideoPopup > iframe');
                    if (!popupDom) {
                        return;
                    }
                    initIntroVideoPopupStatus = true;
                    popupDom.setAttribute('id', 'courseIntroVideoPopupIframe');
                    playerId = 'courseIntroVideoPopupIframe';
                    playButtonId = 'play-button-intro-popup';

//                    player = new YT.Player(playerId, {
//                        events: {
//                            'onStateChange': onPlayerStateChange
//                        }
//                    });
                    $scope.introVideo = document.getElementById(playerId);
                    if (!$scope.introVideoOverlayStatus) {
                        $scope.playVideo($scope.introVideo);
                    }
                    var videoState = null;
                });
            }

            $scope.breadcrumEvent = function ($event) {
                var gotoLink = ''
                if (typeof $event != 'undefined')
                    gotoLink = $event.target.parentNode.href;
                var ga = new gaEventsTracker();
                ga.gaFireInteractiveEvents('breadcrumclick', user_params.user_id + ' || ' + document.URL + ' || ' + gotoLink);
            }

            $scope.defaultFunction = function (courseIds) {
                
                PostReqService.getHashUser(function(userData) {
                    if(userData!=null)
                 var data = userData;
                })
                if (document.readyState === 'complete') {
                    $scope.fetchCoursePreview(courseIds);
                } else {
                    window.addEventListener('load', $scope.fetchCoursePreview(courseIds));
                }

                  self.initUserHash();
            }
            this.initUserHash = function () {
                // Get user information
                PostReqService.getHashUser(function (user) {
                    if (user  && typeof user == 'object') {
                        if(!(user.email_subscription_status==0 && user.email_dnc_status==1)){
                        $scope.email = user.email || $scope.email;
                        $scope.phone = user.phone || $scope.phone;
                        setTimeout(function () {
                                    if (user.phoneCode) {
                                        $scope.queryPhoneCode = user.phoneCode;
                                        $scope.$apply()
                                    }
                        }, 100);
                    }
                    }
                });
            }
            $scope.fetchCoursePreview = function (courseIds) {
                if (typeof courseIds != 'undefined' && courseIds != '') {
                    $http.get(baseApiUrl + "?method=getBundlePreviews",
                            {params: {
                                    "courseId": courseIds
                                }
                            })
                            .then(function (response) {
                                if (typeof response.status !== 'undefined' && typeof response.data !== 'undefined' && response.status == 200) {
                                    var result = response.data;
                                    for (var key in result) {
                                        if (result.hasOwnProperty(key)) {
                                            window.localStorage["cp_data_" + key] = JSON.stringify(result[key]);
                                        }
                                    }
                                }
                            });
                }
            }

            $scope.setReviewsStatus = function ($event, no, val) {
                $event.preventDefault();
                showReviews[no] = val;
            }

            $scope.getReviewStatus = function (id) {
                if (typeof showReviews[id] != 'undefined') {
                    return showReviews[id];
                }
                return 0;
            }
            $scope.playVideo = function (domObj) {
                //console.log('playVideo')
                if ($scope.introPlayer && $scope.introPlayer.playVideo) {
                    $scope.introPlayer.playVideo();
                } else if (domObj && domObj.contentWindow) {
                    $timeout(function () {
                        domObj.contentWindow.postMessage('{"event":"command","func":"playVideo","args":""}', '*')
                    }, 500);
                }
            }
            $scope.showCrsVideo = function (vUrl) {
                $scope.videoUrl = vUrl;
                $scope.isCrsVideoVisible = 1;
                $scope.videoState = '';
                $timeout(function () {
                    $scope.introVideoInit();
                }, 100);
            };

            $scope.hideCrsVideo = function () {
                $scope.videoUrl = '';
                $scope.isCrsVideoVisible = 0;
                $scope.videoState = 'stop';
            };

            $scope.showDefVideo = function (vUrl) {
                $scope.isDefVideoVisible = 1;
                $scope.defVideoState = '';
            };

            $scope.hideDefVideo = function () {
                $scope.isDefVideoVisible = 0;
                $scope.defVideoState = 'stop';
            };
            $scope.crsPreview = {};
            $scope.setCpreviewStatus = function ($event, id, type, val, courseName) {
                $event.preventDefault();
                $scope.ga.gaFireInteractiveEvents('clickoncoursecontenttab', user_params.user_id + ' || ' + document.URL + ' || ' + courseName);

                if (typeof $scope.crsPreview[id] == 'undefined') {
                    $scope.crsPreview[id] = {};
                }
                if ($scope.crsPreview[id][type] == 1)
                    $scope.crsPreview[id][type] = 0;
                else
                    $scope.crsPreview[id][type] = 1;
                var secVid = 2 - type;
                var secVidId = 2;
                if (secVid == 0)
                    secVidId = 1;
                if ($scope.crsPreview[id][secVidId] != 'undefined')
                    $scope.crsPreview[id][secVidId] = 0;
                if (typeof $scope.crsClassroomS[id] != 'undefined') {
                    $scope.crsClassroomS[id][secVidId] = 0;
                }
                if (typeof $scope.crsAboutC[id] != 'undefined')
                    $scope.crsAboutC[id][secVidId] = 0;

            }

            $scope.getCpreviewStatus = function (id, type) {
                if (typeof $scope.crsPreview[id] != 'undefined') {
                    return $scope.crsPreview[id][type];
                }
                return 0;
            }

            $scope.getClassroomClasses = function (id, type, second) {
                var classStr = '';
                var secVid = 2 - type;
                var secVidId = 2;
                if (secVid == 0)
                    secVidId = 1;

                if ($scope.getClassroomSStatus(id, type)) {
                    classStr += 'collapse-box';
                }
                if (second && ($scope.getClassroomSStatus(id, type) || $scope.getCpreviewStatus(id, type))) {
                    // classStr += ' hidden';
                }
                if (second && ($scope.getClassroomSStatus(id, secVidId)
                        || $scope.getCpreviewStatus(id, secVidId)
                        || $scope.getAboutCStatus(id, secVidId))) {
                    classStr += ' hide-buttons';
                }
                return classStr;
            }
            $scope.getClassroomClassesO = function (id, type) {
                var classStr = '';

                if ($scope.getClassroomSStatus(id, type)) {
                    classStr += 'collapse-box';
                }
                if (($scope.getClassroomSStatus(id, type) == 0 && $scope.getCpreviewStatus(id, type) == 0)) {
                    classStr += ' hidden';
                }
                return classStr;
            }

            $scope.getPreviewClasses = function (id, type, toggleFlag) {
                var classStr = '';
                var secVid = 2 - type;
                var secVidId = 2;
                if (secVid == 0)
                    secVidId = 1;

                if ($scope.getCpreviewStatus(id, type)) {
                    classStr += 'collapse-box';
                }
                if (($scope.getClassroomSStatus(id, type) || $scope.getCpreviewStatus(id, type))) {
                    if (typeof toggleFlag !== "undefined") {
                        classStr += ' toggle-course-content';
                    } else {
                        classStr += ' hidden';
                    }
                }

                if (($scope.getClassroomSStatus(id, secVidId)
                        || $scope.getCpreviewStatus(id, secVidId)
                        || $scope.getAboutCStatus(id, secVidId))) {
                    classStr += ' hide-buttons';
                }

                return classStr;
            }

            $scope.getPreviewClassesO = function (id, type, toggleFlag) {
                var classStr = '00';
                if ($scope.getCpreviewStatus(id, type)) {
                    classStr += 'collapse-box';
                }
                if (($scope.getClassroomSStatus(id, type) == 0 && $scope.getCpreviewStatus(id, type) == 0)) {
                    if (typeof toggleFlag !== "undefined") {
                        classStr += ' toggle-course-content';
                    } else {
                        classStr += ' hidden';
                    }
                }
                return classStr;
            }

            $scope.setClassroomSStatus = function ($event, id, type) {
                $event.preventDefault();
                if (typeof $scope.crsClassroomS[id] == 'undefined') {
                    $scope.crsClassroomS[id] = {};
                }
                if ($scope.crsClassroomS[id][type] == 1)
                    $scope.crsClassroomS[id][type] = 0;
                else
                    $scope.crsClassroomS[id][type] = 1;
                var secVid = 2 - type;
                var secVidId = 2;
                if (secVid == 0)
                    secVidId = 1;
                if ($scope.crsClassroomS[id][secVidId] != 'undefined')
                    $scope.crsClassroomS[id][secVidId] = 0;
                if (typeof $scope.crsPreview[id] != 'undefined') {
                    $scope.crsPreview[id][secVidId] = 0;
//                    $scope.crsPreview[id][2] = 0;
                }
                if (typeof $scope.crsAboutC[id] != 'undefined')
                    $scope.crsAboutC[id][secVidId] = 0;
            }

            $scope.getClassroomSStatus = function (id, type) {
                if (typeof $scope.crsClassroomS[id] != 'undefined') {
                    return $scope.crsClassroomS[id][type];
                }
                return 0;
            }


            $scope.setAboutCStatus = function ($event, id, type) {
                $event.preventDefault();
                if (typeof $scope.crsAboutC[id] == 'undefined') {
                    $scope.crsAboutC[id] = {};
                }
                var secVid = 2 - type;
                var secVidId = 2;
                if (secVid == 0)
                    secVidId = 1;
                if ($scope.crsAboutC[id][type] == 1)
                    $scope.crsAboutC[id][type] = 0;
                else
                    $scope.crsAboutC[id][type] = 1;
                if (typeof $scope.crsAboutC[id] != 'undefined')
                    $scope.crsAboutC[id][secVidId] = 0;
                if (typeof $scope.crsClassroomS[id] != 'undefined') {
                    $scope.crsClassroomS[id][secVidId] = 0;
                }
                if (typeof $scope.crsPreview[id] != 'undefined') {
                    $scope.crsPreview[id][secVidId] = 0;
                }
            }

            $scope.getAboutCStatus = function (id, type) {
                if (typeof $scope.crsAboutC[id] != 'undefined') {
                    return $scope.crsAboutC[id][type];
                }
                return 0;
            }

            $scope.setAboutMStatus = function ($event, id, type) {
                $event.preventDefault();
                if (typeof $scope.crsAboutM[id] == 'undefined') {
                    $scope.crsAboutM[id] = {};
                }
                if (typeof $scope.crsAboutM[id] != 'undefined' && $scope.crsAboutM[id][type] == 1) {
                    $scope.crsAboutM[id][type] = 0;
                    if ((typeof $scope.crsPreview[id] !== 'undefined') && (typeof $scope.crsPreview[id][type] != 'undefined'))
                        $scope.crsPreview[id][type] = 0;
                    if ($scope.crsClassroomS[id][type] != 'undefined')
                        $scope.crsClassroomS[id][type] = 0;
                }
                else
                    $scope.crsAboutM[id][type] = 1;
            }

            $scope.getAboutMStatus = function (id, type) {
                if (typeof $scope.crsAboutM[id] != 'undefined') {
                    return $scope.crsAboutM[id][type];
                }
                return 0;
            }
            var ga = new gaEventsTracker();
            $scope.ga = ga;
            $scope.gaFireMasterProgramCourseClick = function (courseName) {
                ga.gaFireInteractiveEvents('subslearningpathClick', user_params.user_id + ' || ' + document.URL + ' || ' + courseName);
            }
            $scope.gaFirejobAssistClick = function ($event) {
                ga.gaFireInteractiveEvents('jobassistclick', user_params.user_id + ' || ' + document.URL + ' || ' + $event.target.href);
            }
            $scope.gaOnEnroll = function () {
                ga.gaFireInteractiveEvents('enrollBundle', user_params.user_id + ' || ' + document.URL);
            }

            $scope.gaOnSticky = function (courseName, name) {
                ga.gaFireInteractiveEvents('bundlestickyClick', user_params.user_id + ' || ' + document.URL + ' || ' + courseName + ' || ' + name);
            }

            $scope.gaOnFAQ = function (courseName, title) {
                ga.gaFireInteractiveEvents('faqclickedopen', user_params.user_id + ' || ' + document.URL + ' || ' + courseName + ' || ' + title);
            }

            $scope.gaOnDesc = function (courseName, title) {
                ga.gaFireInteractiveEvents('mdclickedopen', user_params.user_id + ' || ' + document.URL + ' || ' + courseName + ' || ' + title);
            }

            $scope.showBundleAgendaPopUp = function (agendaUrl,btnText) {
               var siteModule = 'bundle agenda';
                WebTracking.eventReq.triggerEvent({
                    event_id : "sl_lead_module_initiated",
                    event_data: {
                      'sl_lead_button_text' : btnText || '',
                      'sl_lead_type' : 'b2c',
                      'sl_site_module' : 'bundle agenda',
                    },
                    common : "product",
                    user_attributes: ['sl_lead_type']
                });
                $scope.submitAgendaUrl = agendaUrl;
                //var bundleAgendaCookie = getCookieByName('_cpruid');
                var bundleAgendaCookie = getCookieByName('_user_ld_info');
                var agendaLeadCreated = false;
                if (typeof bundleAgendaCookie !== "undefined") {
                    var bundle_id = user_params.bundle_id;
                    bundle_id = 'b' + bundle_id;
                    var cookieCourseIds = bundleAgendaCookie.split(',');
                    if (cookieCourseIds.indexOf(bundle_id) !== -1) {
                        agendaLeadCreated = true;
                    }
                }
                
                ga.gaFireInteractiveEvents('leadformclicked', user_params.user_id + ' || ' + document.URL + ' || ' + user_params.bundle_name + ' || ' + 'bundle agenda');

                 if(!$scope.isEuro){
                    // logic added if not logged in
                    if($cookies[user_params.enterpriseCountCookieName] == undefined || $cookies[user_params.enterpriseCountCookieName] == ''){
                        if(LeadService.isSkipPopup(siteModule)){
                            if(bundleAgendaCookie){
                                $scope.submitBundleAgendaLead($scope.submitAgendaUrl, agendaLeadCreated, true);
                            }
                            else{
                                 $scope.submitBundleAgendaLead($scope.submitAgendaUrl, false, true);
                            }
                        }
                        else{
                            $scope.showBundleAgenda = true;
                        }
                    }
                    else{
                        if(LeadService.isSkipPopup(siteModule)){
                            if(bundleAgendaCookie){
                                $scope.submitBundleAgendaLead($scope.submitAgendaUrl, agendaLeadCreated, true);
                            }
                            else{
                                 $scope.submitBundleAgendaLead($scope.submitAgendaUrl, false, true);
                            }
                        }
                        else
                            window.open($scope.submitAgendaUrl, '_blank');
                    }
                }

                if ($scope.isEuro  && ($cookies[user_params.enterpriseCountCookieName] == undefined || $cookies[user_params.enterpriseCountCookieName] == '')) {
                    var optinSet = typeof getCookieByName(user_params.OPTIN_COOKIE) != 'undefined' ? true : false;
                    var optin = getCookieByName(user_params.OPTIN_COOKIE) == 1 ? true : false;
                    if (LeadService.isSkipPopup(siteModule)) {
                        if ((optin == true) || bundleAgendaCookie || !optinSet) {
                            $scope.submitBundleAgendaLead($scope.submitAgendaUrl,agendaLeadCreated,true);
                        } 
                        else
                            window.open($scope.submitAgendaUrl, '_blank');
                        
                    }
                    else{
                        if(optin == true|| !optinSet)
                            $scope.showBundleAgenda = true;
                        else {
                            window.open($scope.submitAgendaUrl, '_blank');
                        }
                    }
                }
            }
            $scope.submitIndegratedForm = function () {
                if ($scope.indegratedForm.$invalid) {
                    return $scope.helpers.FormNotValid($scope.indegratedForm);
                } else {
                    var userEmail = $scope.indegratedForm.userEmail.$modelValue;
                    var userPhone = $scope.inQueryPhoneCode + $scope.indegratedForm.userPhone.$modelValue;
                    var userName = $scope.indegratedForm.userName.$modelValue;
                    var obj3 = {
                        name: userName,
                        email: userEmail,
                        phone: userPhone,
                        queryTxt: "Apply Now Integrated Program",
                        query: "Apply Now Integrated Program",
                        agreeToContact: 1,
                        queryTyp: 'integrated-program-popup',
                        bundleId: user_params.bundle_id,
                        bundleName: user_params.bundle_name
                    };
                    obj3['customerType'] = 'B2C';
                    obj3['leadTrainingType'] = 'Not Sure';
                    obj3['leadSourceString'] = document.URL;
                    obj3['tagName'] = 'program application';
                    obj3['leadSource'] = fetchUTMSource();
                    obj3['type'] = 'program application';
                    obj3['productTypeId'] = user_params.productTypeId;
                    obj3['billingTypeId'] = user_params.billingTypeId;
                    obj3['method'] = 'saveCallback';
                    obj3['GCLID'] = getGCLID();
                    obj3['lead_delay_time'] = user_params.leadCreateAfter;

                    PostReqService.sendPostRequest(baseApiUrlNocache, obj3)
                            .then(function (data) {
                                if (data != null) {
                                    if (data.data.status == 'Success') {
                                        //Open in new Page new form
                                        //Close Popup
                                        var user = {};
                                        user.email = encodeURIComponent(userEmail);
                                        user.key = data.data.result.key;
                                        user.url_current = window.location;
                                        user.bundle_name = user_params.bundle_name;
                                        var paramsArr = user;
                                        paramsArr.method = 'generateUserHash',
                                                PostReqService.sendPostRequest(baseApiUrlNocache, paramsArr).then(function (data) {
                                            var resData = data.data;
                                            if (resData && resData.status == 'success' && resData.data && resData.data.auh) {
                                                window.open(user_params.integrated_program_form + '?step=' + resData.data.auh, "_self");
                                                document.querySelector('body').classList.remove('body_fixed');
                                            } else {
                                                $scope.integratedQueryStatusClass = "error_msg";
                                                $scope.integratedQueryStatusMsg = "There was some problem, please try again.";
                                            }
                                        });

                                        $scope.integratedFormDisplayStatus = 0;
                                    } else {
                                        $scope.integratedQueryStatusClass = "error_msg";
                                        $scope.integratedQueryStatusMsg = "There was some problem, please try again.";
                                    }
                                }
                                //$scope.integratedFormDisplayStatus = {'display':'none'};
                            });
                }
            }
            $scope.$watch('cAgreeCheck', function (newValue, oldValue) {
                $scope.hasValidation = !$scope.isEuro || ($scope.cAgreeCheck && $scope.isEuro);
            });
            $scope.$watch('userPhone', function (newValue) {
                if ($scope.indegratedForm && $scope.indegratedForm.userPhone) {
                    if (isNaN(newValue)) {
                        $scope.indegratedForm.userPhone.$setValidity('required', false);
                    } else if (newValue.length > PHONE_MAX_LENGTH) {
                        $scope.indegratedForm.userPhone.$setValidity('required', false);
                    }
                }
            });
            $scope.$watch('phone', function (newValue) {
                if($scope.hasValidation)
                    {
                if ($scope.previewLeadForm && $scope.previewLeadForm.phone) {
                    setPhoneValidity($scope.previewLeadForm.phone, newValue);
                }
            }});
            
            var setPhoneValidity = function (fieldModel, newValue) {
                if (isNaN(newValue)) {
                    fieldModel.$setValidity('phone', false);
                } else if (newValue.length > PHONE_MAX_LENGTH) {
                    fieldModel.$setValidity('phone', false);
                } else {
                    fieldModel.$setValidity('phone', true);
                }
            }
            var leadInitiated = false;
            $scope.intiateLead = function () {
                if (!leadInitiated) {
                    WebTracking.eventReq.triggerEvent({
                        event_id : "sl_lead_user_initiated_lead_form",
                        event_data: {
                          'sl_lead_type' : 'b2c',
                          'sl_site_module' : 'bundle agenda',
                        },
                        common : "product",
                        user_attributes: ['sl_lead_type']
                    });
                    leadInitiated = true;
                }
            }

            $scope.submitBundleAgendaLead = function (agendaUrl, fetchFromDwnAgenda, isValidate, isFormSubmit) {
                isFormSubmit = (typeof isFormSubmit == 'undefined')?false:isFormSubmit;
                var siteModule = 'bundle agenda';
                var userEmail = '';
                var userPhone = '';
                var userName = '';
                if (isValidate) {

                } else {
                    if ($scope.hasValidation) {
                    userEmail = $scope.previewLeadForm.email.$modelValue;
                    userPhone = $scope.queryPhoneCode + $scope.previewLeadForm.phone.$modelValue;
                    userName = $scope.previewLeadForm.email.$modelValue;
                    if ($scope.previewLeadForm.$invalid) {
                        if ($scope.previewLeadForm.email.$invalid) {
                            $scope.previewLeadForm.email.$setViewValue($scope.previewLeadForm.email.$viewValue);
                        }
                        if ($scope.previewLeadForm.phone.$invalid) {
                            $scope.previewLeadForm.phone.$setViewValue($scope.previewLeadForm.phone.$viewValue);
                        }
                        return;
                    }
                    if (!$scope.cAgreeCheck) {
                        return;
                    }
                }}

                if(user_params.isEuro) {
                        setCookie(user_params.OPTIN_COOKIE, 0, 90);
                }

                if (document.getElementById("agenda_lead")) {
                    document.getElementById("agenda_lead").disabled = true;
                }


                ga.gaFireInteractiveEvents('leadcapturequeryform', user_params.user_id + ' || ' + document.URL + ' || ' + user_params.bundle_name + ' || ' + 'bundle agenda');
                window.open($scope.submitAgendaUrl, '_blank');
                
                var optinSet = typeof getCookieByName(user_params.OPTIN_COOKIE) != 'undefined' ? true : false;
                var optin = getCookieByName(user_params.OPTIN_COOKIE) == 1 ? true : false;
                if(user_params.isEuro && !optin && !LeadService.isSkipPopup(siteModule) && !$scope.cAgreeCheck) {                   
                    $rootScope.showBundleAgenda = false;
                    $scope.hideAgendLeadPopup();
                    return;
                }
                if (fetchFromDwnAgenda === false || fetchFromDwnAgenda === null) {
                    webengage.onReady(function () {
                        var dwnAgendaCookieCIds = getCookieByName('_user_ld_info');
                        if ( (typeof dwnAgendaCookieCIds !== "undefined" && dwnAgendaCookieCIds) || LeadService.isSkipPopup(siteModule)) {
                            var userInfo = [];
                            if(typeof webengage.state != 'undefined' && typeof webengage.state.getForever != 'undefined'){
                                userInfo = webengage.state.getForever().uattr;
                                userEmail = userInfo.we_email;
                                userPhone = userInfo.we_phone;
                            }
                        }
                        var webEngageLeadParams = [];
                        if (typeof webengage.state != 'undefined' && typeof webengage.state.getForever != 'undefined') {
                            webEngageLeadParams = webengage.state.getForever().uattr;
                        }
                        var eventData = {
                            'sl_lead_type': 'b2c',
                            'sl_site_module': 'bundle agenda',
                            'sl_user_email': userEmail,
                            'sl_user_phone': userPhone || '',
                            'sl_email_opt_in': true,
                            'sl_sms_opt_in': true,
                            'sl_call_opt_in':true
                        }
                        if (typeof webEngageLeadParams !== "undefined" && typeof webEngageLeadParams['we_first_name'] !== "undefined" && webEngageLeadParams['we_first_name']) {
                            eventData.sl_user_first_name = webEngageLeadParams['we_first_name'];
                        }
                        if (typeof webEngageLeadParams !== "undefined" && typeof webEngageLeadParams['we_last_name'] !== "undefined" && webEngageLeadParams['we_last_name']) {
                            eventData.sl_user_last_name = webEngageLeadParams['we_last_name'];
                        }
                        WebTracking.eventReq.triggerEvent({
                            event_id: "sl_lead_user_submitted_lead_form",
                            event_data: eventData,
                            common: "product",
                            user_attributes: ['sl_lead_type', 'sl_event_time', 'sl_user_email', 'sl_user_phone','sl_call_opt_in'],
                        });
                        var obj3 = {
                            name: userName,
                            email: userEmail,
                            phone: userPhone,
                            queryTxt: "Downloaded Bundle Agenda",
                            query: "Downloaded Bundle Agenda",
                            agreeToContact: $scope.cAgreeCheck,
                            queryTyp: 'bundle-agenda-popup',
                            bundleId: user_params.bundle_id,
                            bundleName: user_params.bundle_name
                        };
                        obj3['customerType'] = 'B2C';
                        obj3['leadTrainingType'] = 'Not Sure';
                        obj3['leadSourceString'] = document.URL;
                        obj3['tagName'] = 'bundle agenda';
                        obj3['leadSource'] = fetchUTMSource();
                        //obj3['type'] = 'bundle agenda';
                        obj3['b2cQueryType'] = 'bundle agenda';
                        obj3['productTypeId'] = user_params.productTypeId;
                        obj3['billingTypeId'] = user_params.billingTypeId;
                        //obj3['method'] = 'saveCallback';
                        obj3['GCLID'] = getGCLID();
                        obj3['fetchData'] = $rootScope.isLoggedIn ? 1 : 0;
                        obj3['sl_user_message'] = "Downloaded Bundle Agenda";
                        //obj3['save_bpr'] = 1;
                        obj3['lead_uid'] = generateLeadId(LeadService.getLeadEmail(userEmail));
                        var locatorCookie = getCookieByName('locatori9');
                        var locatorCookieObj = JSON.parse(locatorCookie);
                        obj3['countryId'] = locatorCookieObj.country_id;
                        obj3['countryName'] = locatorCookieObj.country_name.replace(/\+/g, ' ');
                        obj3['cityId'] = locatorCookieObj.city_id;
                        obj3['cityName'] = locatorCookieObj.name;
                        obj3['autoLead'] = isFormSubmit ? 0 : 1;

                        var webEngageLeadFormParams = WebTracking.eventReq.eventParam.event_data;
                        var finalB2CParamArr = PostReqService.prepareB2CLeadParameters(obj3, webEngageLeadFormParams);
                        var applicationContentType = 'json';
                        PostReqService.sendPostRequest(leadApiGatewayEndpoint, finalB2CParamArr, applicationContentType)
                                .then(function (data) {
                                    if (data != null) {
                                        if (data.status == 200 && data.data.status == "success") {
                                            // setCookie('_cpruid', data.data.cpr_uid, 90);
                                            var dACId = 'b' + user_params.bundle_id;
                                            if (dwnAgendaCookieCIds) {
                                                var dwnAgendaCookieCIdArr = dwnAgendaCookieCIds.split(",");
                                                var bundle_id = 'b' + user_params.bundle_id;
                                                dwnAgendaCookieCIdArr.push(bundle_id);
                                                dACId = dwnAgendaCookieCIdArr.join(",");
                                            }
                                            LeadService.setUserLeadCookie(user_params.bundle_id,dACId);
                                            PostReqService.getHashUser(function (userData) {
                                                if (userData != null)
                                                if (userData.email == userEmail) {
                                                    LeadService.setSkipPopup();
                                                }
                                            })
                                            $rootScope.isPreviewLeadCreated = true;
                                        } else {
                                            $scope.popupStatusMsg = "There was some problem, please try again.";
                                        }
                                    }
                                    if (document.getElementById("agenda_lead")) {
                                        document.getElementById("agenda_lead").disabled = false;
                                    }
                                    $rootScope.showBundleAgenda = false;
                                    $scope.hideAgendLeadPopup();
                                }).catch(function (data) {
                                    if (document.getElementById("agenda_lead")) {
                                        document.getElementById("agenda_lead").disabled = false;
                                    }
                                });
                    });
                    $scope.previewLeadForm.$setPristine();
                    $scope.email = '';
                    $scope.phone = '';
                    self.initUserHash();

                }
             
            }

            $scope.hideAgendLeadPopup = function (status) {
                WebTracking.eventReq.triggerEvent({
                    event_id : "sl_lead_form_closed",
                    event_data: {
                      'sl_lead_type' : 'b2c',
                      'sl_site_module' : 'bundle agenda',
                    },
                    common : "product",
                    user_attributes: ['sl_lead_type']
                });
                this.showBundleAgenda = status;
            }

            $scope.agreeCheck = function () {
                $scope.cAgreeCheck = !$scope.cAgreeCheck;
                $scope.isAagreeCheckDirty = true;
            }

            var setCookie = function (cname, cvalue, exdays, path) {
                path = path || "/";
                var d = new Date();
                d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
                var expires = "expires=" + d.toUTCString();
                document.cookie = cname + "=" + cvalue + "; " + expires + ";path=" + path + ";SameSite=Lax;";
            }
            $scope.expandLearningPathDiv = function ($event) {
                var pageTitle = $event.target.getAttribute('data-page-title');
                if ($scope.learningPathExpand == false) {
                    $scope.learningPathExpand = true;
                    $scope.learningPathShowMoreLabel = 'Show Less';
                    var el = document.getElementsByClassName('learning-path-toggle'), i;
                    for (i = 0; i < el.length; ++i) {
                        el[i].classList.remove('hide');
                    }
                    if (document.querySelector('.bundle-course-index-3') !== null && document.querySelector('.bundle-course-index-3').classList.contains('bundle-course-blur-block')) {
                        document.querySelector('.bundle-course-index-3').classList.remove('bundle-course-blur-block');
                    }
                    $scope.gaShowMoreCourseInLP(pageTitle);
                } else {
                    $scope.learningPathExpand = false;
                    $scope.learningPathShowMoreLabel = 'Show All Courses';
                    var el = document.getElementsByClassName('learning-path-toggle'), i;
                    for (i = 0; i < el.length; ++i) {
                        el[i].classList.add('hide');
                    }
                    if (document.querySelector('.bundle-course-index-3') !== null) {
                        document.querySelector('.bundle-course-index-3').classList.add('bundle-course-blur-block');
                    }
                    $scope.gaShowLessCourseInLP(pageTitle);
                    document.getElementById('learn-box').scrollIntoView(true);
                    $event.stopPropagation();
                }
            };
            $scope.gaShowMoreCourseInLP = function (pageTitle) {
                ga.gaFireInteractiveEvents('SemBundleShowMoreCourseInLearningPath', user_params.user_id + ' || ' + document.URL + ' || ' + pageTitle);
            };
            $scope.gaShowLessCourseInLP = function (pageTitle) {
                ga.gaFireInteractiveEvents('SemBundleShowLessCourseInLearningPath', user_params.user_id + ' || ' + document.URL + ' || ' + pageTitle);
            };
            $scope.gaGdprOptInCheckbox=function(event){
                if (user_params.isEuro && event.target.checked){
                    var pGaKey="gdprOptinCheckboxChecked";
                    var pGaLabel= user_params.user_id + ' || ' + user_params.bundle_name + ' || ' + 'bundle agenda';
                     ga.gaFireInteractiveEvents(pGaKey, pGaLabel);
                }
            }

        })