angular.module('Simplilearn')
.controller('PaymentController', function($scope,$http,$rootScope,LocService,$timeout,$compile) {
	$scope.init = function(){
		$timeout(function() {
                var button = document.getElementById('button-to-pay');
                if(button) {
                    button.click();
                }
            }, 3000);
	}
})
;

