angular.module('Simplilearn')
.controller('MenuCtrl', function($scope,MenuService,$http,$rootScope,$cookies,$timeout) {
    var self = this;
    self.user_params = user_params;
    this.isMenuVisible = false;
    this.currentItemId = null;
    this.currentSubCatId = null;
    this.isMobileInnerMenuVisible = false;
    //this.menuData = MenuService.getMenuData();
	$scope.isIpad = isIpad;
    $scope.headerMenu = {'local_menu_storage_all_course' : '', 'local_menu_storage_frs':''};
    this.subscriptionData = {};
    this.isSubsAvailable = false;
    self.helpers = new helpers();
    this.currentFRSMenuItem = '';
    this.isFRSMenuVisible = false;
    this.isSearchVisible = false;
    this.isMobileFrsVisible = false;
    this.menuHoverEvent = false;
    this.searchType = false;
    var defVerticalId = null;
    var defCatId = null;



    $scope.frsMenuData = '';
    if (typeof frs_menu_data !== 'undefined') {
        $scope.frsMenuData = frs_menu_data;
    }
    $scope.breadcrumEvent = function ($event,productType,url,name,id) {
        var gotoLink = ''
        if (typeof $event != 'undefined')
            gotoLink = $event.target.parentNode.href;
        breadcrumEvent(productType, gotoLink, name, id);
    }
    this.initDefCategory = function(pVerticalId, pLabelId) {
        defVerticalId = pVerticalId;
        defCatId = pLabelId;
        //this.setMenuItemId(pVerticalId);
        //this.setSubCatId(pLabelId);
    };

    this.setMenuItemId = function(itemId){
        MenuService.setCurrentItemId(itemId);
        this.currentItemId = MenuService.getCurrentItemId();
    };

    this.hideMenu = function(){
        this.isMenuVisible = false;
    };

    this.closeMenuOverlayClick = function(e) {
        if(e && e.target) {
            if(angular.element(e.target).attr("id") == 'courses-menu-data') {
                this.closeMenu();
                e.stopPropagation();
            }
        }
        var overlapEl=document.getElementById('overlap-id');
                if(overlapEl){
                    var overlapClasslist=overlapEl.classList;
                    if(overlapClasslist)
                    overlapClasslist.add('overlap-cls');
                }
    }

    this.closeMenu = function () {
        var overlapEl=document.getElementById('overlap-id');
                if(overlapEl){
                    var overlapClasslist=overlapEl.classList;
                    if(overlapClasslist)
                    overlapClasslist.add('overlap-cls');
                }
        document.querySelector('body').classList.remove('body_fixed');
        document.getElementById('courses-menu-data').classList.remove('show_main_menu');
        this.hideMenu();
        this.isMenuVisible = false;
        var x = document.querySelectorAll(".active_level_1");
        angular.element(x).removeClass("active_level_1");
        var subMenuClass = document.querySelectorAll(".active_level_2");
        angular.element(subMenuClass).removeClass("active_level_2");
    }
    this.closeSubMenu = function (){
        var x = document.querySelectorAll(".active_level_1");
        angular.element(x).removeClass("active_level_1");
        var subMenuClass = document.querySelectorAll(".active_level_2");
        angular.element(subMenuClass).removeClass("active_level_2");
        var overlapEl=document.getElementById('overlap-id');
                if(overlapEl){
                    var overlapClasslist=overlapEl.classList;
                    if(overlapClasslist)
                    overlapClasslist.add('overlap-cls');
                }
    }
    this.addMenuClass = function (){
        if(!document.getElementById('courses-menu-data').classList.contains('show_main_menu')){
            document.getElementById('courses-menu-data').classList.add('show_main_menu');
        } else {
            document.getElementById('courses-menu-data').classList.remove('show_main_menu');
        }
        document.querySelector('body').classList.add('body_fixed');
    }

    this.hideAllMenus = function() {
        this.hideMenu();                //hide courses menu
        this.hideFRSMenu();             //hide free resource menu
        this.hideSearch();              //hide search
    };

    this.showMenu = function( isSticky ){
        this.hideAllMenus();
        document.getElementById('courses-menu-data').style.left = (document.getElementById('courses-menu').getBoundingClientRect().left - 30) + 'px';;
        document.getElementById('courses-menu-data').style.top = (document.getElementById('courses-menu').getBoundingClientRect().top + 45) + 'px';;
        this.isMenuVisible = true;
    };

    this.isCurrentItem = function(itemId){
        return this.currentItemId !== null && this.currentItemId == itemId && this.isMenuVisible == true;
    };

    this.isCurrentItemMobile = function(itemId){
        return this.currentItemId !== null && this.currentItemId == itemId && this.isMobileInnerMenuVisible == true;
    };

    this.setSubCatId = function(subCatId,catUrl){
        MenuService.setSubCatId(subCatId);
        this.currentSubCatId = MenuService.getSubCatId();

        if(typeof catUrl !='undefined' && $rootScope.hybridWidthFlag == 1){
            window.location.href = catUrl // redirect to category page on mobiles
        }

    };

    this.isCurrentSubCat = function(itemId, subCatId){
        return this.currentItemId !== null && this.currentSubCatId !== null && this.currentItemId == itemId && this.currentSubCatId == subCatId && this.isMenuVisible == true; //@review confusing statement
    };

    this.isFourthLevelMenuVisible = function() {
        if( this.isMenuVisible && self.isSubsAvailable ) {
            return true;
        } else {
            return false;
        }
    };

    this.showMainMenu = function(pVerticalId, pLabelId) {
        if(pVerticalId !== null && pLabelId !== null) {
            this.setMenuItemId(pVerticalId);
            this.setSubCatId(pLabelId);
        } else {
            this.setMenuItemId(defVerticalId);
            this.setSubCatId(defCatId);
        }
        this.showMenu();
    };
    $scope.$watch(function(){return self.currentSubCatId;},function(newVal){
        if(typeof self.subscriptionData[newVal] != 'undefined'){
            self.isSubsAvailable = true;
        }else{
            self.isSubsAvailable = false;
        }
    });

    this.fetchSubsData = function(){
        if (window.localStorage.getItem("header_subs_data") === null) {
            var urlObj = self.helpers.makeValidApiUrl('fetchSubscriptionData');
            $http.get(urlObj.url, {cache: urlObj.cached})
                .success(function(data, status, header, config) {
                    window.localStorage["header_subs_data"] = JSON.stringify(data);
                    self.createSubscriptionData(data);
            });
        }else{
            var data = JSON.parse(window.localStorage["header_subs_data"]);
            self.createSubscriptionData(data);
        }

    }

    this.createSubscriptionData = function(data){
        var dataLen = data.length;
        for(var i=0;i<dataLen;i++){
            var subscription = data[i];
            var pricings = subscription.pricings;
            var bundleUrl = subscription.bundle_url;
            if(typeof bundleUrl !='undefined' && bundleUrl!='' && bundleUrl!=null){
                if(bundleUrl.charAt(0) == '/'){
                    bundleUrl = bundleUrl.substring(1);
                }
            }
            if(pricings != undefined && typeof pricings[ipCountryIdValue] != 'undefined' && typeof pricings[ipCountryIdValue]['priceMonthly'] != 'undefined'){
                self.subscriptionData[subscription.primary_label_id] =
                        {'labelName':subscription.label_name,'yearlyPrice':pricings[ipCountryIdValue]['priceYearly'],
                    'monthlyPrice':pricings[ipCountryIdValue]['priceMonthly'],'currency':JSON.parse(getCookieByName('locatori9')).symbol,
                    'url':baseUrl+bundleUrl};
            }
        }
    }

    this.openLink = function(url){
        location.href = url;
    };

            var gaHeaderClass = function() {
                var ga = new gaEventsTracker();
                this.gaFH = function() {
                    if(!this.menuHoverEvent){
                        ga.gaFireInteractiveEvents('flyouthover', user_params.user_id + ' || ' + document.URL);
                        this.menuHoverEvent = true;
                    }
                }
                //gaFireHeaderFlyoutClick
                this.gFHFC = function(type,name,data,id) {
                    var dataUpdated = user_params.user_id + ' || ' + document.URL + ' || ' + data;
                    if(type == 'category')
                        ga.gaFireInteractiveEvents('flyoutcatclick', dataUpdated);
                    else if (type == 'master') {
                        var mId = id.replace('b', '');
                        ga.gaFireInteractiveEvents('flyoutMasterProgclick', dataUpdated);
                        WebTracking.eventReq.triggerEvent({
                            event_id: "sl_nav_user_clicks_on_a_link_in_Megamenu",
                            event_data: {
                                'sl_destination_link': data || '',
                                'sl_destination_product_name': name || '',
                                'sl_destination_product_type': 'master',
                                'sl_destination_product_id' : parseInt(mId) || 0 ,
                            },
                            common: "product",
                        });
                    }
                    else {
                        ga.gaFireInteractiveEvents('flyoutclick', dataUpdated);
                        var eventData = {};
                        eventData['sl_destination_link'] = data || '';
                        eventData['sl_destination_product_name'] = name || '';
                        if(typeof id != 'undefined' && id.indexOf('b') !== -1){
                            var mId = id.replace('b', '');
                            eventData['sl_destination_product_id'] = parseInt(mId) || 0 ;
                            eventData['sl_destination_product_type'] = 'master';
                        } else {
                            eventData['sl_destination_product_id'] = parseInt(id) || 0 ;
                            eventData['sl_destination_product_type'] = 'course';
                        }
                        WebTracking.eventReq.triggerEvent({
                            event_id: "sl_nav_user_clicks_on_a_link_in_Megamenu",
                            event_data: eventData,
                            common: "product",
                        });
                    }
                }
                this.frsMenuClick = function(type,$event) {
                    var data = user_params.user_id + ' || ' + document.URL + ' || ' + $event;
                    if(type == 'category') {
                        ga.gaFireInteractiveEvents('resourcescatclick', data);
                    }
                    else {
                        ga.gaFireInteractiveEvents('resourcesclick', data);
                    }
                }
                //gaFireHomePageSearch
                this.gFHPS = function() {
                    var elems = document.getElementsByClassName('search_in');
                    var value = '';
                    for (var i = 0; i < elems.length; i++) {
                        if (elems[i].value != "") {
                            value = elems[i].value;
                            break;
                        }
                    }
                    ga.gaFireInteractiveEvents('homepagesearch', value);
                }
                this.logoClick = function($event) {
                    ga.gaFireInteractiveEvents('logoclick', user_params.user_id + ' || ' + document.URL + ' || ' + $event.target.href);
                    WebTracking.eventReq.triggerEvent({
                        event_id: "sl_nav_user_clicks_on_simplilearn_logo",
                        event_data : {
                            'sl_destination_link': frontendUrl || '',
                            'sl_destination_page_type':'home'
                        },
                        common: "product",
                    });
                }

                this.searchInitiated = function(){
                    if(!this.searchType){
                        ga.gaFireInteractiveEvents('searchinitiated', user_params.user_id + ' || ' + document.URL);
                        this.searchType = true;
                        WebTracking.eventReq.triggerEvent({
                            event_id: "sl_nav_user_initiates_search",
                            event_data : {
                           'sl_search_type':'header',
                        },
                            common: "product",
                        });
                    }
                }

                this.searchClick = function(category){
                    var label = document.getElementById('header_srch').value;
                    ga.gaFireInteractiveEvents(category, user_params.user_id + ' || ' + document.URL + ' || ' + label);
                    WebTracking.eventReq.triggerEvent({
                        event_id: "sl_nav_user_completes_search",
                        event_data : {
                           'sl_search_term' : label || '',
                           'sl_search_type':'header',
                        },
                        common: "product",
                    });
                }
                var menuhoverFired = false;
                this.frsMenuHover = function() {
                    if(!menuhoverFired){
                        ga.gaFireInteractiveEvents('frsmenuhover', user_params.user_id + ' || ' + document.URL);
                        menuhoverFired = true;
                    }
                }
                var menuhoverFiredHeader = false;
                this.masterMenuHover = function () {
                    if (!menuhoverFiredHeader) {
                        WebTracking.eventReq.triggerEvent({
                            event_id: "sl_nav_user_hovers_over_all_courses",
                            common: "product",
                        });
                        menuhoverFiredHeader = true;
                    }
                }
                this.gaDoubleNavClickGeneric=function(topNavName,destinationUrl){
                   ga.gaFireInteractiveEvents('dobubleNavClickedGeneric', user_params.user_id + ' || ' + document.URL + ' || ' + topNavName + ' || '+ destinationUrl );
                   WebTracking.eventReq.triggerEvent({
                        event_id: "sl_nav_user_clicks_on_a_link_in_top_Nav",
                        event_data : {
                           'sl_destination_link' : destinationUrl || '',
                           'sl_destination_page_type' : topNavName || '',
                        },
                        common: "product",
                    });
               }
            };
            //ga menu js
            $scope.gMCJ = new gaHeaderClass();


            this.showFRSMainMenu = function(activeMenuItem){
                self.hideAllMenus();        //hide all menu items
                self.currentFRSMenuItem = activeMenuItem;
                self.showFRSMenu();
            };

            this.setCurrentFRSMenuItem = function(currentItem){
                self.currentFRSMenuItem = currentItem;
            }

            this.isCurrentFRSMenuItem = function(menuItem){
                if(self.currentFRSMenuItem === menuItem){
                    return true;
                }else{
                    return false;
                }
            }

            this.showFRSMenu = function(){
                self.isFRSMenuVisible = true;
                document.getElementById('resources-menu-data').style.left = document.getElementById('resources-menu').getBoundingClientRect().left + 'px';;
                document.getElementById('resources-menu-data').style.top = (document.getElementById('resources-menu').getBoundingClientRect().top + 45) + 'px';;
            };

            this.hideFRSMenu = function(){
                self.isFRSMenuVisible = false;
            };


            this.loadFrsMegaMenuImages = function() {
                if ($scope.frsMenuData !='' || $scope.frsMenuData !=null || typeof $scope.frsMenuData!= 'undefined') {
                    angular.forEach($scope.frsMenuData, function(value, key) {
                           var cnt = parseInt(1);
                           angular.forEach(value, function(innerValue, innerKey) {
                            var image = document.getElementById(key+'_'+cnt);
                            // New logic based on data-is-placeholder-img vaue
                            if(image.getAttribute('data-is-placeholder-img')) {
                                if (innerValue) {
                                    image.setAttribute('src', innerValue);
                                }
                                image.setAttribute('data-is-placeholder-img', 0);

                            }
                            // Old functionality
                            if (image.getAttribute('src') ==''|| image.getAttribute('src') ==null || typeof image.getAttribute('src') =='undefined') {
                                image.setAttribute('src', innerValue);
                            }
                            cnt++;
                        });
                    });
                }
            }

            this.showSearch = function(){
                self.hideAllMenus();        //hide all menu items
                self.isSearchVisible = true;
                $timeout(function() {
                    document.getElementById('header_srch').focus();
                }, 100);
            };

            this.hideSearch = function(){
                self.isSearchVisible = false;
            };

            $rootScope.$on('orientationChanged', function(pEvt, pVal) {
                if(pVal) {
                    $scope.$apply(function() {
                        self.hideAllMenus();
                    });
                }
            });

            $scope.redirectionToHomeEvent=function(){
                var referrerUrl = window.location.href;
                var param=['_trackEvent', 'Details_Page:Redirection_to_Simplilearn_Home', 'User click on Simplilearn logo and gets redirected to the Simplilearn homepage from FRS homepage', referrerUrl, 0, false];
                _gaq.push(param)

                if (printGaInConsole) {
                    console.log(param);
                }
            };
            this.clickOnExploreCat = function (name, id, url) {
                WebTracking.eventReq.triggerEvent({
                    event_id: "sl_nav_user_clicks_on_explore_category_in_Megamenu",
                    event_data: {
                        'sl_destination_product_category': name || '',
                        'sl_destination_product_category_id': parseInt(id) || 0,
                        'sl_destination_link': url,
                        'sl_destination_product_type':'category'
                    },
                    common: "product",
                });
            }
});
