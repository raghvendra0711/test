/**
 *
 * Website Events
 * Author : Kusum Saini
 */
 !function(e,n){"object"==typeof exports&&"undefined"!=typeof module?n():"function"==typeof define&&define.amd?define(n):n()}(0,function(){"use strict";function e(e){var n=this.constructor;return this.then(function(t){return n.resolve(e()).then(function(){return t})},function(t){return n.resolve(e()).then(function(){return n.reject(t)})})}function n(){}function t(e){if(!(this instanceof t))throw new TypeError("Promises must be constructed via new");if("function"!=typeof e)throw new TypeError("not a function");this._state=0,this._handled=!1,this._value=undefined,this._deferreds=[],u(e,this)}function o(e,n){for(;3===e._state;)e=e._value;0!==e._state?(e._handled=!0,t._immediateFn(function(){var t=1===e._state?n.onFulfilled:n.onRejected;if(null!==t){var o;try{o=t(e._value)}catch(f){return void i(n.promise,f)}r(n.promise,o)}else(1===e._state?r:i)(n.promise,e._value)})):e._deferreds.push(n)}function r(e,n){try{if(n===e)throw new TypeError("A promise cannot be resolved with itself.");if(n&&("object"==typeof n||"function"==typeof n)){var o=n.then;if(n instanceof t)return e._state=3,e._value=n,void f(e);if("function"==typeof o)return void u(function(e,n){return function(){e.apply(n,arguments)}}(o,n),e)}e._state=1,e._value=n,f(e)}catch(r){i(e,r)}}function i(e,n){e._state=2,e._value=n,f(e)}function f(e){2===e._state&&0===e._deferreds.length&&t._immediateFn(function(){e._handled||t._unhandledRejectionFn(e._value)});for(var n=0,r=e._deferreds.length;r>n;n++)o(e,e._deferreds[n]);e._deferreds=null}function u(e,n){var t=!1;try{e(function(e){t||(t=!0,r(n,e))},function(e){t||(t=!0,i(n,e))})}catch(o){if(t)return;t=!0,i(n,o)}}var c=setTimeout;t.prototype["catch"]=function(e){return this.then(null,e)},t.prototype.then=function(e,t){var r=new this.constructor(n);return o(this,new function(e,n,t){this.onFulfilled="function"==typeof e?e:null,this.onRejected="function"==typeof n?n:null,this.promise=t}(e,t,r)),r},t.prototype["finally"]=e,t.all=function(e){return new t(function(n,t){function o(e,f){try{if(f&&("object"==typeof f||"function"==typeof f)){var u=f.then;if("function"==typeof u)return void u.call(f,function(n){o(e,n)},t)}r[e]=f,0==--i&&n(r)}catch(c){t(c)}}if(!e||"undefined"==typeof e.length)throw new TypeError("Promise.all accepts an array");var r=Array.prototype.slice.call(e);if(0===r.length)return n([]);for(var i=r.length,f=0;r.length>f;f++)o(f,r[f])})},t.resolve=function(e){return e&&"object"==typeof e&&e.constructor===t?e:new t(function(n){n(e)})},t.reject=function(e){return new t(function(n,t){t(e)})},t.race=function(e){return new t(function(n,t){for(var o=0,r=e.length;r>o;o++)e[o].then(n,t)})},t._immediateFn="function"==typeof setImmediate&&function(e){setImmediate(e)}||function(e){c(e,0)},t._unhandledRejectionFn=function(e){void 0!==console&&console&&console.warn("Possible Unhandled Promise Rejection:",e)};var l=function(){if("undefined"!=typeof self)return self;if("undefined"!=typeof window)return window;if("undefined"!=typeof global)return global;throw Error("unable to locate global object")}();"Promise"in l?l.Promise.prototype["finally"]||(l.Promise.prototype["finally"]=e):l.Promise=t});
 /**
 * Copyright (c) 2014, Facebook, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * https://raw.github.com/facebook/regenerator/master/LICENSE file. An
 * additional grant of patent rights can be found in the PATENTS file in
 * the same directory.
 */

!(function(global) {
  "use strict";

  var hasOwn = Object.prototype.hasOwnProperty;
  var undefined; // More compressible than void 0.
  var iteratorSymbol =
    typeof Symbol === "function" && Symbol.iterator || "@@iterator";

  var inModule = typeof module === "object";
  var runtime = global.regeneratorRuntime;
  if (runtime) {
    if (inModule) {
      // If regeneratorRuntime is defined globally and we're in a module,
      // make the exports object identical to regeneratorRuntime.
      module.exports = runtime;
    }
    // Don't bother evaluating the rest of this file if the runtime was
    // already defined globally.
    return;
  }

  // Define the runtime globally (as expected by generated code) as either
  // module.exports (if we're in a module) or a new, empty object.
  runtime = global.regeneratorRuntime = inModule ? module.exports : {};

  function wrap(innerFn, outerFn, self, tryLocsList) {
    // If outerFn provided, then outerFn.prototype instanceof Generator.
    var generator = Object.create((outerFn || Generator).prototype);
    var context = new Context(tryLocsList || []);

    // The ._invoke method unifies the implementations of the .next,
    // .throw, and .return methods.
    generator._invoke = makeInvokeMethod(innerFn, self, context);

    return generator;
  }
  runtime.wrap = wrap;

  // Try/catch helper to minimize deoptimizations. Returns a completion
  // record like context.tryEntries[i].completion. This interface could
  // have been (and was previously) designed to take a closure to be
  // invoked without arguments, but in all the cases we care about we
  // already have an existing method we want to call, so there's no need
  // to create a new function object. We can even get away with assuming
  // the method takes exactly one argument, since that happens to be true
  // in every case, so we don't have to touch the arguments object. The
  // only additional allocation required is the completion record, which
  // has a stable shape and so hopefully should be cheap to allocate.
  function tryCatch(fn, obj, arg) {
    try {
      return { type: "normal", arg: fn.call(obj, arg) };
    } catch (err) {
      return { type: "throw", arg: err };
    }
  }

  var GenStateSuspendedStart = "suspendedStart";
  var GenStateSuspendedYield = "suspendedYield";
  var GenStateExecuting = "executing";
  var GenStateCompleted = "completed";

  // Returning this object from the innerFn has the same effect as
  // breaking out of the dispatch switch statement.
  var ContinueSentinel = {};

  // Dummy constructor functions that we use as the .constructor and
  // .constructor.prototype properties for functions that return Generator
  // objects. For full spec compliance, you may wish to configure your
  // minifier not to mangle the names of these two functions.
  function Generator() {}
  function GeneratorFunction() {}
  function GeneratorFunctionPrototype() {}

  var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype;
  GeneratorFunction.prototype = Gp.constructor = GeneratorFunctionPrototype;
  GeneratorFunctionPrototype.constructor = GeneratorFunction;
  GeneratorFunction.displayName = "GeneratorFunction";

  // Helper for defining the .next, .throw, and .return methods of the
  // Iterator interface in terms of a single ._invoke method.
  function defineIteratorMethods(prototype) {
    ["next", "throw", "return"].forEach(function(method) {
      prototype[method] = function(arg) {
        return this._invoke(method, arg);
      };
    });
  }

  runtime.isGeneratorFunction = function(genFun) {
    var ctor = typeof genFun === "function" && genFun.constructor;
    return ctor
      ? ctor === GeneratorFunction ||
        // For the native GeneratorFunction constructor, the best we can
        // do is to check its .name property.
        (ctor.displayName || ctor.name) === "GeneratorFunction"
      : false;
  };

  runtime.mark = function(genFun) {
    if (Object.setPrototypeOf) {
      Object.setPrototypeOf(genFun, GeneratorFunctionPrototype);
    } else {
      genFun.__proto__ = GeneratorFunctionPrototype;
    }
    genFun.prototype = Object.create(Gp);
    return genFun;
  };

  // Within the body of any async function, `await x` is transformed to
  // `yield regeneratorRuntime.awrap(x)`, so that the runtime can test
  // `value instanceof AwaitArgument` to determine if the yielded value is
  // meant to be awaited. Some may consider the name of this method too
  // cutesy, but they are curmudgeons.
  runtime.awrap = function(arg) {
    return new AwaitArgument(arg);
  };

  function AwaitArgument(arg) {
    this.arg = arg;
  }

  function AsyncIterator(generator) {
    // This invoke function is written in a style that assumes some
    // calling function (or Promise) will handle exceptions.
    function invoke(method, arg) {
      var result = generator[method](arg);
      var value = result.value;
      return value instanceof AwaitArgument
        ? Promise.resolve(value.arg).then(invokeNext, invokeThrow)
        : Promise.resolve(value).then(function(unwrapped) {
            // When a yielded Promise is resolved, its final value becomes
            // the .value of the Promise<{value,done}> result for the
            // current iteration. If the Promise is rejected, however, the
            // result for this iteration will be rejected with the same
            // reason. Note that rejections of yielded Promises are not
            // thrown back into the generator function, as is the case
            // when an awaited Promise is rejected. This difference in
            // behavior between yield and await is important, because it
            // allows the consumer to decide what to do with the yielded
            // rejection (swallow it and continue, manually .throw it back
            // into the generator, abandon iteration, whatever). With
            // await, by contrast, there is no opportunity to examine the
            // rejection reason outside the generator function, so the
            // only option is to throw it from the await expression, and
            // let the generator function handle the exception.
            result.value = unwrapped;
            return result;
          });
    }

    if (typeof process === "object" && process.domain) {
      invoke = process.domain.bind(invoke);
    }

    var invokeNext = invoke.bind(generator, "next");
    var invokeThrow = invoke.bind(generator, "throw");
    var invokeReturn = invoke.bind(generator, "return");
    var previousPromise;

    function enqueue(method, arg) {
      function callInvokeWithMethodAndArg() {
        return invoke(method, arg);
      }

      return previousPromise =
        // If enqueue has been called before, then we want to wait until
        // all previous Promises have been resolved before calling invoke,
        // so that results are always delivered in the correct order. If
        // enqueue has not been called before, then it is important to
        // call invoke immediately, without waiting on a callback to fire,
        // so that the async generator function has the opportunity to do
        // any necessary setup in a predictable way. This predictability
        // is why the Promise constructor synchronously invokes its
        // executor callback, and why async functions synchronously
        // execute code before the first await. Since we implement simple
        // async functions in terms of async generators, it is especially
        // important to get this right, even though it requires care.
        previousPromise ? previousPromise.then(
          callInvokeWithMethodAndArg,
          // Avoid propagating failures to Promises returned by later
          // invocations of the iterator.
          callInvokeWithMethodAndArg
        ) : new Promise(function (resolve) {
          resolve(callInvokeWithMethodAndArg());
        });
    }

    // Define the unified helper method that is used to implement .next,
    // .throw, and .return (see defineIteratorMethods).
    this._invoke = enqueue;
  }

  defineIteratorMethods(AsyncIterator.prototype);

  // Note that simple async functions are implemented on top of
  // AsyncIterator objects; they just return a Promise for the value of
  // the final result produced by the iterator.
  runtime.async = function(innerFn, outerFn, self, tryLocsList) {
    var iter = new AsyncIterator(
      wrap(innerFn, outerFn, self, tryLocsList)
    );

    return runtime.isGeneratorFunction(outerFn)
      ? iter // If outerFn is a generator, return the full iterator.
      : iter.next().then(function(result) {
          return result.done ? result.value : iter.next();
        });
  };

  function makeInvokeMethod(innerFn, self, context) {
    var state = GenStateSuspendedStart;

    return function invoke(method, arg) {
      if (state === GenStateExecuting) {
        throw new Error("Generator is already running");
      }

      if (state === GenStateCompleted) {
        if (method === "throw") {
          throw arg;
        }

        // Be forgiving, per 25.3.3.3.3 of the spec:
        // https://people.mozilla.org/~jorendorff/es6-draft.html#sec-generatorresume
        return doneResult();
      }

      while (true) {
        var delegate = context.delegate;
        if (delegate) {
          if (method === "return" ||
              (method === "throw" && delegate.iterator[method] === undefined)) {
            // A return or throw (when the delegate iterator has no throw
            // method) always terminates the yield* loop.
            context.delegate = null;

            // If the delegate iterator has a return method, give it a
            // chance to clean up.
            var returnMethod = delegate.iterator["return"];
            if (returnMethod) {
              var record = tryCatch(returnMethod, delegate.iterator, arg);
              if (record.type === "throw") {
                // If the return method threw an exception, let that
                // exception prevail over the original return or throw.
                method = "throw";
                arg = record.arg;
                continue;
              }
            }

            if (method === "return") {
              // Continue with the outer return, now that the delegate
              // iterator has been terminated.
              continue;
            }
          }

          var record = tryCatch(
            delegate.iterator[method],
            delegate.iterator,
            arg
          );

          if (record.type === "throw") {
            context.delegate = null;

            // Like returning generator.throw(uncaught), but without the
            // overhead of an extra function call.
            method = "throw";
            arg = record.arg;
            continue;
          }

          // Delegate generator ran and handled its own exceptions so
          // regardless of what the method was, we continue as if it is
          // "next" with an undefined arg.
          method = "next";
          arg = undefined;

          var info = record.arg;
          if (info.done) {
            context[delegate.resultName] = info.value;
            context.next = delegate.nextLoc;
          } else {
            state = GenStateSuspendedYield;
            return info;
          }

          context.delegate = null;
        }

        if (method === "next") {
          context._sent = arg;

          if (state === GenStateSuspendedYield) {
            context.sent = arg;
          } else {
            context.sent = undefined;
          }
        } else if (method === "throw") {
          if (state === GenStateSuspendedStart) {
            state = GenStateCompleted;
            throw arg;
          }

          if (context.dispatchException(arg)) {
            // If the dispatched exception was caught by a catch block,
            // then let that catch block handle the exception normally.
            method = "next";
            arg = undefined;
          }

        } else if (method === "return") {
          context.abrupt("return", arg);
        }

        state = GenStateExecuting;

        var record = tryCatch(innerFn, self, context);
        if (record.type === "normal") {
          // If an exception is thrown from innerFn, we leave state ===
          // GenStateExecuting and loop back for another invocation.
          state = context.done
            ? GenStateCompleted
            : GenStateSuspendedYield;

          var info = {
            value: record.arg,
            done: context.done
          };

          if (record.arg === ContinueSentinel) {
            if (context.delegate && method === "next") {
              // Deliberately forget the last sent value so that we don't
              // accidentally pass it on to the delegate.
              arg = undefined;
            }
          } else {
            return info;
          }

        } else if (record.type === "throw") {
          state = GenStateCompleted;
          // Dispatch the exception by looping back around to the
          // context.dispatchException(arg) call above.
          method = "throw";
          arg = record.arg;
        }
      }
    };
  }

  // Define Generator.prototype.{next,throw,return} in terms of the
  // unified ._invoke helper method.
  defineIteratorMethods(Gp);

  Gp[iteratorSymbol] = function() {
    return this;
  };

  Gp.toString = function() {
    return "[object Generator]";
  };

  function pushTryEntry(locs) {
    var entry = { tryLoc: locs[0] };

    if (1 in locs) {
      entry.catchLoc = locs[1];
    }

    if (2 in locs) {
      entry.finallyLoc = locs[2];
      entry.afterLoc = locs[3];
    }

    this.tryEntries.push(entry);
  }

  function resetTryEntry(entry) {
    var record = entry.completion || {};
    record.type = "normal";
    delete record.arg;
    entry.completion = record;
  }

  function Context(tryLocsList) {
    // The root entry object (effectively a try statement without a catch
    // or a finally block) gives us a place to store values thrown from
    // locations where there is no enclosing try statement.
    this.tryEntries = [{ tryLoc: "root" }];
    tryLocsList.forEach(pushTryEntry, this);
    this.reset(true);
  }

  runtime.keys = function(object) {
    var keys = [];
    for (var key in object) {
      keys.push(key);
    }
    keys.reverse();

    // Rather than returning an object with a next method, we keep
    // things simple and return the next function itself.
    return function next() {
      while (keys.length) {
        var key = keys.pop();
        if (key in object) {
          next.value = key;
          next.done = false;
          return next;
        }
      }

      // To avoid creating an additional object, we just hang the .value
      // and .done properties off the next function object itself. This
      // also ensures that the minifier will not anonymize the function.
      next.done = true;
      return next;
    };
  };

  function values(iterable) {
    if (iterable) {
      var iteratorMethod = iterable[iteratorSymbol];
      if (iteratorMethod) {
        return iteratorMethod.call(iterable);
      }

      if (typeof iterable.next === "function") {
        return iterable;
      }

      if (!isNaN(iterable.length)) {
        var i = -1, next = function next() {
          while (++i < iterable.length) {
            if (hasOwn.call(iterable, i)) {
              next.value = iterable[i];
              next.done = false;
              return next;
            }
          }

          next.value = undefined;
          next.done = true;

          return next;
        };

        return next.next = next;
      }
    }

    // Return an iterator with no values.
    return { next: doneResult };
  }
  runtime.values = values;

  function doneResult() {
    return { value: undefined, done: true };
  }

  Context.prototype = {
    constructor: Context,

    reset: function(skipTempReset) {
      this.prev = 0;
      this.next = 0;
      this.sent = undefined;
      this.done = false;
      this.delegate = null;

      this.tryEntries.forEach(resetTryEntry);

      if (!skipTempReset) {
        for (var name in this) {
          // Not sure about the optimal order of these conditions:
          if (name.charAt(0) === "t" &&
              hasOwn.call(this, name) &&
              !isNaN(+name.slice(1))) {
            this[name] = undefined;
          }
        }
      }
    },

    stop: function() {
      this.done = true;

      var rootEntry = this.tryEntries[0];
      var rootRecord = rootEntry.completion;
      if (rootRecord.type === "throw") {
        throw rootRecord.arg;
      }

      return this.rval;
    },

    dispatchException: function(exception) {
      if (this.done) {
        throw exception;
      }

      var context = this;
      function handle(loc, caught) {
        record.type = "throw";
        record.arg = exception;
        context.next = loc;
        return !!caught;
      }

      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        var record = entry.completion;

        if (entry.tryLoc === "root") {
          // Exception thrown outside of any try block that could handle
          // it, so set the completion value of the entire function to
          // throw the exception.
          return handle("end");
        }

        if (entry.tryLoc <= this.prev) {
          var hasCatch = hasOwn.call(entry, "catchLoc");
          var hasFinally = hasOwn.call(entry, "finallyLoc");

          if (hasCatch && hasFinally) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            } else if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }

          } else if (hasCatch) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            }

          } else if (hasFinally) {
            if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }

          } else {
            throw new Error("try statement without catch or finally");
          }
        }
      }
    },

    abrupt: function(type, arg) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc <= this.prev &&
            hasOwn.call(entry, "finallyLoc") &&
            this.prev < entry.finallyLoc) {
          var finallyEntry = entry;
          break;
        }
      }

      if (finallyEntry &&
          (type === "break" ||
           type === "continue") &&
          finallyEntry.tryLoc <= arg &&
          arg <= finallyEntry.finallyLoc) {
        // Ignore the finally entry if control is not jumping to a
        // location outside the try/catch block.
        finallyEntry = null;
      }

      var record = finallyEntry ? finallyEntry.completion : {};
      record.type = type;
      record.arg = arg;

      if (finallyEntry) {
        this.next = finallyEntry.finallyLoc;
      } else {
        this.complete(record);
      }

      return ContinueSentinel;
    },

    complete: function(record, afterLoc) {
      if (record.type === "throw") {
        throw record.arg;
      }

      if (record.type === "break" ||
          record.type === "continue") {
        this.next = record.arg;
      } else if (record.type === "return") {
        this.rval = record.arg;
        this.next = "end";
      } else if (record.type === "normal" && afterLoc) {
        this.next = afterLoc;
      }
    },

    finish: function(finallyLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.finallyLoc === finallyLoc) {
          this.complete(entry.completion, entry.afterLoc);
          resetTryEntry(entry);
          return ContinueSentinel;
        }
      }
    },

    "catch": function(tryLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc === tryLoc) {
          var record = entry.completion;
          if (record.type === "throw") {
            var thrown = record.arg;
            resetTryEntry(entry);
          }
          return thrown;
        }
      }

      // The context.catch method must only be called with a location
      // argument that corresponds to a known catch block.
      throw new Error("illegal catch attempt");
    },

    delegateYield: function(iterable, resultName, nextLoc) {
      this.delegate = {
        iterator: values(iterable),
        resultName: resultName,
        nextLoc: nextLoc
      };

      return ContinueSentinel;
    }
  };
})(
  // Among the various tricks for obtaining a reference to the global
  // object, this seems to be the most reliable technique that does not
  // use indirect eval (which violates Content Security Policy).
  typeof global === "object" ? global :
  typeof window === "object" ? window :
  typeof self === "object" ? self : this
);

// // =================================================

var WebTracking = WebTracking || {};
var weusrCookie = getCookieByName('weusr');

// events list
WebTracking.events = {
    'user_auto_login': {'category': "SL_Engagement", 'action': "User Auto Login", 'labelRequired': true, 'noninteractiveness': false},
    // Course Page events
    'sl_eng_product_page_viewed': {'category': "SL_Engagement", 'action': "Product Page viewed", 'labelRequired': true, 'noninteractiveness': false},
    'sl_lead_query_box_toggle_clicked': {'category': "SL_Lead", 'action': "Query Box Lead form toggle clicked", 'labelRequired': true, 'noninteractiveness': false},
    'sl_lead_user_initiated_lead_form': {'category': "SL_Lead", 'action': "Lead form initiated", 'labelRequired': true, 'noninteractiveness': false},
    'sl_lead_user_submitted_lead_form': {'category': "SL_Lead", 'action': "Lead form submitted", 'labelRequired': true, 'noninteractiveness': false},
    'sl_lead_user_lead_created_automatically': {'category': "SL_Lead", 'action': "User's lead created automatically", 'labelRequired': true, 'noninteractiveness': false},
    'sl_lead_module_initiated': {'category': "SL_Lead", 'action': "Lead Module initiated", 'labelRequired': true, 'noninteractiveness': false},
    'sl_lead_form_closed': {'category': "SL_Lead", 'action': "Lead form Closed", 'labelRequired': true, 'noninteractiveness': false},
    'sl_eng_intro_video_clicked': {'category': "SL_Engagement", 'action': "Introduction video clicked", 'labelRequired': true, 'noninteractiveness': false},
    'sl_eng_intro_video_closed': {'category': "SL_Engagement", 'action': "Introduction video closed", 'labelRequired': true, 'noninteractiveness': false},
    'sl_eng_page_sticky_top_nav_show_section_change': {'category': "SL_Engagement", 'action': "Page Sticky Top Nav shows change in section", 'labelRequired': true, 'noninteractiveness': false},
    'sl_eng_class_info_clicked': {'category': "SL_Engagement", 'action': "Class Information Clicked", 'labelRequired': true, 'noninteractiveness': false},
    'sl_eng_class_info_carousal_explored': {'category': "SL_Engagement", 'action': "Class Information Carousal Explored", 'labelRequired': true, 'noninteractiveness': false},
    'sl_eng_class_info_downloaded': {'category': "SL_Engagement", 'action': "Class Information Downloaded", 'labelRequired': true, 'noninteractiveness': false},
    'sl_eng_class_info_popup_closed': {'category': "SL_Engagement", 'action': "Class Information pop up closed", 'labelRequired': true, 'noninteractiveness': false},
    'sl_eng_web_page_viewed' : { 'category': "SL_Engagement", 'action': "User views the Corporate Training page", 'labelRequired': true, 'noninteractiveness': false },
    'sl_corptrain_eng_user_clicks_on_category' : { 'category': "SL_Engagement", 'action': "User clicks on the category buttons on Corporate Page", 'labelRequired': true, 'noninteractiveness': false },
    'sl_corptrain_eng_user_explores_course_advisor' : { 'category': "SL_Engagement", 'action': "User clicks on the course advisor carousal", 'labelRequired': true, 'noninteractiveness': false },
    'sl_corptrain_eng_user_explores_review_carousal' : { 'category': "SL_Engagement", 'action': "User explores the review carousal", 'labelRequired': true, 'noninteractiveness': false },
    'sl_corptrain_eng_user_explores_resources' : { 'category': "SL_Engagement", 'action': "User explores the resources on Corporate Training page", 'labelRequired': true, 'noninteractiveness': false },
    'sl_eng_product_description_explored': {'category': "SL_Engagement", 'action': "Product Description question explored", 'labelRequired': true, 'noninteractiveness': false},
    'sl_eng_money_back_guarantee_explored': {'category': "SL_Engagement", 'action': "Money Back Guarantee explored", 'labelRequired': true, 'noninteractiveness': false},
    'sl_eng_product_ratings_clicked': {'category': "SL_Engagement", 'action': "Product Ratings clicked", 'labelRequired': true, 'noninteractiveness': false},
    'sl_eng_product_toc_explored': {'category': "SL_Engagement", 'action': "Product TOC explored", 'labelRequired': true, 'noninteractiveness': false},
    'sl_eng_product_exam_question_explored': {'category': "SL_Engagement", 'action': "Product Exam and Certification question explored", 'labelRequired': true, 'noninteractiveness': false},
    'sl_eng_course_advisor_viewed': {'category': "SL_Engagement", 'action': "Course Advisor Section viewed", 'labelRequired': true, 'noninteractiveness': false},
    'sl_eng_product_reviews_view_more_clicked': {'category': "SL_Engagement", 'action': "Product Reviews View More Clicked", 'labelRequired': true, 'noninteractiveness': false},
    'sl_eng_product_reviews_read_more_clicked': {'category': "SL_Engagement", 'action': "Product Review Read More Clicked", 'labelRequired': true, 'noninteractiveness': false},
    'sl_eng_product_user_profile_clicked': {'category': "SL_Engagement", 'action': "Product Review User Profile Clicked", 'labelRequired': true, 'noninteractiveness': false},
    'sl_eng_product_faq_question_explored': {'category': "SL_Engagement", 'action': "Product FAQ question explored", 'labelRequired': true, 'noninteractiveness': false},
    'sl_eng_product_faq_view_more_clicked': {'category': "SL_Engagement", 'action': "Product FAQ View More Clicked", 'labelRequired': true, 'noninteractiveness': false},
    'sl_eng_chat_triggered': {'category': "SL_Engagement", 'action': "Chat triggered", 'labelRequired': true, 'noninteractiveness': false},
    'sl_eng_chat_button_clicked': {'category': "SL_Engagement", 'action': "Chat button clicked", 'labelRequired': true, 'noninteractiveness': false},
    'sl_nav_people_also_bought_courses_clicked': {'category': "SL_Engagement", 'action': "People Also bought courses clicked", 'labelRequired': true, 'noninteractiveness': false},
    'sl_pay_enroll_button_clicked_osl': {'category': "SL_Engagement", 'action': "Enroll now clicked on OSL", 'labelRequired': true, 'noninteractiveness': false},
    'sl_pay_enroll_button_clicked_lvc': {'category': "SL_Engagement", 'action': "Enroll now clicked on LVC", 'labelRequired': true, 'noninteractiveness': false},
    'sl_pay_enroll_button_clicked_classroom': {'category': "SL_Engagement", 'action': "Enroll now clicked on Classroom", 'labelRequired': true, 'noninteractiveness': false},
    'sl_pay_user_makes_payment' : { 'category': "SL_Payment", 'action': "User makes payment and lands on Thank you Page", 'labelRequired': true, 'noninteractiveness': false },
    'sl_pay_user_removes_item_from_cart': { 'category': "SL_Payment", 'action': "User removes the course from Cart", 'labelRequired': true, 'noninteractiveness': false },

    'sl_nav_user_hovers_over_all_courses': { 'category': "SL_Navigation", 'action': "User hovers over All Courses button on top nav", 'labelRequired': true, 'noninteractiveness': false },
    'sl_nav_user_clicks_on_a_link_in_Megamenu': { 'category': "SL_Navigation", 'action': "User clicks on a link in Megamenu of All Courses", 'labelRequired': true, 'noninteractiveness': false },
    'sl_nav_user_clicks_on_explore_category_in_Megamenu': { 'category': "SL_Navigation", 'action': "User clicks on Category button in Megamenu of All Courses", 'labelRequired': true, 'noninteractiveness': false },
    'sl_nav_user_initiates_search': { 'category': "SL_Navigation", 'action': "User inititates Search", 'labelRequired': true, 'noninteractiveness': false },
    'sl_nav_user_completes_search': { 'category': "SL_Navigation", 'action': "User completes Search", 'labelRequired': true, 'noninteractiveness': false },
    'sl_nav_user_clicks_on_a_link_in_top_Nav': { 'category': "SL_Navigation", 'action': "User clicks on a link in Top Nav", 'labelRequired': true, 'noninteractiveness': false },
    'sl_user_clicks_on_Login': { 'category': "SL_Navigation", 'action': "User clicks on Login", 'labelRequired': true, 'noninteractiveness': false },
    'sl_nav_user_clicks_on_simplilearn_logo': { 'category': "SL_Navigation", 'action': "User clicks on Simplilearn logo", 'labelRequired': true, 'noninteractiveness': false },
    'sl_user_logs_out': { 'category': "SL_Navigation", 'action': "User logs out", 'labelRequired': true, 'noninteractiveness': false },
    'sl_user_clicks_on_my_courses': { 'category': "SL_Navigation", 'action': "User clicks on My courses", 'labelRequired': true, 'noninteractiveness': false },
     //B2B pages event
    'sl_eng_web_page_viewed':{ 'category': "SL_Engagement", 'action': "Web Page viewed", 'labelRequired': true, 'noninteractiveness': false },

    'sl_refer_user_clicks_on_referal_link_in_footer': { 'category': "SL_Referral", 'action': "The user clicks on referral link on website footer", 'labelRequired': true, 'noninteractiveness': false },
    'sl_refer_user_online_registers_for_referral_prog': { 'category': "SL_Referral", 'action': "User registers for referral program", 'labelRequired': true, 'noninteractiveness': false },
    'sl_refer_user_initiates_giving_referral_leads': { 'category': "SL_Referral", 'action': "User initiates submission of referral leads on the referral page", 'labelRequired': true, 'noninteractiveness': false },
    'sl_lead_user_submits_referee_lead_with_email_id': { 'category': "SL_Referral", 'action': "User submits the referee lead with email id", 'labelRequired': true, 'noninteractiveness': false },
    'sl_lead_user_submits_the_referee_lead_with_phone': { 'category': "SL_Referral", 'action': "User submits the referee lead with phone number", 'labelRequired': true, 'noninteractiveness': false },
    'sl_lead_referrer_submits_referee_lead_with_emailid': { 'category': "SL_Referral", 'action': "Referrer submits the referee lead with email id", 'labelRequired': true, 'noninteractiveness': false },
    'sl_lead_referrer_submits_referee_lead_with_phone': { 'category': "SL_Referral", 'action': "Referrer submits the referee lead with phone number", 'labelRequired': true, 'noninteractiveness': false },
    'sl_refer_user_copied_referral_link': { 'category': "SL_Referral", 'action': "User copied the referral link", 'labelRequired': true, 'noninteractiveness': false },
    'sl_refer_user_promotes_referral_link_socially': { 'category': "SL_Referral", 'action': "User promoting the referral link on social channel", 'labelRequired': true, 'noninteractiveness': false },


    // FRS Page Events
    'sl_frs_eng_user_lands_on_frs_homepage': {'category': "SL_Engagement", 'action': "User lands on FRS homepage", 'labelRequired': true, 'noninteractiveness': false},
    'sl_frs_nav_user_explores_resources_on_homepage': {'category': "SL_Navigation", 'action': "User explores FRS resources on homepage", 'labelRequired': true, 'noninteractiveness': false},
    'sl_frs_nav_view_all_resources_clicked_on_homepage': {'category': "SL_Navigation", 'action': "User clicks on view all resources of a category on Homepage", 'labelRequired': true, 'noninteractiveness': false},
    'sl_frs_eng_user_clicks_on_resource_filter_on_frs': {'category': "SL_Engagement", 'action': "User clicks on resource filter on frs pages", 'labelRequired': true, 'noninteractiveness': false},
    'sl_frs_nav_user_clicks_a_resource_on_segment_page': {'category': "SL_Navigation", 'action': "User explore a resource on the FRS category page", 'labelRequired': true, 'noninteractiveness': false},
    'sl_frs_eng_user_change_segment_filter_on_category_page': {'category': "SL_Engagement", 'action': "User changes segment filter on Category page", 'labelRequired': true, 'noninteractiveness': false},
//    'sl_frs_eng_user_clicks_on_resource_tabs_on_frs': {'category': "SL_Engagement", 'action': "User clicks on resource tabs on frs pages", 'labelRequired': true, 'noninteractiveness': false},
    'sl_frs_eng_user_change_segment_filter_on_frs_pages': {'category': "SL_Engagement", 'action': "User changes segment filter on FRS pages", 'labelRequired': true, 'noninteractiveness': false},
    'sl_frs_nav_resource_in_left_hand_nav_clicked': {'category': "SL_Navigation", 'action': "User clicks on a resource in left hand nav panel", 'labelRequired': true, 'noninteractiveness': false},
    'sl_frs_nav_recommended_resource_clicked': {'category': "SL_Navigation", 'action': "User clicks on a resource in the recommended resource section", 'labelRequired': true, 'noninteractiveness': false},
    'sl_frs_eng_course_pop_up_in_frs_clicked': {'category': "SL_Engagement", 'action': "User clicks on the course pop up on FRS resource page", 'labelRequired': true, 'noninteractiveness': false},
    'sl_frs_eng_user_lands_on_frs_detail_resource_page': {'category': "SL_Engagement", 'action': "User lands on FRS detail resource page", 'labelRequired': true, 'noninteractiveness': false},
    'sl_frs_nav_user_scrolls_from_one_resource_to_other': {'category': "SL_Engagement", 'action': "User moves from one resource to another while scrolling", 'labelRequired': true, 'noninteractiveness': false},
    'sl_frs_eng_user_lands_on_frs_authors_page' : {'category': "SL_Engagement", 'action': "User lands on the FRS authors page", 'labelRequired': true, 'noninteractiveness': false},
    'sl_frs_lead_user_initiated_lead_form': {'category': "SL_FRS Lead", 'action': "Lead form initiated", 'labelRequired': true, 'noninteractiveness': false},
    'sl_frs_lead_user_submitted_lead': {'category': "SL_FRS Lead", 'action': "Lead form submitted", 'labelRequired': true, 'noninteractiveness': false},
    'sl_frs_lead_module_initiated': {'category': "SL_FRS Lead", 'action': "Lead Module initiated", 'labelRequired': true, 'noninteractiveness': false},
    'sl_frs_lead_form_closed': {'category': "SL_FRS Lead", 'action': "Lead form Closed", 'labelRequired': true, 'noninteractiveness': false},

    'sl_nav_user_hovers_over_all_courses': { 'category': "SL_Navigation", 'action': "User hovers over All Courses button on top nav", 'labelRequired': true, 'noninteractiveness': false },

    //homepage events
    'sl_nav_user_clicks_on_explore_courses_on_homepage': { 'category': "SL_Engagement", 'action': "User clicks on Explore courses on homepage", 'labelRequired': true, 'noninteractiveness': false },
    'sl_nav_user_clicks_master_carousal_on_homepage': { 'category': "SL_Engagement", 'action': "User clicks on Master program Carousal on homepage", 'labelRequired': true, 'noninteractiveness': false },
    'sl_nav_user_clicks_on_product_card_on_homepage': { 'category': "SL_Engagement", 'action': "User clicks on Product cards on homepage", 'labelRequired': true, 'noninteractiveness': false },
    'sl_eng_user_clicks_course_type_toggle_on_homepage':{ 'category': "SL_Engagement", 'action': "User clicks on toggle of course type on homepage", 'labelRequired': true, 'noninteractiveness': false },
    'sl_eng_user_explores_testimonials_on_homepage':{ 'category': "SL_Engagement", 'action': "User explores testimonials on homepage", 'labelRequired': true, 'noninteractiveness': false },
    //Category Page Events Start
    'sl_nav_popular_course_on_category_page_clicked': { 'category': "SL_Navigation", 'action': "Popular product clicked on Category Page", 'labelRequired': true, 'noninteractiveness': false },
    'sl_nav_product_on_category_page_clicked':{ 'category': "SL_Navigation", 'action': "Product on Category Page Clicked", 'labelRequired': true, 'noninteractiveness': false },
    //Category Page Events End
    //FPT Event
    'sl_eng_fpt_final_score': { 'category': "SL_Navigation", 'action': "FPT Final Score", 'labelRequired': true, 'noninteractiveness': false },
    'sl_nav_breadcrumb_clicked':{ 'category': "SL_Navigation", 'action': "Breadcrumb clicked on a product page", 'labelRequired': true, 'noninteractiveness': false },
    //Search Page Events
    'sl_search_user_views_search_result': { 'category': "SL_Navigation", 'action': "User lands on the search page and views search result", 'labelRequired': true, 'noninteractiveness': false },
    'sl_search_user_clicks_on_a_search_result': { 'category': "SL_Navigation", 'action': "User clicks on a search result", 'labelRequired': true, 'noninteractiveness': false },
    'sl_lead_chat_lead_created_by_agent':{ 'category': "SL_Lead", 'action': "Chat lead created by chat agent by clicking on Xenia form submit", 'labelRequired': true, 'noninteractiveness': false },

    'sl_eng_category_faq_question_explored': {'category': "SL_Engagement", 'action': "Category FAQ question explored", 'labelRequired': true, 'noninteractiveness': false},
    'sl_eng_category_faq_view_more_clicked': {'category': "SL_Engagement", 'action': "Category FAQ View More Clicked", 'labelRequired': true, 'noninteractiveness': false},
};
// WE user attribute mappting to sl attributes
WebTracking.userAttributesMap = {
    'sl_user_email': 'we_email',
    'sl_user_first_name': 'we_first_name',
    'sl_user_last_name': 'we_last_name',
    'sl_user_phone' : 'we_phone',
    'sl_user_company' : 'we_company',
    'sl_user_state':'we_region',
    // 'sl_product_name':'sl_latest_course_of_interest',
    // 'sl_product_category':'sl_latest_category_of_interest',
    // 'sl_product_category_id':'sl_latest_category_of_interest_id',
    // 'sl_product_id':'sl_latest_course_of_interest_id',
    // 'sl_product_training_type': 'sl_latest_product_training_type_interested',
    // 'sl_product_type':'sl_latest_product_type_interested',
    // 'sl_site_module':'sl_last_lead_site_module',
    // 'sl_frs_site_module':'sl_frs_last_lead_site_module',
    'sl_lead_type':'sl_user_type',
    'sl_user_country':'we_country',
    'sl_user_jobtitle':'sl_user_jobtitle',
    'sl_email_opt_in':'we_email_opt_in',
    'sl_sms_opt_in':'we_sms_opt_in',
    'sl_user_products_bought':'sl_user_products_bought',
    'sl_call_opt_in':'sl_call_opt_in',
    'SL_Purdue_TotalWorkExp':'SL_Purdue_TotalWorkExp'
};

(typeof user_params == 'undefined') && (user_params = {});
WebTracking.questionAttrMap = {
  "Email":'sl_user_email',
  "Mobile": 'sl_user_phone',
  "Phone": 'sl_user_phone',
  "First Name": 'sl_user_first_name',
  "Last Name": 'sl_user_last_name',
  "Company": 'sl_user_company',
  "Employees_Range__c": 'sl_user_number_employees',
  "years_of_experience": "years_of_experience",
}
WebTracking.commonUserAttr = {
    'product' : [
        // 'sl_product_name', 'sl_product_category',
        // 'sl_product_id','sl_product_training_type','sl_product_type',
        // 'sl_site_module','sl_product_category_id',
        'sl_email_opt_in','sl_sms_opt_in'
        ],
    'sl_user_attr' : {
        'sl_user_email' : 'email',
        'sl_user_first_name' : 'first_name',
        'sl_user_last_name' : 'last_name',
        'sl_user_phone' : 'phone',
        'sl_user_country':'country'
    },
    'sl_user_attr_no_update' : {
        // 'sl_site_module': 'sl_first_lead_site_module',
    },
    'we_location_attrs' : ['we_country', 'we_city','we_region'],
    'user_attributes' : ['sl_user_type']
}

WebTracking.commonData = {
    'order': ['sl_page_type', 'sl_order_id', 'sl_currency', 'sl_product_price_symbol', 'sl_product_id', 'sl_product_name',
            'sl_product_ratings', 'sl_product_image', 'sl_product_category', 'sl_product_category_id', 'sl_product_training_type',
            'sl_product_price_osl', 'sl_product_price_lvc', 'sl_product_price_classroom', 'sl_product_type', 'sl_utm_src'
     ],
    'product' : ['sl_page_type', 'sl_product_id', 'sl_product_name', 'sl_currency',
       'sl_product_ratings', 'sl_product_image', 'sl_product_category',
       'sl_product_category_list', 'sl_product_category_id',
       'sl_product_training_type', 'sl_product_type', 'sl_product_learners',
       'sl_product_price_osl', 'sl_product_price_classroom', 'sl_product_price_lvc',
       'sl_product_accredition', 'sl_number_of_course_advisors', 'sl_course_advisors',
       'sl_product_has_free_courses', 'sl_product_free_courses_list','sl_product_number_of_subproduct',
       'sl_product_list_of_subproduct', 'sl_product_price_symbol','sl_product_masters_programs_list','sl_user_type'],

    'frs' : ['sl_frs_resource_id','sl_frs_resource_name','sl_frs_segment_id',
        'sl_frs_segment_name','sl_frs_resource_type','sl_frs_resource_image',
        'sl_frs_author_name','sl_frs_author_image','sl_frs_author_profile_link',
        'sl_frs_resource_view_count','sl_frs_resource_download_count',
        'sl_frs_resource_event_timestamp','sl_frs_resource_updated_timestamp',
        'sl_frs_resource_link','sl_frs_timezone','sl_frs_recommended_resources'],

}
WebTracking.gaBarredAttributes = ['sl_user_email', 'sl_user_first_name', 'sl_user_last_name', 'sl_user_phone'];
// attributes barred to be sent to GA
WebTracking.weBarredEvents = [];
// ===============================================================================================================
'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

WebTracking.eventReq = {
    user: "",
    event_data_key: 'we_event_data',
    user_attr_key: 'we_attr_data',
    uattr: {},
    eventParam: [],
    finalGaParam: [],
    userAttrPush: {},
    // check if WE logged in email is different than new event email and login, create user cookie
    loginUser: function () {
        var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                    switch (_context.prev = _context.next) {
                        case 0:
                            if (typeof this.eventParam != 'undefined' && typeof this.eventParam.event_data != 'undefined' && typeof this.eventParam.event_data['sl_user_email'] != 'undefined' && this.eventParam.event_data['sl_user_email'] != '' && this.eventParam.event_data['sl_user_email'] != this.user) {
                                this.user = this.eventParam.event_data['sl_user_email'];
                                webengage.user.login(this.user);
                                if(this.eventParam.event_data['sl_user_phone']) {
                                    webengage.user.setAttribute('we_phone', this.eventParam.event_data['sl_user_phone']);
                                }
                            }

                        case 1:
                        case 'end':
                            return _context.stop();
                    }
                }
            }, _callee, this);
        }));

        function loginUser() {
            return _ref.apply(this, arguments);
        }

        return loginUser;
    }(),
    logoutUser: function logoutUser() {
        if (typeof webengage != 'undefined' && typeof webengage.state != 'undefined') {
            var weUserData = webengage.state.getForever();
            if (typeof weUserData != 'undefined') {
                webengage.user.logout();
            }
        }
    },
    getDataFromUserParams: function getDataFromUserParams(fields) {
        var self = this;
        if (Array.isArray(fields)) {
            var data = {};
            fields.forEach(function (key) {
                data[key] = typeof user_params[key] != 'undefined' ? user_params[key] : null;
                if (!isNaN(data[key])) {
                    data[key] = Number(data[key]) || 0;
                } else if (self.IsJsonString(data[key])) {
                    data[key] = JSON.parse(data[key]) || {};
                } else {
                    data[key] = data[key] || "";
                }
            });
            return data;
        }
        return {};
    },
    setEventParams: function setEventParams(params) {
        this.eventParam = params;
        if (typeof this.eventParam.event_data == 'undefined') {
            this.eventParam.event_data = {};
        }
        if (typeof webengage != 'undefined' && typeof webengage.state != 'undefined') {
            var weUserData = webengage.state.getForever();
            var hashKey = '';
            if (typeof weUserData != 'undefined' && weUserData && typeof weUserData['uattr'] != 'undefined') {
                if (typeof this.eventParam.event_data['sl_user_email'] !== 'string' || this.eventParam.event_data['sl_user_email'] == weUserData['cuid']) {
                    this.uattr = weUserData['uattr'];
                } else {
                    this.uattr = {};
                }
            }
            if (typeof this.eventParam.event_data['sl_user_email'] != 'undefined') {
                hashKey = this.eventParam.event_data['sl_user_email'];
            } else if (typeof this.uattr.we_email === 'string' && this.uattr.we_email) {
                this.user = this.uattr.we_email;
                hashKey = this.user;
            }
            if (typeof this.eventParam.event_data['sl_user_phone'] != 'undefined') {
                hashKey += "," + this.eventParam.event_data['sl_user_phone'];
            } else if (typeof this.uattr.we_phone === 'string' && this.uattr.we_phone) {
                hashKey += "," + weUserData.uattr['we_phone'];
            }
            this.eventParam.event_data['sl_user_email_hash'] = btoa(hashKey);
        }

        if (typeof this.eventParam.event_data['sl_user_type'] == 'undefined') {
            this.eventParam.event_data['sl_user_type'] = typeof user_params.sl_user_type !== 'undefined' ? user_params.sl_user_type : 'b2c';
        }
        if (typeof this.uattr['sl_user_type'] != 'undefined' && this.uattr['sl_user_type'] == 'b2b') {
            this.eventParam.event_data['sl_user_type'] = this.uattr['sl_user_type'];
        }
        this.eventParam.event_data['sl_event_time'] = Math.floor(new Date());
        this.eventParam.event_data['sl_utm_src'] = fetchUTMSource();
        var user = getUserInfo();
        for (userKey in WebTracking.commonUserAttr['sl_user_attr']) {
            if (typeof this.eventParam.event_data[userKey] == 'undefined' && typeof this.eventParam['user_attributes'] != 'undefined' && this.eventParam['user_attributes'].indexOf(userKey) != -1) this.eventParam.event_data[userKey] = user[WebTracking.commonUserAttr['sl_user_attr'][userKey]];
        }
        if (typeof this.eventParam != 'undefined' && typeof this.eventParam.common != 'undefined' && typeof WebTracking.commonData != 'undefined' && typeof WebTracking.commonData[this.eventParam.common] != 'undefined') {
            for (keyN in WebTracking.commonData[this.eventParam['common']]) {
                commonKey = WebTracking.commonData[this.eventParam['common']][keyN];
                if (typeof this.eventParam.event_data[commonKey] == 'undefined') {
                    var valueCommonKey = "";
                    if (typeof user_params[commonKey] != 'undefined' && user_params[commonKey] !== '') {
                        if (user_params[commonKey] === 'true') {
                            valueCommonKey = true;
                        } else if (user_params[commonKey] === 'false') {
                            valueCommonKey = false;
                        } else if (!isNaN(user_params[commonKey])) {
                            valueCommonKey = Number(user_params[commonKey]) || 0;
                        } else if (this.IsJsonString(user_params[commonKey])) {
                            valueCommonKey = JSON.parse(user_params[commonKey]) || {};
                        } else {
                            valueCommonKey = user_params[commonKey] || "";
                        }
                        if (valueCommonKey != "" && valueCommonKey != 0) this.eventParam.event_data[commonKey] = valueCommonKey;
                    }
                }
            }
        }
        if (typeof this.eventParam != 'undefined' && typeof this.eventParam.user_attributes == 'undefined') {
            this.eventParam.user_attributes = WebTracking.commonUserAttr['user_attributes'];
        } else if (typeof this.eventParam != 'undefined' && typeof this.eventParam.user_attributes != 'undefined') {
            this.eventParam.user_attributes = this.eventParam.user_attributes.concat(WebTracking.commonUserAttr['user_attributes']).filter(onlyUnique);
        }
        if (typeof this.eventParam != 'undefined' && typeof this.eventParam.common != 'undefined' && typeof WebTracking.commonUserAttr != 'undefined' && typeof WebTracking.commonUserAttr[this.eventParam.common] != 'undefined') {
            this.eventParam.user_attributes = this.eventParam.user_attributes.concat(WebTracking.commonUserAttr[this.eventParam.common]).filter(onlyUnique);
        }

        if (printGaInConsole) {
            console.log('this.eventParam.event_data', this.eventParam.event_data);
        }
    },
    // trigger fuction calls for doing tasks on an event
    triggerEvent: function triggerEvent(params) {
        // console.log(params)
        this.setEventParams(params);
        try {
            var fnCalls = [this.loginUser(), this.userAttributesWE(), this.eventPushWE(), this.eventPushSL(), this.userAttPushSL()/*, this.eventPushGA()*/];
            Promise.all(fnCalls).then(this.postEvent());
        } catch (err) {
            console.log('Event tracking error : ', err);
        }
        var eventData = (params && params.event_data) || {};
        if(typeof setAuh === "function") setAuh(eventData);
    },
    userAttributesWE: function () {
        var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var userAttrs, weUserData, userAttributeKey, uAttrName, sessionObj;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                    switch (_context2.prev = _context2.next) {
                        case 0:
                            if (typeof this.eventParam != 'undefined' && typeof this.eventParam.user_attributes != 'undefined') {
                                userAttrs = {};

                                if (typeof webengage != 'undefined' && typeof webengage.state != 'undefined') {
                                    weUserData = webengage.state.getForever();

                                    userAttrs = typeof weUserData != 'undefined' && weUserData && typeof weUserData['uattr'] != 'undefined' ? weUserData['uattr'] : {};
                                }
                                for (index in this.eventParam.user_attributes) {
                                    userAttributeKey = this.eventParam.user_attributes[index];
                                    uAttrName = "";
                                    // console.log('userAttributeKey',userAttributeKey)

                                    if (typeof this.eventParam.userAttributesMap != 'undefined' && typeof this.eventParam.userAttributesMap[userAttributeKey] != 'undefined' && typeof this.eventParam.event_data[userAttributeKey] != 'undefined' && this.eventParam.event_data[userAttributeKey] != '') {
                                        uAttrName = this.eventParam.userAttributesMap[userAttributeKey];
                                    } else if (typeof WebTracking.userAttributesMap[userAttributeKey] != 'undefined' && typeof this.eventParam.event_data[userAttributeKey] != 'undefined' && this.eventParam.event_data[userAttributeKey] != '') {
                                        uAttrName = WebTracking.userAttributesMap[userAttributeKey];
                                    } else if (typeof this.eventParam.event_data[userAttributeKey] != 'undefined' && this.eventParam.event_data[userAttributeKey] != '') {
                                        uAttrName = userAttributeKey;
                                    }
                                    if (uAttrName != '') {
                                        // console.log('uAttrName', userAttributeKey, WebTracking.commonUserAttr['sl_user_attr_no_update'][userAttributeKey]);
                                        if (WebTracking.commonUserAttr['we_location_attrs'].indexOf(uAttrName) != -1 && typeof webengage.util != 'undefined') {
                                            sessionObj = webengage.util.getSessionCookie();

                                            sessionObj[uAttrName] = this.eventParam.event_data[userAttributeKey]; //all manipulations you want to do with we_city, we_country and we_region
                                            webengage.util.setSessionCookie(sessionObj);
                                        } else {
                                            webengage.user.setAttribute(uAttrName, this.eventParam.event_data[userAttributeKey]);
                                        }
                                        this.userAttrPush[uAttrName] = this.eventParam.event_data[userAttributeKey];

                                        if (typeof this.eventParam['sl_user_attr_no_update'] != 'undefined' && typeof this.eventParam['sl_user_attr_no_update'][userAttributeKey] != 'undefined' && typeof userAttrs[this.eventParam['sl_user_attr_no_update'][userAttributeKey]] == 'undefined') {
                                            webengage.user.setAttribute(this.eventParam['sl_user_attr_no_update'][userAttributeKey], this.eventParam.event_data[userAttributeKey]);
                                            this.userAttrPush[this.eventParam['sl_user_attr_no_update'][userAttributeKey]] = this.eventParam.event_data[userAttributeKey];
                                        } else if (typeof WebTracking.commonUserAttr['sl_user_attr_no_update'][userAttributeKey] != 'undefined' && typeof userAttrs[WebTracking.commonUserAttr['sl_user_attr_no_update'][userAttributeKey]] == 'undefined') {
                                            webengage.user.setAttribute(WebTracking.commonUserAttr['sl_user_attr_no_update'][userAttributeKey], this.eventParam.event_data[userAttributeKey]);
                                            this.userAttrPush[WebTracking.commonUserAttr['sl_user_attr_no_update'][userAttributeKey]] = this.eventParam.event_data[userAttributeKey];
                                        }
                                    }
                                }
                                // console.log('update user attributes in WE',this.eventParam.user_attributes);
                                // console.log('user attributes event push to Kafka');
                            }

                        case 1:
                        case 'end':
                            return _context2.stop();
                    }
                }
            }, _callee2, this);
        }));

        function userAttributesWE() {
            return _ref2.apply(this, arguments);
        }

        return userAttributesWE;
    }(),
    // event push to WE
    eventPushWE: function () {
        var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var obj_length, weData;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
                while (1) {
                    switch (_context3.prev = _context3.next) {
                        case 0:
                            if (typeof this.eventParam != 'undefined' && typeof this.eventParam.event_data != 'undefined' && typeof this.eventParam.event_id != 'undefined' && typeof WebTracking.events[this.eventParam.event_id] != 'undefined' && WebTracking.weBarredEvents.indexOf(this.eventParam.event_id) == -1) {
                                obj_length = 0;

                                for (eventAttributeKey in this.eventParam.event_data) {
                                    // console.log('eventAttributeKey',eventAttributeKey)
                                    if (typeof this.eventParam.event_data[eventAttributeKey] == 'undefined' || this.eventParam.event_data[eventAttributeKey] == '') {
                                        delete this.eventParam.event_data[eventAttributeKey];
                                    } else {
                                        obj_length += 1;
                                    }
                                }
                                weData = this.eventParam.event_data;

                                weData['event_name'] = WebTracking.events[this.eventParam.event_id].action;

                                if (obj_length > 0) {
                                    webengage.track(this.eventParam.event_id, this.eventParam.event_data);
                                }

                                //console.log('event push to WE', this.eventParam.event_data, obj_length);
                            }

                        case 1:
                        case 'end':
                            return _context3.stop();
                    }
                }
            }, _callee3, this);
        }));

        function eventPushWE() {
            return _ref3.apply(this, arguments);
        }

        return eventPushWE;
    }(),
    // event push to Kafka
    eventPushSL: function () {
        var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
            var obj_length, weUserData, params, userData;
            return regeneratorRuntime.wrap(function _callee4$(_context4) {
                while (1) {
                    switch (_context4.prev = _context4.next) {
                        case 0:
                            if (!(typeof this.eventParam != 'undefined' && typeof this.eventParam.event_data != 'undefined' && typeof this.eventParam.event_id != 'undefined' && typeof WebTracking.events[this.eventParam.event_id] != 'undefined' && WebTracking.weBarredEvents.indexOf(this.eventParam.event_id) == -1)) {
                                _context4.next = 14;
                                break;
                            }

                            // webengage.track(WebTracking.events[this.eventParam.event_id].action, this.eventParam.event_data);
                            // console.log('event push to Kafka', this.eventParam.event_data);
                            obj_length = 0;


                            for (eventAttributeKey in this.eventParam.event_data) {
                                // console.log('eventAttributeKey',eventAttributeKey)
                                if (typeof this.eventParam.event_data[eventAttributeKey] == 'undefined' || this.eventParam.event_data[eventAttributeKey] == '') {
                                    delete this.eventParam.event_data[eventAttributeKey];
                                } else {
                                    obj_length += 1;
                                }
                            }
                            weData = this.cloneData(this.eventParam.event_data);
                            //Array.from(this.eventParam.event_data);
                            if (typeof webengage != 'undefined' && typeof webengage.state != 'undefined') {
                                weUserData = webengage.state.getForever();

                                if (typeof weUserData != 'undefined' && weUserData && typeof weUserData['cuid'] != 'undefined') weData['we_user_id'] = weUserData['cuid'];
                                if (typeof weUserData != 'undefined' && weUserData && typeof weUserData['luid'] != 'undefined') weData['we_anon_id'] = weUserData['luid'];
                            }
                            weData['sl_page_url'] = document.URL;
                            weData['event_name'] = WebTracking.events[this.eventParam.event_id].action;
                            weData['event_id'] = this.eventParam.event_id;
                            params = { "records": [{ "value": weData, "key": this.eventParam.event_id }] };

                            if (!(obj_length > 0)) {
                                _context4.next = 14;
                                break;
                            }

                            _context4.next = 12;
                            return this.sendEventsSL(params);

                        case 12:
                            if (typeof webengage != 'undefined' && typeof webengage.state != 'undefined') {
                                weUserData = webengage.state.getForever();

                                if (typeof weUserData == 'undefined' || typeof weUserData != 'undefined' && typeof weUserData['cuid'] == 'undefined') {
                                    if (sessionStorage) {
                                        userData = JSON.parse(sessionStorage.getItem(this.event_data_key));

                                        if (typeof userData == 'undefined' || userData == null) {
                                            userData = [];
                                        }
                                        userData.push(weData);
                                        sessionStorage.setItem(this.event_data_key, JSON.stringify(userData));
                                        //setSlGlobalData(this.event_data_key,userData);
                                    }
                                }
                            }
                            //if (printGaInConsole) console.log('event push to Kafka', params);

                        case 14:
                        case 'end':
                            return _context4.stop();
                    }
                }
            }, _callee4, this);
        }));

        function eventPushSL() {
            return _ref4.apply(this, arguments);
        }

        return eventPushSL;
    }(),
    // event push to Kafka
    userAttPushSL: function () {
        var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
            var weData, weUserData, params, userData;
            return regeneratorRuntime.wrap(function _callee5$(_context5) {
                while (1) {
                    switch (_context5.prev = _context5.next) {
                        case 0:
                            if (!(typeof this.userAttrPush != 'undefined' && !this.isEmpty(this.userAttrPush))) {
                                _context5.next = 11;
                                break;
                            }

                            weData = {};

                            weData['sl_event_time'] = typeof this.userAttrPush['sl_event_time'] != 'undefined' ? this.userAttrPush['sl_event_time'] : Math.floor(new Date());
                            weData['sl_page_url'] = document.URL;
                            weData['user_attr'] = this.cloneData(this.userAttrPush);
                            //Array.from(this.userAttrPush);
                            if (typeof webengage != 'undefined' && typeof webengage.state != 'undefined') {
                                weUserData = webengage.state.getForever();

                                if (typeof weUserData != 'undefined' && typeof weUserData['cuid'] != 'undefined') weData['we_user_id'] = weUserData['cuid'];
                                if (typeof weUserData != 'undefined' && typeof weUserData['luid'] != 'undefined') weData['we_anon_id'] = weUserData['luid'];
                            }
                            params = { "records": [{ "value": weData, "key": 'we_user_attr_update' }] };
                            _context5.next = 9;
                            return this.sendEventsSL(params);

                        case 9:
                            if (typeof webengage != 'undefined' && typeof webengage.state != 'undefined') {
                                weUserData = webengage.state.getForever();

                                if (typeof weUserData == 'undefined' || typeof weUserData != 'undefined' && typeof weUserData['cuid'] == 'undefined') {
                                    if (sessionStorage) {
                                        userData = JSON.parse(sessionStorage.getItem(this.user_attr_key));

                                        if (typeof userData == 'undefined' || userData == null) {
                                            userData = [];
                                        }
                                        userData.push(weData);
                                        sessionStorage.setItem(this.user_attr_key, JSON.stringify(userData));
                                        //setSlGlobalData(this.user_attr_key,userData);
                                    }
                                }
                            }
                            //if (printGaInConsole) console.log('user att event push to Kafka', params);

                        case 11:
                        case 'end':
                            return _context5.stop();
                    }
                }
            }, _callee5, this);
        }));

        function userAttPushSL() {
            return _ref5.apply(this, arguments);
        }

        return userAttPushSL;
    }(),
    //send events to KAfka
    sendEventsSL: function sendEventsSL(params) {
        return;
        var xhr = new XMLHttpRequest();
        // xhr.withCredentials = true;
        xhr.open("POST", eventsSLURL, true);
        xhr.setRequestHeader("Content-Type", "application/vnd.kafka.json.v2+json;charset=utf-8;");
        // xhr.setRequestHeader("cache-control", "no-cache");
        // xhr.setRequestHeader("Authorization", "Basic " + btoa(eventsSLUser + ":" + eventsSLPass));
        xhr.onload = function () {
            if (printGaInConsole) console.log('sendEventsSL response', xhr.response);
            return xhr.response;
        };
        xhr.onerror = function () {
            if (printGaInConsole) console.log('sendEventsSL error response', xhr.response);
            return xhr.response;
        };

        xhr.send(JSON.stringify(params));
    },
    // parse event data and push event to GA
    eventPushGA: function () {
        var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
            return regeneratorRuntime.wrap(function _callee6$(_context6) {
                while (1) {
                    switch (_context6.prev = _context6.next) {
                        case 0:
                            if (!(typeof this.eventParam != 'undefined' && typeof this.eventParam.event_data != 'undefined' && typeof this.eventParam.event_id != 'undefined' && typeof WebTracking.events[this.eventParam.event_id] != 'undefined')) {
                                _context6.next = 4;
                                break;
                            }

                            _context6.next = 3;
                            return this.preparePushParam();

                        case 3:
                            this.gaPush(_context6.sent);
                            // console.log('event push to GA', this.eventParam.event_data);
                            // console.log('event push to Kafka');

                        case 4:
                        case 'end':
                            return _context6.stop();
                    }
                }
            }, _callee6, this);
        }));

        function eventPushGA() {
            return _ref6.apply(this, arguments);
        }

        return eventPushGA;
    }(),
    postEvent: function postEvent() {
        var event = typeof this.eventParam.event_id != 'undefined' ? this.eventParam.event_id : "";
        if (printGaInConsole) {
            console.log('event done', event);
        }
    },
    preparePushParam: function preparePushParam() {
        if (typeof this.eventParam !== "undefined" && typeof this.eventParam.event_id !== "undefined") {

            if (typeof WebTracking.events[this.eventParam.event_id] !== "undefined") {
                var value = 0;
                var eventDetail = WebTracking.events[this.eventParam.event_id];
                var funnelString = eventDetail.category;
                var funnelAction = eventDetail.action;
                var funnelLabel = '';
                var noninteractiveness = eventDetail.noninteractiveness;

                if (eventDetail.labelRequired) {
                    funnelLabel = user_params.user_id || 'undefined';
                    for (eventAttributeKey in this.eventParam.event_data) {
                        // console.log('eventAttributeKey',eventAttributeKey)
                        if (WebTracking.gaBarredAttributes.indexOf(eventAttributeKey) == -1 && this.eventParam.event_data[eventAttributeKey] != '') {
                            if (_typeof(this.eventParam.event_data[eventAttributeKey]) == "object") funnelLabel += ' || ' + JSON.stringify(this.eventParam.event_data[eventAttributeKey]);else funnelLabel += ' || ' + this.eventParam.event_data[eventAttributeKey];
                        }
                    }
                    funnelLabel += typeof this.eventParam.entry_page != 'undefined' ? " || " + this.eventParam.entry_page : " || " + document.URL;
                    // console.log('funnelLabel',funnelLabel)
                    return ['_trackEvent', funnelString, funnelAction, funnelLabel, value, noninteractiveness];
                } else {
                    return ['_trackEvent', funnelString, funnelAction, funnelLabel, value, noninteractiveness];
                }
            }

            // console.log('preparePushParam',this.finalGaParam);
        }
    },
    gaPush: function gaPush(finalGaParam) {
        if(!Array.isArray(finalGaParam)) {
            console.error("SL:Error - gaPush invalid finalGaParam");
            return;
        }
        var arrLength = finalGaParam.length;
        if (arrLength > 0) {
            if (printGaInConsole) {
                console.log(finalGaParam);
            }
            if(typeof _gaq !=='undefined'){
                _gaq.push(finalGaParam);
            }
        }
    },
    isEmpty: function isEmpty(obj) {
        for (var key in obj) {
            if (obj.hasOwnProperty(key)) return false;
        }
        return true;
    },
    IsJsonString: function IsJsonString(str) {
        try {
            JSON.parse(str);
        } catch (e) {
            return false;
        }
        return true;
    },
    cloneData: function cloneData(data) {
        return JSON.parse(JSON.stringify(data));
    }
};
WebTracking.setUserParams = function(key, value) {
    user_params[key] = value;
};
// ===============================================================================================================
// WebTracking.eventReq = {
//     user : "",
//     event_data_key:'we_event_data',
//     user_attr_key:'we_attr_data',
//     uattr : {},
//     eventParam: [],
//     finalGaParam: [],
//     userAttrPush: {},
//     // check if WE logged in email is different than new event email and login, create user cookie
//     loginUser: async function () {
//         if ( typeof this.eventParam != 'undefined' && typeof this.eventParam.event_data != 'undefined' && typeof this.eventParam.event_data['sl_user_email'] != 'undefined'
//             && this.eventParam.event_data['sl_user_email'] != '' && this.eventParam.event_data['sl_user_email'] != this.user) {
//             this.user = this.eventParam.event_data['sl_user_email'];
//             webengage.user.login(this.user);
//         }
//     },
//     logoutUser: function () {
//         if (typeof webengage != 'undefined' && typeof webengage.state != 'undefined') {
//           var weUserData = webengage.state.getForever();
//           if (typeof weUserData != 'undefined' && typeof weUserData['cuid'] != 'undefined') {
//             webengage.user.logout();
//           }
//         }
//     },
//     getDataFromUserParams: function(fields) {
//        var self = this;
//        if (Array.isArray(fields)) {
//            var data = {};
//            fields.forEach(function(key) {
//                data[key] = (typeof user_params[key] != 'undefined')?user_params[key]:null;
//                if (!isNaN(data[key])) {
//                    data[key] = Number(data[key]) || 0;
//                } else if (self.IsJsonString(data[key])) {
//                    data[key] = JSON.parse(data[key]) || {};
//                } else {
//                    data[key] = data[key] || "";
//                }
//            });
//            return data;
//        }
//        return {};
//    },
//     setEventParams: function(params){
//       this.eventParam = params;
//       if (typeof this.eventParam.event_data == 'undefined') {
//           this.eventParam.event_data = {}
//       }
//       if (typeof webengage != 'undefined' && typeof webengage.state != 'undefined') {
//           var weUserData = webengage.state.getForever();
//           // if(!weUserData) return;
//            var hashKey = '';
//            if (typeof this.eventParam.event_data['sl_user_email'] != 'undefined') {
//                hashKey = this.eventParam.event_data['sl_user_email'];
//            } else if (typeof weUserData != 'undefined' && typeof weUserData['cuid'] != 'undefined') {
//                this.user = weUserData['cuid'];
//                hashKey = this.user;
//            }
//            if (typeof this.eventParam.event_data['sl_user_phone'] != 'undefined') {
//                hashKey += "," + this.eventParam.event_data['sl_user_phone'];
//            } else if (typeof weUserData != 'undefined' && typeof weUserData['we_phone'] != 'undefined') {
//                hashKey += "," + weUserData['we_phone'];
//            }
//            this.eventParam.event_data['sl_user_email_hash'] = btoa(hashKey);
//            if (typeof weUserData != 'undefined' && typeof weUserData['uattr'] != 'undefined')
//               this.uattr = weUserData['uattr'];
//       }

//       if (typeof this.eventParam.event_data['sl_user_type'] == 'undefined') {
//           this.eventParam.event_data['sl_user_type'] = (typeof user_params.sl_user_type !== 'undefined')?user_params.sl_user_type:'b2c';
//       }
//       if ( typeof this.uattr['sl_user_type'] != 'undefined' && this.uattr['sl_user_type'] == 'b2b') {
//           this.eventParam.event_data['sl_user_type'] = this.uattr['sl_user_type'];
//       }
//       this.eventParam.event_data['sl_event_time'] = Math.floor(new Date());
//       this.eventParam.event_data['sl_utm_src'] = fetchUTMSource();
//       var user = getUserInfo();
//       for ( userKey in WebTracking.commonUserAttr['sl_user_attr'] ) {
//           if (typeof this.eventParam.event_data[userKey] == 'undefined' && typeof this.eventParam['user_attributes'] != 'undefined' && this.eventParam['user_attributes'].indexOf(userKey) != -1 )
//               this.eventParam.event_data[userKey] = user[WebTracking.commonUserAttr['sl_user_attr'][userKey]];
//       }
//       if (typeof this.eventParam != 'undefined' && typeof this.eventParam.common != 'undefined' && typeof WebTracking.commonData != 'undefined' && typeof WebTracking.commonData[this.eventParam.common] != 'undefined') {
//         for ( keyN in WebTracking.commonData[this.eventParam['common']] ) {
//           commonKey = WebTracking.commonData[this.eventParam['common']][keyN];
//           if (typeof this.eventParam.event_data[commonKey] == 'undefined') {
//             var valueCommonKey = "";
//             if(typeof user_params[commonKey] != 'undefined' && user_params[commonKey] !== ''){
//               if (user_params[commonKey] === 'true') {
//                   valueCommonKey = true;
//               } else if (user_params[commonKey] === 'false') {
//                   valueCommonKey = false;
//               } else if(!isNaN(user_params[commonKey])) {
//                 valueCommonKey = Number(user_params[commonKey]) || 0;
//               } else if( this.IsJsonString(user_params[commonKey])) {
//                 valueCommonKey = JSON.parse(user_params[commonKey]) || {};
//               } else {
//                 valueCommonKey = user_params[commonKey] || "";
//               }
//               if (valueCommonKey != "" && valueCommonKey != 0)
//                 this.eventParam.event_data[commonKey] = valueCommonKey;
//             }

//           }
//         }
//       }
//       if (typeof this.eventParam != 'undefined' && typeof this.eventParam.user_attributes == 'undefined') {
//           this.eventParam.user_attributes = WebTracking.commonUserAttr['user_attributes'];
//       }
//       else if (typeof this.eventParam != 'undefined' && typeof this.eventParam.user_attributes != 'undefined'){
//           this.eventParam.user_attributes = this.eventParam.user_attributes.concat(WebTracking.commonUserAttr['user_attributes']).filter( onlyUnique );
//       }
//       if (typeof this.eventParam != 'undefined' && typeof this.eventParam.common != 'undefined' && typeof WebTracking.commonUserAttr != 'undefined' && typeof WebTracking.commonUserAttr[this.eventParam.common] != 'undefined') {
//           this.eventParam.user_attributes = this.eventParam.user_attributes.concat(WebTracking.commonUserAttr[this.eventParam.common]).filter( onlyUnique );
//       }

//       if (printGaInConsole) {
//           console.log('this.eventParam.event_data',this.eventParam.event_data)
//       }
//     },
//     // trigger fuction calls for doing tasks on an event
//     triggerEvent: function (params) {
//        var self = this;
//        webengage.onReady(function() {
//         // console.log(params)
//         self.setEventParams(params);
//         try {
//             var fnCalls = [
//                 self.loginUser(),
//                 self.userAttributesWE(),
//                 self.eventPushWE(),
//                 self.eventPushSL(),
//                 self.userAttPushSL(),
//                 self.eventPushGA()];
//             Promise.all(fnCalls).then(self.postEvent());
//         } catch(err) {
//             console.log('Event tracking error : ',err)
//         }
//        });
//     },
//     userAttributesWE: async function () {
//         if ( typeof this.eventParam != 'undefined' && typeof this.eventParam.user_attributes != 'undefined') {
//             var userAttrs = {};
//             if (typeof webengage != 'undefined' && typeof webengage.state != 'undefined') {
//                 var weUserData = webengage.state.getForever();
//                 userAttrs = typeof weUserData != 'undefined' && typeof weUserData['uattr'] != 'undefined' ? weUserData['uattr'] : {};
//             }
//             for (index in this.eventParam.user_attributes) {
//                 var userAttributeKey  = this.eventParam.user_attributes[index]
//                 var uAttrName = "";
//                 // console.log('userAttributeKey',userAttributeKey)
//                 if(typeof this.eventParam.userAttributesMap != 'undefined' && typeof this.eventParam.userAttributesMap[userAttributeKey] != 'undefined' && typeof this.eventParam.event_data[userAttributeKey] != 'undefined' && this.eventParam.event_data[userAttributeKey] != '') {
//                     uAttrName = this.eventParam.userAttributesMap[userAttributeKey];
//                 } else if(typeof WebTracking.userAttributesMap[userAttributeKey] != 'undefined' && typeof this.eventParam.event_data[userAttributeKey] != 'undefined' && this.eventParam.event_data[userAttributeKey] != '') {
//                     uAttrName = WebTracking.userAttributesMap[userAttributeKey];
//                 } else if(typeof this.eventParam.event_data[userAttributeKey] != 'undefined' && this.eventParam.event_data[userAttributeKey] != '') {
//                     uAttrName = userAttributeKey;
//                 }
//                 if (uAttrName != ''){
//                     // console.log('uAttrName', userAttributeKey, WebTracking.commonUserAttr['sl_user_attr_no_update'][userAttributeKey]);
//                     if(WebTracking.commonUserAttr['we_location_attrs'].indexOf(uAttrName) != -1 && typeof webengage.util != 'undefined') {
//                         var sessionObj         = webengage.util.getSessionCookie();
//                         sessionObj[uAttrName]  = this.eventParam.event_data[userAttributeKey]; //all manipulations you want to do with we_city, we_country and we_region
//                         webengage.util.setSessionCookie(sessionObj)
//                     } else {
//                         webengage.user.setAttribute(uAttrName, this.eventParam.event_data[userAttributeKey]);
//                     }
//                     this.userAttrPush[uAttrName] = this.eventParam.event_data[userAttributeKey];

//                     if (typeof this.eventParam['sl_user_attr_no_update'] !='undefined'
//                         && typeof this.eventParam['sl_user_attr_no_update'][userAttributeKey] != 'undefined'
//                         && typeof userAttrs[this.eventParam['sl_user_attr_no_update'][userAttributeKey]] == 'undefined') {
//                         webengage.user.setAttribute(this.eventParam['sl_user_attr_no_update'][userAttributeKey], this.eventParam.event_data[userAttributeKey]);
//                         this.userAttrPush[this.eventParam['sl_user_attr_no_update'][userAttributeKey]] = this.eventParam.event_data[userAttributeKey];
//                     } else if (typeof WebTracking.commonUserAttr['sl_user_attr_no_update'][userAttributeKey] != 'undefined'
//                         && typeof userAttrs[WebTracking.commonUserAttr['sl_user_attr_no_update'][userAttributeKey]] == 'undefined') {
//                         webengage.user.setAttribute(WebTracking.commonUserAttr['sl_user_attr_no_update'][userAttributeKey], this.eventParam.event_data[userAttributeKey]);
//                         this.userAttrPush[WebTracking.commonUserAttr['sl_user_attr_no_update'][userAttributeKey]] = this.eventParam.event_data[userAttributeKey];
//                     }
//                 }


//             }
//             // console.log('update user attributes in WE',this.eventParam.user_attributes);
//             // console.log('user attributes event push to Kafka');
//         }
//     },
//     // event push to WE
//     eventPushWE: async function () {
//         if ( typeof this.eventParam != 'undefined' && typeof this.eventParam.event_data != 'undefined'
//             && typeof this.eventParam.event_id != 'undefined'
//             && typeof WebTracking.events[this.eventParam.event_id] != 'undefined'
//             && WebTracking.weBarredEvents.indexOf(this.eventParam.event_id) == -1) {
//             var obj_length = 0;
//             for (eventAttributeKey in this.eventParam.event_data) {
//                 // console.log('eventAttributeKey',eventAttributeKey)
//                 if(typeof this.eventParam.event_data[eventAttributeKey] == 'undefined' || this.eventParam.event_data[eventAttributeKey] == '') {
//                     delete this.eventParam.event_data[eventAttributeKey];
//                 } else {
//                     obj_length += 1;
//                 }
//             }
//             var weData = this.eventParam.event_data;
//             weData['event_name'] = WebTracking.events[this.eventParam.event_id].action;
//             if (obj_length > 0){
//                 webengage.track(this.eventParam.event_id, this.eventParam.event_data);

//             }

//             //console.log('event push to WE', this.eventParam.event_data, obj_length);
//         }

//     },
//     // event push to Kafka
//     eventPushSL: async function () {
//         if ( typeof this.eventParam != 'undefined' && typeof this.eventParam.event_data != 'undefined'
//             && typeof this.eventParam.event_id != 'undefined'
//             && typeof WebTracking.events[this.eventParam.event_id] != 'undefined'
//             && WebTracking.weBarredEvents.indexOf(this.eventParam.event_id) == -1) {
//             // webengage.track(WebTracking.events[this.eventParam.event_id].action, this.eventParam.event_data);
//             // console.log('event push to Kafka', this.eventParam.event_data);
//             var obj_length = 0;

//             for (eventAttributeKey in this.eventParam.event_data) {
//                 // console.log('eventAttributeKey',eventAttributeKey)
//                 if (typeof this.eventParam.event_data[eventAttributeKey] == 'undefined' || this.eventParam.event_data[eventAttributeKey] == '') {
//                     delete this.eventParam.event_data[eventAttributeKey];
//                 } else {
//                     obj_length += 1;
//                 }
//             }
//             weData = this.cloneData(this.eventParam.event_data);
//             //Array.from(this.eventParam.event_data);
//             if (typeof webengage != 'undefined' && typeof webengage.state != 'undefined') {
//                 var weUserData = webengage.state.getForever();
//                 if (typeof weUserData != 'undefined' && typeof weUserData['cuid'] != 'undefined')
//                     weData['we_user_id'] = weUserData['cuid'];
//                 if (typeof weUserData != 'undefined' && typeof weUserData['luid'] != 'undefined')
//                     weData['we_anon_id'] =  weUserData['luid'];
//             }
//             weData['sl_page_url'] = document.URL;
//             weData['event_name'] = WebTracking.events[this.eventParam.event_id].action;
//             weData['event_id'] = this.eventParam.event_id;
//             var params = {"records":[{"value":weData,"key":this.eventParam.event_id}]}
//             if (obj_length > 0) {
//                 await this.sendEventsSL(params)
//                 if (typeof webengage != 'undefined' && typeof webengage.state != 'undefined') {
//                   var weUserData = webengage.state.getForever();
//                   if (typeof weUserData == 'undefined' || (typeof weUserData != 'undefined' && typeof weUserData['cuid'] == 'undefined')) {
//                     if(sessionStorage) {
//                       var userData = JSON.parse(sessionStorage.getItem(this.event_data_key));
//                       if(typeof userData == 'undefined' || userData == null) {
//                         userData = [];
//                       }
//                       userData.push(weData);
//                       sessionStorage.setItem(this.event_data_key,JSON.stringify(userData))
//                       setSlGlobalData(this.event_data_key,userData);
//                     }
//                   }
//                 }
//                 if (printGaInConsole)
//                   console.log('event push to Kafka', params);
//             }
//         }

//     },
//     // event push to Kafka
//     userAttPushSL: async function () {
//         if ( typeof this.userAttrPush != 'undefined' && !this.isEmpty(this.userAttrPush)) {
//             var weData = {};
//             weData['sl_event_time'] = typeof this.userAttrPush['sl_event_time'] != 'undefined' ? this.userAttrPush['sl_event_time'] : Math.floor(new Date());
//             weData['sl_page_url'] = document.URL;
//             weData['user_attr'] = this.cloneData(this.userAttrPush);
//             //Array.from(this.userAttrPush);
//             if (typeof webengage != 'undefined' && typeof webengage.state != 'undefined') {
//                 var weUserData = webengage.state.getForever();
//                 if (typeof weUserData != 'undefined' && typeof weUserData['cuid'] != 'undefined')
//                     weData['we_user_id'] = weUserData['cuid'];
//                 if (typeof weUserData != 'undefined' && typeof weUserData['luid'] != 'undefined')
//                     weData['we_anon_id'] = weUserData['luid'];
//             }
//             var params = {"records":[{"value":weData,"key":'we_user_attr_update'}]};
//             await this.sendEventsSL(params);
//             if (typeof webengage != 'undefined' && typeof webengage.state != 'undefined') {
//               var weUserData = webengage.state.getForever();
//               if (typeof weUserData == 'undefined' || (typeof weUserData != 'undefined' && typeof weUserData['cuid'] == 'undefined')) {
//                 if(sessionStorage) {
//                   var userData = JSON.parse(sessionStorage.getItem(this.user_attr_key));
//                   if(typeof userData == 'undefined' || userData == null) {
//                     userData = [];
//                   }
//                   userData.push(weData);
//                   sessionStorage.setItem(this.user_attr_key,JSON.stringify(userData))
//                   setSlGlobalData(this.user_attr_key,userData);
//                 }
//               }
//             }
//             if (printGaInConsole)
//               console.log('user att event push to Kafka', params);
//         }

//     },
//     //send events to KAfka
//     sendEventsSL: function (params) {
//         var xhr = new XMLHttpRequest();
//         // xhr.withCredentials = true;
//         xhr.open("POST", eventsSLURL, true);
//         xhr.setRequestHeader("Content-Type", "application/vnd.kafka.json.v2+json;charset=utf-8;");
//         // xhr.setRequestHeader("cache-control", "no-cache");
//         // xhr.setRequestHeader("Authorization", "Basic " + btoa(eventsSLUser + ":" + eventsSLPass));
//         xhr.onload = function () {
//             if (printGaInConsole)
//                 console.log('sendEventsSL response',xhr.response)
//             return xhr.response;
//         };
//         xhr.onerror = function () {
//             if (printGaInConsole)
//                 console.log('sendEventsSL error response',xhr.response)
//             return xhr.response;
//         };

//         xhr.send(JSON.stringify(params));

//     },
//     // parse event data and push event to GA
//     eventPushGA: async function () {
//         if ( typeof this.eventParam != 'undefined' && typeof this.eventParam.event_data != 'undefined'
//             && typeof this.eventParam.event_id != 'undefined' && typeof WebTracking.events[this.eventParam.event_id] != 'undefined') {
//             await this.preparePushParam()
//             this.gaPush()
//             // console.log('event push to GA', this.eventParam.event_data);
//             // console.log('event push to Kafka');
//         }

//     },
//     postEvent: function () {
//         var event = typeof this.eventParam.event_id != 'undefined' ? this.eventParam.event_id : "";
//         if (printGaInConsole) {
//             console.log('event done', event);
//         }
//     },
//     preparePushParam: function () {
//         if (typeof this.eventParam !== "undefined" && typeof this.eventParam.event_id !== "undefined") {

//             if (typeof WebTracking.events[this.eventParam.event_id] !== "undefined") {
//                 var value = 0;
//                 var eventDetail = WebTracking.events[this.eventParam.event_id];
//                 var funnelString = eventDetail.category;
//                 var funnelAction = eventDetail.action;
//                 var funnelLabel = '';
//                 var noninteractiveness = eventDetail.noninteractiveness;

//                 if (eventDetail.labelRequired) {
//                     funnelLabel = user_params.user_id || 'undefined';
//                     for (eventAttributeKey in this.eventParam.event_data) {
//                         // console.log('eventAttributeKey',eventAttributeKey)
//                             if (WebTracking.gaBarredAttributes.indexOf(eventAttributeKey) == -1 && this.eventParam.event_data[eventAttributeKey] != '') {
//                                 if (typeof this.eventParam.event_data[eventAttributeKey] == "object")
//                                     funnelLabel += ' || ' + JSON.stringify(this.eventParam.event_data[eventAttributeKey]);
//                                 else
//                                     funnelLabel += ' || ' + this.eventParam.event_data[eventAttributeKey];
//                             }

//                     }
//                     funnelLabel += typeof this.eventParam.entry_page != 'undefined' ? " || " + this.eventParam.entry_page : " || " + document.URL;
//                     // console.log('funnelLabel',funnelLabel)
//                     this.finalGaParam = ['_trackEvent', funnelString, funnelAction, funnelLabel, value, noninteractiveness];
//                 } else {
//                     this.finalGaParam = ['_trackEvent', funnelString, funnelAction, funnelLabel, value, noninteractiveness];
//                 }
//             }

//             // console.log('preparePushParam',this.finalGaParam);

//         }
//     },
//     gaPush: function () {
//         var arrLength = this.finalGaParam.length;
//         if (arrLength > 0) {
//             if (printGaInConsole) {
//                 console.log(this.finalGaParam);
//             }
//             if(typeof _gaq !=='undefined'){
//                 _gaq.push(this.finalGaParam);
//             }
//         }
//     },
//     isEmpty: function (obj) {
//         for(var key in obj) {
//             if(obj.hasOwnProperty(key))
//                 return false;
//         }
//         return true;
//     },
//     IsJsonString: function (str) {
//       try {
//           JSON.parse(str);
//       } catch (e) {
//           return false;
//       }
//       return true;
//     },
//     cloneData: function (data) {
//       return JSON.parse(JSON.stringify(data));
//     }
// };
WebTracking.setUserParams = function(key, value) {
    user_params[key] = value;
}
WebTracking.eventReq.setType = function(value) {
    if (typeof value != 'undefined' && value != '') {
        if (value === 'true') {
            value = true;
        } else if (value === 'false') {
            value = false;
        } else if (!isNaN(value)) {
            value = Number(value) || 0;
        } else if (this.IsJsonString(value)) {
            value = JSON.parse(value) || {};
        } else {
            value = value || "";
        }
    } else {
        value = "";
    }
    return value;
}
WebTracking.setUserParams = function(key, value) {
    user_params[key] = value;
}
