angular.module('Simplilearn')
.service('engagementMatrix', ['$http', function ($http) {
    this.update = function (dataObj) {
        try {
            var url = baseApiUrlNocache + '?method=setEngagementMatrix';
            var res = $http.post(url, dataObj);
            // console.log(dataObj);
            res.success(function (data, status, headers, config) {
                // console.log(data);
            });
            res.error(function (data, status, headers, config) {
                // console.log(data);
                console.log("Error : " + JSON.stringify({data: data}));
            });
        } catch (e) {
            console.log(" ###### Error ####### ")
            console.log("Error Message : " + e.message);
            console.log("Error Code : " + e.number & 0xFFFF);
            console.log("Error Name : " + e.name);
        }
    }
}])
.service('contentInfo', function ($http, $cookies,PostReqService) {
     var paramsDetail = {
        filter: setUpDetails.data.filter,
        p: 1,
        content_id:setUpDetails.data.content_id,
        url:setUpDetails.data.url,
        load_condition: 3,
        type:setUpDetails.data.type,
        initialFocussedId:setUpDetails.data.content_id,
        method: 'getFrsDetailsApi'
    }
    var promise = PostReqService.sendPostRequest(siteBaseApiUrlNocache+'?method=getFrsDetailsApi', paramsDetail).
    then(function (output) {
        var contentInfo = output.data.data;

        return contentInfo;
    });
    return promise;
})