angular.module('Simplilearn')
        .service('ScopeService', function ($rootScope) {
            var mem = {};
            return {
                store: function (key, value) {
                    $rootScope.$emit('scope.stored', key);
                    mem[key] = value;
                },
                get: function (key) {
                    return mem[key];
                },
                delete: function (key) {

                    if (key instanceof Array) {
                        if (key.length) {
                            key.forEach(function (current_value) {
                                if (typeof mem[current_value] !== 'undefined') {
                                    delete mem[current_value];
                                }
                            });
                        }
                    }
                }
            };
        });