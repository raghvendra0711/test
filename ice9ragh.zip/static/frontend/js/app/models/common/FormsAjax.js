angular.module('Simplilearn')
.service('FormsAjax', function($http,PostReqService,$compile) {

   this.loadFormviaAjaxSL = function(form_to_load,scope){
      //console.log(user_params.forms_ajax_load)
   this.form_data = null;
   var obj3 = {data_forms : form_to_load}
   PostReqService.sendPostRequest(baseApiUrlNocache + '?method=getCoursePageFormsAjax', obj3)
            .then(function (data) {
                if (data != null && data.data.status == 'success') {
                   this.form_data = data.data.data;
                   angular.forEach(this.form_data,function(value,index){
                        var elem = document.getElementById(index);
                        if(elem !== undefined && elem !== null && elem.innerHTML === "") {
                           angular.element(elem).html(value);
                           $compile(angular.element(elem).contents())(scope);
                        }
                   })

                }
            });
   }

});