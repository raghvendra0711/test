angular.module('Simplilearn')                                                                                                                                                                        
.service("HelperService", function($swipe) { 
    var hfElem,
    commonStore = {};
    
    this.$ = function(elem) {
        hfElem = elem;
        return this;
    };
    
    this.closest = function(fn) {
        while (hfElem) {
            if ( fn.call(hfElem) ) {
                return this;
            }
            hfElem = hfElem.parentNode;
        }
        return false;
    };
    
    this.elem = function() {
        return hfElem;
    };
    
    this.hasClass = function(pClass) {
         return ( (" " + hfElem.className + " " ).indexOf( " "+pClass+" " ) > -1 );
    };
    
    this.onHybridClick = function(pCallback) {
        var elemClicked = false;
        angular.element(hfElem).on('touchstart', function() {
            elemClicked = true;
        });
        angular.element(hfElem).on('touchmove', function() {
            elemClicked = false;
        });
        angular.element(hfElem).on('click touchend', function(event) {
            if (event.type === "click") {
                elemClicked = true;
            }
            
            if (elemClicked){
                pCallback.call(hfElem, event);
            }
        });
    };
    
    var onSwipe = function(pDirection, pCallback) {
        var MAX_VERTICAL_DISTANCE = 75;
        var MAX_VERTICAL_RATIO = 0.3;       // Vertical distance should not be more than a fraction of the horizontal distance.
        var MIN_HORIZONTAL_DISTANCE = 30;
        var startCoords, valid;
        
        var validSwipe = function(coords) {
            if (!startCoords) return false;
            var deltaY = Math.abs(coords.y - startCoords.y);
            var deltaX = (coords.x - startCoords.x) * pDirection;           //Multiplying by direction makes detlaX always positive
            
            return valid &&                                                 //Check that swipe event is valid/not cancelled
                deltaY < MAX_VERTICAL_DISTANCE &&                           //Should not cross vertical threshold, otherwise it becomes a scroll
                deltaX > 0 &&                                               //deltaX should always be positive(because it is being multiplied by direction)
                deltaX > MIN_HORIZONTAL_DISTANCE &&                         //Swipe should be longer than x-coordinate threshold
                deltaY / deltaX < MAX_VERTICAL_RATIO;
        };
      
        $swipe.bind(angular.element(hfElem), {
            'start': function(coords) {
                startCoords = coords;
                valid = true;
            },
            'cancel': function() {
                valid = false;
            },
            'end': function(coords, event) {
                if (validSwipe(coords)) {
                    pCallback.call(hfElem, event);
                }
            }
        });
    };
    
    this.onSwipeLeft = function(pCallback) {
        onSwipe(-1, pCallback);              //negative X-coordinate direction for swipe left
    };
    
    this.onSwipeRight = function(pCallback) {
        onSwipe(1, pCallback);              //positive X-coordinate direction for swipe right
    };
    
    this.dataStorage = function(pKey, pVal) {
        if( typeof pKey !== 'undefined' && typeof pVal !== 'undefined' ) {
            commonStore[pKey] = pVal;
        } else {
            return commonStore;
        }
    };
});


