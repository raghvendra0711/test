angular.module('Simplilearn')
.service('MenuService', function(){

    var currentItemId = null,
        currentSubCatId = null,
        menuData = {};
    
    this.getCurrentItemId = function(){
        return currentItemId;
    };
    
    this.setCurrentItemId = function(itemId){
        currentItemId = itemId;
    };
    
    this.getSubCatId = function(){
        return currentSubCatId;
    };
    
    this.setSubCatId = function(subCatId){
        currentSubCatId = subCatId;
    };
   
});


