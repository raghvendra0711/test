angular.module('Simplilearn')
        .service('CpService', function($http, $rootScope, $timeout, $sce, LeadService, $location, $window,PostReqService,StorageService,$cookies ) {

            var coursePreviewData = null,
                    numOfLessons = null,
                    currSectionId = null,
                    currScoId = null,
                    currElearningId = null,
                    showPreviewVid = [],
                    sectionIframeSrc = [],
                    showIFrameStatus = [],
                    refresh_cache_param = $window.refresh_cache_param,
                    bundle_name='',tagNameStr='course preview',isMultipleVideoUrl = null,
                    semCurrElearningId=null,videoUrlStr=null,semVideoType='',videoPlayList = [],isSemTemplateThird=false;
            var jwPlayerObj,isFromELearning,url, videoFinished = [],goToVideoPlayStatus=false;
            var currentCourseId = 0,
                vidType = null;
            var self = this;
            this.lesson = '';
            this.chapter = '';
            var shortPreviewPopupFlag = true;
            this.exceedPopup = false;
            this.setExceedPopup = function(status) {
                this.exceedPopup = status;
            }

            this.getExceedPopup = function () {
                return this.exceedPopup;
            }

            this.listenerFlag = false;
            this.previewLeadPopup = 0;
            this.setPreviewLeadPopup = function(status){
                this.previewLeadPopup = status;
                if(isSemTemplateThird){
                    var coursePreviewDivId = "course_preview_vid-" + currentCourseId;
                    var index =jwplayer(coursePreviewDivId).getPlaylistIndex();
                    jwplayer(coursePreviewDivId).play()
                    jwplayer(coursePreviewDivId).playlistItem(index);
                }
            }
            this.getPreviewLeadPopup = function(){
                return this.previewLeadPopup;
            }

            this.getCurrScoId = function() {
                return currScoId;
            }


            this.setCurrentCourseId = function(courseId){
                currentCourseId = courseId;
            }

            this.getCurrentCourseId = function(){
                return this.currentCourseId;
            }

            this.setBundleName = function(bundleName){
                bundle_name = bundleName;
            }
            this.getCoursePreviewData = function(pCourseId) {
                var refresh_cache = '';
                if( typeof $location.search()[refresh_cache_param] !== 'undefined' && $location.search()[refresh_cache_param] ) {
                    refresh_cache = '&'+refresh_cache_param+'=1';
                }
                var promise = $http.get(baseApiUrl + "?method=getCoursePreviewData"+refresh_cache,
                        { params: {
                                    "course_id":pCourseId
                                  }
                        })
                        .then(function(response) {
                            if( typeof response.data.status !== 'undefined' && typeof response.data.content !== 'undefined' && response.data.status == 'success' ) {
                                coursePreviewData = response.data.content;
                            }
                            else {
                                coursePreviewData = null;
                            }

                            return coursePreviewData;
                        });

                return promise;
            };

            /// Preview click
            this.handleVideoLinkClick = function(elearningId, lessons, scoId, sectionId, fromELearning,vidurl,vidtype,entp,lesson,chapter,optin) {
                self.lesson = lesson;
                self.chapter = chapter;
                numOfLessons = lessons;
                var siteModule = 'course preview';
                currSectionId = sectionId;
                currScoId = scoId;
                currElearningId = elearningId;
                isFromELearning = fromELearning;
                url = vidurl;
                vidType = vidtype;
                if (numOfLessons !== 0 && numOfLessons !== null) {   //to allow the case of independent video i.e. a video not under any module.
                    return;
                }

                if (!currScoId || (!currScoId && isFromELearning) ) {
                    return;
                }

                $rootScope.isCpClicked = 1;
                if(!user_params.isEuro){
                    var _cpLeadInfoExist = getCookieByName('_user_ld_info');
                    if(shortPreviewPopupFlag) {
                        if((entp == undefined || entp == '')){
                            if(LeadService.isSkipPopup(siteModule)){
                                this.showPreview();                                  
                            }
                            else{
                                self.showPreviewLead();
                                self.gaCoursePreviewModelJs.evtFireOnCoursePreviewLead();
                            }
                        }
                        else{
                            if(LeadService.isSkipPopup(siteModule)){
                                this.showPreview();                                  
                            }
                            else{
                                this.showPreview();   //no lead
                            }
                        }                      
                    } else {
                        if (!optin && $rootScope.isLoggedIn != true && (entp == undefined || entp == '')) {
                            $timeout(function() {
                                var loginBtnObj = document.getElementById('registerBtn');
                                if(!loginBtnObj) {
                                    var loginBtnObj = document.getElementById('loginBtnAlt');
                                }

                                angular.element(loginBtnObj).triggerHandler('click');
                            }, 0);
                        }
                        else {
                            this.showPreview();
                        }
                    }
                }
                // if country is euro and not b2b portal
                if(user_params.isEuro /*&& (entp == undefined || entp == '')*/ ) {
                    var optinSet = typeof getCookieByName(user_params.OPTIN_COOKIE) != 'undefined' ? true : false;
                    var optin = getCookieByName(user_params.OPTIN_COOKIE) == 1 ? true : false;
                    //var cprCookie = getCookieByName('_cpruid');
                    var _cpLeadInfoExist = getCookieByName('_user_ld_info');
                     if (LeadService.isSkipPopup(siteModule)) {
                        if ((optin == true || $rootScope.isPreviewLeadCreated) || !optinSet || _cpLeadInfoExist) {
                            this.showPreview();
                            self.gaCoursePreviewModelJs.evtFireOnCoursePreviewLead();
                        } 
                        else {
                            this.showPreview();
                        }
                    }
                    else{
                        if(($cookies[user_params.enterpriseCountCookieName])){ 
                            this.showPreview();
                        }
                        else{
                        if((optin == true) || !optinSet){
                            $timeout(function() {
                            self.showPreviewLead();
                        }, 0);
                        }
                        else {
                            this.showPreview();
                        }
                    }
                }
            }

                if(!self.listenerFlag) {
                    $rootScope.$on('isPreviewLeadCreated', function(pEvt, pVal) {
                        if(pVal && $rootScope.isCpClicked === 1) {
                           // console.log("line 160 called");
                            self.showPreview();
                        }
                    });

                    $rootScope.$on('isLoggedIn', function(pEvt, pVal) {
                        if(pVal && $rootScope.isCpClicked === 1) {
                           // console.log("line 167 called");
                            self.showPreview();
                        }
                    });
                    self.listenerFlag = true;
                }

                return $rootScope.isCpClicked !== null && showPreviewVid[currentCourseId] === 1 && $rootScope.isCpClicked === 1;
            };
            // Preview click Sem Master
            this.handleVideoLinkClickSem = function (elearningId, lessons, scoId, sectionId, fromELearning, vidurl, vidtype, entp, lesson, chapter,optin) {
                self.lesson = lesson;
                self.chapter = chapter;
                numOfLessons = lessons;
                currSectionId = sectionId;
                currScoId = scoId;
                currElearningId = elearningId;
                isFromELearning = fromELearning;
                url = vidurl;
                vidType = vidtype;
                if (numOfLessons !== 0 && numOfLessons !== null) {   //to allow the case of independent video i.e. a video not under any module.
                    return;
                }
                if (!currScoId || (!currScoId && isFromELearning)) {
                    return;
                }
                $rootScope.isCpClicked = 1;
                if(!user_params.isEuro){
                    var _cpLeadInfoExist = getCookieByName('_user_ld_info');
                    if (shortPreviewPopupFlag) {
                        var semFreeVideoFlag = false;
                        if($rootScope.isSemBundle && $rootScope.templateId == 2){
                            var semBundleId=user_params.bundle_id;
                            var sembFVCookie='_sembfv'+semBundleId+'_identifier';
                            var sembFreeVideo= getCookieByName(sembFVCookie);
                            var sembFVIDCookie='_sembfvId'+semBundleId+'_identifier';
                            var sembFreeVideoId = getCookieByName(sembFVIDCookie);
                            semFreeVideoFlag = (typeof sembFreeVideo === "undefined" || sembFreeVideo == "false" )? true : false;
                            if(semFreeVideoFlag != true && $rootScope.isPreviewLeadCreated != true){
                                entp='';
                            }
                            if(typeof sembFreeVideoId !=="undefined" && sembFreeVideoId == currScoId){
                                 semFreeVideoFlag=true;
                            }
                         }
                         
                         if((entp == undefined || entp == '')){
                            if(LeadService.isSkipPopup('course preview') || semFreeVideoFlag){
                                this.showPreview(semFreeVideoFlag);                                  
                            }
                            else{

                                self.showPreviewLead();
                                self.gaCoursePreviewModelJs.evtFireOnCoursePreviewLead();
                            }
                        }
                        else{
                            if(LeadService.isSkipPopup('course preview')){
                                this.showPreview();                                  
                            }
                            else{
                                this.showPreview();   //no lead
                            }
                        }
                    } else {
                        if ($rootScope.isLoggedIn != true && (entp == undefined || entp == '')) {
                            $timeout(function () {
                                var loginBtnObj = document.getElementById('registerBtn');
                                if (!loginBtnObj) {
                                    var loginBtnObj = document.getElementById('loginBtnAlt');
                                }
                                angular.element(loginBtnObj).triggerHandler('click');
                            }, 0);
                        }
                        else {
                            //console.log("line 231 called");
                            this.showPreview();
                        }
                    }
                }
                // if country is euro and not b2b portal
                if(user_params.isEuro  /*&& (entp == undefined || entp == '')*/ ) {
                    var optinSet = typeof optin != 'undefined' ? true:false;
                    var optin = (optin == 1) ? true : false;
                    var _cpLeadInfoExist = getCookieByName('_user_ld_info');
                    var semFreeVideoFlag = false;
                    if($rootScope.isSemBundle && $rootScope.templateId == 2){
                            var semBundleId=user_params.bundle_id;
                            var sembFVCookie='_sembfv'+semBundleId+'_identifier';
                            var sembFreeVideo= getCookieByName(sembFVCookie);
                            var sembFVIDCookie='_sembfvId'+semBundleId+'_identifier';
                            var sembFreeVideoId = getCookieByName(sembFVIDCookie);
                           semFreeVideoFlag = (typeof sembFreeVideo === "undefined" || sembFreeVideo == "false" )? true : false;
                           if(semFreeVideoFlag != true && $rootScope.isPreviewLeadCreated != true){
                               entp='';
                           }
                           if(typeof sembFreeVideoId !=="undefined" && sembFreeVideoId == currScoId){
                                semFreeVideoFlag=true;
                           }
                        }
                    
                    if (LeadService.isSkipPopup('course preview')) {
                        if ((optin == true || $rootScope.isPreviewLeadCreated) || !optinSet || _cpLeadInfoExist) {
                            this.showPreview(semFreeVideoFlag);
                            self.gaCoursePreviewModelJs.evtFireOnCoursePreviewLead();
                        } 
                        else {
                            this.showPreview(semFreeVideoFlag);
                        }
                    }
                    else{
                        if(((optin == true) || !optinSet) && semFreeVideoFlag != true){
                            $timeout(function() {
                            self.showPreviewLead();
                              $rootScope.showPreviewLeadStatus = true;
                        }, 0);
                        }
                        else {
                            this.showPreview(semFreeVideoFlag);
                        }
                }                                     
                }

                if (!self.listenerFlag) {
                    $rootScope.$on('isPreviewLeadCreated', function (pEvt, pVal) {
                        if (pVal && $rootScope.isCpClicked === 1) {
                            //console.log("line 277 called");
                            self.showPreview();
                        }
                    });

                    $rootScope.$on('isLoggedIn', function (pEvt, pVal) {
                        if (pVal && $rootScope.isCpClicked === 1) {
                            //console.log("line 285 called");
                            self.showPreview();
                        }
                    });
                    self.listenerFlag = true;
                }
                return $rootScope.isCpClicked !== null && showPreviewVid[currentCourseId] === 1 && $rootScope.isCpClicked === 1;
            };
             this.fhandleVideoLinkClickSem = function (elearningId, lessons, scoId, sectionId, fromELearning, vidurl, vidtype, entp, lesson, chapter,optin,isMultipleVideo,index) {
                 self.lesson = lesson;
                self.chapter = chapter;
                numOfLessons = lessons;
                currSectionId = sectionId;
                var _cpLeadInfoExist = getCookieByName('_user_ld_info');
                currScoId = scoId;
                currElearningId = elearningId;
                isFromELearning = fromELearning;
                url = vidurl;
                vidType = vidtype;
                currentCourseId= parseInt(currentCourseId);
                isMultipleVideoUrl = typeof isMultipleVideo !=="undefined" ? isMultipleVideo : null;
                if (numOfLessons !== 0 && numOfLessons !== null) {   //to allow the case of independent video i.e. a video not under any module.
                    return;
                }

                if (!currScoId || (!currScoId && isFromELearning)) {
                    return;
                }
                $rootScope.isCpClicked = 1;
                $rootScope.goToVideoIndex=index;
                if(!user_params.isEuro){
                    if (shortPreviewPopupFlag) {
                        if (!LeadService.isSkipPopup('course preview')&&(entp == undefined || entp == '') && (index > 0)) {
                            $rootScope.showPreviewLeadStatus = true;
                            self.gaCoursePreviewModelJs.evtFireOnCoursePreviewLead();
                            $rootScope.semVideoIndex=index; 
                            self.showPreviewLead();
                            this.fshowPreview(index);
                        }
                        else {
                            $timeout(function() {
                             $rootScope.showPreviewLeadStatus = false;
                             $rootScope.semVideoIndex=index;
                            self.fshowPreview(index);
                        }, 0);
                        }
                    } else {
                        if ($rootScope.isLoggedIn != true && (entp == undefined || entp == '')) {
                            $timeout(function () {
                                var loginBtnObj = document.getElementById('registerBtn');
                                if (!loginBtnObj) {
                                    var loginBtnObj = document.getElementById('loginBtnAlt');
                                }
                                angular.element(loginBtnObj).triggerHandler('click');
                            }, 0);
                        }
                        else {
                            $rootScope.semVideoIndex=index;
                            this.fshowPreview(index);
                        }
                    }
                }
                // if country is euro and not b2b portal
                if(user_params.isEuro /* && (entp == undefined || entp == '') */) {
                    var optinSet = typeof optin != 'undefined' ? true:false;
                    var optin = (optin == 1) ? true : false;
                    //if course preview cookie is not created and optin cookie is not created
                    //show form
                    if((!LeadService.isSkipPopup('course preview') && (index > 0))){
                        $timeout(function() {
                            if(parseInt(index)){
                                $rootScope.semVideoIndexEuro = index;
                                $rootScope.showPreviewLeadStatus = true;
                                self.showPreviewLead();
                            }else{
                                $rootScope.semVideoIndexEuro = index;
                                $rootScope.showPreviewLeadStatus = false;
                            }
                            self.fshowPreview(index);
                        }, 0);
                        //if course preview cookie is set and user has opted in to create lead
                        //then show course preview and create lead
                    } else if(optin == true && $rootScope.isPreviewLeadCreated){
                        $rootScope.showPreviewLeadStatus = false;
                        $rootScope.semVideoIndexEuro = index;
                        this.fshowPreview(index);
                        self.gaCoursePreviewModelJs.evtFireOnCoursePreviewLead();
                    }else if(optin == false){
                        $rootScope.showPreviewLeadStatus = false;
                    }
                    else {
                        $rootScope.semVideoIndexEuro = index;
                        this.fshowPreview(index);
                    }

                }

                if (!self.listenerFlag) {
                    $rootScope.$on('isPreviewLeadCreated', function (pEvt, pVal) {
                        if (pVal && $rootScope.isCpClicked === 1) {
                            if(typeof user_params.isEuro !=="undefined" && user_params.isEuro){
                                if($rootScope.semVideoIndexEuro){
                                    index = $rootScope.semVideoIndexEuro;
                                }
                            }
                            if(!user_params.isEuro){
                                if($rootScope.semVideoIndex){
                                    index = $rootScope.semVideoIndex;
                                }
                            }
//                            self.fshowPreview(index);
                        }
                    });

                    $rootScope.$on('isLoggedIn', function (pEvt, pVal) {
                        if (pVal && $rootScope.isCpClicked === 1) {
//                            self.fshowPreview(index);
                        }
                    });
                    self.listenerFlag = true;
                }
                return $rootScope.isCpClicked !== null && showPreviewVid[currentCourseId] === 1 && $rootScope.isCpClicked === 1;
            };

            this.showPreviewLead = function() {
                self.setPreviewLeadPopup(1);
            };

            this.coursePreviewWatch = function (type) {
                var optin = (getCookieByName(user_params.OPTIN_COOKIE) == 1) ? true : false;
                if (!optin && user_params.isEuro) {
                    return;
                }
                if(typeof $rootScope.hasValidationCoursePreview != 'undefined' && $rootScope.hasValidationCoursePreview === false) {
                    $rootScope.hasValidationCoursePreview = null;
                    return;
                }
            };

            this.showPreview = function(semFreeVideoFlag){
                var courseType = '';
                var optin = getCookieByName(user_params.OPTIN_COOKIE) == 1 ? true : false;
                var optinSet = typeof $cookies[user_params.OPTIN_COOKIE] != 'undefined' ? true:false;
                if(user_params.course_id) {
                    courseType = 'course';
                } else if(user_params.bundle_id) {
                    courseType = 'bundle';
                }
                videoFinished[currentCourseId] = 0;
                for(var key in showPreviewVid){
                    showPreviewVid[key] = 0;
                }
                if(typeof isFromELearning != 'undefined' && url!=null && url !=''){
                    var postParams = {'method':'getVideoUrl','video':url, 'isFromELearning': (isFromELearning)?1:0, 'type': courseType };
                    PostReqService.sendPostRequest(baseApiUrlNocache,postParams)
                            .then(function (response) {
                                if(typeof response.data !== 'undefined' && response.data == null){
                                }else if (typeof response.status !== 'undefined' && typeof response.data !== 'undefined' && response.status == '200') {
                                    var resData = response.data;
                                    if(resData && resData.status == "success") {
                                        try{
                                            if($cookies[user_params.enterpriseCountCookieName] == undefined || $cookies[user_params.enterpriseCountCookieName] == ''){
                                                if((optin!==false || !optinSet) && !LeadService.getLeadStatus('course preview')){
                                                if(!semFreeVideoFlag)
                                                    self.submitPreviewLead();
                                                
                                        }
                                            }
                                            else {
                                               if(LeadService.isSkipPopup('course preview')){
                                                self.submitPreviewLead();
                                            }
                                        }
                                        }
                                        catch(err){}
                                        showPreviewVid[currentCourseId] = 1;
                                        if($rootScope.isLoggedIn) {
                                            self.coursePreviewWatch(0);
                                        } else {
                                            self.coursePreviewWatch(1);
                                        }

                                        if(!isFromELearning) {
                                            var videoUrl = response.data;
                                            var vUrl = videoUrl.url;
                                            videoFinished[currentCourseId] = 0;
                                            var coursePreviewDivId = "course_preview_vid-"+currentCourseId;
                                            jwPlayerObj = jwplayer(coursePreviewDivId).setup({
                                                    file: vUrl,
                                                    image: '',
                                                    base: staticUrl + 'core/js/jwplayer/',
                                                    width: "100%",
                                                    aspectratio:"2:1",
                                                    startparam: 'start',
                                                    //skin: staticUrl + 'core/js/jwplayer/skin_base64_new.xml',
                                                    fallback: false,
                                                    icons: true,
                                                    autostart: true
                                            }).on('complete',function(){
                                                $timeout(function() {
                                                    document.getElementById(coursePreviewDivId).innerHTML = '';
                                                }, 500);
                                                $rootScope.$apply(function(){
                                                    for(var key in showPreviewVid){
                                                        videoFinished[key] = 0;
                                                    }
                                                    videoFinished[currentCourseId] = 1;
                                                });
                                            }).on('play',function(){
                                                $rootScope.$apply(function(){
                                                    videoFinished[currentCourseId] = 0;
                                                });
                                            });
                                            showIFrameStatus[currentCourseId] = 0;
                                        } else {
                                            var videoUrl = response.data;
                                            var vUrl = videoUrl.url;
                                            if (vidType == 'webcontent') {
                                                sectionIframeSrc[currentCourseId] = $sce.trustAsResourceUrl(vUrl);
                                                showIFrameStatus[currentCourseId] = 1;
                                            } else if (vidType == 'mp4') {
                                                videoFinished[currentCourseId] = 0;
                                                var coursePreviewDivId = "course_preview_vid-" + currentCourseId;
                                                jwPlayerObj = jwplayer(coursePreviewDivId).setup({
                                                    file: vUrl,
                                                    image: '',
                                                    base: staticUrl + 'core/js/jwplayer/',
                                                    width: "100%",
                                                    aspectratio: "2:1",
                                                    startparam: 'start',
                                                    fallback: false,
                                                    icons: true,
                                                    autostart:true,
                                                }).on('complete',function(){
                                                    $timeout(function () {
                                                        document.getElementById(coursePreviewDivId).innerHTML = '';
                                                    },0);
                                                    $rootScope.$apply(function () {
                                                        for (var key in showPreviewVid) {
                                                            videoFinished[key] = 0;
                                                        }
                                                        videoFinished[currentCourseId] = 1;
                                                    });
                                                    if (document.exitFullscreen) {
                                                        document.exitFullscreen();
                                                    }
                                                   
                                                }).on('play',function(){
                                                    if($rootScope.isSemBundle && $rootScope.templateId == 2){
                                                                var semBundleId=user_params.bundle_id;
                                                                var sembFVCookie='_sembfv'+semBundleId+'_identifier';
                                                                var sembFreeVideo= getCookieByName(sembFVCookie);
                                                                if(typeof sembFreeVideo ==="undefined" || sembFreeVideo != true){
                                                                    var exdays= 90;
                                                                    var d = new Date();
                                                                    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
                                                                    var expires = "expires=" + d.toUTCString();
                                                                    var cname = sembFVCookie;
                                                                    var cvalue=1;
                                                                    var path ="/";
                                                                    document.cookie = cname + "=" + cvalue + "; " + expires + ";path=" + path + ";SameSite=Lax;";
                                                                }
                                                                var sembFVIDCookie='_sembfvId'+semBundleId+'_identifier';
                                                                var sembFreeVideoId = getCookieByName(sembFVIDCookie);
                                                                if(typeof sembFreeVideoId === "undefined" || sembFreeVideoId == "false"){
                                                                    var exdays= 90;
                                                                    var d = new Date();
                                                                    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
                                                                    var expires = "expires=" + d.toUTCString();
                                                                    var cname = sembFVIDCookie;
                                                                    var cvalue=currScoId;
                                                                    var path ="/";
                                                                    document.cookie = cname + "=" + cvalue + "; " + expires + ";path=" + path + ";SameSite=Lax;";
                                                                }
                                                    }
                                                    $rootScope.$apply(function () {
                                                        videoFinished[currentCourseId] = 0;
                                                    });
                                                });
                                                showIFrameStatus[currentCourseId] = 0;
                                            }
                                        }

                                        self.gaCoursePreviewModelJs.gaFireOnCoursePreviewSuccess();
                                    } else {

                                        /*
                                        // Exceed Popup
                                        self.setExceedPopup(true);
                                        var exceedPopup = document.getElementById('course-preview-restrict');
                                        exceedPopup.style.display = 'block';
                                        */

                                        $timeout(function() {
                                            self.showPreviewLead();
                                        }, 0);
                                    }
                                }
                            });
                }else{
                    self.gaCoursePreviewModelJs.gaFireOnCoursePreviewSuccess();
                    sectionIframeSrc[currentCourseId] = $sce.trustAsResourceUrl(baseLmsUrl + "course/scorm/course-preview/elearningId/"+currElearningId+"/sectionId/" + currSectionId + "/scoId/" + currScoId);
                    showIFrameStatus[currentCourseId] = 1;
                }
                return true;
            };

            this.submitPreviewLead = function () {
                var siteModule = 'course preview';
                var _cpLeadInfoExist = getCookieByName('_user_ld_info');
                var cprPID = '';
                if (typeof user_params.sl_product_type !== "undefined" && user_params.sl_product_type == "course") {
                    cprPID = 'cprc' + user_params.course_id;
                }
                else if (typeof user_params.sl_product_type !== "undefined" && user_params.sl_product_type == "bundle") {
                    cprPID = 'cprb' + user_params.bundle_id;
                }
                var autoLead = 0;
                var optinSet = typeof $cookies[user_params.OPTIN_COOKIE] != 'undefined' ? true:false;
                
                if(!user_params.isEuro && typeof _cpLeadInfoExist !=="undefined" && _cpLeadInfoExist || LeadService.isSkipPopup(siteModule)){
                    autoLead = 1;
                } else if(!user_params.isEuro && $rootScope.isLoggedIn && typeof($cookies[user_params.enterpriseCountCookieName]) != undefined || LeadService.isSkipPopup(siteModule)){
                    autoLead = 1;
                } else if(user_params.isEuro && typeof _cpLeadInfoExist !=="undefined" && _cpLeadInfoExist && optinSet || LeadService.isSkipPopup(siteModule)){
                    autoLead = 1;
                } else{
                    autoLead = 0;
                }
                if ((typeof _cpLeadInfoExist !=="undefined" && _cpLeadInfoExist) || LeadService.isSkipPopup(siteModule) || ($rootScope.isLoggedIn && typeof($cookies[user_params.enterpriseCountCookieName]) != undefined)) {
                    $rootScope.isCpClicked=0;
                    var coursePreviewCookieCIdArr = [];
                    if(typeof _cpLeadInfoExist !=="undefined"){
                        coursePreviewCookieCIdArr=_cpLeadInfoExist.split(",")
                    }
                    if ((coursePreviewCookieCIdArr.length > 0 && coursePreviewCookieCIdArr.indexOf(cprPID) == -1 ) || (coursePreviewCookieCIdArr.length == 0)) {
                        webengage.onReady(function () {
                            var webEngageLeadParams = [];
                            if(typeof webengage.state != 'undefined' && typeof webengage.state.getForever != 'undefined'){
                                webEngageLeadParams = webengage.state.getForever().uattr;
                            }
                            if(typeof webEngageLeadParams !=="undefined" && webEngageLeadParams['we_email']){
                                    var locatorCookie = getCookieByName('locatori9');
                                    var locatorCookieObj = JSON.parse(locatorCookie);
                                    var leadSourceString = document.URL;
                                    var idVar = user_params.course_id != undefined || user_params.course_id != '' ? user_params.course_id : user_params.bundle_id;
                                    var pageCategory = typeof user_params.pageCategory !== "undefined" ? user_params.pageCategory : '';
                                    var firstName = webEngageLeadParams['we_first_name'];
                                    var lastName = webEngageLeadParams['we_last_name'];
                                    var phone= webEngageLeadParams['we_phone'];
                                    var email = webEngageLeadParams['we_email'];
                                    var cprPID=0;
                                    var cprPName="";
                                    if(typeof user_params.sl_product_type !=="undefined" && user_params.sl_product_type == "course"){
                                           cprPID = user_params.course_id;
                                           cprPName=user_params.course_name;
                                    }
                                    else if(typeof user_params.sl_product_type !=="undefined" && user_params.sl_product_type == "bundle"){
                                           cprPID =  user_params.bundle_id;
                                           cprPName=user_params.bundle_name;
                                    }
                                    var postParams = {
                                        'email': email,
                                        'phone': phone,
                                        'courseId': idVar,
                                        'topicId': self.getCurrScoId(),
                                        'courseName': user_params.course_name,
                                        'customerType': 'B2C',
                                        'agreeToContact': '',
                                        'leadSource': fetchUTMSource(),
                                        'leadTrainingType': 'Not Sure',
                                        'leadSourceString': leadSourceString,
                                        'tagName': siteModule,
                                        'b2cQueryType': 'course_preview',
                                        'productTypeId': user_params.productTypeId,
                                        'billingTypeId': user_params.billingTypeId,
                                        'query': '',
                                        'auth': '1',
                                        'GCLID': getGCLID(),
                                        'pageCategory': pageCategory,
                                        'countryId': locatorCookieObj.country_id,
                                        'countryName': locatorCookieObj.country_name.replace(/\+/g, ' '),
                                        'cityId': locatorCookieObj.city_id,
                                        'cityName': locatorCookieObj.name,
                                        'sl_product_id': cprPID,
                                        'sl_product_name': cprPName,
                                        'autoLead' : autoLead,
                                    };
                                WebTracking.eventReq.triggerEvent({
                                    event_id : "sl_lead_user_submitted_lead_form",
                                    event_data: {
                                        'sl_lead_type' : 'b2c',
                                        'sl_site_module' : siteModule,
                                        'sl_user_email': email,
                                        'sl_user_phone' : phone || '',
                                        'sl_email_opt_in' : true,
                                        'sl_sms_opt_in': true,
                                        'sl_user_first_name' :  typeof   firstName  != 'undefined' && firstName  ? firstName : '',
                                        'sl_user_last_name' :   typeof   lastName   != 'undefined'   &&   lastName ?  lastName : '',
                                        'sl_call_opt_in':true
                                    },
                                    common : "product",
                                    user_attributes: ['sl_lead_type', 'sl_event_time','sl_user_email','sl_user_phone','sl_call_opt_in'],
                                    // userAttributesMap: {'sl_event_time' : 'sl_last_lead_creation_date'},
                                    // sl_user_attr_no_update:{'sl_event_time' : 'sl_first_lead_creation_date'}
                                });
                                var webEngageLeadFormParams = WebTracking.eventReq.eventParam.event_data;
                                var finalB2CParamArr=PostReqService.prepareB2CLeadParameters(postParams,webEngageLeadFormParams);
                                var applicationContentType='json';
                                try{
                                        PostReqService.sendPostRequest(leadApiGatewayEndpoint, finalB2CParamArr,applicationContentType)
                                                .then(function (data, status, header, config){
                                                            if (typeof data !=="undefined" && data != null) {
                                                                if (data.status == 200 && data.data.status == "success") {
                                                                            // Update user hash
                                                                            var user = $rootScope.userInfo || {};
                                                                            user.email = postParams.email;
                                                                            user.phone = phone || user.phone;
                                                                            user.phoneCode = user.phoneCode || '';
                                                                            PostReqService.setUserHash(user);
                                                                            self.setPreviewLeadPopup(0)
                                                                            $rootScope.isPreviewLeadCreated = true;
                                                                            $rootScope.showPreviewLeadStatus = false;
                                                                            $rootScope.$emit('isPreviewLeadCreated', true);
                                                                            var coursePreviewWatch = 0;
                                                                            var cprPID = 0;
                                                                            if(user_params.course_id){
                                                                                var cId = user_params.course_id;
                                                                            }
                                                                            else if(user_params.bundle_id){
                                                                                var cId = user_params.bundle_id;
                                                                            }
                                                                                
                                                                            var _cpLeadInfoExist = getCookieByName('_user_ld_info');
                                                                            if (typeof user_params.sl_product_type !== "undefined" && user_params.sl_product_type == "course") {
                                                                                cprPID = 'cprc' + user_params.course_id;
                                                                            }
                                                                            else if (typeof user_params.sl_product_type !== "undefined" && user_params.sl_product_type == "bundle") {
                                                                                cprPID = 'cprb' + user_params.bundle_id;
                                                                            }

                                                                            if (_cpLeadInfoExist) {
                                                                                var coursePreviewCookieCIdArr = _cpLeadInfoExist.split(",");
                                                                                if (coursePreviewCookieCIdArr.indexOf(cprPID) == -1) {
                                                                                    coursePreviewCookieCIdArr.push(cprPID);
                                                                                    cprPID = coursePreviewCookieCIdArr.join(",");
                                                                                }
                                                                            }
                                                                            LeadService.setUserLeadCookie(cId,cprPID); 
                                                                            PostReqService.getHashUser(function (userData) {
                                                                                    if (userData != null){
                                                                                        if(userData.email == email)
                                                                                             LeadService.setSkipPopup();
                                                                                    }
                                                                             })
                                                                            if(typeof user_params.isPlayListVideo !=='undefined' && user_params.isPlayListVideo === true &&  typeof $rootScope.templateId !=="undefined" && parseInt($rootScope.templateId) ===3){
                                                                                $rootScope.semVideoPlayListLeadStatus = true;
                                                                                $timeout(function () {
                                                                                    //console.log("called");
                                                                                    if (typeof _cpLeadInfoExist !== 'undefined') {
                                                                                        if ($rootScope.isLoggedIn) {
                                                                                            self.coursePreviewWatch(0);
                                                                                        } else {
                                                                                            self.coursePreviewWatch(1);
                                                                                        }
                                                                                    }
                                                                                }, 1000);
                                                                            }
                                                                            if ($rootScope.isLoggedIn) {
                                                                                  var leadId = (typeof data.data.data !== "undefiend" && typeof data.data.data.success !=='undefined' && typeof data.data.data.success[0] !== 'undefined' && typeof data.data.data.success[0].lead_id !=='undefined') ? data.data.data.success[0].lead_id : '';
                                                                                  if(leadId){
                                                                                      setUpDataLayer('leadCapture', 'coursePreview', {'leadId': leadId});
                                                                                  }
                                                                            }
                                                                            var gaPreviewLead = new gaClassForPreviewLead();
                                                                            gaPreviewLead.gaFireOnPreviewLead('leadsubmittedpreview', user_params.user_id + ' || ' + document.URL + ' || course preview || ' + user_params.course_name + ' || ' + user_params.chapter + ' || ' + user_params.lesson);
                                                                }
                                                            }
                                            }).catch(function(err){});
                                }catch(err){}
                            }
                        });
                    }
                }
            }
           /** Sem Third Template VideoList Functionalities Starts Here **/
               this.fshowPreview = function(index){
                      $rootScope.goToVideoIndex= index;
                      var coursePreviewDivId = "course_preview_vid-" + currentCourseId;
                      jwplayer(coursePreviewDivId).playlistItem(index);
              //        var _freeVideoViewed = getCookieByName('free_video_viewed');
                      if($rootScope.showPreviewLeadStatus && parseInt(index) > 0 ){
                                  $timeout(function() {
                                                jwplayer().stop()
                                              }, 1000);

                      }
               };
              this.setSemPlaylistParams =function(elearningId,urlStr,videoType,courseId){
                  isMultipleVideoUrl = 1;
                  semCurrElearningId=elearningId;
                  videoUrlStr=urlStr;
                  semVideoType=videoType;
                  currentCourseId = courseId;
                  isSemTemplateThird = true;
              }
            this.fshowPlalistPreview = function(jumpToVideoIndex){
                //console.log("Jump To Playing Video",jumpToVideoIndex);
                var courseType = '';
                var coursePreviewDivId = "course_preview_vid-" + currentCourseId;
                var goToVideoIndex = typeof jumpToVideoIndex !=='undefined' ? parseInt(jumpToVideoIndex) : '';
                $rootScope.goToVideoIndex= goToVideoIndex;
                goToVideoPlayStatus =false;
                var currentVideoIndex=0;
                var videoIndexCounter = 0 ;
                var stopVideoPlay = false;
                if(user_params.course_id) {
                    courseType = 'course';
                } else if(user_params.bundle_id) {
                    courseType = 'bundle';
                }
                videoFinished[currentCourseId] = 0;
                for(var key in showPreviewVid){
                    showPreviewVid[key] = 0;
                }
                var videoEncodedUrl = typeof videoUrlStr !=="undefined" ? videoUrlStr.split(",") :[];
                if(typeof semCurrElearningId != 'undefined' && videoUrlStr!=null && videoUrlStr !=''){
                    var postParams = {'method':'getMultipleVideoUrl','video':videoUrlStr, 'isFromELearning': (semCurrElearningId)?1:0, 'type': 'course','isMultipleVideoUrl': isMultipleVideoUrl };
                    PostReqService.sendPostRequest(baseApiUrlNocache,postParams)
                            .then(function (response) {
                                if(typeof response.data !== 'undefined' && response.data == null){
                                }else if (typeof response.status !== 'undefined' && typeof response.data !== 'undefined' && response.status == '200') {
                                    var resData = response.data;
                                    if(resData.url){
                                        var videoUrlList= resData.url;
                                        for(var key in videoUrlList){
                                            var vUrl = videoUrlList[key];
                                            videoPlayList[key]={"file":decodeURI(vUrl)}
                                        }
                                    }
                                    if(resData && resData.status == "success") {
                                    showPreviewVid[currentCourseId] = 1;
                                    var videoUrl = response.data;
                                    var vUrl = videoUrl.url;
                                    if (semVideoType == 'webcontent') {
                                        sectionIframeSrc[currentCourseId] = $sce.trustAsResourceUrl(vUrl);
                                        showIFrameStatus[currentCourseId] = 1;
                                    } else if (semVideoType == 'mp4') {
                                        videoFinished[currentCourseId] = 0;
                                        jwPlayerObj = jwplayer(coursePreviewDivId).setup({
                                            playlist: videoPlayList,
                                            image: '',
                                            base: staticUrl + 'core/js/jwplayer/',
                                            width: "100%",
                                            aspectratio: "2:1",
                                            startparam: 'start',
                                            fallback: false,
                                            icons: true,
                                            autostart: true,
                                        }).on('complete',function(){
                                               var nextListVideoIndex = jwplayer(coursePreviewDivId).getPlaylistIndex();
                                               if(typeof goToVideoIndex !=="undefined" && parseInt(goToVideoIndex) > 0 && goToVideoIndex < nextListVideoIndex){
                                                   goToVideoIndex= jwplayer(coursePreviewDivId).getPlaylistIndex();
                                               }
                                               if(typeof goToVideoIndex !=="undefined" && parseInt(goToVideoIndex) > 0){
                                                   goToVideoIndex = parseInt(goToVideoIndex) + 1 ;
                                                   if(goToVideoIndex < videoPlayList.length){
                                                       videoIndexCounter = parseInt(goToVideoIndex);
                                                   }else{
                                                       goToVideoIndex = 0;
                                                       videoIndexCounter = 0;
                                                   }
                                               }else{
                                                  var playListVideoIndex = jwplayer(coursePreviewDivId).getPlaylistIndex();
                                                  if(parseInt(playListVideoIndex) < videoPlayList.length){
                                                      videoIndexCounter = parseInt(playListVideoIndex)+1;
                                                  }else{
                                                       videoIndexCounter =0 ;
                                                  }
                                               }
                                                if(goToVideoIndex !=='undefined' && goToVideoIndex !=='' && $rootScope.singlePreviewVideoPlayed === false){
                                                    $rootScope.singlePreviewVideoPlayed =true;
                                                    if(goToVideoIndex){
                                                        var cname = 'free_video_viewed';
                                                        var cvalue = goToVideoIndex;
                                                        var d = new Date();
                                                        d.setTime(d.getTime() + (3600 * 1000 * 24 * 365));
                                                        var expires = "expires=" + d.toUTCString();
                                                        document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/;SameSite=Lax;";
                                                    }
                                                }
                                                if(parseInt(videoIndexCounter)=== 0){
                                                    goToVideoIndex=0;
                                                    $rootScope.goToVideoIndex=0;
                                                }
                                               // console.log("Playing Video",videoIndexCounter);
                                                jwplayer(coursePreviewDivId).playlistItem(videoIndexCounter);
                                        }).onBeforePlay(function(){
                                           //console.log("Current :",jwplayer(coursePreviewDivId).getPlaylistIndex(),goToVideoIndex,$rootScope.singlePreviewVideoPlayed,$rootScope.previewPopupVideoPlayed);
                                           if(goToVideoPlayStatus && $rootScope.goToVideoIndex && $rootScope.singlePreviewVideoPlayed === false){
                                               //console.log("Current Video Index",goToVideoIndex);
                                               if(typeof goToVideoIndex !=="undefined" && goToVideoIndex > 0){
                                                   goToVideoIndex = parseInt(jwplayer(coursePreviewDivId).getPlaylistIndex());
                                               }
                                           }else if(typeof $rootScope.goToVideoIndex !=="undefined"){
                                              goToVideoIndex= parseInt($rootScope.goToVideoIndex);
                                           }
                                           var currentVideoIndex = typeof goToVideoIndex !=="undefined" && parseInt(goToVideoIndex) > 0 ? parseInt(goToVideoIndex) : jwplayer(coursePreviewDivId).getPlaylistIndex();
                                           var semAgendaLeadSubmitted= getCookieByName('_semagenda');
                                           var coursePreviewWatchLead= getCookieByName('_cpwlead');
                                           /*
                                            * 
                                            * Need To Change Here Create Lead
                                            */
                                          // var _cpruidExist = getCookieByName('_cpruid');
                                           var _cpLeadInfoExist = getCookieByName('_user_ld_info');
                                            // console.log(_cpruidExist,coursePreviewWatchLead);
                                           if(typeof semAgendaLeadSubmitted !=="undefined" && parseInt(semAgendaLeadSubmitted) && (typeof coursePreviewWatchLead ==="undefined" || parseInt(coursePreviewWatchLead)===0) && $rootScope.previewPopupVideoPlayed === true && parseInt(currentVideoIndex)){
                                                    $timeout(function () {
                                                        var cname = '_cpwlead';
                                                        var cvalue = 1;
                                                        var d = new Date();
                                                        d.setTime(d.getTime() + (3600 * 1000 * 24 * 365));
                                                        var expires = "expires=" + d.toUTCString();
                                                        var subdomain= '.simplilearn.com';
                                                        document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/;domain="+subdomain+';SameSite=Lax;';
                                                        if ($rootScope.isLoggedIn) {
                                                            self.coursePreviewWatch(0);
                                                        } else {
                                                            self.coursePreviewWatch(1);
                                                        }
                                                        //New Lead Function
                                                        self.submitPreviewLead();
                                                    }, 1000);
                                                    //console.log("Course Preview Lead Created From Top 1: ",$rootScope.isPreviewLeadCreated);
                                            }else if(LeadService.isSkipPopup('course preview') && (typeof coursePreviewWatchLead ==="undefined" || parseInt(coursePreviewWatchLead)===0)  && parseInt(currentVideoIndex)){       
                                            var cname = '_cpwlead';
                                                    var cvalue = 1;
                                                    var d = new Date();
                                                    d.setTime(d.getTime() + (3600 * 1000 * 24 * 365));
                                                    var expires = "expires=" + d.toUTCString();
                                                    var subdomain= '.simplilearn.com';
                                                    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/;domain="+subdomain+';SameSite=Lax;';
                                                    $timeout(function () {
                                                        if ($rootScope.isLoggedIn) {
                                                            self.coursePreviewWatch(0);
                                                        } else {
                                                            self.coursePreviewWatch(1);
                                                        }
                                                        //New Lead Function
                                                        if(!LeadService.getLeadStatus('course preview')){       
                                                            self.submitPreviewLead();
                                                        }
//                                                        }
                                                    }, 1000);
                                                //console.log("Course Preview Lead Created From Top 2: ",$rootScope.isPreviewLeadCreated);
                                            }
                                           if(parseInt(currentVideoIndex) >= videoPlayList.length){
                                               currentVideoIndex =0;
                                               jwplayer(coursePreviewDivId).playlistItem(0);
                                           }
                                            if(currentVideoIndex){
                                                 url = videoEncodedUrl[currentVideoIndex];
                                            }
                                           if(parseInt(currentVideoIndex) && parseInt(currentVideoIndex) < videoPlayList.length){
                                                    var el =document.getElementsByClassName("sem-playlist-video");
                                                    if(el.length){
                                                       for(var i=0;i<el.length;i++){
                                                           el[i].classList.remove("active");
                                                       }
                                                       var currentIndex= jwplayer(coursePreviewDivId).getPlaylistIndex();
                                                       var videoIndex = parseInt(currentIndex) > currentVideoIndex ? currentIndex : currentVideoIndex;
                                                       el[videoIndex].classList.add("active")
                                                       currentVideoIndex = videoIndex;
                                                       if($rootScope.initialFreeVideoUrl && currentVideoIndex){
                                                           var currentVideoUrl = videoEncodedUrl[currentVideoIndex];
                                                           if($rootScope.initialFreeVideoUrl !== currentVideoUrl){
                                                               stopVideoPlay = true;
                                                               if(_cpLeadInfoExist){
                                                                   stopVideoPlay=false;
                                                               }
                                                              // console.log("Not Same Url",$rootScope.initialFreeVideoUrl,currentVideoUrl);
                                                           }
                                                       }
                                                    }
                                            }else{
                                                if(parseInt(currentVideoIndex) === 0){
                                                    var el =document.getElementsByClassName("sem-playlist-video");
                                                    if(el.length){
                                                    for(var i=0;i<el.length;i++){
                                                        el[i].classList.remove("active");
                                                    }
                                                    var identifier = "playlist-elm-"+currentVideoIndex;

                                                      if(!$rootScope.isSemMobile && (!$rootScope.isSemIosDevice && !$rootScope.semTablet)) {
                                                        $timeout(function () {
                                                            document.getElementById(identifier).scrollIntoView(true);
                                                        }, 0);
                                                    }
                                                    el[currentVideoIndex].classList.add("active");

                                                    }
                                                }
                                            }
                                        if (currentVideoIndex > 0 &&  $rootScope.isPreviewLeadCreated != true && $rootScope.showPreviewLeadStatus == false && ($rootScope.previewPopupVideoPlayed === true || $rootScope.singlePreviewVideoPlayed === true )) {
                                                if(user_params.isEuro) {
                                                   var optin = $cookies[user_params.OPTIN_COOKIE];
                                                   var optinSet = typeof optin != 'undefined' ? true:false;
                                                   if(!optinSet){
                                                        $timeout(function() {
                                                            jwplayer(coursePreviewDivId).playlistItem(currentVideoIndex);
                                                            $rootScope.showPreviewLeadStatus = true;
                                                            try{
                                                                jwplayer().stop();
                                                                }
                                                            catch(e){}
                                                        }, 1000);
                                                   }else if(optin == true && $rootScope.isPreviewLeadCreated){
                                                             $rootScope.showPreviewLeadStatus = false;
                                                             self.gaCoursePreviewModelJs.evtFireOnCoursePreviewLead();
                                                             jwplayer(coursePreviewDivId).playlistItem(currentVideoIndex);
                                                    }else{
                                                        //console.log("currentVideoIndex",currentVideoIndex);
                                                        jwplayer(coursePreviewDivId).playlistItem(currentVideoIndex);
                                                    }
                                               }else{
                                                   if(currentVideoIndex){
                                                       $timeout(function() {
                                                           $rootScope.showPreviewLeadStatus = true;
                                                            try{
                                                                jwplayer().stop();
                                                                }
                                                            catch(e){}
                                                    }, 1000);
                                                   }
                                                   // self.gaCoursePreviewModelJs.evtFireOnCoursePreviewLead();
                                               }
                                          }else{
                                              if($rootScope.goToVideoIndex && !goToVideoPlayStatus){
                                                jwplayer(coursePreviewDivId).playlistItem(currentVideoIndex);
                                              }
                                          }

                                        }).on('play',function(){
                                            if($rootScope.goToVideoIndex){
                                                 goToVideoPlayStatus=true;
                                             }
                                            var isFullScreen = jwplayer().getFullscreen();
                                            if($rootScope.showPreviewLeadStatus && (stopVideoPlay || isFullScreen)){
                                               // console.log("Stop Play 1");
                                                $rootScope.showPreviewLeadStatus = true;
                                                document.getElementById("sem-course-preview-lead-form").classList.add("bs-sem-course-preview-lead-form")
                                                $timeout(function() {
                                                            try{
                                                                jwplayer().stop();
                                                            }
                                                            catch(e){}
                                                                //jwplayer().getPlugin("display").hide();
                                                            //jwplayer().resize(500, 500)
                                                    }, 1000);
                                            }
                                            // console.log(goToVideoIndex,$rootScope.goToVideoIndex,$rootScope.initialFreeVideoUrl,videoEncodedUrl[currentVideoIndex],currentVideoIndex);
                                            if(goToVideoIndex !=='undefined' && goToVideoIndex !=='' && $rootScope.singlePreviewVideoPlayed === false && stopVideoPlay === true){
                                                    // console.log("Stop Play 2");
                                                     $timeout(function() {
                                                         $rootScope.singlePreviewVideoPlayed =true;
                                                         $rootScope.showPreviewLeadStatus = true;
                                                         if(goToVideoIndex){
                                                                    var cname = 'free_video_viewed';
                                                                    var cvalue = goToVideoIndex;
                                                                    var d = new Date();
                                                                    d.setTime(d.getTime() + (3600 * 1000 * 24 * 365));
                                                                    var expires = "expires=" + d.toUTCString();
                                                                    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/;SameSite=Lax;";
                                                        }
                                                        try{
                                                            jwplayer().stop();
                                                        }
                                                        catch(e){}
                                                    }, 1000);
                                          }
                                        });
                                        showIFrameStatus[currentCourseId] = 0;
                                    }
                                        self.gaCoursePreviewModelJs.gaFireOnCoursePreviewSuccess();
                                    } else {

                                        /*
                                        // Exceed Popup
                                        self.setExceedPopup(true);
                                        var exceedPopup = document.getElementById('course-preview-restrict');
                                        exceedPopup.style.display = 'block';
                                        */

                                        $timeout(function() {
                                            self.showPreviewLead();
                                        }, 0);
                                    }
                                }
                            });
                }else{

                    self.gaCoursePreviewModelJs.gaFireOnCoursePreviewSuccess();

                    sectionIframeSrc[currentCourseId] = $sce.trustAsResourceUrl(baseLmsUrl + "course/scorm/course-preview/elearningId/"+currElearningId+"/sectionId/" + currSectionId + "/scoId/" + currScoId);
                    showIFrameStatus[currentCourseId] = 1;
                }
                if(LeadService.isSkipPopup('course preview') && parseInt(jumpToVideoIndex)>0) {
                     self.submitPreviewLead();
                }
                return true;
            };
            this.hidePreview = function(){
               showPreviewVid[currentCourseId] = 0;
               $rootScope.isCpClicked = 0;
               sectionIframeSrc[currentCourseId] = '';
               if(typeof jwPlayerObj != 'undefined' && jwPlayerObj != null){
                   jwPlayerObj.stop();
               }
               self.gaCoursePreviewModelJs.evtFireOnCoursePreviewClosed();
               return !(showPreviewVid[currentCourseId] === 0 && $rootScope.isCpClicked !== null && $rootScope.isCpClicked === 0);
            };

            this.getIframeSrc = function(courseId) {
                return sectionIframeSrc[courseId];
            };

            this.getShowPreviewStatus = function(courseId) {
                return showPreviewVid[courseId];
            };

            var gaClassForCoursePreview = function() {

                this.gaFireOnCoursePreviewSuccess = function() {
                    var ga = new gaEventsTracker();
                    var currentPageType = this.gaGetCurrentPageType();
                    ga.gaFireInteractiveEvents('coursepagewatchcoursepreview',user_params.user_id + ' || ' + document.URL + ' || course preview || ' + user_params.course_name + ' || ' + self.chapter + ' || ' + self.lesson);
                    // if(currentPageType == 'generic') {
                    //     ga.gaFireInteractiveEvents('coursepagegenericcoursepreviewsuccess');
                    // } else if(currentPageType == 'classroom') {
                    //         ga.gaFireInteractiveEvents('coursepageclassroomcoursepreviewsuccess');
                    // } else if(currentPageType == 'online') {
                    //     ga.gaFireInteractiveEvents('coursepageonlinecoursepreviewsuccess');
                    // }
                }

                this.gaFireOnCoursePreviewLoggedIn = function() {
                    WebTracking.eventReq.triggerEvent({
                        event_id : "sl_lead_user_submitted_lead_form",
                        event_data: {
                          'sl_lead_type' : 'b2c',
                          'sl_site_module' : 'course preview',
                          'sl_email_opt_in' : true,
                          'sl_sms_opt_in': true,
                          'sl_call_opt_in':true
                        },
                        common : "product",
                        user_attributes: ['sl_lead_type', 'sl_event_time','sl_user_email','sl_user_first_name','sl_user_last_name','sl_user_phone','sl_call_opt_in'],
                        // userAttributesMap: {'sl_event_time' : 'sl_last_lead_creation_date'},
                        // sl_user_attr_no_update:{'sl_event_time' : 'sl_first_lead_creation_date'}
                    });
                    var ga = new gaEventsTracker();
                    var currentPageType = this.gaGetCurrentPageType();
                    ga.gaFireInteractiveEvents('leadcapturecoursepreview',user_params.user_id + ' || ' + document.URL + ' || course preview || ' + user_params.course_name + ' || ' + self.chapter + ' || ' + self.lesson);
                }

                this.evtFireOnCoursePreviewLead = function() {

                    WebTracking.eventReq.triggerEvent({
                        event_id : "sl_lead_module_initiated",
                        event_data: {
                          'sl_lead_button_text' : 'Preview',
                          'sl_lead_type' : 'b2c',
                          'sl_site_module' : 'course preview',
                          // 'sl_preview_chapter' : self.chapter || '',
                          // 'sl_preview_lesson' : self.lesson || '',
                        },
                        common : "product",
                        user_attributes: ['sl_lead_type']
                    });
                    var ga = new gaEventsTracker();
                    ga.gaFireInteractiveEvents('leadformclicked',user_params.user_id + ' || ' + document.URL + ' || course preview || '+user_params.course_name + ' || ' + self.chapter + ' || '+ self.lesson);

                }

                this.evtFireOnCoursePreviewClosed = function() {
                    WebTracking.eventReq.triggerEvent({
                        event_id : "sl_lead_form_closed",
                        event_data: {
                          'sl_lead_button_text' : 'Preview',
                          'sl_lead_type' : 'b2c',
                          'sl_site_module' : 'course preview',
                          // 'sl_preview_chapter' : self.chapter || '',
                          // 'sl_preview_lesson' : self.lesson || '',
                        },
                        common : "product",
                        'user_attributes': ['sl_lead_type']
                    });
                    var ga = new gaEventsTracker();
                    ga.gaFireInteractiveEvents('coursepageclosecoursepreview',user_params.user_id + ' || ' + document.URL + ' || course preview || ' + user_params.course_name + ' || ' + self.chapter + ' || ' + self.lesson);

                }

                this.gaGetCurrentPageType = function() {
                    var path = $location.path();
                    path = path.substr(path.indexOf('/')+1);
                    var returnType = 'generic';
                    if(path == 'ilt') {
                        returnType = 'classroom';
                    } else if (path == 'osl') {
                        returnType = 'online';
                    }
                    return returnType;
                }


            };
            this.gaCoursePreviewModelJs = new gaClassForCoursePreview();

            this.getIFrameDisplayStatus = function(courseId){
                return showIFrameStatus[courseId];
            };

            this.isVideoFinished  = function(courseId){
                return videoFinished[courseId];
            };
            var setCookie = function (cname, cvalue, exdays, path) {
                path = path || "/";
                var d = new Date();
                d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
                var expires = "expires=" + d.toUTCString();
                document.cookie = cname + "=" + cvalue + "; " + expires + ";path=" + path + ";SameSite=Lax;";
            };
            var gaClassForPreviewLead = function () {
                var ga = new gaEventsTracker();
                this.gaFireOnPreviewLead = function (cat, label) {
                    if (typeof label !== 'undefined' && label) {
                        ga.gaFireInteractiveEvents(cat, label);
                    } else {
                        ga.gaFireInteractiveEvents(cat);
                    }
                }
            }
});