angular.module('Simplilearn')
.service('CorporateLeadService', function() {
    var self = this;
    var leadFormStatus = false;
    
    var gaPageTabName = '',
        gaPagePosition = '';
    
    self.setLeadFormStatus = function( pStatus ) {
        leadFormStatus = pStatus;
        if(pStatus) {
            angular.element(document.body).addClass('hide_scroll');
        }
        else {
            angular.element(document.body).removeClass('hide_scroll');            
        }
    };
    
    self.getLeadFormStatus = function() {
        return leadFormStatus;
    };
    
    self.setGaPositionData = function( pTabName, pPosition ) {
        gaPageTabName = pTabName;
        gaPagePosition = pPosition;
    };
    
    self.getGaPageTab = function() {
        return gaPageTabName;
    };
    
    self.getGaPagePosition = function() {
        return gaPagePosition;
    };
});


