angular.module('Simplilearn')
.service('LocService', function($http,$q,$cookies){

    var currentCountry = null,
        countryData = null,
        self = this;
	this.showChangeCountryModalStatus = {'display':'none'};
	this.showCountryList = {'display':'none'};
	this.showCityList = {'display':'none'};

	this.getChangeCountryModalStatus = function(){
		return this.showChangeCountryModalStatus;
	}

	this.setChangeCountryModalStatus = function(statusVal){
		this.showChangeCountryModalStatus.display = statusVal;
	}

	this.changeLocCity = function(cityObj){
		deferred = $q.defer();
		$http({
			method: 'GET',
			url: baseApiUrl,
			params: {cityId:cityObj.id,method:'changeLocation'}
		}).success(function(data){
			if(data.status == "Success"){
				deferred.resolve();
				location.reload();
			}else{
				deferred.reject(error);
			}

		}).error(function(){
			deferred.reject(error);
		});
		return deferred.promise;
	}

    this.getCountryData = function() {
        if( countryData !== null ) {
            var promise = $q.when(countryData);

            return promise;
        }
        else if( typeof countryDataIe !== 'undefined' && countryDataIe !== null && !!countryDataIe ) {
            var promise = $q.when(countryDataIe);
            try {
                countryData = countryDataIe;
                //if cookie is available, set current country
                if ($cookies.locatori9 && (typeof JSON.parse($cookies.locatori9).country_id !== 'undefined') && !!JSON.parse($cookies.locatori9).country_id) {
                    self.setCurrentCountry(null, JSON.parse($cookies.locatori9).country_id);
                }
            } catch (e) {
                console.error("SL:Error getCountryData", e)
            }

            return promise;
        }
        else {
            var promise = $http.get(CountryDataJsonUrl)
            .then(function (response) {
                countryData = response.data;
                //if cookie is available, set current country
                if( (typeof JSON.parse($cookies.locatori9).country_id !== undefined) && !!JSON.parse($cookies.locatori9).country_id ) {
                    self.setCurrentCountry( null, JSON.parse($cookies.locatori9).country_id );
                }

                return response.data;
            });

            return promise;
        }
    };

    this.getAppCountryData = function() {
        return countryData;
    };

    this.setCurrentCountry = function(pCountry, pCountryId) {
        //if country object is null, set country from country data
        if( pCountry === null ) {
            for(var cntry_index=0;cntry_index<countryData.length;cntry_index++) {
                if( countryData[cntry_index].id == pCountryId ) {
                    self.setCurrentCountry(countryData[cntry_index], null);
                }
            }
        }
        else {
            currentCountry = pCountry;
        }

        return true;
    };

    this.getCurrentCountry = function() {
        return currentCountry;
    };
});

