angular.module('Simplilearn')
        .service('LoginService', function ($http, $rootScope,HashLogicService,PostReqService) {

            this.login = function (pUserName, pPwd) {

                var hash = HashLogicService.hashLogic(pPwd);
                var loginData = {method:'authenticateUser',email: pUserName, hash: hash, formSource: 0, pdpCoursePreview: 0};

                var promise = PostReqService.sendPostRequest(baseApiUrlNocache,loginData)
                        .then(
                                function(response) {        //success
                                    if (response == null) {
                                        $rootScope.gaHeaderControllerJs.gaFireOnLoginSignupFailure('email | error with connection');
                                        return {};
                                    }
                                    return response;
                                }
                        );

                return promise;
            };
        }).service('HashLogicService', function () {
                this.hashLogic = function (pPwd) {
                    var skey = "kqwcomnrAelIlpmIsplytxzojydfgh";
                    var uncoded = pPwd;
                    var cphr = [];
                    var chr;
                    for (var i = 0; i <= uncoded.length - 1; i++) {
                        chr = uncoded.charCodeAt(i);
                        cphr.push(chr ^ skey.charCodeAt(i));        //xor
                    }

                    return cphr.join(',');
                }
});




