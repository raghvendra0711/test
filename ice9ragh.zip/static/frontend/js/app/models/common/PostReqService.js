angular.module('Simplilearn')
.service('PostReqService', function($http,AMBASSADORENABLE, $rootScope) {
   var self = this;
   this.QUERY_TYPE_ATP = 'ATP';
   this.QUERY_TYPE_B2C = 'B2C';
   this.QUERY_TYPE_B2C_GROUP = 'B2C Groups';
   this.QUERY_TYPE_HIGHER_EDUCATION='Higher Education';
   this.TYPE_GOVERNMENT = 'Government';
   this.BU_IND = 'IN';
   this.BU_ROW  = 'ROW';
   this.BU_US = 'US';
   this.BU_ATP  = 'PARTNER';
   this.BU_B2C = 'B2C';
   this.LEAD_TYPE_B2B = 'B2B';
   this.LEAD_TYPE_B2C = 'B2C';
   this.RECORD_TYPE_B2B = 'B2B';
   this.RECORD_TYPE_SL_GLOBAL ='Simplilearn Global';
   if(typeof window.initGetHashUser == "undefined") window.initGetHashUser = false;
   this.sendPostRequest = function(url,params,contentType){
       if(typeof(url)!== "undefined"){
       var isLeadApi = typeof(leadApiGatewayEndpoint)!=="undefined" && (url == leadApiGatewayEndpoint)?true:false;
       var isQueryString=verifyIfQueryString(url);
       var result=appendMethodToUrl(url,params,isQueryString);
       if(result.methodExist===false && result.url){
           url=result.url;
       }
       if(isLeadApi && user_params.isEuro) {
           setCookie(user_params.OPTIN_COOKIE, 1, 90);
       }
       if(AMBASSADORENABLE == 1){
           if(typeof mbsyshortCode !='undefined' && mbsyshortCode!='' && mbsyshortCode){
               params.mbsy_short_code = mbsyshortCode;
           }
        }
        if(typeof contentType !== "undefined" && contentType == "json"){
            var p = [];
            var config = {
                   headers: {
                       'Content-Type': 'application/json;'
                   },
               };
            for (var key in params) {
                p.push(key + '=' + encodeURIComponent(params[key]));
            }
            var data = JSON.stringify(params);
            if(url.indexOf("?") != -1)
                url += "&rnd=" + new Date().getTime()
            else
                url += "?rnd=" + new Date().getTime()

        }else{
            var p = [];
            var config = {
               headers: {
                   'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
               },
               withCredentials: true
            };
            for (var key in params) {
            p.push(key + '=' + encodeURIComponent(params[key]));
            }
            var data = p.join('&');
        }

        if(isLeadApi) window._lead_response = { status: 'init' };
        var promise = $http.post(url,data,config).then(function(response){
            if(isLeadApi) window._lead_response = response;
           return response;
        },function(e){
            if(isLeadApi) window._lead_response = { status: 'failed', error: e };
            return null;
        });

       return promise;
   }
  }

   this.sendGetRequest = function(url,params){

       if(AMBASSADORENABLE == 1){
           if(typeof mbsyshortCode !='undefined' && mbsyshortCode!='' && mbsyshortCode){
               params.mbsy_short_code = mbsyshortCode;
           }
        }
        var p = [];
        var config = {
               headers: {
                   'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
               }
           };
           var data = '';
        for (var key in params) {
            p.push(key + '=' + encodeURIComponent(params[key]));
            data += key + '/' + encodeURIComponent(params[key]) + '/';
        }
        // var data = p.join('&');
       var promise = $http.get(url+'/'+data,config).then(function(response){
           return response;
       },function(){
           return null;
       });

       return promise;
   }
   
var setCookie = function(cname, cvalue, exdays, path) {
        path = path || "/";
        var d = new Date();
        d.setTime(d.getTime() + (exdays*24*60*60*1000));
        var expires = "expires="+ d.toUTCString();
        document.cookie = cname + "=" + cvalue + "; " + expires +";path="+path+";SameSite=Lax;";
    }

    function parseUser(userInfo, source) {
        userInfo.name = userInfo.name || userInfo.firstname || userInfo.username || '';
        if(userInfo.phone) {
            var phoneData = userInfo.phone.split('-');
            if(phoneData[1]) {
                userInfo.phoneCode = phoneData[0];
                userInfo.phone = phoneData[1];
            }
        }
        /*
        if($rootScope.isLoggedIn) {
            userInfo.source = 'logged_in_user';
        } else {
            if(typeof source != 'undefined') {
                userInfo.source = source;
            }
        }
        */
        if (typeof source != 'undefined') {
            userInfo.source = source;
        } else if ($rootScope.isLoggedIn) {
            userInfo.source = 'logged_in_user';
        } else {
            userInfo.source = 'other';
        }
        if(typeof userInfo.name === "string" && userInfo.name) {
            userInfo.firstname = userInfo.name.match(/^[^ ]+/)[0] || '';
            userInfo.lastname = (userInfo.name.match(/ .+/) || [''])[0].trim();
        }
        if (typeof userInfo.name === "string"){
            userInfo.name = userInfo.name.replace(/undefined/ig,'').trim();
        }
        if (typeof userInfo.firstname === "string"){          
            userInfo.firstname = userInfo.firstname.replace(/undefined/ig,'').trim();
        }
        if (typeof userInfo.lastname === "string"){
            userInfo.lastname  = userInfo.lastname .replace(/undefined/ig,'').trim();
            if(userInfo.lastname.includes("@")){
                userInfo.lastname ='';
                userInfo.name = userInfo.firstname;
            }
            
        }

        return userInfo;
    }
    function isEmpty(obj) {
                if (!obj)
                    return false;
                for (var key in obj) {
                    if (obj.hasOwnProperty(key))
                        return false;
                }
                return true;
            }
    function mergeObjects(obj1, obj2) {
        obj1 = isEmpty(obj1) ? {} : obj1;
        obj2 = isEmpty(obj2) ? {} : obj2;
        let merged = obj1;
        Object.keys(obj2).forEach(function (key) {
             merged[key] = obj2[key];
         });
        return merged;
    }
    
    function cloneObject(obj) {
        return JSON.parse(JSON.stringify(obj));
    }
    
    function setUserInfo(userInfo) {
            window._userInfo = cloneObject(userInfo);
            $rootScope.userInfo = cloneObject(userInfo);
    }
     function getActiveUser() { 
        if (!$rootScope.auh) {
            $rootScope.auh = getHashByKey('auh') || getParameterByName("auh");
        }
        var auh = $rootScope.auh;
        if (!window._userInfo && !$rootScope.isLoggedIn && !auh) {
            window._userInfo = getActiveWeUser();
        } else if (window._userInfo) {
            let weUser = getActiveWeUser() || {};
            if (weUser.email && (window._userInfo.email === weUser.email)) {
                window._userInfo = window._userInfo;
                window._userInfo = mergeObjects(weUser, window._userInfo);
            }
        }
        if (typeof setAuh === "function")
            setAuh(window._userInfo);
        return window._userInfo || null;
        
    }

    /**
     * Get user info by auh or loggedin
     */
    function getUserInfo(hash) {
        return new Promise(function (resolve, reject) {
            var paramsArr = {'method': 'getUserInfo'};
            if (typeof hash === "string" && hash.length !== 0) {
                paramsArr.auh = hash;
            }
            if (typeof paramsArr.auh === "undefined" && !$rootScope.isLoggedIn) {
                reject(new Error("invalid params"));
                return;
            }
            self.sendPostRequest(baseApiUrlNocache, paramsArr).then(function (res) {
                var data = (typeof res == "object" && typeof res.data == "object" && typeof res.data.data !== "undefined") ? res.data.data : {};
                resolve(data)
            }).catch(reject);
        });
    }
    
//    this.initUserLoadEvent = function() {
//        this.getHashUser(function(user) {
//           // create event
//                    var event = new CustomEvent("loadUser", {
//                            detail: user
//                    });
//           // trigger event
//           window.dispatchEvent(event,user);
//        });
//    }
   this.getHashUser = function(callback) {
        if(getActiveUser()) {
            callback(getActiveUser());
            return;
        }
        if (!window.initGetHashUser) {
            window.initGetHashUser = true;
            getHashUserAction(function (userInfo) {
                setUserInfo(userInfo);
                window.dispatchEvent(new CustomEvent('onLoadUserInfo', { detail: userInfo }))
            })
        }
        let postAction = function(event) {
            window.removeEventListener("onLoadUserInfo", postAction);
            callback(getActiveUser());
        }
        window.addEventListener("onLoadUserInfo", postAction);
    }
    
    /**
     * Main user info fetching logic
     * Priority auh > loggedin > webengage
     * @param {function} callback
     */
   function getHashUserAction(callback) {
//    function getHashUserAction(callback) {
        $rootScope.userInfo = {};
        var postAction = function (data) {
            if(data && typeof data.phoneCode !=="undefined" && data.phoneCode){
              data.phoneCode=self.formatUserPhoneCode(data.phoneCode);
            }
            setUserInfo(data);
            self.updateSlGlobalData(data);
            callback(data);
            return;
        }
        $rootScope.userInfo =getActiveUser();
                if ($rootScope.userInfo) {
                    postAction($rootScope.userInfo)
                    return;
                };
        var source = null;
        $rootScope.userInfo = null;
        if(!$rootScope.auh){
            $rootScope.auh = getHashByKey('auh') || getParameterByName("auh");
        }
        var auh = $rootScope.auh? $rootScope.auh :null ;
        if(typeof auh != 'undefined' && auh != null) {
            var data = atob(auh).split(',');
            var mail_add = data[0].trim();
            var phone = (typeof data[1] !== "undefined" && data[1])?data[1]:'';
            if(typeof mail_add != 'undefined' && mail_add != null) {
                var userInfo = {email : mail_add};
                if(phone) {
                    userInfo.phone = phone;
                }
                source = 'url_hash';
                var userData = parseUser(userInfo, source);
                if(typeof userData.email_subscription_status === "undefined")  {
                    userData.email_subscription_status = null;
                }
                if(typeof userData.email_subscription_status === "undefined")  {
                    userData.email_dnc_status = null;
                }
                getUserInfo(auh).then(function(userInfo) {
                    if(typeof userInfo.email_subscription_status !== "undefined") {
                        userData.email_subscription_status = userInfo.email_subscription_status;
                    }
                    if(typeof userInfo.email_dnc_status !== "undefined") {
                        userData.email_dnc_status = userInfo.email_dnc_status;
                    }
                    $rootScope.userInfo = userData;
                    postAction($rootScope.userInfo);
                });
                return;
            } else {
                $rootScope.userInfo = {};
            }
        } else {
            $rootScope.userInfo = {};
        }

        if($rootScope.userInfo && $rootScope.userInfo.email) {
            postAction($rootScope.userInfo);
            return;
        }

        if($rootScope.isLoggedIn) {
            var paramsArr = {
                 'method': 'getUserInfo',
                 "courseUri": (typeof courseUri != 'undefined') ? courseUri : '',
                 "courseId": (typeof courseId != 'undefined') ? courseId : '',
                 "bundleId": (typeof bundleId != 'undefined') ? bundleId : '',
            };
            self.sendPostRequest(baseApiUrlNocache, paramsArr).then(function (data) {
                if (typeof data.data != 'undefined'){
                    var resData = data && data.data;
                    if(resData && resData.status == 'success' && resData.data && resData.data.email) {
                        var userInfo = resData.data;
                        $rootScope.userInfo = parseUser(userInfo);
                        postAction($rootScope.userInfo);
                    } else {
                        $rootScope.userInfo = {};
                        postAction(null);
                    }
                }   else {
                        $rootScope.userInfo = {};
                        postAction(null);
                    }
            });
            return;
        }

        if (typeof webengage != 'undefined' && (typeof webengage.onReady === "function")) {
            webengage.onReady(function() {
                var weUserData = null;
                if(!$rootScope.auh){
                    $rootScope.auh = getHashByKey('auh') || getParameterByName("auh");
                }
                var auh = $rootScope.auh;
                if(typeof webengage.state != 'undefined') {
                    weUserData = webengage.state.getForever();
                }
                
                if (typeof weUserData != 'undefined' && weUserData && typeof weUserData['cuid'] != 'undefined') {
                    var userInfo = {email: weUserData['cuid']};
                    var userAttrs = weUserData['uattr'];
                    if (typeof userAttrs[WebTracking.userAttributesMap.sl_user_first_name] != 'undefined')
                        userInfo['name'] = userAttrs[WebTracking.userAttributesMap.sl_user_first_name];
                    if (typeof userAttrs[WebTracking.userAttributesMap.sl_user_last_name] != 'undefined')
                        userInfo['name'] = userInfo['name'] + ' ' + userAttrs[WebTracking.userAttributesMap.sl_user_last_name];
                    if (typeof userAttrs[WebTracking.userAttributesMap.sl_user_phone] != 'undefined') {
                        userInfo['phone'] = userAttrs[WebTracking.userAttributesMap.sl_user_phone];
                        var wePhone = userInfo['phone'];
                    }
                    if (typeof userAttrs[WebTracking.userAttributesMap.sl_user_email] != 'undefined') {
                        userInfo['email'] = userAttrs[WebTracking.userAttributesMap.sl_user_email];
                        var weEmail = userInfo['email'];
                    }                   
                    source = 'webengage';
                    if(!auh && !$rootScope.isLoggedIn){
                    var paramsArr = {
                        'method': 'getUserInfo',
                        "weEmail" : (typeof weEmail != 'undefined') ? weEmail : '',
                        "wePhone": (typeof wePhone != 'undefined') ? wePhone : '',
                        
                };                 
                self.sendPostRequest(baseApiUrlNocache, paramsArr).then(function (data) {
                if (typeof data.data != 'undefined'){
                    var resData = data && data.data;
                    if(resData && resData.status == 'success' && resData.data && resData.data.email) {
                        var userInfo = resData.data;
                        $rootScope.userInfo = parseUser(userInfo);
                        postAction($rootScope.userInfo);
                    } else {
                        $rootScope.userInfo = {};
                        postAction(null);
                    }
                }   else {
                        $rootScope.userInfo = {};
                        postAction(null);
                    }
            });  
        }
                } else {
                    $rootScope.userInfo = {};
                    postAction(null);
                }
            });
        } else {
            $rootScope.userInfo = {};
            postAction(null);
        }
    }

 function getActiveWeUser() {
        var userInfo = null;
        try {
            if (typeof webengage != 'undefined' && typeof webengage.state != 'undefined') {
            if(typeof webengage.state.getForever === "function" &&
                webengage.state.getForever() &&
                webengage.state.getForever().uattr){
            if (webengage.state.getForever().uattr.we_email) {
                let userAttrs = webengage.state.getForever().uattr;  
//                if(userAttrs.we_email){
                userInfo = { email: userAttrs.we_email || '' };
                if (typeof userAttrs[WebTracking.userAttributesMap.sl_user_first_name] != 'undefined')
                    userInfo['name'] = userAttrs[WebTracking.userAttributesMap.sl_user_first_name];
                userInfo['first_name'] = userInfo['name'];
                if (typeof userAttrs[WebTracking.userAttributesMap.sl_user_last_name] != 'undefined')
                    userInfo['last_name'] = userAttrs[WebTracking.userAttributesMap.sl_user_last_name];
                userInfo['name'] = userInfo['name'] + ' ' + userInfo['last_name'];
                if (typeof userAttrs[WebTracking.userAttributesMap.sl_user_phone] != 'undefined') {
                    userInfo['phone'] = userAttrs[WebTracking.userAttributesMap.sl_user_phone];
                }
                let source = 'webengage';
                userInfo = parseUser(userInfo, source);
//            }
             }
           }
         }
        } catch (e) {
            console.error("SL:Error getActiveWeUser", e);
        }
        if(!$rootScope.userInfo) {
            $rootScope.userInfo = userInfo;
        }
        return userInfo;
    }


    this.getUserData = function(callback) {
        $rootScope.userInfo = {};

        if($rootScope.isLoggedIn) {
            var paramsArr = {
                 'method': 'getUserData',
            };
            this.sendPostRequest(baseApiUrlNocache, paramsArr).then(function (data) {
                var resData = data && data.data;
                if(resData && resData.status == 'success' && resData.data && resData.data.email) {
                    var userInfo = resData.data;
                    $rootScope.userInfo = parseUser(userInfo);
                    callback($rootScope.userInfo);
                } else {
                    $rootScope.userInfo = {};
                    callback(null);
                }
            });
            return;
        }

        return;
    }

    /**
     * Generate hash for user
     */
    this.setUserHash = function(user) {
        if(user && user.email) {
            user.email = user.email;
            $rootScope.userInfo = user;
            self.updateSlGlobalData(user);
        }
    }

    this.updateSlGlobalData = function(user) {
        if(typeof user != 'undefined' && user) {
            var keys = ['name', 'email', 'phone', 'phoneCode'];
            keys.forEach(function(key) {
                if(typeof user[key] != 'undefined' && user[key]) {
                    setSlGlobalData(key, user[key]);
                }
            });
        }
    }

    /**
     * Has free trial check
     */
    this.initFreeTrialCookie = function() {
        try {
            if ($rootScope.isLoggedIn || getCookieByName(user_params.ssoCookieName)) {
                var paramsArr = {method: 'hasFreeTrial'};
                this.sendPostRequest(baseApiUrlNocache, paramsArr).then(function (data) {
                    var response = data.data;
                    if (response.status == 1 && response.data && response.data.hasFreeTrial == 1 && response.data.courses != '') {
                        var courses = response.data.courses;
                        setFreeTrialCookie(courses);
                    } else {
                        setFreeTrialCookie('');
                    }
                });
            }
        } catch(e) {
            console.error("Free trial check failed.");
        }
    }

    var setFreeTrialCookie = function(value) {
        var date = new Date();
        date.setTime(date.getTime() + (90 * 24 * 60 * 60 * 1000));
        document.cookie = user_params.ftCookieName +'='+value+'; expires=' + date.toGMTString() + '; path=/;domain=.simplilearn.com;SameSite=Lax;';
    }

    var verifyIfQueryString = function (url) {
        var isQueryString = false;
        //Check If Url Is A Query String
        if (typeof url != 'undefined' && url.indexOf("?") !== -1) {
            isQueryString = true;
        }
        return isQueryString;
    }
    var appendMethodToUrl = function (url, params, isQueryString) {
        var methodExist = false;
        var response = {'methodExist': false, 'url': url};
        if (url && params) {
            //check if method exist in the url
            if (isQueryString) {
                if (url.indexOf("method") !== -1) {
                    methodExist = response['methodExist'] = true;
                }
            }
            if (methodExist === false) {
                if (params.method) {
                    var methodName = params.method;
                    var baseApiUrl = baseApiUrlNocache + '?method=' + methodName;
                    response['url'] = baseApiUrl;
                }
            }
        }
        return response;
    }
    this.prepareB2CLeadParameters =function(leadParams,webEngageLeadFormParams){
        var eventTime=webEngageLeadFormParams['sl_event_time'];
        var siteModule=webEngageLeadFormParams['sl_site_module'];
        var slLeadType=webEngageLeadFormParams['sl_lead_type'];
        var slProductTraining=webEngageLeadFormParams['sl_product_training_type'];
        var slTrainingTypeStr=getLeadTrainingType(slProductTraining);
        var slProductId=webEngageLeadFormParams['sl_product_id'];
        var personEmailId = typeof leadParams.personEmail !=="undefined" ? leadParams.personEmail : webEngageLeadFormParams['sl_user_email'];
        var personName= typeof leadParams.personName !=="undefined" ? leadParams.personName : '';
        var personPhone = typeof leadParams.personPhone !=="undefined" ? leadParams.personPhone : webEngageLeadFormParams['sl_user_phone'];
        var autoLead = typeof leadParams.autoLead !=="undefined" ? leadParams.autoLead : 0;
        var inputData = {
                    name:personName,
                    email: personEmailId,
                    phone: personPhone,
                    phoneCode: leadParams.queryPhoneCode
        };
        var prefilInfo = getPrefilledInfo(inputData, $rootScope.userInfo);
        var locatorInfo = getCookieByName('locatori9')
        var locatorData= JSON.parse(locatorInfo);
        var cdnCtry= (typeof locatorData.cdnCountry!=='undefined' && locatorData.cdnCountry)  ? locatorData.cdnCountry :'US';
        var leadSourceString=typeof leadParams.leadSourceString !=="undefined" ? leadParams.leadSourceString  : document.URL;
        var countryId=typeof leadParams.cookie_data !=="undefined" && typeof leadParams.cookie_data.country_id !=="undefined" ? leadParams.cookie_data.country_id :leadParams.countryId;
        var countryName =typeof leadParams.cookie_country_name !=="undefined" ? leadParams.cookie_country_name :leadParams.countryName;
        if(countryName){
             countryName=countryName.replace(/\+/g, ' ');
        }
        var cityId=typeof leadParams.cookie_data !=="undefined" && typeof leadParams.cookie_data.city_id  !=="undefined" ? leadParams.cookie_data.city_id : leadParams.cityId;
        var cityName=typeof leadParams.cookie_data!=="undefined" && typeof leadParams.cookie_data.name !=="undefined" ? leadParams.cookie_data.name :leadParams.cityName;
        if(cityName){
              cityName=cityName.replace(/\+/g, ' ');
        }
        var userMessage=typeof leadParams.sl_user_message !=="undefined" ?  leadParams.sl_user_message:'';
        var leadTrainingType=typeof leadParams.leadTrainingType !=="undefined" ? leadParams.leadTrainingType: 'Not Sure';
        var lastCookieSource=getCookieOrigin();
        var type=leadParams.b2cQueryType;
        var productTypeId=typeof leadParams.productTypeId !=="undefined" ? leadParams.productTypeId :'';
        var billingTypeId=typeof leadParams.billingTypeId !=="undefined" ? leadParams.billingTypeId : '';
        var billingTypeName='One time';
        if(parseInt(billingTypeId) === 2){
            billingTypeName='Subscription';
        }
        var entityId=typeof leadParams.selected_course !=="undefined" ? leadParams.selected_course.id:leadParams.sl_product_id;
        if(!entityId && webEngageLeadFormParams['sl_product_id']){
            entityId=webEngageLeadFormParams['sl_product_id'];
        }
        var regionName=typeof locatorData.region_name !=="undefined" ? locatorData.region_name : '';
        if(!entityId && slProductId){
            entityId=slProductId;
        }
        var regionName= typeof leadParams.region_name !=="undefined"  ? leadParams.region_name : (typeof locatorData.region_name !=="undefined" ? locatorData.region_name : '');
        if(regionName){
            regionName=regionName.replace(/\+/g, ' ');
        }
        var leadUID=typeof leadParams.lead_uid !=="undefined" ? leadParams.lead_uid : generateLeadId(personEmailId);
        var d = new Date();
        var isEuro=user_params.isEuro;
        if(!countryId){
            countryId=locatorData['country_id'];
        }
        var marketoTrackingCookie=getCookieByName('_mkto_trk');
        var microKey= (typeof eventTime != 'undefined') ? 'leadat'+eventTime : '';
        var leadCreatedTime=(typeof eventTime != 'undefined') ? eventTime : '';
        var firstCookieSource = getCookieByName('simplilearn_custom');
        var mbsyShortCode=getCookieByName('mbsy');
        if (!mbsyShortCode) {
            mbsyShortCode = leadParams.mbsy_short_code ? leadParams.mbsy_short_code : '';
        }
        var website = location.protocol+'//'+location.hostname+(location.port ? ':'+location.port: '');
        var userAgentStr = navigator.userAgent;
        var deviceInfo=getDeviceInfo();
        var coldSiteModules=user_params.cold_site_modules;
        var isHotLead=true;
        var leadTeam =typeof leadTeamHot !=="undefined" && leadTeamHot ? leadTeamHot : 'hot';
        if(typeof coldSiteModules !=="undefined" && coldSiteModules){
            if(coldSiteModules.indexOf(siteModule)!=-1 ){
                isHotLead=false;
                leadTeam =typeof leadTeamCold !=="undefined" && leadTeamCold ? leadTeamCold : 'cold';
            }
        }
        if (typeof user_params.sl_override_site_module !== "undefined" && user_params.sl_override_site_module && siteModule == user_params.sl_override_site_module) {
            isHotLead=false;
            leadTeam =typeof leadTeamMql !=="undefined" && leadTeamMql ? leadTeamMql : 'mql';
        }else if (typeof leadParams.isFrs !== "undefined" && leadParams.isFrs && leadParams.actualSiteModule !=="undefined" && leadParams.actualSiteModule !== siteModule) {
            isHotLead=false;
            leadTeam =typeof leadTeamMql !=="undefined" && leadTeamMql ? leadTeamMql : 'mql';
        }
        var optInText="";
        if(isEuro){
            optInText=getGdprOptInText(countryId,siteModule);
        }
        var leadCreationMode='Online';
        if(siteModule == "Tollfree"){
            leadCreationMode='Offline';
        }
        var firstPageLandingTime=getCookieByName('simplilearn_landing_time');
        var formatedFirstPageLandingTime=formatTZDateTime(firstPageLandingTime);
        var campaignData = getCampaignDetails();
        var paramsArr = {
                            'sl_user_country': countryName,
                            'countryId': countryId,
                            'city_id': cityId,
                            'city': cityName,
                            'sl_user_message': userMessage,
                            'sl_lead_user_message': userMessage,
                            'lead_training_type': leadTrainingType,
                            'lead_source_string': leadSourceString,
                            'last_cookie_source':lastCookieSource,
                            'type': type,
                            'product_type_id': productTypeId,
                            'billing_type_id': billingTypeId,
                            'billing_type_name':billingTypeName,
                            'first_cookie_source':typeof firstCookieSource !=="undefined" ? firstCookieSource : "",
                            'user_agent':userAgentStr,
                            'Browser':typeof userAgentStr !=="undefined" ? userAgentStr : "",
                            'crt_lead_time':leadCreatedTime,
                            'cookie':typeof marketoTrackingCookie !=="undefined" ? marketoTrackingCookie :"",
                            'first_page':getCookieByName('simplilearn_first_page'),
                            'first_page_time':formatedFirstPageLandingTime,
                            "optInText" : optInText,
                            "mbsy_short_code" : typeof mbsyShortCode !=="undefined" ? mbsyShortCode : "",
                            'GCLID': getGCLID(),
                            'lead_uid' :leadUID ,
                            'microKey':microKey,
                            'entity_id':entityId,
                            'sl_user_state':regionName,
                            'prefilled_source':(!leadParams['is_refer_and_earn'])? prefilInfo.prefilled_source:'other',
                            'prefillled_data': (!leadParams['is_refer_and_earn'])? prefilInfo.prefillled_data:1,
                            'prefilled_modified':(!!leadParams['is_refer_and_earn'])?prefilInfo.prefilled_modified:1,
                            'Website':website,
                            'device_type':deviceInfo.deviceType,
                            'device_os':deviceInfo.browserOs,
                            'device_name':deviceInfo.deviceName,
                            'Operating_System':deviceInfo.browserOs,
                            'isHotLead':isHotLead,
                            'lead_creation_mode':leadCreationMode,
                            'cdnCountry':cdnCtry,
                            'Entry_Page':leadSourceString,
                            'queryType':typeof slLeadType !=="undefined" ? slLeadType : 'b2c',
                            'recordType':'B2C',
                            'bu_type':'B2C',
                            'team':'marketing',
                            'lead_stage':'New',
                            'lead_status':'Sales Rep Needs To Call/Email',
                            'leadsource' : "SL-Website",
                            'Created_By_Email':'marketinglead@simplilearn.com',
                            'trainingType':slTrainingTypeStr,
                            'lead_team':leadTeam,
                            'auto_lead' : autoLead,
                            'campaign_source':campaignData.campaign_source||'',
                            'campaign_source_id':campaignData.campaign_source_id||'',
                            'mkwid':campaignData.mkwid||'',
                            'sl_call_opt_in':true
                            };
            if(leadParams.lead_creation_time){
                paramsArr['lead_creation_time']=leadParams.lead_creation_time;
            }
            var finalListOfParam={};
            if(webEngageLeadFormParams['sl_user_last_name']){
                var slUserLastName=webEngageLeadFormParams['sl_user_last_name'];
                webEngageLeadFormParams['sl_user_last_name']=slUserLastName.trim();
                webEngageLeadFormParams['sl_user_last_name']  = webEngageLeadFormParams['sl_user_last_name'] .replace(/undefined/ig,'').trim();
                if(webEngageLeadFormParams['sl_user_last_name'].includes("@")) 
                    webEngageLeadFormParams['sl_user_last_name'] ='';
            }
            if(webEngageLeadFormParams['sl_user_first_name']){
                var slUserFirstName=webEngageLeadFormParams['sl_user_first_name'];
                webEngageLeadFormParams['sl_user_first_name']=slUserFirstName.trim();
                webEngageLeadFormParams['sl_user_first_name']  = webEngageLeadFormParams['sl_user_first_name'] .replace(/undefined/ig,'').trim();
                if(webEngageLeadFormParams['sl_user_first_name'].includes("@")) 
                    webEngageLeadFormParams['sl_user_first_name'] ='';
            }
            if(!webEngageLeadFormParams['sl_product_id']) {
                paramsArr['sl_product_id'] = leadParams['sl_product_id'] ? leadParams['sl_product_id'] : '';
            }
            if(!webEngageLeadFormParams['sl_product_name']) {
                paramsArr['sl_product_name'] = leadParams['sl_product_name'] ? leadParams['sl_product_name'] : '';
            }
            var undefinedCheckVars = ['createdByEmail','chatOwnerEmail','alternatePhone','alternateEmail','hiddenTokenChat','cl_assign_flag',
                'sl_utm_src','referrer_name','referrer_email'];
            for (i = 0; i < undefinedCheckVars.length; i++) {
                if (leadParams[undefinedCheckVars[i]]) {
                    paramsArr[undefinedCheckVars[i]] = leadParams[undefinedCheckVars[i]] ? leadParams[undefinedCheckVars[i]] : '';
                }
            }
            if(leadParams['leadsource']) {
                paramsArr['leadsource'] = leadParams['leadsource'] ? leadParams['leadsource'] : paramsArr['leadsource'];
            }
            if(leadParams['address']) {
                paramsArr['address'] = leadParams['address'] ? leadParams['address'] : paramsArr['address'];
            }
            /**
             * If in-case sl user currency is not fetchable from webengage is undefined.
             * then fetch it from locator.
             */
            if ( typeof webEngageLeadFormParams['sl_currency'] == "undefined" || !webEngageLeadFormParams['sl_currency']) {
                paramsArr['sl_currency'] = locatorData.currency_code;
                console.log('inside');
            }
            
            /**
             * If in-case sl user phone is not fetchable from webengage/weUserData is undefined/weUserData wephone is not available
             * then fetch it from logged  rootScope userInfo.
             */
            if (!webEngageLeadFormParams['sl_user_phone']) {
                if (typeof webengage != 'undefined' && typeof webengage.state != 'undefined') {
                    var weUserData = webengage.state.getForever();
                    if (typeof weUserData != 'undefined') {
                        var userAttrs = weUserData['uattr'];
                        if (typeof userAttrs != 'undefined' && userAttrs.we_phone !== 'undefined' && userAttrs.we_phone) {
                            paramsArr['sl_user_phone'] = userAttrs.we_phone;
                        } else {
                            if ($rootScope.userInfo && $rootScope.userInfo.phone && $rootScope.userInfo.source == "logged_in_user") {
                                paramsArr['sl_user_phone'] = $rootScope.userInfo.phone;
                            }
                        }
                    } else {
                        if ($rootScope.userInfo && $rootScope.userInfo.phone && $rootScope.userInfo.source == "logged_in_user") {
                            paramsArr['sl_user_phone'] = $rootScope.userInfo.phone;
                        }
                    }
                }
            }
            for(key in webEngageLeadFormParams){
            if (typeof webEngageLeadFormParams[key] == "object")
                finalListOfParam[key] = JSON.stringify(webEngageLeadFormParams[key]);
            else
                finalListOfParam[key] = webEngageLeadFormParams[key];
            }
            for (var attrname in paramsArr) {
                finalListOfParam[attrname] = paramsArr[attrname];
            }
            finalListOfParam['event_id']="sl_lead_created";
            finalListOfParam['event_name']="Lead created";
            if (!leadParams['is_refer_and_earn']) {
                if (sessionStorage) {
                    finalListOfParam['we_attr_data'] = JSON.parse(sessionStorage.getItem('we_attr_data'));
                    finalListOfParam['we_event_data'] = JSON.parse(sessionStorage.getItem('we_event_data'));
                    sessionStorage.setItem('we_attr_data', JSON.stringify([]));
                    sessionStorage.setItem('we_event_data', JSON.stringify([]));
                }
            } else {
                finalListOfParam['we_attr_data'] = [];
                finalListOfParam['we_event_data'] = [];
            }
            return finalListOfParam;
    };
    this.formatUserPhoneCode = function (phoneCode) {
        var defaultPhoneCode = $rootScope.defaultQueryPhoneCode;
        var formattedPhoneCode = defaultPhoneCode;
        if (phoneCode) {
            var phoneCodePrefix = "+";
            var phoneCodeSuffix = "-";
            try {
                var userPhoneCode = phoneCode.replace(/\D/g, '');
                formattedPhoneCode = phoneCodePrefix + userPhoneCode + phoneCodeSuffix;
            } catch (e) {}
        }
        return formattedPhoneCode;
    };
    this.getSelectedCourseDetailById = function (courseId) {
        var locatorCookie = getCookieByName('locatori9');
        var locatorCookieObj = JSON.parse(locatorCookie);
        var countryId = locatorCookieObj.country_id;
        var paramsArr = {method: 'getCourseDetailsById', courseId: courseId, countryId: countryId};
        var courseDetailsInfo = this.sendPostRequest(baseApiUrlNocache, paramsArr)
                .then(function (data) {
                    var response = data.data;
                    if (response.status == 200 && response.message == 'Success' && response.data) {
                        return response.data;
                    }
                });
        return courseDetailsInfo;
    };
    this.getSelectedCourseDetailByIdChatLead = function (courseId,countryId,productTypeId) {
        if(courseId && courseId==155){
            productTypeId = '5';
        }
        if(typeof productTypeId != 'undefined'&& productTypeId == '1') {
            var paramsArr = {method: 'getCourseDetailsById', courseId: courseId, countryId: countryId};
        }else if(typeof productTypeId != 'undefined'&& productTypeId == '2'){
            var paramsArr = {method: 'getBundleDetailsById', courseId: courseId, countryId: countryId};
        }else if(typeof productTypeId != 'undefined'&& productTypeId == '5'){
            var paramsArr = {method: 'getMasterOfMasterDetailsById', courseId: courseId, countryId: countryId};
        }
        var courseDetailsInfo = this.sendPostRequest(baseApiUrlNocache, paramsArr)
                .then(function (data) {
                    var response = data.data;
                    if (response.status == 200 && response.message == 'Success' && response.data) {
                        return response.data;
                    }
                });
        return courseDetailsInfo;
    };
    this.prepareB2BLeadParameters =function(leadParams,webEngageLeadFormParams){
        var eventTime=webEngageLeadFormParams['sl_event_time'];
        var siteModule=webEngageLeadFormParams['sl_site_module'];
        var slLeadType=webEngageLeadFormParams['sl_lead_type'];
        var slProductTraining=webEngageLeadFormParams['sl_product_training_type'];
        var slTrainingTypeStr=getLeadTrainingType(slProductTraining);
        var slProductId=webEngageLeadFormParams['sl_product_id'];
        var personEmailId = typeof leadParams.personEmail !=="undefined" ? leadParams.personEmail : webEngageLeadFormParams['sl_user_email'];
        var personName= typeof leadParams.personName !=="undefined" ? leadParams.personName : '';
        var personPhone = typeof leadParams.personPhone !=="undefined" ? leadParams.personPhone : webEngageLeadFormParams['sl_user_phone'];
        var autoLead = typeof leadParams.autoLead !=="undefined" ? leadParams.autoLead : 0;
        var inputData = {
                    name:personName,
                    email: personEmailId,
                    phone: personPhone,
                    phoneCode: leadParams.queryPhoneCode
        };
        var prefilInfo = getPrefilledInfo(inputData, $rootScope.userInfo);
        var locatorInfo = getCookieByName('locatori9')
        var locatorData= typeof locatorInfo !="undefined" && locatorInfo ? JSON.parse(locatorInfo): {};
        var cdnCtry= (typeof locatorData.cdnCountry!=='undefined' && locatorData.cdnCountry)  ? locatorData.cdnCountry :'US';
        var leadSourceString=typeof leadParams.leadSourceString !=="undefined" ? leadParams.leadSourceString  : document.URL;
        var countryId=typeof leadParams.cookie_data !=="undefined" && typeof leadParams.cookie_data.country_id !=="undefined" ? leadParams.cookie_data.country_id :leadParams.countryId;
        var countryName =typeof leadParams.cookie_country_name !=="undefined" ? leadParams.cookie_country_name :leadParams.countryName;
        if(countryName){
             countryName=countryName.replace(/\+/g, ' ');
        }
//        var userMessage = "";
//        if (webEngageLeadFormParams['sl_lead_user_message']) {
//            userMessage = typeof webEngageLeadFormParams['sl_lead_user_message'] !== "undefined" ? webEngageLeadFormParams['sl_lead_user_message'] : '';
//        }
        var leadTrainingType=typeof leadParams.leadTrainingType !=="undefined" ? leadParams.leadTrainingType: 'Not Sure';
        var lastCookieSource=getCookieOrigin();
//        var type=(typeof leadParams.b2bQueryType !=="undefined") ? leadParams.b2bQueryType : leadParams.type;
        var productTypeId=typeof leadParams.productTypeId !=="undefined" ? leadParams.productTypeId :'';
//        var billingTypeId=typeof leadParams.billingTypeId !=="undefined" ? leadParams.billingTypeId : '';
//        var billingTypeName='One time';
//        if(parseInt(billingTypeId) === 2){
//            billingTypeName='Subscription';
//        }
        var entityId=typeof leadParams.selected_course !=="undefined" ? leadParams.selected_course.id:leadParams.sl_product_id;
        if(!entityId && webEngageLeadFormParams['sl_product_id']){
            entityId = String(webEngageLeadFormParams['sl_product_id']);
        }
        var regionName=typeof locatorData.region_name !=="undefined" ? locatorData.region_name : '';
        if(!entityId && slProductId){
            entityId= String(slProductId);
        }
        var cityId = typeof leadParams.cookie_data !== "undefined" && typeof leadParams.cookie_data.city_id !== "undefined" ? leadParams.cookie_data.city_id : leadParams.cityId;
        var cityName = typeof leadParams.cookie_data !== "undefined" && typeof leadParams.cookie_data.name !== "undefined" ? leadParams.cookie_data.name : leadParams.cityName;
        var regionName = (typeof leadParams.region_name !== "undefined" && leadParams.region_name) ? leadParams.region_name : '';
        var areEqual = true;
        var couName = locatorData.country_name || '';
        couName = couName.replace(/[^a-zA-Z ]/g, " ");
        if ((typeof countryName !== 'undefined' && typeof couName !== 'undefined')) {
            areEqual = countryName.toUpperCase() === couName.toUpperCase();
        } else {
            areEqual = false;
        }
        if(areEqual) {
            if (!regionName) {
                cityId = (typeof locatorData.city_id !== "undefined" && !cityId) ? locatorData.city_id : cityId;
                cityName = (typeof locatorData.name !== "undefined" && !cityName) ? locatorData.name : cityName;
            }
            countryId=locatorData['country_id'] || '';
        }
        if (!regionName) {
            regionName = typeof locatorData.region_name !== "undefined" ? locatorData.region_name : '';
            if (!areEqual) {
                regionName = '';
            }
        }
        if(typeof countryName=='undefined' || !countryName ){
            cityId = (typeof locatorData.city_id !== "undefined" && !cityId) ? locatorData.city_id : cityId;
            cityName = (typeof locatorData.name !== "undefined" && !cityName) ? locatorData.name : cityName;
            regionName = typeof locatorData.region_name !== "undefined" ? locatorData.region_name : '';
            countryId=locatorData['country_id'] || '';
            countryName = couName;
        }
        if(regionName){
            regionName=regionName.replace(/\+/g, ' ');
        }
        if (cityName) {
            cityName = cityName.replace(/\+/g, ' ');
        }
        var leadUID=typeof leadParams.lead_uid !=="undefined" ? leadParams.lead_uid : generateLeadId(personEmailId);
        var d = new Date();
        var isEuro=user_params.isEuro;
        var marketoTrackingCookie=getCookieByName('_mkto_trk');
        var microKey= (typeof eventTime != 'undefined') ? 'leadat'+eventTime : '';
        var leadCreatedTime=(typeof eventTime != 'undefined') ? eventTime : '';
        var firstCookieSource = getCookieByName('simplilearn_custom');
        var mbsyShortCode=getCookieByName('mbsy');
        var website = location.protocol+'//'+location.hostname+(location.port ? ':'+location.port: '');
        var userAgentStr = navigator.userAgent;
        var deviceInfo=getDeviceInfo();
        var coldSiteModules=user_params.cold_site_modules;
        var isHotLead=true;
        var leadTeam ='hot';
        var optInText="";
        if(isEuro){
            optInText=getGdprOptInText(countryId,siteModule);
        }
        var leadCreationMode='Online';
        if(siteModule == "Tollfree"){
            leadCreationMode='Offline';
        }
        var firstPageLandingTime=getCookieByName('simplilearn_landing_time');
        var formatedFirstPageLandingTime=formatTZDateTime(firstPageLandingTime);

        //Get Record Type
        var queryType = (typeof leadParams['Query_Type__c'] !=="undefined") ? leadParams['Query_Type__c']:'B2B';
        var recordType = self.RECORD_TYPE_B2B;
        var leadStatus = "new";
        var buType = self.getBusinessUnit(countryName,queryType);
        queryType = (typeof leadParams['Query_Type__c'] !=="undefined") ? leadParams['Query_Type__c']: (typeof leadParams['Query_type_name__c'] !=="undefined") ? leadParams['Query_type_name__c'] : "B2B";
//        var UTM_Medium__c ="";
//        if(typeof leadParams['UTM_Medium__c'] !=="undefiend"){
//            UTM_Medium__c = leadParams['UTM_Medium__c'] ;
//        }
//        var UTM_Source__c = "";
//        if (typeof leadParams['UTM_Source__c'] !== "undefiend") {
//            UTM_Source__c = leadParams['UTM_Source__c'];
//        }
//        var Latest_Lead_Source_Detail__c = "";
//        if (typeof leadParams['Latest_Lead_Source_Detail__c'] !== "undefiend") {
//            Latest_Lead_Source_Detail__c = leadParams['Latest_Lead_Source_Detail__c'];
//        }
//        var Latest_Lead_Source__c = "";
//        if (typeof leadParams['Latest_Lead_Source__c'] !== "undefiend") {
//            Latest_Lead_Source__c = leadParams['Latest_Lead_Source__c'];
//        }
        var campaignData = getCampaignDetails();
        var paramsArr = {
                            'sl_user_country': countryName,
                            'countryId': typeof countryId!=='undefined'? countryId:"",
                            'city_id': typeof cityId !=='undefined' ? cityId: "",
                            'city': typeof cityName !=='undefined' ? cityName : "",
//                            'sl_user_message': userMessage,
                            'lead_training_type': leadTrainingType,
                            'lead_source_string': leadSourceString,
                            'last_cookie_source':lastCookieSource,
//                              'type': type,
                            'product_type_id': parseInt(productTypeId),
//                            'billing_type_id': billingTypeId,
//                            'billing_type_name':billingTypeName,
                            'first_cookie_source':typeof firstCookieSource !=="undefined" ? firstCookieSource : "",
                            'user_agent':userAgentStr,
                            'Browser':typeof userAgentStr !=="undefined" ? userAgentStr : "",
                            'crt_lead_time':leadCreatedTime,
                            'cookie':typeof marketoTrackingCookie !=="undefined" ? marketoTrackingCookie :"",
                            'first_page':getCookieByName('simplilearn_first_page'),
                            'first_page_time':formatedFirstPageLandingTime,
                            "optInText" : optInText,
                            "mbsy_short_code" : typeof mbsyShortCode !=="undefined" ? mbsyShortCode : "",
                            'GCLID': getGCLID(),
                            'lead_uid' :leadUID ,
                            'microKey':microKey,
                            'entity_id':entityId,
                            'sl_user_state':regionName,
                            'prefilled_source':prefilInfo.prefilled_source,
                            'prefillled_data': prefilInfo.prefillled_data,
                            'prefilled_modified':prefilInfo.prefilled_modified,
                            'Website':website,
                            'device_type':deviceInfo.deviceType,
                            'device_os':deviceInfo.browserOs,
                            'device_name':deviceInfo.deviceName,
                            'Operating_System':deviceInfo.browserOs,
                            'isHotLead':isHotLead,
                            'lead_creation_mode':leadCreationMode,
                            'cdnCountry':cdnCtry,
                            'Entry_Page':leadSourceString,
                            'queryType': queryType,
                            'recordType':recordType,
                            'bu_type':buType,
                            'team':'marketing',
                            'lead_stage':'New',
                           // 'lead_status':'Sales Rep Needs To Call/Email',
                            'lead_status':leadStatus,
                            'leadsource' : "SL-Website",
                            'Created_By_Email':'marketinglead@simplilearn.com',
                            'trainingType':slTrainingTypeStr,
                            'lead_team':leadTeam,
                            'UTM_Medium__c':GetUTMParams('utmcmd'),
                            'UTM_Source__c':fetchUTMSource(),
                            'Latest_Lead_Source_Detail':GetUTMParams('utmcmd'),
                            'Latest_Lead_Source':GetUTMParams('utmcsr'),
                            'campaign_source':campaignData.campaign_source||'',
                            'campaign_source_id':campaignData.campaign_source_id||'',
                            'mkwid':campaignData.mkwid||'',
                            'auto_lead' : autoLead,
                            'sl_call_opt_in':true
                            };
            if(leadParams.lead_creation_time){
                paramsArr['lead_creation_time']=leadParams.lead_creation_time;
            }
            var finalListOfParam={};
            if(webEngageLeadFormParams['sl_user_last_name']){
                var slUserLastName=webEngageLeadFormParams['sl_user_last_name'];
                webEngageLeadFormParams['sl_user_last_name']=slUserLastName.trim();
                webEngageLeadFormParams['sl_user_last_name']  = webEngageLeadFormParams['sl_user_last_name'] .replace(/undefined/ig,'').trim();
                if(webEngageLeadFormParams['sl_user_last_name'].includes("@")) 
                    webEngageLeadFormParams['sl_user_last_name'] ='';
            }
            if(webEngageLeadFormParams['sl_user_first_name']){
                var slUserFirstName=webEngageLeadFormParams['sl_user_first_name'];
                webEngageLeadFormParams['sl_user_first_name']=slUserFirstName.trim();
                webEngageLeadFormParams['sl_user_first_name']  = webEngageLeadFormParams['sl_user_first_name'] .replace(/undefined/ig,'').trim();
                if(webEngageLeadFormParams['sl_user_first_name'].includes("@")) 
                    webEngageLeadFormParams['sl_user_first_name'] ='';
            }
            if(!webEngageLeadFormParams['sl_product_id']) {
                paramsArr['sl_product_id'] = leadParams['sl_product_id'] ? leadParams['sl_product_id'] : null;
            }
            if(!webEngageLeadFormParams['sl_product_name']) {
                paramsArr['sl_product_name'] = leadParams['sl_product_name'] ? leadParams['sl_product_name'] : '';
            }
            var undefinedCheckVars = ['createdByEmail','chatOwnerEmail','alternatePhone','alternateEmail','hiddenTokenChat','cl_assign_flag',
                'sl_utm_src'];
            for (i = 0; i < undefinedCheckVars.length; i++) {
                if (leadParams[undefinedCheckVars[i]]) {
                    paramsArr[undefinedCheckVars[i]] = leadParams[undefinedCheckVars[i]] ? leadParams[undefinedCheckVars[i]] : '';
                }
            }
            if(leadParams['leadsource']) {
                paramsArr['leadsource'] = leadParams['leadsource'] ? leadParams['leadsource'] : paramsArr['leadsource'];
            }
            if(leadParams['address']) {
                paramsArr['address'] = leadParams['address'] ? leadParams['address'] : paramsArr['address'];
            }
            /**
             * If in-case sl user currency is not fetchable from webengage is undefined.
             * then fetch it from locator.
             */
            if ( typeof webEngageLeadFormParams['sl_currency'] == "undefined" || !webEngageLeadFormParams['sl_currency']) {
                paramsArr['sl_currency'] = locatorData.currency_code;
                console.log('inside');
            }
            
            /**
             * If in-case sl user phone is not fetchable from webengage/weUserData is undefined/weUserData wephone is not available
             * then fetch it from logged  rootScope userInfo.
             */
            if (!webEngageLeadFormParams['sl_user_phone']) {
                if (typeof webengage != 'undefined' && typeof webengage.state != 'undefined') {
                    var weUserData = webengage.state.getForever();
                    if (typeof weUserData != 'undefined') {
                        var userAttrs = weUserData['uattr'];
                        if (typeof userAttrs != 'undefined' && userAttrs.we_phone !== 'undefined' && userAttrs.we_phone) {
                            paramsArr['sl_user_phone'] = userAttrs.we_phone;
                        } else {
                            if ($rootScope.userInfo && $rootScope.userInfo.phone && $rootScope.userInfo.source == "logged_in_user") {
                                paramsArr['sl_user_phone'] = $rootScope.userInfo.phone;
                            }
                        }
                    } else {
                        if ($rootScope.userInfo && $rootScope.userInfo.phone && $rootScope.userInfo.source == "logged_in_user") {
                            paramsArr['sl_user_phone'] = $rootScope.userInfo.phone;
                        }
                    }
                }
            }
            for(key in webEngageLeadFormParams){
            if (typeof webEngageLeadFormParams[key] == "object")
                finalListOfParam[key] = JSON.stringify(webEngageLeadFormParams[key]);
            else
                finalListOfParam[key] = webEngageLeadFormParams[key];
            }
            for (var attrname in paramsArr) {
                finalListOfParam[attrname] = paramsArr[attrname];
            }
            finalListOfParam['event_id']="sl_lead_created";
            finalListOfParam['event_name']="Lead created";
            if(sessionStorage) {
              finalListOfParam['we_attr_data'] = JSON.parse(sessionStorage.getItem('we_attr_data'));
              finalListOfParam['we_event_data'] = JSON.parse(sessionStorage.getItem('we_event_data'));
              sessionStorage.setItem('we_attr_data',JSON.stringify([]));
              sessionStorage.setItem('we_event_data',JSON.stringify([]));
            }
            return finalListOfParam;
    };

    this.getBusinessUnit = function (country, queryType) {
        var usCountry = ["united states", "us", "usa", "canada", "ca", "mexico", "mx"];
        var countryIndia = "india";
        var country =  typeof country !== 'undefined' ? country.toLowerCase():'';
        if (typeof queryType !== "undefined" && ((queryType == this.QUERY_TYPE_ATP) || (queryType.toLowerCase() == (this.TYPE_GOVERNMENT).toLowerCase()) || (queryType.toLowerCase() == (this.QUERY_TYPE_HIGHER_EDUCATION).toLowerCase()))) {
            if ((typeof country == "undefined" || !country) || (usCountry.indexOf(country) > -1)) {
                return self.BU_US;
            } else if (country == countryIndia) {
                return self.BU_IND;
            } else {
                return self.BU_ROW;
            }
        } else if (typeof queryType !== "undefined" && ((queryType.toLowerCase() == (this.BU_B2C).toLowerCase()) || ((queryType.toLowerCase() == (this.QUERY_TYPE_B2C_GROUP).toLowerCase())))) {
            return self.BU_B2C;
        } else if (typeof queryType !== "undefined" && queryType == self.LEAD_TYPE_B2B) {
            if ((typeof country == "undefined" || !country) || (usCountry.indexOf(country) > -1)) {
                return self.BU_US;
            } else if (country == countryIndia) {
                return self.BU_IND;
            } else {
                return self.BU_ROW;
            }
        }
        return queryType;
 };
});
