angular.module('Simplilearn')
        .service('LeadService', function (PostReqService, $rootScope) {
            var self = this;
            var autoLeadDelay = 15; // min
            var leadStatus = {};
            this.autoLeadSiteModule = 'auto repeat lead';
            this.latestAutoLeadCookie = user_params.LATEST_AUTO_LEAD_COOKIE_NAME;
            this.skipPopupCookie = user_params.SKIP_POPUP_COOKIE_NAME;
            this.cookieExpireTime = 168; // 7 days
            
            this.setLeadStatus = function(siteModule, value) {                
                leadStatus[siteModule] = value? true:false;
            };
            this.getLeadStatus = function(siteModule) {
                return leadStatus[siteModule]? true:false;                
            };
            
            this.createLead = function (paramsArr) {
                paramsArr.method = 'saveCallback';
                var promise = PostReqService.sendPostRequest(baseApiUrlNocache, paramsArr)
                        .then(function (response) {
                            return {'response': response, 'status': true};
                        });

                return promise;
            };
            
            this.getLeadEmail = function(email) {
                if(typeof email != 'undefined' && email) {
                    return email;
                }
                if(typeof user_params != 'undefined' && typeof user_params.email != 'undefined' && user_params.email) {
                    return user_params.email;
                }
                if(typeof $rootScope.userInfo != 'undefined' && typeof $rootScope.userInfo.email != 'undefined' && $rootScope.userInfo.email) {
                    return $rootScope.userInfo.email;
                }
                return '';
            }
            
            this.initSkipCookie = function () {
                PostReqService.getHashUser(function (userData) {
                            var isSkip = false;
                    try {
                        
                  if (userData != null) {                           
                  if (userData.email_subscription_status == 1 && userData.email_dnc_status == 0 && userData.email && userData.phone) {
                                    isSkip = true;
                                }
                            }
                      
                    } catch (e) {
                        console.error("SL:Error isSkipPopup", e);
                        isSkip = false;
                    }
                    if (isSkip) {
                                setCookieByName(self.skipPopupCookie, 1, self.cookieExpireTime);
                            } else
                                setCookieByName(self.skipPopupCookie, null, 0);
                });
            }
            this.setSkipPopup = function()
            {
                setCookieByName(self.skipPopupCookie, 1, self.cookieExpireTime);
            }
            this.isSkipPopup = function (siteModule) {
                if(getCookieByName(self.skipPopupCookie)){
                    return true;
                }
                else
                    return false;
            }
            this.setUserLeadCookie = function(course_id,siteModule){
                if(course_id){
                    setCookieByName('_user_ld_info', siteModule, 90);                     
                }
                else
                    setCookieByName('_user_ld_info', null,0);
            }                   
             var isAutoLeadSource = function (lead) {
                var autoLeadId = '';
                var hash = getHashByKey("auh");
                var validateAutoLeadSource = function (leadData) {
                    try {
                        $rootScope.flag = true;
                        if (getParameterByName("auto_lead") != 1 || typeof leadData !== "object" || !leadData.sl_product_id || user_params.isB2b != 0) {
                            return false;
                        }
                        if (typeof leadData.sl_user_email !== "string" || leadData.sl_user_email.trim().length === 0 || typeof leadData.sl_user_phone !== "string" || leadData.sl_user_phone.trim().length === 0) {
                            return false;
                        }
                        var hashData = null;
                        try {
                            hashData = hash?atob(hash):null;
                        } catch (e) {
                            console.warn("SL:Warn isAutoLeadSource - invalid auh", e);
                            hashData = null;
                        }
                        if (!$rootScope.isLoggedIn && (!hashData || typeof hashData !== "string" || hashData.split(",").length < 2)) {
                            return false;
                        }
                        autoLeadId = (leadData.sl_product_type || '') + "_" + leadData.sl_product_id;
                        if (getCookieByName(self.latestAutoLeadCookie) === autoLeadId) {
                            return false;
                        }
                        return true;
                    } catch (e) {
                        console.error("SL:Error isAutoLeadSource", e);
                    }
                    return false;
                }
                return new Promise(function(resolve) {
                    if(!validateAutoLeadSource(lead)) {
                        resolve(false)
                        return;
                    }
                        PostReqService.getHashUser(function(userInfo) {
                        var autoLeadStatus = (userInfo.email_subscription_status == 1 && getCookieByName(self.latestAutoLeadCookie) != autoLeadId && userInfo.email_dnc_status == 0);
                            if(autoLeadStatus) {
                            setCookieByName(self.latestAutoLeadCookie, autoLeadId, self.cookieExpireTime);
                        }
                        resolve(autoLeadStatus);
                    }).catch(function(e) {
                        console.error("SL:Error isAutoLeadSource", e);
                        resolve(false);
                    });
                });
            }

            this.createAutoLead = function (leadData) {
                return new Promise(function (resolve, reject) {
//                        var autoLead = function(user) {
                            PostReqService.getHashUser(function(userData) {
                            var userInfo= {};
                            if(userData !== null && typeof userData== 'object') {
                               if (typeof userData['email'] != 'undefined')
                                  userInfo.email = userData['email'];
                                if (typeof userData.phone != 'undefined' && userData.phone) {
                                    userInfo.user_phone = userData.phone;
                                    if (typeof userData.phoneCode != 'undefined' && userData.phoneCode) {
                                        userInfo.user_phone = "+" + userData.phoneCode.replace(/\+|\-/g, '') + "-" + userInfo.user_phone;
                                    }
                                }
                            
                            }
//                            window.removeEventListener("loadUser", autoLead);
                            setTimeout(function() {
                                try {
                                    
                                    if(typeof $rootScope.userInfo == "object" && $rootScope.userInfo && $rootScope.userInfo.email_subscription_status == 0) {
                                        return;
                                    }
//                                    var user = getActiveWeUser() || {};
                                    var eventData = {};
                                    if(typeof leadData !== "object" || !leadData) {
                                        var locatorCookieObj = {};
                                        try {
                                            var locatorCookie = getCookieByName('locatori9');
                                            locatorCookieObj = JSON.parse(locatorCookie);
                                        } catch(e) {
                                            console.error("SL:Error createAutoLead", e);
                                            locatorCookieObj = {};
                                        }
                                        var lead = {
                                            sl_product_id: user_params.sl_product_id || '',
                                            sl_product_name: user_params.course_name || '',
                                            sl_user_type : 'B2C',
                                            leadTrainingType : 'Not Sure',
                                            leadSourceString : document.URL,
                                            sl_utm_src : fetchUTMSource(),
                                            b2cQueryType : self.autoLeadSiteModule,
                                            productTypeId : user_params.productTypeId || '',
                                            billingTypeId : user_params.billingTypeId || '',
                                            GCLID : getGCLID(),
                                            fetchData : $rootScope.isLoggedIn ? 1 : 0,
                                            countryId : locatorCookieObj.country_id || null,
                                            countryName : (locatorCookieObj.country_name || '').replace(/\+/g, ' '),
                                            cityId : locatorCookieObj.city_id || null,
                                            cityName : locatorCookieObj.name || null,
                                            autoLead : getParameterByName("auto_lead") == 1 ? 1 : 0,
                                        };
                                        eventData.sl_user_email = userInfo.email || '';
//                                        eventData.sl_user_first_name = user.we_first_name || '';
//                                        eventData.sl_user_last_name = user.we_last_name || '';
                                        eventData.sl_user_phone = userInfo.user_phone || '';
                                        eventData.sl_lead_type = 'b2c';
                                        eventData.sl_product_type = user_params.sl_product_type || '';
                                        eventData.sl_site_module = self.autoLeadSiteModule;
                                        eventData.sl_email_opt_in = true;
                                        eventData.sl_sms_opt_in = true;
                                        leadData =  lead;
                                        Object.keys(eventData).forEach(function(key) {
                                            leadData[key] = eventData[key];
                                        });
                                    }
                                    isAutoLeadSource(leadData).then(function (status) {
                                        if(!status){
                                            return;
                                        }
                                        WebTracking.eventReq.triggerEvent({
                                            event_id: "sl_lead_user_lead_created_automatically",
                                            event_data: eventData,
                                            common: "product",
                                            user_attributes: ['sl_event_time'],
                                        });
                                        eventData = WebTracking.eventReq.eventParam.event_data;
                                        leadData = PostReqService.prepareB2CLeadParameters(leadData, eventData);
                                        leadData.lead_creation_time = new Date().getTime() + autoLeadDelay * 60000;
                                        var applicationContentType = "json";
                                        PostReqService.sendPostRequest(leadApiGatewayEndpoint, leadData, applicationContentType).then(function (res) {
                                            resolve(res);
                                        }).catch(function (e) {
                                            console.error("SL:Error createAutoLead", e);
                                            reject(e);
                                        });
                                    }).catch(function (e) {
                                        console.error("SL:Error createAutoLead", e);
                                        reject(e);
                                    });
                                } catch(e) {
                                    console.error("SL:Error createAutoLead", e);
                                    reject(e);
                                }
                            }, 100);
                        });
//                        window.addEventListener("loadUser", autoLead);
                })
            };
            
            // init
            (function() {
                
                self.initSkipCookie();
            })();
        });

