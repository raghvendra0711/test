angular.module('Simplilearn')
        .service('StorageService', function($window) {

            var falseState = false;
            var trueState = true;
            var self = this;

            this.isSupported = function() {
                if (!$window.localStorage) {
                    return falseState;
                }
                return trueState;
            };

            this.setItem = function(key, item) {
                if (self.isSupported()) {
                    if (typeof key !== 'undefined' && key && item) {
                        $window.localStorage.setItem(key, item);
                        return trueState;
                    }

                }
                return falseState;
            };

            this.getItem = function(key) {
                if (self.isSupported()) {
                    if (typeof key !== 'undefined' && key) {
                        var item = $window.localStorage.getItem(key);
                        if (item) {
                            return item;
                        }
                    }
                }

                return falseState;
            };

            this.removeItem = function(key) {
                if (self.getItem(key)) {
                    $window.localStorage.removeItem(key);
                    return trueState;
                }
                return falseState;
            };


        });