angular.module('Simplilearn')
.service('FilterService', function(){
				this.filterValues = null;
				this.setFilterValues = function(params){
					this.filterValues = params;
				}
                                
                                this.getFilterValues = function(){
                                    return this.filterValues;
                                }
				
				this.updateFilter=function(filterName,filterValue,typeVal){
					this.filterArray = null;
					if(typeVal == 'course'){
						this.filterArray = this.filterValues.course;
					}else if(typeVal == 'ebooks'){
						this.filterArray = this.filterValues.ebooks;
					}else if(typeVal == 'tests'){
						this.filterArray = this.filterValues.tests;
					}
					if(filterName == 'category' && this.filterArray.category.indexOf(filterValue)==-1){
						this.filterArray.category.push(filterValue);
					}else if(filterName == 'category' && this.filterArray.category.indexOf(filterValue)!=-1){
						var indexVal = this.filterArray.category.indexOf(filterValue);
						this.filterArray.category.splice(indexVal, 1);
					}
					if(filterName == 'provider' && this.filterArray.provider.indexOf(filterValue)==-1){
						this.filterArray.provider.push(filterValue);
					}else if(filterName == 'provider' && this.filterArray.provider.indexOf(filterValue)!=-1){
						var indexVal = this.filterArray.provider.indexOf(filterValue);
						this.filterArray.provider.splice(indexVal, 1);
					}
					if(filterName == 'courseType' && this.filterArray.courseType.indexOf(filterValue)==-1){
						this.filterArray.courseType.push(filterValue);
					}else if(filterName == 'courseType' && this.filterArray.courseType.indexOf(filterValue)!=-1){
						var indexVal = this.filterArray.courseType.indexOf(filterValue);
						this.filterArray.courseType.splice(indexVal, 1);
					}
					if(filterName == 'courselevel' && this.filterArray.courselevel.indexOf(filterValue)==-1){
						this.filterArray.courselevel.push(filterValue);
					}else if(filterName == 'courselevel' && this.filterArray.courselevel.indexOf(filterValue)!=-1){
						var indexVal = this.filterArray.courselevel.indexOf(filterValue);
						this.filterArray.courselevel.splice(indexVal, 1);
					}
                                        if(filterName == 'learning_options' && this.filterArray.learningOption.indexOf(filterValue)==-1){
						this.filterArray.learningOption.push(filterValue);
					}else if(filterName == 'learning_options' && this.filterArray.learningOption.indexOf(filterValue)!=-1){
						var indexVal = this.filterArray.learningOption.indexOf(filterValue);
						this.filterArray.learningOption.splice(indexVal, 1);
					}
                                        if(filterName == 'offers' && this.filterArray.offer.indexOf(filterValue)==-1){
						this.filterArray.offer.push(filterValue);
					}else if(filterName == 'offers' && this.filterArray.offer.indexOf(filterValue)!=-1){
						var indexVal = this.filterArray.offer.indexOf(filterValue);
						this.filterArray.offer.splice(indexVal, 1);
					}
					if(typeVal == 'course'){
						this.filterValues.course = this.filterArray;
					}else if(typeVal == 'ebooks'){
						this.filterValues.ebooks = this.filterArray;
					}else if(typeVal == 'tests'){
						this.filterValues.tests = this.filterArray;
					}
					return this.filterArray;			
				}
				
				this.filterVisible = function(strobj){
					this.filterValArray = null;
					if(strobj.typeVar == 'course'){
						this.filterValArray = this.filterValues.course;
					}else if(strobj.typeVar == 'ebooks'){
						this.filterValArray = this.filterValues.ebooks;
					}else if(strobj.typeVar == 'tests'){
						this.filterValArray = this.filterValues.tests;
					}
					
					var categoryStatus = false;
					var providerStatus = false;
					var courseTypeStatus = false;
					var courselevelStatus = false;
                                        var learningOptionStatus = false;
                                        var offerStatus = false;
					
					if(this.filterValArray.category.length == 0 && this.filterValArray.provider.length == 0 && this.filterValArray.courseType.length == 0 && this.filterValArray.courselevel.length == 0 && this.filterValArray.learningOption.length == 0 && this.filterValArray.offer.length == 0){
						categoryStatus = true;
						providerStatus = true;
						courseTypeStatus = true;
						courselevelStatus = true;
                                                learningOptionStatus = true;
                                                offerStatus = true;
					}else{
						
						categoryStatus = false;
						providerStatus = false;
						courseTypeStatus = false;
						courselevelStatus = false;
                                                learningOptionStatus = false;
                                                offerStatus = false;
						if(this.filterValArray.category.length > 0){
						
							var categoryVals = this.filterValArray.category;
							for(var i=0;i<categoryVals.length;i++){
								if((strobj.category).indexOf(categoryVals[i])!=-1){
									categoryStatus = true;
									break;
								}
							}
						}else{
							categoryStatus = true;
						}
						
						if(this.filterValArray.provider.length > 0){
							
							var providerVals = this.filterValArray.provider;
							for(var i=0;i<providerVals.length;i++){
								if((strobj.provider).indexOf(providerVals[i])!=-1){
									providerStatus = true;
									break;
								}
							}
						}else{
							providerStatus = true;
						}
						
						if(this.filterValArray.courseType.length > 0){
							
							var courseTypeVals = this.filterValArray.courseType;
							for(var i=0;i<courseTypeVals.length;i++){
								if((strobj.course_type).indexOf(courseTypeVals[i])!=-1){
									courseTypeStatus = true;
									break;
								}
							}
						}else{
							courseTypeStatus = true;
						}
						
						if(this.filterValArray.courselevel.length > 0){
							
							var courselevelVals = this.filterValArray.courselevel;
							for(var i=0;i<courselevelVals.length;i++){
								if((strobj.level).indexOf(courselevelVals[i])!=-1){
									courselevelStatus = true;
									break;
								}
							}
						}else{
							courselevelStatus = true;
						}
                                                
                                                if(this.filterValArray.learningOption.length > 0){
							
							var learningOptionVals = this.filterValArray.learningOption;
							for(var i=0;i<learningOptionVals.length;i++){
								if((strobj.learning_options).indexOf(learningOptionVals[i])!=-1){
									learningOptionStatus = true;
									break;
								}
							}
						}else{
							learningOptionStatus = true;
						}
                                                
                                                if(this.filterValArray.offer.length > 0){
							
							var offerVals = this.filterValArray.offer;
							for(var i=0;i<offerVals.length;i++){
								if((strobj.offer).indexOf(offerVals[i])!=-1){
									offerStatus = true;
									break;
								}
							}
						}else{
							offerStatus = true;
						}
						
					}
					
					return (categoryStatus && providerStatus && courseTypeStatus && courselevelStatus && learningOptionStatus && offerStatus);
					
				}
			});
