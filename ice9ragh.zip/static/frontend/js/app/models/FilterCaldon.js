angular.module('Simplilearn')
.filter('decodeURL', function() {
 return function(input){
   if(input !== undefined ){
     var test =  decodeURIComponent(input);
     return decodeURI(test);
   }
 }
})
.filter('decodeSeoURL', function() {
 return function(input){
   if(input !== undefined ){
     var test =  decodeURIComponent(input);
     var decodedValue =  decodeURI(test);
     var replaceSlash =  decodedValue.replace(/^\//, '');
     return replaceSlash;
   }
 }
})
.filter('rawHtml', ['$sce', function($sce){
  return function(val) {
    return $sce.trustAsHtml(val);
  };
}])
.filter('limitHtml', ['$sce','$filter' ,function($sce,$filter){
  return function(val) {
  	var content = $filter('limitTo')(val,200);
    if (content && content.length == 200) {
      content = content.concat('...');
    }
    return $sce.trustAsHtml(content);
  };
}])
.filter( 'domain', function () {
  return function ( input ) {
    var matches,
        output = "",
        urls = /\w+:\/\/([\w|\.]+)/;

    matches = urls.exec( input );

    if ( matches !== null ) output = matches[1];

    return output;
  };
})
.filter("trustUrl", ['$sce', function ($sce) {
 return function (recordingUrl) {
   return $sce.trustAsResourceUrl(recordingUrl);
 };
}])
.filter('getTweetShareUrl', function () {
            return function (seoUrl) {
                if (seoUrl !== undefined) {
                    // var shareUrl = "http://192.168.1.12/apachedev/git/ice9/frontend/public/" + seoUrl;
                     var shareUrl = frontendCanonicalUrl+ '/'+ seoUrl;
                    var tweetShareUrl = "https://twitter.com/intent/tweet?text=@simplilearn&url=" + shareUrl;
                    return decodeURI(tweetShareUrl);
                }
            }
        })
        .filter('getFbShareUrl', function () {
            return function (seoUrl) {
                if (seoUrl !== undefined) {
                //var shareUrl="http://www.simplilearn.com/how-to-validate-accelerated-mobile-pages-quickly-via-google-article";
                    // var shareUrl = "http://192.168.1.12/apachedev/git/ice9/frontend/public/" + seoUrl;
                     var shareUrl = frontendCanonicalUrl+ '/'+ seoUrl;
                    var fbShareUrl = "https://www.facebook.com/sharer/sharer.php?u=" + shareUrl;
                    return decodeURI(fbShareUrl);
                }
            }
        })
        .filter('getLinkedInShareUrl', function () {
            return function (seoUrl) {
                if (seoUrl !== undefined) {
                    // var shareUrl = "http://192.168.1.12/apachedev/git/ice9/frontend/public/" + seoUrl;
                     var shareUrl = frontendCanonicalUrl+ '/'+ seoUrl;
                    var linkedInShareUrl = "https://www.linkedin.com/shareArticle?mini=true&url=" + decodeURI(shareUrl);
                    return decodeURI(linkedInShareUrl);
                }
            }
        })
