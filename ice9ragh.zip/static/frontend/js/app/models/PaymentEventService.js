angular.module('Simplilearn')
.service('PaymentEventService', function () {
    this.triggerPaymentEvent = function () {
        var eventData = WebTracking.eventReq.getDataFromUserParams(['sl_order_id', 'sl_final_cart_value', 'sl_currency', 'sl_payment_option_chosen', 'sl_cart_items']);
        WebTracking.eventReq.triggerEvent({event_id: "sl_pay_user_chooses_a_payment_option", event_data: eventData});
        var eventData = WebTracking.eventReq.getDataFromUserParams(['sl_order_id', 'sl_final_cart_value', 'sl_currency', 'sl_payment_option_chosen', 'sl_cart_items']);
        WebTracking.eventReq.triggerEvent({event_id: "sl_pay_user_initiates_payment", event_data: eventData});
    };

    this.getItemAttributeByIndex = function(index) {
        var data = {};
        var item = this.getItemDataByIndex(index)
        if(typeof item == 'undefined' || !item) {
            return data;
        }
        if(!Array.isArray(item.cateforyInfo)) {
            var cateforyInfo = []
            item.cateforyInfo = (item.cateforyInfo)?[item.cateforyInfo]:[];
            item.cateforyInfo.forEach(function(category){
                for(var id in category) {
                    cateforyInfo.push({ id: id, name: category[id],})
                };
            })
            item.cateforyInfo = cateforyInfo;
        }
        var mapperItemsToAttribute = {
            'sl_product_id' : 'course_id',
            'sl_product_name' : 'course_name',
            'sl_product_image' : 'image',
            'sl_product_category' : ['primary_label_name', 'category'],
            'sl_product_category_id' : 'primary_label_id',
            'sl_product_category_list' : 'cateforyInfo',
            'sl_product_training_type' : 'to_show_type',
            'sl_product_price_osl' : '',
            'sl_product_price_lvc' : '',
            'sl_product_price_classroom' : '',
            'sl_product_type' : 'productTypeName',
        }
        Object.keys(mapperItemsToAttribute).forEach(function(key) {
            var targetKeys = mapperItemsToAttribute[key];
            if(!Array.isArray(targetKeys)) {
                targetKeys = [targetKeys];
            }
            for(var i in targetKeys) {
                var targetKey = targetKeys[i];
                data[key] = (targetKey && item[targetKey])?item[targetKey]:'';
                if(data[key]) break;
            }
        });
        var key = 'sl_product_price_classroom';
        data['sl_product_training_type'] = 'classroom';
        if(item.trainingType_id == 2) {
            key = 'sl_product_price_osl';
            data['sl_product_training_type'] = 'osl';
        } else if((item.trainingType_id == 9)) {
            key = 'sl_product_price_lvc';
            data['sl_product_training_type'] = 'lvc';
        }
        var productId = data['sl_product_id'];
        if (!data['sl_product_type']) {
            data['sl_product_type'] = 'course';
            if (productId.indexOf('b') > -1) {
                data['sl_product_type'] = 'bundle';
            } else if (productId.indexOf('m') > -1) {
                data['sl_product_type'] = 'mom';
            }
        }
        data['sl_product_id'] = productId.replace('b', '').replace('m',  '');
        data[key] = item.display_total_price || 0;
        for (var key in data) {
            data[key] = WebTracking.eventReq.setType(data[key]);
        }
        return data;

    },
    this.getItemDataByIndex = function(index) {
        var items = user_params.sl_cart_items || [];
        return (typeof items[index] != 'undefined')?items[index]:{};
        /*for(var i in items) {
            var item = items[i];
            if(item.course_id == id) {
                return item;
            }
        }
        return {};*/
    }
    this.getAllItems = function() {
        return user_params.sl_cart_items || [];
    }
});