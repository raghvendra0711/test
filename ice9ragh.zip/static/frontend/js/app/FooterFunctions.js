var getActiveWeUser = function () {
    if (typeof webengage !== "undefined" &&
            typeof webengage.state !== "undefined" &&
            typeof webengage.state.getForever === "function" &&
            webengage.state.getForever() &&
            webengage.state.getForever().uattr
    ) {
        return webengage.state.getForever().uattr;
    }
    return null;
}
function onlyUnique(value, index, self) {
    return self.indexOf(value) === index;
}
function closeTicker(id) {
    if (typeof id != 'undefined' && id) {
        var clas = document.getElementsByClassName(id);
        clas[0].style.display = 'none';
        var date = new Date();
        date.setTime(date.getTime() + (4 * 24 * 60 * 60 * 1000));
        document.cookie = '_tikr_msg=1; expires=' + date.toGMTString() + '; path=/;SameSite=Lax';
        return;
    }
}
function getCookieByName(c_name) {
    var i, x, y, ARRcookies = document.cookie.split(";");

    for (i = 0; i < ARRcookies.length; i++)
    {
        x = ARRcookies[i].substr(0, ARRcookies[i].indexOf("="));
        y = ARRcookies[i].substr(ARRcookies[i].indexOf("=") + 1);
        x = x.replace(/^\s+|\s+$/g, "");
        if (x == c_name)
        {
            return unescape(y);
        }
    }
}

var setCookieByName = function (cname, cvalue, exhours, path, sameSite) {
    path = path || "/";
    var d = new Date();
    d.setTime(d.getTime() + (exhours * 60 * 60 * 1000));
    var expires = "expires=" + d.toUTCString();
    var cookieStr = cname + "=" + cvalue + "; " + expires + ";path=" + path + ";domain=.simplilearn.com;";
    if(typeof sameSite === "string" && sameSite.length > 0) {
        cookieStr += "SameSite=" + sameSite + ";";
        if (sameSite == "None" && location.protocol == 'https:') {
            cookieStr = cookieStr + ";secure;";
        }
    } else {
        cookieStr += "SameSite=Lax;"
    }
    document.cookie = cookieStr;
}

var setUser = function (email,lead) {
    console.log('setUser was called',email);
    if(typeof webengage != 'undefined' && typeof webengage.user != 'undefined' && typeof email != 'undefined' && email!= '')
        webengage.user.login(email);
    if (typeof webengage != 'undefined' && typeof webengage.screen != 'undefined' && typeof lead != 'undefined' && lead == 1) {
        webengage.screen("userInfo",{lead:1});
    }
}

function GetUTMParams(sParam, cookieStr) {
    var cookieUTM = '';
    if(typeof cookieStr != 'undefined' && cookieStr != '') {
        cookieUTM = cookieStr;
    }
    if(cookieUTM == '')
        cookieUTM = getCookieByName('__utmz');

    if(typeof cookieUTM == 'undefined' || !cookieUTM ) {
        cookieUTM = getCookieByName('sl_utmz');
    }
    //var cookieUTM = '31204797.1381386645.21.4.utmcsr=google|utmgclid=CLCM26HSi7oCFbF34godGFAA1g|utmccn=G-Brand-India|utmcmd=cpc|utmctr=simplilearn';
    if (cookieUTM != '' && typeof cookieUTM != 'undefined' && cookieUTM != null) {
        var sURLVariablesstr = cookieUTM;
        sURLVariables = sURLVariablesstr.replace(/(.)+utmcsr/g, "utmcsr");
        sURLVariables = sURLVariables.split('|');
        for (var i = 0; i < sURLVariables.length; i++)
        {
            var sParameterName = sURLVariables[i].split('=');
            if (sParameterName[0] == sParam) {
                return sParameterName[1];
            }
        }
        return false;
    }
    return false;
}
function sendUtmDetailsToDataLayer() {
    var utmSource = GetUTMParams('utmcsr');
    if (utmSource != '') {
        var utmMedium = GetUTMParams('utmcmd');
        var utmCampaign = GetUTMParams('utmccn');
        setDataLayerForUTMDetails(utmSource, utmMedium, utmCampaign);
    }
}
function setDataLayerForUTMDetails(source, medium, campaign) {
    if (typeof dataLayer == 'undefined') {
        dataLayer = [];
    }
    dataLayer.push({
        'event': 'source-medium-campaign-details',
        'source': source,
        'medium': medium,
        "campaign": campaign
    });
    return true;
}

function sendCountryCodeToDataLayer() {
    if (typeof dataLayer == 'undefined') {
        dataLayer = [];
    }
    if (typeof user_params.countryCode != 'undefined') {
        var pushData = {'countryCode': user_params.countryCode};
        dataLayer.push(pushData);
        return true;
    } else {
        return false;
    }
}
function sendArticleParamsToDataLayer() {
    if (typeof dataLayer == 'undefined') {
        dataLayer = [];
    }
    if (typeof user_params.product_name != 'undefined') {
        var pushData = {'product_name': user_params.product_name};
        dataLayer.push(pushData);
    }
    if (typeof user_params.product_id != 'undefined') {
        var pushData = {'product_id': user_params.product_id};
        dataLayer.push(pushData);
    }
    if (typeof user_params.category != 'undefined') {
        var pushData = {'category': user_params.category};
        dataLayer.push(pushData);
    }
    if (typeof user_params.category_id != 'undefined') {
        var pushData = {'category_id': user_params.category_id};
        dataLayer.push(pushData);
    }
    if (typeof user_params.segment_name != 'undefined') {
        var pushData = {'segment_name': user_params.segment_name};
        dataLayer.push(pushData);
    }
    if (typeof user_params.segment_id != 'undefined') {
        var pushData = {'segment_id': user_params.segment_id};
        dataLayer.push(pushData);
    }
    if (typeof user_params.resource_type != 'undefined') {
        var pushData = {'resource_type': user_params.resource_type};
        dataLayer.push(pushData);
    }

    return true;
}


var lpMTagConfig = {'lpServer': "server.iad.liveperson.net", 'lpNumber': "24435859", 'lpProtocol': (document.location.toString().indexOf('https:') == 0) ? 'https' : 'http'};

function lpAddMonitorTag(src) {
    if (typeof (src) == 'undefined' || typeof (src) == 'object') {
        src = lpMTagConfig.lpMTagSrc ? lpMTagConfig.lpMTagSrc : '/hcp/html/mTag.js';
    }
    if (src.indexOf('http') != 0) {
        src = lpMTagConfig.lpProtocol + "://" + lpMTagConfig.lpServer + src + '?site=' + lpMTagConfig.lpNumber;
    } else {
        if (src.indexOf('site=') & 0) {
            if (src.indexOf('?') & 0)
                src = src + '?';
            else
                src = src + '&';
            src = src + 'site=' + lpMTagConfig.lpNumber;
        }
    }
    ;
    var s = document.createElement('script');
    s.setAttribute('type', 'text/javascript');
    s.setAttribute('charset', 'iso-8859-1');
    s.setAttribute('src', src);
    document.getElementsByTagName('head').item(0).appendChild(s);
}

function downloadJSAtOnload() {

    //GTM init
    setTimeout(function() {
        //webengage code
        if (isDesktopDevice()) {
            // removing to enable new webengage account
            // window.webengageWidgetInit = window.webengageWidgetInit || function() {
            //     webengage.init({licenseCode: webEngageId}).onReady(function() {
            //         webengage.render();
            //     });
            // };
            // (function(d) {
            //     var _we = d.createElement('script');
            //     _we.type = 'text/javascript';
            //     _we.async = true;
            //     _we.src = (d.location.protocol == 'https:' ? "//ssl.widgets.webengage.com" : "//cdn.widgets.webengage.com") + "/js/widget/webengage-min-v-3.0.js";
            //     var _sNode = d.getElementById('_webengage_script_tag');
            //     _sNode.parentNode.insertBefore(_we, _sNode);
            // })(document);
        }
        //gamooga chat script
        //typeof is_href_lang === 'undefined' &&
        if (typeof isMomPage !=='undefined' &&isMomPage == false && typeof is_caldon_pulse === 'undefined' && typeof isCaldonPage === 'undefined'  && typeof is_enterprise_page ==='undefined' && typeof isB2BLandingPage === 'undefined' /*&& typeof is_corporate_page === 'undefined'*/) {
            getLiveChatCode();
        }
        if (typeof is_caldon_pulse !== 'undefined' && is_caldon_pulse === 1) {
            sendArticleParamsToDataLayer();
        }


//        gtmLoadScript();
        sendUtmDetailsToDataLayer();
        if (typeof isB2BLandingPage === 'undefined')
            sendCountryCodeToDataLayer();
        var gaEvents = new gaEventsTracker;
        gaEvents.init();
    }, 5000);

    mbsyCookieCheck();
}

function getUserInfo(){
    var returnUserInfo = {};
    var $injector = angular.element(document).injector();
    var $rootScope = $injector.get('$rootScope');
    var user = $rootScope.userInfo || {};
    user.name = user.name || user_params.first_name || '';
    var nameData = user.name.split(/ (.+)/);
    returnUserInfo['first_name'] = nameData[0] || '';
    var last_name = "";
    if(typeof nameData[1] != 'undefined' && nameData[1] != '')
        last_name = nameData[1];
    else
        last_name = user_params.last_name || ''
    returnUserInfo['last_name'] = last_name;
    returnUserInfo['email'] = user.email || user_params.email || '';
    returnUserInfo['phone'] = user.phone || user_params.phone || '';
    return returnUserInfo;
}

function returnLinkedInResponse(id, name, email, msg) {
    var $injector = angular.element(document).injector();
    var $rootScope = $injector.get('$rootScope');
    var currentUrl = window.location.href;
    var objs = document.querySelector("[ng-controller='HeaderController']");
    var controllerVar = angular.element(objs);
    var scopeVar = controllerVar.scope();

    if (typeof msg != 'undefined' && msg != '') {
        scopeVar.linkedErrClass = "error_msg";
        scopeVar.linkedinErrMsg = msg;
        scopeVar.$apply();
    } else {
        $rootScope.gaHeaderControllerJs.gaFireOnLoginSignupSuccess('linkedin');
        user_params.loggedIn = 1;
        user_params.user_id = id;
        user_params.email = email;
        $rootScope.isLoggedIn = true;
        $rootScope.$emit('isLoggedIn', true);
        $rootScope.communityRequestPending = {'display': 'none'};
        scopeVar.headerFormsStyle = {'display': 'none'};
        scopeVar.$apply();

        var PostReqService = $injector.get('PostReqService');
        PostReqService.initFreeTrialCookie();
    }

    if (typeof currentUrl != 'undefined' && currentUrl.indexOf('help-and-support') > 0) {
        location.reload();
    }
    else if (window.refurl != 'undefined' && typeof window.refurl == 'object') {
        if (typeof window.refurl.host != 'undefined' && window.refurl.host != '' && typeof window.refurl.source != 'undefined' && window.refurl.source != '') {
            if (window.refurl.host == 'community.simplilearn.com') {
                window.location.href = window.refurl.source;        //after success signup redirect to community page
            } else if (window.refurl.host == 'lms.simplilearn.com') {
                window.location.href = window.refurl.source;        //after success signup redirect to lms page
            }
        }
    }
}

function getLiveChatCode() {

    var ta = document.createElement('script');
    ta.type = 'text/javascript';
    ta.async = true;
    ta.id = "__ta";
    ta.src = '//cdn-jp.gsecondscreen.com/static/tac.min.js';
    var fs = document.getElementsByTagName('script')[0];
    fs.parentNode.insertBefore(ta, fs);
    ta.onload = function() {
        var gamoogaChatSpan = document.getElementsByClassName("gamooga_chat_span");
        var gamoogaChatLoading = document.getElementsByClassName("gamooga_chat_loading");
        var gamoogaChatLink = document.getElementsByClassName("ive_chat_right")[0];
        if(gamoogaChatSpan.length == 0) {
            // console.warn('SL: gamooga chat not available');
            return;
        }
        gamoogaChatLoading[0].className = gamoogaChatLoading[0].className + " hidden_class";
        gamoogaChatSpan[0].className = gamoogaChatSpan[0].className.replace("hidden_class", " ");
        gamoogaChatLink.style.cursor = "pointer";

        var mobileChatWrapper = document.getElementsByClassName("mobile_lead_wrapper")[0];
        var loadingIcons = mobileChatWrapper.getElementsByClassName("load-icon");
        loadingIcons[0].className = loadingIcons[0].className.replace("load-icon", " ");
        //loadingIcons[0].className = loadingIcons[0].className.replace("load-icon", " ");
    };

}

//There was an img tag of shareasale in footer which was dispaying a blank space below footer. This code is to hide the same, if found: Abhijit
var myintervalcount = 0;
var myinterval = setInterval(function() {
    var shareASaleImgObj = document.querySelector("[src='https://shareasale.com/sale.cfm?amount=undefined&tracking=undefined&transtype=sale&merchantID=43470']");
    myintervalcount++;
    if (typeof shareASaleImgObj != 'undefined' && shareASaleImgObj != null) {
        shareASaleImgObj.className = "hidden_class";
        clearInterval(myinterval);
    } else {
        if (myintervalcount > 10) {
            clearInterval(myinterval);
        }
    }
}, 1000);


function isDesktopDevice() {
    var userAgentStr = navigator.userAgent;
    var isDesktop = true;
    if (userAgentStr.indexOf("Android") != -1 || userAgentStr.indexOf("iPad") != -1 || userAgentStr.indexOf("iPhone") != -1 ||
            userAgentStr.indexOf("Blackberry") != -1 || userAgentStr.indexOf("BB") != -1 || userAgentStr.indexOf("Windows Phone") != -1 || userAgentStr.indexOf("Mobile") != -1) {
        isDesktop = false;
    }
    return isDesktop;
}

//Added code to fix ios devices body on click issue. #4365
(function() {
    var userAgentStr = navigator.userAgent;
    if (userAgentStr.indexOf("iPad") != -1 || userAgentStr.indexOf("iPhone") != -1) {
        document.body.style.cursor = 'pointer';
    }
})();

function setUpDataLayer(event, eventLabel, params) {
    if (typeof dataLayer == 'undefined') {
        dataLayer = [];
    }
    var d = new Date();
    var n = d.getMilliseconds();
    var pushData = {
        'event': event,
        'eventLabel': eventLabel
    }

    for (var key in params) {
        pushData[key] = params[key];
    }

    dataLayer.push(pushData);
    return true;
}
function getParameterByName(name) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}

function getPrefilledInfo(inputData, prefilledData) {
    var keys = Object.keys(inputData);
    var prefilInfo = {
        prefillled_data: 1,
        prefilled_source: null,
        prefilled_modified: 0
    };
    if(typeof prefilledData == 'undefined' || !prefilledData) {
        prefilInfo.prefillled_data = 0;
        prefilInfo.prefilled_source = 'other';
    } else {
        prefilInfo.prefilled_source = prefilledData.source || 'other';
        for(var i in keys) {
            var key = keys[i];
            var input = inputData[key] || '';
            var prefil = prefilledData[key] || '';
            if(input != prefil) {
                prefilInfo.prefilled_modified = 1;
            }
        }
    }
    return prefilInfo;
}

function setSlGlobalData(key, val) {
    if(typeof window.sl_custom_val != 'object') {
        window.sl_custom_val = {};
    }
    window.sl_custom_val[key] = val;
    window.sl_custom_param = encodeURIComponent(JSON.stringify(window.sl_custom_val));
}

// Init golbal custom data
function initSlGlobalData() {
    setSlGlobalData('last_source', fetchUTMSource());
    setSlGlobalData('course_id', (typeof user_params == 'object' && user_params.course_id) || '')
}

// Init after page load
window.addEventListener("load", initSlGlobalData);

function fetchUtmSourceFromUrl() {
    var utmcsr = getParameterByName('utm_source');
    var utmccn = getParameterByName('utm_campaign');
    var utmcmd = getParameterByName('utm_medium');
    var utmctr = getParameterByName('utm_term');
    var utmcct = getParameterByName('utm_content');
    var utmgclid = getParameterByName('gclid');
    var utmzCookie = null;
    if(utmcsr || utmccn || utmcmd || utmctr || utmcct || utmgclid) {
        utmzCookie = "utmcsr="+utmcsr+"|utmgclid="+utmgclid+"|utmccn="+utmccn+"|utmcmd="+utmcmd+"|utmctr="+utmctr+"|utmcct="+utmcct+"|create_type=manual_url";
    }
    return utmzCookie;
}


function cJInit() {
    var cjevent = getParameterByName('cjevent');
    if (cjevent != '') {
        var date = new Date();
        date.setTime(date.getTime() + (90 * 24 * 60 * 60 * 1000));
        window.cjevent = cjevent;
        document.cookie = 'cjevent=' + cjevent + '; expires=' + date.toGMTString() + '; path=/;domain=.simplilearn.com;SameSite=Lax';
    }
    var cjeventCookie = getCookieByName('cjevent');
    if ((cjevent == '' && typeof cjeventCookie != 'undefined' || cjeventCookie != '')) {
        window.cjevent = cjeventCookie;
    }
}

/**
 * Return source info. utmz cookie || utm source from url || find from
 * @returns String
 */
function fetchUTMSource() {
    var cookieVal = "utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)|create_type=manual"; // default value

    // from cookie
    var utmzCookie = getCookieByName('__utmz');

    // from url
    if ((typeof utmzCookie == 'undefined' || !utmzCookie)) {
        utmzCookie = fetchUtmSourceFromUrl();
    }

    // from referrer
    if ((typeof utmzCookie == 'undefined' || !utmzCookie) && document.referrer) {
        var referrer = document.referrer;
        var domainData = referrer.match(/\/\/[^/]+/);
        var domain = '';
        var medium = 'referral';
        var campaign = '(referral)';
        var selfDomains = ['simplilearn', 'marketmotive'];
        var organicDomains = ['google', 'bing', 'yahoo', 'baidu', 'ask', 'youtube', 'yandex', 'aol'];
        var selfRefer = false;

        if(Array.isArray(domainData) && domainData[0]) {
            domain = (typeof domainData[0] == 'string')?domainData[0].replace('//', ''):'';

            for(var i in selfDomains) {
                var key = selfDomains[i];
                if(domain.indexOf(key) !== -1) {
                    selfRefer = true;
                }
            }

            if(!selfRefer) {
                for(var i in organicDomains) {
                    var key = organicDomains[i];
                    if(domain.indexOf(key) !== -1) {
                        domain = key;
                        medium = 'organic';
                        campaign = '(organic)';
                        break;
                    }
                }
            }
        }
        if(!selfRefer) {
            var utmcsr = domain;
            var utmcmd = medium;
            var utmcct = referrer;
            var utmccn = campaign;
            var utmctr = '';
            var utmgclid = '';
            utmzCookie = "utmcsr="+utmcsr+"|utmccn="+utmccn+"|utmcmd="+utmcmd+"|utmctr="+utmctr+"|utmcct="+utmcct+"|utmgclid="+utmgclid+"|create_type=manual_ref";
        }
    }

    if (typeof utmzCookie == 'undefined' || !utmzCookie) {
        if(getCookieByName('sl_utmz')) {
            utmzCookie = getCookieByName('sl_utmz');
        } else {
            utmzCookie = cookieVal; // default value
        }
    }

    if(!getCookieByName('__utmz')) {
        setCookieByName('sl_utmz', utmzCookie, 90, "/", "None");
    }
    user_params.utm_params = utmzCookie;
    return utmzCookie;
}
function getGCLID(){
    var utmz = fetchUTMSource();
    var n = utmz.search(/|/i);
    var fromGoogle = false;
    var utmccnSet = false;
    var gclid = '';
    var gclidToSet = '';
    if(utmz != '' && n >= 0){
        utmz = utmz.split('|');
        if(utmz.length > 0){
            for(var i = 0; i<utmz.length;i++){
                var n = utmz[i].search(/=/i);
                if(n >= 0){
                    var params = utmz[i].split('=');
                    var n = params[0].search(/utmcsr/i);
                    if(n >= 0 && params[1] == 'google'){
                        fromGoogle = true;
                    } else if(params[0] == 'utmccn' && params[1] != ''){
                        utmccnSet = true;
                    } else if(params[0].search(/utmgclid/i) != -1){
                        gclid = params[1];
                    }
                }
            }
            if(fromGoogle && utmccnSet && gclid != ''){
                gclidToSet = gclid;
            }
            if(gclidToSet.length===0){
                gclidToSet=getParameterByName("gclid");
            }
            return gclidToSet;
        } else {
            if(gclidToSet.length===0){

                gclidToSet=getParameterByName("gclid");
            }
            return gclidToSet;
        }
    } else {
         if(gclidToSet.length===0){
                gclidToSet=getParameterByName("gclid");
        }

        return gclidToSet;
    }
}

function setSimplilearnCustomCookie() {
    window.addEventListener('load', function() {
        var firstLandingPage = getCookieByName('simplilearn_first_page');
        if(!firstLandingPage) {
            var date = new Date();
            date.setTime(date.getTime() + (90 * 24 * 60 * 60 * 1000));
            setCookieByName('simplilearn_first_page', location.href, 90, "/", "None");
            setCookieByName('simplilearn_landing_time', new Date().toISOString(), 90, "/", "None");
        }

        var firstOrigin = getCookieByName('simplilearn_custom');

        if (!firstOrigin) {
            setCustomCookie(0);
        }
    }, false);
}

function addCouponCodesToAACCookie(code_to_add){
  try {
    //cookie expiration
    var days = 15; //Cookie expire after 15 day
    var date = new Date();
    date.setTime(date.getTime()+(days*24*60*60*1000));
    var expires = "expires="+date.toGMTString();

    //Code_to_add will be in comma seperated string
    var code = getCookieByName('aac');
    //If previous code present
    if(code_to_add != undefined && code_to_add != ''){
      if(code != undefined && code != ''){
      var aac_arr = code_to_add.split(',');
      var curr_aac = code.split(',');
      var last = '';
      for(var i = 0; i < aac_arr.length; i++) {
        if(curr_aac.indexOf(aac_arr[i]) === -1){
          curr_aac.push(aac_arr[i]);
        }
      }
      last = curr_aac.join(',');
      document.cookie = 'aac='+last+ '; path=/;domain=.simplilearn.com ; '+expires+';SameSite=Lax';
     } else {
        document.cookie = 'aac='+code_to_add+ '; path=/;domain=.simplilearn.com ; '+expires+';SameSite=Lax';
     }
    }
  } catch(e){
      console.log("Error in auto Applying coupon");
  }
}

function setCustomCookie(pCntr) {
    var utmzCookie = getCookieByName('__utmz');

    if (utmzCookie) {
        setCookieByName('simplilearn_custom', utmzCookie, 90, "/", "None");
        return;
    }
    else {
        ++pCntr;
        if (pCntr > 10) {
            return false;
        }
        setTimeout(function() {
            setCustomCookie(pCntr);
        }, 400);
    }
}

setSimplilearnCampaignCookies();
function setSimplilearnCampaignCookies() {
    window.addEventListener('load', function () {
        var utmcsr = GetUTMParams('utmcsr');
        var utmcmd = GetUTMParams('utmcmd');
        var duration = 180 * 24;
        var sourceCookies = ['gclid', 'fbclid', 'msclkid'];
        var mkwid = getParameterByName('mkwid');
        var user_source_cookie = getCookieByName('user_source_cookie');
        var isRemoveSourceCookie = false;
        var utmSource = utmcsr+','+utmcmd;
        if (!user_source_cookie) {
            setCookieByName('user_source_cookie', utmSource, duration);
        } else {
            var sourceCookie = [];
            if (user_source_cookie) {
                sourceCookie = user_source_cookie.split(",");
            }
            var source = '';
            var medium = '';
            if (typeof sourceCookie != 'undefined' && sourceCookie.length>0) {
                source = sourceCookie[0] ? sourceCookie[0] : '';
                medium = sourceCookie[1] ? sourceCookie[1] : '';
            }
            if (utmcsr && (utmcsr.toUpperCase() !== source.toUpperCase())) {
                isRemoveSourceCookie = true;
                setCookieByName('user_source_cookie', utmSource, duration);
            } else {
                if (utmcsr && (utmcsr.toUpperCase() == source.toUpperCase())) {
                    if (utmcmd && medium && (utmcmd.toUpperCase() !== medium.toUpperCase())) {
                        isRemoveSourceCookie = true;
                        setCookieByName('user_source_cookie', utmSource, duration);
                    }
                }
            }
        }
        var cookieSet = false;
        for (var i = 0; i < sourceCookies.length; i++) {
            var sourceName = sourceCookies[i];
            var sourceValue = getParameterByName(sourceName);
            if (typeof sourceValue != 'undefined' && sourceValue) {
                var data = {};
                data[sourceName] = sourceValue;
                setCookieByName('campaign_source', JSON.stringify(data), duration, "/", "None");
                cookieSet = true;
                break;
            }
        }
        if (!cookieSet&&isRemoveSourceCookie) {
            setCookieByName('campaign_source', 0, 0);
        }
        if ((typeof mkwid == 'undefined' || !mkwid)) {
            if (cookieSet || isRemoveSourceCookie) {
                setCookieByName('campaign_platform', 0, 0);
            }
        } else {
            var mkwidData = {
                'mkwid': mkwid
            }
            setCookieByName('campaign_platform', JSON.stringify(mkwidData), duration, '/', 'None');
        }
        var getCampaignData = getCampaignDetails();
        if (getCampaignData) {
            setSlGlobalData('campaign_source', (typeof getCampaignData == 'object' && getCampaignData.campaign_source) || '')
            setSlGlobalData('campaign_source_id', (typeof getCampaignData == 'object' && getCampaignData.campaign_source_id) || '')
            setSlGlobalData('mkwid', (typeof getCampaignData == 'object' && getCampaignData.mkwid) || '')
        }
    }, false);
}

function hideMobileFooterDropQueryLink() {
    var drpQryLink = document.getElementsByClassName("mob_footer_drp_qry");
    var chatLink = document.getElementsByClassName("mob_footer_chat");
    drpQryLink[0].className = drpQryLink[0].className + " hidden_class";
    drpQryLink[1].className = drpQryLink[1].className + " hidden_class";

    chatLink[0].className = chatLink[0].className + " full-width";
    chatLink[1].className = chatLink[1].className + " full-width";
}

function showMobileFooterDropQueryLink() {
    var drpQryLink = document.getElementsByClassName("mob_footer_drp_qry");
    var chatLink = document.getElementsByClassName("mob_footer_chat");
    drpQryLink[0].className = drpQryLink[0].className.replace("hidden_class", "");
    drpQryLink[1].className = drpQryLink[1].className.replace("hidden_class", "");

    chatLink[0].className = chatLink[0].className.replace("full-width", "");
    chatLink[1].className = chatLink[1].className.replace("full-width", "");
}

setSimplilearnCustomCookie();

var mbsyName = 'mbsy';
var mbsyshortCode = getParameterByName(mbsyName);
function mbsyCookieCheck() {
    var c = getCookieByName(mbsyName);
    if ((mbsyshortCode != '' && mbsyshortCode)) {
        if (mbsyshortCode != c) {
            setCookieByName('mbsy', mbsyshortCode, 90, '/', 'None');
            return;
        }
    } else if (c) {
        mbsyshortCode = c;
    }
}

/**
 * Get hash parameter value by key
 * @param {string} key
 * @returns {string|null}
 */
function getHashByKey(key) {
    var query = location.hash.replace('#%2F','').replace('#/','').replace('#','');
    var vars = query.split('&');
    for (var i = 0; i < vars.length; i++) {
        var pair = vars[i].split('=');
        if (decodeURIComponent(pair[0]) == key) {
            return (pair[1])?decodeURIComponent(pair[1]) : '';
        }
    }
    return null;
}

function getHashList() {
    var query = location.hash.replace('#%2F','').replace('#/','').replace('#','');
    var vars = query.split('&');
    var list = {};
    for (var i = 0; i < vars.length; i++) {
        var pair = vars[i].split('=');
        if(!pair[1]) {
            list['hashTag'] = pair[0];
        }
        list[pair[0]] = (pair[1])?decodeURIComponent(pair[1]) : '';
    }
    return list;
}

function generateLeadId(key) {
    (typeof key == 'undefined' || !key) && (key = '*');
    window.latest_lead_uid = new Date().getTime() + "_" + key.substr(0, 4) + "_" + parseInt(Math.random() * 10000);
    return window.latest_lead_uid;
}
function getCookieOrigin() {
    var utmzVal = getCookieByName('__utmz');
    var ls_utmzVal = getCookieByName('sl_utmz');
    var utmzVal = typeof utmzVal !== "undefined" ? utmzVal : ls_utmzVal;
    return utmzVal;
}

function getDeviceInfo(userAgent) {
    var deviceInfo = {};
    var isOpera = !!window.opera || navigator.userAgent.indexOf(' OPR/') >= 0;
    // Opera 8.0+ (UA detection to detect Blink/v8-powered Opera)
    var isFirefox = typeof InstallTrigger !== 'undefined';   // Firefox 1.0+
    var isSafari = Object.prototype.toString.call(window.HTMLElement).indexOf('Constructor') > 0;
    // At least Safari 3+: "[object HTMLElementConstructor]"
    var isChrome = !!window.chrome && !isOpera;              // Chrome 1+
    var isIE = /*@cc_on!@*/false || !!document.documentMode;   // At least IE6
    var browserOs = "unknown";
    var nAgt = navigator.userAgent;
    if(typeof userAgent !== 'undefined' && userAgent ) {
        nAgt = userAgent;
    }
        var clientStrings = [
            {s:'Windows 10', r:/(Windows 10.0|Windows NT 10.0)/},
            {s:'Windows 8.1', r:/(Windows 8.1|Windows NT 6.3)/},
            {s:'Windows 8', r:/(Windows 8|Windows NT 6.2)/},
            {s:'Windows 7', r:/(Windows 7|Windows NT 6.1)/},
            {s:'Windows Vista', r:/Windows NT 6.0/},
            {s:'Windows Server 2003', r:/Windows NT 5.2/},
            {s:'Windows XP', r:/(Windows NT 5.1|Windows XP)/},
            {s:'Windows 2000', r:/(Windows NT 5.0|Windows 2000)/},
            {s:'Windows ME', r:/(Win 9x 4.90|Windows ME)/},
            {s:'Windows 98', r:/(Windows 98|Win98)/},
            {s:'Windows 95', r:/(Windows 95|Win95|Windows_95)/},
            {s:'Windows NT 4.0', r:/(Windows NT 4.0|WinNT4.0|WinNT|Windows NT)/},
            {s:'Windows CE', r:/Windows CE/},
            {s:'Windows 3.11', r:/Win16/},
            {s:'Android', r:/Android/},
            {s:'Open BSD', r:/OpenBSD/},
            {s:'Sun OS', r:/SunOS/},
            {s:'Linux', r:/(Linux|X11)/},
            {s:'iOS', r:/(iPhone|iPad|iPod)/},
            {s:'Mac OS X', r:/Mac OS X/},
            {s:'Mac OS', r:/(MacPPC|MacIntel|Mac_PowerPC|Macintosh)/},
            {s:'QNX', r:/QNX/},
            {s:'UNIX', r:/UNIX/},
            {s:'BeOS', r:/BeOS/},
            {s:'OS/2', r:/OS\/2/},
            {s:'Search Bot', r:/(nuhk|Googlebot|Yammybot|Openbot|Slurp|MSNBot|Ask Jeeves\/Teoma|ia_archiver)/}
        ];
        for (var id in clientStrings) {
            var cs = clientStrings[id];
            if (cs.r.test(nAgt)) {
                browserOs = cs.s;
                break;
            }
        }
    var deviceType = 'Desktop';
    if (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|ipad|iris|kindle|Android|Silk|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(nAgt)
            || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(nAgt.substr(0, 4)))
        deviceType = 'Mobile';

    var deviceName = null;
    if (nAgt.match(/Android/i)) {
        deviceName = 'Android';
    }
    if (nAgt.match(/BlackBerry/i)) {
        deviceName = 'BlackBerry';
    }
    if (nAgt.match(/iPhone/i)) {
        deviceName = 'iPhone';
    }
    if (nAgt.match(/iPad/i)) {
        deviceName = 'iPad';
    }
    if (nAgt.match(/iPod/i)) {
        deviceName = 'iPod';
    }
    deviceInfo = {browserOs: browserOs, deviceType: deviceType, deviceName: deviceName};
    return deviceInfo;
}
function getGdprOptInText(countryId, siteModule) {
    var gdprOptinText = 'Please contact me about course options and additional scholarships.';
    var gdprSiteModules = ["bundle agenda", "course preview", "course agenda", "ebook_download", "frs-ebook-hot", 'on demand webinar', "fpt-paper-cold", "GSA_Brochure", "atp brochure", "B2B-ebook"];
    var agreeText = '';
    var euroCountryArr = [];
    if (typeof euroCountriesIds !== "undefined" && euroCountriesIds) {
        euroCountryArr = euroCountriesIds.split(",");
    }
    if (countryId && siteModule && euroCountriesIds.indexOf(countryId)!=-1 && gdprSiteModules.indexOf(siteModule)!=-1) {
        agreeText = gdprOptinText;
    }
    return agreeText;
}
function getLeadTrainingType(leadTrainingType) {
    var leadTrainingTypeStr = "";
    //var trainingTypeLists = ['classroom', 'osl', 'lvc', 'tests', 'webinar', 'ides', 'onlinetolvc', 'notsure', 'coursePass'];
    var lead_class_room_training_str = 'Classroom Training';
    var lead_osl_training_str = 'Online Self Learning';
    var lead_instructor_led_training_str = 'Instructor Led Online Classroom';
    var lead_flexi_pass_training_str = 'Online Classroom Flexi-Pass';
    if (typeof leadTrainingType !== "undefined") {
        switch (leadTrainingType) {
            case "classroom":
                leadTrainingTypeStr = lead_class_room_training_str;
                break;
            case "osl":
                leadTrainingTypeStr = lead_osl_training_str;
                break;
            case "coursePass":
                leadTrainingTypeStr = lead_flexi_pass_training_str;
                break;
            case "lvc":
                leadTrainingTypeStr = lead_flexi_pass_training_str;
                break;
            case "online":
                leadTrainingTypeStr = lead_osl_training_str;
                break;
            default:
                leadTrainingTypeStr = lead_osl_training_str;
        }
    }
    return leadTrainingTypeStr;
}
function formatTZDateTime(dateTime) {
    var formatedDateTime = '';
    if (typeof dateTime !== "undefined" && dateTime) {
        var date = new Date(dateTime);
        var yy = date.getFullYear();
        var gg = date.getDate();
        var mm = (date.getMonth() + 1);

        if (gg < 10)
            gg = "0" + gg;

        if (mm < 10)
            mm = "0" + mm;

        var cur_day = yy + "-" + mm + "-" + gg;

        var hours = date.getHours()
        var minutes = date.getMinutes()
        var seconds = date.getSeconds();

        if (hours < 10)
            hours = "0" + hours;

        if (minutes < 10)
            minutes = "0" + minutes;

        if (seconds < 10)
            seconds = "0" + seconds;
        formatedDateTime = cur_day + " " + hours + ":" + minutes + ":" + seconds;
    }
    return formatedDateTime
}

var produtPageViewedEvent = function() {
    webengage.onReady(function () {
        WebTracking.eventReq.triggerEvent({
            event_id: "sl_eng_product_page_viewed",
            event_data: {},
            common: "product"
        });
    });
}

function checkIfAccordionIsOpen(accordionId) {
    var isAccordionOpen = false;
    if (accordionId) {
        var accordionElm = document.getElementById(accordionId);
        if (accordionElm) {
            isAccordionOpen = accordionElm.classList.contains("arrow-down");
        }
    }
    return isAccordionOpen;
}
function breadcrumEvent(productType,gotoLink,name,id) {
    var eventData = {};
    eventData['sl_destination_product_type'] = productType || '';
    eventData['sl_destination_link'] = gotoLink || '';
    eventData['sl_destination_product_name'] = name || '';
    eventData['sl_destination_product_id'] = parseInt(id) || '';
    WebTracking.eventReq.triggerEvent({
        event_id: "sl_nav_breadcrumb_clicked",
        event_data: eventData,
        common: "product"
    });
}

 function getCampaignDetails() {
    var simpli_source = getCookieByName('campaign_source');
    var simpliSourceCookieObj = {};
    if (typeof simpli_source != 'undefined' && simpli_source) {
        simpliSourceCookieObj = JSON.parse(simpli_source);
    }
    var sourceKeyObj = Object.keys(simpliSourceCookieObj);
    var campaignSource = '';
    var campaignSourceId = '';
    if (sourceKeyObj) {
        campaignSource = sourceKeyObj[0] || '';
        campaignSourceId = simpliSourceCookieObj[campaignSource] || '';
    }
    /*
     * sending merin id to lead
     */
    var campaign_platform = getCookieByName('campaign_platform');
    var campaignPlatformCookieObj = {};
    if (typeof campaign_platform != 'undefined' && campaign_platform) {
        campaignPlatformCookieObj = JSON.parse(campaign_platform);
    }
    var compPlatforms = Object.keys(campaignPlatformCookieObj);
    var campaignPlatformId = '';
    if (compPlatforms) {
        var campaignPlatform = compPlatforms[0] || '';
        campaignPlatformId = campaignPlatformCookieObj[campaignPlatform] || '';
    }

    var campignDetails = {
        'campaign_source': campaignSource,
        'campaign_source_id': campaignSourceId,
        'mkwid': campaignPlatformId || ''
    }
    return campignDetails;
};

function initPreChat() {
    try {
        if (typeof DISABLE_PRECHAT_STATUS === "undefined") return;
        if (typeof prechat_sub == 'function' && DISABLE_PRECHAT_STATUS == 1) {
            prechat_sub();
        }
    } catch (e) {
        console.error("SL:Error prechat_sub is not a defined")
    }
}

!function(e){"use strict";function h(b){var a=b.charCodeAt(0);if(55296<=a&&56319>=a)if(b=b.charCodeAt(1),b===b&&56320<=b&&57343>=b){if(a=1024*(a-55296)+b-56320+65536,65535<a)return d(240|a>>>18,128|a>>>12&63,128|a>>>6&63,128|a&63)}else return d(239,191,189);return 127>=a?inputString:2047>=a?d(192|a>>>6,128|a&63):d(224|a>>>12,128|a>>>6&63,128|a&63)}function k(b){var a=b.charCodeAt(0)<<24,f=l(~a),c=0,e=b.length,g="";if(5>f&&e>=f){a=a<<f>>>24+f;for(c=1;c<f;++c)a=a<<6|b.charCodeAt(c)&63;65535>=a?g+=d(a):1114111>=
a?(a-=65536,g+=d((a>>10)+55296,(a&1023)+56320)):c=0}for(;c<e;++c)g+="\ufffd";return g}var m=Math.log,n=Math.LN2,l=Math.clz32||function(b){return 31-m(b>>>0)/n|0},d=String.fromCharCode,p=atob,q=btoa;e.btoaUTF8=function(b,a){return q((a?"\u00ef\u00bb\u00bf":"")+b.replace(/[\x80-\uD7ff\uDC00-\uFFFF]|[\uD800-\uDBFF][\uDC00-\uDFFF]?/g,h))};e.atobUTF8=function(b,a){a||"\u00ef\u00bb\u00bf"!==b.substring(0,3)||(b=b.substring(3));return p(b).replace(/[\xc0-\xff][\x80-\xbf]*/g,k)}}(""+void 0==typeof global?
""+void 0==typeof self?this:self:global)

// set auh
function setAuh(eventData) {
    try {
        if (typeof btoa !== "function") throw new Error("btoa not defined") 
        var eventData = eventData || {};
        var email = eventData.sl_user_email || eventData.email || null;
        if (email) {
            var phone = eventData.sl_user_phone || '';
            if (!phone) {
                phone = (eventData.phoneCode) ? "+" + eventData.phoneCode.replace("-", "").replace("+", "") + "-" : "";
                phone += eventData.phone || '';
            }
            var name = eventData.username || eventData.name || '';
            if (!name) {
                name = (eventData.firs_tname || '') + ' ';
                name += eventData.last_name || '';
                name = name.trim();
            }
            var hashData = [email, phone, name];
            hashData.push(eventData.sl_user_phone || '');
            var auh = btoa(hashData.join(","));
            if (auh) {
                var expTime = user_params.AUH_EXPIRE_TIME * 24;
                setCookieByName("auh", auh, expTime);
            }
        }
    } catch (e) {
        console.error("SL:Error auh set failed", e);
    }
}