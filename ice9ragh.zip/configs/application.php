<?php
$static_host = 'www.simplilearn.com';
$host = '';
if (!defined('HOST')) {
    $host = !empty($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'www.simplilearn.com';
    define('HOST', $host);
}
$appendStr = '';
if (in_array(APPLICATION_ENV, array('production_onedomain','development','development_enterprise','testing_enterprise','testing'))) {
    $static_host = $host;
    $appendStr = '/apachedev/git/ice9/frontend/public';
}
if (!defined('HOST_STATIC')) {
    define('HOST_STATIC', $static_host);
}

$remoteIpArr = array();
if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $remoteIpArr = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
}

//define('HOST', 'qawww.simplilearn.com');
$config = array();
// ---------------------------------------------------------
// PRODUCTION ENV
// ---------------------------------------------------------
$config['production'] = array (
  'phpSettings' =>
  array (
    'display_startup_errors' => '0',
    'display_errors' => '0',
    'date' =>
    array (
      'timezone' => 'Asia/Calcutta',
    ),
    'session' =>
    array (
      'cookie_domain' => (!empty($_SERVER['HTTP_HOST']) && strpos($_SERVER['HTTP_HOST'],'.simplilearn.net') === false) ? '.simplilearn.com':'.simplilearn.net',
    ),
  ),
  'resources' =>
  array (
    'frontController' =>
    array (
      'params' =>
      array (
        'displayExceptions' => '0',
      ),
            'controllerDirectory' => APPLICATION_PATH . '/controllers',
            'moduleDirectory' => APPLICATION_PATH . '/modules',
      'actionHelperPaths' =>
      array (
        'BaseApp_Action_Helper' => 'BaseApp/Action/Helper',
      ),
    ),
    'layout' =>
    array (
      'layoutPath' => APPLICATION_PATH . '/layouts/scripts/',
    ),
    'db' =>
    array (
      'adapter' => 'pdo_mysql',
      'params' =>
      array (
        'host' => 'i2rds.cuoivis0lb68.us-east-1.rds.amazonaws.com',
        'dbname' => 'ice9',
        'username' => 'simpli_web',
        'password' => 'SLPortal@2010',
        'driver_options' =>
        array (
          1002 => 'SET NAMES utf8, time_zone = \'+5:30\';',
        ),
        'profiler' => '0'
      ),
    ),
    'mail' =>
    array (
      'transport' =>
      array (
        'type' => 'smtp',
        'host' => 'email-smtp.us-east-1.amazonaws.com',
        'auth' => 'login',
        'username' => 'AKIAIWIEDLFCJWCS2T5A',
        'password' => 'Ahgm0YT24d1oTmm+pFLD9owlmHX7P4TA0/WTg4UV1gaL',
        'ssl' => 'tls',
        'port' => '587',
        'register' => '1',
      ),
            'simplilearncourses' =>
                        array(
                                'type' => 'smtp',
                                'host' => 'email-smtp.us-east-1.amazonaws.com',
                                'auth' => 'login',
                                'username' => 'AKIAJ5SMLYHJ2ZSQ52DA',
                                'password' => 'Ailc/Los3sr/zbGDDMesiyMFmeLGhC9LNZBBRUH4KX8c',
                                'ssl' => 'tls',
                                'port' => '587',
                                'register' => '1',
                                'sender_email' => 'mailer@simplilearncourses.com',
                                'sender_name' => 'Simplilearn Courses',
                                'reply_to_email' => 'mailer@simplilearncourses.com',
                        ),
    ),
    'log' =>
    array (
      'stream' =>
      array (
        'writerName' => 'Stream',
        'writerParams' =>
        array (
          'stream' => APPLICATION_PATH . '/../error.log',
          'mode' => 'a+',
        ),
        'formatterName' => 'Simple',
        'formatterParams' =>
        array (
          'format' => '
%timestamp% %priorityName% (%priority%): %message%
%info%
--

',
        ),
      ),
    ),
  ),
  'salesforce' => array(
        'SF_USERNAME' => "apiuser@simplilearn.com",
        'SF_PASSWORD' => "Ap!SiMp!i@321agEIi3DOg4GeRX5guLE0rZulB",
        'WSDL_FILE_NAME' => "/enterprise_v3.wsdl.xml",
    ),
  'includePaths' =>
  array (
    'library' => APPLICATION_PATH . '/../library',
  ),
  'bootstrap' =>
  array (
    'path' => APPLICATION_PATH . '/Bootstrap.php',
    'class' => 'Bootstrap',
  ),
  'appnamespace' => 'BaseApp',
  'constants' =>
  array (
    'WEBSITE_MAIN_URL' => 'https://www.simplilearn.com',
    'FRONTEND_URL' => 'https://'.HOST,
    'FRONTEND_CANONICAL_URL' => 'https://'.HOST,
    'FRONTEND_CANONICAL_URL_SECURE' => 'https://'.HOST,
    'FRONTEND_API_URL' => '//www.simplilearn.com/api/v1',
    'FRONTEND_API_URL_NOCACHE' => '//www.simplilearn.com/api/v1/index/nocache',
    'SHELDON_B2B_PRICING_API' => 'https://www.simplilearn.com/resources/api/v1/getProductPrice',
    'SITE_API_URL_NOCACHE' => 'https://'.HOST.'/api/v1/index/nocache',
    'FRONTEND_CDN_API_URL' => '//www.simplilearn.com/api/v1?method=',
    'FRONTEND_NON_CDN_API_URL' => '//www.simplilearn.com/api/v1?method=',
    'SEO_FRONTEND_URL' => 'https://'.HOST,
    'FREE_RESOURCES_CDN_URL' => 'https://'.HOST.'/ice9/',
    'FRONTEND_REL_PATH' => '',
    'FRS_DEFAULT_THUMBNAIL_ARTICLE' => 'https://'.HOST.'/ice9/free_resources_article_thumb/Article.svgz',
    'FRS_DEFAULT_VERTICAL_THUMBNAIL_EBOOK' => 'https://'.HOST.'/ice9/ebooks/ebook_2.svgz',
    'FRS_DEFAULT_THUMBNAIL_EBOOK' => 'https://'.HOST.'/ice9/ebooks/ebook.svgz',
    'SEO_DEFAULT_THUMB_IMAGE_TO_SHARE' => 'https://'.HOST.'/ice9/free_resources_article_thumb/SIMPLILEARN_LOGO_th.jpg',
    'SEO_DEFAULT_COURSE_THUMB_IMAGE' => 'https://'.HOST.'/ice9/course_images/course_thumbnail_default.png',
    'FRS_WEBINAR_DEFAULT_ICON' => 'https://'.HOST.'/ice9/webinar_thumb_images/226x182/default_icon-webinar.svg',
    'FRS_DEFAULT_400x225_IMAGE' => 'https://'.HOST.'/ice9/review_images/400x225.png',
    'FRS_DEFAULT_140x140_IMAGE' => 'https://'.HOST.'/ice9/review_images/140x140.png',
    'SALESFORCE_LEAD_WEBSITE' => 'https://'.HOST.'/',
    'META_IMAGE' => 'https://'.HOST.'/logo.png',
    'EMAIL_TEMPLATE_DIR' => APPLICATION_PATH . '/../../templates/email/',
    'SEND_EMAIL_ID' => 'no-reply@simplilearn.net',
    'SENDER_NAME' => 'Simplilearn',
    'REPLYTO_EMAIL_ID' => 'support@simplilearn.com',
    'REPLYTO_NAME' => 'Simplilearn Support',
    'CONTACT_US_EMAIL' => 'corporate@simplilearn.com',
    'CORPORATE_SALES_EMAIL' => 'corporatesales@simplilearn.com',
    'CORPORATE_SALES_EMAIL2' => 'corpsales@simplilearn.com',
    'ATP_EMAIL' => 'partner@simplilearn.com',
    'BLOG_EMAIL' => 'promos@simplilearn.com',
    'AFFILIATE_EMAIL' => 'affiliate@simplilearn.com',
    'TRAINER_EMAIL' => 'teach@simplilearn.com',
    'US_COUNTRY_ID' => '34',
    'INDIA_COUNTRY_ID' => '6',
    'AUS_COUNTRY_ID' => '2',
    'UK_COUNTRY_ID' => '14',
    'SHOW_STATIC_HEADER' => '1',
    'DEFAULT_COUNTRY_TIME_ZONE' => 'Europe/London',
    'WEBEX_EMAIL_ID' => 'messenger@webex.com',
    'SUBSCRIPTION_CONVERSION_FACTOR' => '63',
    'SUBSCRIPTION_IND_CURRENCY_ID' => '6',
    'CLUSTER_ID_AMERICAS' => '6',
    'ACCOUNTS_PATH' => 'https://accounts.simplilearn.com',
    'IOS_RECEIPT_VALIDATION_URL' => 'https://buy.itunes.apple.com/verifyReceipt',
    'LOG_FORMAT' => '
%timestamp% %priorityName% (%priority%): %message%
%info%
--
',
    'MOBILE_DATA_DB_NAME' => 'mobile_data',
    'MELVIN_DB_HOST' => 'i2rds.cuoivis0lb68.us-east-1.rds.amazonaws.com',
    'MELVIN_DB_USERNAME' => 'simpli_web',
    'MELVIN_DB_PASSWORD' => 'SLPortal@2010',
    'MELVIN_DB_NAME' => 'melv1n_crm2',
    'CLOUD6_DB' => 'cloud6',
    'MAIN_CDN_URL' => 'https://'.HOST_STATIC.'/static',
    'STATIC_URL' => 'https://static.simplilearn.com',
    'SEND_OUT_OF_MEMORY_EMAIL' => 1,
    'BASE_LMS_URL' => 'https://lms.simplilearn.com/',
    'LMS_DOMAIN' => 'lms.simplilearn.com',
    'CRM_URL' => 'https://xenia.simplilearn.com',
    'SSVC_URL' => 'https://www.simplilearn.com/secure/',
    'BACKEND_URL' => 'http://i9simplex.simplilearn.com',
        'MM_FRONTEND_URL' => 'https://www.marketmotive.com',
    'BASE_LMS_API_URL' => 'api/v1/',
    'BASE_LMS_API_URL_V2' => 'api/v2/',
    'BASE_LMS_API_INTERNAL_URL' => 'api/internal/',
    'BASE_LMS_CERTIFICATE_URL' => 'user/certificate/download/crtoken/',
    'BASE_LMS_MANAGE_SUBSCRIPTION_URL' => 'user/profile/manage-subscription',
    'REL_LOCAL_URL' => '../../static',
    'SIMPLEX_MAINTENANCE' => 0,
    'BACKEND_ROWS_PER_PAGE' => 3,
    'CMO_SPEAK_COURSE_DMCA' => 630,
    'FRONTEND_CDN_API_ENABLE' => 1,
    'FRONTEND_API_SERVER_CACHE_ENABLE' => 1,
    'FRONTEND_CDN_API_CACHE_BUST_ID' => 5,
    'FRONTEND_CDN_API_URL_TIMEOUT' => '14400',
    'SYNC_DB_NAME' => 'sync',
    'MELVIN_DB' => 'melv1n_crm2',
    'STUB_DIR' => APPLICATION_PATH . ' ../../static/frontend/js/',
    'IMAGE_CDN_URL' => '',
    'VIDEO_CDN_URL' => '',
    'MONGO_CONN_STR' => 'mongodb://mongo-cm-1:27017,mongo-cm-2:27017,mongo-cm-3:27017/?replicaSet=ice10-mrs',
    'MONGO_DB' => 'ice9',
    'CLOUD6_DB' => 'cloud6',
    'GOOGLE_CLIENT_ID' => '157934410265-3tqcftt9b1501amu8qv0v6i7dnravluj.apps.googleusercontent.com',
    'GOOGLE_SECRET_KEY' => 'L5aCxYOGfGr69x0xAOHYJ_ek',
    'LINKED_IN_API_KEY' => '75g24gm5c4yble',
    'TOOLS_DEVOPS_COURSE_ID' => '704',
    'TOOLS_CEH_COURSE_ID' => '105',
    'TOOLS_MKTNG_BUNDLE_ID' =>  'b23',
    'TOOLS_MKTNG_BUNDLE_ID_SEO' =>  'b69',
    'TOOLS_MKTNG_BUNDLE_ID_SM' =>  'b70',
    'TOOLS_MKTNG_BUNDLE_ID_PPC' =>  'b71',
    'FB_APP_ID' => 507379152611585,
    'DATE_FORMAT' => 'Y-m-d',
    'IP_ADDRESS_ALLOW_OVERRIDE' => 1,
    'IP_ADDRESS_MIN' => 16777216,
    'IP_ADDRESS_MAX' => 3758096383,
    'SSVC_DATABASE' => 'ssvc',
    'UPLOAD_CDN_URL' => 'https://www.simplilearn.com',
    'AFFILIATE_COOKIE_NAME' => '__utmz',
    'CONVERSION_RATIO_FROM_AUD' => 0.9,
    'CONVERSION_RATIO_FROM_INR' => 0.0167,
    'CONVERSION_RATIO_FROM_GBP' => 1.282,
    'CONVERSION_RATIO_FROM_EURO' => 1.14,
    'FORMATTED_CURRENCY_FOR_AUS' => 'AUD',
    'FORMATTED_CURRENCY_FOR_US' => 'USD',
    'FORMATTED_CURRENCY_FOR_IN' => 'INR',
    'FORMATTED_CURRENCY_FOR_GB' => 'GBP',
    'CURRENCY_FOR_AUS' => 'AUD',
    'CURRENCY_FOR_US' => 'USD',
    'CURRENCY_FOR_GB' => 'GBP',
    'CURRENCY_FOR_ONLY_US' => '$',
    'CURRENCY_FOR_IN' => 'Rs.',
    'CURRENCY_FOR_ONLY_UK' => '&pound;',
    'COUNTRY_LINE_DIVIDER' => 10,
    'COURSE_TYPE_FOR_CLASSROOM' => 'Classroom',
    'COURSE_TYPE_FOR_ONLINE' => 'Online Self Learning',
    'TRAINING_TYPE_FOR_ONLINE' => 'online',
    'TRAINING_TYPE_FOR_CLASSROOM' => 'classroom',
    'TRAINING_TYPE_FOR_LVC' => 'lvc',
    'ATP_FORM_DEFAULT_COURSE_ID' => 10,
    'ATP_FORM_DEFAULT_COURSE_NAME' => 'PMP',
    'WEB_ENGAGE_ID' => '311c5642',
    'GOOGLE_TAG_MANAGER_CODE' => 'GTM-WTL3CF',
        'DUKE_INTEGRATED_BUNDLE_ID' => '', //Bundle Id for Duke integrated prog.Add b for each id
        'INTEGRATED_PROG_STEP_FORM_URL' => '/webforms/integrated-program-form-details-to-fill',
        'INTEGRATED_PROG_FORM_ADD_CRT_TIME' => 3600,
    'AD_ELEMENT_PRODUCT_TYPE_COURSE' => 1,
    'AD_ELEMENT_PRODUCT_TYPE_BUNDLE' => 2,
    'GOOGLE_ANALYTICS_CODE' => (!empty($_SERVER['HTTP_HOST']) && strpos($_SERVER['HTTP_HOST'],'.net') !== false) ? 'UA-32079340-9':'UA-32079340-1',
        'GOOGLE_ANALYTICS_CODE_FRS' =>'UA-32079340-5',
    'GOOGLE_ANALYTICS_DOMAIN_NAME' => (!empty($_SERVER['HTTP_HOST']) && strpos($_SERVER['HTTP_HOST'],'.net') !== false) ? 'simplilearn.net':'simplilearn.com',
    'PINGDOM_CODE' => '5561ef85abe53d2b3caa542f',
    'ORIGIN_COOKIE_NAME' => '__utmz',
    'SL_ORIGIN_COOKIE_NAME' => 'sl_utmz',
    'LATEST_AUTO_LEAD_COOKIE_NAME' => '_latest_auto_lead',
    'SKIP_POPUP_COOKIE_NAME' => '_skip_popup',
    'FIRST_ORIGIN_COOKIE_NAME' => 'simplilearn_custom',
    'COOKIE_FIRST_PAGE' => 'simplilearn_first_page',
    'COOKIE_FIRST_PAGE_TIME' => 'simplilearn_landing_time',
    'OPTIN_COOKIE' => '_optin',
    'API_CACHE_TTL' => 3600,
    'REFERRAL_COOKIE_NAME' => 'referral_id',
    'DEFAULT_CURRENCY_COUNTRY_ID' => 34,
    'YOUTUBE_EMBED_PARAMS' => 'html5=1&enablejsapi=1&modestbranding=1&rel=0&autohide=1&iv_load_policy=3&wmode=transparent&showinfo=0&cc_load_policy=1',
    'META_TITLE' => 'Online and Classroom Training for Professional Certification Courses | Simplilearn',
    'META_DESCRIPTION' => 'Enroll for PMPÃ‚Â® certification training in Delhi.  Attend world renowned PMPÃ‚Â® classroom training organized by Simplilearn',
    'META_KEYWORDS' => 'Online classes, Online courses, Free online courses, Online Certification, Online tutoring, Online Training, Certification programs, Microsoft Certification, Cisco Certification, IT Service management',
    'CACHE_ENABLED' => 1,
    'PROFILER_ENABLED' => (in_array('118.102.154.209', $remoteIpArr) && $_SERVER['HTTP_HOST'] == 'i10www.simplilearn.com' && isset($_GET['profiler']) && $_GET['profiler'] == '1') ? '1' : '0',
    'PROFILER_HIDDEN' => (in_array('118.102.154.209', $remoteIpArr) && $_SERVER['HTTP_HOST'] == 'i10www.simplilearn.com' && isset($_GET['profiler']) && $_GET['profiler'] == '1') ? '0' : '1',
    'CACHE_TTL' => 4800,
    'CACHE_CLEAR_PARAM_NAME' => 'clear_cache',
    'CACHE_CLEAR_PARAM_VALUE' => 'now',
    'CACHE_REFRESH_PARAM_NAME' => 'refresh_key_cache',
    'CACHE_TYPE' => 'memcached',
    'CACHE_MEMCACHED_HOST' => 'i9-memcache-server.yx2u3w.cfg.use1.cache.amazonaws.com',
    'CACHE_MEMCACHED_PORT' => 11222,
    'FOR_BUSINESS_LINK' => 'http://enterprise.simplilearn.com/?_r=hdr',
    'PLACEHOLDER_IMG' => 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7',
    'ADD_THIS_WIDGET_ID' => 'ra-5492db360575da40',
    'DEFAULT_COUNTRY_ID' => 34,
    'REVIEWS_LIMIT' => 10,
    'SSVC_PROVIDER_KEY' => 'vdss209csad0g9j2fasefse09r8grs4',
    'SSVC_PROVIDER_KEY_WPP' => 'vdss209csad0g9j2fasefse09etnprri',
    'COMBINE_ALL_JS' => 1,
    'AWS_S3_SECRET_KEY' => 'mMLafyybV7FfayM31n5zv2lS3MZFnUuTDKaWfspu',
    'AWS_S3_ACCESS_KEY' => 'AKIAIYWYMJD2M245ENFQ',
    'AWS_S3_ACCESS_KEY_NEW' => 'AKIAIGSH7TIXFW7ADYIA',
    'AWS_S3_SECRET_KEY_NEW' => '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',
    'AWS_S3_SECRET_KEY_DATALINK' => 'E4RAsnGRV0+XL6WkvnqCTEnuNpMg8DdHkpVMTK//',
    'AWS_S3_ACCESS_KEY_DATALINK' => 'AKIAJKFUGMFRVRDYILEQ',
    'AWS_S3_SECRET_KEY_WEBSITE_DEV' => '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',
    'AWS_S3_ACCESS_KEY_WEBSITE_DEV' => 'AKIAQJELLIZTAPEKZPOO',
    'AWS_S3_DEF_BUCKET_DATALINK' => 'sl-analytics.simplilearn.com',
    'AWS_S3_BUCKET_NAME' => 'static2.simplilearn.com',
    'AWS_S3_IMAGES_PATH' => 'ice9',
    'AWS_S3_BASE_URL' => 'https://www.simplilearn.com',
    'AWS_CLOUD_FRONT_ACCESS_KEY' => 'AKIAIDZG7L5EMVFLHNAA',
    'AWS_CLOUD_FRONT_SECRET_KEY' => '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',
    'AWS_CLOUD_FRONT_DISTRIBUTION_ID' => 'E3B6CFTVLQXWCM',
    'AWS_REGION' => 'us-east-1',
    'SIMPLILEARN_STATS' => '500,000+|$5Bn+',
    'CONTACT_US_IN' => '1-800-102-9602',
    'CONTACT_US_USA' => '844-LEARN-88 (844-532-7688)',
    'CONTACT_US_USA_NUM' => '844-532-7688',
    'CONTACT_US_ROW' => '+1-(281)-241-4333',
    'CONTACT_US_2_IN' => '+91-80-49413511, +91 80 42465004, +91 80 42451133',
    'CONTACT_US_2_ROW' => '+1 (408) 500 0745',
    'CONTACT_US_2_USA' => '+1 (408) 500 0745',
        'DIRECT_CALLS_US_NUM' =>'1-844-842-4145',
        'DIRECT_CALLS_IN_NUM' =>'+91 80494 13482',
        'DIRECT_NUM_CATEGORY_NAME' =>'IT Service and Architecture',
    'GO_TO_WEBINAR_USER_ID' => 'simplilearn@gmail.com',
    'GO_TO_WEBINAR_PASSWORD' => 'webinar@simplilearn123',
    'GO_TO_WEBINAR_CLIENT_ID' => 'pDcV1PzgmDEJqL2bTAGH2aWCA3ZKGmSs',
    'GO_TO_WEBINAR_ORGANIZER_ID' => '7732484106959502598',
        'CA_HEADING_SCHOLARSHIP_COURSE_ID' =>'279',
    'ALLOW_URLS_SITEMAP' => 'sitemap_allow.csv',
    'DISALLOW_URLS_SITEMAP' => 'sitemap_disallow.csv',
    'AB_MODULE_1889' => 0,
    'AB_MODULE_1889_COURSE_ID' => 9,
    'AB_MODULE_1889_REDIRECT_CODE' => 301,
    'AB_MODULE_1889_TRIGGER_STRING' => 'ab1889',
    'AB_MODULE_1889_REDIRECT_OR_NOT' => 0,
    'COMMUNITY_BASE_URL' => 'http://community.simplilearn.com/',
    'AUTO_ASSIGN_FRS_FAIL_EMAIL' => 'coders.nike@simplilearn.net',
    'AUTO_ASSIGN_COURSE_PREVIEW_FAIL_EMAIL' => 'coders.nike@simplilearn.net',
    'EMAIL_FRS_INFORM_CHANGE' => 'frs_mod@simplilearn.com',
    'EMAIL_LECTURE_CREATE_INFORM' => 'coders.seo@simplilearn.com',
    'WEBEX_SITEID' => 408917,
    'WEBEX_PARTNERID' => 'aGH4vnYT2S3iWFy55EybZA',
    'WEBEX_SITEURL' => 'https://simplilearn.webex.com/WBXService/XMLService',
    'WEBEX_SITEID_V2' => '1240102',
    'WEBEX_PARTNERID_V2' => 'WnEdW1IaWDQFzAgDZhVmtw',
    'WEBEX_SITEURL_V2' => 'https://simplilearnsolutions.webex.com/WBXService/XMLService',
    'TESTIMONIAL_DEFAULT_IMAGE' => '/ice9/testimonial_images/default_avatar.png',
    'ENABLE_PHP_FIREWALL' => 1,
    'ENABLE_PHP_REFERER_FIREWALL' => 1,
    'REVIEW_TO_BE_APPROVED_STATUS' => 0,
    'REVIEW_APPROVED_STATUS' => 1,
    'REVIEW_DISAPPROVED_STATUS' => 2,
    'AWS_SEARCH_QUERY_STRING' => 'http://search-search-yqd3wdrrvd7gipybubhnmobdli.us-east-1.cloudsearch.amazonaws.com/2013-01-01/search',
    'ERROR_LOG_FILE_500' => APPLICATION_PATH . '/../500_error.log',
    'ERROR_LOG_FILE' => APPLICATION_PATH . '/../error.log',
    'ERROR_LOG_FILE_YOUTUBE' => APPLICATION_PATH . '/../youtube_error.log',
    'TEMP_LEAD_LOG_FILE' => APPLICATION_PATH . '/../temp_lead_storage.log',
    'SEO_OPEN_GRAPH_SITE_NAME' => 'Simplilearn.com',
    'SEO_TWITTER_SITE_NAME' => '@simplilearn',
    'SEO_DEFAULT_THUMB_IMAGE_TO_SHARE' => 'https://www.simplilearn.com/ice9/free_resources_article_thumb/SIMPLILEARN_LOGO_th.jpg',
    'SEO_RDF_EBOOK_AUTHOR_SIMPLILEARN' => 'Simplilearn',
    'SEO_RDF_AUTHOR_TYPE_ORGANIZATION' => 'Organization',
    'SEO_RDF_AUTHOR_TYPE_PERSON' => 'Person',
    'SEO_RDF_LEGAL_NAME' => 'Simplilearn Americas, Inc.',
    'RESTSERVER' => 'http://api.simplilearn.com',
    'RESTENDPOINT' => '/ruser/',
    'FRESHDESK_EMAIL' => 'gsm@simplilearn.com',
    'FRESHDESK_PASSWORD' => '$impli123',
    'FRESHDESK_DOMAIN' => 'https://simplilearn.freshdesk.com',
    'FRESHDESK_SECRET_KEY' => '69c23b33746f5ede4b4374d0e38d3dd5',
    'BASE_ACCOUNTS_URL' => 'https://accounts.simplilearn.com/',
    'BASE_ACCOUNTS_API' => 'user-api/v1/',
    'ACCOUNT_INTERNAL_API_URL' => '/internal/user-api-v1/',
    'BASE_SSO_ACCOUNT_INTERNAL_API_URL' => 'internal/sso-v1/',
    'BASE_ACCOUNTS_INTERNAL_URL' => 'http://api.simplilearn.com/',
    'BASE_ACCOUNTS_INTERNAL_API' => 'ruser/',
    'SSO_CLIENT_ID' => 'sl_ice9',
    'SSO_CLIENT_SECRET' => '$S$DjybDZCLkGugpb8z5gnT4r7a4Gj4mBAmyMEtH2D4tXqcXPPaoijm',
    'SSO_COOKIE_NAME' => '_sljt',
    'FT_COOKIE_NAME' => '_slft',
    'TOKEN_ALGO' => 'HS512',
    'USER_HASH_COOKIE' => 'auh',
    'AUH_EXPIRE_TIME' => 15,
    'JWT_EXPIRE_TIME' => 90,
    'JWT_TOKEN_NAME' => '_t',
    'I9SIMPLEX_USER_MODULE_SESSION_NAME' => 'simplexModules',
    'SSO_LOG_FILE' => dirname(__FILE__).'/../frontend/sso.log',
    'ONLINE_CLASSROOM_PASS_OSL_ACCESS_DAYS' => 180,
    'LVC_PASS_DUMMY_COURSE_ID' => 503,
    'PASS_ACCESS_DAYS' => 90,
    'SEND_CLOUDX_MAIL_FLAG' => 1,
    'SEO_CITY_EXP_STATUS' => 1,
    'SEO_CITY_EXP_CONFIG' => dirname(__FILE__).'/seo-experiments/jira_3002.ini',
    'SEO_CITY_EXP_DATA' => dirname(__FILE__).'/../static/frontend/stubs/CityData.json',
    'PURGE_WEBSITE' => '/*',
    'CDN_HOST' => 'ice10-elb-1423401012.us-east-1.elb.amazonaws.com',
    'DEFAULT_COUNTRY_CODE' => 'US',
    'SSVC_TOKEN_COOKIE' => '_ttt',
    'ENTERPRISE_CART_COOKIE' => '_entp',
    'ENTERPRISE_PAYMENT_SESSION_NAMESPACE'=>'enterprise_payment',
    'ENTERPRISE_CART_ID_SALT' => '_etn@wpp#$TASL',
    'TOI_POPUP' => 1,
    'INTRO_TEXT_COUSES' => '10,15,233,630',
    'NEW_LEAD_COURSE_PREVIEW_IDS' => '9,659,18,260',
    'UERO_COUNTRIES' =>'13,14,15,16,17,18,19,20,21,22,23,29,31,38,39,40,41,42,43,44,45,46,47,48,75,89,90,97,189,119,179',
    'ACCOUNTS_B2C_GROUP_USER_ID'=>2,
    'AMBASSADOR_API_URL' => 'https://getambassador.com/api/v2/',
    'AMBASSADOR_USERNAME' => 'simplilearn',
    'AMBASSADOR_KEY' => 'ea33d9caefa527a8a828a66b49fa50f9',
    'REFERRER_PROGRAM_COUPON_CODE' => 'REF15',
    'MBSY_NAME' => 'mbsy',
  'NEW_LEAD_COURSE_PREVIEW_COOKIE' => '_cpruid',
  'NEW_LEAD_COURSE_PREVIEW_LIMIT' => 3,
  'AB_LIST_REMOVE_ACCORDION' => "",//35,279,657,662
  'BUNDLE_BLOCK_RESTRICT' => "",
    'DISQUS_SHORTNAME' =>'simplidisqus',
    'DISQUS_PREFIX'=>'',
    'DISQUS_SECRET_KEY'=>'Tb31HXmeBMNywW4dOvZ8VKIeBDkdVoTC5kT18N5xPlyJ0I1ZvrBaNR8dOhAWjv2w',
    'DISQUS_PUBLIC_KEY'=>'uxQtSBJeexaSNhWBXeAyPRYbj7zkW2feNMsNWM934G6EzOGMTF4uTzocFLbEwkR4',
    'MONGO_CONN_STR_FRS'=>'mongodb://mongo-cm-1:27017,mongo-cm-2:27017,mongo-cm-3:27017/?replicaSet=ice10-mrs',
    'MONGO_DB_FRS'=>'caldon',
    'MASTER_PASS_ACCESS_DAYS'=>365,
    'ENTERPRISE_ACCESS_DAYS'=>365,
    'DNS_FETCH_CFS22'=>'//cfs22.simplicdn.net/',
    'DNS_FETCH_CFSI10'=>'//cfi10.simplicdn.net/',
    'DNS_FETCH_CFS3'=>'//cfs3.simplicdn.net/',
    'FRS_ELEMENTS_PER_PAGE_HOME'=>10,
    'FRS_ELEMENTS_PER_PAGE_HOME_MOBILE' => 4,
    'FRS_ALL_SEGMENTS_COLLECTION_ID' => 9999,
    'FRS_ALL_SEGMENTS_COLLECTION_NAME' => "All",
    'CALDON_API'=>'http://caldon.simplilearn.com/api',
    'FRS_MINIMUM_REGISTRANTS_FOR_DISPLAY' => 30,
    'REDIRECT_FILE_301' => 'http://s3.amazonaws.com/static2.simplilearn.com/redirects/php_redirects_301.csv',
    'FRS_CARDS_FOR_MOBILE_API_HOME_PAGE' => 5,
    'FRS_SEGMENTS_OTHER_SEGMENTS_NAME' => "Other Segments",
    'FRS_SEGMENTS_OTHER_SEGMENTS_ID' => 9998,
    'FRS_SEGMENTS_DEFAULT_SEGMENT_ID_FOR_MOBILE_API' => 5,
    'REDIRECT_FILE_302' => 'http://s3.amazonaws.com/static2.simplilearn.com/redirects/php_redirects_302.csv',
    'REDIRECT_FILE_410' => 'http://s3.amazonaws.com/static2.simplilearn.com/redirects/php_status_410.csv',
    'EXPIRES_HEADER_EXCLUSION' => '$^/cart|^/help-and-support$i',
    'EXPIRES_HEADER_INTERVAL'=>19800,
    'ENABLE_COUNTRY_CODE_BASED_PAYMENTS' => "1",
    'LEAD_FORM_EXPERIMENT_COURSE_IDS' => '335,18',
    'BREADCRUMB_VENDOR_URL_EXP' => '5,15,23',
    'VPTEXT_GOOGLE' => 'Google Cloud Platform is a future proof infrastructure with powerful data and analytics committed to open source and industry leading price-performance to build better products. Google Cloud Platform certification training will help you gain knowledge to use Google\'s core infrastructure, data analytics and machine learning.Gain expertise in the platfrom from the Google accredited courses.',
    'VPTEXT_AWS' => 'Amazon Web Services is a secure cloud services platform, offering compute power, database storage, content delivery and other functionality to help businesses scale. AWS certification training helps you scale your cloud skills and gain expertise in AWS platform. AWS Technical Essentials, AWS Developer, AWS Solution Architect, AWS Sys Ops are the major courses offered.',
    'VALID_VIDEO_EXTENSIONS' => "mp4",// csv
    'USER_HASH_CLIENT_SECRET' => 'kDMfkrRYwPsJ0$2aw8IgopLT684ojvI8swP5kKK4HqIJSsFPoqoHfGD',
    'MARKETO_API_URL' => '788-AZS-915.mktorest.com',
    'MARKETO_CLIENT_ID' => 'e663399c-46ed-4a3f-8cae-8726f48194be',
    'MARKETO_CLINET_SECRET' => 'lOLxfIT6AXjs6ezHDfgnAktzPLMdd0qV',
    'COUPON_DISCOUNT_VALUE_CHECK_TYP' => 51,
    'SFA_COUNTRY' => 'US',
    'SFA_COURSE_LIST' => '10,15,630,32,34,18,184,231,233,244,291,335,387,506,594,598,621,637,652,662,670',
        'EC_COUNCIL_COURSE_LIST' => '',
    'SCHOLARSHIP_COURSE_LIST' => '10,184,15,630',
    'COURSE_TRAINER_NAME_CHECK_LIMIT' => 99,
    'WEBENGAGE_API_URL' => 'https://api.webengage.com/',
    'WEBENGAGE_API_AUTHORIZATION_KEY' => '329e5e11-c0b3-4301-8c49-e29a9fa64d79',
    'WEBENGAGE_API_LICENSE_CODE' => '311c5642',
    'WEBENGAGE_SALT' => '$!M:PlIC#@ITNn$',
    'SEGMENT_API_CODE'=> '7anMtaJ2QGICQhglMqK0GmaOUcMsk4TJ',
    'SALESFORCE_OID' => '00D28000000sMrr', // LIVE Salesforce
    'SALESFORCE_HOST' => 'https://simplilearn.my.salesforce.com/', // LIVE Salesforce
    'W2L_WHITE_LIST_DOMAINS' => 'campaign.simplilearn.com',
    'FPT_HOTLEAD_COURSES' => '10,18',
    'COUNTRY_CODE_IND' => 'IN',
    'WEBTOLEAD_SECRET_KEY_WORDPRESS' => '5oxdkNral3s=',
    'WEBTOLEAD_SECRET_KEY_MARKETO_CAMPAIGN' => 'jr4MlySCeNg=',
    'REFER_AND_EARN_MOBILE_ENABLE' => 1,
    'IS_B2B' => 0,
    'SALESFORCE_APIS_SALT' => '$!M:PlIC#@IT@NnY@$',
    'COOKIE_MARKETO_TRACK' => '_mkto_trk',
    'SF_ASSIGN_TRIGGER_VAL'=>'01Q28000000WFH8',
    'COURSE_INFO_API_COURSE_QUANTITY' => 2,
    'ENV_NO_INDEX' => 'meta-noindex',
    'UNSUBSCRIBE_EMAIL' => 'unsubscribe@simplilearn.delivery',
    'SALESFORCE_CLIENT_ID' => '3MVG9ZL0ppGP5UrDmNzl_vZRN906MdS.E5jq0EmcpGCzDl5p3uqG3309GEeptMTQDoLWx4iYiI3PQCaPx_Wuj',
    'SALESFORCE_CLIENT_SECRET' => '6243107613331339249',
    'SALESFORCE_USER_NAME' => 'apiuser@simplilearn.com',
    'SALESFORCE_PASSWORD' => 'Ap!SiMp!i@321agEIi3DOg4GeRX5guLE0rZulB',
    'SALESFORCE_LOGIN_URL' => 'https://login.salesforce.com/services/oauth2/token',
    'SALESFORCE_REDIRECT_URI' => 'https://localhost/resttest/oauth_callback.php',
    'SALESFORCE_LEAD_URL' => 'https://simplilearn.my.salesforce.com/services/apexrest/LeadAPI',
    'SALESFORCE_LEARNER_API_ENDPOINT' => 'https://simplilearn.my.salesforce.com/services/apexrest/learner',
    'SALESFORCE_OPPORTUNITY_ENDPOINT' => 'https://simplilearn.my.salesforce.com/services/apexrest/createOpportunity',
    'SALESFORCE_LMS_DATA_URL' => 'https://simplilearn.my.salesforce.com/services/apexrest/LMSUpdate',
    'SALESFORCE_LOG' => 'salesforce_lead_create.log',
    'LMSTOSFDC_LOG' => 'lms_to_sfdc.log',
    'SF_B2C_RECORD_TYPE_ID' => '01228000000ltkvAAA', // 15digit -> '01228000000ltkv',
    'SF_SL_AMERICA_RECORD_TYPE_ID' => '01228000000N4XnAAK', // 15digit -> '01228000000N4Xn',
    'SF_SL_GLOBAL_RECORD_TYPE_ID' => '01228000000N4XsAAK', // 15digit -> '01228000000N4Xs',
    'SF_SYNC_PROCESS_LIMIT' => 100,
    'SF_SYNC_MAX_ITRATION' => 3,
    'RECORD_TYPE_NAME_SL_AMERICA' => 'Simplilearn America',
    'RECORD_TYPE_NAME_SL_GLOBAL' => 'Simplilearn Global',
    'RECORD_TYPE_NAME_B2C' => 'B2C',
    'MARKETO_TEST_CAMPAIGN_ID' => '2843',
    'MARKETO_CAMPAIGN_ID_MM' => 3167, // new '3166', // Old value 2371
    'MARKETO_CAMPAIGN_ID_CONTACT_US' => 3167, // new '3167', // Old value 2207
    'MARKETO_CAMPAIGN_ID' => 3167, // new '3168', // Old value 1859,
    'MEGA_MENU_MASTER_COURSE_COUNT' => 5,
    'MEGA_MENU_MASTER_COURSE_COUNT_MOBILE' => 3,
    'MEGA_MENU_POPULAR_COURSE_COUNT' => 10,
    'MEGAMENU_LINE_CHAR_COUNT' => 42,
    'SELF_LEAD' => 'self',
    'CEH_COURSE_TO_CHANGE_TEXT' => '105',
    'STATE_GST_STRING' => 'SGST',
    'CENTRE_GST_STRING' => 'CGST',
    'INTEGRATED_GST_STRING' => 'IGST',
    'COURSE_INSTANCE_SCHEMA_COUNT' => 4,
    'TOGAF_COURSE_ID' => 184,
    'COUPON_REPLACE_TEXT' => 'coupon_code',
    'TAG_NAME_LEAD_CREATE' => 'na-payment',
    'SITE_MODULE_TOLLFREE' => 'Tollfree',
    'LEAD_FROM_SL' => 'SL-Website',
    'SITE_MODULE_GSA_QUERY_BOX' => 'GSA_Query Box',
    'SITE_MODULE_MOM_QUERY_BOX' => 'Query Box',
    'SITE_MODULE_GSA_BROCHURE' => 'GSA_Brochure',
    'JOB_ASSIST_MASTERS_PROGRAMS' => '72,67,23,84,80,105,111,112',
    'JOB_ASSIST_MASTERS_COURSES' => '233,230,15,630,684,670,704,262,687,795,105',
    'FREE_TRIAL_DAYS' => 7,
    'FT_UTM_BLOCKED' => 'ir,shareasale,cj,awin',
    'FT_ATP_PARAM' => 'ft_atp',
    'ADD_HREFLANGS_TOPAGE'=> 0,
    'MONGO_COLLECTION_LECTUREPAGECOLLECTION' => 'LecturePagesNew',
    'MONGO_COLLECTION_CONTENTSCOLLECTION' => 'contents',
    'MONGO_COLLECTION_CONTENTSTATSCOLLECTION' => 'content-stats',
    'EMAIL_QUERY_TEXT' => 'In case of queries, please visit our Help and Support page. Here you can read the FAQs or raise a ticket to our Support team for faster resolution. We are happy to help you!',
    'DEFAULT_COURSE_DISCOUNT_RANGE' => '0-100',
    'FREE_COURSE_DISCOUNT_RANGE' => '0-100',
    'S3_PAYMENT_DOC_PATH' => 'payment_doc/production/',
    'S3_PAYMENT_AWS_PATH' => 'http://s3.amazonaws.com/static2.simplilearn.com',
    'SITE_SPEED_SAMPLE_RATE' => 20,
    'DEFAULT_LOCALE' => 'en-US',
    'EVENT_BRITE_TOKEN' =>'OTWKDMPAIAYTWORKXHY2',
    'GDPR_COOKIE_NAME'=>'_gdpr_user_consent',
    'ENTERPRISE_GDPR_COOKIE_NAME'=>'_enterprise_gdpr_user_consent',
    'PAYMENT_SSO_LOGIN' =>  'sl_salesforce',
    'SSO_VERIFIED_USER_COOKIE'=> '_sso_verified_user',
    'COUNTRY_CODE_ROW'=>'ROW',
    'TRANSLATED_SITE'=>'br',
    'DEFAULT_COUNTRY_CODE_HREF'=>'default',
    'CLOUD_SEARCH_TIMEOUT' => 100, // in ms
    'GOOGLE_CONTACT_CLIENT_ID' => '520546642335-6qjaqikonh86sd9gu8f8huoq9km33ti2.apps.googleusercontent.com',
    'GOOGLE_CONTACT_API_KEY' => 'AIzaSyBrn8DGQOCiUPfHx-6ki-3VR4kdhwiAqFA',
    'GOOGLE_OPTIMIZE_COURSE_ID' => '4,256,b72',
    'NEW_VERSION_COURSE_PAGES' => '670,10,15,260,34,32',
    'REACT_COURSE_PAGES' => '670,10,15,260',
    'GA_CODE_OPTIMIZE' => 'UA-32079340-5',
    'ACCESS_CONTROL_ALLOW_ORIGIN_REACT'=>false,
    'KAFKA_CONN_URL' =>'https://services.simplilearn.com/events/kafka/website-events',
    'ENTERPRISE_MAIN_URL' => 'https://enterprise.simplilearn.com',
    'B2B_IDENTIFIER' => '/partners',
    'LEADAPIGATEWAYENDPOINT'=>'https://services.simplilearn.com/leads/store-raw-data/',
    'LEADAPIUPDATEENDPOINT'=>'https://services.simplilearn.com/leads/update-lead/',
    'FPT_PAGEVIEWD_COOKIENAME' =>'fptpvstatus',
    'FPT_LEADGENERATED_COOKIENAME'=>'fptleadId',
    'LEADTEAMCOLD'=>'cold',
    'LEADTEAMHOT'=>'hot',
    'LEADTEAMMQL'=>'mql',
    'HOME_PAGE_TYPE'=>'home',
    'ABOUT_US_PAGE_TYPE'=>'about us',
    'CONTACT_US_PAGE_TYPE'=>'contact us',
    'SEARCH_DEFAULT_IMAGE_ARTICLE' => 'https://www.simplilearn.com/ice9/free_resources_article_thumb/FRSdefault.jpg',
    'SEARCH_DEFAULT_IMAGE_EBOOK' => 'https://www.simplilearn.com/ice9/free_resources_article_thumb/ebook.jpg',
    'SEARCH_DEFAULT_IMAGE_WEBINAR' => 'https://www.simplilearn.com/ice9/free_resources_article_thumb/FRSwebinar.jpg',
    'AFFIRM_PUBLIC_KEY'=>'UB33O6FB3N29J0AE',
    'AFFIRM_JS_URL'=>'https://cdn1.affirm.com/js/v2/affirm.js',
    'AFFIRM_ALLOWED_COUNTRY_SEAMLESS_PAYMENT'=>'US',
    'AFFIRM_APPLICABLE_COUNTRY_ID'=>34,
    'AFFIRM_SKIP_TRAINING_TYPE'=>"2",
    'AFFIRM_USD_CENTS'=>100,
    'JOB_SALARIES_API' => 'https://m8olzk5bm7.execute-api.us-east-1.amazonaws.com/production/fetch-salary-data',
    'AFFIRM_APPLICABLE_OSL_CATEGORY'=>"2",
    'AFFIRM_APPLICABLE_OSL_COURSEIDS'=>"17,18,19,20,21,22,25,26,27,28,29,30,31,184,316,453,887,989,990,1176,1177",
    'PRE_CHAT_DISABLE_COURSES' => '694',
    'REMOVED_COURSES_EXCEPTION'=>'34,105,244,42,32,1300,1147,1145,1146,863,910', //Zest enabled course Ids
    'REMOVED_BUNDLES_EXCEPTION'=>'23,127,101,184',
    'REMOVED_CLASSROOM_EXCEPTION'=>'766',
    'NO_COST_EMI_INDIA_PRICE_LIMIT'=> '15000',
    'ZEST_MONEY_LIMIT' => 15000,
    'ZEST_MONEY_UPPER_LIMIT' => 300000,
    'EDUVANZ_UPPER_LIMIT' => 300000,
    'ZEST_MONEY_DISCOUNT_LIMIT' => 15.25,
    'ZEST_MONEY_DISCOUNT_UPPER_LIMIT' => 27000,
    'OPTIMIZE_CONTAINER_ID'=>'GTM-K965XM7',
    'GA_EXPERIMENT_IDS'=>'10:60255365-55,15:60255365-56,670:60255365-57,260:60255365-58',
    'DISABLE_CAT_IDS_POPUP'=>"10,33,34,35",
    'REACT_CITY_COURSE_IDS' => "244,687,34,659,1176,335,291,387,684,233,261,105,32,18,795,1116,1160,898,1146,704,630,259,42,184,231,827,828,694,832,10,260,670,15,1,2,7,9,19,20,22,26,27,29,30,35,88,165,594,621,637,664,677,863,869,910,922,930,1145,1147,1300,4,5,337,765,766,864,865,866,867,919,921,1052,1391,1425",
    'BAJAJ_FINSERV_EMI_MONTHS' => '3,5,9',
    'MONEY_BACK_GUARANTEE_TEXT_LIMIT' => 700,
    'ENTITY_TYPE_FOR_ENTERPRISE_COURSE_MAPPING' => 1,
    'ENTITY_TYPE_FOR_ENTERPRISE_BUNDLE_MAPPING' => 2,
    'GOOGLE_API_KEY' => 'AIzaSyByCCJJ1I1oOJ5MFvVUxE2tnIcDgW09aac',
    'BAJAJ_ENABLE_COURSESIDS' => '105,910',
    'COUPON_CODE_MOBILE'=>'mobile',
    'PURGE_URL_API_ENDPOINT'=>'https://m8olzk5bm7.execute-api.us-east-1.amazonaws.com/production/create-purge-tasks',
    'GOOGLE_SHEET_ID'=>'1JdpcBjnjPFimXctxdFyPBb6oTszr3hKQ0uiVmfNKeGo',
    'GOOGLE_SHEET_TAB_1'=>'Auto Approved',
    'FOOTERLINKLIMIT'=>10
  ),
    'cta_text' => array(
        'emi' => array('countries' => array(6),'text' => 'EMI Option Available'),
        'vat' => array('countries' =>  array(14), 'text' => '* VAT Included'),
    ),
  'autoloaderNamespaces' =>
  array (
    0 => 'BaseApp_',
  ),
  'referandearnmail' =>
  array (
    'host' => 'smtp.mandrillapp.com',
    'params' =>
    array (
      'auth' => 'login',
      'username' => 'linus@simplilearn.com',
      'password' => 'HnVY6dfYVFIp0lT6Zy1Mbw',
      'port' => '587',
    ),
    'sender_email' => 'no-reply@simplilearnmail.com',
    'sender_name' => 'Simplilearn',
  ),
  'device' =>
  array (
    'compatibility' =>
    array (
      'Windows' => 1,
      'MAC' => 2,
      'iOS' => 4,
      'Android' => 8,
    ),
  ),
  'elearning_compatibility' =>
  array (
    'status' =>
    array (
      0 => 'Not Supported',
      1 => 'Partially Supported',
      2 => 'Supported',
    ),
  ),
  'testimonial_mailer' =>
  array (
    'emailIds' =>
    array (
      0 => 'coders.i9@simplilearn.com',
    ),
  ),
  'search_mailer' =>
  array (
    'emailIds' =>
    array (
      0 => 'category@simplilearn.com',
      1 => 'product@simplilearn.com',
    ),
  ),
  'limit_js' =>
  array (
    0 => 'course',
    1 => 'bundle',
    2 => 'label',
    3 => 'vendor',
    4 => 'search',
    5 => 'cityCourse',
    6 => 'home',
  ),
  'awscloudsearch' =>
  array (
    'aws_cloudsearch_key' => 'AKIAJ6SJYDFOXWU6SFMA',
    'aws_cloudsearch_secret_key' => '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',
    'endpoint' => 'http://search-search-yqd3wdrrvd7gipybubhnmobdli.us-east-1.cloudsearch.amazonaws.com',
    'version' => '2013-01-01',
  ),
  'search' =>
  array (
    'default_selected' =>
    array (
      0 => 'course',
      1 => 'bundle',
    ),
    'enable_default_select' => 1,
  ),
  'lvc_pass_webx_user_data' =>
  array (
    12345 => 'test',
  ),
  'android_version_data' =>
  array (
    'version_number' => '9.8.0',
    'version_code' => 179,
    'is_force_update' => 1,
  ),
  'ios_version_data' =>
  array (
    'version_number' => '6.0',
    'version_code' => 34,
    'is_force_update' => 1,
  ),
  'blacklist' =>
  array (
    'referers' =>
    array (
      0 => 'onclickads.net',
    ),
  ),
  'globalmessage' =>
  array (
    'enabled' => 0,
    'start' => '2016-01-19 07:30:00',
    'interval' => '12 hours 0 seconds',
    'message' => 'Simplilearn is under maintenance for some time. During this time purchases and login will be affected. Sorry for the inconvenience!',
  ),
  'ONLINE_CLASSROOM_PASS_ACCESS_DAYS' =>
  array (
    0 => 90,
  ),
  'EXCLUDE_ACCESS_DAYS_MASTER' =>
  array(
    0 => 30,
    1 => 60,
    2 => 3,
    3 => 10
  ),
  'LVC_BUNDLE_ACCESS_DAYS' => array(
        365 => 365,
   ),
  'popular_courses' =>
  array (
    0 => 10,
    1 => 105,
    2 => 15,
    3 => 156,
    4 => 18,
    5 => 184,
    6 => 2,
    7 => 231,
    8 => 268,
    9 => 279,
    10 =>291,
    11 =>325,
    12 =>335,
    13 =>34,
    14 =>4,
    15 =>43,
  ),
  'master_program_promo_voucher_text' => array(
                                                 '34'=>'*Use the code USMINI to avail an iPad Mini.',
                                                 '35'=>'*Use the code USMINI to avail an iPad Mini.',
                                                 '36'=>'*Use the code USMINI to avail an iPad Mini.',
                                                 '6'=>'*Use the code INMINI to avail an iPad Mini.',
                                                 '14'=>'*Use the code ROMINI to avail an iPad Mini.',
                                                 '24'=>'*Use the code ROMINI to avail an iPad Mini.',
                                                 '30'=>'*Use the code ROMINI to avail an iPad Mini.',
                                                 '62'=>'*Use the code ROMINI to avail an iPad Mini.',
                                                 '61'=>'*Use the code ROMINI to avail an iPad Mini.'
                                                ),
  'webinar' =>
  array (
   'consumer'=>array('simplilearn@gmail.com'=>'pDcV1PzgmDEJqL2bTAGH2aWCA3ZKGmSs','webinar.1@simplilearn.com'=>'ftwGbngfF0tZ5y6oBDRuFrXGLaCbziKM','webinar.2@simplilearn.com'=>'ujJJUZFARKGSIenj4bjUCAoWhsFyOh5N','mark.promo@simplilearn.com'=>'0nBiQduQiz9f0kSYdfC33b8RO7wTPsB9'),
   'password'=>array('simplilearn@gmail.com'=>'webinar@simplilearn123','webinar.1@simplilearn.com'=>'webinarsimpli@123','webinar.2@simplilearn.com'=>'webinarsimpli@123','mark.promo@simplilearn.com'=>'webinarsimpli@123'),
   'organizer'=>array('simplilearn@gmail.com'=>'7732484106959502598','webinar.1@simplilearn.com'=>'7085645829846781702','webinar.2@simplilearn.com'=>'1413461055220141830','mark.promo@simplilearn.com'=>'3193581375725629708'),
  ),
    'mbsyconfig' =>
    array(
        'group_id'=>array('US'=>1,'IN'=>2,'ROW'=>1),
        'camp_id'=>array('US'=>31227,'IN'=>31163,'ROW'=>31227),
        'coupon_code'=>array('US'=>'REFER20','IN'=>'REFER20','ROW'=>'REFER20')
    ),
    'mbsyconfigmobileandroid' =>
    array(
        'group_id'=>array('US'=>1,'IN'=>2,'ROW'=>1),
        'camp_id'=>array('US'=>31227,'IN'=>31163,'ROW'=>31227),
        'coupon_code'=>array('US'=>'REFER20','IN'=>'REFER20','ROW'=>'REFER20')
    ),
    'mbsyconfigmobileios' =>
    array(
        'group_id'=>array('US'=>1,'IN'=>2,'ROW'=>1),
        'camp_id'=>array('US'=>31227,'IN'=>31163,'ROW'=>31227),
        'coupon_code'=>array('US'=>'REFER20','IN'=>'REFER20','ROW'=>'REFER20')
    ),
    'trainermbsyconfig' =>
    array(
        'group_id'=>array('US'=>4,'IN'=>3,'ROW'=>4),
        'camp_id'=>array('US'=>31695,'IN'=>31694,'ROW'=>31695)
    ),
    'countryDropdownCountryList' => array (
        'IN','US','CA','MX'
    ),
    // 'surveyData' =>
    // array(
    //     '33l155j'=>array('lead_team'=>'mql','sl_lead_type'=>'b2b','sl_site_module'=>'b2bsitetest'),
    //     '~5g1cid8'=>array('lead_team'=>'mql','sl_lead_type'=>'b2c','sl_site_module'=>'Video_lesson_popup'),
    //     '33l15jo'=>array('lead_team'=>'mql','sl_lead_type'=>'b2c','sl_site_module'=>'Video_lesson_popup'),
    //     '~162i617'=>array('lead_team'=>'mql','sl_lead_type'=>'b2c','sl_site_module'=>'bundle_agenda_exit_popup'),
    //     '~162i61a'=>array('lead_team'=>'mql','sl_lead_type'=>'b2c','sl_site_module'=>'bundle_agenda_exit_popup'),
    //     '~5g1cho3'=>array('lead_team'=>'hot','sl_lead_type'=>'b2c','sl_site_module'=>'Course_page_offer_popup'),
    //     '7djkhjj'=>array('lead_team'=>'hot','sl_lead_type'=>'b2c','sl_site_module'=>'Course_page_offer_popup'),
    //     '~5g1ci03'=>array('lead_team'=>'mql','sl_lead_type'=>'b2c','sl_site_module'=>'Video_lesson_popup'),
    //     '7djkhii'=>array('lead_team'=>'mql','sl_lead_type'=>'b2c','sl_site_module'=>'Video_lesson_popup'),
    //     '33l15kj'=>array('lead_team'=>'mql','sl_lead_type'=>'b2c','sl_site_module'=>'Video_lesson_popup'),
    //     '~162i624'=>array('lead_team'=>'mql','sl_lead_type'=>'b2c','sl_site_module'=>'Video_lesson_popup'),
    //     '7djkhij'=>array('lead_team'=>'mql','sl_lead_type'=>'b2c','sl_site_module'=>'Video_lesson_popup'),
    //     '33l15kk'=>array('lead_team'=>'mql','sl_lead_type'=>'b2c','sl_site_module'=>'Video_lesson_popup'),
    //     '~162i61o'=>array('lead_team'=>'mql','sl_lead_type'=>'b2c','sl_site_module'=>'Video_lesson_popup'),
    //     '7djkh6d'=>array('lead_team'=>'hot','sl_lead_type'=>'b2c','sl_site_module'=>'Course_page_offer_popup'),
    //     '~5g1cic9'=>array('lead_team'=>'hot','sl_lead_type'=>'b2c','sl_site_module'=>'Course_page_offer_popup'),
    //     '~5g1cibl'=>array('lead_team'=>'mql','sl_lead_type'=>'b2c','sl_site_module'=>'Ebook_popup'),
    //     '7djkh71'=>array('lead_team'=>'mql','sl_lead_type'=>'b2c','sl_site_module'=>'Ebook_popup'),
    //     '~162i6e7'=>array('lead_team'=>'mql','sl_lead_type'=>'b2c','sl_site_module'=>'Ebook_popup'),
    //     '33l1592'=>array('lead_team'=>'mql','sl_lead_type'=>'b2c','sl_site_module'=>'Video_lesson_popup'),
    //     '~162i6dl'=>array('lead_team'=>'mql','sl_lead_type'=>'b2c','sl_site_module'=>'Video_lesson_popup'),
    //     '~5g1cibk'=>array('lead_team'=>'mql','sl_lead_type'=>'b2c','sl_site_module'=>'Video_lesson_popup'),
    //     '7djkh72'=>array('lead_team'=>'mql','sl_lead_type'=>'b2c','sl_site_module'=>'Video_lesson_popup'),
    //     '33l1593'=>array('lead_team'=>'mql','sl_lead_type'=>'b2c','sl_site_module'=>'Video_lesson_popup'),
    //     "~5g1ci89"=>array("lead_team" => "mql","sl_lead_type" => "b2c","sl_site_module" => "Video_lesson_popup"),
    //     "~162i6aa"=>array("lead_team" => "mql","sl_lead_type" => "b2c","sl_site_module" => "Video_lesson_popup"),
    //     "33l15cd"=>array("lead_team" => "mql","sl_lead_type" => "b2c","sl_site_module" => "Video_lesson_popup"),
    //     "7djkhac"=>array("lead_team" => "mql","sl_lead_type" => "b2c","sl_site_module" => "Video_lesson_popup"),
    //     "~5g1ci8a"=>array("lead_team" => "mql","sl_lead_type" => "b2c","sl_site_module" => "Video_lesson_popup"),
    //     "~162i6ab"=>array("lead_team" => "mql","sl_lead_type" => "b2c","sl_site_module" => "Video_lesson_popup"),
    //     "33l15co"=>array("lead_team" => "mql","sl_lead_type" => "b2c","sl_site_module" => "Video_lesson_popup"),
    //     "~162i6a6"=>array("lead_team" => "hot","sl_lead_type" => "b2b","sl_site_module" => "B2B-ebook")
    // ),
    'cloudinary' =>
        array (
          "cloud_name" => "dslvjnnzk",
          "api_key" => "763337412781227",
          "api_secret" => "SpQXXuyn6vHUcMqeuWee9uLSezk"
        ),
);
// print_r($config['production']);

// ---------------------------------------------------------
// PRODUCTION_ONEDOMAIN ENV
// ---------------------------------------------------------
$config['production_onedomain'] = array (
  'phpSettings' =>
  array (
    'display_startup_errors' => '0',
    'display_errors' => '0',
    'date' =>
    array (
      'timezone' => 'Asia/Calcutta',
    ),
    'session' =>
    array (
      'cookie_domain' => HOST,
    ),
  ),
  'resources' =>
  array (
    'frontController' =>
    array (
      'params' =>
      array (
        'displayExceptions' => '0',
      ),
            'controllerDirectory' => APPLICATION_PATH . '/controllers',
            'moduleDirectory' => APPLICATION_PATH . '/modules',
      'actionHelperPaths' =>
      array (
        'BaseApp_Action_Helper' => 'BaseApp/Action/Helper',
      ),
    ),
    'layout' =>
    array (
      'layoutPath' => APPLICATION_PATH . '/layouts/scripts/',
    ),
    'db' =>
    array (
      'adapter' => 'pdo_mysql',
      'params' =>
      array (
        'host' => 'i2rds.cuoivis0lb68.us-east-1.rds.amazonaws.com',
        'dbname' => 'ice9',
        'username' => 'simpli_web',
        'password' => 'SLPortal@2010',
        'driver_options' =>
        array (
          1002 => 'SET NAMES utf8, time_zone = \'+5:30\';',
        ),
        'profiler' => '0'
      ),
    ),
    'mail' =>
    array (
      'transport' =>
      array (
        'type' => 'smtp',
        'host' => 'email-smtp.us-east-1.amazonaws.com',
        'auth' => 'login',
        'username' => 'AKIAIWIEDLFCJWCS2T5A',
        'password' => 'Ahgm0YT24d1oTmm+pFLD9owlmHX7P4TA0/WTg4UV1gaL',
        'ssl' => 'tls',
        'port' => '587',
        'register' => '1',
      ),
            'simplilearncourses' =>
                        array(
                                'type' => 'smtp',
                                'host' => 'email-smtp.us-east-1.amazonaws.com',
                                'auth' => 'login',
                                'username' => 'AKIAJ5SMLYHJ2ZSQ52DA',
                                'password' => 'Ailc/Los3sr/zbGDDMesiyMFmeLGhC9LNZBBRUH4KX8c',
                                'ssl' => 'tls',
                                'port' => '587',
                                'register' => '1',
                                'sender_email' => 'mailer@simplilearncourses.com',
                                'sender_name' => 'Simplilearn Courses',
                                'reply_to_email' => 'mailer@simplilearncourses.com',
                        ),
    ),
    'log' =>
    array (
      'stream' =>
      array (
        'writerName' => 'Stream',
        'writerParams' =>
        array (
          'stream' => APPLICATION_PATH . '/../error.log',
          'mode' => 'a+',
        ),
        'formatterName' => 'Simple',
        'formatterParams' =>
        array (
          'format' => '
%timestamp% %priorityName% (%priority%): %message%
%info%
--

',
        ),
      ),
    ),
  ),
  'salesforce' => array(
        'SF_USERNAME' => "apiuser@simplilearn.com",
        'SF_PASSWORD' => "Ap!SiMp!i@321agEIi3DOg4GeRX5guLE0rZulB",
        'WSDL_FILE_NAME' => "/enterprise_v3.wsdl.xml",
    ),
  'includePaths' =>
  array (
    'library' => APPLICATION_PATH . '/../library',
  ),
  'bootstrap' =>
  array (
    'path' => APPLICATION_PATH . '/Bootstrap.php',
    'class' => 'Bootstrap',
  ),
  'appnamespace' => 'BaseApp',
  'constants' =>
  array (
    'WEBSITE_MAIN_URL' => 'https://www.simplilearn.com', //only used for og url
    'FRONTEND_URL' => 'https://'.HOST,
    'FRONTEND_CANONICAL_URL' => 'https://'.HOST,
    'FRONTEND_CANONICAL_URL_SECURE' => 'https://'.HOST,
    'FRONTEND_API_URL' => '//'.HOST.'/api/v1',
    'FRONTEND_API_URL_NOCACHE' => '//'.HOST.'/api/v1/index/nocache',
    'SITE_API_URL_NOCACHE' =>  'https://'.HOST.'/api/v1/index/nocache',
    'FRONTEND_CDN_API_URL' => '//'.HOST.'/api/v1?method=',
    'FRONTEND_NON_CDN_API_URL' => '//'.HOST.'/api/v1?method=',
    'SEO_FRONTEND_URL' => 'https://'.HOST,
    'FREE_RESOURCES_CDN_URL' => 'https://'.HOST.'/ice9/',
    'FRONTEND_REL_PATH' => '',
    'FRS_DEFAULT_THUMBNAIL_ARTICLE' => 'https://'.HOST.'/ice9/free_resources_article_thumb/Article.svgz',
    'FRS_DEFAULT_VERTICAL_THUMBNAIL_EBOOK' => 'https://'.HOST.'/ice9/ebooks/ebook_2.svgz',
    'FRS_DEFAULT_THUMBNAIL_EBOOK' => 'https://'.HOST.'/ice9/ebooks/ebook.svgz',
    'SEO_DEFAULT_THUMB_IMAGE_TO_SHARE' => 'https://'.HOST.'/ice9/free_resources_article_thumb/SIMPLILEARN_LOGO_th.jpg',
    'SEO_DEFAULT_COURSE_THUMB_IMAGE' => 'https://'.HOST.'/ice9/course_images/course_thumbnail_default.png',
    'FRS_WEBINAR_DEFAULT_ICON' => 'https://'.HOST.'/ice9/webinar_thumb_images/226x182/default_icon-webinar.svg',
    'FRS_DEFAULT_400x225_IMAGE' => 'https://'.HOST.'/ice9/review_images/400x225.png',
    'FRS_DEFAULT_140x140_IMAGE' => 'https://'.HOST.'/ice9/review_images/140x140.png',
    'SALESFORCE_LEAD_WEBSITE' => 'https://'.HOST.'/',
    'META_IMAGE' => 'http://'.HOST.'/logo.png',
    'EMAIL_TEMPLATE_DIR' => APPLICATION_PATH . '/../../templates/email/',
    'SEND_EMAIL_ID' => 'no-reply@simplilearn.net',
    'SENDER_NAME' => 'Simplilearn',
    'REPLYTO_EMAIL_ID' => 'support@simplilearn.com',
    'REPLYTO_NAME' => 'Simplilearn Support',
    'CONTACT_US_EMAIL' => 'corporate@simplilearn.com',
    'CORPORATE_SALES_EMAIL' => 'corporatesales@simplilearn.com',
    'CORPORATE_SALES_EMAIL2' => 'corpsales@simplilearn.com',
    'ATP_EMAIL' => 'partner@simplilearn.com',
    'BLOG_EMAIL' => 'promos@simplilearn.com',
    'AFFILIATE_EMAIL' => 'affiliate@simplilearn.com',
    'TRAINER_EMAIL' => 'teach@simplilearn.com',
    'US_COUNTRY_ID' => '34',
    'INDIA_COUNTRY_ID' => '6',
    'AUS_COUNTRY_ID' => '2',
    'UK_COUNTRY_ID' => '14',
    'SHOW_STATIC_HEADER' => '1',
    'DEFAULT_COUNTRY_TIME_ZONE' => 'Europe/London',
    'WEBEX_EMAIL_ID' => 'messenger@webex.com',
    'SUBSCRIPTION_CONVERSION_FACTOR' => '63',
    'SUBSCRIPTION_IND_CURRENCY_ID' => '6',
    'CLUSTER_ID_AMERICAS' => '6',
    'ACCOUNTS_PATH' => 'https://accounts.simplilearn.com',
    'IOS_RECEIPT_VALIDATION_URL' => 'https://buy.itunes.apple.com/verifyReceipt',
    'LOG_FORMAT' => '
%timestamp% %priorityName% (%priority%): %message%
%info%
--
',
    'MELVIN_DB_HOST' => 'i2rds.cuoivis0lb68.us-east-1.rds.amazonaws.com',
    'MELVIN_DB_USERNAME' => 'simpli_web',
    'MELVIN_DB_PASSWORD' => 'SLPortal@2010',
    'MELVIN_DB_NAME' => 'melv1n_crm2',
    'MAIN_CDN_URL' => 'https://'.HOST_STATIC.'/static',
    'STATIC_URL' => 'https://static.simplilearn.com',
    'SEND_OUT_OF_MEMORY_EMAIL' => 1,
    'BASE_LMS_URL' => 'https://lms.simplilearn.com/',
    'LMS_DOMAIN' => 'lms.simplilearn.com',
    'CRM_URL' => 'https://xenia.simplilearn.com',
    'SSVC_URL' => 'https://www.simplilearn.com/secure/',
    'BACKEND_URL' => 'http://i9simplex.simplilearn.com',
        'MM_FRONTEND_URL' => 'https://www.marketmotive.com',
    'BASE_LMS_API_URL' => 'api/v1/',
    'BASE_LMS_API_URL_V2' => 'api/v2/',
    'BASE_LMS_API_INTERNAL_URL' => 'api/internal/',
    'BASE_LMS_CERTIFICATE_URL' => 'user/certificate/download/crtoken/',
    'BASE_LMS_MANAGE_SUBSCRIPTION_URL' => 'user/profile/manage-subscription',
    'REL_LOCAL_URL' => '../../static',
    'SIMPLEX_MAINTENANCE' => 0,
    'BACKEND_ROWS_PER_PAGE' => 3,
    'CMO_SPEAK_COURSE_DMCA' => 630,
    'FRONTEND_CDN_API_ENABLE' => 1,
    'FRONTEND_API_SERVER_CACHE_ENABLE' => 1,
    'FRONTEND_CDN_API_CACHE_BUST_ID' => 5,
    'FRONTEND_CDN_API_URL_TIMEOUT' => '14400',
    'SYNC_DB_NAME' => 'sync',
    'MELVIN_DB' => 'melv1n_crm2',
    'STUB_DIR' => APPLICATION_PATH . ' ../../static/frontend/js/',
    'IMAGE_CDN_URL' => '',
    'VIDEO_CDN_URL' => '',
    'MONGO_CONN_STR' => 'mongodb://mongo-cm-1:27017,mongo-cm-2:27017,mongo-cm-3:27017/?replicaSet=ice10-mrs',
    'MONGO_DB' => 'ice9',
    'CLOUD6_DB' => 'cloud6_atlas',
    'GOOGLE_CLIENT_ID' => '157934410265-3tqcftt9b1501amu8qv0v6i7dnravluj.apps.googleusercontent.com',
    'GOOGLE_SECRET_KEY' => 'L5aCxYOGfGr69x0xAOHYJ_ek',
    'LINKED_IN_API_KEY' => '75g24gm5c4yble',
    'TOOLS_DEVOPS_COURSE_ID' => '704',
    'TOOLS_CEH_COURSE_ID' => '105',
    'TOOLS_MKTNG_BUNDLE_ID' =>  'b23',
    'TOOLS_MKTNG_BUNDLE_ID_SEO' =>  'b69',
    'TOOLS_MKTNG_BUNDLE_ID_SM' =>  'b70',
    'TOOLS_MKTNG_BUNDLE_ID_PPC' =>  'b71',
    'FB_APP_ID' => 507379152611585,
    'DATE_FORMAT' => 'Y-m-d',
    'IP_ADDRESS_ALLOW_OVERRIDE' => 1,
    'IP_ADDRESS_MIN' => 16777216,
    'IP_ADDRESS_MAX' => 3758096383,
    'SSVC_DATABASE' => 'ssvc',
    'UPLOAD_CDN_URL' => 'https://www.simplilearn.com',
    'AFFILIATE_COOKIE_NAME' => '__utmz',
    'CONVERSION_RATIO_FROM_AUD' => 0.9,
    'CONVERSION_RATIO_FROM_INR' => 0.0167,
    'CONVERSION_RATIO_FROM_GBP' => 1.282,
    'FORMATTED_CURRENCY_FOR_AUS' => 'AUD',
    'FORMATTED_CURRENCY_FOR_US' => 'USD',
    'FORMATTED_CURRENCY_FOR_IN' => 'INR',
    'FORMATTED_CURRENCY_FOR_GB' => 'GBP',
    'CURRENCY_FOR_AUS' => 'AUD',
    'CURRENCY_FOR_US' => 'USD',
    'CURRENCY_FOR_GB' => 'GBP',
    'CURRENCY_FOR_ONLY_US' => '$',
    'CURRENCY_FOR_IN' => 'Rs.',
    'CURRENCY_FOR_ONLY_UK' => '&pound;',
    'COUNTRY_LINE_DIVIDER' => 10,
    'COURSE_TYPE_FOR_CLASSROOM' => 'Classroom',
    'COURSE_TYPE_FOR_ONLINE' => 'Online Self Learning',
    'TRAINING_TYPE_FOR_ONLINE' => 'online',
    'TRAINING_TYPE_FOR_CLASSROOM' => 'classroom',
    'TRAINING_TYPE_FOR_LVC' => 'lvc',
    'ATP_FORM_DEFAULT_COURSE_ID' => 10,
    'ATP_FORM_DEFAULT_COURSE_NAME' => 'PMP',
    'WEB_ENGAGE_ID' => '311c5642',
    'GOOGLE_TAG_MANAGER_CODE' => 'GTM-WTL3CF',
        'DUKE_INTEGRATED_BUNDLE_ID' => '', //Bundle Id for Duke integrated prog.Add b for each id
        'INTEGRATED_PROG_STEP_FORM_URL' => '/webforms/integrated-program-form-details-to-fill',
        'INTEGRATED_PROG_FORM_ADD_CRT_TIME' => 3600,
    'AD_ELEMENT_PRODUCT_TYPE_COURSE' => 1,
    'AD_ELEMENT_PRODUCT_TYPE_BUNDLE' => 2,
    'GOOGLE_ANALYTICS_CODE' => (!empty($_SERVER['HTTP_HOST']) && strpos($_SERVER['HTTP_HOST'],'.net') !== false) ? 'UA-32079340-9':'UA-32079340-1',
        'GOOGLE_ANALYTICS_CODE_FRS' =>'UA-32079340-5',
    'GOOGLE_ANALYTICS_DOMAIN_NAME' => (!empty($_SERVER['HTTP_HOST']) && strpos($_SERVER['HTTP_HOST'],'.net') !== false) ? 'simplilearn.net':'simplilearn.com',
    'PINGDOM_CODE' => '5561ef85abe53d2b3caa542f',
    'ORIGIN_COOKIE_NAME' => '__utmz',
    'FIRST_ORIGIN_COOKIE_NAME' => 'simplilearn_custom',
    'COOKIE_FIRST_PAGE' => 'simplilearn_first_page',
    'COOKIE_FIRST_PAGE_TIME' => 'simplilearn_landing_time',
    'API_CACHE_TTL' => 3600,
    'REFERRAL_COOKIE_NAME' => 'referral_id',
    'DEFAULT_CURRENCY_COUNTRY_ID' => 34,
    'YOUTUBE_EMBED_PARAMS' => 'html5=1&enablejsapi=1&modestbranding=1&rel=0&autohide=1&iv_load_policy=3&wmode=transparent&showinfo=0&cc_load_policy=1',
    'META_TITLE' => 'Online and Classroom Training for Professional Certification Courses | Simplilearn',
    'META_DESCRIPTION' => 'Enroll for PMPÃ‚Â® certification training in Delhi.  Attend world renowned PMPÃ‚Â® classroom training organized by Simplilearn',
    'META_KEYWORDS' => 'Online classes, Online courses, Free online courses, Online Certification, Online tutoring, Online Training, Certification programs, Microsoft Certification, Cisco Certification, IT Service management',
    'CACHE_ENABLED' => 1,
    'PROFILER_ENABLED' => (in_array('118.102.154.209', $remoteIpArr) && $_SERVER['HTTP_HOST'] == 'i10www.simplilearn.com' && isset($_GET['profiler']) && $_GET['profiler'] == '1') ? '1' : '0',
    'PROFILER_HIDDEN' => (in_array('118.102.154.209', $remoteIpArr) && $_SERVER['HTTP_HOST'] == 'i10www.simplilearn.com' && isset($_GET['profiler']) && $_GET['profiler'] == '1') ? '0' : '1',
    'CACHE_TTL' => 4800,
    'CACHE_CLEAR_PARAM_NAME' => 'clear_cache',
    'CACHE_CLEAR_PARAM_VALUE' => 'now',
    'CACHE_REFRESH_PARAM_NAME' => 'refresh_key_cache',
    'CACHE_TYPE' => 'memcached',
    'CACHE_MEMCACHED_HOST' => 'i9-memcache-server.yx2u3w.cfg.use1.cache.amazonaws.com',
    'CACHE_MEMCACHED_PORT' => 11222,
    'FOR_BUSINESS_LINK' => 'http://enterprise.simplilearn.com/?_r=hdr',
    'PLACEHOLDER_IMG' => 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7',
    'ADD_THIS_WIDGET_ID' => 'ra-5492db360575da40',
    'DEFAULT_COUNTRY_ID' => 34,
    'REVIEWS_LIMIT' => 10,
    'SSVC_PROVIDER_KEY' => 'vdss209csad0g9j2fasefse09r8grs4',
    'SSVC_PROVIDER_KEY_WPP' => 'vdss209csad0g9j2fasefse09etnprri',
    'COMBINE_ALL_JS' => 1,
    'AWS_S3_SECRET_KEY' => 'mMLafyybV7FfayM31n5zv2lS3MZFnUuTDKaWfspu',
    'AWS_S3_ACCESS_KEY' => 'AKIAIYWYMJD2M245ENFQ',
    'AWS_S3_ACCESS_KEY_NEW' => 'AKIAIGSH7TIXFW7ADYIA',
    'AWS_S3_SECRET_KEY_NEW' => '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',
    'AWS_S3_SECRET_KEY_DATALINK' => 'E4RAsnGRV0+XL6WkvnqCTEnuNpMg8DdHkpVMTK//',
    'AWS_S3_ACCESS_KEY_DATALINK' => 'AKIAJKFUGMFRVRDYILEQ',
    'AWS_S3_SECRET_KEY_WEBSITE_DEV' => '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',
    'AWS_S3_ACCESS_KEY_WEBSITE_DEV' => 'AKIAQJELLIZTAPEKZPOO',
    'AWS_S3_DEF_BUCKET_DATALINK' => 'sl-analytics.simplilearn.com',
    'AWS_S3_BUCKET_NAME' => 'static2.simplilearn.com',
    'AWS_CLOUD_FRONT_ACCESS_KEY' => 'AKIAIDZG7L5EMVFLHNAA',
    'AWS_CLOUD_FRONT_SECRET_KEY' => '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',
    'AWS_CLOUD_FRONT_DISTRIBUTION_ID' => 'E3B6CFTVLQXWCM',
    'AWS_REGION' => 'us-east-2',
    'SIMPLILEARN_STATS' => '500,000+|$5Bn+',
    'CONTACT_US_IN' => '1-800-102-9602',
    'CONTACT_US_USA' => '844-LEARN-88 (844-532-7688)',
    'CONTACT_US_USA_NUM' => '844-532-7688',
    'CONTACT_US_ROW' => '+1-(281)-241-4333',
    'CONTACT_US_2_IN' => '+91-80-49413511, +91 80 42465004, +91 80 42451133',
    'CONTACT_US_2_ROW' => '+1 (408) 500 0745',
    'CONTACT_US_2_USA' => '+1 (408) 500 0745',
        'DIRECT_CALLS_US_NUM' =>'1-844-842-4145',
        'DIRECT_CALLS_IN_NUM' =>'+91 80494 13482',
        'DIRECT_NUM_CATEGORY_NAME' =>'IT Service and Architecture',
    'GO_TO_WEBINAR_USER_ID' => 'simplilearn@gmail.com',
    'GO_TO_WEBINAR_PASSWORD' => 'webinar@simplilearn123',
    'GO_TO_WEBINAR_CLIENT_ID' => 'pDcV1PzgmDEJqL2bTAGH2aWCA3ZKGmSs',
    'GO_TO_WEBINAR_ORGANIZER_ID' => '7732484106959502598',
        'CA_HEADING_SCHOLARSHIP_COURSE_ID' =>'279',
    'ALLOW_URLS_SITEMAP' => 'sitemap_allow.csv',
    'DISALLOW_URLS_SITEMAP' => 'sitemap_disallow.csv',
    'AB_MODULE_1889' => 0,
    'AB_MODULE_1889_COURSE_ID' => 9,
    'AB_MODULE_1889_REDIRECT_CODE' => 301,
    'AB_MODULE_1889_TRIGGER_STRING' => 'ab1889',
    'AB_MODULE_1889_REDIRECT_OR_NOT' => 0,
    'COMMUNITY_BASE_URL' => 'http://community.simplilearn.com/',
    'AUTO_ASSIGN_FRS_FAIL_EMAIL' => 'coders.i9@simplilearn.com',
    'AUTO_ASSIGN_COURSE_PREVIEW_FAIL_EMAIL' => 'coders.i9@simplilearn.com',
    'EMAIL_FRS_INFORM_CHANGE' => 'frs_mod@simplilearn.com',
    'EMAIL_LECTURE_CREATE_INFORM' => 'coders.seo@simplilearn.com',
    'WEBEX_SITEID' => 408917,
    'WEBEX_PARTNERID' => 'aGH4vnYT2S3iWFy55EybZA',
    'WEBEX_SITEURL' => 'https://simplilearn.webex.com/WBXService/XMLService',
    'WEBEX_SITEID_V2' => '1240102',
    'WEBEX_PARTNERID_V2' => 'WnEdW1IaWDQFzAgDZhVmtw',
    'WEBEX_SITEURL_V2' => 'https://simplilearnsolutions.webex.com/WBXService/XMLService',
    'TESTIMONIAL_DEFAULT_IMAGE' => '/ice9/testimonial_images/default_avatar.png',
    'ENABLE_PHP_FIREWALL' => 1,
    'ENABLE_PHP_REFERER_FIREWALL' => 1,
    'REVIEW_TO_BE_APPROVED_STATUS' => 0,
    'REVIEW_APPROVED_STATUS' => 1,
    'REVIEW_DISAPPROVED_STATUS' => 2,
    'AWS_SEARCH_QUERY_STRING' => 'http://search-search-yqd3wdrrvd7gipybubhnmobdli.us-east-1.cloudsearch.amazonaws.com/2013-01-01/search',
    'ERROR_LOG_FILE_500' => APPLICATION_PATH . '/../500_error.log',
    'ERROR_LOG_FILE' => APPLICATION_PATH . '/../error.log',
    'ERROR_LOG_FILE_YOUTUBE' => APPLICATION_PATH . '/../youtube_error.log',
    'TEMP_LEAD_LOG_FILE' => APPLICATION_PATH . '/../temp_lead_storage.log',
    'SEO_OPEN_GRAPH_SITE_NAME' => 'Simplilearn.com',
    'SEO_TWITTER_SITE_NAME' => '@simplilearn',
    'SEO_DEFAULT_THUMB_IMAGE_TO_SHARE' => 'https://www.simplilearn.com/ice9/free_resources_article_thumb/SIMPLILEARN_LOGO_th.jpg',
    'SEO_RDF_EBOOK_AUTHOR_SIMPLILEARN' => 'Simplilearn',
    'SEO_RDF_AUTHOR_TYPE_ORGANIZATION' => 'Organization',
    'SEO_RDF_AUTHOR_TYPE_PERSON' => 'Person',
    'SEO_RDF_LEGAL_NAME' => 'Simplilearn Americas, Inc.',
    'RESTSERVER' => 'http://api.simplilearn.com',
    'RESTENDPOINT' => '/ruser/',
    'FRESHDESK_EMAIL' => 'gsm@simplilearn.com',
    'FRESHDESK_PASSWORD' => '$impli123',
    'FRESHDESK_DOMAIN' => 'https://simplilearn.freshdesk.com',
    'FRESHDESK_SECRET_KEY' => '69c23b33746f5ede4b4374d0e38d3dd5',
    'BASE_ACCOUNTS_URL' => 'https://accounts.simplilearn.com/',
    'BASE_ACCOUNTS_API' => 'user-api/v1/',
    'BASE_ACCOUNTS_INTERNAL_URL' => 'http://api.simplilearn.com/',
    'BASE_ACCOUNTS_INTERNAL_API' => 'ruser/',
    'SSO_CLIENT_ID' => 'sl_ice9',
    'SSO_CLIENT_SECRET' => '$S$DjybDZCLkGugpb8z5gnT4r7a4Gj4mBAmyMEtH2D4tXqcXPPaoijm',
    'SSO_COOKIE_NAME' => '_sljt',
    'FT_COOKIE_NAME' => '_slft',
    'TOKEN_ALGO' => 'HS512',
    'USER_HASH_COOKIE' => 'auh',
    'AUH_EXPIRE_TIME' => 15,
    'JWT_EXPIRE_TIME' => 90,
    'JWT_TOKEN_NAME' => '_t',
    'I9SIMPLEX_USER_MODULE_SESSION_NAME' => 'simplexModules',
    'SSO_LOG_FILE' => dirname(__FILE__).'/../frontend/sso.log',
    'ONLINE_CLASSROOM_PASS_OSL_ACCESS_DAYS' => 180,
    'LVC_PASS_DUMMY_COURSE_ID' => 503,
    'PASS_ACCESS_DAYS' => 90,
    'SEND_CLOUDX_MAIL_FLAG' => 1,
    'SEO_CITY_EXP_STATUS' => 1,
    'SEO_CITY_EXP_CONFIG' => dirname(__FILE__).'/seo-experiments/jira_3002.ini',
    'SEO_CITY_EXP_DATA' => dirname(__FILE__).'/../static/frontend/stubs/CityData.json',
    'PURGE_WEBSITE' => '/*',
    'CDN_HOST' => 'ice10-elb-1423401012.us-east-1.elb.amazonaws.com',
    'DEFAULT_COUNTRY_CODE' => 'US',
    'SSVC_TOKEN_COOKIE' => '_ttt',
    'ENTERPRISE_CART_COOKIE' => '_entp',
    'ENTERPRISE_PAYMENT_SESSION_NAMESPACE'=>'enterprise_payment',
    'ENTERPRISE_CART_ID_SALT' => '_etn@wpp#$TASL',
    'TOI_POPUP' => 1,
    'INTRO_TEXT_COUSES' => '10,15,233,630',
    'NEW_LEAD_COURSE_PREVIEW_IDS' => '9,659,18,260',
    'ACCOUNTS_B2C_GROUP_USER_ID'=>2,
    'AMBASSADOR_API_URL' => 'https://getambassador.com/api/v2/',
    'AMBASSADOR_USERNAME' => 'simplilearn',
    'AMBASSADOR_KEY' => 'ea33d9caefa527a8a828a66b49fa50f9',
    'REFERRER_PROGRAM_COUPON_CODE' => 'REF15',
    'MBSY_NAME' => 'mbsy',
  'NEW_LEAD_COURSE_PREVIEW_COOKIE' => '_cpruid',
  'NEW_LEAD_COURSE_PREVIEW_LIMIT' => 3,
  'AB_LIST_REMOVE_ACCORDION' => "",//35,279,657,662
  'BUNDLE_BLOCK_RESTRICT' => "",
    'DISQUS_SHORTNAME' =>'simplidisqus',
    'DISQUS_PREFIX'=>'',
    'DISQUS_SECRET_KEY'=>'Tb31HXmeBMNywW4dOvZ8VKIeBDkdVoTC5kT18N5xPlyJ0I1ZvrBaNR8dOhAWjv2w',
    'DISQUS_PUBLIC_KEY'=>'uxQtSBJeexaSNhWBXeAyPRYbj7zkW2feNMsNWM934G6EzOGMTF4uTzocFLbEwkR4',
    'MONGO_CONN_STR_FRS'=>'mongodb://mongo-cm-1:27017,mongo-cm-2:27017,mongo-cm-3:27017/?replicaSet=ice10-mrs',
    'MONGO_DB_FRS'=>'caldon',
    'MASTER_PASS_ACCESS_DAYS'=>365,
    'ENTERPRISE_ACCESS_DAYS'=>365,
    'DNS_FETCH_CFS22'=>'//cfs22.simplicdn.net/',
    'DNS_FETCH_CFSI10'=>'//cfi10.simplicdn.net/',
    'DNS_FETCH_CFS3'=>'//cfs3.simplicdn.net/',
    'FRS_ELEMENTS_PER_PAGE_HOME'=>10,
    'FRS_ALL_SEGMENTS_COLLECTION_ID' => 9999,
    'FRS_ALL_SEGMENTS_COLLECTION_NAME' => "All",
    'CALDON_API'=>'http://caldon.simplilearn.com/api',
    'FRS_MINIMUM_REGISTRANTS_FOR_DISPLAY' => 30,
    'REDIRECT_FILE_301' => 'http://s3.amazonaws.com/static2.simplilearn.com/redirects/php_redirects_301.csv',
    'FRS_CARDS_FOR_MOBILE_API_HOME_PAGE' => 5,
    'FRS_SEGMENTS_OTHER_SEGMENTS_NAME' => "Other Segments",
    'FRS_SEGMENTS_OTHER_SEGMENTS_ID' => 9998,
    'FRS_SEGMENTS_DEFAULT_SEGMENT_ID_FOR_MOBILE_API' => 5,
    'REDIRECT_FILE_302' => 'http://s3.amazonaws.com/static2.simplilearn.com/redirects/php_redirects_302.csv',
    'REDIRECT_FILE_410' => 'http://s3.amazonaws.com/static2.simplilearn.com/redirects/php_status_410.csv',
    'EXPIRES_HEADER_EXCLUSION' => '$^/cart|^/help-and-support$i',
    'EXPIRES_HEADER_INTERVAL'=>19800,
    'ENABLE_COUNTRY_CODE_BASED_PAYMENTS' => "1",
    'LEAD_FORM_EXPERIMENT_COURSE_IDS' => '335,18',
    'BREADCRUMB_VENDOR_URL_EXP' => '5,15,23',
    'VPTEXT_GOOGLE' => 'Google Cloud Platform is a future proof infrastructure with powerful data and analytics committed to open source and industry leading price-performance to build better products. Google Cloud Platform certification training will help you gain knowledge to use Google\'s core infrastructure, data analytics and machine learning.Gain expertise in the platfrom from the Google accredited courses.',
    'VPTEXT_AWS' => 'Amazon Web Services is a secure cloud services platform, offering compute power, database storage, content delivery and other functionality to help businesses scale. AWS certification training helps you scale your cloud skills and gain expertise in AWS platform. AWS Technical Essentials, AWS Developer, AWS Solution Architect, AWS Sys Ops are the major courses offered.',
    'VALID_VIDEO_EXTENSIONS' => "mp4",// csv
    'USER_HASH_CLIENT_SECRET' => 'kDMfkrRYwPsJ0$2aw8IgopLT684ojvI8swP5kKK4HqIJSsFPoqoHfGD',
    'MARKETO_API_URL' => '788-AZS-915.mktorest.com',
    'MARKETO_CLIENT_ID' => 'e663399c-46ed-4a3f-8cae-8726f48194be',
    'MARKETO_CLINET_SECRET' => 'lOLxfIT6AXjs6ezHDfgnAktzPLMdd0qV',
    'COUPON_DISCOUNT_VALUE_CHECK_TYP' => 51,
    'SFA_COUNTRY' => 'US',
    'SFA_COURSE_LIST' => '10,15,630,32,34,18,184,231,233,244,291,335,387,506,594,598,621,637,652,662,670',
        'EC_COUNCIL_COURSE_LIST' => '',
    'SCHOLARSHIP_COURSE_LIST' => '10,184,15,630',
    'COURSE_TRAINER_NAME_CHECK_LIMIT' => 99,
    'WEBENGAGE_API_URL' => 'https://api.webengage.com/',
    'WEBENGAGE_API_AUTHORIZATION_KEY' => '329e5e11-c0b3-4301-8c49-e29a9fa64d79',
    'WEBENGAGE_API_LICENSE_CODE' => '311c5642',
    'WEBENGAGE_SALT' => '$!M:PlIC#@ITNn$',
    'SEGMENT_API_CODE'=> '7anMtaJ2QGICQhglMqK0GmaOUcMsk4TJ',
    'SALESFORCE_OID' => '00D28000000sMrr', // LIVE Salesforce
    'SALESFORCE_HOST' => 'https://simplilearn.my.salesforce.com/', // LIVE Salesforce
    'W2L_WHITE_LIST_DOMAINS' => 'campaign.simplilearn.com',
    'FPT_HOTLEAD_COURSES' => '10,18',
    'COUNTRY_CODE_IND' => 'IN',
    'WEBTOLEAD_SECRET_KEY_WORDPRESS' => '5oxdkNral3s=',
    'WEBTOLEAD_SECRET_KEY_MARKETO_CAMPAIGN' => 'jr4MlySCeNg=',
    'REFER_AND_EARN_MOBILE_ENABLE' => 1,
    'IS_B2B' => 0,
    'SALESFORCE_APIS_SALT' => '$!M:PlIC#@IT@NnY@$',
    'COOKIE_MARKETO_TRACK' => '_mkto_trk',
    'SF_ASSIGN_TRIGGER_VAL'=>'01Q28000000WFH8',
    'COURSE_INFO_API_COURSE_QUANTITY' => 2,
    'ENV_NO_INDEX' => 'meta-noindex',
    'UNSUBSCRIBE_EMAIL' => 'unsubscribe@simplilearn.delivery',
    'SALESFORCE_CLIENT_ID' => '3MVG9ZL0ppGP5UrDmNzl_vZRN906MdS.E5jq0EmcpGCzDl5p3uqG3309GEeptMTQDoLWx4iYiI3PQCaPx_Wuj',
    'SALESFORCE_CLIENT_SECRET' => '6243107613331339249',
    'SALESFORCE_USER_NAME' => 'apiuser@simplilearn.com',
    'SALESFORCE_PASSWORD' => 'Ap!SiMp!i@321agEIi3DOg4GeRX5guLE0rZulB',
    'SALESFORCE_LOGIN_URL' => 'https://login.salesforce.com/services/oauth2/token',
    'SALESFORCE_REDIRECT_URI' => 'https://localhost/resttest/oauth_callback.php',
    'SALESFORCE_LEAD_URL' => 'https://simplilearn.my.salesforce.com/services/apexrest/LeadAPI',
    'SALESFORCE_LEARNER_API_ENDPOINT' => 'https://simplilearn.my.salesforce.com/services/apexrest/learner',
    'SALESFORCE_OPPORTUNITY_ENDPOINT' => 'https://simplilearn.my.salesforce.com/services/apexrest/createOpportunity',
    'SALESFORCE_LMS_DATA_URL' => 'https://simplilearn.my.salesforce.com/services/apexrest/LMSUpdate',
    'SALESFORCE_LOG' => 'salesforce_lead_create.log',
    'LMSTOSFDC_LOG' => 'lms_to_sfdc.log',
    'SF_B2C_RECORD_TYPE_ID' => '01228000000ltkvAAA', // 15digit -> '01228000000ltkv',
    'SF_SL_AMERICA_RECORD_TYPE_ID' => '01228000000N4XnAAK', // 15digit -> '01228000000N4Xn',
    'SF_SL_GLOBAL_RECORD_TYPE_ID' => '01228000000N4XsAAK', // 15digit -> '01228000000N4Xs',
    'SF_SYNC_PROCESS_LIMIT' => 100,
    'SF_SYNC_MAX_ITRATION' => 3,
    'RECORD_TYPE_NAME_SL_AMERICA' => 'Simplilearn America',
    'RECORD_TYPE_NAME_SL_GLOBAL' => 'Simplilearn Global',
    'RECORD_TYPE_NAME_B2C' => 'B2C',
    'MARKETO_TEST_CAMPAIGN_ID' => '2843',
    'MARKETO_CAMPAIGN_ID_MM' => 3167, // new '3166', // Old value 2371
    'MARKETO_CAMPAIGN_ID_CONTACT_US' => 3167, // new '3167', // Old value 2207
    'MARKETO_CAMPAIGN_ID' => 3167, // new '3168', // Old value 1859,
    'MEGA_MENU_MASTER_COURSE_COUNT' => 5,
    'MEGA_MENU_MASTER_COURSE_COUNT_MOBILE' => 3,
    'MEGA_MENU_POPULAR_COURSE_COUNT' => 10,
    'MEGAMENU_LINE_CHAR_COUNT' => 42,
    'SELF_LEAD' => 'self',
    'CEH_COURSE_TO_CHANGE_TEXT' => '105',
    'STATE_GST_STRING' => 'SGST',
    'CENTRE_GST_STRING' => 'CGST',
    'INTEGRATED_GST_STRING' => 'IGST',
    'COURSE_INSTANCE_SCHEMA_COUNT' => 4,
    'TOGAF_COURSE_ID' => 184,
    'COUPON_REPLACE_TEXT' => 'coupon_code',
    'TAG_NAME_LEAD_CREATE' => 'na-payment',
    'SITE_MODULE_TOLLFREE' => 'Tollfree',
    'LEAD_FROM_SL' => 'SL-Website',
    'JOB_ASSIST_MASTERS_PROGRAMS' => '72,67,23,84,80,105,111,112',
    'JOB_ASSIST_MASTERS_COURSES' => '233,230,15,630,684,670,704,262,687,795,105',
    'FREE_TRIAL_DAYS' => 7,
    'FT_UTM_BLOCKED' => 'ir,shareasale,cj,awin',
    'FT_ATP_PARAM' => 'ft_atp',
    'ADD_HREFLANGS_TOPAGE'=> 0,
    'MONGO_COLLECTION_LECTUREPAGECOLLECTION' => 'LecturePagesNew',
    'MONGO_COLLECTION_CONTENTSCOLLECTION' => 'contents',
    'MONGO_COLLECTION_CONTENTSTATSCOLLECTION' => 'content-stats',
//    'PAYMENT_SSO_LOGIN' =>  'salesforce_sso',
    'PAYMENT_SSO_LOGIN' =>  'sl_salesforce',
    'SSO_VERIFIED_USER_COOKIE'=> '_sso_verified_user',
    'GOOGLE_CONTACT_CLIENT_ID' => '520546642335-6qjaqikonh86sd9gu8f8huoq9km33ti2.apps.googleusercontent.com',
    'GOOGLE_CONTACT_API_KEY' => 'AIzaSyBrn8DGQOCiUPfHx-6ki-3VR4kdhwiAqFA',
    'KAFKA_CONN_URL' =>'https://services.simplilearn.com/events/kafka/website-events'
  ),
    'cta_text' => array(
        'emi' => array('countries' => array(6),'text' => 'EMI Option Available'),
        'vat' => array('countries' =>  array(14), 'text' => '* VAT Included'),
    ),
  'autoloaderNamespaces' =>
  array (
    0 => 'BaseApp_',
  ),
  'referandearnmail' =>
  array (
    'host' => 'smtp.mandrillapp.com',
    'params' =>
    array (
      'auth' => 'login',
      'username' => 'linus@simplilearn.com',
      'password' => 'HnVY6dfYVFIp0lT6Zy1Mbw',
      'port' => '587',
    ),
    'sender_email' => 'no-reply@simplilearnmail.com',
    'sender_name' => 'Simplilearn',
  ),
  'device' =>
  array (
    'compatibility' =>
    array (
      'Windows' => 1,
      'MAC' => 2,
      'iOS' => 4,
      'Android' => 8,
    ),
  ),
  'elearning_compatibility' =>
  array (
    'status' =>
    array (
      0 => 'Not Supported',
      1 => 'Partially Supported',
      2 => 'Supported',
    ),
  ),
  'testimonial_mailer' =>
  array (
    'emailIds' =>
    array (
      0 => 'coders.i9@simplilearn.com',
    ),
  ),
  'search_mailer' =>
  array (
    'emailIds' =>
    array (
      0 => 'category@simplilearn.com',
      1 => 'product@simplilearn.com',
    ),
  ),
  'limit_js' =>
  array (
    0 => 'course',
    1 => 'bundle',
    2 => 'label',
    3 => 'vendor',
    4 => 'search',
    5 => 'cityCourse',
    6 => 'home',
  ),
  'awscloudsearch' =>
  array (
    'aws_cloudsearch_key' => 'AKIAJ6SJYDFOXWU6SFMA',
    'aws_cloudsearch_secret_key' => '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',
    'endpoint' => 'http://search-search-yqd3wdrrvd7gipybubhnmobdli.us-east-1.cloudsearch.amazonaws.com',
    'version' => '2013-01-01',
  ),
  'search' =>
  array (
    'default_selected' =>
    array (
      0 => 'course',
      1 => 'bundle',
    ),
    'enable_default_select' => 1,
  ),
  'lvc_pass_webx_user_data' =>
  array (
    12345 => 'test',
  ),
  'android_version_data' =>
  array (
    'version_number' => '7.0',
    'version_code' => 85,
    'is_force_update' => 0,
  ),
  'ios_version_data' =>
  array (
    'version_number' => '6.0',
    'version_code' => 34,
    'is_force_update' => 1,
  ),
  'blacklist' =>
  array (
    'referers' =>
    array (
      0 => 'onclickads.net',
    ),
  ),
  'globalmessage' =>
  array (
    'enabled' => 0,
    'start' => '2016-01-19 07:30:00',
    'interval' => '12 hours 0 seconds',
    'message' => 'Simplilearn is under maintenance for some time. During this time purchases and login will be affected. Sorry for the inconvenience!',
  ),
  'ONLINE_CLASSROOM_PASS_ACCESS_DAYS' =>
  array (
    0 => 90,
  ),
  'EXCLUDE_ACCESS_DAYS_MASTER' =>
  array(
    0 => 30,
    1 => 60,
    2 => 3,
    3 => 10
  ),
  'LVC_BUNDLE_ACCESS_DAYS' => array(
        365 => 365,
   ),
  'popular_courses' =>
  array (
    0 => 10,
    1 => 105,
    2 => 15,
    3 => 156,
    4 => 18,
    5 => 184,
    6 => 2,
    7 => 231,
    8 => 268,
    9 => 279,
    10 =>291,
    11 =>325,
    12 =>335,
    13 =>34,
    14 =>4,
    15 =>43,
  ),
  'master_program_promo_voucher_text' => array(
                                                 '34'=>'*Use the code USMINI to avail an iPad Mini.',
                                                 '35'=>'*Use the code USMINI to avail an iPad Mini.',
                                                 '36'=>'*Use the code USMINI to avail an iPad Mini.',
                                                 '6'=>'*Use the code INMINI to avail an iPad Mini.',
                                                 '14'=>'*Use the code ROMINI to avail an iPad Mini.',
                                                 '24'=>'*Use the code ROMINI to avail an iPad Mini.',
                                                 '30'=>'*Use the code ROMINI to avail an iPad Mini.',
                                                 '62'=>'*Use the code ROMINI to avail an iPad Mini.',
                                                 '61'=>'*Use the code ROMINI to avail an iPad Mini.'
                                                ),
  'webinar' =>
  array (
   'consumer'=>array('simplilearn@gmail.com'=>'pDcV1PzgmDEJqL2bTAGH2aWCA3ZKGmSs','webinar.1@simplilearn.com'=>'ftwGbngfF0tZ5y6oBDRuFrXGLaCbziKM','webinar.2@simplilearn.com'=>'ujJJUZFARKGSIenj4bjUCAoWhsFyOh5N','mark.promo@simplilearn.com'=>'0nBiQduQiz9f0kSYdfC33b8RO7wTPsB9'),
   'password'=>array('simplilearn@gmail.com'=>'webinar@simplilearn123','webinar.1@simplilearn.com'=>'webinarsimpli@123','webinar.2@simplilearn.com'=>'webinarsimpli@123','mark.promo@simplilearn.com'=>'webinarsimpli@123'),
   'organizer'=>array('simplilearn@gmail.com'=>'7732484106959502598','webinar.1@simplilearn.com'=>'7085645829846781702','webinar.2@simplilearn.com'=>'1413461055220141830','mark.promo@simplilearn.com'=>'3193581375725629708'),
  ),
    'mbsyconfig' =>
    array(
        'group_id'=>array('US'=>1,'IN'=>2,'ROW'=>1),
        'camp_id'=>array('US'=>31227,'IN'=>31163,'ROW'=>31227),
        'coupon_code'=>array('US'=>'TESTUS','IN'=>'TESTIND','ROW'=>'TESTUS')
    ),
    'mbsyconfigmobileandroid' =>
    array(
        'group_id'=>array('US'=>1,'IN'=>2,'ROW'=>1),
        'camp_id'=>array('US'=>32099,'IN'=>32098,'ROW'=>32099),
        'coupon_code'=>array('US'=>'TESTUS','IN'=>'TESTIND','ROW'=>'TESTUS')
    ),
    'mbsyconfigmobileios' =>
    array(
        'group_id'=>array('US'=>1,'IN'=>2,'ROW'=>1),
        'camp_id'=>array('US'=>32102,'IN'=>32101,'ROW'=>32102),
        'coupon_code'=>array('US'=>'TESTUS','IN'=>'TESTIND','ROW'=>'TESTUS')
    ),
    'trainermbsyconfig' =>
    array(
        'group_id'=>array('US'=>4,'IN'=>3,'ROW'=>4),
        'camp_id'=>array('US'=>31695,'IN'=>31694,'ROW'=>31695)
    ),
    'countryDropdownCountryList' => array (
        'IN','US','CA','MX'
    )
);

// ---------------------------------------------------------
// production pciserver
// ---------------------------------------------------------

$config['production_pciserver'] = array (
  'constants' =>
  array (
    'WEBSITE_MAIN_URL' => 'https://pciwww.simplilearn.com',
    'SSVC_URL' => 'https://pcissvc.simplilearn.com/secure',
    'FRONTEND_URL' => 'https://pciwww.simplilearn.com',
    'FRONTEND_API_URL' => 'https://pciwww.simplilearn.com/api/v1',
    'FRONTEND_API_URL_NOCACHE' => 'https://pciwww.simplilearn.com/api/v1/index/nocache',
     'SITE_API_URL_NOCACHE' => 'https://pciwww.simplilearn.com/api/v1/index/nocache',
    'FRONTEND_CDN_API_URL' => '//pciwww.simplilearn.com/api/v1?method=',
    'FRONTEND_NON_CDN_API_URL' => '//pciwww.simplilearn.com/api/v1?method=',
  ),
);
$config['production_pciserver'] = array_replace_recursive($config['production'], $config['production_pciserver']);



// ---------------------------------------------------------
// production oneserver test
// ---------------------------------------------------------

$config['production_oneserver'] = array (
  'constants' =>
  array (
    'SSVC_URL' => 'https://cf.simplilearn.com/secure',
    'FRONTEND_URL' => 'https://cf.simplilearn.com',
    'FRONTEND_CANONICAL_URL' => 'https://cf.simplilearn.com',
    'FRONTEND_CANONICAL_URL_SECURE' => 'https://cf.simplilearn.com',
    'MM_FRONTEND_URL' => 'https://cf.marketmotive.com',
    'FRONTEND_API_URL' => 'https://cf.simplilearn.com/api/v1',
    'FRONTEND_API_URL_NOCACHE' => 'https://cf.simplilearn.com/api/v1/index/nocache',
    'SITE_API_URL_NOCACHE' =>  'https://cf.simplilearn.com/api/v1/index/nocache',
  ),
);
$config['production_oneserver'] = array_replace_recursive($config['production'], $config['production_oneserver']);


// ---------------------------------------------------------


// ---------------------------------------------------------
// production enterprise
// ---------------------------------------------------------

$config['production_enterprise'] = array (
  'constants' =>
  array (
    'WEBSITE_MAIN_URL' => 'https://enterprise.simplilearn.com',
    'MAIN_CDN_URL' => 'https://enterprise.simplilearn.com/static',
    'FRONTEND_URL' => 'https://'.HOST,
    'FRONTEND_CANONICAL_URL' => 'https://'.HOST,
    'FRONTEND_CANONICAL_URL_SECURE' => 'https://'.HOST,
    'FRONTEND_API_URL' => 'https://enterprise.simplilearn.com/api/v1',
    'FRONTEND_API_URL_NOCACHE' => 'https://enterprise.simplilearn.com/api/v1/index/nocache',
     'SITE_API_URL_NOCACHE' => 'https://enterprise.simplilearn.com/api/v1/index/nocache',
    'FRONTEND_CDN_API_URL' => 'https://enterprise.simplilearn.com/api/v1?method=',
    'FRONTEND_NON_CDN_API_URL' => 'https://enterprise.simplilearn.com/api/v1?method=',
    'ENTERPRISE_COOKIE_DELIMITER' => '|^|',
    'B2B_IDENTIFIER' => '/partners',
    'IS_B2B' => 1,
    'B2B_RESTRICTIONS' => serialize(array('index','career-edge','about-us','our-team','careers','reviews','contact-us','authorized-training-partner','search','lvc-pass','career-data-labs','feed')),
    'B2B_RESTRICTIONS_GEN' => serialize(array('careers','search','lvc-pass','career-data-labs','feed')),
    'B2B_GENERAL_ID' => 'sl',
    'ADD_HREFLANGS_TOPAGE'=> 0
  ),
);
$config['production_enterprise'] = array_replace_recursive($config['production'], $config['production_enterprise']);


// ---------------------------------------------------------
// production secure
// ---------------------------------------------------------

$config['production_secure'] = array (
  'constants' =>
  array (
    'MAIN_CDN_URL' => 'https://cfs9.simplicdn.net',
    'STATIC_URL' => 'https://static.simplilearn.com',
    'FRONTEND_URL' => 'https://'.HOST,
    'FRONTEND_API_URL' => 'https://'.HOST.'/api/v1',
    'FRONTEND_CDN_API_URL' => 'https://'.HOST.'/api/v1?method=',
    'FRONTEND_NON_CDN_API_URL' => 'https://'.HOST.'/api/v1?method=',
    'FREE_RESOURCES_CDN_URL' => 'https://cfs22.simplicdn.net/ice9',
    'UPLOAD_CDN_URL' => 'https://'.HOST.'/logo.png',
    'META_IMAGE' => 'https://staging-accounts.simplilearn.com/',
    'FOR_BUSINESS_LINK' => 'https://enterprise.simplilearn.com/?_r=hdr'
  ),
);
$config['production_secure'] = array_replace_recursive($config['production'], $config['production_secure']);

//-------------------------------------------------------------------------------

// ---------------------------------------------------------
// production translation
// ---------------------------------------------------------

$config['production_translation'] = array (
  'constants' =>
  array (
    'MONGO_DB' => 'ice9_br',
    'MONGO_DB_FRS' => 'caldon_br',
  ),
);
$config['production_translation'] = array_replace_recursive($config['production'], $config['production_translation']);


// ---------------------------------------------------------
// i9Staging
// ---------------------------------------------------------

$config['i9staging'] = array ();
$config['i9staging'] = array_replace_recursive($config['production'], $config['i9staging']);

//----------------------------------------------------------------


// ---------------------------------------------------------
// sync
// ---------------------------------------------------------

$config['sync'] = array (
  'phpSettings' =>
  array (
    'display_errors' => 1,
  ),
  'resources' =>
  array (
    'frontController' =>
    array (
      'params' =>
      array (
        'displayExceptions' => 1,
      ),
    ),
    'db' =>
    array (
      'params' =>
      array (
        'host' => 'i2rds-read-replica2.cuoivis0lb68.us-east-1.rds.amazonaws.com',
      ),
    ),
  ),
  'constants' =>
  array (
    'CACHE_ENABLED' => 0,
    'SHOW_STATIC_HEADER' => 0,
  ),
);
$config['sync'] = array_replace_recursive($config['production'], $config['sync']);

//---------------------------------------------------------


// ---------------------------------------------------------
// production_simplex
// ---------------------------------------------------------
$config['production_simplex'] = array ();
$config['production_simplex'] = array_replace_recursive($config['production'], $config['production_simplex']);

//---------------------------------------------------------

// ---------------------------------------------------------
// STAGING ENV
// ---------------------------------------------------------
$config['staging'] = array (
  'phpSettings' =>
  array (
    'display_errors' => '1',
  ),
  'resources' =>
  array (
    'frontController' =>
    array (
      'params' =>
      array (
        'displayExceptions' => '1',
      ),
    ),
    'db' =>
    array (
      'params' =>
      array (
        'host' => 'lms.cdd5upvfayzx.us-east-1.rds.amazonaws.com',
        'profiler' => '1',
      ),
    ),
    'mail' =>
    array (
      'transport' =>
      array (
        'type' => 'smtp',
        'auth' => 'login',
        'host' => 'email-smtp.us-east-1.amazonaws.com',
        'username' => 'AKIAI6PLZHO7NZUQGI7Q',
        'password' => 'AkEeVxfV2ad0KT/fNEqnwgN6M+6MIXLFSb/qXileS7Sk',
        'port' => '587',
        'ssl' => 'tls',
        'register' => '1',
      ),
    ),
  ),
   'salesforce' => array(
        'SF_USERNAME' => "tushar.bansal@simplilearn.com",
        'SF_PASSWORD' => "Simple@1uVtotTEW1KUoIZqJ42O0l3GMW",
        'WSDL_FILE_NAME' => "/enterprise.cs6.wsdl.xml",
    ),
  'constants' =>
  array (
    'WEBSITE_MAIN_URL' => 'http://'.HOST,
    'MELVIN_DB_HOST' => 'lms.cdd5upvfayzx.us-east-1.rds.amazonaws.com', //j7LzpyMUcNxB
    'MONGO_CONN_STR' => 'mongodb://54.173.173.8:27017,18.205.96.98:27017,34.239.126.0:27017/?replicaSet=slmongo',
    'MONGO_DB' => 'ice9_staging',
    'MONGO_CONN_STR_FRS' => 'mongodb://54.173.173.8:27017,18.205.96.98:27017,34.239.126.0:27017/?replicaSet=slmongo',
    'MONGO_DB_FRS' => 'caldon',
    'FRONTEND_URL' => 'http://'.HOST.'/frs/frontend/public',
    'MAIN_CDN_URL' => 'http://'.HOST.'/frs/static',
    'FRONTEND_API_URL' => 'http://'.HOST.'/frs/frontend/public/api/v1',
    'FRONTEND_CDN_API_URL' => 'http://'.HOST.'/frs/frontend/public/api/v1?method=',
    'FRONTEND_NON_CDN_API_URL' => 'http://'.HOST.'/frs/frontend/public/api/v1?method=',
    'BACKEND_URL' => 'http://'.HOST.'/frs/backend/public',
    'META_IMAGE' => 'https://www.simplilearn.com/logo.png',
    'SEO_FRONTEND_URL' => 'http://'.HOST,
    'BASE_LMS_URL' => 'https://staging-lms.simplilearn.com/',
    'LMS_DOMAIN' => 'staging-lms.simplilearn.com',
    'ACCOUNTS_PATH' => 'https://staging-accounts.simplilearn.com/',
    'BASE_ACCOUNTS_URL' => 'https://staging-accounts.simplilearn.com/',
    'BASE_ACCOUNTS_INTERNAL_URL' => 'http://staging-api.simplilearn.com/',
//    'CRM_URL' => 'http://crm3.simplilearn.com/git/xenia/public',
    'FRONTEND_API_URL_NOCACHE' => 'http://'.HOST.'/frs/frontend/public/api/v1',
     'SITE_API_URL_NOCACHE' => 'http://'.HOST.'/frs/frontend/public/api/v1',
    'SSVC_PROVIDER_KEY' => 'vdss209csad0g9j2timafse09r8gr123',
    'SSVC_PROVIDER_KEY_WPP' => 'vdss209csad0g9j2fasefse09wppdev',
    'SSVC_URL' => 'http://'.HOST.'/ssvc/public/',
    'AWS_SEARCH_QUERY_STRING' => 'http://search-staging-search-73e2yne6nv6mdv52ofplhzzedq.us-east-1.cloudsearch.amazonaws.com/2013-01-01/search',
    'SENDER_NAME' => 'Simplilearn',
    'REPLYTO_NAME' => 'Simplilearn',
    'SEND_EMAIL_ID' => 'stagingmailer@simplicdn.net',
    'REPLYTO_EMAIL_ID' => 'stagingmailer@simplicdn.net',
    'FRESHDESK_EMAIL' => 'kirit.bellubbi@simplilearn.com',
    'FRESHDESK_PASSWORD' => 'Kirit@123',
    'FRESHDESK_DOMAIN' => 'https://simplilearntest.freshdesk.com',
    'FRESHDESK_SECRET_KEY' => 'd05c037b1ca04a2d6c55762535a6ba21',
    'CACHE_ENABLED' => '0',
    'SHOW_STATIC_HEADER' => '0',
    'COMBINE_ALL_JS' => '0',
    'GOOGLE_ANALYTICS_CODE' => 'UA-32079340-4',
    'GOOGLE_ANALYTICS_DOMAIN_NAME' => HOST,
    'PROFILER_ENABLED' => '1',
    'PROFILER_HIDDEN' => '0',
    'GOOGLE_TAG_MANAGER_CODE' => 'GTM-TDKN64',
    'AWS_CLOUD_FRONT_ACCESS_KEY' => 'AKIAIMCT46EOGJGSLS7A',
    'AWS_CLOUD_FRONT_SECRET_KEY' => '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',
    'AWS_CLOUD_FRONT_DISTRIBUTION_ID' => 'E1JYHUA3T7XXT',
    'RESTSERVER' => 'http://staging-api.simplilearn.com',
    'CACHE_MEMCACHED_HOST' => 'ice10-staging.yx2u3w.cfg.use1.cache.amazonaws.com',
    'CONTACT_US_EMAIL' => 'coders.i9@simplilearn.com',
    'CORPORATE_SALES_EMAIL' => 'coders.i9@simplilearn.com',
    'CORPORATE_SALES_EMAIL2' => 'coders.i9@simplilearn.com',
    'ATP_EMAIL' => 'coders.i9@simplilearn.com',
    'BLOG_EMAIL' => 'coders.i9@simplilearn.com',
    'AFFILIATE_EMAIL' => 'coders.i9@simplilearn.com',
    'TRAINER_EMAIL' => 'coders.i9@simplilearn.com',
    'AMBASSADOR_API_URL' => 'https://getambassador.com/api/v2/',
    'AMBASSADOR_USERNAME' => 'simplilearn',
    'AMBASSADOR_KEY' => 'ea33d9caefa527a8a828a66b49fa50f9',
    'REFERRER_PROGRAM_COUPON_CODE' => 'REFFERER20',
    'MBSY_NAME' => 'mbsy',
    'DISQUS_SHORTNAME' => 'devtest321',
    'DISQUS_PREFIX' => 'stage',
    'WEBENGAGE_API_URL' => 'https://api.webengage.com/',
    'WEBENGAGE_API_AUTHORIZATION_KEY' => 'b63a2822-bbc4-4f23-a01c-ba1707c7533f',
    'WEBENGAGE_API_LICENSE_CODE' => '76ab161',
    'SEGMENT_API_CODE'=> 'N9cvcUyojxfGrq8gATfVtUHbK4z13faQ',
    'DISQUS_SECRET_KEY' => 'Tb31HXmeBMNywW4dOvZ8VKIeBDkdVoTC5kT18N5xPlyJ0I1ZvrBaNR8dOhAWjv2w',
    'DISQUS_PUBLIC_KEY' => 'uxQtSBJeexaSNhWBXeAyPRYbj7zkW2feNMsNWM934G6EzOGMTF4uTzocFLbEwkR4',
    'CALDON_API' => 'http://staging.simplilearn.com/caldon/public/api',
    'ENTERPRISE_CURRENCY_ID_US'=>2,
    'ENTERPRISE_COUNTRY_CODE_US'=>'US',
    'SALESFORCE_CLIENT_ID' => '3MVG99S6MzYiT5k9Zi_aoc.dqucMuIaEp0IRak1LQoaUVk2QwGWowo7PQ1gf.9Xw1K0.a3ABplG4f1bK8n6T0',
    'SALESFORCE_CLIENT_SECRET' => '6365020493184878233',
    'SALESFORCE_USER_NAME' => 'tushar.bansal@simplilearn.com.support',
    'SALESFORCE_PASSWORD' => 'support@123d0vmgXbUGf3MC0egDpCN1bKAj',
    'SALESFORCE_LOGIN_URL' => 'https://test.salesforce.com/services/oauth2/token',
    'SALESFORCE_LEAD_URL' => 'https://simplilearn-test--partialqa.cs58.my.salesforce.com/services/apexrest/LeadAPI',
    'SALESFORCE_LEARNER_API_ENDPOINT' => 'https://simplilearn-test--partialqa.cs58.my.salesforce.com/services/apexrest/learner',
    'SALESFORCE_OPPORTUNITY_ENDPOINT' => 'https://simplilearn-test--partialqa.cs58.my.salesforce.com/services/apexrest/createOpportunity',
    'SALESFORCE_LMS_DATA_URL' => 'https://simplilearn-test--partialqa.cs58.my.salesforce.com/services/apexrest/LMSUpdate',
    'KAFKA_CONN_URL' => 'http://104.211.217.159:8082/topics/click-events'
  ),
  'awscloudsearch' =>
  array (
    'aws_cloudsearch_key' => 'AKIAIF7K64BU3AFSMBYQ',
    'aws_cloudsearch_secret_key' => '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',
    'endpoint' => 'http://search-staging-search-73e2yne6nv6mdv52ofplhzzedq.us-east-1.cloudsearch.amazonaws.com',
    'version' => '2013-01-01',
  ),
);
$config['staging'] = array_replace_recursive($config['production'], $config['staging']);


// -------------------------------------------------------------

// -------------------------------------------------------------
// Docker Compose Env
// ----------------------------------------------------------------

$config['dockercompose'] = array (
        'phpSettings' =>
        array (
                'display_startup_errors' => '1',
                'display_errors' => '1',
                'session' =>
                array (
                        'cookie_domain' => '',
                ),
        ),
        'resources' =>
        array (
                'frontController' =>
                array (
                        'params' =>
                        array (
                                'displayExceptions' => '1',
                        ),
                ),
                'db' =>
                array (
                        'params' =>
                        array (
                                'host' => 'lms.cdd5upvfayzx.us-east-1.rds.amazonaws.com',
                                'dbname' => 'ice9',
                                'username' => 'simpli_web',
                                'password' => 'SLPortal@2010',
                                'profiler' => '1',
                        ),
                ),
                'mail' =>
                array (
                        'transport' =>
                        array (
                                'type' => 'smtp',
                                'auth' => 'login',
                                'host' => 'email-smtp.us-east-1.amazonaws.com',
                                'username' => 'AKIAI6PLZHO7NZUQGI7Q',
                                'password' => 'AkEeVxfV2ad0KT/fNEqnwgN6M+6MIXLFSb/qXileS7Sk',
                                'port' => '587',
                                'ssl' => 'tls',
                                'register' => '1',
                        ),
                ),
                'salesforce' => array(
                    'SF_USERNAME' => "tushar.bansal@simplilearn.com",
                    'SF_PASSWORD' => "Simple@1uVtotTEW1KUoIZqJ42O0l3GMW",
                    'WSDL_FILE_NAME' => "/enterprise.cs6.wsdl.xml",
                )
        ),
        'constants' =>
        array (
                'WEBSITE_MAIN_URL' => 'http://'.HOST.$appendStr,
                'MELVIN_DB_HOST' => 'lms.cdd5upvfayzx.us-east-1.rds.amazonaws.com',
                'MELVIN_DB_NAME' => 'melv1n_crm2_docker',
                'FRONTEND_URL' => 'http://ice9docker.simplilearn.com'.$appendStr,
                'FRONTEND_CANONICAL_URL' => 'http://ice9docker.simplilearn.com'.$appendStr,
                'FRONTEND_CANONICAL_URL_SECURE' => 'http://ice9docker.simplilearn.com'.$appendStr,
                'BASE_LMS_URL' => 'http://paperclipdocker.simplilearn.com/apachedev/git/paperclip/public/',
                'LMS_DOMAIN' => 'paperclipdocker.simplilearn.com',
                'FRONTEND_API_URL' => 'http://ice9docker.simplilearn.com'.$appendStr.'/api/v1',
                'FRONTEND_API_URL_NOCACHE' => 'http://ice9docker.simplilearn.com'.$appendStr.'/api/v1/index/nocache',
                'SITE_API_URL_NOCACHE' => 'http://ice9docker.simplilearn.com'.$appendStr.'/api/v1/index/nocache',
                'FRONTEND_CDN_API_URL' => 'http://ice9docker.simplilearn.com'.$appendStr.'/api/v1?method=',
                'FRONTEND_NON_CDN_API_URL' => 'http://ice9docker.simplilearn.com'.$appendStr.'/api/v1?method=',
                'MAIN_CDN_URL' => 'http://ice9docker.simplilearn.com/apachedev/git/ice9/static',
                'SEND_OUT_OF_MEMORY_EMAIL' => '0',
                'MONGO_CONN_STR' => 'mongodb://xmail:SLPortal$2010@52.44.218.206:27017',
                'MONGO_DB' => 'ice9_staging',
                'CRM_URL' => 'http://xeniadocker.simplilearn.com/apachedev/git/xenia/public',
                'FRONTEND_REL_PATH' => $appendStr,
                'BASE_ACCOUNTS_URL' => 'http://cloud6docker.simplilearn.com/apachedev/git/cloud6/public/',
                'BASE_ACCOUNTS_INTERNAL_URL' => 'http://cloud6docker.simplilearn.com/apachedev/git/cloud6/server/',
                'FB_APP_ID' => '148240102012586',
                'CACHE_ENABLED' => '1',
                'CACHE_TYPE' => 'memcached',
                'CACHE_MEMCACHED_HOST' => 'localhost',
                'CACHE_MEMCACHED_PORT' => '11211',
                'SSVC_URL' => 'http://ice9docker.simplilearn.com/apachedev/pigen/web_services/ssvc/public',
                'SSVC_PROVIDER_KEY' => 'vdss209csad0g9j2fasefsTestingDev',
                'COMBINE_ALL_JS' => '0',
                'GOOGLE_ANALYTICS_CODE' => 'UA-32079340-4',
                'GOOGLE_ANALYTICS_DOMAIN_NAME' => HOST,
                'MELVIN_DB' => 'melv1n_crm2_docker',
                'ATP_EMAIL' => 'coders@simplilearn.com',
                'CORPORATE_SALES_EMAIL' => 'abhishekranjan@simplilearn.com',
                'FREE_RESOURCES_CDN_URL' => 'http://ice9docker.simplilearn.com/apachedev/git/melvin/static5',
                'SHOW_STATIC_HEADER' => '0',
                'COMMUNITY_BASE_URL' => 'http://'.HOST.'/apachedev/xenforo/',
                'PROFILER_ENABLED' => '0',
                'PROFILER_HIDDEN' => '1',
                'AUTO_ASSIGN_FRS_FAIL_EMAIL' => 'coders.i9@simplilearn.com',
                'AUTO_ASSIGN_COURSE_PREVIEW_FAIL_EMAIL' => 'coders.i9@simplilearn.com',
                'EMAIL_FRS_INFORM_CHANGE' => 'neelam.kumari@simplilearn.com',
                'EMAIL_LECTURE_CREATE_INFORM' => 'abhishekranjan@simplilearn.com',
                'WEBEX_SITEID' => '690319',
                'WEBEX_PARTNERID' => 'g0webx!',
                'WEBEX_SITEURL' => 'https://apidemoeu.webex.com/WBXService/XMLService',
                'GO_TO_WEBINAR_USER_ID' => 'abhijit@simplilearn.com',
                'GO_TO_WEBINAR_PASSWORD' => 'xtreme@1234',
                'GO_TO_WEBINAR_CLIENT_ID' => '6w6sKu3fhnjkHOLgkVULdYXNe3DzJUej',
                'GO_TO_WEBINAR_ORGANIZER_ID' => '473542436035096069',
                'IOS_RECEIPT_VALIDATION_URL' => 'https://sandbox.itunes.apple.com/verifyReceipt',
                'ACCOUNTS_PATH' => 'http://cloud6docker.simplilearn.com/apachedev/git/cloud6/public',
                'FRESHDESK_EMAIL' => 'kirit.bellubbi@simplilearn.com',
                'FRESHDESK_PASSWORD' => 'Kirit@123',
                'FRESHDESK_DOMAIN' => 'https://simplilearntest.freshdesk.com',
                'FRESHDESK_SECRET_KEY' => 'd05c037b1ca04a2d6c55762535a6ba21',
                'SENDER_NAME' => 'Simplilearn',
                'REPLYTO_NAME' => 'Simplilearn',
                'SEND_EMAIL_ID' => 'stagingmailer@simplicdn.net',
                'REPLYTO_EMAIL_ID' => 'stagingmailer@simplicdn.net',
                'AWS_SEARCH_QUERY_STRING' => 'http://search-staging-search-73e2yne6nv6mdv52ofplhzzedq.us-east-1.cloudsearch.amazonaws.com/2013-01-01/search',
                'AMBASSADOR_API_URL' => 'https://getambassador.com/api/v2/',
                'AMBASSADOR_USERNAME' => 'simplilearn',
                'AMBASSADOR_KEY' => 'ea33d9caefa527a8a828a66b49fa50f9',
                'REFERRER_PROGRAM_COUPON_CODE' => 'REFFERER20',
                'MBSY_NAME' => 'mbsy',
                'MONGO_CONN_STR_FRS' => 'mongodb://xmail:SLPortal$2010@52.44.218.206:27017',
                'MONGO_DB_FRS' => 'caldon',
                'WEBENGAGE_API_URL' => 'https://api.webengage.com/',
                'WEBENGAGE_API_AUTHORIZATION_KEY' => 'b63a2822-bbc4-4f23-a01c-ba1707c7533f',
                'WEBENGAGE_API_LICENSE_CODE' => '76ab161',
                'SEGMENT_API_CODE'=> 'N9cvcUyojxfGrq8gATfVtUHbK4z13faQ',
                'DISQUS_SHORTNAME' => 'devtest321',
                'DISQUS_PREFIX' => 'dev',
                'DISQUS_SECRET_KEY' => 'Tb31HXmeBMNywW4dOvZ8VKIeBDkdVoTC5kT18N5xPlyJ0I1ZvrBaNR8dOhAWjv2w',
                'DISQUS_PUBLIC_KEY' => 'uxQtSBJeexaSNhWBXeAyPRYbj7zkW2feNMsNWM934G6EzOGMTF4uTzocFLbEwkR4',
                'CALDON_API' => 'http://caldondocker.simplilearn.com/apachedev/git/caldon/public/api',
                #      'LEAD_FORM_EXPERIMENT_COURSE_IDS' => '11,18'
                'LEAD_FORM_EXPERIMENT_COURSE_IDS' => '',
                'RESTSERVER' => 'http://cloud6docker.simplilearn.com/apachedev/git/cloud6/server/',
                'B2B_DOMAIN_NAME' => 'http://enterprise.simplilearn.com'.$appendStr,
                'SALESFORCE_CLIENT_ID' => '3MVG99S6MzYiT5k9Zi_aoc.dqucMuIaEp0IRak1LQoaUVk2QwGWowo7PQ1gf.9Xw1K0.a3ABplG4f1bK8n6T0',
                'SALESFORCE_CLIENT_SECRET' => '6365020493184878233',
                'SALESFORCE_USER_NAME' => 'tushar.bansal@simplilearn.com.support',
                'SALESFORCE_PASSWORD' => 'support@123d0vmgXbUGf3MC0egDpCN1bKAj',
                'SALESFORCE_LOGIN_URL' => 'https://test.salesforce.com/services/oauth2/token',
                'SALESFORCE_LEAD_URL' => 'https://simplilearn-test--partialqa.cs58.my.salesforce.com/services/apexrest/LeadAPI',
                'SALESFORCE_LEARNER_API_ENDPOINT' => 'https://simplilearn-test--partialqa.cs58.my.salesforce.com/services/apexrest/learner',
                'SALESFORCE_OPPORTUNITY_ENDPOINT' => 'https://simplilearn-test--partialqa.cs58.my.salesforce.com/services/apexrest/createOpportunity',
                'SALESFORCE_LMS_DATA_URL' => 'https://simplilearn-test--partialqa.cs58.my.salesforce.com/services/apexrest/LMSUpdate',
                'WEB_ENGAGE_ID' => '76ab161',
                'KAFKA_CONN_URL' => 'http://104.211.217.159:8082/topics/click-events'
        ),
        'search_mailer' =>
        array (
                'emailIds' =>
                array (
                        0 => 'anuj.agarwal@simplilearn.com',
                        1 => 'neelam.kumari@simplilearn.com',
                ),
                'bccIds' =>
                array (
                        0 => 'abhijit@simplilearn.com',
                ),
        ),
        'awscloudsearch' =>
        array (
                'aws_cloudsearch_key' => 'AKIAIF7K64BU3AFSMBYQ',
                'aws_cloudsearch_secret_key' => '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',
                'endpoint' => 'http://search-staging-search-73e2yne6nv6mdv52ofplhzzedq.us-east-1.cloudsearch.amazonaws.com',
                'version' => '2013-01-01',
        ),
);
$config['dockercompose'] = array_replace_recursive($config['production'], $config['dockercompose']);


// -------------------------------------------------------------

// -----------------------------------------------------------------------
// TESTING ENV
// -----------------------------------------------------------------------
$config['testing'] = array (
  'phpSettings' =>
  array (
    'display_startup_errors' => '1',
    'display_errors' => '0',
    'session' =>
    array (
      'cookie_domain' => '.simplilearn.com',
    ),
  ),
  'resources' =>
  array (
    'frontController' =>
    array (
      'params' =>
      array (
        'displayExceptions' => '1',
      ),
    ),
    'db' =>
    array (
      'params' =>
          array (
              'host' => 'devmysql.simplilearn.net',
              'dbname' => 'ice9',
              'username' => 'paperclipadmin',
              'password' => 'Paperclip@123',
              'profiler' => '1',
          ),
    ),
    'mail' =>
    array (
      'transport' =>
      array (
        'type' => 'smtp',
        'auth' => 'login',
        'host' => 'email-smtp.us-east-1.amazonaws.com',
        'username' => 'AKIAI6PLZHO7NZUQGI7Q',
        'password' => 'AkEeVxfV2ad0KT/fNEqnwgN6M+6MIXLFSb/qXileS7Sk',
        'port' => '587',
        'ssl' => 'tls',
        'register' => '1',
      ),
    ),
  ),
    'salesforce' => array(
      'SF_USERNAME' => "admin@simplilearn.net.partialqa",
      'SF_PASSWORD' => "Simpli@1SFDCBQQS2FckY8cz9m1F3MuOPGyH",
      'WSDL_FILE_NAME' => "/enterprise.cs57_1.wsdl.xml",
    ),
  'constants' =>
  array (
    'WEBSITE_MAIN_URL' => 'http://'.HOST.$appendStr,
    'SEND_EMAIL_ID' => 'stagingmailer@simplicdn.net',
    'REPLYTO_EMAIL_ID' => 'stagingmailer@simplicdn.net',
    'MAIN_CDN_URL' => 'http://'.HOST_STATIC.'/apachedev/git/ice9/static',
    'MELVIN_DB_HOST' => 'devmysql.simplilearn.net',
    'MELVIN_DB_NAME' => 'melv1n',
    'MELVIN_DB_USERNAME' => 'paperclipadmin',
    'MELVIN_DB_PASSWORD' => 'Paperclip@123',
    'MONGO_CONN_STR' => 'mongodb://104.211.202.29:27017',
    'MONGO_DB' => 'ice9',
    'CLOUD6_DB' => 'cloud6_atlas',
    'MONGO_CONN_STR_FRS'=>'mongodb://104.211.202.29:27017',
    'MONGO_DB_FRS'=>'caldon',
    'MELVIN_DB' => 'melv1n',
    'SSVC_DATABASE' => 'ssvc',
    'SHELDON_B2B_PRICING_API' => 'http://'.HOST.'/resources/api/v1/getProductPrice',
    'SSVC_URL' => 'http://'.HOST.'/apachedev/pigen/web_services/ssvc/public/secure',
    'FRONTEND_API_URL' => 'http://'.HOST.$appendStr.'/api/v1',
    'FRONTEND_API_URL_NOCACHE' => 'http://'.HOST.$appendStr.'/api/v1/index/nocache',
     'SITE_API_URL_NOCACHE' =>  'http://'.HOST.$appendStr.'/api/v1/index/nocache',
    'FRONTEND_CDN_API_URL' => 'http://'.HOST.$appendStr.'/api/v1?method=',
    'FRONTEND_NON_CDN_API_URL' => 'http://'.HOST.$appendStr.'/api/v1?method=',
    'COMBINE_ALL_JS' => '0',
    'FRONTEND_URL' => 'http://'.HOST.$appendStr,
    'FRONTEND_CANONICAL_URL' => 'http://'.HOST.$appendStr,
    'FRONTEND_CANONICAL_URL_SECURE' => 'https://'.HOST.$appendStr,
    'BASE_LMS_URL' => 'http://'.HOST.'/apachedev/git/paperclip/public/',
    'LMS_DOMAIN' => HOST,
    //'PROFILER_ENABLED' => '0',
    //'PROFILER_HIDDEN' => '1',
    'PROFILER_ENABLED' => (in_array('127.0.0.1', $remoteIpArr) && $_SERVER['HTTP_HOST'] == 'localhost' && isset($_GET['profiler']) && $_GET['profiler'] == '1') ? '1' : '0',
    'PROFILER_HIDDEN' => (in_array('127.0.0.1', $remoteIpArr) && $_SERVER['HTTP_HOST'] == 'localhost' && isset($_GET['profiler']) && $_GET['profiler'] == '1') ? '0' : '1',
    'UPLOAD_CDN_URL' => 'http://cfs22.simplicdn.net',
    'BACKEND_URL' => 'http://'.HOST.'/apachedev/git/ice9/backend/public',
    'REL_UPLOAD_URL' => '../../static',
    'CRM_URL' => 'http://'.HOST.'/apachedev/git/xenia/public',
    'FREE_RESOURCES_CDN_URL' => 'http://'.HOST.'/apachedev/git/melvin/static5',
    'FRONTEND_REL_PATH' => $appendStr,
    'BASE_ACCOUNTS_URL' => 'http://'.HOST.'/apachedev/git/cloud6/public/',
    'BASE_ACCOUNTS_INTERNAL_URL' => 'http://'.HOST.'/apachedev/git/cloud6/server/',
    'FB_APP_ID' => '148240102012586',
    'ACCOUNTS_PATH' => 'http://'.HOST.'/apachedev/git/cloud6/public/',
    'META_DESCRIPTION' => 'Enroll for PMPÃ‚Â® certification training in Delhi.  Attend world renowned PMPÃ‚Â® classroom training organized by Simplilearn',
    'META_IMAGE' => 'http://'.HOST.$appendStr.'/logo.png',
    'META_KEYWORDS' => 'Online classes, Online courses, Free online courses, Online Certification, Online tutoring, Online Training, Certification programs, Microsoft Certification, Cisco Certification, IT Service management',
    'CACHE_ENABLED' => '0',
    'CACHE_TYPE' => 'memcached',
    'CACHE_MEMCACHED_HOST' => 'localhost',
    'CACHE_MEMCACHED_PORT' => '11211',
    'SSVC_PROVIDER_KEY' => 'vdss209csad0g9j2fasefsTestingDev',
    'SSVC_PROVIDER_KEY_WPP' => 'vdss209csad0g9j2fasefse09wppdev',
    'DATE_FORMAT' => 'Y-m-d',
    'WEB_ENGAGE_ID' => '76ab161',
    'GOOGLE_ANALYTICS_CODE' => 'UA-32079340-4',
    'GOOGLE_ANALYTICS_DOMAIN_NAME' => HOST,
    'SET_LOCALSTORAGE' => '0',
    'LOCALSTORAGE_CNAME' => '_site_menu',
    'GOOGLE_TAG_MANAGER_CODE' => 'GTM-TDKN64',
    'SHOW_STATIC_HEADER' => '0',
    'COMMUNITY_BASE_URL' => 'http://'.HOST.'/xenforo/',
    'LINKED_IN_API_KEY' => '78pdcmkabhtlxk',
    'CORPORATE_SALES_EMAIL' => 'anuj.agarwal@simplilearn.com',
    'AUTO_ASSIGN_FRS_FAIL_EMAIL' => 'srinivas.nerella@simplilearn.com',
    'AUTO_ASSIGN_COURSE_PREVIEW_FAIL_EMAIL' => 'coders.i9@simplilearn.com',
    'EMAIL_FRS_INFORM_CHANGE' => 'neelam.kumari@simplilearn.com',
    'EMAIL_LECTURE_CREATE_INFORM' => 'abhishekranjan@simplilearn.com',
    // 'WEBEX_SITEID' => '690319',
    // 'WEBEX_PARTNERID' => 'g0webx!',
    // 'WEBEX_SITEURL' => 'https://apidemoeu.webex.com/WBXService/XMLService',
    'GO_TO_WEBINAR_USER_ID' => 'abhijit@simplilearn.com',
    'GO_TO_WEBINAR_PASSWORD' => 'xtreme@1234',
    'GO_TO_WEBINAR_CLIENT_ID' => '6w6sKu3fhnjkHOLgkVULdYXNe3DzJUej',
    'GO_TO_WEBINAR_ORGANIZER_ID' => '473542436035096069',
    'IOS_RECEIPT_VALIDATION_URL' => 'https://sandbox.itunes.apple.com/verifyReceipt',
    'FRESHDESK_EMAIL' => 'kirit.bellubbi@simplilearn.com',
    'FRESHDESK_PASSWORD' => 'Kirit@123',
    'FRESHDESK_DOMAIN' => 'https://simplilearntest.freshdesk.com',
    'FRESHDESK_SECRET_KEY' => 'd05c037b1ca04a2d6c55762535a6ba21',
    'AWS_SEARCH_QUERY_STRING' => 'http://search-staging-search-73e2yne6nv6mdv52ofplhzzedq.us-east-1.cloudsearch.amazonaws.com/2013-01-01/search',
    'AMBASSADOR_API_URL' => 'https://getambassador.com/api/v2/',
    'AMBASSADOR_USERNAME' => 'simplilearn',
    'AMBASSADOR_KEY' => 'ea33d9caefa527a8a828a66b49fa50f9',
    'REFERRER_PROGRAM_COUPON_CODE' => 'REFFERER20',
    'MBSY_NAME' => 'mbsy',
    'DISQUS_SHORTNAME' => 'devtest321',
    'DISQUS_PREFIX' => 'dev',
    'DISQUS_SECRET_KEY' => 'Tb31HXmeBMNywW4dOvZ8VKIeBDkdVoTC5kT18N5xPlyJ0I1ZvrBaNR8dOhAWjv2w',
    'DISQUS_PUBLIC_KEY' => 'uxQtSBJeexaSNhWBXeAyPRYbj7zkW2feNMsNWM934G6EzOGMTF4uTzocFLbEwkR4',
    'CALDON_API' => 'http://dockerv2.simplilearn.com:8887/apachedev/git/caldon/public/api',
    'ENTERPRISE_CURRENCY_ID_US'=>2,
    'ENTERPRISE_COUNTRY_CODE_US'=>'US',
    'SALESFORCE_OID' => '00DN0000000Adbe',
    'SALESFORCE_HOST' => 'https://simplilearn--PartialQA.cs75.my.salesforce.com/',
    'W2L_WHITE_LIST_DOMAINS' => 'localhost,docker.simplilearn.com',
    'WEBENGAGE_API_URL' => 'https://api.webengage.com/',
    'WEBENGAGE_API_AUTHORIZATION_KEY' => 'b63a2822-bbc4-4f23-a01c-ba1707c7533f',
    'WEBENGAGE_API_LICENSE_CODE' => '76ab161',
    'SEGMENT_API_CODE'=> 'N9cvcUyojxfGrq8gATfVtUHbK4z13faQ',
    'B2B_DOMAIN_NAME' => 'http://enterprise.simplilearn.com'.$appendStr,
    'SF_ASSIGN_TRIGGER_VAL'=>'01Q28000000WFH8',
    'SALESFORCE_CLIENT_ID' => '3MVG9rnryk9FxFMX.Ol9n.__jZ3k0.60Ma6ihRgzA.IHRKOI582SLw1EONN5YRwnPibi6oyHCUC50lu8wCWxo',
    'SALESFORCE_CLIENT_SECRET' => '8E49D6A4EFDFC9414C4D23C3300709B14CA25F4BA0EBECE9EC4EEEA4282B4646',
    'SALESFORCE_USER_NAME' => 'salesforceapi@simplilearn.com.partialqa',
    'SALESFORCE_PASSWORD' => 'SimpliSfdc@123XWu4HDm8jFaPBqh7El5rKlEn3',
    'SALESFORCE_LOGIN_URL' => 'https://test.salesforce.com/services/oauth2/token',
    'EVENT_BRITE_TOKEN' =>'4FKV2QNGQPHUBJHBFJVO',
    'SALESFORCE_LEAD_URL' => 'https://simplilearn--PartialQA.cs75.my.salesforce.com/services/apexrest/LeadAPI',
    'SALESFORCE_LEARNER_API_ENDPOINT' => 'https://simplilearn--PartialQA.cs75.my.salesforce.com/services/apexrest/learner',
    'SALESFORCE_OPPORTUNITY_ENDPOINT' => 'https://simplilearn--PartialQA.cs75.my.salesforce.com/services/apexrest/createOpportunity',
    'SALESFORCE_LMS_DATA_URL' => 'https://simplilearn--PartialQA.cs75.my.salesforce.com/services/apexrest/LMSUpdate',
    'S3_PAYMENT_DOC_PATH' => 'payment_doc/test/',
    'CLOUD_SEARCH_TIMEOUT' => 1000, // in ms
    'ENTERPRISE_GDPR_COOKIE_NAME'=>'_enterprise_gdpr_user_consent',
    'GDPR_COOKIE_NAME'=>'_gdpr_user_consent',
    'GOOGLE_CONTACT_CLIENT_ID' => '903347033552-hml5m4qcj9v36ptiroasc664pabdd5td.apps.googleusercontent.com',
    'GOOGLE_CONTACT_API_KEY' => 'AIzaSyCdmNcfiW4FT04ukZtqErbuOcvt_qjUN-s',
    'GOOGLE_OPTIMIZE_COURSE_ID' => '4,256,b72',
    'NEW_VERSION_COURSE_PAGES' => '670,10,15,260,34,32',
    'REACT_COURSE_PAGES' => '670,10,15,260',
    'GA_CODE_OPTIMIZE' => 'UA-32079340-4',
    'ACCESS_CONTROL_ALLOW_ORIGIN_REACT'=>true,
    'KAFKA_CONN_URL' => 'http://104.211.217.159:8082/topics/click-events',
    'ENTERPRISE_MAIN_URL' => 'http://' . HOST . '/apachedev/git/ice9/frontend/public',
    'LEADAPIGATEWAYENDPOINT'=>'https://rk031posx3.execute-api.us-east-2.amazonaws.com/default/saveLead',
    'LEADAPIUPDATEENDPOINT'=>'https://kpp8i6hjm7.execute-api.us-east-2.amazonaws.com/dev/leads-testing/update-lead',
    'OPTIMIZE_CONTAINER_ID'=>'GTM-K4WJNNN',
    'GA_EXPERIMENT_IDS'=>'15:85465305-54,260:85465305-53',
    'AFFIRM_PUBLIC_KEY'=>'X2KFGUY8Z0ZXM5TR',
    'AFFIRM_JS_URL'=>'https://cdn1-sandbox.affirm.com/js/v2/affirm.js',
    'AFFIRM_ALLOWED_COUNTRY_SEAMLESS_PAYMENT'=>'US',
    'AFFIRM_APPLICABLE_COUNTRY_ID'=>34,
    'AFFIRM_SKIP_TRAINING_TYPE'=>"2",
    'AFFIRM_USD_CENTS'=>100,
    'JOB_SALARIES_API' => 'https://t9bsmdpuz0.execute-api.us-east-2.amazonaws.com/ice9-automation/fetch-salary-data',
    'AWS_S3_SECRET_KEY' => 'mV9tACvt+MC4PKZt38KP0g8TMc0hXM7AHaiwMS7x',
    'AWS_S3_ACCESS_KEY' => 'AKIATUE5EIC4JBFGYRMO',
    'AWS_S3_SECRET_KEY_WEBSITE_DEV' => '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',
    'AWS_S3_ACCESS_KEY_WEBSITE_DEV' => 'AKIATUE5EIC4JBFGYRMO',
    'AWS_S3_BUCKET_NAME'=> 'wwwstatic-test',
    'AWS_S3_IMAGES_PATH' => 'images',
    'AWS_S3_BASE_URL' => 'https://wwwstatic-test.s3.amazonaws.com',
    'AWS_REGION' => 'us-east-2',
    'ENTITY_TYPE_FOR_ENTERPRISE_COURSE_MAPPING' => 1,
    'ENTITY_TYPE_FOR_ENTERPRISE_BUNDLE_MAPPING' => 2,
    'GOOGLE_API_KEY' => 'AIzaSyByCCJJ1I1oOJ5MFvVUxE2tnIcDgW09aac',
    'PURGE_URL_API_ENDPOINT'=>'https://kpp8i6hjm7.execute-api.us-east-2.amazonaws.com/dev/purge-url',
    'GOOGLE_SHEET_ID'=>'1seCSwQu8vob9-oht2-EwcpsSw-5ibAaFP5hhJO79svI',
    'GOOGLE_SHEET_TAB_1'=>'Auto Approved',
    'FOOTERLINKLIMIT'=>10
  ),
  'testimonial_mailer' =>
  array (
    'emailIds' =>
    array (
      0 => 'kusum.saini@simplilearn.net',
      1 => 'manish.sharma@simplilearn.net',
    ),
  ),
  'search_mailer' =>
  array (
    'emailIds' =>
    array (
      0 => 'kusum.saini@simplilearn.net',
      1 => 'manish.sharma@simplilearn.net',
    ),
    'bccIds' =>
    array (
      0 => 'kusum.saini@simplilearn.net',
    ),
  ),
  'awscloudsearch' =>
  array (
    'aws_cloudsearch_key' => 'AKIAIF7K64BU3AFSMBYQ',
    'aws_cloudsearch_secret_key' => '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',
    'endpoint' => 'http://search-staging-search-73e2yne6nv6mdv52ofplhzzedq.us-east-1.cloudsearch.amazonaws.com',
    'version' => '2013-01-01',
  ),

  'mbsyconfig' =>
    array(
        'group_id'=>array('US'=>8,'IN'=>6,'ROW'=>8),
        'camp_id'=>array('US'=>33951,'IN'=>31810,'ROW'=>33951),
        'coupon_code'=>array('US'=>'REFERUS15','IN'=>'REFER15','ROW'=>'REFERUS15')
    ),
    'mbsyconfigmobileandroid' =>
    array(
        'group_id'=>array('US'=>8,'IN'=>6,'ROW'=>8),
        'camp_id'=>array('US'=>33951,'IN'=>31810,'ROW'=>33951),
        'coupon_code'=>array('US'=>'REFERUS15','IN'=>'REFER15','ROW'=>'REFERUS15')
    ),
    'mbsyconfigmobileios' =>
    array(
        'group_id'=>array('US'=>8,'IN'=>6,'ROW'=>8),
        'camp_id'=>array('US'=>33951,'IN'=>31810,'ROW'=>33951),
        'coupon_code'=>array('US'=>'REFERUS15','IN'=>'REFER15','ROW'=>'REFERUS15')
    ),
    'trainermbsyconfig' =>
    array(
        'group_id'=>array('US'=>7,'IN'=>9,'ROW'=>7),
        'camp_id'=>array('US'=>31786,'IN'=>33946,'ROW'=>31786)
    ),
    'cloudinary' =>
        array (
          "cloud_name" => "raghv",
          "api_key" => "296595584424198",
          "api_secret" => "DbDGxVIwz66HXYpRSHbv4VsLap0"
        ),
);
$config['testing'] = array_replace_recursive($config['production'], $config['testing']);


// ---------------------------------------------------------
// testing enterprise
// ---------------------------------------------------------

$config['testing_enterprise'] = array (
  'constants' =>
  array (
    'WEBSITE_MAIN_URL' => 'http://'.HOST.$appendStr,
    'SSVC_URL' => 'http://'.HOST.'/apachedev/pigen/web_services/ssvc/public',
    'MAIN_CDN_URL' => 'http://'.HOST.'/apachedev/git/ice9/static',
    'FRONTEND_URL' => 'http://'.HOST.$appendStr,
    'FRONTEND_CANONICAL_URL' => 'http://'.HOST.$appendStr,
    'FRONTEND_CANONICAL_URL_SECURE' => 'http://'.HOST.$appendStr,
    'FRONTEND_API_URL' => 'http://'.HOST.$appendStr.'/api/v1',
    'FRONTEND_API_URL_NOCACHE' => 'http://'.HOST.$appendStr.'/api/v1/index/nocache',
    'SITE_API_URL_NOCACHE' => 'http://'.HOST.$appendStr.'/api/v1/index/nocache',
    'FRONTEND_CDN_API_URL' => 'http://'.HOST.$appendStr.'/api/v1?method=',
    'FRONTEND_NON_CDN_API_URL' => 'http://'.HOST.$appendStr.'/api/v1?method=',
    'ENTERPRISE_COOKIE_DELIMITER' => '|^|',
    'B2B_IDENTIFIER' => '/partners',
    'IS_B2B' => 1,
    'B2B_RESTRICTIONS' => serialize(array('index','career-edge','about-us','our-team','careers','reviews','contact-us','authorized-training-partner','search','lvc-pass','career-data-labs','feed')),
    'B2B_RESTRICTIONS_GEN' => serialize(array('careers','search','lvc-pass','career-data-labs','feed')),
    'B2B_GENERAL_ID' => 'sl',
    'S3_PAYMENT_DOC_PATH' => 'payment_doc/test/',
  ),
);
$config['testing_enterprise'] = array_replace_recursive($config['testing'], $config['testing_enterprise']);
// -----------------------------------------------------------------
// DEVELOPMENT ENV
// -----------------------------------------------------------------
$config['development'] = array (
  'phpSettings' =>
  array (
    'display_startup_errors' => '1',
    'display_errors' => '1',
    'session' =>
    array (
      'cookie_domain' => '.simplilearn.com',
    ),
  ),
  'resources' =>
  array (
    'frontController' =>
    array (
      'params' =>
      array (
        'displayExceptions' => '1',
      ),
    ),
    'db' =>
    array (
      'params' =>
          array (
              'host' => 'devmysql.simplilearn.net',
              'dbname' => 'ice9',
              'username' => 'paperclipadmin',
              'password' => 'Paperclip@123',
              'profiler' => '1',
            ),
    ),
    'mail' =>
    array (
      'transport' =>
      array (
        'type' => 'smtp',
        'auth' => 'login',
        'host' => 'email-smtp.us-east-1.amazonaws.com',
        'username' => 'AKIAI6PLZHO7NZUQGI7Q',
        'password' => 'AkEeVxfV2ad0KT/fNEqnwgN6M+6MIXLFSb/qXileS7Sk',
        'port' => '587',
        'ssl' => 'tls',
        'register' => '1',
      ),
    ),
  ),
    'salesforce' => array(
        'SF_USERNAME' => "admin@simplilearn.net.partialqa",
        'SF_PASSWORD' => "Simpli@1SFDCBQQS2FckY8cz9m1F3MuOPGyH",
        'WSDL_FILE_NAME' => "/enterprise.cs57_1.wsdl.xml",
    ),
  'constants' =>
  array (
    'WEBSITE_MAIN_URL' => 'http://'.HOST.$appendStr,
    'SEND_EMAIL_ID' => 'stagingmailer@simplicdn.net',
    'REPLYTO_EMAIL_ID' => 'stagingmailer@simplicdn.net',
    'MAIN_CDN_URL' => 'http://'.HOST_STATIC.'/apachedev/git/ice9/static',
    'MELVIN_DB_HOST' => 'devmysql.simplilearn.net',
    'MELVIN_DB_NAME' => 'melv1n',
    'MELVIN_DB_USERNAME' => 'paperclipadmin',
    'MELVIN_DB_PASSWORD' => 'Paperclip@123',
    'MONGO_CONN_STR' => 'mongodb://104.211.202.29:27017',
    'MONGO_DB' => 'ice9',
    'CLOUD6_DB' => 'cloud6_atlas',
    'MONGO_CONN_STR_FRS'=>'mongodb://104.211.202.29:27017',
    'MONGO_DB_FRS'=>'caldon',
    'MELVIN_DB' => 'melv1n',
    'SSVC_DATABASE' => 'ssvc',
    'SSVC_URL' => 'http://'.HOST.'/apachedev/pigen/web_services/ssvc/public/secure',
    'SHELDON_B2B_PRICING_API' => "http://dockerv2.simplilearn.com:8889/resources/api/v1/getProductPrice",
    'FRONTEND_API_URL' => 'http://'.HOST.$appendStr.'/api/v1',
    'FRONTEND_API_URL_NOCACHE' => 'http://'.HOST.$appendStr.'/api/v1/index/nocache',
    'SITE_API_URL_NOCACHE' => 'http://'.HOST.$appendStr.'/api/v1/index/nocache',
    'FRONTEND_CDN_API_URL' => 'http://'.HOST.$appendStr.'/api/v1?method=',
    'FRONTEND_NON_CDN_API_URL' => 'http://'.HOST.$appendStr.'/api/v1?method=',
    'COMBINE_ALL_JS' => '0',
    'FRONTEND_URL' => 'http://'.HOST.$appendStr,
    'FRONTEND_CANONICAL_URL' => 'http://'.HOST.$appendStr,
    'FRONTEND_CANONICAL_URL_SECURE' => 'https://'.HOST.$appendStr,
    'BASE_LMS_URL' => 'http://dockerv2.simplilearn.com:8888/apachedev/git/paperclip/public/',
    'LMS_DOMAIN' => HOST,
    //'PROFILER_ENABLED' => '0',
    //'PROFILER_HIDDEN' => '1',
    'PROFILER_ENABLED' => (in_array('127.0.0.1', $remoteIpArr) && $_SERVER['HTTP_HOST'] == 'localhost' && isset($_GET['profiler']) && $_GET['profiler'] == '1') ? '1' : '0',
    'PROFILER_HIDDEN' => (in_array('127.0.0.1', $remoteIpArr) && $_SERVER['HTTP_HOST'] == 'localhost' && isset($_GET['profiler']) && $_GET['profiler'] == '1') ? '0' : '1',
    'UPLOAD_CDN_URL' => 'http://cfs22.simplicdn.net',
    'BACKEND_URL' => 'http://'.HOST.'/apachedev/git/ice9/backend/public',
    'REL_UPLOAD_URL' => '../../static',
    'CRM_URL' => 'http://'.HOST.'/apachedev/git/xenia/public',
    'FREE_RESOURCES_CDN_URL' => 'http://'.HOST.'/apachedev/git/melvin/static5',
    'FRONTEND_REL_PATH' => $appendStr,
    'BASE_ACCOUNTS_URL' => 'http://'.HOST.'/apachedev/git/cloud6/public/',
    'BASE_ACCOUNTS_INTERNAL_URL' => 'http://'.HOST.'/apachedev/git/cloud6/server/',
    'FB_APP_ID' => '148240102012586',
    'ACCOUNTS_PATH' => 'http://'.HOST.'/apachedev/git/cloud6/public/',
    'META_DESCRIPTION' => 'Enroll for PMPÃ‚Â® certification training in Delhi.  Attend world renowned PMPÃ‚Â® classroom training organized by Simplilearn',
    'META_IMAGE' => 'http://'.HOST.$appendStr.'/logo.png',
    'META_KEYWORDS' => 'Online classes, Online courses, Free online courses, Online Certification, Online tutoring, Online Training, Certification programs, Microsoft Certification, Cisco Certification, IT Service management',
    'CACHE_ENABLED' => '0',
    'CACHE_TYPE' => 'memcached',
    'CACHE_MEMCACHED_HOST' => 'localhost',
    'CACHE_MEMCACHED_PORT' => '11211',
    'SSVC_URL' => 'http://'.HOST.'/apachedev/pigen/web_services/ssvc/public',
    'SSVC_PROVIDER_KEY' => 'vdss209csad0g9j2fasefse09r8grs4',
    'SSVC_PROVIDER_KEY_WPP' => 'vdss209csad0g9j2fasefse09wppdev',
    'DATE_FORMAT' => 'Y-m-d',
    'WEB_ENGAGE_ID' => '76ab161',
    'GOOGLE_ANALYTICS_CODE' => 'UA-32079340-4',
    'GOOGLE_ANALYTICS_DOMAIN_NAME' => HOST,
    'SET_LOCALSTORAGE' => '0',
    'LOCALSTORAGE_CNAME' => '_site_menu',
    'GOOGLE_TAG_MANAGER_CODE' => 'GTM-TDKN64',
    'SHOW_STATIC_HEADER' => '0',
    'COMMUNITY_BASE_URL' => 'http://'.HOST.'/xenforo/',
    'LINKED_IN_API_KEY' => '78pdcmkabhtlxk',
    'CORPORATE_SALES_EMAIL' => 'anuj.agarwal@simplilearn.com',
    'AUTO_ASSIGN_FRS_FAIL_EMAIL' => 'srinivas.nerella@simplilearn.com',
    'AUTO_ASSIGN_COURSE_PREVIEW_FAIL_EMAIL' => 'coders.i9@simplilearn.com',
    'EMAIL_FRS_INFORM_CHANGE' => 'neelam.kumari@simplilearn.com',
    'EMAIL_LECTURE_CREATE_INFORM' => 'abhishekranjan@simplilearn.com',
    'WEBEX_SITEID' => '408917',
    'WEBEX_PARTNERID' => 'aGH4vnYT2S3iWFy55EybZA',
    'WEBEX_SITEURL' => 'https://simplilearn.webex.com/WBXService/XMLService',
    'GO_TO_WEBINAR_USER_ID' => 'abhijit@simplilearn.com',
    'GO_TO_WEBINAR_PASSWORD' => 'xtreme@1234',
    'GO_TO_WEBINAR_CLIENT_ID' => '6w6sKu3fhnjkHOLgkVULdYXNe3DzJUej',
    'GO_TO_WEBINAR_ORGANIZER_ID' => '473542436035096069',
    'IOS_RECEIPT_VALIDATION_URL' => 'https://sandbox.itunes.apple.com/verifyReceipt',
    'FRESHDESK_EMAIL' => 'kirit.bellubbi@simplilearn.com',
    'FRESHDESK_PASSWORD' => 'Kirit@123',
    'FRESHDESK_DOMAIN' => 'https://simplilearntest.freshdesk.com',
    'FRESHDESK_SECRET_KEY' => 'd05c037b1ca04a2d6c55762535a6ba21',
    'AWS_SEARCH_QUERY_STRING' => 'http://search-staging-search-73e2yne6nv6mdv52ofplhzzedq.us-east-1.cloudsearch.amazonaws.com/2013-01-01/search',
    'AMBASSADOR_API_URL' => 'https://getambassador.com/api/v2/',
    'AMBASSADOR_USERNAME' => 'simplilearn',
    'AMBASSADOR_KEY' => 'ea33d9caefa527a8a828a66b49fa50f9',
    'REFERRER_PROGRAM_COUPON_CODE' => 'REFFERER20',
    'MBSY_NAME' => 'mbsy',
    'DISQUS_SHORTNAME' => 'devtest321',
    'DISQUS_PREFIX' => 'dev',
    'DISQUS_SECRET_KEY' => 'Tb31HXmeBMNywW4dOvZ8VKIeBDkdVoTC5kT18N5xPlyJ0I1ZvrBaNR8dOhAWjv2w',
    'DISQUS_PUBLIC_KEY' => 'uxQtSBJeexaSNhWBXeAyPRYbj7zkW2feNMsNWM934G6EzOGMTF4uTzocFLbEwkR4',
    'CALDON_API' => 'http://dockerv2.simplilearn.com:8996/apachedev/git/caldon/public/api',
    'ENTERPRISE_CURRENCY_ID_US'=>2,
    'ENTERPRISE_COUNTRY_CODE_US'=>'US',
    'SALESFORCE_OID' => '00DN0000000Adbe',
    'SALESFORCE_HOST' => 'https://simplilearn--PartialQA.cs75.my.salesforce.com/',
    'W2L_WHITE_LIST_DOMAINS' => 'localhost,docker.simplilearn.com',
    'WEBENGAGE_API_URL' => 'https://api.webengage.com/',
    'WEBENGAGE_API_AUTHORIZATION_KEY' => 'b63a2822-bbc4-4f23-a01c-ba1707c7533f',
    'WEBENGAGE_API_LICENSE_CODE' => '76ab161',
    'SEGMENT_API_CODE'=> 'N9cvcUyojxfGrq8gATfVtUHbK4z13faQ',
    'B2B_DOMAIN_NAME' => 'http://enterprise.simplilearn.com'.$appendStr,
    'SF_ASSIGN_TRIGGER_VAL'=>'01Q28000000WFH8',
    'SALESFORCE_CLIENT_ID' => '3MVG9rnryk9FxFMX.Ol9n.__jZ3k0.60Ma6ihRgzA.IHRKOI582SLw1EONN5YRwnPibi6oyHCUC50lu8wCWxo',
    'SALESFORCE_CLIENT_SECRET' => '8E49D6A4EFDFC9414C4D23C3300709B14CA25F4BA0EBECE9EC4EEEA4282B4646',
    'SALESFORCE_USER_NAME' => "salesforceapi@simplilearn.com.partialqa",
    'SALESFORCE_PASSWORD' => 'SimpliSfdc@123XWu4HDm8jFaPBqh7El5rKlEn3',
    'SALESFORCE_LOGIN_URL' => 'https://test.salesforce.com/services/oauth2/token',
    'EVENT_BRITE_TOKEN' =>'4FKV2QNGQPHUBJHBFJVO',
    'SALESFORCE_LEAD_URL' => 'https://simplilearn--PartialQA.cs75.my.salesforce.com/services/apexrest/LeadAPI',
    'SALESFORCE_LEARNER_API_ENDPOINT' => 'https://simplilearn--PartialQA.cs75.my.salesforce.com/services/apexrest/learner',
    'SALESFORCE_OPPORTUNITY_ENDPOINT' => 'https://simplilearn--PartialQA.cs75.my.salesforce.com/services/apexrest/createOpportunity',
    'SALESFORCE_LMS_DATA_URL' => 'https://simplilearn--PartialQA.cs75.my.salesforce.com/services/apexrest/LMSUpdate',
    'S3_PAYMENT_DOC_PATH' => 'payment_doc/test/',
    'CLOUD_SEARCH_TIMEOUT' => 1000, // in ms
    'ENTERPRISE_GDPR_COOKIE_NAME'=>'_enterprise_gdpr_user_consent',
    'GDPR_COOKIE_NAME'=>'_gdpr_user_consent',
    'GOOGLE_CONTACT_CLIENT_ID' => '903347033552-hml5m4qcj9v36ptiroasc664pabdd5td.apps.googleusercontent.com',
    'GOOGLE_CONTACT_API_KEY' => 'AIzaSyCdmNcfiW4FT04ukZtqErbuOcvt_qjUN-s',
    'GOOGLE_OPTIMIZE_COURSE_ID' => '4,256,b72',
    'NEW_VERSION_COURSE_PAGES' => '670,10,15,260,32,34',
    'REACT_COURSE_PAGES' => '670,10,15,260',
    'GA_CODE_OPTIMIZE' => 'UA-32079340-4',
    'ACCESS_CONTROL_ALLOW_ORIGIN_REACT'=>true,
    'KAFKA_CONN_URL' => 'http://104.211.217.159:8082/topics/click-events',
    // 'KAFKA_CONN_URL' => 'https://kafka-staging-techadmin-f9ad.aivencloud.com:23515/topics/click-events',
    'ENTERPRISE_MAIN_URL' => 'http://' . HOST . '/apachedev/git/ice9/frontend/public',
    'LEADAPIGATEWAYENDPOINT'=>'https://rk031posx3.execute-api.us-east-2.amazonaws.com/default/saveLead',
    'LEADAPIUPDATEENDPOINT'=>'https://kpp8i6hjm7.execute-api.us-east-2.amazonaws.com/dev/leads-testing/update-lead',
    'OPTIMIZE_CONTAINER_ID'=>'GTM-K4WJNNN',
     'GA_EXPERIMENT_IDS'=>'15:85465305-54,260:85465305-53',
    'AFFIRM_PUBLIC_KEY'=>'X2KFGUY8Z0ZXM5TR',
    'AFFIRM_JS_URL'=>'https://cdn1-sandbox.affirm.com/js/v2/affirm.js',
    'AFFIRM_ALLOWED_COUNTRY_SEAMLESS_PAYMENT'=>'US',
    'AFFIRM_APPLICABLE_COUNTRY_ID'=>34,
    'AFFIRM_SKIP_TRAINING_TYPE'=>"2",
    'AFFIRM_USD_CENTS'=>100,
    'JOB_SALARIES_API' => 'https://t9bsmdpuz0.execute-api.us-east-2.amazonaws.com/ice9-automation/fetch-salary-data',
    
    'AWS_S3_SECRET_KEY' => 'mV9tACvt+MC4PKZt38KP0g8TMc0hXM7AHaiwMS7x',
    'AWS_S3_ACCESS_KEY' => 'AKIATUE5EIC4JBFGYRMO',
    'AWS_S3_SECRET_KEY_WEBSITE_DEV' => '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',
    'AWS_S3_ACCESS_KEY_WEBSITE_DEV' => 'AKIATUE5EIC4JBFGYRMO',
    'AWS_S3_BUCKET_NAME'=> 'wwwstatic-test',
    'AWS_S3_IMAGES_PATH' => 'images',
    'AWS_S3_BASE_URL' => 'https://wwwstatic-test.s3.amazonaws.com',
    'AWS_REGION' => 'us-east-2',
    'ENTITY_TYPE_FOR_ENTERPRISE_COURSE_MAPPING' => 1,
    'ENTITY_TYPE_FOR_ENTERPRISE_BUNDLE_MAPPING' => 2,
    'PURGE_URL_API_ENDPOINT'=>'https://kpp8i6hjm7.execute-api.us-east-2.amazonaws.com/dev/purge-url',
    'GOOGLE_API_KEY' => 'AIzaSyByCCJJ1I1oOJ5MFvVUxE2tnIcDgW09aac',
    'GOOGLE_SHEET_ID'=>'1seCSwQu8vob9-oht2-EwcpsSw-5ibAaFP5hhJO79svI',
    'GOOGLE_SHEET_TAB_1'=>'Auto Approved',
    'FOOTERLINKLIMIT'=>10,
    '_'
  ),
  'testimonial_mailer' =>
  array (
    'emailIds' =>
    array (
      0 => 'kusum.saini@simplilearn.net',
      1 => 'manish.sharma@simplilearn.net',
    ),
  ),
  'search_mailer' =>
  array (
    'emailIds' =>
    array (
      0 => 'kusum.saini@simplilearn.net',
      1 => 'manish.sharma@simplilearn.net',
    ),
    'bccIds' =>
    array (
      0 => 'kusum.saini@simplilearn.net',
    ),
  ),
  'awscloudsearch' =>
  array (
    'aws_cloudsearch_key' => 'AKIAIF7K64BU3AFSMBYQ',
    'aws_cloudsearch_secret_key' => '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',
    'endpoint' => 'http://search-staging-search-73e2yne6nv6mdv52ofplhzzedq.us-east-1.cloudsearch.amazonaws.com',
    'version' => '2013-01-01',
  ),
  'mbsyconfig' =>
    array(
        'group_id'=>array('US'=>8,'IN'=>6,'ROW'=>8),
        'camp_id'=>array('US'=>33951,'IN'=>31810,'ROW'=>33951),
        'coupon_code'=>array('US'=>'REFERUS15','IN'=>'REFER15','ROW'=>'REFERUS15')
    ),
    'mbsyconfigmobileandroid' =>
    array(
        'group_id'=>array('US'=>8,'IN'=>6,'ROW'=>8),
        'camp_id'=>array('US'=>33951,'IN'=>31810,'ROW'=>33951),
        'coupon_code'=>array('US'=>'REFERUS15','IN'=>'REFER15','ROW'=>'REFERUS15')
    ),
    'mbsyconfigmobileios' =>
    array(
        'group_id'=>array('US'=>8,'IN'=>6,'ROW'=>8),
        'camp_id'=>array('US'=>33951,'IN'=>31810,'ROW'=>33951),
        'coupon_code'=>array('US'=>'REFERUS15','IN'=>'REFER15','ROW'=>'REFERUS15')
    ),
    'trainermbsyconfig' =>
    array(
        'group_id'=>array('US'=>7,'IN'=>9,'ROW'=>7),
        'camp_id'=>array('US'=>31786,'IN'=>33946,'ROW'=>31786)
    ),
    // 'surveyData' =>
    // array(
    //     '33l155j'=>array('lead_team'=>'mql','sl_lead_type'=>'b2b','sl_site_module'=>'b2bsitetest'),
    //     '~5g1cid8'=>array('lead_team'=>'mql','sl_lead_type'=>'b2c','sl_site_module'=>'Video_lesson_popup'),
    //     '33l15nh'=>array('sl_lead_type'=>'b2c','lead_team'=>'mql','sl_site_module'=>'video_lesson_popup'),
    //     '7djkhlm'=>array('sl_lead_type'=> 'b2c','lead_team'=>'mql','sl_site_module'=>'ebook_popup'),
    // ),
    'cloudinary' =>
        array (
          "cloud_name" => "raghv",
          "api_key" => "296595584424198",
          "api_secret" => "DbDGxVIwz66HXYpRSHbv4VsLap0"
        ),
);
$config['development'] = array_replace_recursive($config['production'], $config['development']);



// ---------------------------------------------------------
// development enterprise
// ---------------------------------------------------------

$config['development_enterprise'] = array (
  'constants' =>
  array (
    'SSVC_URL' => 'http://'.HOST.'/apachedev/pigen/web_services/ssvc/public',
    'MAIN_CDN_URL' => 'http://'.HOST.'/apachedev/git/ice9/static',
    'FRONTEND_URL' => 'http://'.HOST.$appendStr,
    'FRONTEND_CANONICAL_URL' => 'http://'.HOST.$appendStr,
    'FRONTEND_CANONICAL_URL_SECURE' => 'http://'.HOST.$appendStr,
    'FRONTEND_API_URL' => 'http://'.HOST.$appendStr.'/api/v1',
    'FRONTEND_API_URL_NOCACHE' => 'http://'.HOST.$appendStr.'/api/v1/index/nocache',
    'SITE_API_URL_NOCACHE' =>  'http://'.HOST.$appendStr.'/api/v1/index/nocache',
    'FRONTEND_CDN_API_URL' => 'http://'.HOST.$appendStr.'/api/v1?method=',
    'FRONTEND_NON_CDN_API_URL' => 'http://'.HOST.$appendStr.'/api/v1?method=',
    'ENTERPRISE_COOKIE_DELIMITER' => '|^|',
    'B2B_IDENTIFIER' => '/partners',
    'IS_B2B' => 1,
    'B2B_RESTRICTIONS' => serialize(array('index','career-edge','about-us','our-team','careers','reviews','contact-us','authorized-training-partner','search','lvc-pass','career-data-labs','feed')),
    'B2B_RESTRICTIONS_GEN' => serialize(array('careers','search','lvc-pass','career-data-labs','feed')),
    'B2B_GENERAL_ID' => 'sl',
    'S3_PAYMENT_DOC_PATH' => 'payment_doc/test/',
  ),
);
$config['development_enterprise'] = array_replace_recursive($config['development'], $config['development_enterprise']);

$config['production_iceeleven'] = array(
    'constants' => array(
        'MAIN_CDN_URL' => 'https://ice11.simplilearn.com/static',
        'STATIC_URL' => 'https://static.simplilearn.com',
        'FRONTEND_URL' => 'https://ice11.simplilearn.com',
        'FRONTEND_API_URL' => 'https://ice11.simplilearn.com/api/v1',
        'FRONTEND_API_URL_NOCACHE' => 'https://ice11.simplilearn.com/api/v1/index/nocache',
        'SITE_API_URL_NOCACHE' => 'https://ice11.simplilearn.com/api/v1/index/nocache',
        'FRONTEND_CDN_API_URL' => 'https://ice11.simplilearn.com/api/v1?method=',
        'FRONTEND_NON_CDN_API_URL' => 'https://ice11.simplilearn.com/api/v1?method=',
        'FREE_RESOURCES_CDN_URL' => 'https://ice11.simplilearn.com/ice9',
        'COMBINE_ALL_JS' => 1,
        'UPLOAD_CDN_URL' => 'https://ice11.simplilearn.com',
        'META_IMAGE' => 'https://ice11.simplilearn.com/logo.png',
        'FRS_DEFAULT_THUMBNAIL_ARTICLE' => 'https://ice11.simplilearn.com/ice9/free_resources_article_thumb/Article.svgz',
        'FRS_DEFAULT_VERTICAL_THUMBNAIL_EBOOK' => 'https://ice11.simplilearn.com/ice9/ebooks/ebook_2.svgz',
        'FRS_DEFAULT_THUMBNAIL_EBOOK' => 'https://ice11.simplilearn.com/ice9/ebooks/ebook.svgz',
        'SEO_FRONTEND_URL' => 'http://ice11.simplilearn.com',
        'SEO_DEFAULT_THUMB_IMAGE_TO_SHARE' => 'https://ice11.simplilearn.com/ice9/free_resources_article_thumb/SIMPLILEARN_LOGO_th.jpg',
        'SEO_DEFAULT_COURSE_THUMB_IMAGE' => 'https://ice11.simplilearn.com/ice9/course_images/course_thumbnail_default.png',
        'FRS_WEBINAR_DEFAULT_ICON' => 'https://ice11.simplilearn.com/ice9/webinar_thumb_images/226x182/default_icon-webinar.svg',
        'ACCOUNTS_PATH' => 'https://accounts.simplilearn.com/',
        'BASE_ACCOUNTS_URL' => 'https://accounts.simplilearn.com/',
        'BASE_ACCOUNTS_INTERNAL_URL' => 'http://api.simplilearn.com/',
        'RESTSERVER' => 'http://api.simplilearn.com',
        'SSVC_URL' => 'http://staging.simplilearn.com/ssvc/public',
        ),
    'phpSettings' => array(
        'display_startup_errors' => 1,
        'display_errors' => 1
    ),
    'resources' => array(
        'frontController' => array(
            'params' => array(
                'displayExceptions' => 1
            )
        )
    )
);
$config['production_iceeleven'] = array_replace_recursive($config['staging'], $config['production_iceeleven']);

/*
[production_iceeleven : staging]
*/
$configSet = null;
$companyStr = '';
// ------------------------------------------------------------------
if (!empty($config[APPLICATION_ENV])) {
    $configSet =  $config[APPLICATION_ENV];

    // if domain is b2b and url contains b2b identifier append enterprise company name to frontend url
    $frontendUrl = $configSet['constants']['FRONTEND_URL'];
    if (!empty($configSet['constants']['IS_B2B']) && $configSet['constants']['IS_B2B'] == 1) {
        $host = !empty($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';
        $host = !empty($_SERVER['HTTP_X_FORWARDED_HOST'])?$_SERVER['HTTP_X_FORWARDED_HOST'] : $host;
        $reqUri = !empty($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
        $url = "$host$reqUri";$url=strtok($url,'?');
        $b2bId = $configSet['constants']['B2B_IDENTIFIER'];
        $b2bIdPos = strpos($url, $b2bId);
        if(!empty($configSet['constants']['B2B_IDENTIFIER']) && $b2bIdPos !== false){
            $frontendUrl = rtrim($frontendUrl, '/').$b2bId;
            if($host != ''){
                $companyStr = strtok(substr($url, $b2bIdPos+ strlen($b2bId) + 1), '/');
            }
        }//print_r($companyStr);
    }
    if ($companyStr != '') {
        $url = $frontendUrl .'/'.strtolower($companyStr);
        $configSet['constants']['FRONTEND_URL'] =  $url;
    }
    $host = !empty($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';
    $host = !empty($_SERVER['HTTP_X_FORWARDED_HOST'])?$_SERVER['HTTP_X_FORWARDED_HOST'] : $host;
    if(!empty($host)) {
        $host = explode('.',$host);
        if(!empty($host) && !empty($host[0]) && ($host[0] == $configSet['constants']['TRANSLATED_SITE'])) {
            $configSet['constants']['MONGO_DB'] = 'ice9_br';
            $configSet['constants']['MONGO_DB_FRS'] = 'caldon_br';
        }
    }
}
  return $configSet;
