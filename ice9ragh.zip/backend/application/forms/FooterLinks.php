<?php

class Form_FooterLinks extends BaseApp_SubForm
{

    private $isNew = false;
    public function __construct($isNew)
    {
        $this->isNew = $isNew;
        parent::__construct();
    }

    public function init()
    {

        $this->setName('footer_link');
        $this->setAttrib('class',$this->isNew ? 'add':'edit');
        $this->setMethod('post');
        //adding Label name element

        $session = new Zend_Session_Namespace('form');
        $subForm = new Zend_Form_SubForm();
        $objLabelsModel = new Model_Labels();
        
        $subForm->setName('contentForm');
        $exclude_country = $conIdByCluster = [];
        foreach ($session->contentForm as $product) {
            $selectedData = array();
            if ($product == 'new') {
                $selectedData = isset($session->contentFormData[$product]) ? array($session->contentFormData[$product]) : array();
            }
            $clusterModel = new Model_Clusters();
            $countryModel = new Model_Country();
            $footer_link_id = isset($selectedData[0]['id']) && !empty($selectedData[0]['id']) ? $selectedData[0]['id'] : '';
            $allCountriesFlag = isset($selectedData[0]['cluster'], $selectedData[0]['country']) && empty($selectedData[0]['cluster']) && empty($selectedData[0]['country']) ? 1 : 0;
            $footerCategoryVal = isset($selectedData[0]['link_category']) && !empty($selectedData[0]['link_category']) ? $selectedData[0]['link_category'] : 0;
            $links = isset($selectedData[0]['links']) && !empty($selectedData[0]['links']) ? $selectedData[0]['links'] : [];
            $status = isset($selectedData[0]['status']) && !empty($selectedData[0]['status']) ? $selectedData[0]['status'] : 1;
            
            $keyCountryIds = $keyClusterIds = [];
            if (!empty($selectedData)) {
                foreach ($selectedData as $selectedInfo) {
                    if (!empty($selectedInfo['cluster'])) {
                        $keyClusterIds[] = $selectedInfo['cluster'];
                        $excluded_con_arr = [];
                        if (!empty($selectedInfo['exculded_countries'])) {
                            $excluded_con_arr = explode(',', rtrim(ltrim(trim($selectedInfo['exculded_countries']), '['), ']'));

                            $exclude_country = array_merge($exclude_country, $excluded_con_arr);
                        }
                    }
                    if (!empty($selectedInfo['country'])) {
                        $keyCountryIds[] = $selectedInfo['country'];
                    }
                    if (!empty($selectedInfo['cluster'])) {
                        $conIdByClusterArr = $countryModel->getCountryidByClusterId($selectedInfo['cluster']);
                        $conIdByCluster = $conIdByClusterArr[$selectedInfo['cluster']];
                        $finalConIdByCluster = [];
                        $finalConIdByCluster = array_values(array_diff($conIdByCluster, $exclude_country));
                        $keyCountryIds = array_merge($keyCountryIds, $finalConIdByCluster);
                    }
                }
            }

            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);

            $classfck = 'fck-enable';
            if ($product === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
                $classfck = '';
            }

            $resourceIdDom = new Zend_Form_Element_Hidden('footer_link_id');
            $resourceIdDom->setValue($footer_link_id)->clearDecorators();

            $resourceLinksDom = new Zend_Form_Element_Hidden('footer_links');
            $resourceLinksDom->setValue(json_encode($links))->clearDecorators();

            $linkStatusDom = new Zend_Form_Element_Hidden('status');
            $linkStatusDom->setValue($status)->clearDecorators();
            
            //Country
            $country = new Zend_Form_Element_Select('country_id');
            if (empty($footer_link_id)) {
                $keyCountryIds = isset($selectedData['country_id']) ? $selectedData['country_id'] : array();
                $keyClusterIds = isset($selectedData['cluster_id']) ? $selectedData['cluster_id'] : array();
                $allCountriesFlag = isset($selectedData['all_country']) ? $selectedData['all_country'] : 0;
                $footerCategoryVal = isset($selectedData['footerCategory']) ? $selectedData['footerCategory'] : 0;
                //json_encode($selectedData['footer_links']);          
            }
            // $keyCountry = !empty($keyCountryIds) ? explode(',', $keyCountryIds) : array();
            $country->setOptions(array('required' => false, 'multiple' => true, 'multioptions' => $countryModel->getListDisplay()))
                ->setValue($keyCountryIds)->setAttrib('class', 'courseListAll countryListAll skipPreviousClick')
                ->setLabel('Country')
                ->setRegisterInArrayValidator(false);
            
            //Cluster
            $cluster = new Zend_Form_Element_Select('cluster_id');

            $keyCluster = !empty($keyClusterIds) ? implode(',', $keyClusterIds) : '';
            $cluster->setOptions(array('required' => false, 'multiple' => true, 'multioptions' => $clusterModel->fetchForSelect()))
                ->setValue($keyClusterIds)->setAttrib('class', 'multiple clusterListAll selectedCluster')
                ->setLabel('Cluster')
                ->setAttrib('data-last-selected', $keyCluster)
                ->setAttrib('onchange', 'countryByClusterSelectFooterLinks(this)')
                ->setAttrib('data-isedit', !empty($footer_link_id) ? true : false)
                ->setRegisterInArrayValidator(false);

            //Check All Countries
            $allCountryChecked = 0;
            $isClusterCountryDisabled = false;
            if (!$this->isNew && empty($keyCluster) && empty($keyCountry)) {
                $allCountryChecked = 1;
                $isClusterCountryDisabled = true;
            }
            if (!empty($allCountriesFlag) && $allCountriesFlag == 1) {
                $allCountryChecked = 1;
            }
            $checkAllCountry = new Zend_Form_Element_Checkbox('all_country');
            $checkAllCountry->setValue($allCountriesFlag)
                ->setLabel('All Countries')
                ->setAttrib('onclick', 'checkAllCountry(this)')
                ->setAttrib('class', 'allCountry');

            if ($isClusterCountryDisabled) {
                $cluster->setOptions(array('disabled' => true));
                $country->setOptions(array('disabled' => true));
            }
            if ($this->_allCountryDisable) {
                $checkAllCountry->setAttrib('onclick', 'return false')->setAttrib('style', 'opacity: 0.5;');;
            }

            $allFooterCategory = array(
                BaseApp_Dao_FooterLinks::TRENDING_COURSES_LINK => BaseApp_Dao_FooterLinks::TRENDING_COURSES_LINK_TEXT,
                BaseApp_Dao_FooterLinks::TRENDING_BUNDLES_LINK => BaseApp_Dao_FooterLinks::TRENDING_BUNDLES_LINK_TEXT,
                BaseApp_Dao_FooterLinks::TRENDING_RESOURCES_LINK => BaseApp_Dao_FooterLinks::TRENDING_RESOURCES_LINK_TEXT
            );
            $footerCategories = array_merge(array(0 => '--Select--'), $allFooterCategory);

            $footerCategory = new Zend_Form_Element_Select('footerCategory');
            $footerCategory->setLabel('Footer Category')
                ->setOptions(array('multioptions' => $footerCategories))
                ->setValue($footerCategoryVal)
                ->setAttrib('class', 'footer-category')
                ->setAttrib('onchange', 'showLinksDropDown(this)');

            //Invert Selection
            $invertBtn = new Zend_Form_Element_Button('invert');
            $invertBtn->setLabel('Invert Countries')->setAttrib('class', 'btn btn-warning remove invert-all')->setAttrib('onclick', 'invertSelection(this)');
            if ($allCountryChecked) {
                $invertBtn->setOptions(array('disabled' => true));
            }
            
            $courseCategory = new Zend_Form_Element_Select('courseCategory');
            $courseCategory->setLabel('Category')
                ->setOptions(array('multioptions' => array('0' => '--Select--') + $objLabelsModel->getLabelsToshow()))
                ->setAttribs(array('class' => 'course-category'));

            $frsModel = new Model_FrsMongo();
            $allSegmentsInfo = $frsModel->getAllSegments();
            $getAllResoursesTypes = $frsModel->getAllResoursesTypes();
            $mongoDb = new Model_Default;
            $segmentMappings = $mongoDb->CategorySegmentMapping->find(array())->fields(array('_id' => false))->toArray();
            
            $allSegments = array();
            foreach($allSegmentsInfo as $segmentInfo){
                $allSegments[$segmentInfo['id']] = $segmentInfo['value'];
            }

            $resourceCategory = new Zend_Form_Element_Select('resourceCategory');
            $resourceCategory->setLabel('Resource Category')
                ->setOptions(array('multioptions' => array('0' => '--Select--') + $allSegments))
                ->setAttribs(array('class' => 'resource-category res-filter'));

            $resourceProductType = new Zend_Form_Element_Select('resourceProductType');
            $resourceProductType->setLabel('Product Type')
                ->setOptions(array('multioptions' => array('0' => '--Select--','course'=>'Course','bundle'=>'Bundle')))
                ->setAttribs(array('class' => 'resource-prod-type res-filter'));
            

            $allResoursesTypes = [];
            foreach ($getAllResoursesTypes as $getAllResoursesType) {
                $getAllResoursesTypeVal = $getAllResoursesType;
                if($getAllResoursesType == 'video_homepage'){ 
                    $getAllResoursesType = 'Tutorial homepage'; 
                }
                $allResoursesTypes[$getAllResoursesTypeVal] = ucwords(str_replace('_',' ', $getAllResoursesType));
            }

            $resourceType = new Zend_Form_Element_Select('resourceType');
            $resourceType->setLabel('Resource Type')
                ->setOptions(array('multioptions' => array('0' => '--Select--') + $allResoursesTypes))
                ->setAttribs(array('class' => 'resource-type res-filter'));

            
            //course drop down
            $footerlinkModel = new Model_FooterLinks();
            $allCourses = $footerlinkModel->getAllCoursesLinks();
            $courseList = array();
            $courseListRes = array();
            $courseList[0] = '--Select--';
            $courseListRes[0] = '--Select--';
            foreach ($allCourses as $key => $value) {
                $courseList[$value['primary_label_id'].'_'.$value['course_id']] = $value['name'];
                $courseListRes[$value['primary_label_id'].'_c_'.$value['course_id']] = $value['name'];
            }
            $courseLinks = $courseList;
            $footerCourseLinkVal = 0; //place dynamic course id of course url
            $footerCourses = new Zend_Form_Element_Select('footerCourses');
            $footerCourses->setLabel('Link Product')
                ->setOptions(array('multioptions' => $courseLinks))
                ->setValue($footerCourseLinkVal)
                ->setAttribs(array('class' => 'footer-course'));
            
            $footer_courses_info = new Zend_Form_Element_Hidden('footer_courses_info');
            $footer_courses_info->setValue(json_encode($allCourses))->clearDecorators();

            //bundle drop down 
            $allBundles = $footerlinkModel->getAllBundlesLinks();
            $bundleList = array();
            $bundleList[0] = '--Select--';
            foreach ($allBundles as $key => $value) {
                $bundleList[$value['primary_label_id'].'_'.$value['bundle_id']] = $value['name'];
                $courseListRes[$value['primary_label_id'].'_b_'.$value['bundle_id']] = $value['name'];
            }
            $bundleLinks = $bundleList;
            $footerBundleLinkVal = 0;
            $footerBundles = new Zend_Form_Element_Select('footerBundles');
            $footerBundles->setLabel('Link Product')
                ->setOptions(array('multioptions' => $bundleLinks))
                ->setValue($footerBundleLinkVal)
                ->setAttribs(array('class' => 'footer-bundle'));

            $footer_bundles_info = new Zend_Form_Element_Hidden('footer_bundles_info');
            $footer_bundles_info->setValue(json_encode($allBundles))->clearDecorators();

            $segment_map_info = new Zend_Form_Element_Hidden('segment_map_info');
            $segment_map_info->setValue(json_encode($segmentMappings))->clearDecorators();
            

            //resourses drop down            
            $allResources = $frsModel->getAllResoursesLinks(); //fetch from mongo
            $resourceList = array();
            // $resourceList[0] = '--Select--';
            foreach ($allResources as $key => $resource) {
                $resource['id'] = $resource['_id']->{'$id'};
                unset($resource['_id']);
                $resourceList[json_encode($resource)] = $resource['title'];
            }
            $resourceLinks = $resourceList;
            $footerResourceLinkVal = 0;
            $footerResources = new Zend_Form_Element_Select('footerResources');
            $footerResources->setLabel('Link Resource')
                ->setOptions(array('multioptions' => $resourceLinks))
                ->setValue($footerResourceLinkVal)
                ->setAttribs(array('class' => 'footer-resource multiple filterSearch','size'=>5));
            
            $footer_resources_info = new Zend_Form_Element_Hidden('footer_resources_info');
            $footer_resources_info->setValue(json_encode($allResources))->clearDecorators();

            $resourceProduct = new Zend_Form_Element_Select('resourceProduct');
            $resourceProduct->setLabel('Product')
                ->setOptions(array('multioptions' => array('0' => '--Select--') + $courseListRes ))
                ->setAttribs(array('class' => 'resource-prod res-filter'));

            if(!$this->isNew){
                $footerCategory->setAttrib('disabled', 'disabled');
                $cluster->setAttrib('disabled' , 'disabled');
                $country->setAttrib('disabled' , 'disabled');
                $checkAllCountry->setAttrib('disabled', 'disabled');

                $hfooterCategory = new Zend_Form_Element_Hidden('hidden_footerCategory');
                $hfooterCategory->setValue($footerCategoryVal)->clearDecorators();

                $hall_country = new Zend_Form_Element_Hidden('hidden_all_country');
                $hall_country->setValue($allCountriesFlag)->clearDecorators();

                $hcluster_id = new Zend_Form_Element_Hidden('hidden_cluster_id');
                $hcluster_id->setValue(json_encode($keyClusterIds))->clearDecorators();
                
                $hcountry_id = new Zend_Form_Element_Hidden('hidden_country_id');
                $hcountry_id->setValue(json_encode($keyCountryIds))->clearDecorators();
                // prd([$keyClusterIds,$keyCountryIds]);
                $elements = array(
                    $footerCategory, $checkAllCountry, $cluster, $country, 
                    $invertBtn, $resourceIdDom,
                    $footer_resources_info,$footer_courses_info,$footer_bundles_info,
                    $segment_map_info,
                    $hfooterCategory,$hall_country,
                    $hcluster_id,$hcountry_id, $linkStatusDom
                );
                $rowForm->addElements($elements);
            }else{
                $elements = array(
                    $footerCategory, $checkAllCountry, $cluster, $country, 
                    $invertBtn, $resourceIdDom, 
                    $footer_resources_info,$footer_courses_info,$footer_bundles_info,
                    $segment_map_info,
                    $linkStatusDom
                );
                $rowForm->addElements($elements);
            }

            $link_text = new Zend_Form_Element_Text('link_text');
            $link_text->addFilter('stringTrim')
                ->setLabel('Link Text')
                ->setAttrib('placeholder', 'Link Text');
            $add = new Zend_Form_Element_Button('add');
            $add->setLabel('Add Link')
                ->setAttribs(array('class' => 'btn btn-success add', 'onclick' => 'addLink(this)'));
            switch ($footerCategoryVal) {
                case 1:
                    $footerBundles->setAttrib('style', 'display:none');
                    $footerResources->setAttrib('style', 'display:none');
                    $resourceCategory->setAttrib('style', 'display:none');
                    $resourceProductType->setAttrib('style', 'display:none');
                    $resourceProduct->setAttrib('style', 'display:none');
                    $resourceType->setAttrib('style', 'display:none');
                    break;
                case 2:
                    $footerCourses->setAttrib('style', 'display:none');
                    $footerResources->setAttrib('style', 'display:none');
                    $resourceCategory->setAttrib('style', 'display:none');
                    $resourceProductType->setAttrib('style', 'display:none');
                    $resourceProduct->setAttrib('style', 'display:none');
                    $resourceType->setAttrib('style', 'display:none');
                    break;
                case 3:
                    $footerCourses->setAttrib('style', 'display:none');
                    $footerBundles->setAttrib('style', 'display:none');
                    $courseCategory->setAttrib('style', 'display:none');
                    break;
                default:
                    $add->setAttrib('style', 'display:none');
                    $footerCourses->setAttrib('style', 'display:none');
                    $footerBundles->setAttrib('style', 'display:none');
                    $footerResources->setAttrib('style', 'display:none');
                    $link_text->setAttrib('style', 'display:none');
                    $courseCategory->setAttrib('style', 'display:none');
                    $resourceCategory->setAttrib('style', 'display:none');
                    $resourceProductType->setAttrib('style', 'display:none');
                    $resourceProduct->setAttrib('style', 'display:none');
                    $resourceType->setAttrib('style', 'display:none');
                    break;
            }
            $addLinkElements = array($courseCategory,$footerCourses, $footerBundles, $resourceCategory, $resourceProductType,$resourceProduct,$resourceType, $footerResources, $link_text, $add);

            $rowForm->addElements($addLinkElements);
            $rowForm->addElements(array($resourceLinksDom));
            $rowForm->setElementDecorators($this->getElementDecorators());
            switch ($footerCategoryVal) {
                case 1:
                    $rowForm->getElement('footerBundles')->getDecorator('Label')->setOption('style', 'display: none');
                    $rowForm->getElement('footerResources')->getDecorator('Label')->setOption('style', 'display: none');
                    $rowForm->getElement('resourceCategory')->getDecorator('Label')->setOption('style', 'display: none');
                    $rowForm->getElement('resourceProductType')->getDecorator('Label')->setOption('style', 'display: none');
                    $rowForm->getElement('resourceProduct')->getDecorator('Label')->setOption('style', 'display: none');
                    $rowForm->getElement('resourceType')->getDecorator('Label')->setOption('style', 'display: none');
                    break;
                case 2:
                    $rowForm->getElement('footerCourses')->getDecorator('Label')->setOption('style', 'display: none');
                    $rowForm->getElement('footerResources')->getDecorator('Label')->setOption('style', 'display: none');
                    $rowForm->getElement('resourceCategory')->getDecorator('Label')->setOption('style', 'display: none');
                    $rowForm->getElement('resourceProductType')->getDecorator('Label')->setOption('style', 'display: none');
                    $rowForm->getElement('resourceProduct')->getDecorator('Label')->setOption('style', 'display: none');
                    $rowForm->getElement('resourceType')->getDecorator('Label')->setOption('style', 'display: none');
                    break;
                case 3:
                    $rowForm->getElement('footerCourses')->getDecorator('Label')->setOption('style', 'display: none');
                    $rowForm->getElement('footerBundles')->getDecorator('Label')->setOption('style', 'display: none');
                    $rowForm->getElement('courseCategory')->getDecorator('Label')->setOption('style', 'display: none');
                    break;
                default:
                    $rowForm->getElement('link_text')->getDecorator('Label')->setOption('style', 'display: none');
                    $rowForm->getElement('footerCourses')->getDecorator('Label')->setOption('style', 'display: none');
                    $rowForm->getElement('footerBundles')->getDecorator('Label')->setOption('style', 'display: none');
                    $rowForm->getElement('footerResources')->getDecorator('Label')->setOption('style', 'display: none');
                    $rowForm->getElement('resourceCategory')->getDecorator('Label')->setOption('style', 'display: none');
                    $rowForm->getElement('resourceProductType')->getDecorator('Label')->setOption('style', 'display: none');
                    $rowForm->getElement('resourceProduct')->getDecorator('Label')->setOption('style', 'display: none');
                    $rowForm->getElement('resourceType')->getDecorator('Label')->setOption('style', 'display: none');
                    $rowForm->getElement('courseCategory')->getDecorator('Label')->setOption('style', 'display: none');
                    break;
            }

            if ($rowForm->getElement('add')) {
                $rowForm->getElement('add')->removeDecorator('Label');
            }

            if ($rowForm->getElement('invert')) {
                $rowForm->getElement('invert')->removeDecorator('Label');
            }

            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        }

        $subForm->setDecorators($this->getSubFormDecoratorsMain('course-faq-editor', 'contentForm'));

        $this->addSubForm($subForm, 'contentForm');
        //$this->addSubForm($addLinkSubForm, 'adlink');

        $this->addElement('submit', 'Save', array(
            'ignore' => true,
            'label' => 'Save'
        ));
        $this->addElement('button', 'Cancel', array(
            'label' => 'Cancel',
            'ignore' => true,
            //'id' => 'cancel_form',
            'class' => 'btn btn-warning',
            'onclick' => "window.location='" . BACKEND_URL . "/admin/footer-links'"
        ));
    }

    protected function getSubFormDecoratorsMain($className, $id)
    {
        return array(
            'FormElements',
            array(
                'HtmlTag', array('tag' => 'ul')
            ),
            array(
                array('row' => 'HtmlTag'),
                array('tag' => 'li', 'class' => $className, 'id' => $id)
            )
        );
    }

    public function removeUneditableElements()
    {
        return false;
    }

    // public function isValid($data, &$errorMessage = '', $showlink_urlField = true)
    // {
    //     $status = parent::isValid($data);
    //     // prd($data);
    //     if (!empty($data['contentForm'])) {
    //         $subForm = 'contentForm';
    //         foreach ($data['contentForm'] as $key => $row) {
    //             if (empty($row['all_country']) && !isset($row['cluster_id']) && !isset($row['country_id'])) {
    //                 $status = false;
    //                 $this->getSubForm($subForm)->getSubForm($key)->getElement('all_country')->setErrors(array(" Please select either All Countries or Cluser & Country"));
    //             }
    //             /* if (isset($row['cluster_id']) && !isset($row['country_id'])) {
    //                 $status = false;
    //                 $this->getSubForm($subForm)->getSubForm($key)->getElement('country_id')->setErrors(array(" Please select country"));
    //             } */
    //             // if (empty($row['link_text'])) {
    //             //     $status = false;
    //             //     $this->getSubForm($subForm)->getSubForm($key)->getElement('link_text')->setErrors(array("Please enter link_text."));
    //             // }
    //             // if (empty($row['link_url']) && $showlink_urlField) {
    //             //     $status = false;
    //             //     $this->getSubForm($subForm)->getSubForm($key)->getElement('link_url')->setErrors(array("Please enter link_url."));
    //             // }
    //         }
    //         return $status;
    //     }
    // }
}
