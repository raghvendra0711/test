<?php

class Form_Venues extends BaseApp_Form
{
    public function init(){
        $this->setName('Venues');
        $this->setMethod('post');
        
        $this->addElement('textarea','address',array(
            'label'=>'Address',
            'required'=>true,
            'cols' => 60,
            'rows' => 6,
            'class'=>'longtext'
        ));

         $this->addElement('text','map',array(
            'label'=>'Map ',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $obj =new Model_Country();
        $this->addElement('select','country_id',array(
            'label'=>'Country',
            'required'=>false,
            'multioptions'=>array('0'=>'--Select--') + $obj->fetchForSelect()
        ));

        $this->addElement('select','city_id',array(
            'label'=>'City',
            'required'=>false,
            'registerInArrayValidator' => false,
            'fetchDisabled' => 'true' 
        ));
             
         $this->addElement('text','contactPerson',array(
            'label'=>'Contact Person Name ',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

         $this->addElement('text','contactNumber',array(
            'label'=>'Contact Number ',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));
        
        $this->addElement('submit','Add Venue',array(
          'ignore'=>true,
          'label'=>'Add Venue',
          'class'=>'btn btn-info'
         ));
    }
}

