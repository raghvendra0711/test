<?php

class Form_MobileDeepLink extends BaseApp_Form
{
    const TYPE_COURSE='course';
    const TYPE_ARTICLE='article';
    const TYPE_MASTER='masters';
    const TYPE_WEBINAR='webinar';
    const TYPE_EBOOK='ebook';
    const TYPE_DEEPLINK='deeplink';
    
    const TYPE_BANNER='banner';
    const TYPE_HL='hl';
    const TYPE_VL='vl';
    const TYPE_GRID='grid';
    const TYPE_FRS='frs';
    
    
    protected $productTypes = array();
    protected $widgetTypes = array();
    
    public function __construct($data) {
        $this->init($data);
    }
    
    public function init($data){
        $this->setName('Mobile App');
        $this->setMethod('post');
        $this->loadDefaultDecorators();
        
        $this->productTypes=   array(
            self::TYPE_DEEPLINK         =>  'Deeplink'
           ,self::TYPE_COURSE           =>  'Course'
           ,self::TYPE_ARTICLE          =>  'Article'
           ,self::TYPE_MASTER           =>  'Master'
           ,self::TYPE_WEBINAR          =>  'Webinar'
           ,self::TYPE_EBOOK            =>  'Ebook'           
        );
        $this->widgetTypes=   array(
            self::TYPE_BANNER=>'Banner'
           ,self::TYPE_HL=>'Horizontal Listing'
           ,self::TYPE_VL=>'Vertical Listing'
           ,self::TYPE_GRID=>'Grid'
           ,self::TYPE_FRS=>'FRS'
        );                
        $widgetInfo = !empty($data['info']) ? $data['info'] : array();
        $widget_type = !empty($data['widget_type']) ? $data['widget_type'] : '';
        $data = !empty($data['data']) ? $data['data'] : array();              
        $this->addElement('text','widget_type',array(
            'label'=>'Widget Type*',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'attribs' => array('readonly' => 'readonly'),
            'autocomplete' => 'off',
            'value'     =>  $widget_type
        ));        
        $this->addElement('text', 'name', array(
            'label' => 'Name of the widget*',
            'required' => true,  
            'attribs' => array('required' => 'required','maxlength' => "30"),          
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'value' => !empty($widgetInfo['title']) ? $widgetInfo['title'] : ''
        ));
        $this->addElement('text', 'limit', array(
            'label' => 'Limit *',
            'filters' => array('StringTrim'),
            'attribs' => array('required' => 'required'),
            'class' => 'number',
            'required' => true,
            'value'=>!empty($widgetInfo['limit']) ? $widgetInfo['limit'] : ''
                        ));                           
        $content_type = isset($widgetInfo['product_type'])?$widgetInfo['product_type']:"";
        
        $this->addElement('hidden','product_type_old',array('value'=> $content_type,'required' => false));
        $this->addElement('select', 'product_type', array(
                            'label'                     => 'Product Type*',
                            'required'                  => true,
                            'style'                     => 'margin-bottom: 10px;',
                            'value'                     => '',
                            'registerInArrayValidator'  => false,
                            'multioptions'              => array('0' => '--Select product type--') + $this->productTypes
        ));

        //deeplink

        $this->addElement('text', 'title', array(
            'label' => 'Name of the Content*',
            'required' => true,
            'filters' => array('StringTrim'),
            // 'attribs' => array('required' => 'required','maxlength' => "30"),
            'class' => 'longtext'
        ));
        $this->getElement('title')->setDescription('Character limit is 30 for name');
        $this->getElement('name')->setDescription('Character limit is 30 for name');
        
        $validatorsName = array(new Zend_Validate_StringLength(array('max' => 30)));
        $this->getElement('name')->addValidators($validatorsName);

        $this->addElement('text', 'deep_link', array(
            'label' => 'Deep link*',
            'required' => true,
            // 'attribs' => array('required' => 'required'),
            'filters' => array('StringTrim'),
            'class' => 'longtext'
        ));
        
        if(!empty($data['image_url'])){
            $this->addElement('file','image_url',array(
                'label'=>'Image Link (720px X 320px, 100kb)* ',
                'required'=>true,
                // 'attribs' => array('required' => 'required'),
                'destination'=>sys_get_temp_dir(),
                'validators'=>array('Extension' => array('jpeg','png','jpg'),
                            array('ImageSize',false, array('maxwidth'=>720,'maxheight'=>320)),
                            array('Size',false, array('useByteString'=> true, 'max' => '100kb'))
                        
            )));                    
            $this->addElement('text', 'image_value', array(
                'label' => 'Image Link',
                // 'attribs' => array('required' => 'required'),                
                'value' => @$data['image_url'],
                'helper' => 'formNote'                
            ));
        }else{
            $this->addElement($this->createElement('file','image_url',array(
                'label'=>'Image Link (720px X 320px, 100kb)*',
                'required'=>true,
                // 'attribs' => array('required' => 'required'),
                'destination'=>sys_get_temp_dir(),
                'validators'=>array('Extension' => array('jpeg','png','jpg'),
                            array('ImageSize',false, array('maxwidth'=>720,'maxheight'=>320)),
                            array('Size',false, array('useByteString'=> true, 'max' => '100kb'))                        
            ))));
        }
        $deep_link_group = array('title','deep_link','image_url','image_value','btn_add_deeplink_item');
        $this->addDisplayGroup($deep_link_group, 'deep_link_group');
        $this->getDisplayGroup('deep_link_group')
                ->setLegend('Choose Deep-Link Widget Contents')
                ->clearDecorators()                                
                ->addDecorator('FormElements')
                ->addDecorator('Fieldset', array('class' => 'deeplink-form-contents','style' => 'padding: 4px 0px 10px 10px; Display:none;'));
        
        

        //deeplink

        //others
        
        $obj = new Model_Labels();
        $this->addElement('select', 'category_id', array(
            'label' => 'Choose Category',
            'value' => !empty($widgetInfo['category_id']) ? $widgetInfo['category_id'] : '',
            'required' => false,           
            'registerInArrayValidator' => false,
            'multioptions' => array('0' => '--Select Category--') + $obj->getPrimaryLableData()
        ));

        $content_type = isset($data['info']['content_type'])?$data['info']['content_type']:"";
        $this->addElement('select', 'choose_learning', array(                            
                            'required'                  => true,
                            'style'                     => 'display: none;',
                            'value'                     => $content_type,
                            'registerInArrayValidator'  => false,
                            'multioptions'              => array('course'   => 'Course', 'bundle'   => 'Master')
        ));

        //choose course/master

        $this->addElement('select', 'product_id_temp', array(
            'label' => 'Choose Product',
            'required' => false,
            'size' => 12,
            'multiple' => false,
            'class' => 'multiple',
            'registerInArrayValidator' => false,            
        ));

        $products = !empty($data['content_ids_sorted_list']) ? $data['content_ids_sorted_list'] : '';
        $this->addElement('hidden', 'product_ids', array('required' => false));       
        $this->addElement('hidden','product_name',array('required' => false));
       // end image content
              
       
        $catGroup = array('category_id','product_id_temp');
        $this->addDisplayGroup($catGroup, 'cat_group');
        $this->getDisplayGroup('cat_group')
            ->setLegend('Choose Widget Contents')
            ->clearDecorators()
            ->addDecorator('FormElements')
            ->addDecorator('Fieldset', array('class' => 'rest-form-contents', 'style' => 'Display: none; padding: 4px 0px 10px 10px;'));
        
        //others end

        
        $this->addElement('submit', 'Add Mobile App', array(
            'ignore' => true,
            'style' => 'display: none;',            
            'label' => 'Add Content',
            'class' => 'btn btn-info'
        ));

        //display contents as list           
        if(!empty($data['sequence_ids_sorted_list'])){   
            $widgets = !empty($data['sequence_ids_sorted_list'])?$data['sequence_ids_sorted_list']:'';
            $this->addElement('hidden', 'widgets_ids', array('required' => false, 'value' => $widgets));
            $this->addElement('select', 'banner_items_temp', array(
                'required' => false,            
                'multiple' => true,
                'class' => 'multiple widget_items',
                'style'   => 'display:none;',
                'registerInArrayValidator' => false,            
                'multioptions' => !empty($data['contentitems'])? $data['contentitems']:array(),
            )); 
            $this->addElement('submit', 'Reorder', array(
                'ignore' => true,
                // 'style' => 'display: none;',            
                'label' => 'Reorder & Save',
                'class' => 'btn btn-info'
            )); 
            $this->getElement('banner_items_temp')->removeDecorator('Label');
            $widgetGroup = array('banner_items_temp','Reorder','widgets_ids');
            
            $this->addDisplayGroup($widgetGroup, 'widget_group');
            $this->getDisplayGroup('widget_group')
                    ->setLegend('Banner Content List (Image size: 720px X 320px, 100kb)')
                    ->clearDecorators()
                    ->addDecorator('FormElements')
                    ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper'));                        
            }                
        // list end
    }
    
    public function isValid($data) {       
        $status = true; 
        if($data['product_type'] =='deeplink'){
            $status = parent::isValid($data);
            if (!$status){
                return false;
            } 
        }
               
        $sequenceObj         = new Model_WidgetSequence();
        $title = !empty($data['name']) ? $data['name'] : '';
        if($title == '' || strlen($title) >30 ){
            $this->getElement('name')->setErrors(array("name cannot exceed 30 charecter length"));
            return false;
        }
        if(empty($data['limit'])){
            $this->getElement('limit')->setErrors(array("limit should be greater than zero"));
            return false;
        } else{
            if ( ! preg_match('/^\d+$/', $data['limit']) ) {
                $this->getElement('limit')->setErrors(array("limit should be number "));
                return false;
              }
        }
        if (!empty($data['image_url']['name']) && ($data['image_url']['name'] != '')) {
            $fileName = $data['image_url']['name'];
            $fileName = explode(".", $fileName)[0];
            if (!@preg_match('/^[A-Za-z0-9_-]+$/', $fileName)) {
                //$this->getElement('product_type')->setErrors(array("File name can only be Alpha numerics with _ and - "));
                $this->getElement('image_url')->setErrors(array("File name can only be Alpha numerics with _ and - "));
                $status = false;
            }
        }

        $widgetData = $sequenceObj->getSectionContentByTitle($title);
        if (!empty($widgetData)&&empty($data['widget_id'])) {
            $this->getElement('name')->setErrors(array("duplicate widget title"));
            return false;
        }       
        return $status;
    }        
}
