<?php

class Form_ChangeLog extends BaseApp_Form {

    const ICE9_DB = 'ice9';
    
    public function init() {
        $this->setName('dbStructure');
        $this->setMethod('get');
        $this->addElement('select', 'db_name', array(
            'label' => 'Select Database:',
            'multioptions' => array(''=> '--SELECT--',  self::ICE9_DB=>self::ICE9_DB),
            'required' => true
        ));
        $this->addElement('select', 'table_name', array(
            'label' => 'Select Table:',
            'multioptions' => array(''=> '--SELECT--'),
            'required' => true
        ));        
        
        $this->addElement('text', 'row', array(
            'label' => 'Row Id',
            'required' => false
        ));
        
        $this->addElement('submit', 'show', array(
            'ignore' => true,
            'label' => 'Show',
            'class' => 'btn btn-info'
        ));        
        $this->_decorate();
        
    }
}
