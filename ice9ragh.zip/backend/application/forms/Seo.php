<?php

class Form_Seo extends BaseApp_SubForm
{
    
    protected $submitName = 'Save';

    protected $seoParams = array();
    
    private $_UrlTypes = array(
        'Category' => 'Category',
        'Category List' => 'Category List',
        'Course' => 'Course',
        'Course List' => 'Course List',
        'Bundle' => 'Bundle',
        'Articles' => 'Articles',
        'Articles List' => 'Articles List',
        'Webinars' => 'Webinars',
        'Webinars List' => 'Webinars List',
        'Practice Tests' => 'Practice Tests',
        'Practice Tests List' => 'Practice Tests List',
        'Videos' => 'Videos',
        'Videos List' => 'Videos List',
        'E-books' => 'E-books',
        'E-books List' => 'E-books List',
        'Corporate Training' => 'Corporate Training',
        'Lvc Pass' => 'Lvc Pass',
        'Vendor' => 'Vendor',
        'City Page' => 'City Page',
        'Lecture Page' => 'Lecture Page',
        'Others' => 'Others'
    );
    
    private $_UrlRequiresThumbnail = array(
        'Category',
        'Course',
        'Bundle',
        'Articles',
        'Webinars',
        'Videos',
        'E-books',
        'Lecture Page'
    );

     public function __construct($paramsArr = array()) {
        $this->seoParams = $paramsArr;
        $this->init();
    }
    public function init(){
        $this->setName('Seo');
        $this->setMethod('post');
        
        $this->addElement('text','urlShow',array(
            'label'=>'URL*',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'disabled' => true,
            'autocomplete' => 'off',
            'validators' => array(
                new Zend_Validate_Db_NoRecordExists(
                            array(
                                'table' => 'seo',
                                'field' => 'url'
                            )
                        )
            )
        ));
        
        $this->addElement('select','url_type',array(
            'label'=>'What type of URL it is? *',
            'required'=>true,
            'registerInArrayValidator' => false,
            'multioptions'=> array(''=>'--Select--') + $this->_UrlTypes
        ));


        if(!empty($this->seoParams)){
            if((isset($this->seoParams['course_id']) && !empty($this->seoParams['course_id'])) || (isset($this->seoParams['bundle_id']) && !empty($this->seoParams['bundle_id']))){
                $obPt = new BaseApp_Dao_ProductTypes();
                $productDetails = $obPt->fetchForSelect();
                unset($productDetails[3]);
                unset($productDetails[4]);
                $this->addElement('select','linkable_type_id',array(
                    'label'=>'Product Type',
                    'class'=>'seo_linkable_type_id',
                    'disabled' => true,
                    'registerInArrayValidator' => false,
                    'multioptions'=> array('0'=>'--Select--') + $productDetails,
                    'value'=> !empty($this->seoParams['product_type_id']) ? $this->seoParams['product_type_id']:0,
                ));

                if( (!empty($this->seoParams['product_type_id']) && $this->seoParams['product_type_id'] == BaseApp_Dao_ProductTypes::TYPE_ID_COURSE) || !empty($this->seoParams['course_id'])) {
                    $productObj = new Model_Courses();
                }elseif( (!empty($this->seoParams['product_type_id']) && $this->seoParams['product_type_id'] == BaseApp_Dao_ProductTypes::TYPE_ID_BUNDLE) || !empty($this->seoParams['bundle_id']) ){
                    $productObj = new Model_Bundles();
                }else{
                    $productObj = new Model_Courses();
                }

                $this->addElement('select','linkable_id',array(
                    'label'=>'Product',
                    'class'=>'seo_linkable_id',
                    'disabled' => true,
                    'registerInArrayValidator' => false,
                    'fetchDisabled' => 'true',
                    'multioptions'=> array('0'=>'--Select--') + $productObj->fetchProductDetails(),
                    'value'=>$this->seoParams['course_id'],

                ));

                $objCountry = new Model_Country();
                $this->addElement('select','seo_country_id',array(
                    'label'=>'Country',
                    'class'=>'seo_country_id',
                    'disabled' => true,
                    'registerInArrayValidator' => false,
                    'multioptions'=> array('0'=>'--Select--') + $objCountry->fetchForSelect(),
                    'value'=> !empty($this->seoParams['country_id']) ? $this->seoParams['country_id']: 0,
                ));

                $objCity = new Model_City();
                $this->addElement('select','seo_city_id',array(
                    'label'=>'City',
                    'class'=>'seo_city_id',
                    'disabled' => true,
                    'registerInArrayValidator' => false,
                    'multioptions'=> array('0'=>'--Select--') + $objCity->fetchForSelect(),
                    'value'=> !empty($this->seoParams['city_id']) ? $this->seoParams['city_id'] : 0,
                ));

                $this->addElement('textarea','about_city',array(
                    'label'=>'City Description',
										'filter'=>array('StringTrim'),
                    'rows' => 5,
                    'cols' => 60,
                    'class'=>'fck-enableDesc',
                    'autocomplete' => 'off'

                ));    

                $this->addElement('textarea','city_address',array(
                    'label'=>'City Address',
                    'rows' => 5,
                    'cols' => 60,
                    'class'=>'longtext',
                    'autocomplete' => 'off'

                ));    
            }
        }else{
            $obPt = new BaseApp_Dao_ProductTypes();
            $productDetails = $obPt->fetchForSelect();
            unset($productDetails[3]);
            unset($productDetails[4]);
            $this->addElement('select','linkable_type_id',array(
                'label'=>'Product Type',
                'class'=>'seo_linkable_type_id',
                'disabled' => false,
                'registerInArrayValidator' => false,
                'multioptions'=> array('0'=>'--Select--') + $productDetails
            ));

            $this->addElement('select','linkable_id',array(
                'label'=>'Product',
                'class'=>'seo_linkable_id',
                'disabled' => true,
                'registerInArrayValidator' => false,
                'fetchDisabled' => 'true',
            ));

            $objCountry = new Model_Country();
            $this->addElement('select','seo_country_id',array(
                'label'=>'Country',
                'class'=>'seo_country_id',
                'disabled' => true,
                'registerInArrayValidator' => false,
                'multioptions'=> array('0'=>'--Select--') + $objCountry->fetchForSelect()
            ));


            $this->addElement('select','seo_city_id',array(
                'label'=>'City',
                'class'=>'seo_city_id',
                'disabled' => true,
                'registerInArrayValidator' => false,
                'fetchDisabled' => 'true',
            ));

            $this->addElement('textarea','about_city',array(
                'label'=>'City Description',
								'filter'=>array('StringTrim'),
                'rows' => 5,
                'cols' => 60,
                'disabled' => true,
                'class'=>'fck-enableDesc',
                'autocomplete' => 'off'

            ));

            $this->addElement('textarea','city_address',array(
                    'label'=>'City Address',
                    'rows' => 5,
                    'cols' => 60,
                    'class'=>'longtext',
                    'autocomplete' => 'off'

                ));    
        }
        

        $this->addElement('text','title',array(
            'label'=>'Meta Title*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off'
        ));
        
        $this->addElement('text','description',array(
            'label'=>'Meta Description*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off'
        ));
        
        $this->addElement('text','keyword',array(
            'label'=>'Meta Keyword(CSV)*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off'
        ));
        
        $this->addElement('text','h1Tag',array(
            'label'=>'H1 Tag*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off'
        ));
        $this->addElement('text','h2Tag',array(
            'label'=>'H2 Tag (max 82 characters)',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off'
        ));
            
        $this->addElement('text','thumb_image',array(
            'label'=>'Thumbnail Image',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off',
            'validators' => array(
                new BaseApp_Validate_Image('seo', 'thumb_image', true)
            )
        ));
        
        $this->addElement('text','alt_text',array(
            'label'=>'Alt text',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off'
        ));
        
        $this->addElement('text','canonical',array(
            'label'=>'Canonical',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off'
        ));

        $this->addElement('checkbox','noindex',array(
            'label'=>'No Index',
            'value'=>0
        ));
        
        $this->addElement('checkbox','https',array(
            'label'=>'HTTPS',
            'value'=>0
        ));
        
        $this->addElement('text','amp_link',array(
            'label'=>'AMP Link',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off',
            'validators' => array(
                    new BaseApp_Validate_Url()
                )
        ));

        /**
         * H2 tags for course page Sub form
         */
        $h2SubForm = new Zend_Form_SubForm();
        $h2SubForm->setName('h2tags'); 
        $h2SubForm->setLegend(' H2 Tags');

        $lengthValidator =  array(new Zend_Validate_StringLength(array('max' => 35)));

        $h2SubForm->addElement('text',BaseApp_Dao_ProductSectionData::SECTION_TYPE_COURSE_OVERVIEW_H2,
        array(
            'label'=>'Course Overview',
            'class' => 'h2tag-field',
            'data-suffix'=> 'Course Overview',
            'filters'=>array('StringTrim'),
            'class' => 'h2TagElement',
            'validators' =>  $lengthValidator
        ));
        
        $h2SubForm->addElement('text',BaseApp_Dao_ProductSectionData::SECTION_TYPE_KEY_FEATURES_H2,
        array(
            'label'=>'Key Features',
            'class' => 'h2tag-field',
            'data-suffix'=> 'Key Features',
            'class' => 'h2TagElement',
            'filters'=>array('StringTrim'),
            'validators' =>  $lengthValidator
        ));
        
        $h2SubForm->addElement('text',BaseApp_Dao_ProductSectionData::SECTION_TYPE_COURSE_DESCRIPTION_H2,
        array(
            'label'=>'Course Description',
            'class' => 'h2tag-field',
            'data-suffix'=> 'Course Description',
            'class' => 'h2TagElement',
            'filters'=>array('StringTrim'),
            'validators' =>  $lengthValidator
        ));

        $h2SubForm->addElement('text',BaseApp_Dao_ProductSectionData::SECTION_TYPE_COURSE_CURRICULUM_H2,
        array(
            'label'=>'Course Curriculum',
            'class' => 'h2tag-field',
            'data-suffix'=> 'Course Curriculum',
            'class' => 'h2TagElement',
            'filters'=>array('StringTrim'),
            'validators' =>  $lengthValidator
        ));

        $h2SubForm->addElement('text',BaseApp_Dao_ProductSectionData::SECTION_TYPE_COURSE_PREVIEW_H2,
        array(
            'label'=>'Course Preview',
            'class' => 'h2tag-field',
            'data-suffix'=> 'Course Preview',
            'class' => 'h2TagElement',
            'filters'=>array('StringTrim'),
            'validators' =>  $lengthValidator
        ));

        $h2SubForm->addElement('text',BaseApp_Dao_ProductSectionData::SECTION_TYPE_COURSE_ADVISOR_H2,
        array(
            'label'=>'Course Advisor',
            'class' => 'h2tag-field',
            'data-suffix'=> 'Course Advisor',
            'class' => 'h2TagElement',
            'filters'=>array('StringTrim'),
            'validators' =>  $lengthValidator
        ));

        $h2SubForm->addElement('text',BaseApp_Dao_ProductSectionData::SECTION_TYPE_EXAM_CERTIFICATION_H2,
        array(
            'label'=>'Exam and Certification',
            'class' => 'h2tag-field',
            'data-suffix'=> 'Exam and Certification',         
            'class' => 'h2TagElement',
            'filters'=>array('StringTrim'),
            'validators' =>  $lengthValidator
        ));

        $h2SubForm->addElement('text',BaseApp_Dao_ProductSectionData::SECTION_TYPE_COURSE_REVIEW_H2,
        array(
            'label'=>'Review',
            'class' => 'h2tag-field',
            'data-suffix'=> 'Review',
            'class' => 'h2TagElement',
            'filters'=>array('StringTrim'),
            'validators' =>  $lengthValidator
        ));

        $h2SubForm->addElement('text',BaseApp_Dao_ProductSectionData::SECTION_TYPE_COURSE_FAQ_H2,
        array(
            'label'=>'FAQ',
            'class' => 'h2tag-field',
            'data-suffix'=> 'FAQ',
            'class' => 'h2TagElement',
            'filters'=>array('StringTrim'),
            'validators' =>  $lengthValidator
        ));

        $h2SubForm->addElement('text',BaseApp_Dao_ProductSectionData::SECTION_TYPE_COURSE_TRAINING_OPTION_H2,
        array(
            'label'=>'Training Option',
            'class' => 'h2tag-field',
            'data-suffix'=> 'Training Option',
            'class' => 'h2TagElement',
            'filters'=>array('StringTrim'),
            'validators' =>  $lengthValidator
        ));

        $h2SubForm->addElement('text',BaseApp_Dao_ProductSectionData::SECTION_TYPE_COURSE_BENEFITS_H2,
        array(
            'label'=>'Benefits',
            'class' => 'h2tag-field',
            'data-suffix'=> 'Benefits',
            'class' => 'h2TagElement',
            'filters'=>array('StringTrim'),
            'validators' =>  $lengthValidator
        ));

        $h2SubForm->addElement('text',BaseApp_Dao_ProductSectionData::SECTION_TYPE_COURSE_SKILL_COVERED_H2,
        array(
            'label'=>'Skills Covered',
            'class' => 'h2tag-field',
            'data-suffix'=> 'Skills Covered',
            'class' => 'h2TagElement',
            'filters'=>array('StringTrim'),
            'validators' =>  $lengthValidator
        ));

        $h2SubForm->setElementDecorators($this->getElementDecorators());        
        $this->addSubForm($h2SubForm, 'h2tags');

        /**
         * END: H2 tags for course page Sub form
         */

        
        $session = new Zend_Session_Namespace('form');
        
        /*
         * Start: Sub form for FB open graphs
         */

        $this->addElement('hidden','fbOpenGraph_err',array(
                'required'=>false,
                'value'=>''
        ));
        
        $keySiteName = isset($session->fbOpenGraphData['siteName'])?$session->fbOpenGraphData['siteName']:'';
        $keyPageUrl = isset($session->fbOpenGraphData['pageUrl'])?$session->fbOpenGraphData['pageUrl']:'';
        $keyTitle = isset($session->fbOpenGraphData['title'])?$session->fbOpenGraphData['title']:'';
        $keyDescription = isset($session->fbOpenGraphData['description'])?$session->fbOpenGraphData['description']:'';
        $keyImage = isset($session->fbOpenGraphData['image'])?$session->fbOpenGraphData['image']:'';
        
        $subForm = new Zend_Form_SubForm();
        $subForm->setName('fbOpenGraph'); 
        
        $fbSiteName = new Zend_Form_Element_Text('siteName');
        $fbSiteName->setLabel('Site Name')->addFilter('stringTrim')->setAttrib('class', 'longtext')->setValue($keySiteName);
                
        $fbPageUrl = new Zend_Form_Element_Text('pageUrl');
        $fbPageUrl->setLabel('URL')->addFilter('stringTrim')->setAttrib('class', 'longtext')->setValue($keyPageUrl);
                
        $fbTitle = new Zend_Form_Element_Text('title');
        $fbTitle->setLabel('Title')->addFilter('stringTrim')->setAttrib('class', 'longtext')->setValue($keyTitle);
        
        $fbDescription = new Zend_Form_Element_Textarea('description');
        $fbDescription->setLabel('Description')->setAttrib('rows', 6)->setAttrib('cols', 60)->setValue($keyDescription);
        
        $fbImage = new Zend_Form_Element_Text('image');
        $fbImage->setLabel('Image')->addFilter('stringTrim')->setValue('')->setAttrib('class', 'longtext')->setValue($keyImage);
        

        $elements = array($fbSiteName, $fbPageUrl, $fbTitle, $fbDescription, $fbImage);            

        $subForm->addElements($elements);
        $subForm->setElementDecorators($this->getElementDecorators());
        $subForm->setDecorators($this->getSubFormDecoratorsMain('fbOpenGraph', 'fbOpenGraph'));            
        $subForm->setLegend('Facebook Open Graph');
        $this->addSubForm($subForm, 'fbOpenGraph');   

        
        
        /*
         * End: Sub form for FB open graphs
         */
        
        /*
         * Start: Sub form for TwitterCards
         */
        
        $this->addElement('hidden','twitterCards_err',array(
                'required'=>false,
                'value'=>''
        ));
        $keySiteName = isset($session->twitterCardsData['siteName'])?$session->twitterCardsData['siteName']:'';
        $keyPageUrl = isset($session->twitterCardsData['pageUrl'])?$session->twitterCardsData['pageUrl']:'';
        $keyTitle = isset($session->twitterCardsData['title'])?$session->twitterCardsData['title']:'';
        $keyDescription = isset($session->twitterCardsData['description'])?$session->twitterCardsData['description']:'';
        $keyImage = isset($session->twitterCardsData['image'])?$session->twitterCardsData['image']:'';
        
        $subForm = new Zend_Form_SubForm();
        $subForm->setName('twitterCards'); 
                
        $twitterPageUrl = new Zend_Form_Element_Text('pageUrl');
        $twitterPageUrl->setLabel('URL')->addFilter('stringTrim')->setValue($keyPageUrl)->setAttrib('class', 'longtext');
        
                
        $twitterSite = new Zend_Form_Element_Text('siteName');
        $twitterSite->setLabel('Site')->addFilter('stringTrim')->setValue($keySiteName)->setAttrib('class', 'longtext');
        
        $twitterTitle = new Zend_Form_Element_Text('title');
        $twitterTitle->setLabel('Title')->addFilter('stringTrim')->setValue($keyTitle)->setAttrib('class', 'longtext');
        
        $twitterDescription = new Zend_Form_Element_Textarea('description');
        $twitterDescription->setLabel('Description')->setAttrib('rows', 6)->setAttrib('cols', 60)->setValue($keyDescription);
        
        $twitterImage = new Zend_Form_Element_Text('image');
        $twitterImage->setLabel('Image')->addFilter('stringTrim')->setValue($keyImage)->setAttrib('class', 'longtext');
        

        $elements = array($twitterPageUrl, $twitterSite, $twitterTitle, $twitterDescription, $twitterImage);            

        $subForm->addElements($elements);
        $subForm->setElementDecorators($this->getElementDecorators());
        $subForm->setDecorators($this->getSubFormDecoratorsMain('twitterCards', 'twitterCards'));            
        $subForm->setLegend('Twitter Cards');
        $this->addSubForm($subForm, 'twitterCards');        

        
        
        /*
         * End: Sub form for TwitterCards
         */
                        
        
        /*
         * Start: Sub form for subscription price
         */
        
         $subForm = new Zend_Form_SubForm();
         $subForm->setName('metatags');           
         foreach ($session->metatags as $product) {            
            $keyName = isset($session->metatagsData[$product]['name'])?$session->metatagsData[$product]['name']:'';                
            $keyContent = isset($session->metatagsData[$product]['content'])?$session->metatagsData[$product]['content']:'';            
            
            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);  
            
            if ($product === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
            }
            
            $name = new Zend_Form_Element_Select('name');
            $metaModel = new Model_SeoMetatags();
            $name->setOptions(array('multioptions' => array('' => '--Select--') + $metaModel->getNamesToDisplay()))->setValue($keyName)->setAttrib('class', 'name')->setLabel('Tag Name');
            
            $content = new Zend_Form_Element_Text('content');
            $content->addFilter('stringTrim')->setValue($keyContent)->setAttrib('class', 'content')->setLabel('Content')->setAttrib('placeholder', 'Content');

            if ($product !== '__template__') {
                $name->setRequired(false);
                $content->setRequired(false);
            }
            
            $removeMetatag = new Zend_Form_Element_Button('remove');
            $removeMetatag ->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');        
         
            $elements = array($name, $content);
            if ($product !== 'new') {
                $elements[] = $removeMetatag;            
            }
            
            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());

            if($rowForm->getElement('remove')) {
                $rowForm->getElement('remove')->removeDecorator('Label');
            }
            
            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        }
        $subForm->setDecorators($this->getSubFormDecoratorsMain('metatags', 'metatags'));

        $addPrice = new Zend_Form_Element_Button('add');
        $addPrice->setLabel('Add More')->setAttrib('class', 'btn btn-warning add');
        $subForm->addElement($addPrice);

        $subForm->setElementDecorators($this->getElementDecorators());
        $subForm->getElement('add')->removeDecorator('Label');        
        $subForm->setLegend('Meta Tags');
        $this->addSubForm($subForm, 'metatags');
        $this->postSetup(); 
        /*
         * End: Sub form for subscription price
         */      
        
        
        $this->addElement('hidden','seo_id',array(
           'required'=>false,
           'value'=> ''
        ));
        
        $this->addElement('hidden','url',array(
           'required'=>true,
           'value'=> ''
        ));
        
        
    }
    
    protected function getSubFormDecoratorsMain($className, $id) {
        return array(   
            'FormElements',                        
            array(                
                'HtmlTag', array('tag' => 'ul')
            ),
            'Fieldset',
            array(
                array('row' => 'HtmlTag'),                
                array('tag' => 'li', 'class' => $className, 'id' => $id)
            )
        );
    } 

    public function removeUneditableElements(){
        //$this->getElement('url')->setAttrib('disabled', 'disabled');
        //$this->getElement('url')->setRequired(false);
        return false;
    } 
    
    public function removeOptionalElements() {
        $this->removeElement('urlShow');
    }
    
    public function isValid($data) {
        
        $status = parent::isValid($data); 
            
        if($data['url_type'] && in_array($data['url_type'], $this->_UrlRequiresThumbnail) && !$data['thumb_image']) {
            $this->getElement('thumb_image')->setErrors(array("thumb image is required for {$data['url_type']} URL"));
            $status = false;
        }  
        if($data['canonical']) {
            if(preg_match("/([^a-z0-9\-\/]+)/", $data['canonical'])) {
                $this->getElement('canonical')->setErrors(array("'{$data['canonical']}' is not a valid group url"));
                $status = false;
            }   
            if(preg_match("/^(http|https|www)/", $data['canonical'])) {
                $this->getElement('canonical')->setErrors(array("'{$data['canonical']}' is not a valid group url"));
                $status = false;
            }    
            if(preg_match("/\/\//", $data['canonical'])) {
                $this->getElement('canonical')->setErrors(array("'{$data['canonical']}' is not a valid group url"));
                $status = false;
            }    
        }

        
        
        if (!empty($data['amp_link'])) {
            $amp_link = $data['amp_link'];
            preg_match('/([^:])(\/{2,})/', $amp_link, $matches);
            if(!empty($matches)){
                $this->getElement('amp_link')->setErrors(array("Too many slases in the url."));
                return false;
            }
            $modelSeo = new Model_Seo();
            $res = $modelSeo->getDataByAmpUrl($amp_link);
            if (!empty($res) && count($res) > 1) {
                $err = array_column($res, 'url');
                $err = implode(',', $err);
                $this->getElement('amp_link')->setErrors(array("AMP Link is already allocated to {$err}."));
                $status = false;
            } elseif (!empty($res) && count($res) == 1) {
                $_c = current($res);
                if ($_c['seo_id'] != $data['seo_id']) {
                    $err = array_column($res, 'url');
                    $err = implode(',', $err);
                    $this->getElement('amp_link')->setErrors(array("AMP Link is already allocated to {$err}."));
                    $status = false;
                }
            }elseif(empty($res)) {
                $ampPageData = $this->_pullUrlInfo($amp_link);
                if (!($ampPageData['httpStatus'] == 200)) {
                    $this->getElement('amp_link')->setErrors(array("Please provide an valid AMP Link."));
                    $status = false;
                } elseif (!preg_match('(<html amp lang="en">|<html amp>)', $ampPageData['pageData'])) {
                    $this->getElement('amp_link')->setErrors(array("AMP Link is invalid."));
                    $status = false;
                } else {
                    $currentUrl = FRONTEND_CANONICAL_URL . $data['url'];
                    $currentPageData = $this->_pullUrlInfo($currentUrl);
                    $parentCanonical = $this->_fetchCanonicalUrl($currentPageData['pageData']);
                    $ampCanonical = $this->_fetchCanonicalUrl($ampPageData['pageData']);
                    if (!($parentCanonical == $ampCanonical)) {
                        $this->getElement('amp_link')->setErrors(array("Canonical urls are not matching for parent and amp page."));
                        $status = false;
                    }
                }
            }
        }

        if(!empty($data['fbOpenGraph'])){
            if(isset($data['fbOpenGraph']['pageUrl']) && !empty($data['fbOpenGraph']['pageUrl']) ){
                if (strpos( strtolower($data['fbOpenGraph']['pageUrl']),'https://' ) === false) {    
                    $this->getElement('fbOpenGraph_err')->setErrors(array("fbOpenGraph page url link should be Https"));
                    $status = false;    
                }
            }

            if(isset($data['fbOpenGraph']['image']) && !empty($data['fbOpenGraph']['image']) ){
                if (strpos( strtolower($data['fbOpenGraph']['image']),'https://www.simplilearn.com/' ) === false) {    
                    $this->getElement('fbOpenGraph_err')->setErrors(array("fbOpenGraph image url link should be https and simplilearn domain"));
                    $status = false;    
                }
            }
        }

        if(!empty($data['twitterCards'])){
            if(isset($data['twitterCards']['pageUrl']) && !empty($data['twitterCards']['pageUrl']) ){
                if (strpos( strtolower($data['twitterCards']['pageUrl']),'https://' ) === false) {    
                    $this->getElement('twitterCards_err')->setErrors(array("twitterCards page url link should be Https"));
                    $status = false;    
                }
            }

            if(isset($data['twitterCards']['image']) && !empty($data['twitterCards']['image']) ){
                if (strpos( strtolower($data['twitterCards']['image']),'https://www.simplilearn.com/' ) === false) {    
                    $this->getElement('twitterCards_err')->setErrors(array("twitterCards image url link should be https and simplilearn domain"));
                    $status = false;    
                }
            }
        }



        return $status;
    }
    
    private function _pullUrlInfo($url) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        $http_status_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return array('httpStatus'=>$http_status_code,'pageData'=>$result);
    }
    private function _fetchCanonicalUrl($html) {
        libxml_use_internal_errors(true);
        $d = new DomDocument();
        $d->loadHTML($html);
        $xp = new domxpath($d);
        foreach ($xp->query("//link[@rel='canonical']") as $el) {
            $res[] = $el->getAttribute("href");
        }
        return implode(',',array_unique(array_filter($res)));
    }
}
