<?php

class Form_Reviews extends BaseApp_Form
{
    public function init(){
        $this->setName('trainingTypes');
        $this->setMethod('post');
      
         //adding Label name element
         
         $this->addElement('text','reviewerName',array(
            'label'=>'Name of reviewer',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('text','linkedinUrl',array(
            'label'=>'LinkedIn Url',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        )); 
         
         $obj =new Model_Courses();
         $this->addElement('select','course_id',array(
            'label'=>'Courses',
            'required'=>false,
            'multioptions'=>array('0'=>'--Select--') + $obj->fetchForSelect(array('is_dummy = ?' => 0, 'is_free = ?' => 0))
        ));

         $this->addElement('text','company',array(
            'label'=>'Company',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        )); 

         $this->addElement('text','industry',array(
            'label'=>'Industry',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

         $this->addElement('text','position',array(
            'label'=>'Position',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        )); 

         $this->addElement('text','rating',array(
            'label'=>'Rating',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        )); 

         $this->addElement('text','review',array(
            'label'=>'Review',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        )); 

         //adding course submit element
          $this->addElement('submit','Add Review',array(
            'ignore'=>true,
            'label'=>'Add Review'
           ));
    }
}

