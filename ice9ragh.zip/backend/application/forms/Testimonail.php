<?php

class Form_Testimonail extends BaseApp_Form
{

    public function init(){

        $this->setName('Testimonail');
        $this->setMethod('post');

        $validatorsName = array(new Zend_Validate_StringLength(array('max' => 100)));
        $validatorsEmail = array(new BaseApp_Validate_EmailAddress());

        $this->addElement('text','name',array(
            'label'=>'Name*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));


        $this->addElement('text','email',array(
            'label'=>'Email Id*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                new BaseApp_Validate_EmailAddress()
            )
        ));

        $this->addElement('text','linkedinUrl',array(
            'label'=>'LinkedIn Profile',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                new BaseApp_Validate_Url()
            )
        ));
        
        $linkedImageVlidator = new BaseApp_Validate_Image('reviews','linkedin_profile_image');
        $linkedImageVlidator->setHasCustomDomainCheck(true, array('simplilearn.com', 'media.licdn.com'));
        $this->addElement('text','imgUrl',array(
            'label'=>'LinkedIn Profile Image',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                new BaseApp_Validate_Url('reviews','imgUrl'), $linkedImageVlidator
            )
        ));

        $this->addElement('textarea','review',array(
            'label'=>'Testimonial',
            'required'=>false,
            'cols' => 60,
            'rows' => 6,
            'class'=>'longtext'
        ));


        $this->addElement('checkbox','isGeneric',array(
            'label'=>'Is Generic','value'=>0
        ));

         $course =new Model_Courses();
         $this->addElement('select','course_id',array(
            'label'=>'Course',
            'required'=>false,
            'multioptions'=>array('0'=>'--Select--') + $course->fetchForSelect(array('is_dummy = ?' => 0, 'is_free = ?' => 0))
        ));

         $objTraining =new Model_TrainingTypes();
         $this->addElement('select','training_id',array(
            'label'=>'Training Type*',
            'required'=>true,
            'multioptions'=>array('0'=>'--Select--') + $objTraining->getTrainingTypes()
        ));

         // fetch training Types for the select courseID

        $obj =new Model_Country();
        $countryData = array();
        foreach($obj->fetchAll(array(), array('columns'=>array('id' =>'country_id', 'name'), 'order' => array('orderNo DESC'))) as $countrySingle) {
            $countryData[$countrySingle['id']] = $countrySingle['name'];
        }
        $this->addElement('select','country_id',array(
            'required'=>false,
            'label' => 'Country*',
            'registerInArrayValidator' => false,
            'multioptions'=> array('0' => '--Select--')+$countryData
        ));

        $this->addElement('select','city_id',array(
            'required'=>false,
            'label' => 'City*',
            'registerInArrayValidator' => false,
            'multioptions'=> array('0' => '--Select--'),
        ));

        $bundle = new Model_Bundles();
         $this->addElement('select','bundle_id',array(
            'label'=>'Masters Program',
            'required'=>false,
            'registerInArrayValidator' => false,
            'class' => 'bundleListAll',
            'multioptions'=>array('0'=>'--Select--') + $bundle->fetchForSelect()
        ));

        /* $objCluster =new Model_Clusters();
        $this->addElement('select','cluster_id_bundle',array(
            'label'=>'Masters Program Clusters',
            'required'=>false,
            'multiple' => true,
            'class' => 'multiple',
            'registerInArrayValidator' => false,
            'multioptions'=>$objCluster->fetchForSelect()
        ));

        $this->addElement('hidden','cluster_id_bundle_tmp',array(
                'required'=>false,
                'value'=>''
        ));

        $this->addElement('button','cluster_inward_bundle',array(
            'label'=>'Invert Clusters',
            'ignore'=>true,
            'class'=>'btn btn-warning'
        ));

        $objCountry =new Model_Country();
        $this->addElement('select','country_id_bundle',array(
            'label'=>'Countries Associated for Masters Program',
            'required'=>false,
            'multiple' => true,
            'class' => 'courseListAll',
            'registerInArrayValidator' => false,
            'multioptions'=>$objCountry->getListDisplay()
        ));

        $this->addElement('button','country_inward_bundle',array(
            'label'=>'Invert Countries',
            'ignore'=>true,
            'class'=>'btn btn-warning'
        )); */

        $this->addElement('checkbox','show_on_homepage',array(
            'label'=>'Show on homepage','value'=>0
        ));

        $objCluster =new Model_Clusters();
        $this->addElement('select','cluster_id_homepage',array(
            'label'=>'Clusters for homepage review',
            'required'=>false,
            'multiple' => true,
            'class' => 'multiple',
            'registerInArrayValidator' => false,
            'multioptions'=>$objCluster->fetchForSelect()
        ));

        $this->addElement('hidden','cluster_id_homepage_tmp',array(
                'required'=>false,
                'value'=>''
        ));

        $this->addElement('button','cluster_inward_homepage',array(
            'label'=>'Invert Clusters',
            'ignore'=>true,
            'class'=>'btn btn-warning'
        ));

        $objCountry =new Model_Country();
        $this->addElement('select','country_id_homepage',array(
            'label'=>'Countries Associated for homepage',
            'required'=>false,
            'multiple' => true,
            'class' => 'courseListAll',
            'registerInArrayValidator' => false,
            'multioptions'=>$objCountry->getListDisplay()
        ));

        $this->addElement('button','country_inward_homepage',array(
            'label'=>'Invert Countries',
            'ignore'=>true,
            'class'=>'btn btn-warning'
        ));

        $this->addElement('text','company',array(
            'label'=>'Company Name',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('text','position',array(
            'label'=>'designation',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('text','createDate',array(
            'label'=>'Date Created*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'datepicker'
        ));

        $this->addElement('select','rating',array(
            'label'=>'Rating*',
            'required'=>true,
            'multioptions'=>array('0'=>'--Select--', 1 => 1, 2 => 2, 3 => 3, 4 => 4, 5 => 5)
        ));

         $this->addElement('submit','Add_Testimonial',array(
          'ignore'=>true,
          'label'=>'Add Testimonial',
          'class'=>'btn btn-info'
         ));

        $this->getElement('name')->addValidators($validatorsName);
        $this->getElement('email')->addValidators($validatorsEmail);
    }

    public function removeUneditableElements(){

        $this->getElement('name')->setAttrib('disabled', 'disabled');
        $this->getElement('name')->setRequired(false);

        $this->getElement('email')->setAttrib('disabled', 'disabled');
        $this->getElement('email')->setRequired(false);

        $this->getElement('review')->setAttrib('disabled', 'disabled');
        $this->getElement('review')->setRequired(false);

        $this->getElement('isGeneric')->setAttrib('disabled', 'disabled');
        $this->getElement('isGeneric')->setRequired(false);

        $this->getElement('course_id')->setAttrib('disabled', 'disabled');
        $this->getElement('course_id')->setRequired(false);

        $this->getElement('training_id')->setAttrib('disabled', 'disabled');
        $this->getElement('training_id')->setRequired(false);

        $this->getElement('country_id')->setAttrib('disabled', 'disabled');
        $this->getElement('country_id')->setRequired(false);

        $this->getElement('city_id')->setAttrib('disabled', 'disabled');
        $this->getElement('city_id')->setRequired(false);

        $this->getElement('createDate')->setAttrib('disabled', 'disabled');
        $this->getElement('createDate')->setRequired(false);

        $this->getElement('rating')->setAttrib('disabled', 'disabled');
        $this->getElement('rating')->setRequired(false);

    }

    public function isValid($data) {
       // prd($data);
        $status = parent::isValid($data);
        $todaysDate = strtotime(date("Y-m-d"));
        if(isset($data['createDate']))
            $testimonialDate = strtotime($data['createDate']);
        if(!empty($testimonialDate) && ($testimonialDate > $todaysDate)){
            $this->getElement('createDate')->setErrors(array("Cannot add a future date"));
            $status = false;
        }

        if(empty($data['rating'])){
            $this->getElement('rating')->setErrors(array("Rating is required"));
            $status = false;
        }

        if(empty($data['country_id'])){
            $this->getElement('country_id')->setErrors(array("Country is required"));
            $status = false;
        }
        if(empty($data['city_id'])) {
            $this->getElement('city_id')->setErrors(array("City is required"));
            $status = false;
        }

        if(empty($data['training_id'])){
            $this->getElement('training_id')->setErrors(array("Training Type is required"));
            $status = false;
        }

        if(empty($data['course_id']) && empty($data['bundle_id'])){
            $this->getElement('course_id')->setErrors(array("Either course or masters program is required"));
            $status = false;
        }

        /* if(!empty($data['bundle_id']) && (empty($data['cluster_id_bundle']) && empty($data['country_id_bundle']))){
            $this->getElement('cluster_id_bundle_tmp')->setErrors(array("Need to select cluster or country to show review on masters page"));
            $status = false;
        } */

        if(!empty($data['show_on_homepage']) && $data['show_on_homepage'] == 1 && (empty($data['cluster_id_homepage']) && empty($data['country_id_homepage']))){
            $this->getElement('cluster_id_homepage_tmp')->setErrors(array("Need to select cluster or country to show review on homepage"));
            $status = false;
        }
        return $status;
    }
}