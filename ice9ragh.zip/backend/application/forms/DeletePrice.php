<?php

class Form_DeletePrice extends BaseApp_Form
{

    public function init(){

        $this->addElement('text','pricing_id',array(
            'label'=>'Pricing Id',
            'required'=>false,
            'readonly'=>'readonly',
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('submit','DeletePricing',array(
            'ignore'=>true,
            'label'=>'Delete Price',
            'class'=>'btn btn-info'
        ));
    }

}