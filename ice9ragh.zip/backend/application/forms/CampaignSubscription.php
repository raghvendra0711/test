<?php

class Form_CampaignSubscription extends BaseApp_Form
{
    public function init(){


        $this->setName('CampaignSubscription');
        $this->setMethod('post');
         //adding Label name element
        $validatorsName = array(new Zend_Validate_StringLength(array('max' => 100)));
        
        $this->addElement('radio','campaign_source',array(
           'label' =>'for',
           'required'=>false,
           'multioptions'=>array('1' => 'Course','2' => 'Subscription'),
           'value' => '2'
        ));
         
        $this->addElement('text','displayName',array(
            'label'=>'Name',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off'
        ));
         
        $labelModel = new Model_Labels();
        $this->addElement('select','label_id',array(
            'label'=>'Labels',
            'required'=>true,
            'multiple' => true,
            'registerInArrayValidator' => false,
            'multioptions'=>$labelModel->fetchForSelect()
        ));
         
        $this->addElement('text','specialText',array(
            'label'=>'Special Text',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off'
        ));
        
        $this->addElement('text','topBannerPath',array(
            'label'=>'Top Banner',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off',
            'validators' => array(
                new BaseApp_Validate_Image('campaignSubscription', 'topBannerPath', true)
            )
        ));
        
        $this->addElement('text','smallBannerPath',array(
            'label'=>'Small Banner',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off',
            'validators' => array(
                new BaseApp_Validate_Image('campaignSubscription', 'smallBannerPath', true)
            )
        ));       
        
        $clusterModel = new Model_Clusters();
        $this->addElement('select','clustersIncluded',array(
            'label'=>'Clusters/BU',
            'required'=>true,
            'multiple' => true,
            'registerInArrayValidator' => false,
            'multioptions'=>$clusterModel->fetchForSelect()          
        ));
        
        $countryModel = new Model_Country();
        $this->addElement('select','clustersExcluded',array(
            'label'=>'Country/Clusters/BU',
            'required'=>false,
            'multiple' => true,
            'registerInArrayValidator' => false,
            'multioptions'=>$countryModel->fetchForSelect()                           
        ));
        
        $this->addElement('text','validFrom',array(
            'label'=>'Offer valid from',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off'
        ));
        
        $this->addElement('text','validto',array(
            'label'=>'To',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off'
        ));
        
        $this->addElement('text','alert',array(
            'label'=>'Alert',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off',
            'validators' => array(
                new BaseApp_Validate_EmailAddress()
            )
        ));
        
        $this->addElement('text','percentage',array(
            'label'=>'Percentage',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off'
        ));
        
         
        $this->addElement('submit','Save',array(
           'ignore'=>true,
           'label'=>'Save',
           'class'=>'btn btn-info'
        ));        
        $this->getElement('displayName')->addValidators($validatorsName);         
    }    
    
    public function removeUneditableElements(){
        $this->removeElement('campaign_source');
    }
}