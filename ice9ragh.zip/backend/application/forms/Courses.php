<?php

class Form_Courses extends BaseApp_SubForm {

    const COURSE_PHOTO_PATH = 'images/courses/';
    const MAX_TOOLS_ALLOWED = 6;
    const MAX_TOOL_CATEGORY_NAME_CHARCTERS = 50;
    const MIN_TOOL_CATEGORY_NAME_CHARCTERS = 5;    
    const LABEL_IS_NEW_COURSE_PAGE = 'Course Page Type*';
    const LABEL_NEW_COURSE_PAGE = 'New Course Page';
    const LABEL_OLD_COURSE_PAGE = 'Old Course Page';

    protected $submitName = 'Next';
    private $_courseId = false;
    private $_vData = array();
    private $_new = false;
    private $_fieldLabels = array(
        'accreditor_id' => 'Accreditation Logos for Old Course, SEM, Enterprise Page (Max 2 allowed)',
        'accreditor_id_new' => "Accreditation Logos for new Course Page",
        'accreditor_title' => "Accreditation Heading",
        'courseToolsFeature' => "Tools Covered",
    );
    public $courseStatus = array(
        'no_where' => 'No Where',
        'universal' => 'Universal',
        'b2b_only' => 'B2B Only',
        'private_b2b' => 'Private B2B',
        'b2c_only' => 'B2C Only',
        'complimentary_course' => 'Complimentary Course',
        'learning_path_only' => 'Learning Path Only'
    );
   // Fair-Use policy : Configurable Max Allowed Active Registration for a course
    public $maxActiveRegistrationAllowed = array(
        '9999' => 'No Limit',
        '1' => '1',
        '2' => '2',
        '3' => '3',
        '4' => '4',
        '5' => '5',
        '6' => '6',
        '7' => '7',
        '8' => '8',
        '9' => '9',
        '10' => '10',
        '20' => '20',
        '30' => '30',
        '40' => '40',
        '50' => '50'        
    );
    public function __construct($courseId = false, $new = true) {
        if ($courseId) {
            $this->_courseId = $courseId;
            $this->editCourse($courseId);
        } else {
            $this->init($new);
        }
        $this->loadDefaultDecorators();
    }

    public function init($new = true) {
        $this->setName('courses');
        $this->setMethod('post');
        $this->setAttrib('class', 'courseForm');
        
        $validatorsData = array(new Zend_Validate_StringLength(array('max' => 50)));
        $validatorsSource = array(new Zend_Validate_StringLength(array('max' => 30)));
        $validatorsName = array(new Zend_Validate_StringLength(array('max' => 100)));
        $validatorsDescription = array(new Zend_Validate_StringLength(array('max' => 90)));
        $validatorsLogoAndDirectorName = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 40)));
        $validatorsLogoAndDirectorDesig = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 40)));
        $validatorsLogoAndDirectorAchie = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 40)));
        $validatorsDirectorDesc = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 280)));
        $validatorsIntroText = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 500)));
        $validatorsCourseOverview = array(new Zend_Validate_StringLength(array('max' => 350)));
        $validatorsOslDefalutText = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 50)));
        $validatorsB2BCardText = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 700)));

        $validatorsCompanyCardTextForYourself = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 700)));
        $validatorsCompanyCardTextForManagers = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 700)));
        $validatorsCompanyCardTextForOSL = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 700)));
        $validatorsCompanyCardTextForLVC = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 700)));
        $courseModel = new Model_Courses();

        $validatorsPassCardText = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 320)));
        $validatorsOSLCardText = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 400)));
        $validateUrl = array(new BaseApp_Validate_Url());
        $validatorsCourseTool = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 70)));

        if ($new) {
            $validators = array(
                new Zend_Validate_Db_NoRecordExists(array(
                    'table' => 'courses',
                    'field' => 'name'
                        )), new Zend_Validate_NotEmpty(), new Zend_Validate_StringLength(array('max' => 100)));

            $validateDisplayName = array(
                new Zend_Validate_Db_NoRecordExists(array(
                    'table' => 'courses',
                    'field' => 'displayName'
                        )), new Zend_Validate_NotEmpty(), new Zend_Validate_StringLength(array('max' => 100)));
        }
        
        //****************************** Course Basics Starts *****************************
        $this->addElement('radio', 'is_new_course_page', array(
            'required' => true,
            'label' => self::LABEL_IS_NEW_COURSE_PAGE,
            'multiOptions' => array(1 => self::LABEL_NEW_COURSE_PAGE, 0 => self::LABEL_OLD_COURSE_PAGE),
            'separator' => '',
            'registerInArrayValidator' => false,
            'value' => 1
        ));
        $this->addElement('text', 'name', array(
            'label' => 'Name of the Course*',
            'required' => true,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
        ));
        $this->addElement('text', 'displayName', array(
            'label' => 'Display Name*',
            'required' => true,
            'filters' => array('StringTrim'),
            'class' => 'longtext'
        ));
        $this->addElement('text', 'tags', array(
            'label' => 'Tags (comma separated)*',
            'required' => true,
            'filters' => array('StringTrim'),
            'class' => 'longtext'
        ));
        $this->addElement('text', 'url', array(
            'label' => 'Course Url*',
            'required' => true,
            'filters' => array('StringTrim'),
            'class' => 'longtext'
        ));
        $basicGroup = array('is_new_course_page','name','displayName','tags','url');
        $this->addDisplayGroup($basicGroup, 'basic_group');
        $this->getDisplayGroup('basic_group')
                ->setLegend('Course Basics')
                ->clearDecorators()
                ->addDecorator('FormElements')
                ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper'));
        //****************************** Course Basics Ends *****************************

        //****************************** Course Mappings Starts*************************
        $obj = new Model_Labels();
        $this->addElement('select', 'primary_label_id', array(
            'label' => 'Primary Category',
            'required' => true,
            'registerInArrayValidator' => false,
            'multioptions' => array('0' => '--Select--') + $obj->getPrimaryLableData(),
            'class' => 'primary_label_id'
        ));
        $this->addElement('hidden', 'categoryLabelName', array(
            'required' => false,
            'value' => ''
        ));
        $this->addElement('select', 'label_id', array(
            'label' => 'Other Categories associated with this Course*',
            'required' => true,
            'multiple' => true,
            'class' => 'multiple',
            'registerInArrayValidator' => false,
            'multioptions' => $obj->getPrimaryLableData()
        ));
        $obj = new Model_Vendors();
        $this->addElement('select', 'vendor_id', array(
            'label' => 'Course Vendor',
            'required' => false,
            'multioptions' => array('0' => '--Select--') + $obj->fetchForSelect()
        ));
        $looper = new BaseApp_Communication_Looper();
        $allCourses = $looper->getCourseList();
        $coursesData = !empty($allCourses['data']) ? $allCourses['data'] : array();
        $this->addElement('select', 'primary_eLearning_id', array(
            'label' => 'Primary Elearning',
            'required' => false,
            'multioptions' => array('0' => '--Select--') + $coursesData
        ));
        $this->addElement('radio', 'level', array(
            'required' => true,
            'label' => 'Course Level',
            'multiOptions' => array('Foundational' => 'Foundational', 'Advanced' => 'Advanced', 'Tool Based' => 'Tool Based', 'Knowledge Nuggets' => 'Knowledge Nuggets', 'Leadership Series' => 'Leadership Series'),
            'separator' => '',
            'value' => 'beginner'
        ));
        $mappingsGroup = array('primary_label_id','label_id','vendor_id','primary_eLearning_id','level');
        $this->addDisplayGroup($mappingsGroup, 'mappings_group');
        $this->getDisplayGroup('mappings_group')
                ->setLegend('Course Mappings')
                ->clearDecorators()
                ->addDecorator('FormElements')
                ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper'));
        //****************************** Course Mappings Ends *****************************
        
        //****************************** Course Content Starts *****************************
        $this->addElement('textarea', 'intro_text', array(
            'label' => 'Course Introduction',
            'filter' => array('StringTrim'),
            'rows' => 5,
            'value' => $courseModel->getCourseIntroText($this->_courseId),
            'cols' => 60,
            'class' => 'description',
            'validators' => $validatorsIntroText
        ));
        $this->addElement('textarea', 'shortDescription', array(
            'label' => 'Course Introduction for Mobile',
            'filter' => array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class' => 'description',
            'validators' => $validatorsIntroText
        ));
        $this->addElement('textarea', 'overview', array(
            'label' => 'Course Overview *',
            'filter' => array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class' => 'description',
            'validators' => $validatorsCourseOverview
        ));
        $this->addElement('textarea', 'b2b_contents', array(
            'label' => 'B2B Card Text',
            'filter' => array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class' => 'b2b_contents fck-enable',
            'validators' => $validatorsB2BCardText,
            'value' => '<ul><li>Blended learning delivery model (self-paced e-learning and/or instructor-led options)</li><li>Course, category, and all-access pricing</li><li>Enterprise-class learning management system (LMS)</li><li>Enhanced reporting for individuals and teams</li><li>24x7 teaching assistance and support</li></ul>'
        ));
        $this->addElement('textarea', 'classroom_card_contents', array(
            'label' => 'Classroom Card Text',
            'filter' => array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class' => 'fck-enable',
            'validators' => $validatorsOSLCardText,
            'value' => '<ul><li>2 Days Classroom Training</li></ul>'
        ));
        $this->addElement('textarea', 'flexi_card_contents', array(
            'label' => 'Online Classroom Flexi Pass Card Text',
            'filter' => array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class' => 'fck-enable',
            'validators' => $validatorsPassCardText,
            'value' => '<ul><li>num_of_days days of access to high-quality, self-paced learning content designed by industry experts</li></ul>'
        ));
        $this->addElement('textarea', 'osl_contents', array(
            'label' => 'OSL Card Text',
            'filter' => array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class' => 'fck-enable',
            'validators' => $validatorsOSLCardText,
            'value' => '<ul><li>num_of_days days of access to high-quality, self-paced learning content designed by industry experts</li></ul>'
        ));
        $this->addElement('textarea', 'osl_defalut_text', array(
            'label' => 'OSL DEFAULT TEXT',
            'filter' => array('StringTrim'),
            'rows' => 5,
            'value' =>"Everything in Self-Paced Learning, plus",
            'cols' => 60,
            'class' => 'description',
            'validators' => $validatorsOslDefalutText
        ));
        $course = new Model_Courses();
        $this->addElement('select', 'freeCourses', array(
            'label' => 'Free Courses',
            'required' => false,
            'multiple' => true,
            'class' => 'multiple',
            'registerInArrayValidator' => false,
            'multioptions' => $course->getFreeCourseData(array('is_dummy = ?' => 0))
        ));
        $contentGroup = array('intro_text','shortDescription','overview'
            ,'b2b_contents','classroom_card_contents','flexi_card_contents','osl_contents','osl_defalut_text','freeCourses');
        $this->addDisplayGroup($contentGroup, 'content_group');
        $this->getDisplayGroup('content_group')
                ->setLegend('Course Content')
                ->clearDecorators()
                ->addDecorator('FormElements')
                ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper'));
        //****************************** Course Content Ends *****************************

        //****************************** Course Advisors Starts *****************************
        $this->addElement('select', 'course_advisor_temp', array(
            'label' => 'Course Advisors',
            'required' => false,
            'size' => 12,
            'multiple' => true,
            'class' => 'multiple',
            'registerInArrayValidator' => false,
            'multioptions' => array('0' => '--Select--') + $this->getCourseAdvisorsData()
        ));
        $this->addElement('hidden', 'course_advisor', array('required' => false, 'value' => ''));
        $advisorGroup = array('course_advisor_temp');
        $this->addDisplayGroup($advisorGroup, 'advisor_group');
        $this->getDisplayGroup('advisor_group')
                ->setLegend('Course Advisors')
                ->clearDecorators()
                ->addDecorator('FormElements')
                ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper'));
        //****************************** Course Advisors Ends *****************************
        
        //****************************** Course Logos Starts *****************************
        $this->addElement('text', 'accreditor_title', array(
            'label' => $this->_fieldLabels['accreditor_title'],
        ));
        $accreditorObj = new Model_Accreditors();
        $accreditorCond = array('isCoursePage'=>1);
        $this->addElement('select', 'accreditor_id', array(
            'label' => $this->_fieldLabels['accreditor_id'],
            'required' => false,
            'class' => 'multiple old_course_field',
            'size' => 12,
            'registerInArrayValidator' => false,
            'multioptions' => $this->convertIdFormat($accreditorObj->fetchForSelect($accreditorCond))
        ));
        $this->addElement('hidden', 'accreditor_id_sorted_list', array('required' => false, 'value' => ''));
        $this->addElement('select', 'accreditor_id_new', array(
            'label' => $this->_fieldLabels['accreditor_id_new'],
            'required' => false,
            'class' => 'multiple new_course_field',
            'size' => 12,
            'registerInArrayValidator' => false,
            'multioptions' => $this->convertIdFormat($accreditorObj->fetchForSelect(array('isNewCoursePage' => 1)))
        ));
        $this->addElement('hidden', 'accreditor_id_sorted_list_new', array('required' => false, 'value' => ''));
        $courseTools = new Zend_Form_Element_Select('tool_id');
        $toolsList = $this->getAllTools();
        $selectedList = array();
        $selectedListString = implode(',', array_intersect($selectedList, $toolsList));
        $this->addElement('select', 'courseToolsFeature', array(
            'label' => $this->_fieldLabels['courseToolsFeature'],
            'required' => false,
            'multioptions' => $toolsList,
            'size' => 12,
            'class' => 'multiple',
            'registerInArrayValidator' => false,
            'value' => '',
        ));
        $this->addElement('hidden', 'courseToolsFeatureSortedList', array('required' => false, 'value' => $selectedListString));
        $this->addElement('text', 'image_home_page', array(
            'label' => 'Course Logo link (160 x 160)*',
            'required' => true,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'validators' => array(
                new BaseApp_Validate_Image('courses', 'image_home_page')
            )
        ));
        $this->addElement($this->createElement('file','certificate_image',array(
            'label'=>'Certificate image* (730px X 516px, 382kb)',
            'required'=>false,
            'destination'=>sys_get_temp_dir(),
            'validators'=>array('Extension' => array('jpeg','png','jpg'),
                array('ImageSize',false, array('maxwidth'=>730,'maxheight'=>516)),
                array('Size',false, array('useByteString'=> true, 'max' => '382kb'))
            )
        )));
        $this->addElement('text', 'certificate_alt_text', array(
            'label' => 'Certificate Alt Text',
            'required' => false,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
        ));
        $logosGroup = array('accreditor_title','accreditor_id','accreditor_id_new','courseToolsFeature','image_home_page','certificate_image','certificate_alt_text');
        $this->addDisplayGroup($logosGroup, 'logos_group');
        $this->getDisplayGroup('logos_group')
                ->setLegend('Logos')
                ->clearDecorators()
                ->addDecorator('FormElements')
                ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper'));
        //****************************** Course Logos Ends *****************************
        
        //****************************** Course Collateral Starts *****************************
        $this->addElement('text', 'agendaUrl', array(
            'label' => 'Course Agenda',
            'required' => false,
            'filters' => array('StringTrim'),
            'class' => 'longtext'
        ));
        $this->addElement('text', 'videoLink', array(
            'label' => 'Introduction Video',
            'placeholder' => " Youtube video Embeded Link",
            'required' => false,
            'filters' => array('StringTrim'),
            'class' => 'longtext embeded-youtube-intro-video',
        ));
        $this->addElement('text', 'videoThumbnail', array(
            'label' => 'Video Thumbnail Image',
            'placeholder' => " Please Enter video Thumbnail Image",
            'required' => false,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
        ));
        $this->addElement('text', 'pre_run_video', array(
            'label' => 'Pre Run Video',
            'required' => false,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
        ));
        $this->addElement('text', 'flexi_pass_video', array(
            'label' => 'Flexi Pass Video',
            'required' => false,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
        ));
        $collateralGroup = array('agendaUrl','videoLink','videoThumbnail','pre_run_video','flexi_pass_video');
        $this->addDisplayGroup($collateralGroup, 'collateral_group');
        $this->getDisplayGroup('collateral_group')
                ->setLegend('Course Collateral')
                ->clearDecorators()
                ->addDecorator('FormElements')
                ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper'));
        //****************************** Course Collateral Ends *****************************
        
        //****************************** Course Others Starts *****************************
        /** Start: Sub form for training types */
        $subForm = new Zend_Form_SubForm();
        $subForm->setName('trainingTypes');

        $traingType = new Model_TrainingTypes();
        $trainingTypeIds = $traingType->loadAll();

        $objAccessDays = new Model_AccessDays();

        $trainingTypeOsl = new Zend_Form_Element_Checkbox('osl2');
        $trainingTypeOsl->setLabel($trainingTypeIds[2]['name']);

        $oslAccessdays = new Zend_Form_Element_MultiCheckbox('oslAccessDays');
        $oslAccessdays->setLabel('select access days')->setOptions(array('multiOptions' => $objAccessDays->getAccessDays(2), 'separator' => ''))->setAttrib('class', 'oslAccessDays');


        $trainingTypeClassRoom = new Zend_Form_Element_Checkbox('ilt1');
        $trainingTypeClassRoom->setLabel($trainingTypeIds[1]['name']);

        $classRoomAccessDays = new Zend_Form_Element_MultiCheckbox('classRoomAccessDays');
        $classRoomAccessDays->setLabel('access days')->setOptions(array('multioptions' => $objAccessDays->getAccessDays(1), 'separator' => ''))->setAttrib('class', 'classRoomAccessDays');

        $trainingTypeIlo = new Zend_Form_Element_Checkbox('ilt3');
        $trainingTypeIlo->setLabel($trainingTypeIds[3]['name']);

        $iloAccessDays = new Zend_Form_Element_MultiCheckbox('iloAccessDays');
        $iloAccessDays->setLabel('access days')->setOptions(array('multioptions' => $objAccessDays->getAccessDays(3), 'separator' => ''))->setAttrib('class', 'iloAccessDays');

        $elements = array($trainingTypeOsl, $oslAccessdays, $trainingTypeIlo, $iloAccessDays, $trainingTypeClassRoom, $classRoomAccessDays);
        $subForm->addElements($elements);
        $subForm->setElementDecorators($this->getElementDecorators());
        $decos = $this->getSubFormDecorators();
        $decos[3][1]['class'] =  array('subform training-types-subform-courses');
        $subForm->setDecorators($decos);
        $subForm->setLegend('Training Types*');
        $this->addSubForm($subForm, 'trainingTypes');
        
        /** End: Sub form for training types*/
        
        $this->addElement('select', 'max_reg_count', array(
            'label' => 'Number of Active Registration Allowed (For Fair-Use policy)*',
            'required' => true,
            'value' => 3,
            'multioptions' => $this->maxActiveRegistrationAllowed
        ));
        $objPromo = new Model_PromoParams();
        $this->addElement('select', 'promo_id', array(
            'label' => 'Promo Param',
            'required' => false,
            'registerInArrayValidator' => false,
            'multioptions' => array(NULL => '--Select--') + $objPromo->fetchForSelect()
        ));
        $othersGroup = array('max_reg_count','promo_id');
        $this->addDisplayGroup($othersGroup, 'others_group');
        $this->getDisplayGroup('others_group')
                ->setLegend('Course Others')
                ->clearDecorators()
                ->addDecorator('FormElements')
                ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper'));
        //****************************** Course Others Ends *****************************
        
        //****************************** Course Settings Starts *****************************
        $this->addElement('checkbox', 'hideFromSearch', array(
            'label' => 'Hide course from website'
            ));

            $this->addElement('checkbox', 'osl_exam_fee_included', array(
            'label' => 'Is Exam Fee Included for Online Training',
            'value' => 0
            ));

            $this->addElement('radio', 'isCirtification', array(
            'required' => true,
            'label' => 'Is this a Certification course?',
            'multiOptions' => array(1 => 'Yes', 0 => 'No'),
            'separator' => '',
            'registerInArrayValidator' => false,
            'value' => 1
            ));

            $this->addElement('checkbox', 'is_b2b', array(
            'label' => 'Available for Enterprise ?'
            ));

            $this->addElement('select', 'course_available_for', array(
                'label' => 'Course Available For*',
                'required' => true,
                'multioptions' => $this->courseStatus,
                ));

            $this->addElement('text', 'enterprise_list', array(
                'label' => 'Select One or More Enterprise(s)*',
                'filter' => array('StringTrim'),
                'style' => 'display: none'
            ));
            
            $this->addElement('checkbox', 'is_part_payment', array(
                'label' => 'Available for Part Payment',
                'value' => '1'
            ));

            $this->addElement('checkbox', 'can_be_free', array(
            'label' => 'OSL can be given free?'
            ));
            $this->addElement('checkbox', 'is_free', array(
            'label' => 'Is a Free Course'
            ));
            $this->addElement('checkbox', 'revenue_share', array(
            'label' => 'Is revenue shared'
            ));

            $this->addElement('checkbox', 'is_dummy', array(
            'label' => 'Is Dummy Course'
            ));

            $this->addElement('checkbox', 'money_back_guarantee', array(
                'label' => 'Money back guarantee',
            ));

            $this->addElement('textarea', 'money_back_guarantee_text', array(
                'label' => 'Money back guarantee text*',
                'required' => false,
                'rows' => 5,
                'cols' => 60,
                'filters' => array('StringTrim'),
                'class' => 'keyName',
            ));

            $settingsGroup = array('hideFromSearch','osl_exam_fee_included','isCirtification','is_b2b','course_available_for','enterprise_list','is_part_payment','can_be_free','is_free','revenue_share','is_dummy','money_back_guarantee','money_back_guarantee_text');
            $this->addDisplayGroup($settingsGroup, 'settings_group');
            $this->getDisplayGroup('settings_group')
                    ->setLegend('Settings')
                    ->clearDecorators()
                    ->addDecorator('FormElements')
                    ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper')); 
        //****************************** Course Settings Ends *****************************
        

        $session = new Zend_Session_Namespace('form');
        
        $this->addElement('checkbox', 'previewFromElearning', array(
            'label' => 'Course Preview from e-Learning?',
            'value' => 1,
            'attribs' => array('disabled' => 'disabled'),
            'class'=>'hide'
        ));




        /*
          $obj =new Model_Accreditors();
          $this->addElement('select','accreditor_id',array(
          'label'=>'Is the Course Accredited ?',
          'required'=>false,
          'multioptions'=>array('0'=>'--Select--') + $obj->fetchForSelect()
          ));
         */



        // $this->addElement('text', 'image_course_detail_page', array(
        //     'label' => 'Course Detail page Image Link (Super big (size))*',
        //     'required' => true,
        //     'filters' => array('StringTrim'),
        //     'class' => 'longtext',
        //     'validators' => array(
        //         new BaseApp_Validate_Image('courses', 'image_course_detail_page', true)
        //     )
        // ));


        // $this->addElement('text', 'image_list_page', array(
        //     'label' => 'List page Image Link (120 x 120)*',
        //     'required' => true,
        //     'filters' => array('StringTrim'),
        //     'class' => 'longtext',
        //     'validators' => array(
        //         new BaseApp_Validate_Image('courses', 'image_list_page')
        //     )
        // ));

        // $this->addElement('text', 'image_mobile', array(
        //     'label' => 'Mobile Image Link (60 x 60)*',
        //     'required' => true,
        //     'filters' => array('StringTrim'),
        //     'class' => 'longtext',
        //     'validators' => array(
        //         new BaseApp_Validate_Image('courses', 'image_mobile')
        //     )
        // ));

        //Movong to Enterprice
        //Company card for OSL
        /*$this->addElement('textarea', 'company_card_osl_contents', array(
            'label' => 'Company Card Text For OSL Courses',
            'filter' => array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class' => 'b2b_contents fck-enable',
            'validators' => $validatorsCompanyCardTextForOSL,
            'value' => '<ul><li>num_of_days days of access to high-quality, self-paced learning content designed by industry experts</li></ul>'
        ));
        //Company card for LVC
        $this->addElement('textarea', 'company_card_lvc_contents', array(
            'label' => 'Company Card Text For LVC Courses',
            'filter' => array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class' => 'b2b_contents fck-enable',
            'validators' => $validatorsCompanyCardTextForLVC,
            'value' => '<ul><li>num_of_days days of access to high-quality, self-paced learning content designed by industry experts</li></ul>'
        ));*/
        
        //Moving to Settings
        /*
        $this->addElement('radio', 'isCirtification', array(
            'required' => true,
            'label' => 'Is this a Certification course?',
            'multiOptions' => array(1 => 'Yes', 0 => 'No'),
            'separator' => '',
            'registerInArrayValidator' => false,
            'value' => 1
        ));
        $this->addElement('checkbox', 'is_b2b', array(
            'label' => 'Available for Enterpirse ?'
        ));
        $this->addElement('checkbox', 'osl_exam_fee_included', array(
            'label' => 'Is Exam Fee Included for Online Training',
            'value' => 0
        ));
        $this->addElement('checkbox', 'revenue_share', array(
            'label' => 'Is revenue shared'
        ));
        $this->addElement('checkbox', 'hideFromSearch', array(
            'label' => 'Hide course from website'
        ));
        $this->addElement('select', 'course_available_for', array(
            'label' => 'Course Available For*',
            'required' => true,
            'multioptions' => $this->courseStatus,
        ));

        $this->addElement('checkbox', 'can_be_free', array(
            'label' => 'Can be given free'
        ));
        $this->addElement('checkbox', 'is_dummy', array(
            'label' => 'Is Dummy Course'
        ));
        $this->addElement('checkbox', 'is_free', array(
            'label' => 'Is a Free Course'
        ));
        */
        
        /*$this->addElement('checkbox', 'for_india', array(
            'label' => 'Show Data For India'
        ));
        $session = new Zend_Session_Namespace('form');
        $session->conversionIndiaData = array(
            'industry' => array(
                'data' => '',
                'source' => '',
                'link' => ''
            ),
            'job' => array(
                'data' => '',
                'source' => '',
                'link' => ''
            ),
            'salary' => array(
                'data' => '',
                'source' => '',
                'link' => ''
            )
        );
        $subForm = new Zend_Form_SubForm();
        $subForm->setName('conversionForIndia');
        foreach ($session->conversionIndiaData as $product => $productData) {
            $keyData = isset($productData['data']) ? $productData['data'] : '';
            $keySource = isset($productData['source']) ? $productData['source'] : '';
            $keyLink = isset($productData['link']) ? $productData['link'] : '';

            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName(strtoupper($product));

            $data = new Zend_Form_Element_Text('data');
            $data->addFilter('stringTrim')->setValue($keyData)->setAttrib('class', 'longtext')->setLabel('Data*')->addValidators($validatorsData);

            $source = new Zend_Form_Element_Text('source');
            $source->addFilter('stringTrim')->setValue($keySource)->setAttrib('class', 'longtext')->setLabel('Source*')->addValidators($validatorsSource);

            $link = new Zend_Form_Element_Text('link');
            $link->addFilter('stringTrim')->setValue($keyLink)->setAttrib('class', 'longtext')->setLabel('Link')->addValidators($validateUrl);

            $elements = array($data, $source, $link);

            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());
            $rowForm->setLegend(strtoupper($product));
            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        }
        $subForm->setDecorators($this->getSubFormDecoratorsMain('course-conversion', 'conversionForIndia'));
        $subForm->setElementDecorators($this->getElementDecorators());
        $this->addSubForm($subForm, 'conversionForIndia');

        $obj = new Model_ProductSectionData();
        $obj->setDisplayField('name');*/


        /* Start For Us */
        /*$this->addElement('checkbox', 'for_us', array(
            'label' => 'Show Data For Us/Row'
        ));
        $subForm = new Zend_Form_SubForm();
        $subForm->setName('conversionForUs');
        foreach ($session->conversionIndiaData as $product => $productData) {
            $keyData = isset($productData['data']) ? $productData['data'] : '';
            $keySource = isset($productData['source']) ? $productData['source'] : '';
            $keyLink = isset($productData['link']) ? $productData['link'] : '';

            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName(strtoupper($product));

            $data = new Zend_Form_Element_Text('data');
            $data->addFilter('stringTrim')->setValue($keyData)->setAttrib('class', 'longtext')->setLabel('Data*')->addValidators($validatorsData);

            $source = new Zend_Form_Element_Text('source');
            $source->addFilter('stringTrim')->setValue($keySource)->setAttrib('class', 'longtext')->setLabel('Source*')->addValidators($validatorsSource);

            $link = new Zend_Form_Element_Text('link');
            $link->addFilter('stringTrim')->setValue($keyLink)->setAttrib('class', 'longtext')->setLabel('Link')->addValidators($validateUrl);

            $elements = array($data, $source, $link);

            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());
            $rowForm->setLegend(strtoupper($product));
            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        }
        $subForm->setDecorators($this->getSubFormDecoratorsMain('course-conversion', 'conversionForUs'));
        $subForm->setElementDecorators($this->getElementDecorators());
        $this->addSubForm($subForm, 'conversionForUs');*/

        /**
         * Sub Form For Course Tools
         */
        /*$this->addElement('hidden', 'course_tool_err', array(
            'required' => false,
            'value' => ''
        ));*/
        
        
        /*
        $subForm = new Zend_Form_SubForm();
        $subForm->setName('courseToolsFeature');
        foreach ($session->courseToolsFeature as $product) {
            $keyCourseCategory = isset($session->courseToolsFeatureData[$product]['course_category']) ? $session->courseToolsFeatureData[$product]['course_category'] : '';
            $keyToolId = isset($session->courseToolsFeatureData[$product]['tool_id']) ? $session->courseToolsFeatureData[$product]['tool_id'] : '';
            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);
            if ($product === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
            }
            $courseCategory = new Zend_Form_Element_Text('course_category');
            $courseCategory->addFilter('stringTrim')->setValue($keyCourseCategory)->setAttrib('class', 'courseCategory')->setAttrib('placeholder', 'Full Length Category Name')->setLabel('Course Category')->addValidators($validatorsCourseTool);
            $courseTools = new Zend_Form_Element_Select('tool_id');
            $toolList = $this->getAllTools();
            $courseTools->setOptions(array('select' => true, 'multiple' => true, 'required' => false, 'registerInArrayValidator' => false, 'multioptions' => array('0' => '--Select--') + $toolList))->setValue($keyToolId)->setAttrib('class', 'courseTool multiple')->setLabel('Tools');
            $removeSetsNumber = new Zend_Form_Element_Button('remove');
            $removeSetsNumber->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');
            if ($product !== 'new') {
                $elements = array($courseCategory, $courseTools, $removeSetsNumber);
            } else {
                $elements = array($courseCategory, $courseTools);
            }
            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());
            if ($rowForm->getElement('remove')) {
                $rowForm->getElement('remove')->removeDecorator('Label');
            }
            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        }
        $subForm->setDecorators($this->getSubFormDecoratorsMain('courseTool', 'courseToolsFeature'));
        $courseToolsBtn = new Zend_Form_Element_Button('add');
        $courseToolsBtn->setLabel('Add')->setAttrib('class', 'btn btn-warning add');
        $subForm->addElement($courseToolsBtn);
        $subForm->setElementDecorators($this->getElementDecorators());
        $subForm->getElement('add')->removeDecorator('Label');
        $this->addSubForm($subForm, 'courseToolsFeature');
        */
        /**
         * End Of Sub-Form
         */
        $this->postSetup();
        if ($new) {
            $this->getElement('name')->addValidators($validators);
            $this->getElement('displayName')->addValidators($validateDisplayName);
        }

        /*$this->getElement('company_card_osl_contents')->setDescription('Please use "num_of_days" tag to mention number of days osl elearning access <br><br>')
                ->setDecorators(array(
                    'ViewHelper',
                    array('Description', array('escape' => false, 'tag' => false)),
                    array('HtmlTag', array('tag' => 'dd')),
                    array('Label', array('tag' => 'dt')),
                    'Errors',
        ));
        $this->getElement('company_card_lvc_contents')->setDescription('Please use "num_of_days" tag to mention number of days osl elearning access <br><br>')
                ->setDecorators(array(
                    'ViewHelper',
                    array('Description', array('escape' => false, 'tag' => false)),
                    array('HtmlTag', array('tag' => 'dd')),
                    array('Label', array('tag' => 'dt')),
                    'Errors',
        ));*/

        
        /*$this->getElement('flexi_card_contents')->setDescription('Please use "num_of_days" tag to mention number of days osl elearning access <br>Character Limit: 320 (including spaces)<br>')
                ->setDecorators(array(
                    'ViewHelper',
                    array('Description', array('escape' => false, 'tag' => false)),
                    array('HtmlTag', array('tag' => 'dd')),
                    array('Label', array('tag' => 'dt')),
                    'Errors',
        ));
        $this->getElement('osl_contents')->setDescription('Please use "num_of_days" tag to mention number of days osl elearning access <br>Character Limit: 400 (including spaces)<br>')
                ->setDecorators(array(
                    'ViewHelper',
                    array('Description', array('escape' => false, 'tag' => false)),
                    array('HtmlTag', array('tag' => 'dd')),
                    array('Label', array('tag' => 'dt')),
                    'Errors',
        ));*/
        $this->getElement('flexi_card_contents')->setDescription('Please use "num_of_days" tag to mention number of days osl elearning access <br>Character Limit: 320 (including spaces)<br>')
                ->setDecorators(array(
                    'ViewHelper',
                    array('Description', array('escape' => false, 'tag' => 'p','class' => 'description-note')),
                    array('HtmlTag', array('tag' => 'div','class' => 'element')),
                    array('Label', array('tag' => 'div')),
                    array('Errors'),
                    array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
        ));
        $this->getElement('osl_contents')->setDescription('Please use "num_of_days" tag to mention number of days osl elearning access <br>Character Limit: 400 (including spaces)<br>')
                ->setDecorators(array(
                    'ViewHelper',
                    array('Description', array('escape' => false, 'tag' => 'p','class' => 'description-note')),
                    array('HtmlTag', array('tag' => 'div','class' => 'element')),
                    array('Label', array('tag' => 'div')),
                    array('Errors'),
                    array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
        ));
        $this->getElement('intro_text')->setDescription('Character Limit: 500 (including spaces)')
                ->setDecorators(array(
                    'ViewHelper',
                    array('Description', array('escape' => false, 'tag' => 'p','class' => 'description-note')),
                    array('HtmlTag', array('tag' => 'div','class' => 'element')),
                    array('Label', array('tag' => 'div')),
                    array('Errors'),
                    array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
        ));
                $this->getElement('shortDescription')->setDescription('Character Limit: 500 (including spaces)')
                ->setDecorators(array(
                    'ViewHelper',
                    array('Description', array('escape' => false, 'tag' => 'p','class' => 'description-note')),
                    array('HtmlTag', array('tag' => 'div','class' => 'element')),
                    array('Label', array('tag' => 'div')),
                    array('Errors'),
                    array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
        ));
        $this->getElement('overview')->setDescription('Character Limit: 350 (including spaces)')
                ->setDecorators(array(
                    'ViewHelper',
                    array('Description', array('escape' => false, 'tag' => 'p','class' => 'description-note overview-description-note')),
                    array('HtmlTag', array('tag' => 'div','class' => 'element')),
                    array('Label', array('tag' => 'div')),
                    array('Errors'),
                    array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
        ));
        $this->getElement('b2b_contents')->setDescription('Character Limit: 700 (including spaces)')
                ->setDecorators(array(
                    'ViewHelper',
                    array('Description', array('escape' => false, 'tag' => 'p','class' => 'description-note')),
                    array('HtmlTag', array('tag' => 'div','class' => 'element')),
                    array('Label', array('tag' => 'div')),
                    array('Errors'),
                    array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
        ));
        $this->getElement('classroom_card_contents')->setDescription('Character Limit: 400 (including spaces)')
                ->setDecorators(array(
                    'ViewHelper',
                    array('Description', array('escape' => false, 'tag' => 'p','class' => 'description-note')),
                    array('HtmlTag', array('tag' => 'div','class' => 'element')),
                    array('Label', array('tag' => 'div')),
                    array('Errors'),
                    array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
        ));        
        $this->getElement('osl_defalut_text')->setDescription('Character Limit: 50 (including spaces)')
                ->setDecorators(array(
                    'ViewHelper',
                    array('Description', array('escape' => false, 'tag' => 'p','class' => 'description-note')),
                    array('HtmlTag', array('tag' => 'div','class' => 'element')),
                    array('Label', array('tag' => 'div')),
                    array('Errors'),
                    array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
        ));

        //Had to set the decorator  at the bottom , otherwise it is somehow getting overwritten
        $this->getElement('certificate_image')->setDecorators(
            array(
                'File',
                array('Errors', array('class'=>'errors error-file')),
                array(
                    array('data' => 'HtmlTag'),
                    array('tag' =>'div', 'class'=> 'element')
                ),
                array(
                    'Label',
                    array('tag' => 'div')
                ),
                array(
                    array('row' => 'HtmlTag'),
                    array('tag' => 'li')
                )
            )
        );
        
        $hiddenFields = array('categoryLabelName','course_advisor','accreditor_id_sorted_list','accreditor_id_sorted_list_new','courseToolsFeatureSortedList');
        foreach($hiddenFields as $field){
            $this->getElement($field)->setDecorators(array('ViewHelper'));
        }

        /*
          //adding course submit element
          $this->addElement('submit','Save',array(
          'ignore'=>true,
          'label'=>'Save',
          'class'=>'btn btn-info'
          ));
         *
         */
    }
    // end of function init

    public function getCourseAdvisorsData(){
        $return = array();
        $obj = new Model_ProductSectionData();
        $data = $obj->fetchAll(array('sectionType = ?' => "directors"));
        if (!empty($data)) {
            uasort($data, function($a, $b) {
                return strcmp($a['name'], $b['name']);
            });
            foreach ($data as $key => $value) {
                $return[$value['id']] = $value['id'].' - '.$value['name'];
            }
        }
        return $return;
    }
    public function removeUneditableElements() {
        $this->removeElement('url');
        return false;
    }

    public function editCourse($courseId) {
        $this->setName('EditCourse');
        $this->setMethod('post');
        $this->setAttrib('class', 'courseForm');
        $this->setAttrib('data-id', $courseId);
        $session = new Zend_Session_Namespace('form');
        $validatorsData = array(new Zend_Validate_StringLength(array('max' => 50)));
        $validatorsSource = array(new Zend_Validate_StringLength(array('max' => 30)));
        $validatorsName = array(new Zend_Validate_StringLength(array('max' => 100)));
        $validatorsDescription = array(new Zend_Validate_StringLength(array('max' => 90)));
        $validatorsLogoAndDirectorName = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 40)));
        $validatorsLogoAndDirectorDesig = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 70)));
        $validatorsLogoAndDirectorAchie = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 40)));
        $validatorsDirectorDesc = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 280)));
        $validatorsIntroText = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 500)));
        $validatorsCourseOverview = array(new Zend_Validate_StringLength(array('max' => 350)));
        $validatorsOslDefalutText = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 50)));
        $validatorsB2BCardText = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 700)));


        $validatorsCompanyCardTextForYourself = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 700)));
        $validatorsCompanyCardTextForManagers = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 700)));

        $validatorsCompanyCardTextForOSL = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 700)));
        $validatorsCompanyCardTextForLVC = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 700)));


        $validatorsPassCardText = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 320)));
        $validatorsOSLCardText = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 400)));
        $validateUrl = array(new BaseApp_Validate_Url());
        $validators = array(new Zend_Validate_NotEmpty(), new Zend_Validate_StringLength(array('max' => 100)));
        $validatorsCourseTool = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 70)));
        $objCourse = new Model_Courses();
        $courseData = $objCourse->fetchAll(array('course_id=?' => $courseId), array(), false);
        if (empty($courseData))
            return false;
        $courseData = $courseData[0];
        $courseData['intro_text'] = $objCourse->getCourseIntroText($courseId);
        $objSectionMapping = new Model_SectionMapping();
        $sectionData = $objSectionMapping->getByLinkableIdLinkableType($courseId, BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE, 'sm.id ASC');
        if (!empty($sectionData)) {
            $courseAdvisors = isset($sectionData['directors']) ? array_column($sectionData['directors'], 'section_id') : array();
            $courseData['course_advisor'] = array_unique($courseAdvisors);
        }

        $imageModel = new Model_Images();
        $imageData = $imageModel->getInclusionImages($courseId);

        //****************************** Course Basics Starts *****************************
        $this->addElement('radio', 'is_new_course_page', array(
            'required' => true,
            'label' => self::LABEL_IS_NEW_COURSE_PAGE,
            'multiOptions' => array(1 => self::LABEL_NEW_COURSE_PAGE, 0 => self::LABEL_OLD_COURSE_PAGE),
            'separator' => '',
            'registerInArrayValidator' => false,
            'value' => $courseData['is_new_course_page']
        ));
        $this->addElement('text', 'name', array(
            'label' => 'Name of the Course*',
            'required' => true,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'value' => $courseData['name']
        ));
        $this->addElement('hidden', 'currentCourseName', array(
            'required' => false,
            'value' => $courseData['name']
        ));
        $this->addElement('text', 'displayName', array(
            'label' => 'Display Name*',
            'required' => true,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'value' => $courseData['displayName']
        ));
        $objTag = new Model_Tags();
        $tagData = $objTag->getByLinkable($courseId, BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE);
        $this->addElement('text', 'tags', array(
            'label' => 'Tags (comma separated)*',
            'required' => true,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'value' => $tagData['tag']
        ));
        $basicGroup = array('is_new_course_page','name','displayName','tags');
        $this->addDisplayGroup($basicGroup, 'basic_group');
        $this->getDisplayGroup('basic_group')
                ->setLegend('Course Basics')
                ->clearDecorators()
                ->addDecorator('FormElements')
                ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper'));
        //****************************** Course Basics Ends *****************************
        
        //****************************** Course Mappings Starts*************************
        $obj        = new Model_Labels();
        $labelArr   = $obj->getPrimaryLableData();
        $this->addElement('select', 'primary_label_id', array(
            'label' => 'Primary Category',
            'required' => true,
            'registerInArrayValidator' => false,
            'multioptions' => array('0' => '--Select--') + $labelArr,
            'value' => $courseData['primary_label_id'],
            'class' => 'primary_label_id'
        ));
        $primaryLabelName = !empty($labelArr[$courseData['primary_label_id']]) ? $labelArr[$courseData['primary_label_id']] : '';
        $this->addElement('hidden', 'categoryLabelName', array(
            'required' => false,
            'value' => $primaryLabelName
        ));
        $this->addElement('hidden', 'oldCategoryLabelID', array(
            'required' => false,
            'value' => $courseData['primary_label_id']
        ));
        $this->addElement('select', 'label_id', array(
            'label' => 'Other Categories associated with this Course*',
            'required' => true,
            'multiple' => true,
            'class' => 'multiple',
            'registerInArrayValidator' => false,
            'multioptions' => $obj->getPrimaryLableData(),
            'value' => explode(",", $courseData['label_id'])
        ));
        $obj = new Model_Vendors();
        $this->addElement('select', 'vendor_id', array(
            'label' => 'Course Vendor',
            'required' => false,
            'multioptions' => array('0' => '--Select--') + $obj->fetchForSelect(),
            'value' => $courseData['vendor_id']
        ));

        $this->addElement('hidden', 'old_eLearning_id', array(
            'required' => false,
            'value' => $courseData['primary_eLearning_id']
        ));

        $looper = new BaseApp_Communication_Looper();
        $allCourses = $looper->getCourseList();
        $courseList = !empty($allCourses['data']) ? $allCourses['data'] : array();
        $this->addElement('select', 'primary_eLearning_id', array(
            'label' => 'Primary Elearning',
            'required' => false,
            'multioptions' => array('0' => '--Select--') + $courseList,
            'value' => $courseData['primary_eLearning_id']
        ));
        $this->addElement('hidden', 'old_primary_eLearning_id', array(
            'required' => false,
            'value' => $courseData['primary_eLearning_id']
        ));
        $this->addElement('radio', 'level', array(
            'required' => true,
            'label' => 'Course Level',
            'multiOptions' => array('Foundational' => 'Foundational', 'Advanced' => 'Advanced', 'Tool Based' => 'Tool Based', 'Knowledge Nuggets' => 'Knowledge Nuggets', 'Leadership Series' => 'Leadership Series'),
            'separator' => '',
            'registerInArrayValidator' => false,
            'value' => $courseData['level']
        ));
        $mappingsGroup = array('primary_label_id','label_id','vendor_id','primary_eLearning_id','level');
        $this->addDisplayGroup($mappingsGroup, 'mappings_group');
        $this->getDisplayGroup('mappings_group')
                ->setLegend('Course Mappings')
                ->clearDecorators()
                ->addDecorator('FormElements')
                ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper'));
        //****************************** Course Mappings Ends*************************        
        
        //****************************** Course Content Starts *****************************
        $this->addElement('textarea', 'intro_text', array(
            'label' => 'Course Introduction',
            'filter' => array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class' => 'description',
            'value' => $courseData['intro_text'],
            'validators' => $validatorsIntroText
        ));
        $this->addElement('textarea', 'shortDescription', array(
            'label' => 'Course Introduction for Mobile',
            'filter' => array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class' => 'description',
            'value' => $courseData['shortDescription'],
            'validators' => $validatorsIntroText
        ));
        $overviewId = isset($session->overview['course_faq_id'])?$session->overview['course_faq_id']:null;
        $overview = isset($session->overview['question'])?$session->overview['question']:null;
        $this->addElement('textarea', 'overview', array(
            'label' => 'Course Overview *',
            'filter' => array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class' => 'description',
            'value' => $overview,
            'validators' => $validatorsCourseOverview
        ));
        $this->addElement('hidden', 'course_faq_id', array(
            'required' => false,
            'value' => $overviewId 
        ));
        $this->addElement('textarea', 'b2b_contents', array(
            'label' => '﻿Course B2b Card',
            'filter' => array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class' => 'b2b_contents fck-enable',
            'validators' => $validatorsB2BCardText,
            'value' => $courseData['b2b_contents']
        ));
        $this->addElement('textarea', 'classroom_card_contents', array(
            'label' => 'Classroom Card Text',
            'filter' => array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class' => 'fck-enable',
            'validators' => $validatorsOSLCardText,
            'value' => $courseData['classroom_card_contents']
        ));
        $this->addElement('textarea', 'flexi_card_contents', array(
            'label' => 'Online Classroom Flexi Pass Card Text',
            'filter' => array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class' => 'fck-enable',
            'validators' => $validatorsPassCardText,
            'value' => $courseData['flexi_card_contents']
        ));
        $this->addElement('textarea', 'osl_contents', array(
            'label' => 'OSL Card Text',
            'filter' => array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class' => 'fck-enable',
            'validators' => $validatorsOSLCardText,
            'value' => $courseData['osl_contents']
        ));
        $this->addElement('textarea', 'osl_defalut_text', array(
            'label' => 'OSL DEFAULT TEXT',
            'filter' => array('StringTrim'),
            'rows' => 5,
            'value' => !empty($courseData['osl_defalut_text'])?$courseData['osl_defalut_text']:'',
            'cols' => 60,
            'class' => 'description',
            'validators' => $validatorsOslDefalutText
        ));
        $course = new Model_Courses();
        $this->addElement('select', 'freeCourses', array(
            'label' => 'Free Courses',
            'required' => false,
            'multiple' => true,
            'class' => 'multiple',
            'registerInArrayValidator' => false,
            'multioptions' => $course->getFreeCourseData(array('is_dummy = ?' => 0, 'course_id <> ?' => $courseId)),
            'value' => explode(",", $courseData['freeCourses'])
        ));
        $contentGroup = array('intro_text','shortDescription','overview'
            ,'b2b_contents','classroom_card_contents','flexi_card_contents','osl_contents','osl_defalut_text','freeCourses');
        $this->addDisplayGroup($contentGroup, 'content_group');
        $this->getDisplayGroup('content_group')
                ->setLegend('Course Content')
                ->clearDecorators()
                ->addDecorator('FormElements')
                ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper'));
        //****************************** Course Content Ends *****************************
        
        //****************************** Course Advisors Starts *****************************
        $obj = new Model_ProductSectionData();
        $obj->setDisplayField('name');
        $obj = new Model_ProductSectionData();
        $obj->setDisplayField('name');
        $this->addElement('select', 'course_advisor_temp', array(
            'label' => 'Course Advisors',
            'required' => false,
            'size' => 12,
            'multiple' => true,
            'class' => 'multiple',
            'registerInArrayValidator' => false,
            'multioptions' => array('0' => '--Select--') + $this->getCourseAdvisorsData()
        ));
        $advisorValue = !empty($courseData['course_advisor']) ? implode(",", $courseData['course_advisor']) : "";
        $this->addElement('hidden', 'course_advisor', array('required' => false, 'value' => $advisorValue));
        $advisorGroup = array('course_advisor_temp');
        $this->addDisplayGroup($advisorGroup, 'advisor_group');
        $this->getDisplayGroup('advisor_group')
                ->setLegend('Course Advisors')
                ->clearDecorators()
                ->addDecorator('FormElements')
                ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper'));
        //****************************** Course Advisors Ends *****************************
        //
        //****************************** Course Logos Starts *****************************
        $modelProductSectionData = new Model_ProductSectionData();
        $titleData = $modelProductSectionData->getDataByType($courseId,  BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE, BaseApp_Dao_ProductSectionData::SECTION_TYPE_ACCREDITOR_TITLE, true);
        $sectionTitle = '';
        if(!empty($titleData) && is_array($titleData) && !empty(current($titleData)['sectionTitle'])) {
            $sectionTitle = current($titleData)['sectionTitle'];
        }
        $this->addElement('text', 'accreditor_title', array(
            'label' => $this->_fieldLabels['accreditor_title'],
            'value' => $sectionTitle,
        ));
        
        $accreditorCond = array('isCoursePage'=>1);
        $accreditorObj = new Model_Accreditors();
        $accreditorMappingObj = new Model_AccreditorMapping();
        $oldCourseAcreditorList = $accreditorObj->fetchForSelect($accreditorCond);        
        $newCourseAcreditorList = $accreditorObj->fetchForSelect(array('isNewCoursePage' => 1));
        $courseAcreditorSelected = $accreditorMappingObj->fetchAll(array(
            'linkable_type = ?' => BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE, 
            'linkable_id = ?' => $courseId,
        ), array(
            'columns' => array('id', 'accreditor_id', 'accreditor_type'),
            'order' => array('id ASC')
        ));
        $selectedAccreditors = [];
        $selectedAccreditorsNew = [];
        foreach ($courseAcreditorSelected as $item) {
            if ($item['accreditor_type'] === BaseApp_Dao_AccreditorMapping::TYPE_CLASSIC_COURSE_PAGE) {
                $selectedAccreditors[] = $item['accreditor_id'];
            }
            if ($item['accreditor_type'] === BaseApp_Dao_AccreditorMapping::TYPE_NEW_COURSE_PAGE) {
                $selectedAccreditorsNew[] = $item['accreditor_id'];
            }
        }
        $selectedListCsv = implode(',', $selectedAccreditors);
        $selectedListCsvNew = implode(',', $selectedAccreditorsNew);
        $this->addElement('select', 'accreditor_id', array(
            'label' => $this->_fieldLabels['accreditor_id'],
            'required' => false,
            'multioptions' => $this->convertIdFormat($oldCourseAcreditorList),
            'size' => 12,
            'class' => 'multiple old_course_field',
            'registerInArrayValidator' => false,
            'value' => '',
        ));
        $this->addElement('hidden', 'accreditor_id_sorted_list', array('required' => false, 'value' => $selectedListCsv));
        $this->addElement('select', 'accreditor_id_new', array(
            'label' => $this->_fieldLabels['accreditor_id_new'],
            'required' => false,
            'multioptions' => $this->convertIdFormat($newCourseAcreditorList),
            // 'multiple' => true,
            'size' => 12,
            'class' => 'multiple new_course_field',
            'registerInArrayValidator' => false,
            'value' => ''
        ));
        $this->addElement('hidden', 'accreditor_id_sorted_list_new', array('required' => false, 'value' => $selectedListCsvNew));
        
        $toolsList = $this->getAllTools();
        $selectedList = array_keys($this->getSelectedTools());
        $this->addElement('select', 'courseToolsFeature', array(
            'label' => $this->_fieldLabels['courseToolsFeature'],
            'required' => false,
            'multioptions' => $toolsList,
            'size' => 12,
            'class' => 'multiple',
            'registerInArrayValidator' => false,
            'value' => '',
        ));
        $this->addElement('hidden', 'courseToolsFeatureSortedList', array('required' => false, 'value' => implode(',', $selectedList)));
        $this->addElement('text', 'image_home_page', array(
            'label' => 'Course Logo link (160 x 160)*',
            'required' => true,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'value' => @$imageData['image_home_page']['imagePath'],
            'validators' => array(
                new BaseApp_Validate_Image('courses', 'image_home_page')
            )
        ));
        $this->addElement('hidden', 'certificate_image_old', array(
            'value' => @$imageData['image_certificate']['imagePath'],
        ));
        $this->addElement('hidden', 'certificate_image_id', array(
            'value' => @$imageData['image_certificate']['image_id'],
        )); 
        $this->addElement($this->createElement('file','certificate_image',array(
            'label'=>'Certificate image* (730px X 516px, 380kb)',
            'required'=>false,
            'destination'=>sys_get_temp_dir(),            
            'validators'=>array('Extension' => array('jpeg','png','jpg'),
                array('ImageSize',false, array('maxwidth'=>730,'maxheight'=>516)),
                array('Size',false, array('useByteString'=> true, 'max' => '382kb'))
            )
        )));        
        if(isset($imageData['image_certificate'])){
            $this->addElement('text', 'certificate_value', array(
                'label' => 'Certificate Url',                
                'value' => @$imageData['image_certificate']['imagePath'],
                'helper' => 'formNote'                
            ));
        }
        $this->addElement('text', 'certificate_alt_text', array(
            'label' => 'Certificate Alt Text',
            'required' => false,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'value' => @$imageData['image_certificate']['imageDescription'],
        ));
        $logosGroup = array('accreditor_title','accreditor_id','accreditor_id_new','courseToolsFeature','image_home_page','certificate_image','certificate_value','certificate_alt_text');
        $this->addDisplayGroup($logosGroup, 'logos_group');
        $this->getDisplayGroup('logos_group')
                ->setLegend('Logos')
                ->clearDecorators()
                ->addDecorator('FormElements')
                ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper'));        
        //****************************** Course Logos Ends *****************************

        //****************************** Course Collateral Starts *****************************
        $this->addElement('text', 'agendaUrl', array(
            'label' => 'Course Agenda',
            'required' => false,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'value' => $courseData['agendaUrl']
        ));
        $default    = array();
        $modelVideo = new Model_Videos();
        $videoData  = $modelVideo->getByCourse($courseId, 0, 'about_course');
        if ($videoData) {
            $seoMd = new Model_Seo();
            $conds = array(
                'controller=?' => Model_Videos::SEO_DEFAULT_CONTROLLER,
                'action=?' => Model_Videos::SEO_DEFAULT_ACTION,
                'linkable_id=?' => $videoData['video_id'],
                'linkable_type=?' => 'video'
            );
            $seoData = current($seoMd->fetchAll($conds, array(), false));
            $default = array(
                'videoLink' => $videoData['videoLink'],
                'dateCreated' => $videoData['dateCreated'],
                'videoUrl' => $seoData['url'],
                'videoThumbnail' => $seoData['thumb_image'],
                'videoDescription' => $videoData['shortDescription']
            );
        }
        $preRun = $modelVideo->getByCourse($courseId, FALSE, 'pre_run_video');
        $flexiVideo = $modelVideo->getByCourse($courseId, FALSE, 'flexi_pass_video');
        $default['pre_run_video'] = !empty($preRun['videoLink']) ? $preRun['videoLink'] : '';
        $default['flexi_pass_video'] = !empty($flexiVideo['videoLink']) ? $flexiVideo['videoLink'] : '';
        
        // Video Link  Section //
        $this->addElement('text', 'videoLink', array(
            'label' => 'Introduction Video',
            'placeholder' => " Youtube video Embeded Link",
            'required' => false,
            'filters' => array('StringTrim'),
            'class' => 'longtext embeded-youtube-intro-video',
            'value' => !empty($default['videoLink']) ? $default['videoLink'] : ''
        ));
        $this->addElement('text', 'dateCreated', array(
            'label' => 'Video Uploaded date',
            'placeholder' => "YYYY-MM-DD",
            'required' => false,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'attribs' => array('readonly' => 'readonly'),
            'value' => !empty($default['dateCreated']) ? $default['dateCreated'] : ''
        ));
        $this->addElement('text', 'videoThumbnail', array(
            'label' => 'Video Thumbnail Image',
            'placeholder' => " Video Thumbnail Image",
            'required' => false,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'value' => !empty($default['videoThumbnail']) ? $default['videoThumbnail'] : ''
        ));
        $this->addElement('textarea', 'videoDescription', array(
            'label' => 'Video Description',
            'filter' => array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class' => 'description',
            'attribs' => array('readonly' => 'readonly'),
            'value' => !empty($default['videoDescription']) ? $default['videoDescription'] : ''
        ));
        $this->addElement('text', 'pre_run_video', array(
            'label' => 'Pre Run Video',
            'placeholder' => " Youtube video Embeded Link",
            'required' => false,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'value' => !empty($default['pre_run_video']) ? $default['pre_run_video'] : ''
        ));
        $this->addElement('text', 'flexi_pass_video', array(
            'label' => 'Flexi Pass Video',
            'placeholder' => " Youtube video Embeded Link",
            'required' => false,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'value' => !empty($default['flexi_pass_video']) ? $default['flexi_pass_video'] : ''
        ));
        $collateralGroup = array('agendaUrl','videoLink','dateCreated','videoThumbnail','videoDescription','pre_run_video','flexi_pass_video');
        $this->addDisplayGroup($collateralGroup, 'collateral_group');
        $this->getDisplayGroup('collateral_group')
                ->setLegend('Course Collateral')
                ->clearDecorators()
                ->addDecorator('FormElements')
                ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper'));
        //****************************** Course Collateral Ends *****************************
        
        //****************************** Course Others Starts *****************************
        $session = new Zend_Session_Namespace('form');

        /** Start: Sub form for training types*/
        $subForm = new Zend_Form_SubForm();
        $subForm->setName('trainingTypes');

        $traingType = new Model_TrainingTypes();
        $trainingTypeIds = $traingType->loadAll();
        $objAccessDays = new Model_AccessDays();

        $keyOSL = isset($session->trainingTypesData['osl2']) ? $session->trainingTypesData['osl2'] : '';
        $keyOSLAccessdays = isset($session->trainingTypesData['oslAccessDays']) ? $session->trainingTypesData['oslAccessDays'] : '';
        $keyClassRoom = isset($session->trainingTypesData['ilt1']) ? $session->trainingTypesData['ilt1'] : '';
        $keyClassRoomAccessDays = isset($session->trainingTypesData['classRoomAccessDays']) ? $session->trainingTypesData['classRoomAccessDays'] : '';

        $keyILO = isset($session->trainingTypesData['ilt3']) ? $session->trainingTypesData['ilt3'] : '';
        $keyILOAccessDays = isset($session->trainingTypesData['iloAccessDays']) ? $session->trainingTypesData['iloAccessDays'] : '';


        $trainingTypeOsl = new Zend_Form_Element_Checkbox('osl2');
        $trainingTypeOsl->setLabel($trainingTypeIds[2]['name']);
        if ($keyOSL) {
            $trainingTypeOsl->setAttrib('checked', true);
        }

        $oslAccessdays = new Zend_Form_Element_MultiCheckbox('oslAccessDays');
        $oslAccessdays->setLabel('select access days')->setOptions(array('multiOptions' => $objAccessDays->getAccessDays(2), 'separator' => ''))->setValue($keyOSLAccessdays)->setAttrib('class', 'oslAccessDays');


        $trainingTypeClassRoom = new Zend_Form_Element_Checkbox('ilt1');
        $trainingTypeClassRoom->setLabel($trainingTypeIds[1]['name']);
        if ($keyClassRoom) {
            $trainingTypeClassRoom->setAttrib('checked', true);
        }

        $classRoomAccessDays = new Zend_Form_Element_MultiCheckbox('classRoomAccessDays');
        $classRoomAccessDays->setLabel('access days')->setOptions(array('multioptions' => $objAccessDays->getAccessDays(1), 'separator' => ''))->setValue($keyClassRoomAccessDays)->setAttrib('class', 'classRoomAccessDays');

        $trainingTypeIlo = new Zend_Form_Element_Checkbox('ilt3');
        $trainingTypeIlo->setLabel($trainingTypeIds[3]['name']);
        if ($keyILO) {
            $trainingTypeIlo->setAttrib('checked', true);
        }

        $iloAccessDays = new Zend_Form_Element_MultiCheckbox('iloAccessDays');
        $iloAccessDays->setLabel('access days')->setOptions(array('multioptions' => $objAccessDays->getAccessDays(3), 'separator' => ''))->setValue($keyILOAccessDays)->setAttrib('class', 'iloAccessDays');

        $elements = array($trainingTypeOsl, $oslAccessdays, $trainingTypeIlo, $iloAccessDays, $trainingTypeClassRoom, $classRoomAccessDays);

        $subForm->addElements($elements);
        $subForm->setElementDecorators($this->getElementDecorators());
        $decos = $this->getSubFormDecorators();
        $decos[3][1]['class'] =  array('subform training-types-subform-courses');
        $subForm->setDecorators($decos);
        $subForm->setLegend('Training Types*');
        $this->addSubForm($subForm, 'trainingTypes');
        /** End: Sub form for training types*/
        
        $this->addElement('select', 'max_reg_count', array(
            'label' => 'Number of Active Registration Allowed (For Fair-Use policy)*',
            'required' => true,
            'value' => $courseData['max_reg_count'],
            'multioptions' => $this->maxActiveRegistrationAllowed
        ));
        $objPromo = new Model_PromoParams();
        $this->addElement('select', 'promo_id', array(
            'label' => 'Promo Param',
            'required' => false,
            'registerInArrayValidator' => false,
            'multioptions' => array('0' => '--Select--') + $objPromo->fetchForSelect(),
            'value' => $courseData['promo_id']
        ));
        $othersGroup = array('max_reg_count','promo_id');
        $this->addDisplayGroup($othersGroup, 'others_group');
        $this->getDisplayGroup('others_group')
                ->setLegend('Course Others')
                ->clearDecorators()
                ->addDecorator('FormElements')
                ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper'));        
                
        //****************************** Course Others Ends *****************************
        
        //****************************** Course Settings Starts *****************************
        $this->addElement('checkbox', 'hideFromSearch', array(
            'label' => 'Hide course from website',
            'value' => $courseData['hideFromSearch']
            ));
            $this->addElement('checkbox', 'osl_exam_fee_included', array(
            'label' => 'Is Exam Fee Included for Online Training',
            'value' => $courseData['osl_exam_fee_included']
            ));

            $this->addElement('radio', 'isCirtification', array(
            'required' => true,
            'label' => 'Is this a Certification course?',
            'multiOptions' => array(1 => 'Yes', 0 => 'No'),
            'separator' => '',
            'registerInArrayValidator' => false,
            'value' => $courseData['isCirtification']
            ));

            $this->addElement('checkbox', 'is_b2b', array(
            'label' => 'Available for Enterprise ?',
            'value' => $courseData['is_b2b']
            ));
            
            $this->addElement('select', 'course_available_for', array(
                'label' => 'Course Available For*',
                'required' => true,
                'multioptions' => $this->courseStatus,
                'value' => $courseData['course_available_for']
                ));
            $this->addElement('hidden', 'oldCourseAvailableFor', array(
                'required' => false,
                'value' => $courseData['course_available_for']
            ));
            $this->addElement('text', 'enterprise_list', array(
                'label' => 'Select One or More Enterprise(s)*',
                'filter' => array('StringTrim'),
                'style' => 'display: none'
            ));
            $this->addElement('checkbox', 'is_part_payment', array(
                'label' => 'Available For Part Pament',
                'value' => $courseData['is_part_payment']
             ));
            $this->addElement('checkbox', 'can_be_free', array(
            'label' => 'OSL can be given free?',
            'value' => $courseData['can_be_free']
            ));

            $this->addElement('checkbox', 'revenue_share', array(
            'label' => 'Is revenue shared',
            'value' => $courseData['revenue_share']
            ));

            $this->addElement('checkbox', 'money_back_guarantee', array(
                'label' => 'Money back guarantee',
                'value' => $courseData['money_back_guarantee']
            ));

            $this->addElement('textarea', 'money_back_guarantee_text', array(
                'label' => 'Money back guarantee text*',
                'required' => false,
                'rows' => 5,
                'cols' => 60,
                'filters' => array('StringTrim'),
                'class' => 'keyName',
                'value' => $courseData['money_back_guarantee_text']
            ));

            $settingsGroup = array('hideFromSearch','osl_exam_fee_included','isCirtification','is_b2b','course_available_for','enterprise_list','is_part_payment','can_be_free','revenue_share','money_back_guarantee','money_back_guarantee_text');
            $this->addDisplayGroup($settingsGroup, 'settings_group');
            $this->getDisplayGroup('settings_group')
                    ->setLegend('Settings')
                    ->clearDecorators()
                    ->addDecorator('FormElements')
                    ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper')); 
        //****************************** Course Settings Ends *****************************    
       

        /*
          $this->addElement('text','url',array(
          'label'=>'course Url*',
          'required'=>true,
          'filters'=>array('StringTrim'),
          'class'=>'longtext',
          'value'=>$courseData['url'],
          'validators' => array(
          new Zend_Validate_Db_NoRecordExists(array(
          'table' => 'seo',
          'field' => 'url'
          ))
          )
          ));
         */

        /* $obj =new Model_Accreditors();
          $this->addElement('select','accreditor_id',array(
          'label'=>'Is the Course Accredited ?',
          'required'=>false,
          'multioptions'=>array('0'=>'--Select--') + $obj->fetchForSelect(),
          'value'=>$courseData['accreditor_id']
          )); */
        

        // $this->addElement('text', 'image_course_detail_page', array(
        //     'label' => 'Course Detail page Image Link (Super big (size))*',
        //     'required' => true,
        //     'filters' => array('StringTrim'),
        //     'class' => 'longtext',
        //     'value' => @$imageData['image_course_detail_page']['imagePath'],
        //     'validators' => array(
        //         new BaseApp_Validate_Image('courses', 'image_course_detail_page')
        //     )
        // ));



        // $this->addElement('text', 'image_list_page', array(
        //     'label' => 'List page Image Link (120 x 120)*',
        //     'required' => true,
        //     'filters' => array('StringTrim'),
        //     'class' => 'longtext',
        //     'value' => @$imageData['image_list_page']['imagePath'],
        //     'validators' => array(
        //         new BaseApp_Validate_Image('courses', 'image_list_page')
        //     )
        // ));

        // $this->addElement('text', 'image_mobile', array(
        //     'label' => 'Mobile Image Link (60 x 60)*',
        //     'required' => true,
        //     'filters' => array('StringTrim'),
        //     'class' => 'longtext',
        //     'value' => @$imageData['image_mobile']['imagePath'],
        //     'validators' => array(
        //         new BaseApp_Validate_Image('courses', 'image_mobile')
        //     )
        // ));
        
        //moving to enterprice
        //Company card for yourself
        /*$this->addElement('textarea', 'company_card_osl_contents', array(
            'label' => 'Course OSL Card',
            'filter' => array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class' => 'b2b_contents fck-enable',
            'validators' => $validatorsCompanyCardTextForOSL,
            'value' => $courseData['company_card_osl_contents']
        ));
        //Company card for managers
        $this->addElement('textarea', 'company_card_lvc_contents', array(
            'label' => 'Course LVC Card',
            'filter' => array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class' => 'b2b_contents fck-enable',
            'validators' => $validatorsCompanyCardTextForLVC,
            'value' => $courseData['company_card_lvc_contents']
        ));*/
        //movong to settings section
        /*$this->addElement('radio', 'isCirtification', array(
            'required' => true,
            'label' => 'Is this a Certification course?',
            'multiOptions' => array(1 => 'Yes', 0 => 'No'),
            'separator' => '',
            'registerInArrayValidator' => false,
            'value' => $courseData['isCirtification']
        ));
        $this->addElement('checkbox', 'is_b2b', array(
            'label' => 'Available for Enterpirse ?',
            'value' => $courseData['is_b2b']
        ));
        $this->addElement('checkbox', 'osl_exam_fee_included', array(
            'label' => 'Is Exam Fee Included for Online Training',
            'value' => $courseData['osl_exam_fee_included']
        ));
        $this->addElement('checkbox', 'revenue_share', array(
            'label' => 'Is revenue shared',
            'value' => $courseData['revenue_share']
        ));
        $this->addElement('checkbox', 'hideFromSearch', array(
            'label' => 'Hide course from website',
            'value' => $courseData['hideFromSearch']
        ));
        $this->addElement('hidden', 'oldhideFromSearch', array(
            'required' => false,
            'value' => $courseData['hideFromSearch']
        ));
        $this->addElement('select', 'course_available_for', array(
            'label' => 'Course Available For*',
            'required' => true,
            'multioptions' => $this->courseStatus,
            'value' => $courseData['course_available_for']
        ));
        $this->addElement('checkbox', 'can_be_free', array(
            'label' => 'Can be given free',
            'value' => $courseData['can_be_free']
        ));
        */
        
        /*$conversionIndiaData = array(
            'industry' => array(
                'data' => '',
                'source' => '',
                'link' => ''
            ),
            'job' => array(
                'data' => '',
                'source' => '',
                'link' => ''
            ),
            'salary' => array(
                'data' => '',
                'source' => '',
                'link' => ''
            )
        );
        $session = new Zend_Session_Namespace('form');

        $subForm = new Zend_Form_SubForm();
        $subForm->setName('conversionForIndia');
        $conversionData = $session->conversionIndiaData;

        if (array_key_exists(INDIA_COUNTRY_ID, $conversionData)) {
            $conversionIndiaData = $conversionData[INDIA_COUNTRY_ID];
        }

        $this->addElement('checkbox', 'for_india', array(
            'label' => 'Show Data For India',
            'value' => empty($conversionIndiaData['industry']['data']) ? false : true
        ));

        foreach ($conversionIndiaData as $product => $productData) {
            $keyData = isset($productData['data']) ? $productData['data'] : '';
            $keySource = isset($productData['source']) ? $productData['source'] : '';
            $keyLink = isset($productData['link']) ? $productData['link'] : '';

            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);


            $data = new Zend_Form_Element_Text('data');
            $data->addFilter('stringTrim')->setValue($keyData)->setAttrib('class', 'longtext')->setLabel('Data*')->addValidators($validatorsData);

            $source = new Zend_Form_Element_Text('source');
            $source->addFilter('stringTrim')->setValue($keySource)->setAttrib('class', 'longtext')->setLabel('Source*')->addValidators($validatorsSource);

            $link = new Zend_Form_Element_Text('link');
            $link->addFilter('stringTrim')->setValue($keyLink)->setAttrib('class', 'longtext')->setLabel('Link')->addValidators($validateUrl);



            $elements = array($data, $source, $link);

            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());
            $rowForm->setLegend($product);
            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        }
        $subForm->setDecorators($this->getSubFormDecoratorsMain('course-conversion', 'conversionForIndia'));

        $subForm->setElementDecorators($this->getElementDecorators());
        $this->addSubForm($subForm, 'conversionForIndia');*/


        /* Start For Us */
        /*$conversionUsData = array(
            'industry' => array(
                'data' => '',
                'source' => '',
                'link' => ''
            ),
            'job' => array(
                'data' => '',
                'source' => '',
                'link' => ''
            ),
            'salary' => array(
                'data' => '',
                'source' => '',
                'link' => ''
            )
        );
        if (array_key_exists(US_COUNTRY_ID, $conversionData)) {
            $conversionUsData = $conversionData[US_COUNTRY_ID];
        }

        $this->addElement('checkbox', 'for_us', array(
            'label' => 'Show Data For Us/Row',
            'value' => empty($conversionUsData['industry']['data']) ? false : true
        ));

        $subForm = new Zend_Form_SubForm();
        $subForm->setName('conversionForUs');
        foreach ($conversionUsData as $product => $productData) {
            $keyData = isset($productData['data']) ? $productData['data'] : '';
            $keySource = isset($productData['source']) ? $productData['source'] : '';
            $keyLink = isset($productData['link']) ? $productData['link'] : '';

            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);


            $data = new Zend_Form_Element_Text('data');
            $data->addFilter('stringTrim')->setValue($keyData)->setAttrib('class', 'longtext')->setLabel('Data*')->addValidators($validatorsData);

            $source = new Zend_Form_Element_Text('source');
            $source->addFilter('stringTrim')->setValue($keySource)->setAttrib('class', 'longtext')->setLabel('Source*')->addValidators($validatorsSource);

            $link = new Zend_Form_Element_Text('link');
            $link->addFilter('stringTrim')->setValue($keyLink)->setAttrib('class', 'longtext')->setLabel('Link')->addValidators($validateUrl);

            $elements = array($data, $source, $link);

            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());
            $rowForm->setLegend($product);
            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        }
        $subForm->setDecorators($this->getSubFormDecoratorsMain('course-conversion', 'conversionForUs'));

        $subForm->setElementDecorators($this->getElementDecorators());
        $this->addSubForm($subForm, 'conversionForUs');


        $this->addElement('checkbox', 'previewFromElearning', array(
            'label' => 'Course Preview from e-Learning?',
            'value' => 1,
            'class'=>'hide',
            'attribs' => array('disabled' => 'disabled')
        ));*/

        /**
         * Sub Form For Course Tools
         */
        /*$this->addElement('hidden', 'course_tool_err', array(
            'required' => false,
            'value' => ''
        ));*/
        
        /*$subForm = new Zend_Form_SubForm();
        $subForm->setName('courseToolsFeature');
        foreach ($session->courseToolsFeature as $product) {
            $keyCourseCategory = isset($session->courseToolsFeatureData[$product]['course_category']) ? $session->courseToolsFeatureData[$product]['course_category'] : '';
            $keyToolId = isset($session->courseToolsFeatureData[$product]['tool_id']) ? $session->courseToolsFeatureData[$product]['tool_id'] : '';
            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);
            if ($product === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
            }
            $courseCategory = new Zend_Form_Element_Text('course_category');
            $courseCategory->addFilter('stringTrim')->setValue($keyCourseCategory)->setAttrib('class', 'courseCategory')->setAttrib('placeholder', 'Full Length Category Name')->setAttrib('maxlength', self::MAX_TOOL_CATEGORY_NAME_CHARCTERS)->setLabel('Course Category')->addValidators($validatorsCourseTool, false, array(0, self::MAX_TOOL_CATEGORY_NAME_CHARCTERS));
            $courseTools = new Zend_Form_Element_Select('tool_id');
            $toolList = $this->getAllTools();
            $courseTools->setOptions(array('select' => true, 'multiple' => true, 'required' => false, 'registerInArrayValidator' => false, 'multioptions' => array('0' => '--Select--') + $toolList))->setValue($keyToolId)->setAttrib('class', 'courseTool multiple')->setLabel('Tools');
            $removeSetsNumber = new Zend_Form_Element_Button('remove');
            $removeSetsNumber->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');
            if ($product !== 'new') {
                $elements = array($courseCategory, $courseTools, $removeSetsNumber);
            } else {
                $elements = array($courseCategory, $courseTools);
            }
            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());
            if ($rowForm->getElement('remove')) {
                $rowForm->getElement('remove')->removeDecorator('Label');
            }
            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        }
        $subForm->setDecorators($this->getSubFormDecoratorsMain('courseTool', 'courseToolsFeature'));
        $courseToolsBtn = new Zend_Form_Element_Button('add');
        $courseToolsBtn->setLabel('Add')->setAttrib('class', 'btn btn-warning add');
        $subForm->addElement($courseToolsBtn);        
        $subForm->setElementDecorators($this->getElementDecorators());
        $subForm->getElement('add')->removeDecorator('Label');
        $this->addSubForm($subForm, 'courseToolsFeature');
        */
        
        /**
         * End Of Sub-Form
         */
        $this->postSetup();

        $this->getElement('name')->addValidators($validators);
        $this->getElement('displayName')->addValidators($validators);

        /*$this->getElement('company_card_osl_contents')->setDescription('Please use "num_of_days" tag to mention number of days osl elearning access <br><br>')
                ->setDecorators(array(
                    'ViewHelper',
                    array('Description', array('escape' => false, 'tag' => false)),
                    array('HtmlTag', array('tag' => 'dd')),
                    array('Label', array('tag' => 'dt')),
                    'Errors',
        ));
        $this->getElement('company_card_lvc_contents')->setDescription('Please use "num_of_days" tag to mention number of days osl elearning access <br><br>')
                ->setDecorators(array(
                    'ViewHelper',
                    array('Description', array('escape' => false, 'tag' => false)),
                    array('HtmlTag', array('tag' => 'dd')),
                    array('Label', array('tag' => 'dt')),
                    'Errors',
        ));*/

        /*$this->getElement('flexi_card_contents')->setDescription('Please use "num_of_days" tag to mention number of days osl elearning access <br>Character Limit: 320 (including spaces)<br>')
                ->setDecorators(array(
                    'ViewHelper',
                    array('Description', array('escape' => false, 'tag' => false)),
                    array('HtmlTag', array('tag' => 'dd')),
                    array('Label', array('tag' => 'dt')),
                    'Errors',
        ));
        $this->getElement('osl_contents')->setDescription('Please use "num_of_days" tag to mention number of days osl elearning access <br>Character Limit: 400 (including spaces)<br>')
                ->setDecorators(array(
                    'ViewHelper',
                    array('Description', array('escape' => false, 'tag' => false)),
                    array('HtmlTag', array('tag' => 'dd')),
                    array('Label', array('tag' => 'dt')),
                    'Errors',
        ));*/
        $this->getElement('flexi_card_contents')->setDescription('Please use "num_of_days" tag to mention number of days osl elearning access <br>Character Limit: 320 (including spaces)<br>')
                ->setDecorators(array(
                    'ViewHelper',
                    array('Description', array('escape' => false, 'tag' => 'p','class' => 'description-note')),
                    array('HtmlTag', array('tag' => 'div','class' => 'element')),
                    array('Label', array('tag' => 'div')),
                    array('Errors'),
                    array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
        ));
        $this->getElement('osl_contents')->setDescription('Please use "num_of_days" tag to mention number of days osl elearning access <br>Character Limit: 400 (including spaces)<br>')
                ->setDecorators(array(
                    'ViewHelper',
                    array('Description', array('escape' => false, 'tag' => 'p','class' => 'description-note')),
                    array('HtmlTag', array('tag' => 'div','class' => 'element')),
                    array('Label', array('tag' => 'div')),
                    array('Errors'),
                    array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
        ));
        $this->getElement('intro_text')->setDescription('Character Limit: 500 (including spaces)')
                ->setDecorators(array(
                    'ViewHelper',
                    array('Description', array('escape' => false, 'tag' => 'p','class' => 'description-note')),
                    array('HtmlTag', array('tag' => 'div','class' => 'element')),
                    array('Label', array('tag' => 'div')),
                    array('Errors'),
                    array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
        ));
        $this->getElement('shortDescription')->setDescription('Character Limit: 500 (including spaces)')
                ->setDecorators(array(
                    'ViewHelper',
                    array('Description', array('escape' => false, 'tag' => 'p','class' => 'description-note')),
                    array('HtmlTag', array('tag' => 'div','class' => 'element')),
                    array('Label', array('tag' => 'div')),
                    array('Errors'),
                    array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
        ));
        $this->getElement('overview')->setDescription('Character Limit: 350 (including spaces)')
                ->setDecorators(array(
                    'ViewHelper',
                    array('Description', array('escape' => false, 'tag' => 'p','class' => 'description-note overview-description-note')),
                    array('HtmlTag', array('tag' => 'div','class' => 'element')),
                    array('Label', array('tag' => 'div')),
                    array('Errors'),
                    array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
        ));
        $this->getElement('b2b_contents')->setDescription('Character Limit: 700 (including spaces)')
                ->setDecorators(array(
                    'ViewHelper',
                    array('Description', array('escape' => false, 'tag' => 'p','class' => 'description-note')),
                    array('HtmlTag', array('tag' => 'div','class' => 'element')),
                    array('Label', array('tag' => 'div')),
                    array('Errors'),
                    array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
        ));
        $this->getElement('classroom_card_contents')->setDescription('Character Limit: 400 (including spaces)')
                ->setDecorators(array(
                    'ViewHelper',
                    array('Description', array('escape' => false, 'tag' => 'p','class' => 'description-note')),
                    array('HtmlTag', array('tag' => 'div','class' => 'element')),
                    array('Label', array('tag' => 'div')),
                    array('Errors'),
                    array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
        ));        
        $this->getElement('osl_defalut_text')->setDescription('Character Limit: 50 (including spaces)')
                ->setDecorators(array(
                    'ViewHelper',
                    array('Description', array('escape' => false, 'tag' => 'p','class' => 'description-note')),
                    array('HtmlTag', array('tag' => 'div','class' => 'element')),
                    array('Label', array('tag' => 'div')),
                    array('Errors'),
                    array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
        ));
        //Had to set the decorator  at the bottom , otherwise it is somehow getting overwritten
        $this->getElement('certificate_image')->setDecorators(
            array(
                'File',
                array('Errors', array('class'=>'errors error-file')),
                array(array('data' => 'HtmlTag'),array('tag' =>'div', 'class'=> 'element')),
                array('Label',array('tag' => 'div')),
                array(array('row' => 'HtmlTag'),array('tag' => 'li')),
                
            )
        );
        $hiddenFields = array('currentCourseName','categoryLabelName','oldCategoryLabelID','oldCourseAvailableFor','old_primary_eLearning_id','course_faq_id','course_advisor','accreditor_id_sorted_list','accreditor_id_sorted_list_new','courseToolsFeatureSortedList');
        foreach($hiddenFields as $field){
            $this->getElement($field)->setDecorators(array('ViewHelper'));
        }
        
    }
    
    private function convertIdFormat($list) {
        if(empty($list)) {
            return array();
        }
        foreach($list as $key => $val) {
            $list[$key] = "$key - $val";
        };
        return $list;
    }
    
    protected function getSubFormDecoratorsMain($className, $id) {
        return array(
            'FormElements',
            array(
                'HtmlTag', array('tag' => 'ul')
            ),
            array(
                array('row' => 'HtmlTag'),
                array('tag' => 'li', 'class' => $className, 'id' => $id)
            )
        );
    }

    public function isValid($data) {
        if ($data['is_new_course_page'] == 1 && empty($data['certificate_image_old'])){
            $this->getElement('certificate_image')->setRequired(true);
        }
        if ($data['is_new_course_page'] == 1){
            $this->getElement('overview')->setRequired(true);
        }
        $status = parent::isValid($data);
        if (!$status)
            return false;
        if ($data['is_new_course_page'] == '1' && $data['certificate_image']['name'] != '' && !empty($data['certificate_image']['name']) ){
            $fileName = $data['certificate_image']['name'];
            $fileName = explode(".", $fileName)[0];            
            if(!@preg_match('/^[A-Za-z0-9_-]+$/', $fileName)){
                $this->getElement('certificate_image')->setErrors(array("File name can only be Alpha numerics with _ and - "));
                $status = false;
            }   
        }            

        // accreditor_title
        if(empty($data['accreditor_title']) && (!empty($data['accreditor_id_sorted_list']) || !empty($data['accreditor_id_sorted_list_new']))) {
            $this->getElement('accreditor_title')->setErrors(array("Value is required and can't be empty"));
            $status = false;
        }

        if (isset($data['is_dummy']) && !$data['is_dummy'] && isset($data['is_free']) && !$data['is_free']) {
            if (empty($data['url'])) {
                $this->getElement('url')->setErrors(array("Value is required and can't be empty"));
            } else {
                $data['url'] = trim($data['url']);
                $checkSlash = substr($data['url'], 0, 1);
                if ($checkSlash != '/') {
                    $data['url'] = trim('/' . $data['url']);
                }
                $objSeo = new Model_Seo();
                if (false === $objSeo->validateUrl($data['url'])) {
                    $this->getElement('url')->setErrors(array("'{$data['url']}' is not a valid Course url"));
                    $status = false;
                }
            }
        }

        if (isset($data['is_b2b']) && $data['is_b2b']) {
            if (empty($data['b2b_contents'])) {
                $this->getElement('b2b_contents')->setErrors(array("B2B Card Text is required if course is available for Enterpirse"));
                $status = false;
            }
        }



        /*
          if(isset($data['is_free']) && $data['is_free']) {
          if(!isset($data['primary_eLearning_id']) || !$data['primary_eLearning_id']) {
          $this->getElement('primary_eLearning_id')->setErrors(array("Primary eLearning is required for free course"));
          $status = false;
          }
          }
         *
         */

        if ($data['agendaUrl']) {
            if (strpos(strtolower($data['agendaUrl']), 'https://www.simplilearn.com/ice9/pdfs/agenda/') === false) {
                $this->getElement('agendaUrl')->setErrors(array("Link should be Https and should have simplilearn domain"));
                $status = false;
            }
        }

        if (isset($data['primary_eLearning_id']) && $data['primary_eLearning_id']) {
            $courseObj = new BaseApp_Dao_Courses();
            $courseData = $courseObj->fetchAll(array('primary_eLearning_id = ?' => $data['primary_eLearning_id']), array('columns' => array('displayName', 'course_id')));
            if ($courseData) {
                $courseData = current($courseData);
                if ($this->_courseId) {
                    if ($this->_courseId != $courseData['course_id']) {
                        $this->getElement('primary_eLearning_id')->setErrors(array("'{$data['primary_eLearning_id']}' already assigned to the course '{$courseData['displayName']}'"));
                        $status = false;
                    }
                } else {
                    $this->getElement('primary_eLearning_id')->setErrors(array("'{$data['primary_eLearning_id']}' already assigned to the course '{$courseData['displayName']}'"));
                    $status = false;
                }
            }
        }
        
        // if( empty($data['for_india']) && empty($data['for_us'])){
        //     if(empty($data['for_india']))
        //         $this->getElement('for_india')->setErrors(array("Please select one or more countries to show data"));
        //     else
        //         $this->getElement('for_us')->setErrors(array("Please select one or more countries to show data"));
        //     return false;
        // }
        
        /**
         * Validate Tool Coverage
        if (!empty($data['courseToolsFeature'])) {
            $courseToolsValidStatus = $this->_validateCourseTools($data['courseToolsFeature']);
            if ($courseToolsValidStatus['toolCategoryCrossMaxLimit']):
                $maxAllowedTool = self::MAX_TOOLS_ALLOWED;
                $this->getElement('course_tool_err')->setErrors(array("Maxium Allowed Tool In Tool Coverage is : {$maxAllowedTool}"));
                $status = false;
            elseif (!empty($courseToolsValidStatus['toolCategoryDuplicate'])):
                $duplicateCategories = implode(' | ', $courseToolsValidStatus['toolCategoryDuplicate']);
                $this->getElement('course_tool_err')->setErrors(array("Duplicate Category Name Provided In Tools Coverage : {$duplicateCategories}"));
                $status = false;
            elseif (!empty($courseToolsValidStatus['toolsNotSelected'])):
                $toolNotSelected = implode(' | ', $courseToolsValidStatus['toolsNotSelected']);
                $msg = "Tool(s) Not Selected For Tool Category : {$toolNotSelected}.Either Remove It Or Select Atleast One Tool";
                $this->getElement('course_tool_err')->setErrors(array($msg));
                $status = false;
            elseif (!empty($courseToolsValidStatus['toolCategoryNameMinLimit'])):
                $msg = 'Minimum Characters For Tools Coverage Category Name Must Be : ' . self::MIN_TOOL_CATEGORY_NAME_CHARCTERS;
                $this->getElement('course_tool_err')->setErrors(array($msg));
                $status = false;
            elseif (!empty($courseToolsValidStatus['toolCategoryNameMaxLimit'])):
                $msg = 'Maximum Characters Allowed For Tools Coverage Category Is : ' . self::MAX_TOOL_CATEGORY_NAME_CHARCTERS;
                $this->getElement('course_tool_err')->setErrors(array($msg));
                $status = false;
            elseif (!empty($courseToolsValidStatus['toolNamesDuplicate'])):
                $duplicateToolNames = implode(' | ', $courseToolsValidStatus['toolNamesDuplicate']);
                //$this->getElement('course_tool_err')->setErrors(array("Duplicate Tool Selected In Tools Coverage  : {$duplicateToolNames}"));
                $duplicateToolList = '';
                if (!empty($courseToolsValidStatus['toolDuplicateList'])):
                    foreach ($courseToolsValidStatus['toolDuplicateList'] as $k => $list):
                        $duplicateToolList.="Tool : $k -> Present In Category :" . implode(' & ', array_unique($list)) . '   ||   ';
                    endforeach;
                    $duplicateToolList = rtrim($duplicateToolList, '   ||   ');
                    $this->getElement('course_tool_err')->setErrors(array("Duplicate Tool Selected In Tools Coverage  : {$duplicateToolList}"));
                endif;
                $status = false;
            endif;
        }
         * 
         */
        //Validate Intro Video        
        if ($data['videoLink']) {
            $videoLink = "";
            if (!empty($this->getView()->courseId)) {
                $courseId = $this->getView()->courseId;
                $modelVideo = new Model_Videos();
                $videoData = $modelVideo->getByCourse($courseId, 0, 'about_course');
                $videoLink = isset($videoData['videoLink']) ? $videoData['videoLink'] : "";
            }
            if (strpos(strtolower($data['videoLink']), 'https://www.youtube.com/embed/') === false) {
                $this->getElement('videoLink')->setErrors(array("Link should be Https and also Emebed  "));
                $status = false;
            } else if($data['videoLink'] != $videoLink){
                $youtubeApi = new BaseApp_Utility_YoutubeApi();
                $this->_vData = $youtubeApi->getVideoDetails($data['videoLink'],"snippet,contentDetails");
                if(!is_array($this->_vData)){
                    if($this->_vData == BaseApp_Utility_YoutubeApi::INVALID_VIDEO){
                    $this->getElement('videoLink')->setErrors(array("Please enter valid youtube video link"));
                    }
                    else if ($this->_vData == BaseApp_Utility_YoutubeApi::LIMIT_ERROR) {
                        $this->getElement('videoLink')->setErrors(array("Daily limit for authenticated use exceeded"));
                    } else {
                        $this->getElement('videoLink')->setErrors(array("Something is wrong with api."));
                    }
                    $status = false;
                }
            }

                if (!$data['videoThumbnail']) {
                    $this->getElement('videoThumbnail')->setErrors(array("video thumb nail image required"));
                    $status = false;
                } elseif (strpos(strtolower($data['videoThumbnail']), 'https://img.youtube.com') === false) {
                    $this->getElement('videoThumbnail')->setErrors(array("Link should be Https and also a Youtube link"));
                    $status = false;
                }
            }
        if (!empty($data['pre_run_video'])) {
            if (strpos(strtolower($data['pre_run_video']), 'https://www.youtube.com/embed/') === false) {
                $this->getElement('pre_run_video')->setErrors(array("Link should be Https and also Emebed "));
                $status = false;
            }
        }
        if (!empty($data['flexi_pass_video'])) {
            if (strpos(strtolower($data['flexi_pass_video']), 'https://www.youtube.com/embed/') === false) {
                $this->getElement('flexi_pass_video')->setErrors(array("Link should be Https and also Emebed "));
                $status = false;
            }
        }
        if (isset($data['money_back_guarantee']) && $data['money_back_guarantee']) {
            $data['money_back_guarantee_text'] = strip_tags(preg_replace( "/\r|\n/", "", $data['money_back_guarantee_text']));
            if (empty($data['money_back_guarantee_text'])) {
                $this->getElement('money_back_guarantee_text')->setErrors(array("Money Back Guarantee Text is required if Money Back Guarantee is checked"));
                $status = false;
            } elseif (!empty($data['money_back_guarantee_text']) && strlen($data['money_back_guarantee_text']) > MONEY_BACK_GUARANTEE_TEXT_LIMIT) {
                $this->getElement('money_back_guarantee_text')->setErrors(array("Money Back Guarantee Text should not exceed ".MONEY_BACK_GUARANTEE_TEXT_LIMIT." characters."));
                $status = false;
            }
        }
        return $status;
    }

    public function subFormValidations($data, $subForm, $status, $sectionTitle = '') {
        $count = 0;
        $countDir = 0;
        $status = true;
        if ($subForm == 'courseDirectors' && !empty($data)) {
            $errorKey = '';
            foreach ($data as $key => $dir) {
                if ($countDir == 0)
                    $errorKey = $key;
                if (!empty($dir['imageUrl']))
                    $countDir++;
                if (!empty($dir['show_at_top']) && $dir['show_at_top'] == 1)
                    $count++;
            }
            if ($countDir > 0 && $count == 0) {
                $this->getSubForm($subForm)->getSubForm($errorKey)->getElement('show_at_top')->setErrors(array("At least one director should be selected to show at top."));
                $status = false;
            }
            if ($count > 1) {
                $this->getSubForm($subForm)->getSubForm($errorKey)->getElement('show_at_top')->setErrors(array("Only one director should be selected to show at top."));
                $status = false;
            }
        }
        return $status;
    }

    /**
     * Get All Tools
     * @return array
     */
    private function getAllTools() {
        $modelProductSectionData = new Model_ProductSectionData();
        $sectionType = 'tools';
        $toolList = array();
        $result = $modelProductSectionData->getBySectionType($sectionType);
        if (!empty($result)) {
            $toolList = array_unique($result);
        }
        $toolList = $this->convertIdFormat($toolList);
        return $toolList;
    }
    
    private function getSelectedTools() {
        $sectionDataModel = new Model_ProductSectionData();
        $res = array();
        $selectedList = $sectionDataModel->getDataByType($this->_courseId, $sectionDataModel::LINKABLE_TYPE_COURSE, $sectionDataModel::SECTION_TYPE_COURSE_TOOLS, true, 'sm.id asc');
        if(!empty($selectedList)) {
            foreach($selectedList as $temp) {
                $res[$temp['section_id']] = $temp['name'];
            }
        }
        return $res;
    }

    /**
     * Replace Double Spaces Between Words With Single Space.
     * @param string $data
     * @return string
     */
    private function replaceDoubleSpaceWithSingle($param) {
        $result = '';
        if (!empty($param)):
            $result = preg_replace('!\s+!', ' ', $param);
        endif;
        return $result;
    }

    public function getVideoData(){
        return $this->_vData;
    }

}
