
<?php

class Form_CoursesMobileContent extends BaseApp_Form
{

    private $_courseId = null;

    public function __construct($courseId = false, $new = true)
    {
        if ($courseId) {
            $this->_courseId = $courseId;
        }
        $this->init($courseId);
        $this->loadDefaultDecorators();
    }

    public function init($courseId)
    {
        $this->setName('CoursesMobileContent');
        $this->setMethod('post');
        $this->setAttrib('class', 'courseForm');


        //Image upload for rectangular


        $imageModel = new Model_Images();
        $imageData = $imageModel->getInclusionImages($courseId);
        $courseData = new Model_Courses();
        $elearningHours = $courseData->getTotalElearningHours($courseId);
        $totalSeconds = !empty($elearningHours) && !empty($elearningHours[0]) && !empty($elearningHours[0]['totalDuration']) ? $elearningHours[0]['totalDuration'] : 0; 
        $hours = !empty($totalSeconds) ? floor($totalSeconds/3600) : 0;
        $hours = !empty($hours) ? $hours."h" : "0h";
        $minutes = !empty($totalSeconds) ? floor(($totalSeconds/60) % 60) : "0m";
        $minutes = !empty($minutes) ? $minutes."m" : 0;
        $seconds = !empty($totalSeconds) ?  $totalSeconds % 60 : "0s";
        $seconds = !empty($seconds) ? $seconds."s" : 0;
        $totalDuration = !empty($hours || $minutes || $seconds) ? "$hours:$minutes:$seconds" : "0h:0m:0s";


        $this->addElement($this->createElement('file', 'rect_image', array(
            'label' => 'Upload banner image* (360px X 194px, 380kb)',
            'required' => false,
            'destination' => sys_get_temp_dir(),
            'validators' => array(
                'Extension' => array('jpeg', 'png', 'jpg'),
                array('ImageSize', false, array('maxwidth' => 360, 'maxheight' => 194)),
                array('Size', false, array('useByteString' => true, 'max' => '380kb'))
            )
        )));
        if (!empty($imageData['rectangular_image'])) {
            $this->addElement('text', 'rectangular_value', array(
                'label' => 'Banner image Url',
                'value' => @$imageData['rectangular_image']['imagePath'],
                'helper' => 'formNote'
            ));
        }
        //Image upload for square image

        $this->addElement($this->createElement('file', 'square_image', array(
            'label' => 'Upload icon image* (288px X 288px, 380kb)',
            'required' => false,
            'destination' => sys_get_temp_dir(),
            'validators' => array(
                'Extension' => array('jpeg', 'png', 'jpg'),
                array('ImageSize', false, array('maxwidth' => 288, 'maxheight' => 288)),
                array('Size', false, array('useByteString' => true, 'max' => '380kb'))
            )
        )));
        if (!empty($imageData['square_image'])) {
            $this->addElement('text', 'square_value', array(
                'label' => 'Icon Image Url',
                'value' => @$imageData['square_image']['imagePath'],
                'helper' => 'formNote'
            ));
        }
        $this->addElement('text', 'totalDuration', array(
            'label' => 'Total Elearning Duration',
            'attribs' => array('readonly' => 'readonly'),
            'value' => !empty($totalDuration) && !empty($totalSeconds) ? $totalDuration : "0h:0m:0s"
        ));

        $this->addElement('submit', 'Save', array(
            'ignore' => true,
            'label' => 'Upload',
            'class' => 'btn btn-info'
        ));
        $this->getElement('rect_image')->setDecorators(
            array(
                'File',
                array('Errors', array('class' => 'errors error-file')),
                array(
                    array('data' => 'HtmlTag'),
                    array('tag' => 'div', 'class' => 'element')
                ),
                array(
                    'Label',
                    array('tag' => 'div')
                ),
                array(
                    array('row' => 'HtmlTag'),
                    array('tag' => 'li')
                )
            )
        );
    }
    public function isValid($data)
    {
        $status = parent::isValid($data);
        if (!$status)
            return false;

        if ($data['rect_image']['name'] != '' && !empty($data['rect_image']['name'])) {
            $fileName = $data['rect_image']['name'];
            $fileName = explode(".", $fileName)[0];
            if (!@preg_match('/^[A-Za-z0-9_-]+$/', $fileName)) {
                $this->getElement('rect_image')->setErrors(array("File name can only be Alpha numerics with _ and - "));
                $status = false;
            }
        }
        if ($data['square_image']['name'] != '' && !empty($data['square_image']['name'])) {
            $fileName = $data['square_image']['name'];
            $fileName = explode(".", $fileName)[0];
            if (!@preg_match('/^[A-Za-z0-9_-]+$/', $fileName)) {
                $this->getElement('square_image')->setErrors(array("File name can only be Alpha numerics with _ and - "));
                $status = false;
            }
        }
        return $status;
    }
}
