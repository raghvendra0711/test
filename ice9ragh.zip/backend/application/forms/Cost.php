<?php

class Form_Cost extends BaseApp_SubForm
{
    
    protected $submitName = 'Save';

    protected $costParams = array();
   
     public function __construct($paramsArr = array()) {
        $this->costParams = $paramsArr;
        $this->init();
    }
    public function init(){
        $this->setName('Cost');
        $this->setMethod('post');
        
        $this->addElement('text','course_name',array(
            'label'=>'COURSE*',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'readonly' => true,
            'autocomplete' => 'off'
        ));
        
         $this->addElement('checkbox', 'status', array(
            'label' => 'status', 'value' => 1
        ));
         
        $this->postSetup(); 
        $this->addElement('hidden','primary_course_id',array(
           'required'=>true,
           'value'=> ''
        ));
    }
   
    public function removeUneditableElements(){
        //$this->getElement('url')->setAttrib('disabled', 'disabled');
        //$this->getElement('url')->setRequired(false);
        return false;
    } 
    
    public function removeOptionalElements() {
        $this->removeElement('course_name');
    }
    
    public function isValid($data) {
        
        $status = parent::isValid($data); 
        return $status;
    }
}
