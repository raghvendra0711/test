<?php

class Form_Ebooks extends BaseApp_Form
{

    public function init(){

        $this->setName('Ebooks');
        $this->setMethod('post');

        $course =new Model_Courses();
        $this->addElement('select','course_id',array(
            'label'=>'Courses (Maximum allowed '.  Model_Ebooks::MAX_COURSES_ALLOWED_LINK.')',
            'required'=>false,
            'multiple' => true,
            'class' => 'multiple',
            'registerInArrayValidator' => false,
            'multioptions'=>$course->fetchForSelect(array('is_dummy = ?' => 0, 'is_free = ?' => 0))
        ));
        
        $label =new Model_Labels();
        $this->addElement('select','label_id',array(
            'label'=>'Labels (Maximum allowed '.  Model_Ebooks::MAX_CATEGORIES_ALLOWED_LINK.')*',
            'required'=>true,
            'multiple' => true,
            'class' => 'multiple',
            'registerInArrayValidator' => false,
            'multioptions'=>$label->fetchForSelect()
        ));
        
        $this->addElement('select','lead_course_id',array(
            'required'=>true,
            'label' => 'Course For Lead*', 
            'multioptions'=>array('0'=>'--Select--') +$course->fetchForSelect()
         ));
        
        $this->addElement('text','url',array(
            'label'=>'URL*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));
        
        $this->addElement('text','name',array(
            'label'=>'E-Book Name*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                new Zend_Validate_Db_NoRecordExists(array(
                    'table' => 'ebooks',
                    'field' => 'name'
                ))
            )
        ));

        $this->addElement('text','displayName',array(
            'label'=>'Display Name*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                new Zend_Validate_Db_NoRecordExists(array(
                    'table' => 'ebooks',
                    'field' => 'displayName'
                ))
            )
        ));

        $this->addElement('text','authorName',array(
            'label'=>'Author Name*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('text','downloadUrl',array(
            'label'=>'URL for Ebook*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('text','thumb_image',array(
            'label'=>'Thumbnail Image Url*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                new BaseApp_Validate_Image('ebooks', 'thumb_image')
            )
        ));
       
        $this->addElement('textarea','description',array(
            'label'=>'Description*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class' =>'fck-enable'
        ));
                
        $this->addElement('text','tags',array(
            'label'=>'Tags (comma separated)*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));
        
        $this->addElement('checkbox','is_featured',array(
            'label'=>'Is Featured?',
            'required'=>false
        ));
         
         $this->addElement('submit','Add EBook',array(
          'ignore'=>true,
          'label'=>'Submit'
         ));
    }

    public function removeUneditableElements(){
        $this->removeElement('url');
        return false;
    }

    public function removeOptionalValidators() {
        $this->getElement('name')->removeValidator('Db_NoRecordExists');
        $this->getElement('name')->setRequired(true);
        
        $this->getElement('displayName')->removeValidator('Db_NoRecordExists');
        $this->getElement('displayName')->setRequired(true);        
    }
    
    public function isValid($data) {   
        $status = parent::isValid($data);                
        if(!empty($data['url'])){
            $data['url'] = trim($data['url']);
            $checkSlash = substr($data['url'], 0,1);
            if($checkSlash != '/'){
                $data['url'] = trim('/'.$data['url']);
            }
            $objSeo = new Model_Seo();
            if(false === $objSeo->validateUrl($data['url'])){
                $this->getElement('url')->setErrors(array("'{$data['url']}' is not a valid Ebooks url"));
                $status = false;   
            }
        }
        if(!$data['lead_course_id']) {
            $this->getElement('lead_course_id')->setErrors(array("Value is required and can't be empty"));
            $status = false;
        }
        return $status;
    }
}