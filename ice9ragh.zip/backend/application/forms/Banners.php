<?php

class Form_Banners extends BaseApp_Form
{
    public function init(){

        $this->setName('Banners');
        $this->setMethod('post');
         //adding Label name element

        $labelModel = new Model_Labels();
        $this->addElement('select','labels',array(
            'label'=>'Label',
            'required'=>false,
            'multioptions'=>array('0'=>'--Select--') + $labelModel->getLabelsToshow()
        ));
        
        $this->addElement('checkbox','homeBanner',array(
            'label'=>'Is Home Page Banner'
        ));
         
        
        $clusterModel = new Model_Clusters();
        $this->addElement('select','cluster_id',array(
            'label'=>'Clusters/BU',
            'required'=>true,
            'multiple' => true,
            'registerInArrayValidator' => false,
            'multioptions'=>$clusterModel->getListDisplay()                  
        ));
        
        $countryModel = new Model_Country();
        $this->addElement('select','country_id',array(
            'label'=>'Countries',
            'required'=>false,
            'multiple' => true,
            'registerInArrayValidator' => false,
            'multioptions'=>$countryModel->getListDisplay()                  
        ));
         
         
        $this->addElement('text','banner_path',array(
            'label'=>'Banner',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off'
        ));
        
        $this->addElement('text','mobile_banner_path',array(
            'label'=>'Mobile Banner',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off'
        ));
        
        $this->addElement('submit','Save',array(
           'ignore'=>true,
           'label'=>'Save',
           'class'=>'btn btn-info'
        ));
    }
    
    public function removeUneditableElements(){
        $this->removeElement('labels');
        $this->removeElement('homeBanner');
    }
}