<?php

class Form_CompanyCoursePricing extends BaseApp_SubForm {

    protected $_domains;
    protected $_companyId = false;
    protected $_ppids = 0;
    protected $_learnerTotalRange = 0;
    protected $_exludedCourseIds = array();
    protected $_currentPlan = 0;
    protected $_productTypes=array();
    CONST PRICE_PLAN_DISCOUNT = 1;
    CONST PRICE_PLAN_FIXED = 2;
    CONST ACCESS_DAYS_365 = 4;

    public function setCompanyId($id) {
        $this->_companyId = $id;
    }

    public function __construct($companyId = 0, $isEdit = true, $ppids = 0, $ptype = '') {
        $this->_companyId = $companyId;
        $this->_exludedCourseIds = $this->_getExcludedCourseData();
        $this->_currentPlan = $this->_getPricingPlan();
        $this->_productTypes=$this->_getProductType();
        if ($isEdit && !empty($ppids)) {
            $this->editPricing($ppids, $ptype);
        } else {
            $this->init();
        }
        $this->loadDefaultDecorators();
    }

    /**
     * Edit Pricing
     * @param type $ppids
     */
    public function editPricing($ppids, $ptype) {
       
        $pricingData = array();
        $disableSelect = '';
        $isFlatPricing = 0;
       
        if ($ptype == 'product') {
            $b2bProPriObj = new Model_B2BProductPricing();
            $pricingData = $b2bProPriObj->getCoursePricingDataById($this->_companyId, $ppids);
        }
        if ($ptype == 'flat') {
            $b2bProPriObj = new Model_B2BFlatPricing();
            $pricingData = $b2bProPriObj->getCoursePricingDataById($this->_companyId, $ppids);
            $disableSelect = 'pointer-events: none';
            $isFlatPricing = 1;
        }
        $session = new Zend_Session_Namespace('form');
        $leanerRangeInfo = $session->learnerRange;
        $leanerRangaData = $this->_getCompanyPriceRange();
        if (!empty($leanerRangaData)) {
            $this->_learnerTotalRange = count($leanerRangeInfo) - 1;
        }
        $this->setName('CompanyPricing');
        $this->setMethod('post');
        $this->setAttrib('class', 'editCompanyPricingCourse');
        $subForm = new Zend_Form_SubForm();
        $subForm->setName('companyPricingCourse ');
        $hiddenElement = '';
        if (!empty($session->learnerRange)) {
            foreach ($session->learnerRange as $rangeIndex => $pricing) {
                $learnerRangeIndex = !empty($session->learnerRangeData[$pricing]) ? $session->learnerRangeData[$pricing]['min'] . '-' . $session->learnerRangeData[$pricing]['max'] : 0;
                $pricingInfo = array();
                if (!empty($pricingData[$learnerRangeIndex])) {
                    $pricingInfo = $pricingData[$learnerRangeIndex][0];
                }
                $rowForm = new Zend_Form_SubForm();
                $rowForm->setName($pricing);
                $elements = array();
                if ($pricing === '__template__') {
                    $rowForm->setAttrib('style', 'display: none;');
                } else {
                    if ($rangeIndex > 1) {
                        $hiddenElement = "hide-form-el";
                    }
                }
                $linkableType = new Zend_Form_Element_Hidden('linkable_type');
                $linkableType->setRequired(false)->setValue('course');
                /**
                 * Product Type 
                 */
                $productTypeVal = !empty($pricingInfo) ? $pricingInfo['product_type'] : 0;
                $productTypeLabel = empty($hiddenElement) ? "Product Type" : "";
                $productType = new Zend_Form_Element_Select('product_type');
                //$productTypeArr = array(0 => '--Select Product Type --', 'osl' => 'OSL', 'lvc' => 'LVC', 'mp' => 'Master Program');
                $productTypeArr = array(0 => '--Select Product Type --')+ $this->_productTypes;
                $productType->setOptions(array('multioptions' => $productTypeArr))
                        ->setValue($productTypeVal)
                        ->setAttribs(array('class' => "company_product_type $hiddenElement", 'style' => $disableSelect))
                        ->setLabel($productTypeLabel);
                /**
                 * Pricing Level
                 */
                $pricingLevelVal = !empty($pricingInfo) && !empty($pricingInfo['pricing_level']) ? $pricingInfo['pricing_level'] : 1;

                $locationModeLabel = empty($hiddenElement) ? "Pricing Level" : "";
                $locationMode = new Zend_Form_Element_Select('location_mode');
                //$locationMode->setOptions(array('multioptions' => array(0 => '--Select--', 2 => 'By Country')))->setValue('')->setAttrib('class', 'location')->setLabel('Pricing Level');
                $locationMode->setOptions(array('multioptions' => array(0 => '--Select--', 1 => 'By Cluster', 2 => 'By Country')))
                        ->setValue($pricingLevelVal)
                        ->setAttribs(array('class' => "location company-pricing-level $hiddenElement", 'style' => $disableSelect))
                        ->setLabel($locationModeLabel);
                /**
                 * Product Category
                 */
                $productCategoryVal = !empty($pricingInfo['product_category']) ? $pricingInfo['product_category'] : 0;
                $productCategoryArr[0] = '--Select Product Category --';
                $productCategoryArr['allcategories'] = 'All Categories';
                if (!empty($session->productCategory)) {
                    foreach ($session->productCategory as $key => $val) {
                        if ($key == 'new') {
                            continue;
                        }
                        $productCategoryArr[$key] = $val;
                    }
                }
                $productCategoryLabel = empty($hiddenElement) ? "Product Category" : "";
                $productCategory = new Zend_Form_Element_Select('product_category');
                $productCategory->setOptions(array('multioptions' => $productCategoryArr))
                        ->setValue($productCategoryVal)
                        ->setAttribs(array('class' => "company_category_type $hiddenElement", 'style' => $disableSelect))
                        ->setLabel($productCategoryLabel);
                /**
                 * Product List 
                 */
                $productListLabel = empty($hiddenElement) ? "Product List" : "";
                $productListArr = array('0' => '-- All Course --');
                if($productTypeVal=="mp"){
                    $productListArr = array('0' => '-- All Masters --');
                }
                $productList = new Zend_Form_Element_Select('product_list');
                $productList->setOptions(array('multioptions' => $productListArr))
                        ->setValue('')
                        ->setAttribs(array('class' => "courseListAll company_product_list $hiddenElement", 'size' => 15, 'style' => $disableSelect))
                        ->setLabel($productListLabel);
                /**
                 * Final Selection List
                 */
                $finalProductListVal = !empty($pricingInfo) ? $pricingInfo['productNameList'] : array();
                $finalProductListLabel = empty($hiddenElement) ? "Final Product List [ Click Course To Remove Form The List ]" : "";
                $finalProductListArr = array();
                $finalProductList = new Zend_Form_Element_Select('final_product_list');
                $finalProductList->setOptions(array('multioptions' => $finalProductListArr))
                        ->setValue('')
                        ->setAttribs(array('class' => "courseListAll company_final_product_list $hiddenElement", 'size' => 15, 'style' => $disableSelect))
                        ->setLabel($finalProductListLabel);
                $finalProductList->addMultiOptions($finalProductListVal);
                /**
                 * Country List
                 */
                $countryIdVal = !empty($pricingInfo) ? $pricingInfo['country_id'] : 0;
                $country = new Zend_Form_Element_Select('country_id');
                $countryList = array();
                $countryModel = new Model_Country();
                $countryList = $countryModel->fetchForSelect();
                $country->setOptions(array('multioptions' => array('0' => '--Select--') + $countryList, 'registerInArrayValidator' => false))
                        ->setValue($countryIdVal)
                        ->setAttribs(array('class' => "country course_country", 'style' => $disableSelect))
                        ->setLabel('Country');
                if ($pricingLevelVal == 1 || $rangeIndex > 1) {
                    $country->setOptions(array('style' => 'display: none'));
                }
                /**
                 * Cluster List
                 */
                $clusterIdVal = !empty($pricingInfo) ? $pricingInfo['cluster_id'] : 0;
                $clusterLabel = !empty($clusterLevelHide) ? "Cluster" : "";
                $cluster = new Zend_Form_Element_Select('cluster_id');
                $clusterList = array();
                $obj = new Model_Clusters();
                $clusterList = $obj->fetchForSelect();
                $cluster->setOptions(array('multioptions' => array('0' => '--Select--') + $clusterList, 'reDeisterInArrayValidator' => false))
                        ->setValue($clusterIdVal)
                        ->setAttribs(array('class' => "cluster course_cluster", 'style' => $disableSelect))
                        ->setLabel("Cluster");
                if ($pricingLevelVal == 2 || $rangeIndex > 1) {
                    $cluster->setOptions(array('style' => 'display: none'));
                }

                $leanerRangeMinVal = !empty($leanerRangaData[$rangeIndex]['min']) ? $leanerRangaData[$rangeIndex]['min'] : 0;
                $leanerRangeMaxVal = !empty($leanerRangaData[$rangeIndex]['max']) ? $leanerRangaData[$rangeIndex]['max'] : 0;
                $learnerRangeIdVal = !empty($leanerRangaData[$rangeIndex]['id']) ? $leanerRangaData[$rangeIndex]['id'] : 0;

                $learnerRangeMin = new Zend_Form_Element_Text('learners_range_min');
                $learnerRangeMin->addFilter('stringTrim')->setValue($leanerRangeMinVal)->setAttribs(array('class' => 'learnerRangeMin readonly_input', 'readonly' => 'true'))->setLabel('Learner Range Min');

                $learnerRangeMax = new Zend_Form_Element_Text('learners_range_max');
                $learnerRangeMax->addFilter('stringTrim')->setValue($leanerRangeMaxVal)->setAttribs(array('class' => 'learnerRangeMax readonly_input', 'readonly' => 'true'))->setLabel('Learner Range Max');

                $learnerRangeId = new Zend_Form_Element_Text('learners_range_id');
                $learnerRangeId->addFilter('stringTrim')->setValue($learnerRangeIdVal)->setAttribs(array('class' => 'hide-form-el readonly_input', 'readonly' => 'true'))->setLabel('');

                /**
                 * Access days 
                 */
                $accessDaysVal = !empty($pricingInfo) ? $pricingInfo['access_day_id'] : self::ACCESS_DAYS_365;
                $setsNumber = new Zend_Form_Element_Select('access_day_id');
                $accessObj = new Model_AccessDays();
                $arr = $accessObj->getAccessDaysById('osl');
                $con = ['4' => 365];
                $disabled = array_diff($arr,$con);
                $disabled_options = array_keys($disabled);
                $setsNumber->addFilter('stringTrim')
                        ->setValue($accessDaysVal)
                        ->setAttrib('class', 'accessDaysCount')
                        ->setAttrib('disable',$disabled_options)
                        ->setAttrib('placeholder', 'Access Days')
                        ->setLabel('Access Days')
                        ->setOptions(array('multioptions' => array('0' => '--Select--') + $accessObj->getAccessDaysById('osl'), 'registerInArrayValidator' => false));
                /**
                 * Training Type
                 */
                $trainingTypeVal = 0;
                if ($productTypeVal == "osl" || $productTypeVal == "mp") {
                    $trainingTypeVal = BaseApp_Dao_TrainingTypes::TYPE_ELEARNING;
                } else {
                    $trainingTypeVal = BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS;
                }
                $trainingType = new Zend_Form_Element_Select('training_id');
                $trainingType->setOptions(array('multioptions' => array(BaseApp_Dao_TrainingTypes::TYPE_ELEARNING => 'Online Self Learning', BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS => 'LVC')))
                        ->setValue($trainingTypeVal)
                        ->setAttrib('class', 'trainingId hide-form-el')
                        ->setLabel('');

                $hideFlatPriceClass = '';
                if ($this->_currentPlan == self::PRICE_PLAN_DISCOUNT) {
                    $hideFlatPriceClass = 'hide-form-el';
                }
                /**
                 * Flat Price
                 */
                $flatPriceVal = !empty($pricingInfo) ? $pricingInfo['flat_price'] : '';
                $flatPrice = new Zend_Form_Element_Text('flat_price');
                $flatPrice->addFilter('stringTrim')
                        ->setValue($flatPriceVal)
                        ->setAttrib('class', "flat_price $hideFlatPriceClass")
                        ->setLabel('Flat Price')
                        ->setAttrib('placeholder', 'Flat Price');
                /**
                 * Flat Discount 
                 */
                $flatDiscountVal = !empty($pricingInfo) ? $pricingInfo['flat_discount'] : '';
                $discount = new Zend_Form_Element_Text('flat_discount');
                $discount->addFilter('stringTrim')
                        ->setValue($flatDiscountVal)
                        ->setAttrib('class', 'flat_discount')
                        ->setLabel('Discount(%)')
                        ->setAttrib('placeholder', 'Discount (%)');
                /**
                 * Final List Of Selected Product Ids.
                 */
                $finalProductListIdsVal = !empty($pricingInfo['productids']) ? $pricingInfo['productids'] . ',' : '';
                $selectedCourseIds = new Zend_Form_Element_Text('final_course_ids');
                $selectedCourseIds->setValue($finalProductListIdsVal)
                        ->setAttrib('class', 'final_course_ids hide-form-el')
                        ->setLabel('');

                $elements = array($linkableType, $productType, $locationMode, $country, $cluster, $productCategory, $productList, $finalProductList, $learnerRangeMin, $learnerRangeMax, $learnerRangeId, $setsNumber, $trainingType, $flatPrice, $discount, $selectedCourseIds);

                $removeSetsNumber = new Zend_Form_Element_Button('remove');
                $removeSetsNumber->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove hide-form-el')->setAttrib('onclick', 'removeSubFormElement(this)');

                if ($pricing !== 'new') {
                    $elements[] = $removeSetsNumber;
                }
                $rowForm->addElements($elements);
                $rowForm->setElementDecorators($this->getElementDecorators());

                if ($rowForm->getElement('remove')) {
                    $rowForm->getElement('remove')->removeDecorator('Label');
                }
                if ($this->_currentPlan == self::PRICE_PLAN_DISCOUNT) {
                    $rowForm->getElement('flat_price')->removeDecorator('Label');
                }
                if ($pricingLevelVal == 1 || $rangeIndex > 1) {
                    $label = $rowForm->getElement('country_id')->getDecorator('Label');
                    $label->setOption('style', 'display: none;');
                }
                if ($pricingLevelVal == 2 || $rangeIndex > 1) {
                    $label = $rowForm->getElement('cluster_id')->getDecorator('Label');
                    $label->setOption('style', 'display: none;');
                }


                $rowForm->setDecorators($this->getSubFormDecorators());
                $subForm->addSubForm($rowForm, $pricing);
            }

            $subForm->setDecorators($this->getSubFormDecoratorsMain('companyPricingCourse', 'companyPricingCourse'));
            // $addPricing = new Zend_Form_Element_Button('add');
            // $addPricing->setLabel('Add Pricing')->setAttribs(array('class' => 'btn btn-warning add', 'data-total-range' => $this->_learnerTotalRange, 'data-range-info' => json_encode($leanerRangaData)));
            // $subForm->addElement($addPricing);

            $subForm->setElementDecorators($this->getElementDecorators());
            // $subForm->getElement('add')->removeDecorator('Label');
            $this->addSubForm($subForm, 'companyPricingCourse');
            // course pricing subform end
            $this->addElement('hidden', 'company_id', array('required' => false));
            $this->addElement('hidden', 'is_flat', array('required' => false, 'value' => $isFlatPricing));
            $this->addElement('hidden', 'is_edit_mode', array('required' => false, 'value' => true));
            $this->addElement('hidden', 'original_ppids', array('required' => false, 'value' => $ppids));
            $exludedCourseIdsListStr = implode(',', $this->_exludedCourseIds);
            $this->addElement('hidden', 'excluded_course_ids_list', array('required' => false, 'value' => $exludedCourseIdsListStr));
            $this->addElement('submit', 'Save Pricing', array(
                'id'=>'saveCoursePricing',
                'ignore' => true,
                'label' => 'Update Pricing',
                'class' => 'btn btn-info'
            ));
            $this->addElement('button', 'Cancel Pricing', array(
                'ignore' => true,
                'label' => 'Cancel',
                'class' => 'btn cancel_pricing btn-info',
                'data-company-id' => $this->_companyId
            ));
        }
    }

    public function init() {
        $session = new Zend_Session_Namespace('form');
        $leanerRangeInfo = $session->learnerRange;
        $leanerRangaData = $this->_getCompanyPriceRange();
        if (!empty($leanerRangaData)) {
            $this->_learnerTotalRange = count($leanerRangeInfo) - 1;
        }
        $this->setName('CompanyPricing');
        $this->setMethod('post');
        $subForm = new Zend_Form_SubForm();
        $subForm->setName('companyPricingCourse');
        $hiddenElement = '';
        if (!empty($session->learnerRange)) {

            foreach ($session->learnerRange as $rangeIndex => $pricing) {
                $rowForm = new Zend_Form_SubForm();
                $rowForm->setName($pricing);
                $elements = array();
                if ($pricing === '__template__') {
                    $rowForm->setAttrib('style', 'display: none;');
                } else {
                    if ($rangeIndex > 1) {
                        $hiddenElement = "hide-form-el";
                    }
                }
                $linkableType = new Zend_Form_Element_Hidden('linkable_type');
                $linkableType->setRequired(false)->setValue('course');
                /**
                 * Product Type 
                 */
                $productTypeLabel = empty($hiddenElement) ? "Product Type" : "";
                $productType = new Zend_Form_Element_Select('product_type');
                $productTypeArr = array(0 => '--Select Product Type --')+ $this->_productTypes;
                $productType->setOptions(array('multioptions' => $productTypeArr))
                        ->setValue('')
                        ->setAttrib('class', "company_product_type $hiddenElement")
                        ->setLabel($productTypeLabel);

                $locationModeLabel = empty($hiddenElement) ? "Pricing Level" : "";
                $locationMode = new Zend_Form_Element_Select('location_mode');
                $locationMode->setOptions(array('multioptions' => array(0 => '--Select--', 1 => 'By Cluster', 2 => 'By Country')))
                        ->setValue('')
                        ->setAttrib('class', "location company-pricing-level $hiddenElement")
                        ->setLabel($locationModeLabel);
                /**
                 * Product Category
                 */
                $productCategoryArr[0] = '--Select Product Category --';
                $productCategoryArr['allcategories'] = 'All Categories';
                if (!empty($session->productCategory)) {
                    foreach ($session->productCategory as $key => $val) {
                        if ($key == 'new') {
                            continue;
                        }
                        $productCategoryArr[$key] = $val;
                    }
                }
                $productCategoryLabel = empty($hiddenElement) ? "Product Category" : "";
                $productCategory = new Zend_Form_Element_Select('product_category');
                $productCategory->setOptions(array('multioptions' => $productCategoryArr))
                        ->setValue('')
                        ->setAttrib('class', "company_category_type $hiddenElement")
                        ->setLabel($productCategoryLabel)
                        ->setRegisterInArrayValidator(false);
                /**
                 * Product List 
                 */
                $productListLabel = empty($hiddenElement) ? "Product List" : "";
                $productListArr = array('0' => '');
                $productList = new Zend_Form_Element_Select('product_list');
                $productList->setOptions(array('multioptions' => $productListArr))
                        ->setValue('')
                        ->setAttribs(array('class' => "courseListAll company_product_list $hiddenElement", 'size' => 15,))
                        ->setLabel($productListLabel);
                /**
                 * Final Selection List
                 */
                $finalProductListLabel = empty($hiddenElement) ? "Final Product List [ Click Course To Remove Form The List ]" : "";
                $finalProductListArr = array('0' => '');
                $finalProductList = new Zend_Form_Element_Select('final_product_list');
                $finalProductList->setOptions(array('multioptions' => $finalProductListArr))
                        ->setValue('')
                        ->setAttribs(array('class' => "courseListAll company_final_product_list $hiddenElement", 'size' => 15,))
                        ->setLabel($finalProductListLabel);
                /**
                 * Country List
                 */
                $countryLabel = empty($hiddenElement) ? "Country" : "";
                $country = new Zend_Form_Element_Select('country_id');
                $countryList = array();
                $countryModel = new Model_Country();
                $countryList = $countryModel->fetchForSelect();
                $country->setOptions(array('multioptions' => array('0' => '--Select--') + $countryList, 'registerInArrayValidator' => false))
                        ->setValue('')
                        ->setAttrib('class', "country company-pricing-level-hide $hiddenElement")
                        ->setLabel("Country");


                /**
                 * Cluster List
                 */
                $clusterLabel = empty($hiddenElement) ? "Cluster" : "";
                $cluster = new Zend_Form_Element_Select('cluster_id');
                $clusterList = array();
                $obj = new Model_Clusters();
                $clusterList = $obj->fetchForSelect();
                $cluster->setOptions(array('multioptions' => array('0' => '--Select--') + $clusterList, 'registerInArrayValidator' => false))
                        ->setValue('')
                        ->setAttrib('class', "cluster company-pricing-level-hide $hiddenElement")
                        ->setLabel("Cluster");

                /* $defCountry = new Zend_Form_Element_Select('def_country_id');
                  $countryList = array();
                  $countryModel = new Model_Country();
                  $countryList = $countryModel->fetchForSelect();
                  $defCountry->setOptions(array('multioptions' => array('0' => '--Select--') + $countryList, 'registerInArrayValidator' => false))->setValue('')->setAttrib('class', 'country')->setLabel('Default Country'); */
                $leanerRangeMinVal = !empty($leanerRangaData[$rangeIndex]['min']) ? $leanerRangaData[$rangeIndex]['min'] : 0;
                $leanerRangeMaxVal = !empty($leanerRangaData[$rangeIndex]['max']) ? $leanerRangaData[$rangeIndex]['max'] : 0;
                $learnerRangeIdVal = !empty($leanerRangaData[$rangeIndex]['id']) ? $leanerRangaData[$rangeIndex]['id'] : 0;


                $learnerRangeMin = new Zend_Form_Element_Text('learners_range_min');
                $learnerRangeMin->addFilter('stringTrim')->setValue($leanerRangeMinVal)->setAttribs(array('class' => 'learnerRangeMin readonly_input', 'readonly' => 'true'))->setLabel('Learner Range Min');

                $learnerRangeMax = new Zend_Form_Element_Text('learners_range_max');
                $learnerRangeMax->addFilter('stringTrim')->setValue($leanerRangeMaxVal)->setAttribs(array('class' => 'learnerRangeMax readonly_input', 'readonly' => 'true'))->setLabel('Learner Range Max');

                $learnerRangeId = new Zend_Form_Element_Text('learners_range_id');
                $learnerRangeId->addFilter('stringTrim')->setValue($learnerRangeIdVal)->setAttribs(array('class' => 'hide-form-el readonly_input', 'readonly' => 'true'))->setLabel('');

                $setsNumber = new Zend_Form_Element_Select('access_day_id');
                $accessObj = new Model_AccessDays();
                $arr = $accessObj->getAccessDaysById('osl');
                $con = ['4' => 365];
                $disabled = array_diff($arr,$con);
                $disabled_options = array_keys($disabled);
                $setsNumber->addFilter('stringTrim')->setValue(self::ACCESS_DAYS_365)
                ->setAttrib('disable',$disabled_options)
                ->setAttrib('class' , 'accessDaysCount')
                ->setAttrib('placeholder', 'Access Days')->setLabel('Access Days')->setOptions(array('multioptions' => array('0' => '--Select--') + $accessObj->getAccessDaysById('osl'), 'registerInArrayValidator' => false));
                $trainingType = new Zend_Form_Element_Select('training_id');
                $trainingType->setOptions(array('multioptions' => array(BaseApp_Dao_TrainingTypes::TYPE_ELEARNING => 'Online Self Learning', BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS => 'LVC')))->setValue(BaseApp_Dao_TrainingTypes::TYPE_ELEARNING)->setAttrib('class', 'trainingId hide-form-el')->setLabel('');

                $hideFlatPriceClass = '';
                if ($this->_currentPlan == self::PRICE_PLAN_DISCOUNT) {
                    $hideFlatPriceClass = 'hide-form-el';
                }
                $flatPrice = new Zend_Form_Element_Text('flat_price');
                $flatPrice->addFilter('stringTrim')->setValue('')->setAttrib('class', "flat_price $hideFlatPriceClass")->setLabel('Flat Price')->setAttrib('placeholder', 'Flat Price');

                $discount = new Zend_Form_Element_Text('flat_discount');
                $discount->addFilter('stringTrim')->setValue('')->setAttrib('class', 'flat_discount')->setLabel('Discount(%)')->setAttrib('placeholder', 'Discount (%)');

                $selectedCourseIds = new Zend_Form_Element_Text('final_course_ids');
                $selectedCourseIds->setValue('')->setAttrib('class', 'final_course_ids hide-form-el')
                        ->setLabel('');

                $elements = array($linkableType, $productType, $locationMode, $country, $cluster, $productCategory, $productList, $finalProductList, $learnerRangeMin, $learnerRangeMax, $learnerRangeId, $setsNumber, $trainingType, $flatPrice, $discount, $selectedCourseIds);

                $removeSetsNumber = new Zend_Form_Element_Button('remove');
                $removeSetsNumber->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove hide-form-el')->setAttrib('onclick', 'removeSubFormElement(this)');

                if ($pricing !== 'new') {
                    $elements[] = $removeSetsNumber;
                }
                $rowForm->addElements($elements);
                $rowForm->setElementDecorators($this->getElementDecorators());

                $label = $rowForm->getElement('cluster_id')->getDecorator('Label');
                $label->setOption('style', 'display: none;');

                $label = $rowForm->getElement('country_id')->getDecorator('Label');
                $label->setOption('style', 'display: none;');

                if ($rowForm->getElement('remove')) {
                    $rowForm->getElement('remove')->removeDecorator('Label');
                }
                if ($this->_currentPlan == self::PRICE_PLAN_DISCOUNT) {
                    $rowForm->getElement('flat_price')->removeDecorator('Label');
                }
                $rowForm->setDecorators($this->getSubFormDecorators());
                $subForm->addSubForm($rowForm, $pricing);
            }


            $subForm->setDecorators($this->getSubFormDecoratorsMain('companyPricingCourse', 'companyPricingCourse'));
            // $addPricing = new Zend_Form_Element_Button('add');
            // $addPricing->setLabel('Add Pricing')->setAttribs(array('class' => 'btn btn-warning add', 'data-total-range' => $this->_learnerTotalRange, 'data-range-info' => json_encode($leanerRangaData)));
            // $subForm->addElement($addPricing);

            $subForm->setElementDecorators($this->getElementDecorators());
            // $subForm->getElement('add')->removeDecorator('Label');
            $this->addSubForm($subForm, 'companyPricingCourse');
            // course pricing subform end
            $this->addElement('hidden', 'company_id', array('required' => false));
            $this->addElement('hidden', 'is_b2b_flat_pricing', array('required' => false, 'value' => 0));
            $this->addElement('hidden', 'company_pricing_plan', array('required' => false, 'value' => 0));
            $exludedCourseIdsListStr = implode(',', $this->_exludedCourseIds);
            $this->addElement('hidden', 'excluded_course_ids_list', array('required' => false, 'value' => $exludedCourseIdsListStr));
            $finalListOfCourses = new Zend_Form_Element_Textarea('finalSelectedCourses');
            $finalListOfCourses->setAttribs(array('required' => false, 'id' => 'final-selected-courses', 'readonly' => 'true', 'style' => 'display:none;'))
                    ->setRequired(false);
            $this->addElement($finalListOfCourses);
            //$this->addElement('hidden', 'excluded_master_ids_list', array('required' => false, 'value' => $exludedCourseIdsListStr));
            $this->addElement('submit', 'Save Pricing', array(
                'id'=>'saveCoursePricing',
                'ignore' => true,
                'label' => 'Save Pricing',
                'class' => 'btn btn-info'
            ));
        }
    }

    public function isValid($data) {
        $status = parent::isValid($data);
        if (!$status) {
            return false;
        }

        if (!empty($data['companyPricingCourse'])) {
            foreach ($data['companyPricingCourse'] as $key => $value) {

                if ($key == 'new') {
                    /**
                     * Product Type 
                     */
                    if (empty($value['product_type'])) {
                        $this->getSubForm('companyPricingCourse')
                                ->getSubForm($key)
                                ->getElement('product_type')
                                ->setErrors(array("Please Select Product Type."));
                        $status = false;
                    }
                    /**
                     * Pricing Level
                     */
                    if (empty($value['location_mode'])) {
                        $this->getSubForm('companyPricingCourse')
                                ->getSubForm($key)
                                ->getElement('location_mode')
                                ->setErrors(array("Please Select Pricing Level."));
                        $status = false;
                    }


                    /**
                     * Product Category
                     */
                    if (empty($value['product_category'])) {
                        $this->getSubForm('companyPricingCourse')
                                ->getSubForm($key)
                                ->getElement('product_category')
                                ->setErrors(array("Please Select Product Category."));
                        $status = false;
                    }

                    /**
                     * Final Product List
                     */
                    if (empty($data['finalSelectedCourses'])) {
                        $this->getSubForm('companyPricingCourse')
                                ->getSubForm($key)
                                ->getElement('final_product_list')
                                ->setErrors(array("Final Product List Is Empty"));
                        $status = false;
                    }


                    /**
                     * Flat Price / Flat Discount
                     */
                    if ($data['company_pricing_plan'] == self::PRICE_PLAN_FIXED && empty($value['flat_price'])) {
                        $this->getSubForm('companyPricingCourse')
                                ->getSubForm($key)
                                ->getElement('flat_price')
                                ->setErrors(array("Flatprice  is required."));
                        $status = false;
                    }
                }

                if ($key != '__template__') {
                    /**
                     * Access Days 
                     */
                    if (empty($value['access_day_id'])) {
                        $this->getSubForm('companyPricingCourse')
                                ->getSubForm($key)
                                ->getElement('access_day_id')
                                ->setErrors(array("Access Days can only be " . ENTERPRISE_ACCESS_DAYS));
                        $status = false;
                    }
                    //
                    if ($data['company_pricing_plan'] == self::PRICE_PLAN_FIXED) {
                        if (empty($value['flat_price'])) {
                            $this->getSubForm('companyPricingCourse')
                                    ->getSubForm($key)
                                    ->getElement('flat_price')
                                    ->setErrors(array("Flatprice is required."));
                            $status = false;
                        }
                        if (!empty($value['flat_price']) && $value['flat_price'] < 0) {
                            $this->getSubForm('companyPricingCourse')
                                    ->getSubForm($key)
                                    ->getElement('flat_price')
                                    ->setErrors(array("Flatprice cannot be negative."));
                            $status = false;
                        }
                        if (!empty($value['flat_discount']) && ($value['flat_discount'] < 1 || $value['flat_discount'] > 100)) {
                            $this->getSubForm('companyPricingCourse')
                                    ->getSubForm($key)
                                    ->getElement('flat_discount')
                                    ->setErrors(array("Discount should be between 1-100."));
                            $status = false;
                        }
                        if ((empty($value['flat_discount'])) && $value['flat_discount'] != '' && ($value['flat_discount'] == 0)) {
                            $this->getSubForm('companyPricingCourse')
                                    ->getSubForm($key)
                                    ->getElement('flat_price')
                                    ->setErrors(array("Discount should be between 1-100."));
                            $status = false;
                            }
                            
                    } else if ($data['company_pricing_plan'] == self::PRICE_PLAN_DISCOUNT) {
                       


                             if ((empty($value['flat_discount'])) && ($value['flat_discount'] == 0)) {
                            $this->getSubForm('companyPricingCourse')
                                    ->getSubForm($key)
                                    ->getElement('flat_price')
                                    ->setErrors(array("Discount should be between 1-100."));
                            $status = false;
                            }

                            



                            else if (!empty($value['flat_discount']) && (($value['flat_discount'] < 1) || ($value['flat_discount'] > 100))) {
                                $this->getSubForm('companyPricingCourse')
                                        ->getSubForm($key)
                                        ->getElement('flat_discount')
                                        ->setErrors(array("Discount should be between 1-100."));
                                $status = false;
                            }

                    }
                }
            }
        }
        return $status;
    }

    public function validateLRCourse($status, $value, $key, $learnerRArr, $name) {
        if ($value['learners_range_min'] < 0 || !filter_var($value['learners_range_min'], FILTER_VALIDATE_INT)) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_min')->setErrors(array("Learners range has to be integer."));
            return false;
        }
        if ($value['learners_range_max'] > 0 && !filter_var($value['learners_range_max'], FILTER_VALIDATE_INT)) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_max')->setErrors(array("Learners range has to be integer."));
            return false;
        }
        if ($value['learners_range_max'] != 0 && $value['learners_range_min'] >= $value['learners_range_max']) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_max')->setErrors(array("Learners range max has to be greater than min."));
            return false;
        }

        if (!empty($learnerRArr['data'][$value['training_id']][$value['learners_range_min']])) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_min')->setErrors(array("Learners range min cannot be same for a category."));
            return false;
        }
        if (!empty($learnerRArr['data'][$value['training_id']][$value['learners_range_max']])) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_max')->setErrors(array("Learners range max cannot be same as min for a category."));
            return false;
        }
        if (!empty($learnerRArr['maxVals'][$value['training_id']][$value['learners_range_min']])) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_min')->setErrors(array("Learners range min cannot be same as max for a category."));
            return false;
        }
        if (!empty($learnerRArr['maxVals'][$value['training_id']][$value['learners_range_max']])) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_max')->setErrors(array("Learners range max cannot be same for a category."));
            return false;
        }
        return $status;
    }

    public function validateLRCat($status, $value, $key, $learnerRArr, $name) {
        if ($value['learners_range_min'] < 0 || !filter_var($value['learners_range_min'], FILTER_VALIDATE_INT)) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_min')->setErrors(array("Learners range has to be integer."));
            return false;
        }
        if ($value['learners_range_max'] > 0 && !filter_var($value['learners_range_max'], FILTER_VALIDATE_INT)) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_max')->setErrors(array("Learners range has to be integer."));
            return false;
        }
        if ($value['learners_range_max'] != 0 && $value['learners_range_min'] >= $value['learners_range_max']) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_max')->setErrors(array("Learners range max has to be greater than min."));
            return false;
        }

        if (!empty($learnerRArr['data'][$value['learners_range_min']])) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_min')->setErrors(array("Learners range min cannot be same for a category."));
            return false;
        }
        if (!empty($learnerRArr['data'][$value['learners_range_max']])) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_max')->setErrors(array("Learners range max cannot be same as min for a category."));
            return false;
        }
        if (!empty($learnerRArr['maxVals'][$value['learners_range_min']])) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_min')->setErrors(array("Learners range min cannot be same as max for a category."));
            return false;
        }
        if (!empty($learnerRArr['maxVals'][$value['learners_range_max']])) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_max')->setErrors(array("Learners range max cannot be same for a category."));
            return false;
        }
        return $status;
    }

    protected function getSubFormDecoratorsMain($className, $id) {
        return array(
            'FormElements',
            array(
                'HtmlTag', array('tag' => 'ul')
            ),
            array(
                array('row' => 'HtmlTag'),
                array('tag' => 'li', 'class' => $className, 'id' => $id)
            )
        );
    }

    public function removeUneditableElements() {
        $this->removeElement('url');
        return false;
    }

    public function subFormValidations($data, $subForm, $status) {
        $count = 0;
        $accessDays = $data;
        end($accessDays);
        $keyA = key($accessDays);
        if ($subForm == 'accessDays' && count($data) > 2) {
            $this->getSubForm($subForm)->getSubForm($keyA)->getElement('accessDays')->setErrors(array("Only 2 bundle prices are allowed."));
            $status = false;
        }
        return $status;
    }

    public function _decorate() {
        
    }

    private function _getCompanyPriceRange() {
        $rangeData = array();
        $learnerRangeObj = new Model_LearnersRange();
        $larnerRangeData = $learnerRangeObj->getByLinkable($this->_companyId);
        if (!empty($larnerRangeData)) {
            $rangeData = array_combine(range(1, count($larnerRangeData)), $larnerRangeData);
        }
        return $rangeData;
    }

    private function _getExcludedCourseData() {
        $data = array();
        $b2bExcObj = new Model_B2bProductExclusions();
        $linkableTypes = array('course', 'bundle');
        $excCoursesData = $b2bExcObj->fetchAll(array('company_id =?' => $this->_companyId, 'linkable_type IN (?)' => $linkableTypes, 'status = ?' => 1));
        if (!empty($excCoursesData)) {
            $data = array_column($excCoursesData, 'linkable_id');
        }
        return $data;
    }

    private function _getPricingPlan() {
        $pricingPlanId = 0;
        $obj = new Model_ProductSectionData();
        $result = current($obj->fetchAll(array('id =?' => $this->_companyId), array('columns' => array('company_price_plans'))));
        if (!empty($result)) {
            $pricingPlanId = $result['company_price_plans'];
        }
        return $pricingPlanId;
    }

    private function _getProductType() {
        $productTypes=array();
        $obj = new Model_ProductSectionData();
        $result = $obj->fetchAll(array(
                            'company =?' => $this->_companyId,
                            'sectionType IN (?)' => array(BaseApp_Dao_TrainingTypes::B2B_TRAINING_TYPE, BaseApp_Dao_TrainingTypes::B2B_PRODUCT_TYPE)
                            ), array('columns' => array('name' => 'description', 'id' => 'name')));
        if (!empty($result)) {
            foreach($result as $row){
                $name=$row['name'];
                if($name==BaseApp_Dao_TrainingTypes::TYPE_ELEARNING_NAME){
                  $productTypes[BaseApp_Dao_TrainingTypes::TYPE_ELEARNING_NAME]="OSL";
                  
                }
                if($name==BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS_NAME){
                  $productTypes[BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS_NAME]="LVC";
                  
                }
                if($name==BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES){
                  $productTypes["mp"]="Master Program";
                  
                }
            }
        }
        return $productTypes;
    }
    
    
}
