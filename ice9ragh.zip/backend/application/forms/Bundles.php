<?php

class Form_Bundles extends BaseApp_SubForm {

    const MAX_TOOLS_ALLOWED = 6;
    const MAX_TOOL_CATEGORY_NAME_CHARCTERS = 50;
    const MIN_TOOL_CATEGORY_NAME_CHARCTERS = 5;
    const MAX_BUNDLE_ACCREDITOR_CHARACTER = 45;
    const MIN_BUNDLE_ACCREDITOR_CHARACTER = 5;
    private $_vData = array();

    public function __construct($bundleId= false) {
        $this->init($bundleId);
    }

    public $bundleStatus = array(
        'no_where' => 'No Where',
        'universal' => 'Universal',
        'b2b_only' => 'B2B Only',
        'private_b2b' => 'Private B2B',
        'b2c_only' => 'B2C Only',
        'complimentary_course' => 'Complimentary Course',
    );
    
    private $_fieldLabels = array(
        'primary_accreditor_logo'   =>  'Primary Logo ?(Max 4 allowed)',
        'secondary_accreditor_logo' =>  'Secondary Logo ?(Max 4 allowed)',
        'courseToolsFeature' => "Tools Covered",
    );

    public function init($bundleId) {
        $this->setName('Bundles');
        $this->setMethod('post');
        $this->setAttrib("class","form-width");

        $validatorsName = array(new Zend_Validate_StringLength(array('max' => 100)));
        $validatorsDescription = array(new Zend_Validate_StringLength(array('max' => 400)));
        $validatorsLogoAndDirectorName = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 60)));
        $validatorsLogoAndDirectorDesig = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 70)));
        $validatorsDirectorDesc = array(new Zend_Validate_StringLength(array('min' => 2)));
        $validatorsLogoDesc = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 200)));
        $validatorsNameDesc = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 90)));
        $validatorsKeyNameDesc = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 35)));
        $validatorsKeyNameText = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 50)));
        $validatorsPromoLen = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 100)));
        $validatorsCertificateHeader = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 55)));
        $validatorsCertificateSubHeader = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 70)));
        $validatorsCertificateSubText = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 400)));
        $validatorsCourseTool = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 70)));
        $imageData = array();
        if (!empty($bundleId)) {          
            $imageModel = new Model_Images();
            $imageData = $imageModel->getInclusionImages($bundleId,'bundle');
        }
        $this->addElement('radio', 'master_type', array(
            'required' => true,
            'label' => 'Type*',
            'multiOptions'=>array(
                BaseApp_Dao_Bundles::MASTER_TYPE_CLASSIC => 'Classic Master',
                BaseApp_Dao_Bundles::MASTER_TYPE_UNIVERSITY => 'University Master',
                BaseApp_Dao_Bundles::MASTER_TYPE_COHORT => 'Cohort Master',
            ),
            'separator' => '',
            'value' => 'type'
        ));

//        $this->addElement('checkbox', 'isUniversityMaster', array(
//            'label' => 'Is University Master'
//        ));
        
        
        $this->addElement('text', 'name', array(
            'label' => 'Bundle Name*',
            'required' => true,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'autocomplete' => 'off'
        ));
        $this->addElement('hidden', 'currentBundleName', array(
           'required' => false,
        ));
        $this->addElement('text', 'display_name', array(
            'label' => 'Display Name*',
            'required' => true,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'autocomplete' => 'off'
        ));

        $obj = new Model_Labels();

        $this->addElement('hidden', 'bundle_tmp_id', array(
            'required' => false,
            'value' => ''
        ));

        $this->addElement('select', 'primary_label_id', array(
            'label' => 'Primary Category*',
            'required' => true,
            'multioptions' => array('0' => '--Select--') + $obj->getLabelsToshow(),
            'class'=>'primary_label_id'
        ));
        $this->addElement('select', 'label_id', array(
            'label' => 'Secondary Category',
            'required' => false,
            'multiple' => true,
            'class' => 'courseListAll ',
            'registerInArrayValidator' => false,
            'multioptions' => $obj->getLabelsToshow()
        ));

        $course = new Model_Courses();
        $this->addElement('select', 'primary_course_id', array(
            'required' => true,
            'label' => 'Primary Course*',
            'multioptions' => array('0' => '--Select--') + $course->fetchForSelect(array('is_dummy = ?' => 0, 'is_free = ?' => 0))
        ));
        $this->addElement('text', 'url', array(
            'label' => 'Bundle URL*',
            'required' => true,
            'filters' => array('StringTrim'),
            'class' => 'longtext'
        ));
        $universityObj = new Model_University();
        $universityCond = array('page_type = ?' => BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_UNIVERSITY_MASTER);
        $this->addElement('select', 'university', array(
            'label' => 'University*',
            'required' => true,
            'multioptions' => array('0' => '--Select--') + $universityObj->fetchForSelect($universityCond),
        ));
        //********************** Bundle Setting Section Started *******************/

        $this->addElement('select', 'bundle_available_for', array(
            'label' => 'Bundle Available For*',
            'required' => true,
            'multioptions' => $this->bundleStatus,
        ));
        $this->addElement('hidden', 'old_bundle_available_for', array('required' => false));

        $this->addElement('text', 'enterprise_list_bundle', array(
            'label' => 'Select One or More Enterprise(s)*',
            'filter' => array('StringTrim'),
        ));
        $this->addElement('checkbox', 'is_part_payment', array(
            'label' => 'Available for part-payment',
            'checked' => true
        ));
        $this->addElement('checkbox', 'isIntegratedProg', array(
            'label' => 'Is Integrated Program'
        ));
        $this->addElement('checkbox', 'hideFromSearch', array(
            'label' => 'Hide from search and list pages'
        ));

        $this->addElement('checkbox', 'partialView', array(
            'id' => 'partialView',
            'label' => 'Is Non Master Program View'
        ));

        $this->addElement('checkbox', 'job_assist_for_ind', array(
            'label' => 'Job Assist For India ?'
        ));

        $settingGroup = array('bundle_available_for','enterprise_list_bundle','is_part_payment','isIntegratedProg','hideFromSearch','partialView','job_assist_for_ind');
        $this->addDisplayGroup($settingGroup, 'setting_group');
        $this->getDisplayGroup('setting_group')
                ->setLegend('Bundle Settings')
                ->clearDecorators()
                ->addDecorator('FormElements')
                ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper'));

        //*****************Bundle Settings Section End *************************/



        //*****************Bundle Details Section Started *********************/



        $this->addElement('textarea', 'description', array(
            'label' => 'Bundle Introduction*',
            'required' => true,
            'filter' => array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class' => 'description'
        ));

        
        $this->addElement('textarea', 'program_overview', array(
            'label' => 'Program Overview Intro*',
            'filter' => array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class' => 'description',
            'value' => $this->getOverviewvalue()
        ));
    


        $this->addElement('textarea', 'program_details_intro', array(
            'label' => 'Program Details Intro*',
            'filter' => array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'value' => $this->getDetailsvalue(),
            'class' => 'description',
        ));



        $this->addElement('text', 'agendaUrl', array(
            'label' => 'Bundle Agenda',
            'required' => false,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'value' => ''
        ));


        $this->addElement('text', 'searchTags', array(
            'label' => 'Search tags (comma separated)*',
            'required' => true,
            'filters' => array('StringTrim'),
            'class' => 'longtext'
        ));

        $obj = new Model_Vendors();
        $this->addElement('select', 'vendor_id', array(
            'label' => 'Vendor',
            'required' => false,
            'multioptions' => array('0' => '--Select--') + $obj->fetchForSelect()
        ));


        $obj = new Model_ProductSectionData();
        $obj->setDisplayField('name');
        $this->addElement('hidden', 'course_advisor');
        $this->addElement('select', 'course_advisor_temp', array(
            'label' => 'Program Advisors',
            'required' => false,
            'size' => 12,
            'class' => 'multiple',
            'registerInArrayValidator' => false,
            'multioptions' => array('0' => '--Select--') + $obj->fetchForSelect(array('sectionType = ?' => "directors"))
        ));

        $this->addElement('hidden', 'course_advisor_err', array(
            'required' => false,
            'value' => ''
        ));


        $this->addElement('hidden', 'projectTitleSectionIdOverview', array(
            'required' => false,
            'value' => ''
        ));

        $this->addElement('hidden', 'projectTitleSectionIdDetails', array(
            'required' => false,
            'value' => ''
        ));



        $bundledetailGroup = array('description','program_overview','program_details_intro','agendaUrl','searchTags','vendor_id','course_advisor_temp','course_advisor_err');
        $this->addDisplayGroup($bundledetailGroup, 'bundle_detail_Group');
        $this->getDisplayGroup('bundle_detail_Group')
                ->setLegend('Bundle Details')
                ->clearDecorators()
                ->addDecorator('FormElements')
                ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper'));


        //*****************Bundle Details Section End ************************/
        
        $this->addElement('hidden', 'categoryLabelName', array(
           'required' => false,
           'value' => ''
        ));
         $this->addElement('hidden', 'oldCategoryLabelID', array(
           'required' => false,
           'value' => ''
        ));
       
        // Learning Path
        $this->setLearningPath();


        $this->addElement('checkbox', 'can_be_free', array(
            'label' => 'OSLs can be given free?'
        ));

        $this->addElement('checkbox', 'is_part_payment', array(
            'label' => 'Available for part-payment',
            'checked' => true
        ));
        
       
        
        $this->addElement('button', 'label_inward', array(
            'label' => 'Invert Countries',
            'ignore' => true,
            'class' => 'btn btn-warning'
        ));

        // $obj = new Model_Vendors();
        // $this->addElement('select', 'vendor_id', array(
        //     'label' => 'Vendor',
        //     'required' => false,
        //     'multioptions' => array('0' => '--Select--') + $obj->fetchForSelect()
        // ));
        // **************bundle logo section started*****************//
        $this->addElement('hidden', 'banner_image_old', array(
            'value' => @$imageData['banner_image']['imagePath'],
        ));
        $this->addElement($this->createElement('file','banner_image',array(
            'label'=> 'Banner Image*',
            // 'required'=>true,
            'destination'=>sys_get_temp_dir(),            
            'validators'=>array('Extension' => array('jpg'),
            //     array('ImageSize',false, array('maxwidth'=>730,'maxheight'=>516)),
            //     array('Size',false, array('useByteString'=> true, 'max' => '382kb'))
            )
        )));  
        if(isset($imageData['banner_image'])){
            
            $this->addElement('text', 'banner_image_value', array(
                'label' => 'Banner Image Url',                
                'value' => @$imageData['banner_image']['imagePath'],
                'helper' => 'formNote'                
            ));
        }
        $this->addElement('hidden', 'tumbnail_image_old', array(
            'value' => @$imageData['tumbnail_image']['imagePath'],
        ));
        $this->addElement($this->createElement('file','tumbnail_image',array(
            'label'=> 'Thumbnail Image (svgz)*',
            // 'required'=>true,
            'destination'=>sys_get_temp_dir(),            
            'validators'=>array('Extension' => array('svgz'),
                
            )
        ))); 
        if(isset($imageData['tumbnail_image'])){
            $this->addElement('text', 'tumbnail_image_value', array(
                'label' => 'Thumbnail Image Url',                
                'value' => @$imageData['tumbnail_image']['imagePath'],
                'helper' => 'formNote'                
            ));
        }
        $this->addElement('hidden', 'home_page_tumbnail_image_old', array(
            'value' => @$imageData['home_page_tumbnail_image']['imagePath'],
        ));
        $this->addElement($this->createElement('file','home_page_tumbnail_image',array(
            'label'=> 'Home Page Thumbnail Image (404 x228)(jpg)*',
            // 'required'=>true,
            'destination'=>sys_get_temp_dir(),            
            'validators'=>array('Extension' => array('jpg'),
                array('ImageSize',false, array('maxwidth'=>404,'maxheight'=>228)),
                array('Size',false, array('useByteString'=> true, 'max' => '382kb'))
            )
        ))); 
       
        if(isset($imageData['home_page_tumbnail_image'])){
            $this->addElement('text', 'home_page_tumbnail_image_value', array(
                'label' => 'Home Page Thumbnail Image Url',                
                'value' => $imageData['home_page_tumbnail_image']['imagePath'],
                'helper' => 'formNote'                
            ));
        }
        $accreditorObj = new Model_Accreditors(); 
       
        $this->addElement('text', 'primary_accreditor_label', array(
            'label' => 'Primary Accreditor',
            'required' => false,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'autocomplete' => 'off',
            'maxlength'=>self::MAX_BUNDLE_ACCREDITOR_CHARACTER
        ));
        
        $accreditorCond = array('isMasterCoursePage'=>1);
        $this->addElement('select', 'primary_accreditor_logo', array(
            'label' => $this->_fieldLabels['primary_accreditor_logo'],
            'required' => false,
            'class' => 'multiple accreditor_logo skipPreviousClick',
            'multiple' => true,
            'registerInArrayValidator' => false,
            'multioptions' => $accreditorObj->fetchForSelect($accreditorCond)
        ));
        
        $this->addElement('text', 'secondary_accreditor_label', array(
            'label' => 'Secondary Accreditor',
            'required' => false,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'autocomplete' => 'off',
            'maxlength'=>self::MAX_BUNDLE_ACCREDITOR_CHARACTER
        ));
        $this->addElement('select', 'secondary_accreditor_logo', array(
            'label' => $this->_fieldLabels['secondary_accreditor_logo'],
            'required' => false,
            'class' => 'multiple accreditor_logo skipPreviousClick',
            'multiple' => true,
            'registerInArrayValidator' => false,
            'multioptions' => $accreditorObj->fetchForSelect($accreditorCond)
        ));
        $toolsList = $this->getAllTools();
        $selectedList = array();
        if(!empty($bundleId)){
            $selectedList = array_keys($this->getSelectedTools($bundleId));
        }
        $selectedListString = implode(',', array_intersect($selectedList, $toolsList));
        $this->addElement('select', 'courseToolsFeature', array(
            'label' => $this->_fieldLabels['courseToolsFeature'],
            'required' => false,
            'multioptions' => $toolsList,
            'size' => 12,
            'class' => 'multiple',
            'registerInArrayValidator' => false,
            'value' => '',
        ));
        
        $this->addElement('button', 'label_inward', array(
            'label' => 'Invert Countries',
            'ignore' => true,
            'class' => 'btn btn-warning'
        ));
        $this->addElement('hidden', 'courseToolsFeatureSortedList', array('required' => false, 'value' => implode(',', $selectedList)));
        
        $settingGroup1 = array('banner_image','banner_image_value','tumbnail_image','tumbnail_image_value','home_page_tumbnail_image','home_page_tumbnail_image_value','primary_accreditor_label','primary_accreditor_logo','secondary_accreditor_label','secondary_accreditor_logo','courseToolsFeature');
        $this->addDisplayGroup($settingGroup1, 'setting_group1');
        $this->getDisplayGroup('setting_group1')
                ->setLegend('Logos')
                ->clearDecorators()
                ->addDecorator('FormElements')
                ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper'));


        // $this->addElement('textarea', 'description', array(
        //     'label' => 'Top Description*',
        //     'required' => true,
        //     'filter' => array('StringTrim'),
        //     'rows' => 5,
        //     'cols' => 60,
        //     'class' => 'description'
        // ));
        

        // $this->addElement('text','sale_point_first',array(
        //     'label'=>'Sale point1',
        //     'required'=>false,
        //     'filters'=>array('StringTrim'),
        //     'class'=>'longtext',
        //     'autocomplete' => 'off'
        // ));
        // $this->addElement('text','sale_point_second',array(
        //     'label'=>'Sale point2',
        //     'required'=>false,
        //     'filters'=>array('StringTrim'),
        //     'class'=>'longtext',
        //     'autocomplete' => 'off'
        // ));
        // $this->addElement('text','sale_point_third',array(
        //     'label'=>'Sale point3',
        //     'required'=>false,
        //     'filters'=>array('StringTrim'),
        //     'class'=>'longtext',
        //     'autocomplete' => 'off'
        // ));
        // $this->addElement('text','sale_point_fourth',array(
        //     'label'=>'Sale point4',
        //     'required'=>false,
        //     'filters'=>array('StringTrim'),
        //     'class'=>'longtext',
        //     'autocomplete' => 'off'
        // ));

        // $this->addElement('text', 'url', array(
        //     'label' => 'URL*',
        //     'required' => true,
        //     'filters' => array('StringTrim'),
        //     'class' => 'longtext'
        // ));

        // $this->addElement('button', 'course_inward', array(
        //     'label' => 'Invert Courses',
        //     'ignore' => true,
        //     'class' => 'btn btn-warning'
        // ));

      

       $this->addElement('hidden', 'payment_type_id', array(
            'required' => true,
            'multiOptions' => array(BaseApp_Dao_PaymentType::ONETIME_PAYMENT_TYPE_ID => 'Bundle', BaseApp_Dao_PaymentType::SUBSCRIPTION_PAYMENT_TYPE_ID => 'Subscription'),
            'separator' => '',
            'value' => 'bundle'
        ));
        $this->getElement('payment_type_id')->setValue(BaseApp_Dao_PaymentType::ONETIME_PAYMENT_TYPE_ID);
        

        $this->addElement('text', 'subscription_logo', array(
            'label' => 'Subscription logo for home page*',
            'required' => false,
            'filters' => array('StringTrim'),
            'class' => 'longtext'
        ));

        $session = new Zend_Session_Namespace('form');

        /*
         * Start: Sub form for subscription price
         */

        $subForm = new Zend_Form_SubForm();
        $subForm->setName('countrySubscriptionPrice');
        
        foreach ($session->countrySubscriptionPrice as $product) {
            $keyCurrency = isset($session->countrySubscriptionPriceData[$product]['currency_id']) ? $session->countrySubscriptionPriceData[$product]['currency_id'] : '';
            $keyCountry = isset($session->countrySubscriptionPriceData[$product]['country_id']) ? $session->countrySubscriptionPriceData[$product]['country_id'] : '';
            $keyCluster = isset($session->countrySubscriptionPriceData[$product]['cluster_id']) ? $session->countrySubscriptionPriceData[$product]['cluster_id'] : '';
            $keyPriceMonthly = isset($session->countrySubscriptionPriceData[$product]['priceMonthly']) ? $session->countrySubscriptionPriceData[$product]['priceMonthly'] : '';
            $keyPriceYearly = isset($session->countrySubscriptionPriceData[$product]['priceYearly']) ? $session->countrySubscriptionPriceData[$product]['priceYearly'] : '';

            $keyLocationMode = '';
            if ($keyCountry) {
                $keyLocationMode = 2;
            } else if ($keyCluster) {
                $keyLocationMode = 1;
            }
            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);

            if ($product === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
            }

            $currency = new Zend_Form_Element_Select('currency_id');
            $currencyModel = new Model_Currency();
            $currency->setOptions(array('multioptions' => $currencyModel->getCurrencyToDisplay()))->setValue($keyCurrency)->setAttrib('class', 'currency')->setLabel('Currency');

            $locationMode = new Zend_Form_Element_Select('location_mode');
            $locationMode->setOptions(array('multioptions' => array(0 => '--Select--', 1 => 'By Cluster', 2 => 'By Country')))->setValue($keyLocationMode)->setAttrib('class', 'location')->setLabel('Pricing Level');

            $country = new Zend_Form_Element_Select('country_id');
            $countryList = array();
            if ($keyCurrency && $keyLocationMode == 2) {
                $countryModel = new Model_Country();
                $countryList = $countryModel->fetchForSelect(array('currency_id=?' => $keyCurrency));
            }
            $country->setOptions(array('multioptions' => $countryList, 'registerInArrayValidator' => false))->setValue($keyCountry)->setAttrib('class', 'country')->setLabel('Country');

            $cluster = new Zend_Form_Element_Select('cluster_id');
            $clusterList = array();
            if ($keyCurrency && $keyLocationMode == 1) {
                $obj = new Model_Clusters();
                $clusterList = $obj->fetchForSelect(array('currency_id=?' => $keyCurrency));
            }
            $cluster->setOptions(array('multioptions' => $clusterList, 'registerInArrayValidator' => false))->setValue($keyCluster)->setAttrib('class', 'cluster')->setLabel('Cluster');

            $priceMonthly = new Zend_Form_Element_Text('priceMonthly');
            $priceMonthly->addFilter('stringTrim')->setValue($keyPriceMonthly)->setAttrib('class', 'price')->setLabel('Monthly')->setAttrib('placeholder', 'price');

            $priceYearly = new Zend_Form_Element_Text('priceYearly');
            $priceYearly->addFilter('stringTrim')->setValue($keyPriceYearly)->setAttrib('class', 'price')->setLabel('Yearly')->setAttrib('placeholder', 'price');

            // need to varify  with master
            

            // $subscriptionId = new Zend_Form_Element_Hidden('subscriptionId');
            // $subscriptionId->addFilter('stringTrim')->setValue($keySubscriptionId);

            if ($product !== '__template__') {
                $country->setRequired(false);
                $cluster->setRequired(false);
                $locationMode->setRequired(false);
                $currency->setRequired(false);
                $priceMonthly->setRequired(false);
                $priceYearly->setRequired(false);
            }

            $removeCountrySubscriptionPrice = new Zend_Form_Element_Button('remove');
            $removeCountrySubscriptionPrice->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');

            $elements = array($currency, $locationMode, $cluster, $country, $priceMonthly, $priceYearly);
            if ($product !== 'new') {
                $elements[] = $removeCountrySubscriptionPrice;
            }

            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());

            if ($rowForm->getElement('remove')) {
                $rowForm->getElement('remove')->removeDecorator('Label');
            }

            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        }

        $subForm->setDecorators($this->getSubFormDecoratorsMain('countryPrice', 'countrySubscriptionPrice'));

        $addPrice = new Zend_Form_Element_Button('add');
        $addPrice->setLabel('Add More')->setAttrib('class', 'btn btn-warning add');
        $subForm->addElement($addPrice);

        $subForm->setElementDecorators($this->getElementDecorators());
        $subForm->getElement('add')->removeDecorator('Label');
        $this->addSubForm($subForm, 'countrySubscriptionPrice');

        /*
         * End: Sub form for subscription price
         */

        
        
        $this->addElement('hidden', 'oldhideFromSearch', array(
           'required' => false,
        ));

        // $this->addElement('hidden', 'partialView', array(
        //     'id' => 'partialView'
        // ));



        /**
         * certificate Header Text Start
         */
        $this->addElement('textarea', 'certificate_header_text', array(
            'label' => 'Section heading',
            'required' => false,
            'rows' => 5,
            'cols' => 60,
            'filters' => array('StringTrim'),
            'class' => 'keyName',
            'validators' => $validatorsCertificateHeader
        ));

        $this->addElement('text', 'certificate_image', array(
            'label' => 'Certificate Image Link',
            'required' => false,
            'filters' => array('StringTrim'),
            'class' => 'keyName',
            'validators' => array(
                new BaseApp_Validate_Image('bundles', 'certificate_logo')
            )
        ));
        
        $this->addElement('text', 'certificate_alt_text', array(
            'label' => 'Certificate Alt Text',
            'required' => false,
            'filters' => array('StringTrim'),
            'class' => 'keyName',
        ));

        $certificateSectionGroup = array('certificate_header_text', 'certificate_image', 'certificate_alt_text', 'certificateFeature');
        $this->addDisplayGroup($certificateSectionGroup, 'certificate_group');
        $this->getDisplayGroup('certificate_group')
            ->setLegend('Bundle Certificate')
            ->clearDecorators()
            ->addDecorator('FormElements')
            ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper'));

        /**
         * Start: sub form for faqs
         *
         */
        $subForm = new Zend_Form_SubForm();
        $subForm->setName('certificateFeature');
        foreach ($session->certificateFeature as $product) {
            $keyQuestion = isset($session->certificateFeatureData[$product]['header_text']) ? $session->certificateFeatureData[$product]['header_text'] : '';
            $keyAnswer = isset($session->certificateFeatureData[$product]['short_description']) ? $session->certificateFeatureData[$product]['short_description'] : '';

            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);

            if ($product === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
            }

            $question = new Zend_Form_Element_Text('header_text');
            $question->addFilter('stringTrim')->setValue($keyQuestion)->setAttrib('class', 'question')->setAttrib('placeholder', "Add certificate's merits. Example - Earn your certificate")->setLabel('Heading Text')->addValidators($validatorsCertificateSubHeader);

            $answer = new Zend_Form_Element_Text('short_description');
            $answer->addFilter('stringTrim')->setValue($keyAnswer)->setAttrib('class', 'faqDescription')->setAttrib('placeholder', 'Details describing the header text field')->setLabel('Point Text')->addValidators($validatorsCertificateSubText);

            $removeSetsNumber = new Zend_Form_Element_Button('remove');
            $removeSetsNumber->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');

            if ($product !== 'new') {
                $elements = array($question, $answer, $removeSetsNumber);
            } else {
                $elements = array($question, $answer);
            }

            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());

            if ($rowForm->getElement('remove')) {
                $rowForm->getElement('remove')->removeDecorator('Label');
            }

            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        }

        $subForm->setDecorators($this->getSubFormDecoratorsMain('examFaq', 'certificateFeature'));

        $addPrice = new Zend_Form_Element_Button('add');
        $addPrice->setLabel('Add')->setAttrib('class', 'btn btn-warning add');
        $subForm->addElement($addPrice);

        $subForm->setElementDecorators($this->getElementDecorators());
        $subForm->getElement('add')->removeDecorator('Label');
        $this->addSubForm($subForm, 'certificateFeature');
        /**
         * End: sub form for faqs
         *
         */

        $this->videoSection();
       


        /**
         * End: sub form for faqs
         *
         */
       

        $obj = new Model_ProductSectionData();
        $obj->setDisplayField('name');
        $this->addElement('select', 'trusted_by', array(
            'label' => 'Trusted By Section',
            'required' => false,
            'multiple' => true,
            'class' => 'multiple',
            'registerInArrayValidator' => false,
            'multioptions' => array('0' => '--Select--') + $obj->fetchForSelect(array('sectionType = ?' => "trustedByLogos"))
        ));
        $this->addElement('hidden', 'trusted_by_err', array(
            'required' => false,
            'value' => ''
        ));
        
        $obj->setDisplayField('name');
        $this->addElement('select', 'alumni', array(
            'label' => 'Alumni Section(Max 4 allowed)',
            'required' => false,
            'multiple' => true,
            'class' => 'multiple',
            'registerInArrayValidator' => false,
            'multioptions' => array('0' => '--Select--') + $obj->fetchForSelect(array('sectionType = ?' => "alumni"))
        ));
        $this->addElement('hidden', 'alumni_err', array(
            'required' => false,
            'value' => ''
        ));
        // Sub Form For Course Tools
        $this->addElement('hidden', 'bundle_tool_err', array(
            'required' => false,
            'value' => ''
        ));
        // $subForm = new Zend_Form_SubForm();
        // $subForm->setName('courseToolsFeature');
        // if (!empty($session->courseToolsFeature)) {
        //     foreach ($session->courseToolsFeature as $product) {
        //         prd($session->courseToolsFeature);
        //         $keyCourseCategory = isset($session->courseToolsFeatureData[$product]['course_category']) ? $session->courseToolsFeatureData[$product]['course_category'] : '';
        //         $keyToolId = isset($session->courseToolsFeatureData[$product]['tool_id']) ? $session->courseToolsFeatureData[$product]['tool_id'] : '';
        //         $rowForm = new Zend_Form_SubForm();
        //         $rowForm->setName($product);
        //         if ($product === '__template__') {
        //             $rowForm->setAttrib('style', 'display: none;');
        //         }
        //         $courseCategory = new Zend_Form_Element_Text('course_category');
        //         $courseCategory->addFilter('stringTrim')->setValue($keyCourseCategory)->setAttrib('class', 'courseCategory')->setAttrib('maxlength', self::MAX_TOOL_CATEGORY_NAME_CHARCTERS)->setAttrib('placeholder', 'Full Length Category Name')->setLabel('Bundle Category')->addValidators($validatorsCourseTool, false, array(0, self::MAX_TOOL_CATEGORY_NAME_CHARCTERS));
        //         $bundleTools = new Zend_Form_Element_Select('tool_id');
        //         $toolList = $this->getAllBundleTools();
        //         $bundleTools->setOptions(array('select' => true, 'multiple' => true, 'required' => false, 'registerInArrayValidator' => false, 'multioptions' => array('0' => '--Select--') + $toolList))->setValue($keyToolId)->setAttrib('class', 'courseTool multiple')->setLabel('Tools');
        //         $removeSetsNumber = new Zend_Form_Element_Button('remove');
        //         $removeSetsNumber->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');
        //         if ($product !== 'new') {
        //             $elements = array($courseCategory, $bundleTools, $removeSetsNumber);
        //         } else {
        //             $elements = array($courseCategory, $bundleTools);
        //         }
        //         $rowForm->addElements($elements);
        //         $rowForm->setElementDecorators($this->getElementDecorators());
        //         if ($rowForm->getElement('remove')) {
        //             $rowForm->getElement('remove')->removeDecorator('Label');
        //         }
        //         $rowForm->setDecorators($this->getSubFormDecorators());
        //         $subForm->addSubForm($rowForm, $product);
        //     }
        // }

        // $subForm->setDecorators($this->getSubFormDecoratorsMain('courseTool', 'courseToolsFeature'));
        // $bundleToolsBtn = new Zend_Form_Element_Button('add');
        // $bundleToolsBtn->setLabel('Add')->setAttrib('class', 'btn btn-warning add');
        // $subForm->addElement($bundleToolsBtn);
        // $subForm->setElementDecorators($this->getElementDecorators());
        // $subForm->getElement('add')->removeDecorator('Label');
        // $this->addSubForm($subForm, 'courseToolsFeature');

        // End Of Sub-Form
        $this->postSetup();
        $this->getElement('description')->setDescription('Character Limit: 400 (including spaces)')
        ->setDecorators(array(
            'ViewHelper',
            array('Description', array('escape' => false, 'tag' => 'p','class' => 'description-note')),
            array('HtmlTag', array('tag' => 'div','class' => 'element')),
            array('Label', array('tag' => 'div')),
            array('Errors'),
            array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
        ));

        $this->getElement('banner_image')->setDecorators(
            array(
                'File',
                array('Errors', array('class'=>'errors error-file')),
                array(
                    array('data' => 'HtmlTag'),
                    array('tag' =>'div', 'class'=> 'element')
                ),
                array(
                    'Label',
                    array('tag' => 'div')
                ),
                array(
                    array('row' => 'HtmlTag'),
                    array('tag' => 'li')
                )
            )
        );
        $this->getElement('tumbnail_image')->setDecorators(
            array(
                'File',
                array('Errors', array('class'=>'errors error-file')),
                array(
                    array('data' => 'HtmlTag'),
                    array('tag' =>'div', 'class'=> 'element')
                ),
                array(
                    'Label',
                    array('tag' => 'div')
                ),
                array(
                    array('row' => 'HtmlTag'),
                    array('tag' => 'li')
                )
            )
        );
        $this->getElement('home_page_tumbnail_image')->setDecorators(
            array(
                'File',
                array('Errors', array('class'=>'errors error-file')),
                array(
                    array('data' => 'HtmlTag'),
                    array('tag' =>'div', 'class'=> 'element')
                ),
                array(
                    'Label',
                    array('tag' => 'div')
                ),
                array(
                    array('row' => 'HtmlTag'),
                    array('tag' => 'li')
                )
            )
        );
        $this->getElement('name')->addValidators($validatorsName);
        $this->getElement('description')->addValidators($validatorsDescription);

       
    }
    private function getSelectedTools($bundleId) {
        $sectionDataModel = new Model_ProductSectionData();
        $res = array();
        $selectedList = $sectionDataModel->getDataByType($bundleId, $sectionDataModel::LINKABLE_TYPE_BUNDLE, $sectionDataModel::SECTION_TYPE_COURSE_TOOLS, true, 'sm.id asc');
        if(!empty($selectedList)) {
            foreach($selectedList as $temp) {
                $res[$temp['section_id']] = $temp['name'];
            }
        }
        return $res;
    }
    private function videoSection()
    {
        $this->addElement('text', 'videoLink', array(
            'label' => 'Embeded YouTube Video',
            'placeholder' => " Please Enter A Embeded You Tube video Link",
            'required' => false,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'validators' => array(
                new BaseApp_Validate_Url()
            )
        ));
        $this->addElement('text', 'dateCreated', array(
            'label' => 'Uploaded Date',
            'placeholder' => 'YYYY-MM-DD',
            'required' => false,
            'filters' => array('StringTrim'),
            'attribs' => array('readonly' => 'readonly'),
            'class' => 'longtext'
        ));
        $this->addElement('text', 'duration', array(
            'label' => 'Duration',
            'placeholder' => "HH:MM:SS",
            'required' => false,
            'filters' => array('StringTrim'),
            'attribs' => array('readonly' => 'readonly'),
            'class' => 'longtext'
        ));

        $this->addElement('text', 'videoThumbnail', array(
            'label' => 'Thumbnail Image',
            'placeholder' => " Please Enter video Thumbnail Image",
            'required' => false,
            'filters' => array('StringTrim'),
            'class' => 'longtext'
        ));

        $this->addElement('textarea', 'videoDescription', array(
            'label' => 'Video Description',
            'filter' => array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'attribs' => array('readonly' => 'readonly'),
            'class' => 'description'
        ));
    }

    private function changeFromatToAppendId($data) {
        $result = array();
        foreach($data as $id => $item) {
            $result[$id] = "$item - $id";
        }
        return $result;
    }

    private function setLearningPath() {
        $course = new Model_Courses();
        $courseList = $this->changeFromatToAppendId($course->getAllCoursesByTrainingType(array(BaseApp_Dao_TrainingTypes::TYPE_ELEARNING, BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS)));
        $this->addElement('select', 'course_id_tmp', array(
            'required' => false,
            'size' => 12,
            'label' => 'Courses*',
            'class' => 'courseListAll selectAll SearchBoxPlugin',
            'registerInArrayValidator' => false,
            'multioptions' => $courseList,
        ));

        $this->addElement('hidden', 'course_id', array(
            'required' => false,
            'value' => ''
        ));
        $alternateCourses = array("Blank Element") + $courseList;
        $this->addElement('select', 'course_or_tmp', array(
            'required' => false,
            'size' => 12,
            'label' => '',
            'class' => 'courseListAll selectAll hide',
            'registerInArrayValidator' => false,
            'multioptions' => $alternateCourses
        ));

        $this->addElement('hidden', 'course_or_id', array(
            'required' => false
        ));

        $this->addElement('select', 'bundle_electives_temp', array(
            'required' => false,
            'size' => 4,
            'label' => 'Electives',
            'class' => 'courseListAll SearchBoxPlugin',
            'multioptions' => $courseList,
        ));

        $this->addElement('hidden', 'bundle_electives', array(
            'required' => false,
            'value' => ''
        ));
        $this->addElement('hidden', 'bundle_electives_keys', array(
            'required' => false,
            'value' => ''
        ));
        $this->addElement('hidden', 'bundle_elec_md5', array(
            'required' => false,
            'value' => ''
        ));
        $learningPathGroup = array('course_id_tmp', 'bundle_electives_temp');
        $this->addDisplayGroup($learningPathGroup, 'learning_path_group');
        $this->getDisplayGroup('learning_path_group')
            ->setLegend('Learning Path')
            ->clearDecorators()
            ->addDecorator('FormElements')
            ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper'));
    }

    protected function getSubFormDecoratorsMain($className, $id) {
        return array(
            'FormElements',
            array(
                'HtmlTag', array('tag' => 'ul')
            ),
            array(
                array('row' => 'HtmlTag'),
                array('tag' => 'li', 'class' => $className, 'id' => $id)
            )
        );
    }

    public function removeUneditableElements() {
        $this->removeElement('url');
        return false;
    }

    public function removeVideoElements(){
        $this->removeElement('dateCreated');
        $this->removeElement('videoDescription');
        $this->removeElement('duration');
   }

    public function isValid($data) {
        if (empty($data['tumbnail_image_old'])){
            $this->getElement('tumbnail_image')->setRequired(true);
        }
        if (empty($data['banner_image_old'])){
            $this->getElement('banner_image')->setRequired(true);
        }
        if ($data['master_type'] == BaseApp_Dao_Bundles::MASTER_TYPE_UNIVERSITY && empty($data['home_page_tumbnail_image_old'])){
            $this->getElement('home_page_tumbnail_image')->setRequired(true);
        }
        $status = parent::isValid($data);
        if (!empty($data['url'])) {
            $data['url'] = trim($data['url']);
            $checkSlash = substr($data['url'], 0, 1);
            if ($checkSlash != '/') {
                $data['url'] = trim('/' . $data['url']);
            }
            $objSeo = new Model_Seo();
            if (false === $objSeo->validateUrl($data['url'])) {
                $this->getElement('url')->setErrors(array("'{$data['url']}' is not a valid Bundle url"));
                $status = false;
            }
        }
        if (isset($data['master_type'])) {


            if (!empty($data['banner_image']['tmp_name'])) {
                $imageSize = getimagesize($data['banner_image']['tmp_name']);
                $width = $imageSize[0];
                $height = $imageSize[1];
                if ($data['banner_image']['name'] != '' && !empty($data['banner_image']['name']) ){
                    $fileName = $data['banner_image']['name'];
                    $fileName = explode(".", $fileName)[0];            
                    if(!@preg_match('/^[A-Za-z0-9_-]+$/', $fileName)){
                        $this->getElement('banner_image')->setErrors(array("File name can only be Alpha numerics with _ and - "));
                        $status = false;
                    }   
                }    
                if ($data['master_type'] == BaseApp_Dao_Bundles::MASTER_TYPE_CLASSIC) {
                    if ($width > 1600 || $height > 513) {
                        $this->getElement('banner_image')->setErrors(array("Maximum allowed dimension for image  is 1600 x 513"));
                        $status = false;
                    }
                }
                if ($data['master_type'] == BaseApp_Dao_Bundles::MASTER_TYPE_COHORT) {
                    if ($width > 1600 || $height > 357) {
                        $this->getElement('banner_image')->setErrors(array("Maximum allowed dimension for image  is 1600 x 357"));
                        $status = false;
                    }
                }
                if ($data['master_type'] == BaseApp_Dao_Bundles::MASTER_TYPE_UNIVERSITY) {
                    if ($width > 1600 || $height > 562) {
                        $this->getElement('banner_image')->setErrors(array("Maximum allowed dimension for image  is 1600 x 562"));
                        $status = false;
                    }
                }
            }
            if ($data['tumbnail_image']['name'] != '' && !empty($data['tumbnail_image']['name']) ){
                    
                $fileName = $data['tumbnail_image']['name'];
                $fileName = explode(".", $fileName)[0];            
                if(!@preg_match('/^[A-Za-z0-9_-]+$/', $fileName)){
                    $this->getElement('tumbnail_image')->setErrors(array("File name can only be Alpha numerics with _ and - "));
                    $status = false;
                }   
            }    
            if ($data['master_type'] == BaseApp_Dao_Bundles::MASTER_TYPE_UNIVERSITY) {
                $imageSize = getimagesize($data['home_page_tumbnail_image']['tmp_name']);
                $image_width = $imageSize[0];
                $image_height = $imageSize[1];
                if (!empty($data['home_page_tumbnail_image']['tmp_name'])) {
                    if ($image_width > 404 || $image_height > 228) {
                        $this->getElement('home_page_tumbnail_image')->setErrors(array("Maximum allowed dimension for image  is 404 x 228"));
                        $status = false;
                    }
               
                }
                if ($data['home_page_tumbnail_image']['name'] != '' && !empty($data['home_page_tumbnail_image']['name']) ){
                    $fileName = $data['home_page_tumbnail_image']['name'];
                    $fileName = explode(".", $fileName)[0];            
                    if(!@preg_match('/^[A-Za-z0-9_-]+$/', $fileName)){
                        $this->getElement('home_page_tumbnail_image')->setErrors(array("File name can only be Alpha numerics with _ and - "));
                        $status = false;
                    }   
                }    
            
        }

    }
        if(empty($data['program_overview']) && $data['master_type'] == BaseApp_Dao_Bundles::MASTER_TYPE_COHORT) {
            $this->getElement('program_overview')->setErrors(array("Value is required and can't be empty"));
            $status = false;
        }

        if(empty($data['program_details_intro']) && $data['master_type'] == BaseApp_Dao_Bundles::MASTER_TYPE_COHORT) {
            $this->getElement('program_details_intro')->setErrors(array("Value is required and can't be empty"));
            $status = false;
        }
        if(empty($data['program_overview']) && $data['master_type'] == BaseApp_Dao_Bundles::MASTER_TYPE_UNIVERSITY) {
            $this->getElement('program_overview')->setErrors(array("Value is required and can't be empty"));
            $status = false;
        }

        if(empty($data['program_details_intro']) && $data['master_type'] == BaseApp_Dao_Bundles::MASTER_TYPE_UNIVERSITY) {
            $this->getElement('program_details_intro')->setErrors(array("Value is required and can't be empty"));
            $status = false;
        }
        if (!$data['primary_label_id']) {
            $this->getElement('primary_label_id')->setErrors(array("Value is required and can't be empty"));
            $status = false;
        }
        if (!$data['primary_course_id']) {
            $this->getElement('primary_course_id')->setErrors(array("Value is required and can't be empty"));
            $status = false;
        }
        if (isset($data['label_id']) && !in_array($data['primary_label_id'], $data['label_id'])) {
            $this->getElement('primary_label_id')->setErrors(array("selected primary label does not exists in labels selected"));
            $status = false;
        }
        if (isset($data['course_id']) && count(explode(",", $data['course_id'])) < 2) {
            $this->getElement('course_id_tmp')->setErrors(array("Atleast 2 primary courses should be selected to build a learning path"));
            $status = false;
        }

        if (isset($data['master_type']) && $data['master_type'] == BaseApp_Dao_Bundles::MASTER_TYPE_CLASSIC) {
            if (isset($data['course_id']) && count(explode(",", $data['course_id'])) > 7) {
                $this->getElement('course_id_tmp')->setErrors(array("Maximum 7 courses allowed"));
                $status = false;
            }
        }
        if(isset($data['master_type']) && $data['master_type'] == BaseApp_Dao_Bundles::MASTER_TYPE_UNIVERSITY && $data['university'] == 0){
            $this->getElement('university')->setErrors(array("Value is required and can't be empty"));
            $status = false;
        }

        if (isset($data['course_id']) && !in_array($data['primary_course_id'], explode(",", $data['course_id'])) && !in_array($data['primary_course_id'], explode(",", $data['course_or_id']))) {
            $this->getElement('primary_course_id')->setErrors(array("selected primary course does not exists in courses selected"));
            $status = false;
        }
        if (!empty($data['course_advisor']) && count($data['course_advisor']) > 4) {
            $this->getElement('course_advisor_err')->setErrors(array("Cannot select more than 4 course advisors."));
            $status = false;
        }

        if (!empty($data['trusted_by']) && count($data['trusted_by']) % 2 == 0) {
            $this->getElement('trusted_by_err')->setErrors(array("Only Odd number of Images can be shown on frontend."));
            $status = false;
        }
        if (!empty($data['course_advisor']) && count($data['course_advisor']) > 4) {
            $this->getElement('course_advisor_err')->setErrors(array("Cannot select more than 4 course advisors."));
            $status = false;
        }
        if (!empty($data['trusted_by']) && count($data['trusted_by']) > 4) {
            $this->getElement('trusted_by_err')->setErrors(array("Cannot select more than 4 Trusted by logos."));
            $status = false;
        }
        if (!empty($data['alumni']) && count($data['alumni']) > 4) {
            $this->getElement('alumni_err')->setErrors(array("Cannot select more than 4 course alumni."));
            $status = false;
        }

        if (isset($data['bundle_electives'])) {
            $_a = array_merge(explode(',', $data['course_id']), explode(',', $data['course_or_id']));
            $_b = array_filter(explode(',', $data['bundle_electives']));
            $_c = array_intersect($_a, $_b);
            $_d = count($_c);
            if (!empty($_c)) {
                $this->getElement('bundle_electives_temp')->setErrors(array("Error: Elective already chosen as a course. Please select a different elective"));
                $status = false;
            }
        }

        if (!empty($data['payment_type_id']) && $data['payment_type_id'] == BaseApp_Dao_PaymentType::SUBSCRIPTION_PAYMENT_TYPE_ID && !$data['subscription_logo']) {
            $this->getElement('subscription_logo')->setErrors(array("Value is required and can't be empty"));
            $status = false;
        }
        #validation for agenda page
        if ($data['agendaUrl']) {
            if (strpos(strtolower($data['agendaUrl']), 'https://www.simplilearn.com/ice9/pdfs/agenda/') === false) {
                $this->getElement('agendaUrl')->setErrors(array("Link should be Https and should have simplilearn domain"));
                $status = false;
            }
        }
        if ($data['videoLink']) {
            $videoLink = "";
            if (!empty($this->getView()->bundleId)) {
                $bundleId = $this->getView()->bundleId;
                $modelVideo = new Model_Videos();
                $videoData = $modelVideo->getByLinkableId($bundleId, 'bundle', BaseApp_Dao_TrainingTypes::TYPE_ELEARNING, 'about_bundle');
                $videoLink = isset($videoData['videoLink']) ? $videoData['videoLink'] : "";
            }
            if (strpos(strtolower($data['videoLink']), 'https://www.youtube.com/embed/') === false) {
                $this->getElement('videoLink')->setErrors(array("Link should be Https and also Emebed "));
                $status = false;
            } else if($data['videoLink'] != $videoLink){
                $youtubeApi = new BaseApp_Utility_YoutubeApi();
                $this->_vData = $youtubeApi->getVideoDetails($data['videoLink'],"snippet,contentDetails");
                if (!is_array($this->_vData)) {
                    if ($this->_vData == BaseApp_Utility_YoutubeApi::INVALID_VIDEO) {
                        $this->getElement('videoLink')->setErrors(array("Please enter valid youtube video link"));
                    } else if ($this->_vData == BaseApp_Utility_YoutubeApi::LIMIT_ERROR) {
                        $this->getElement('videoLink')->setErrors(array("Daily limit for authenticated use exceeded"));
                    } else {
                        $this->getElement('videoLink')->setErrors(array("Something is wrong with api."));
                    }
                    $status = false;
                }
            }
            if (!$data['videoThumbnail']) {
                $this->getElement('videoThumbnail')->setErrors(array("video thumb nail image required"));
                $status = false;
            } elseif (strpos(strtolower($data['videoThumbnail']), 'https://img.youtube.com/') === false) {
                $this->getElement('videoThumbnail')->setErrors(array("Link should be Https and also Youtube link"));
                $status = false;
            }
        }


        if (!empty($data['bundle_tmp_id']) && (!empty($data['promotional_short_description']) || !empty($data['promotional_long_description']))) {

            if (!empty($data['promotional_short_description'])) {
                $couponTxt = COUPON_REPLACE_TEXT;
                $pos = strpos($data['promotional_short_description'], $couponTxt);
                $couponData = array();
                if (!empty($data['coupon_id'])) {
                    if ((empty($data['cluster_id_bundle']) && empty($data['country_id_bundle']))) {
                        $this->getElement('cluster_id_bundle_tmp')->setErrors(array("Either cluster or country is Mandatory to show banner"));
                        $status = false;
                    }
                    $couponObj = new Model_Coupons();
                    $couponData = current($couponObj->fetchAll(array('coupon_id =?' => $data['coupon_id'], 'status =?' => 1, 'validto >= ?' => time(), 'purpose = ?' => 'marketing'), array('columns' => '*'), false));

                    if (empty($couponData) || empty($couponData['code'])) {
                        $this->getElement('coupon_id')->setErrors(array("Please add a valid coupon id"));
                        $status = false;
                    } else if (!empty($data['bundle_tmp_id'])) {
                        $bundlesCoupon = !empty($couponData['bundle_id']) ? explode(',', $couponData['bundle_id']) : array();
                        if (empty($couponData['bundle_id']) || !in_array($data['bundle_tmp_id'], $bundlesCoupon)) {
                            $this->getElement('coupon_id')->setErrors(array("This coupon is not valid for this masters program."));
                            $status = false;
                        }
                    } else {
                        if (!empty($data['cluster_id_bundle']) || !empty($data['country_id_bundle'])) {
                            if (!empty($data['cluster_id_bundle'])) {
                                $modelCountry = new Model_Country();
                                $countries = $modelCountry->fetchForSelect(array("cluster_id IN (?)" => $data['cluster_id_bundle']), array(), false);
                                if (!empty($data['country_id_bundle'])) {
                                    $data['country_id_bundle'] = array_merge($data['country_id_bundle'], array_keys($countries));
                                } else {
                                    $data['country_id_bundle'] = array_keys($countries);
                                }
                            }
                            if (!empty($data['country_id_bundle'])) {
                                $couponCountries = explode(',', $couponData['country_id']);
                                $countryDiff = array_diff($data['country_id_bundle'], $couponCountries);
                                if (!empty($countryDiff)) {
                                    $this->getElement('coupon_id')->setErrors(array("Coupon is not valid in all the countries and clusters selected."));
                                    $status = false;
                                }
                            }
                        }
                    }
                }
                // else if (!empty($data['bundle_tmp_id']) && empty($data['coupon_id'])) {
                //     $this->getElement('coupon_id')->setErrors(array("Coupon Id is Mandatory"));
                //     $status = false;
                // }
                else if (empty($data['bundle_tmp_id']) && !empty($data['coupon_id'])) {
                    $this->getElement('coupon_id')->setErrors(array("Cannot add Coupon Id for a new masters program"));
                    $status = false;
                }
                if (!empty($data['coupon_id']) && $pos === false) {
                    if (!empty($couponData) && !empty($couponData['code'])) {
                        $posC = strpos($data['promotional_short_description'], $couponData['code']);
                        if ($posC === false) {
                            $this->getElement('coupon_id')->setErrors(array("Short Description should contain " . $couponTxt . " string for coupon to be added"));
                            $status = false;
                        }
                    }
                }
            }
            if (empty($data['promotional_long_description'])) {
                $this->getElement('promotional_long_description')->setErrors(array("Promotional Long Description is Mandatory"));
                $status = false;
            }
            if (empty($data['promotional_image'])) {
                $this->getElement('promotional_image')->setErrors(array("Promotional Image is Mandatory"));
                $status = false;
            }
        }
        if (!$data['partialView'] && $data['master_type'] == BaseApp_Dao_Bundles::MASTER_TYPE_CLASSIC) {
            if (!empty($data['certificate_header_text']) && $data['master_type']!=BaseApp_Dao_Bundles::MASTER_TYPE_COHORT) {
                if (empty($data['certificate_image'])) {
                    $this->getElement('certificate_image')->setErrors(array("Certificate Image is Mandatory for master program"));
                    $status = false;
                }
            }
            
            if (!empty($data['certificate_alt_text'])) {
                if (empty($data['certificate_header_text']) && $data['master_type']!=BaseApp_Dao_Bundles::MASTER_TYPE_COHORT) {
                    $this->getElement('certificate_header_text')->setErrors(array("Certificate Header is Mandatory for master program"));
                    $status = false;
                }
                if (empty($data['certificate_image'])) {
                    $this->getElement('certificate_image')->setErrors(array("Certificate Image is Mandatory for master program"));
                    $status = false;
                }
            }
            
            if (!empty($data['certificate_image'])) {
                if ( empty($data['certificate_header_text']) && $data['master_type']!=BaseApp_Dao_Bundles::MASTER_TYPE_COHORT ) {
                    $this->getElement('certificate_header_text')->setErrors(array("Certificate Header is Mandatory for master program"));
                    $status = false;
                }
            }
        }
        /**
         * Validate Tools Coverage
         */
        // if (!empty($data['courseToolsFeature'])) {
        //     $bundleToolsValidStatus = $this->_validateBundleTools($data['courseToolsFeature']);
        //     if ($bundleToolsValidStatus['toolCategoryCrossMaxLimit']):
        //         $maxAllowedTool = self::MAX_TOOLS_ALLOWED;
        //         $this->getElement('bundle_tool_err')->setErrors(array("Maxium Allowed Tool In Tool Coverage is : {$maxAllowedTool}"));
        //         $status = false;
        //     elseif (!empty($bundleToolsValidStatus['toolCategoryDuplicate'])):
        //         $bundleCategories = implode(' | ', $bundleToolsValidStatus['toolCategoryDuplicate']);
        //         $this->getElement('bundle_tool_err')->setErrors(array("Duplicate Category Name Provided In Tools Coverage : {$bundleCategories}"));
        //         $status = false;
        //     elseif (!empty($bundleToolsValidStatus['toolsNotSelected'])):
        //         $toolNotSelected = implode(' | ', $bundleToolsValidStatus['toolsNotSelected']);
        //         $msg = "Tool(s) Not Selected For Tool Category : {$toolNotSelected}.Either Remove It Or Select Atleast One Tool";
        //         $this->getElement('bundle_tool_err')->setErrors(array($msg));
        //         $status = false;
        //     elseif (!empty($bundleToolsValidStatus['toolCategoryNameMinLimit'])):
        //         $msg = 'Minimum Characters For Tools Coverage Category Name Must Be : ' . self::MIN_TOOL_CATEGORY_NAME_CHARCTERS;
        //         $this->getElement('bundle_tool_err')->setErrors(array($msg));
        //         $status = false;
        //     elseif (!empty($bundleToolsValidStatus['toolCategoryNameMaxLimit'])):
        //         $msg = 'Maximum Characters Allowed For Tools Coverage Category Is : ' . self::MAX_TOOL_CATEGORY_NAME_CHARCTERS;
        //         $this->getElement('bundle_tool_err')->setErrors(array($msg));
        //         $status = false;
        //     elseif (!empty($bundleToolsValidStatus['toolNamesDuplicate'])):
        //         $duplicateToolNames = implode(' | ', $bundleToolsValidStatus['toolNamesDuplicate']);
        //         //$this->getElement('bundle_tool_err')->setErrors(array("Duplicate Tool Selected In Tools Coverage  : {$duplicateToolNames}"));
        //         $duplicateToolList = '';
        //         if (!empty($bundleToolsValidStatus['toolDuplicateList'])):
        //             foreach ($bundleToolsValidStatus['toolDuplicateList'] as $k => $list):
        //                 $duplicateToolList.="Tool : $k -> Present In Category :" . implode(' & ', array_unique($list)) . '   ||   ';
        //             endforeach;
        //             $duplicateToolList = rtrim($duplicateToolList, '   ||   ');
        //             $this->getElement('bundle_tool_err')->setErrors(array("Duplicate Tool Selected In Tools Coverage  : {$duplicateToolList}"));
        //         endif;
        //         $status = false;
        //     endif;
        // }
        return $status;
    }

    public function subFormValidations($data, $subForm, $status) {
        $count = 0;
        $accessDays = $data;
        end($accessDays);
        $keyA = key($accessDays);
        if ($subForm == 'accessDays' && count($data) > 2) {
            $this->getSubForm($subForm)->getSubForm($keyA)->getElement('accessDays')->setErrors(array("Only 2 bundle prices are allowed."));
            $status = false;
        }
        return $status;
    }

    /**
     * Get All Tools
     * @return array
     */
    private function getAllBundleTools() {
        $modelProductSectionData = new Model_ProductSectionData();
        $sectionType = 'tools';
        $toolList = array();
        $result = $modelProductSectionData->getBySectionType($sectionType);
        if (!empty($result)) {
            $toolList = array_unique($result);
        }
        return $toolList;
    }

    /**
     * Validate Bundle tool list
     * @param array $toolList
     * @return array
     */
    private function _validateBundleTools($toolList) {
        $validationResult = array('toolCategoryDuplicate' => 0, 'toolNamesDuplicate' => 0, 'toolCategoryCrossMaxLimit' => 0, 'toolCategoryNameCrossMinLimit' => 0, 'toolsNotSelected' => array(), 'toolDuplicateList' => array());
        $selectedToolListIds = array_column($toolList, 'tool_id');
        if (!empty($selectedToolListIds)):
            $toolCategoryOriginal = array_column($toolList, 'course_category');
            $toolCategory = array_map('strtolower', array_filter($toolCategoryOriginal));
            $toolCategory = array_map('trim', array_filter($toolCategory));
            $toolCategory = array_map(array($this, 'replaceDoubleSpaceWithSingle'), array_filter($toolCategory));
            /**
             * Maximum Tools Coverage Check.
             */
            if (count($toolCategory) > self::MAX_TOOLS_ALLOWED):
                $validationResult['toolCategoryCrossMaxLimit'] = 1;
            endif;
            /**
             * Duplicate Tools Coverage Category Name Check.
             */
            $uniqueToolCategory = array_unique($toolCategory);
            $duplicatesToolCategory = 0;
            if (count($uniqueToolCategory) < count($toolCategory)):
                $duplicatesToolCategory = array_unique(array_diff_assoc($toolCategory, $uniqueToolCategory));
                $validationResult['toolCategoryDuplicate'] = array_values($duplicatesToolCategory);
            endif;
            /**
             * Validate If Category Name Is present But No Tools Selected.
             */
            $toolNotSelectedError = 0;
            foreach ($toolList as $tool):
                if (empty($tool['course_category'])):
                    continue;
                endif;
                if (!empty($tool['course_category']) && empty($tool['tool_id'])):
                    $validationResult['toolsNotSelected'][] = $tool['course_category'];
                    $toolNotSelectedError = 1;
                endif;
            endforeach;


            /**
             * Maximum & Minimum Tools Coverage Category Name Character Limit.
             */
            $toolCatNameCharacterLimitValidation = 0;
            foreach ($uniqueToolCategory as $catName):
                if ((strlen($catName) < self::MIN_TOOL_CATEGORY_NAME_CHARCTERS)):
                    $toolCatNameCharacterLimitValidation = 1;
                    $validationResult['toolCategoryNameMinLimit'] = 1;
                    break;
                endif;
                if ((strlen($catName) > self::MAX_TOOL_CATEGORY_NAME_CHARCTERS)):
                    $toolCatNameCharacterLimitValidation = 1;
                    $validationResult['toolCategoryNameMaxLimit'] = 1;
                    break;
                endif;
            endforeach;
            /**
             * Duplicate Tools Coverage Tool Name Check.
             */
            if ((!is_array($duplicatesToolCategory) && $duplicatesToolCategory == 0) && $toolCatNameCharacterLimitValidation === 0 && $toolNotSelectedError === 0):
                $allToolList = $this->getAllBundleTools();
                $toolIdArr = array_column($toolList, 'tool_id');
                $toolIdTempArr = array();
                $duplicatesToolIds = array();
                $uniqueTool = array();
                foreach ($toolIdArr as $key => $toolIds):
                    foreach ($toolIds as $id):
                        if (!in_array($id, $toolIdTempArr)):
                            $toolIdTempArr[] = $id;
                            $uniqueTool[$toolCategoryOriginal[$key]][] = $allToolList[$id];
                        else:
                            $duplicatesToolIds[$toolCategoryOriginal[$key]][] = $allToolList[$id];
                        endif;
                    endforeach;
                endforeach;
                $uniqueDuplicateToolList = array();
                if (!empty($duplicatesToolIds)):
                    $toolNamesDuplicate = array();
                    foreach ($duplicatesToolIds as $key => $duplicateTool):
                        $toolCategory = $key;
                        $toolNames = implode(',', $duplicateTool);
                        $toolNamesDuplicate[] = $toolCategory . ":" . "$toolNames";
                        foreach ($duplicateTool as $pkey => $dTool):
                            $uniqueDuplicateToolList[$dTool][] = $key;
                            foreach ($uniqueTool as $tkey => $uToolList):
                                $uTList = array_values($uToolList);
                                if (in_array($dTool, $uTList)):
                                    $uniqueDuplicateToolList[$dTool][] = $tkey;
                                endif;
                            endforeach;
                            //$key = array_search($dTool, array_column($uniqueTool, 'uid'));
                        endforeach;
                    endforeach;
                    $validationResult['toolNamesDuplicate'] = $toolNamesDuplicate;
                    $validationResult['toolDuplicateList'] = $uniqueDuplicateToolList;
                endif;
            endif;
        endif;
        return $validationResult;
    }

    /**
     * Replace Double Spaces Between Words With Single Space.
     * @param string $data
     * @return string
     */
    private function replaceDoubleSpaceWithSingle($param) {
        $result = '';
        if (!empty($param)):
            $result = preg_replace('!\s+!', ' ', $param);
        endif;
        return $result;
    }
    private function getAllTools() {
        $modelProductSectionData = new Model_ProductSectionData();
        $sectionType = 'tools';
        $toolList = array();
        $result = $modelProductSectionData->getBySectionType($sectionType);
        if (!empty($result)) {
            $toolList = array_unique($result);
        }
        $toolList = $this->convertIdFormat($toolList);
        return $toolList;
    }
    private function convertIdFormat($list) {
        if(empty($list)) {
            return array();
        }
        foreach($list as $key => $val) {
            $list[$key] = "$key - $val";
        };
        return $list;
    }
    public function validateAcceditorLabel($label='',$accreditorLabel = '') {
        $response = array('isValid' => false, 'message' => 'Empty');
        if (!empty($label) && !empty($accreditorLabel)) {
            $accreditorLength = strlen($accreditorLabel);
            if ($accreditorLength > self::MAX_BUNDLE_ACCREDITOR_CHARACTER) {
                $response['isValid'] = false;
                $response['message'] = "Maximum ".self::MAX_BUNDLE_ACCREDITOR_CHARACTER."characters allowed for $label.";
            } else if ($accreditorLength < self::MIN_BUNDLE_ACCREDITOR_CHARACTER) {
                $response['isValid'] = false;
                $response['message'] = "Minimum ".self::MIN_BUNDLE_ACCREDITOR_CHARACTER." characters required for $label.";
            } else {
                $response = array('isValid' => true, 'message' => '');
            }
            return $response;
        }
    }

    public function _getBundleSectionMappingData(Model_ProductSectionData $modelObj, $linkableId, $linkableType, $sectionType)
    {
        $bundleData = $modelObj->getDataByType($linkableId, $linkableType, $sectionType);
        $bundleData = !empty($bundleData)?current($bundleData):array();
        return $bundleData;
    }

    
    public function getOverviewvalue(){
        
        $bundleId = $this->getView()->bundleId;
        if(!empty($bundleId)){
       $obj = new Model_ProductSectionData();
        $mappingData = $this->_getBundleSectionMappingData($obj,$bundleId,BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES,
        BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLE_OVERVIEW_TITLE);
        $data = !empty($mappingData['ps_description']) ? $mappingData['ps_description'] : "";
        return $data;
}
    }

public function getDetailsvalue(){
    $bundleId = $this->getView()->bundleId;
    if(!empty($bundleId)){
    $obj = new Model_ProductSectionData();
    $mappingData = $this->_getBundleSectionMappingData($obj,$bundleId,BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES,
    BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLE_DETAILS_TITLE);
    $data = !empty($mappingData['ps_description']) ? $mappingData['ps_description'] : "";
    return $data;
}
}
    public function getVideoData(){
        return $this->_vData;
    }
}
