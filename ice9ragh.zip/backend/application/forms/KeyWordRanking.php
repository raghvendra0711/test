<?php

class Form_KeyWordRanking extends BaseApp_SubForm {

    public function init() {

        $this->setName('KeyWordRankingForm');
        $this->setMethod('post');

        $course = new Model_YoutubeCourseName();
        $data = $course->getAll();
        $new_array = array();
        foreach ($data as $array) {
            foreach ($array as $val) {
                $new_array[$val] = $val;
            }
        }

        $coursename = array_unique($new_array);


        $this->addElement('select', 'course', array(
            'required' => true,
            'label' => 'Course*',
            'multioptions' => $coursename
        ));
        $this->addElement('submit', 'addCourse', array(
            'ignore' => true,
            'label' => 'Add Course',
            'class' => 'btn btn-info'
        ));

        $this->addElement('text', 'keyword', array(
            'label' => 'Keyword*',
            'required' => true,
            'class' => 'longtext',
            'placeholder' => 'keyword'
        ));

        $this->addElement('text', 'videoid', array(
            'label' => 'VideoId',
            'required' => true,
            'class' => 'longtext',
            'placeholder' => 'videoid'
        ));

        $this->addElement('submit', 'add', array(
            'ignore' => true,
            'label' => 'Add',
            'class' => 'btn btn-info'
        ));

        $this->addElement('submit', 'download', array(
            'ignore' => true,
            'label' => 'Download',
            'class' => 'btn btn-info'
        ));
    }

    public function isValid($data) {

        $status = true;
        if (!empty($data)) {

            if (empty($data['keyword'])) {
                $this->getElement('keyword')->setErrors(array("you did not selected any keyword"));
                $status = false;
            }
        } else {
            $status = false;
        }

        return $status;
    }

}
