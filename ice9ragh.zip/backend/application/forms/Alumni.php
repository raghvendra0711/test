<?php

class Form_Alumni extends BaseApp_Form
{

    public function init(){

        $this->setName('Alumni');
        $this->setMethod('post');
         //adding Label name element

        $this->addElement('text','name',array(
            'label'=>'Name*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'placeholder'=>'Alumni Name'
        ));

        $this->addElement('text','imageUrl',array(
            'label'=>'Image Url*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'placeholder'=>'Alumni Image',
            'validators' => array(
                new BaseApp_Validate_Image('category', 'alumni_image')
            )
        ));

        $this->addElement('text','linkedin_url',array(
            'label'=>'Linked In Url*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'placeholder'=>'Alumni Linked In Url'
        ));

        $obj =new Model_Labels();

        $this->addElement('select','label_id',array(
                'label'=>'Categories to be mapped to Alumni*',
                'required'=>false,
                'multiple' => true,
                'class' => 'multiple',
                'registerInArrayValidator' => false,
                'multioptions'=>$obj->fetchForSelect()
        ));

        $this->addElement('hidden','label_id_err',array(
                'required'=>false,
                'value'=>''
        ));

        $bundle = new Model_Bundles();
        $this->addElement('select','bundle_id_arr',array(
                'label'=>'Associated Bundles',
                'required'=>false,
                'multiple' => true,
                'registerInArrayValidator' => false,
                'class' => 'courseListAll',
                'multioptions'=>$bundle->fetchForSelect()
        ));

        $this->addElement('hidden','bundle_id_err',array(
                'required'=>false,
                'value'=>''
        ));

        $obj =new Model_ProductSectionData();
        $obj->setDisplayField('name');
        $this->addElement('select','company',array(
                'label'=>'Company*',
                'required'=>true,
                'registerInArrayValidator' => false,
                'multioptions'=>array('0'=>'--Select--') + $obj->fetchForSelect(array('sectionType = ?' => "company"))
        ));

         $this->addElement('submit','Add Alumni',array(
          'ignore'=>true,
          'label'=>'Add Alumni',
          'class'=>'btn btn-info'
         ));

        $validatorsAlumniName = array(new Zend_Validate_StringLength(array('min' => 2,'max'=>40)));

        $this->getElement('name')->addValidators($validatorsAlumniName);
    }

    public function isValid($data) {
        $status = parent::isValid($data);
        if(!$status)
            return false;
            if(!empty($data['linkedin_url'])){
                $data['linkedin_url'] = trim($data['linkedin_url']);
                $file_headers = @get_headers($data['linkedin_url']);
                if(!$file_headers || $file_headers[0] == 'HTTP/1.1 404 Not Found') {
                    $this->getElement('linkedin_url')->setErrors(array("'{$data['linkedin_url']}' is not a valid linked in url"));
                    $status = false;
                }
            }
            if(!empty($data['label_id'])){
                $obj =new Model_SectionMapping();
                $recordCount = $obj->getSectionCountByProduct($data['label_id'], 'Category', 'alumni');
                $obj =new Model_Labels();
                $labels = $obj->fetchForSelect();
                $consumedCategories = array();
                if(!empty($recordCount)){
                    foreach ($recordCount as $record){
                        if($record['count'] >= 4)
                            $consumedCategories[] = $labels[$record['linkable_id']];
                    }
                }
                if(!empty($consumedCategories)){
                    $this->getElement('label_id_err')->setErrors(array("4 alumni already added to: ".implode(', ', $consumedCategories)."."));
                    $status = false;
                }
            }

            if(!empty($data['bundle_id_arr'])){
                $obj =new Model_SectionMapping();
                $recordCount = $obj->getSectionCountByProduct($data['bundle_id_arr'], 'bundle', 'alumni');
                $obj = new Model_Bundles();
                $bundles = $obj->fetchForSelect();
                $consumedBundles = array();
                if(!empty($recordCount)){
                    foreach ($recordCount as $record){
                        if($record['count'] >= 4)
                            $consumedBundles[] = $bundles[$record['linkable_id']];
                    }
                }
                if(!empty($consumedBundles)){
                    $this->getElement('bundle_id_err')->setErrors(array("4 alumni already added to: ".implode(', ', $consumedBundles)."."));
                    $status = false;
                }
            }
            if($data['company'] == 0){
                $this->getElement('company')->setErrors(array("Value is required and can't be empty"));
                $status = false;
            }
        return $status;
    }
}