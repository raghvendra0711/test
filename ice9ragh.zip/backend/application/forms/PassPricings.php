<?php

class Form_PassPricings extends BaseApp_SubForm
{
    protected $submitName = 'Save Pass';

    public function init(){
        
        $this->setName('passPricing');
        $this->setMethod('post');

        $this->addElement('text','name',array(
            'label'=>'Name*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off'
        ));

        $this->addElement('text','displayName',array(
            'label'=>'Display Name*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off'
        ));
        
        $this->addElement('text','url',array(
            'label'=>'URL*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('text','shortDescription',array(
            'label'=>'Short Description*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off'
        ));
        
        $course =new Model_Courses();
        $this->addElement('select','course_id',array(
            'label'=>'Dummy Course*',
            'required'=>true,
            'registerInArrayValidator' => false,
            'multioptions'=>array('0'=>'--Select--') + $course->fetchForSelect(array('is_dummy = ?' => 1, 'is_free = ?' => 0))
        ));
        
        $objAccessDays = new Model_AccessDays();            
        $this->addElement('select','osl_access_days',array(
            'label'=>'Osl access days*',
            'required'=>true,
            'registerInArrayValidator' => false,
            'multioptions'=>array('0'=>'--Select--') + $objAccessDays->getLvcAccessDays()
        ));
        
        $session = new Zend_Session_Namespace('form');

        /*
         * Start: Sub form for price
         */
        
         $subForm = new Zend_Form_SubForm();
         $subForm->setName('countryPrice');           
         foreach ($session->countryPrice as $product) {            
            $keyCurrency = isset($session->countryPriceData[$product]['currency_id'])?$session->countryPriceData[$product]['currency_id']:'';                
            $keyCountry = isset($session->countryPriceData[$product]['country_id'])?$session->countryPriceData[$product]['country_id']:'';            
            $keyCluster = isset($session->countryPriceData[$product]['cluster_id'])?$session->countryPriceData[$product]['cluster_id']:'';            
            $keyDiscount = isset($session->countryPriceData[$product]['discount'])?$session->countryPriceData[$product]['discount']:'';    
            $keyPrice = isset($session->countryPriceData[$product]['price'])?$session->countryPriceData[$product]['price']:'';    
            
            $keyLocationMode = '';    
            if($keyCountry) {
                $keyLocationMode = 2;
            }
            else if($keyCluster) {
                $keyLocationMode = 1;
            }
            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);  
            
            if ($product === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
            }
            
            $currency = new Zend_Form_Element_Select('currency_id');
            $currencyModel = new Model_Currency();
            $currency->setOptions(array('multioptions' => $currencyModel->getCurrencyToDisplay()))->setValue($keyCurrency)->setAttrib('class', 'currency')->setLabel('Currency');
            
            $locationMode = new Zend_Form_Element_Select('location_mode');
            $locationMode->setOptions(array('multioptions' => array(0=>'--Select--',1=>'By Cluster',2=>'By Country')))->setValue($keyLocationMode)->setAttrib('class', 'location')->setLabel('Pricing Level');
            
            $country = new Zend_Form_Element_Select('country_id');
            $countryList = array();
            if($keyCurrency && $keyLocationMode == 2) {
                $countryModel = new Model_Country();
                $countryList = $countryModel->fetchForSelect(array('currency_id=?'=>$keyCurrency));
            }            
            $country->setOptions(array('multioptions' => $countryList, 'registerInArrayValidator' => false))->setValue($keyCountry)->setAttrib('class', 'country')->setLabel('Country'); 
            
            $cluster = new Zend_Form_Element_Select('cluster_id');
            $clusterList = array();
            if($keyCurrency && $keyLocationMode == 1) {
                $obj = new Model_Clusters();
                $clusterList = $obj->fetchForSelect(array('currency_id=?'=>$keyCurrency));                               
            }
            $cluster->setOptions(array('multioptions' => $clusterList, 'registerInArrayValidator' => false))->setValue($keyCluster)->setAttrib('class', 'cluster')->setLabel('Cluster');    
            
            $price = new Zend_Form_Element_Text('price');
            $price->addFilter('stringTrim')->setValue($keyPrice)->setAttrib('class', 'price')->setLabel('Price')->setAttrib('placeholder', 'Price');

            $discount = new Zend_Form_Element_Text('discount');
            $discount->addFilter('stringTrim')->setValue($keyDiscount)->setAttrib('class', 'discount')->setLabel('Discount(%)')->setAttrib('placeholder', 'Discount (%)');
            
            if ($product !== '__template__') {
                $country->setRequired(false);
                $cluster->setRequired(false);
                $locationMode->setRequired(false);
                $currency->setRequired(false);
                $discount->setRequired(false);
                $price->setRequired(false);
            }
            
            $removeCountryPrice = new Zend_Form_Element_Button('remove');
            $removeCountryPrice->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');        
         
            $elements = array($currency, $locationMode, $cluster, $country, $price, $discount);
            if ($product !== 'new') {
                $elements[] = $removeCountryPrice;            
            }
            
            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());

            if($rowForm->getElement('remove')) {
                $rowForm->getElement('remove')->removeDecorator('Label');
            }
            
            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        }
        
        $subForm->setDecorators($this->getSubFormDecoratorsMain('countryPrice', 'countryPrice'));

        $addPrice = new Zend_Form_Element_Button('add');
        $addPrice->setLabel('Add More')->setAttrib('class', 'btn btn-warning add');
        $subForm->addElement($addPrice);

        $subForm->setElementDecorators($this->getElementDecorators());
        $subForm->getElement('add')->removeDecorator('Label');
        $this->addSubForm($subForm, 'countryPrice');
        $this->postSetup(); 
        
        /*
         * End: Sub form for price
         */        
        
    }

    public function removeUneditableElements(){
        $this->removeElement('url');
        $this->removeElement('course_id');
        $this->removeElement('osl_access_days');
        return false;
    } 
    

    protected function getSubFormDecoratorsMain($Id='passPriceContainer',$class='passPriceContainer') {
        return array(   
            'FormElements',                        
            array(                
                'HtmlTag', array('tag' => 'ul')
            ),
            array(
                array('row' => 'HtmlTag'),                
                array('tag' => 'li', 'class' => $class, 'id' => $Id)
            )
        );
    }
    
    public function isValid($data) {
        $status = parent::isValid($data);
        if(isset($data['course_id']) && !$data['course_id']) {
            $this->getElement('course_id')->setErrors(array("Value is required and can't be empty"));
        }        
        if(isset($data['osl_access_days']) && !$data['osl_access_days']) {
            $this->getElement('osl_access_days')->setErrors(array("Value is required and can't be empty"));
        }
        if(!empty($data['url'])){
            $data['url'] = trim($data['url']);
            $checkSlash = substr($data['url'], 0,1);
            if($checkSlash != '/'){
                $data['url'] = trim('/'.$data['url']);
            }
            $objSeo = new Model_Seo();
            if(false === $objSeo->validateUrl($data['url'])){
                $this->getElement('url')->setErrors(array("'{$data['url']}' is not a valid Bundle url"));
                $status = false;   
            }
        }                        
        return $status;
    } 
 
    
}