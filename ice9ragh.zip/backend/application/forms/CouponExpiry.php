<?php

class Form_CouponExpiry extends BaseApp_Form
{
    
    public function init(){

        $this->setName('CouponExpiry');
        $this->setMethod('post');
        $this->addElement('file','coupoCsv',array(
            'label'=>'Upload A csv File',
            'required'=>true,
            'destination'=>sys_get_temp_dir(),
            'validators' => array(array('Extension', true, 'csv')) 
        ));

        $this->addElement('text','validto',array(
            'label'=>'End Date',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'datepicker'
        ));

        $this->addElement('submit','Save',array(
          'ignore'=>true,
          'label'=>'Save',
          'class'=>'btn btn-info'
         ));
    }
}