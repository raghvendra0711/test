<?php

class Form_SeoMetatag extends BaseApp_Form {

    public function init() {
        $this->addElement('text', 'name', array(
            'label' => 'Tag Name',
            'required'=>true
        ));
        $this->addElement('submit', 'save', array(
            'label' => 'Save'
        ));
    }
    
    public function isValid($data) {        
        $return = parent::isValid($data);
        if(isset($data['name']) && $data['name']) {
            $model = new Model_SeoMetatags();
            if($model->getByName($data['name'])) {
                $this->getElement('name')->setErrors(array("'{$data['name']}' already exists"));
                $return = false;
            }
        }
        return $return;
    }
}
