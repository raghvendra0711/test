<?php

class Form_BundleContentBenefits extends BaseApp_SubForm {
    
    private $_trainingId = '';
    private $_showAnswerField = true;
    public $isCityForm = false;
    
    public function __construct($isCityForm = false) {
        $this->isCityForm = $isCityForm;
        parent::__construct();
    }
    
    public function init() {
        $this->setName('bundleBenefits');
        $this->setMethod('post');
        //adding Label name element
        
        $session = new Zend_Session_Namespace('form');
        $subForm = new Zend_Form_SubForm();
        $subForm->setName('aboutBundle');     
        $product = 'new';  
         
        $faqId = isset($session->aboutBundleData[$product]['faq_id']) ? $session->aboutBundleData[$product]['faq_id'] : '';
        $keyQuestion = isset($session->aboutBundleData[$product]['question']) ? $session->aboutBundleData[$product]['question'] : '';
        $keyAnswer = isset($session->aboutBundleData[$product]['answer']) ? $session->aboutBundleData[$product]['answer'] : '';
        $keyJumpTo = isset($session->aboutBundleData[$product]['jump_to_section']) ? $session->aboutBundleData[$product]['jump_to_section'] : '';
        $keyCountryIds = isset($session->aboutBundleData[$product]['countryIds']) ? $session->aboutBundleData[$product]['countryIds'] : array();
        $allCountriesFlag = isset($session->aboutBundleData[$product]['allCountries']) ? $session->aboutBundleData[$product]['allCountries'] : 0;
        $keyIndustryName = isset($session->aboutBundleData[$product]['industry_name']) ? $session->aboutBundleData[$product]['industry_name'] : '';
        $keyIndustryPointOneHeader = isset($session->aboutBundleData[$product]['point_one_heading']) ? $session->aboutBundleData[$product]['point_one_heading'] : '';
        $keyIndustryPointOneText = isset($session->aboutBundleData[$product]['point_one_text']) ? $session->aboutBundleData[$product]['point_one_text'] : '';
        $keyIndustryPointTwoHeader = isset($session->aboutBundleData[$product]['point_two_heading']) ? $session->aboutBundleData[$product]['point_two_heading'] : '';
        $keyIndustryPointTwoText = isset($session->aboutBundleData[$product]['point_two_heading']) ? $session->aboutBundleData[$product]['point_two_heading'] : '';
        $keyDesination = isset($session->aboutBundleData[$product]['designation']) ? $session->aboutBundleData[$product]['designation'] : '';
        

        $rowForm = new Zend_Form_SubForm();
        $rowForm->setName($product);
        
        $classfck = 'fck-enable';
        if ($product === '__template__') {
            $rowForm->setAttrib('style', 'display: none;');
            $classfck = '';
        }
        
        $resourceIdDom = new Zend_Form_Element_Hidden('course_faq_id');
        if(! $this->isCityForm){
            $resourceIdDom->setValue($faqId)->clearDecorators();
        }else{
            $resourceIdDom->setValue($faqId)->setLabel('Job positions:')->setDecorators(array(
                array('Label',
                        array('class' => 'job-profiles-label'))
            ));
        }
        
        //Country
        if(! $this->isCityForm){
            $country = new Zend_Form_Element_Select('country_id');
            $countryModel = new Model_Country();
            $keyCountry = !empty($keyCountryIds) ? explode(',', $keyCountryIds) : array();
            $country->setOptions(array('required' => true))
            ->setValue($keyCountry)
            ->setLabel('Country')
            ->setRegisterInArrayValidator(false)
            ->setAttrib('onClick', 'clearSalaries()')
            ->setAttrib('options', array(0=> 'United States', 6=> 'India'));                                       
        }

        if($this->_showAnswerField){
            
            $answer = new Zend_Form_Element_Textarea('answer');
            $answer->addFilter('stringTrim')
            ->setValue($keyAnswer)
            ->setAttrib('class', !$this->isCityForm ? $classfck :'fck-enable-intro')
            ->setAttrib('rows', 5)
            ->setAttrib('cols', 60)
            ->setAttrib('required', true)
            ->setLabel('Intro *');

            $industryName = new Zend_Form_Element_Text('industry_name');
            $industryName->setLabel('Industry Name *')->addFilter('stringTrim')->setValue('')->setAttrib('class', 'longtext')->setValue($keyIndustryName); // set value here

            $pointOneHeading = new Zend_Form_Element_Text('point_one_heading');
            $pointOneHeading->setLabel('Point One Heading *')->addFilter('stringTrim')->setValue('')->setAttrib('class', 'longtext')->setValue($keyIndustryPointOneHeader); // set value here
            
            $pointOneText = new Zend_Form_Element_Text('point_one_text');
            $pointOneText->setLabel('Point One Text *')->addFilter('stringTrim')->setValue('')->setAttrib('class', 'longtext')->setValue($keyIndustryPointOneText); // set value here

            $pointTwoHeading = new Zend_Form_Element_Text('point_two_heading');
            $pointTwoHeading->setLabel('Point Two Heading *')->addFilter('stringTrim')->setValue('')->setAttrib('class', 'longtext')->setValue($keyIndustryPointTwoHeader); // set value here
            
            $pointTwoText = new Zend_Form_Element_Text('point_two_text');
            $pointTwoText->setLabel('Point Two Text *')->addFilter('stringTrim')->setValue('')->setAttrib('class', 'longtext')->setValue($keyIndustryPointTwoText); // set value here

        }
        
        $removeFaq = new Zend_Form_Element_Button('remove');
        $removeFaq->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');
               
        $elements = array();
        if($this->_showAnswerField){
            if($this->isCityForm){
                $elements = array($answer, $industryName,
                                 $pointOneHeading, $pointOneText,
                                 $pointTwoHeading, $pointTwoText, 
                                 $resourceIdDom);
            }else{
                $elements = array($country, $answer, $industryName, 
                                    $pointOneHeading, $pointOneText,
                                    $pointTwoHeading, $pointTwoText,
                                    $resourceIdDom);
            }
        }else{
            if($this->isCityForm){
                // $elements = array($answer, $industryName, $resourceIdDom);
                $elements = array($answer, $industryName,
                                 $pointOneHeading, $pointOneText,
                                 $pointTwoHeading, $pointTwoText, 
                                 $resourceIdDom);
            }else{
                // $elements = array($country, $answer, $industryName, $resourceIdDom);
                $elements = array($country, $answer, $industryName, 
                                    $pointOneHeading, $pointOneText,
                                    $pointTwoHeading, $pointTwoText,
                                    $resourceIdDom);
            }
        }
        if ($product !== 'new') {
            $elements[] = $removeFaq;
        }
        
        $rowForm->addElements($elements);
        $rowForm->setElementDecorators($this->getElementDecorators());
        
        if ($rowForm->getElement('remove')) {
            $rowForm->getElement('remove')->removeDecorator('Label');
        }
        
        if ($rowForm->getElement('invert')) {
            $rowForm->getElement('invert')->removeDecorator('Label');
        }
        //Adding job desgnation sub form
        
        $jdSubForm = $this->_createJobDesignationSubForm($session->aboutBundle, $session->aboutBundleData);
        $rowForm->addSubForm($jdSubForm, 'job designation');
        
        $rowForm->setDecorators($this->getSubFormDecorators());
        $subForm->addSubForm($rowForm, $product);                                  
        $subForm->setDecorators($this->getSubFormDecoratorsMain('course-faq-editor', 'aboutBundle'));
        
        $this->addSubForm($subForm, 'aboutBundle');
        
        if($this->isCityForm){
            $this->addElement('button', 'Save city', array(
                'ignore' => true,
                'class' => 'btn btn-success',
                'label' => 'Save',
            ));
        }else{
            $this->addElement('submit', 'Save', array(
                'ignore' => true,
                'label' => 'Save',
            ));
        }
        $this->addElement('button', 'Cancel', array(
            'label' => 'Cancel',
            'ignore' => true,
            'id' => 'cancel_form',
            'class' => 'btn btn-warning'
        ));
    }
    
    /**
    * Creates a sub form which is going to encapsulate the individual subforms of each Job Designation
    * @formTypes include _template_ and new
    * We create the subform for _template_ and hide it and use it to add more rows
    * When you click on the add Job , the subform created for _template_ will be copied , form names changed
    * and added back to the form. 
    * @return jdSubForm subform with two forms for jobs one is _template_ which will be hidden and other visible.
    */
    private function _createJobDesignationSubForm($formTypes, $data) {
        $jdSubForm = new Zend_Form_SubForm();
        $jdSubForm->setName('jobs Container');
        foreach ($formTypes as $product) {
            if (!empty($product)){
                $formData = isset($data[$product]) ? $data[$product]: array();
                $desig = !empty($data['new']['designation'])?$data['new']['designation']:'';
                if(!empty($formData['jobdesignation'])){
                    foreach($formData['jobdesignation'] as $key => $jobData){
                        if ($key === '__template__') {
                            continue;
                        }
                        $jdSubForm->addSubForm($this->_getJobDesignationSubForm($key, $jobData,$desig), $key);
                    }                
                } else {
                    $jdSubForm->addSubForm($this->_getJobDesignationSubForm($product,'',$desig), $product);
                }
            }
        }
        $jdSubForm->setDecorators($this->getSubFormDecoratorsMain('job-designation-container', 'jobs'));         
        if(!$this->isCityForm){
            $addJob = new Zend_Form_Element_Button('add');
            $addJob->setLabel('Add Job')->setAttrib('class', 'btn btn-success add');
            $jdSubForm->addElement($addJob);  
        }

        return $jdSubForm;
    }
    
    /**
    * Function to create the individual subform of each job description. 
    * Which will be copied later on clicking add job
    * @return jdForm sub form of job designation. salary and company fields.
    */
    private function _getJobDesignationSubForm($type, $values= array(),$desig = '') {
            $jdForm = new Zend_Form_SubForm();
            $jdForm->setElementDecorators($this->getJobFormElementDecorators());        
            $jdForm->setName($type);
            
            if ($type === '__template__') {
                $jdForm->setAttrib('style', 'display: none;');
            }

            //Elements
            if($this->isCityForm){
                $jdForm->addElement('text', 'designation', array(
                    'label' => ($type === '__template__') ? 'Job position ':  (isset($values['designation']) && !empty($values['designation']) ? $values['designation']: 'Job position '),
                    'required' => ($type === '__template__') ? false : true,
                    'filters' => array('StringTrim'),
                    'placeholder' => 'Job Designation',
                    'readonly' => true,
                    'class' => 'sal-req jobDesignation hide',
                    //'value' => isset($values['designation']) && !empty($values['designation']) ? $values['designation']: '' ,
                    'validators' => array(
                        array(new Zend_Validate_StringLength(array('max' => 32)))
                    )
                ));

                $designationElement = $jdForm->getElement('designation')->setDecorators(array(
                    array('Label',
                            array('class' => 'designation-label'))
                ));
            }else{
                $jdForm->addElement('text', 'designation', array(
                    'label' => ($type === '__template__') ? 'Job position ':  'Job position ',
                    'required' => ($type === '__template__') ? false : true,
                    'filters' => array('StringTrim'),
                    'placeholder' => 'Job Designation',
                    'class' => 'sal-req jobDesignation',
                    'value' => isset($values['designation']) ? $values['designation']: '' ,
                    'validators' => array(
                        array(new Zend_Validate_StringLength(array('max' => 32)))
                    )
                ));
            }
            if(! $this->isCityForm){
                $jdForm->addElement('button', 'get-salary', array(
                    'label'=> 'Get Salary',
                    'class' => 'btn btn-info get-salary',
                    'onClick' => 'getSalaryDetailsForBundle(this, "'.JOB_SALARIES_API.'")'
                ));
            }

            $jdForm->addElement('text', 'min', array(
                'filters' => array('StringTrim'),
                'required' => ($type === '__template__') ? false : true,
                'class' => 'shorttext min-salary sal-req',
                'placeholder' => 'Min Salary',
                'value' => isset($values['min']) ? $values['min']: ''
            ));
            
            $jdForm->addElement('text', 'avg', array(
                'filters' => array('StringTrim'),
                'required' => ($type === '__template__') ? false : true,
                'class' => 'shorttext avg-salary sal-req',
                'placeholder' => 'Average Salary',
                'value' => isset($values['avg']) ? $values['avg']: ''
            ));
            
            $jdForm->addElement('text', 'max', array(
                'filters' => array('StringTrim'),
                'required' => ($type === '__template__') ? false : true,
                'class' => 'shorttext max-salary sal-req',
                'placeholder' => 'Max Salary',
                'value' => isset($values['max']) ? $values['max']: ''
            ));      

            
            
            if(!$this->isCityForm){                
                $selectHiringCompanies= $this->_getHiringCompaniesForSelect();
                $jdForm->addElement('text', 'desig_field', array(
                    'label' => 'Designation *',
                    'required' =>($type === '__template__') ? false : true,
                    'filters' => array('StringTrim'),
                    'placeholder' => 'Job Designation',
                    'class' => 'longtext',
                    'value' => $desig ,
                    'validators' => array(
                        array(new Zend_Validate_StringLength(array('max' => 32)))
                    )
                ));
                $jdForm->addElement('select', 'hiring_companies', array(
                    //'required' => ($type === '__template__') ? false : true,
                    //'label' => 'Hiring Companies',
                    'size' => 12,
                    'data-name'=> $type,
                    'class' => 'multiple',
                    'registerInArrayValidator' => false,
                    'value' => isset($keyDesination) ? $keyDesination: '',
                    'multioptions' => $selectHiringCompanies
                ));
                $basicGroup = array('desig_field','hiring_companies');
                $jdForm->addDisplayGroup($basicGroup, 'basic_group');
                $jdForm->getDisplayGroup('basic_group')
                        ->setLegend('Hiring Companies')
                        ->clearDecorators()
                        ->addDecorator('FormElements')
                        ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper'));

                $jdForm->addElement('hidden', 'company_ids', array(
                    'required' => ($type === '__template__') ? false : true,
                    'value' => !empty($values['company_ids']) ? $values['company_ids']: '',
                ));
            }

            $jdForm->addElement('hidden', 'section_id', array(
                'required' => false,
                'class'=>'hidSectionId',
                'value' => isset($values['section_id']) ? $values['section_id']: ''
            ));

            $jdForm->addElement('hidden', 'section_map_id', array(
                'required' => false,
                'class'=>'hidSectionMapId',
                'value' => isset($values['section_map_id']) ? $values['section_map_id']: ''
            ));

            if(! $this->isCityForm){
                $removeForm = new Zend_Form_Element_Button('remove');
                $removeForm->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');
                if ($type !== 'new') {
                    $jdForm->addElement($removeForm);
                }
            }
            
            $jdForm->setDecorators($this->getSubFormDecorators());
        return $jdForm;
        
    }

    private function _getHiringCompaniesForSelect(){
        $obj = new Model_ProductSectionData();
        $cond = array(
            'sectionType = ?' => BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_HIRING_COMPANIES, 
            'long_description like ?' => '%'.BaseApp_Dao_ProductTypes::DESCRIPTION_VALUE_FOR_MASTER_INDUSTRYTRENDS_COMAPNIES.'%',
            'status = ?' => 1
        );
        $hiringCompanies = $obj->fetchAll($cond);
        $returnSelectArray = array();
        if (!empty($hiringCompanies)){
            foreach( $hiringCompanies as $company) {
                $returnSelectArray[$company['id']] = $company['name'] .' - '. $company['id']; 
            }

        }
       return $returnSelectArray;
    }

    protected function getJobFormElementDecorators()
    {
        $elementDecorators = array(
            'ViewHelper',
            array(
                array('data' => 'HtmlTag'),
                array('tag' =>'div', 'class'=> 'element')
            ),
            'Errors',
            array(
                'Label',
                array('tag' => 'div')
            ),
            array(
                array('row' => 'HtmlTag'),
                //array('tag' => 'li')
            )
        );

        return $elementDecorators;
    }
    
    protected function getBenefitsFormDecorators($className, $id)
    {
        return array(
            'FormElements',
        array('HtmlTag', array('tag' => 'ul'/*, 'data-role' => 'fieldset', 'role' => 'listitem'*/)),
        'Fieldset',
        array(
            array('row' => 'HtmlTag'),
            array('tag' => 'li',  'class' => $className, 'id' => $id)
            )
            //             array('HtmlTag', array('tag' => 'li'/*, 'data-role' => 'listview', 'role' => 'list'*/))
        );
    }
    
    
    protected function getSubFormDecoratorsMain($className, $id) {
        return array(
            'FormElements',
            array(
                'HtmlTag', array('tag' => 'ul')
            ),
            array(
                array('row' => 'HtmlTag'),
                array('tag' => 'li', 'class' => $className, 'id' => $id)
                )
            );
        }
        
        public function removeUneditableElements() {
            return false;
        }
        
        public function isValid($data, &$errorMessage='',$showAnswerField=true) {
              
            $status = parent::isValid($data);
            
            if (!empty($data['aboutBundle'])) {
                $subForm = 'aboutBundle';
                foreach ($data['aboutBundle'] as $key => $row) { 
                    $industryName = !empty($row['industry_name']) ? $row['industry_name'] : '';
                     
                    if($industryName == '' || strlen($industryName) >30 ){
                        $this->getSubForm($subForm)->getSubForm($key)->getElement('industry_name')->setErrors(array("Industry name cannot be empty or exceed 30 charecter length"));
                         
                    }
                    $heading1 = !empty($row['point_one_heading']) ? $row['point_one_heading'] : '';
                    if($heading1 == '' || strlen($heading1) >26 ){
                        $this->getSubForm($subForm)->getSubForm($key)->getElement('point_one_heading')->setErrors(array("Point One Heading cannot be empty or exceed 26 charecter length"));
                         
                    }
                    
                    $heading2 = !empty($row['point_two_heading']) ? $row['point_two_heading'] : '';
                    if($heading2 == '' || strlen($heading2) >26 ){
                        $this->getSubForm($subForm)->getSubForm($key)->getElement('point_two_heading')->setErrors(array("Point Two Heading cannot be empty or exceed 26 charecter length"));
                         
                    }

                    $point1 = !empty($row['point_one_text']) ? $row['point_one_text'] : '';
                    if($point1 == '' || strlen($point1) >75 ){
                        $this->getSubForm($subForm)->getSubForm($key)->getElement('point_one_text')->setErrors(array("Point one text cannot exceed 75 charecter length"));
                         
                    }

                    $point2 = !empty($row['point_two_text']) ? $row['point_two_text'] : '';
                    if($point2 == '' || strlen($point2) >75){
                        $this->getSubForm($subForm)->getSubForm($key)->getElement('point_two_text')->setErrors(array("Point two text cannot be empty or exceed 75 charecter length"));
                         
                    }                
                    
                    if (empty($row['answer'])) {
                        $status = false;
                        $this->getSubForm($subForm)->getSubForm($key)->getElement('answer')->setErrors(array("Please enter Intro."));                        
                    } else {
                        //Removing &nbsp and html tags and replacing new lines with spaces to count the number of characters
                        $answerText = trim(preg_replace('/\s+/', ' ', strip_tags(html_entity_decode($row['answer']))));
                        if (strlen($answerText) > 300) {
                            $status = false;
                            $this->getSubForm($subForm)->getSubForm($key)->getElement('answer')->setErrors(array("Value is more than 300 characters long"));
                        }
                    }  
                                      
                    if (isset($row['jobdesignation'])){
                        foreach($row['jobdesignation'] as $jobKey=>$job){
                            if($jobKey == "__template__"){
                                continue;
                            }
                            if (!($job['max']>$job['avg']) && !($job['avg']>$job['min'])){                                
                                $status = false;
                                $this->getSubForm($subForm)->getSubForm($key)->getSubForm('job designation')->getSubForm($jobKey)->getElement('designation')->setErrors(array("Salary values must be incremental"));
                            }  
                            
                        }
                    }
                }    
                           
                return $status;
            }
        }
    }
    
