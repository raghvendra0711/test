<?php

class Form_AboutCourses extends BaseApp_SubForm
{

    public function init(){
        $this->setName('CourseFaq');
        $this->setMethod('post');
         //adding Label name element

        $this->addElement('text','videoLink',array(
            'label' => 'Embeded You Tube Video',
            'placeholder'=>" Please Enter A Embeded You Tube video Link",
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('text','dateCreated',array(
            'label' => 'Video Uploaded date',
            'placeholder'=>"YYYY-MM-DD",
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('text','videoThumbnail',array(
            'label' => 'Video Thumbnail Image',
            'placeholder'=>" Please Enter video Thumbnail Image",
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('textarea','videoDescription',array(
            'label'=>'Video Description',
            'filter'=>array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class'=>'description'
        ));

        $this->addElement('text','pre_run_video',array(
            'label'=>'Pre Run Video Link',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
        ));

        $this->addElement('text','flexi_pass_video',array(
            'label'=>'Flexi Pass Video Link',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
        ));

        $this->addElement('checkbox','previewFromElearning',array(
            'label'=>'Course Preview from e-Learning?',
            'value'=>1
        ));

        $session = new Zend_Session_Namespace('form');

        /**
         * Start: course preview
         */
        $subForm = new Zend_Form_SubForm();
        $subForm->setName('coursePreview');
        foreach ($session->coursePreview as $product => $videoSession) {
            $chapterName = isset($session->coursePreviewData[$product]['chapterName'])?$session->coursePreviewData[$product]['chapterName']:'';
            $chapterForm = new Zend_Form_SubForm();
            $chapterForm->setName($product);
            if ($product === '__template__') {
                $chapterForm->setAttrib('style', 'display: none;');
            }

            $chapterNameObj = new Zend_Form_Element_Text('chapterName');
            $chapterNameObj->addFilter('stringTrim')->setValue($chapterName)->setAttrib('class', 'longtext')->setLabel('ChapterName');

            $removeChapter = new Zend_Form_Element_Button('remove');
            $removeChapter->setLabel('Remove Chapter')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');
            $elements = array($chapterNameObj);
            if($product !== 'new') {
                $elements[] = $removeChapter;
            }

            $chapterForm->addElements($elements);
            $chapterForm->setElementDecorators($this->getElementDecorators());

            if($chapterForm->getElement('remove')) {
                $chapterForm->getElement('remove')->removeDecorator('Label');
            }

            $chapterForm->setDecorators($this->getSubFormDecorators('chapter-subform subform'));
            foreach($videoSession['videos'] as $videoProduct) {
                if($product === '__template__' && $videoProduct !== '__template__') {
                    continue;
                }
                if($videoProduct == '__template__' && $product !== '__template__') {
                    continue;
                }

                $videoForm = new Zend_Form_SubForm();
                $videoForm->setName($product.'-'.$videoProduct);
                $videoName = isset($session->coursePreviewData[$product]['video'][$videoProduct]['name'])?$session->coursePreviewData[$product]['video'][$videoProduct]['name']:'';
                $videoLink = isset($session->coursePreviewData[$product]['video'][$videoProduct]['url'])?$session->coursePreviewData[$product]['video'][$videoProduct]['url']:'';
                $videoLength = isset($session->coursePreviewData[$product]['video'][$videoProduct]['duration'])?$session->coursePreviewData[$product]['video'][$videoProduct]['duration']:'';

                if ($videoProduct === '__template__') {
                    $videoForm->setAttrib('style', 'display: none;');
                }

                $videoNameObj = new Zend_Form_Element_Text('name');
                $videoNameObj->addFilter('stringTrim')->setValue($videoName)->setAttrib('class', 'longtext videoField')->setLabel('Name');
                $videoLinkObj = new Zend_Form_Element_Text('url');
                $videoLinkObj->addFilter('stringTrim')->setValue($videoLink)->setAttrib('class', 'longtext videoField')->setLabel('Link');
                $videoLengthObj = new Zend_Form_Element_Text('duration');
                $videoLengthObj->addFilter('stringTrim')->setValue($videoLength)->setAttrib('class', 'longtext videoField')->setLabel('Length')->setAttrib('placeholder', 'HH:MM:SS');

                $removeVideo = new Zend_Form_Element_Button('remove');
                $removeVideo->setLabel('Remove Video')->setAttrib('class', 'btn btn-danger removeVideo')->setAttrib('onclick', 'removeSubFormElement(this)');

                $elements = array($videoNameObj, $videoLinkObj, $videoLengthObj);
                if($videoProduct !== 'new') {
                    $elements[] = $removeVideo;
                }

                $videoForm->addElements($elements);
                $videoForm->setElementDecorators($this->getElementDecorators());

                if($videoForm->getElement('remove')) {
                    $videoForm->getElement('remove')->removeDecorator('Label');
                }

                $videoForm->setDecorators($this->getSubFormDecorators('video-subform subform'));
                $videoForm->setLegend('Video');
                $chapterForm->addSubForm($videoForm, $videoProduct);
            }
            $addVideo = new Zend_Form_Element_Button('add');
            $addVideo->setLabel('Add Video')->setAttrib('class', 'btn btn-warning add-course-preview-video');
            $chapterForm->addElement($addVideo);

            $subForm->addSubForm($chapterForm, $product);
        }

        $subForm->setDecorators($this->getSubFormDecoratorsMain('course-faq-editor', 'coursePreview'));

        $addChapter = new Zend_Form_Element_Button('add');
        $addChapter->setLabel('Add Chapter')->setAttrib('class', 'btn btn-warning add');
        $subForm->addElement($addChapter);

        $subForm->setElementDecorators($this->getElementDecorators());
        $subForm->getElement('add')->removeDecorator('Label');
        $this->addSubForm($subForm, 'coursePreview');


        /**
         * End: course preview
         */

         $subForm = new Zend_Form_SubForm();
         $subForm->setName('aboutCourse');
         foreach ($session->aboutCourse as $product) {
            $faqId = isset($session->aboutCourseData[$product]['faq_id'])?$session->aboutCourseData[$product]['faq_id']:'';
            $keyQuestion = isset($session->aboutCourseData[$product]['question'])?$session->aboutCourseData[$product]['question']:'';
            $keyAnswer = isset($session->aboutCourseData[$product]['answer'])?$session->aboutCourseData[$product]['answer']:'';
                        $keyJumpTo = isset($session->aboutCourseData[$product]['jump_to_section'])?$session->aboutCourseData[$product]['jump_to_section']:'';

            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);

            $classfck = 'fck-enable';
            if ($product === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
                $classfck = '';
            }


            $resourceIdDom = new Zend_Form_Element_Hidden('course_faq_id');
            $resourceIdDom->addFilter('stringTrim')->setValue($faqId)->clearDecorators();

            $question = new Zend_Form_Element_Text('question');
            $question->addFilter('stringTrim')->setValue($keyQuestion)->setAttrib('class', 'longtext')->setLabel('Question');

            $answer = new Zend_Form_Element_Textarea('answer');
            $answer->addFilter('stringTrim')->setValue($keyAnswer)->setAttrib('class', $classfck)->setAttrib('rows', 5)->setAttrib('cols', 60)->setLabel('Answer');

            $jumpTo = new Zend_Form_Element_Checkbox('jump_to_section');
            $jumpTo->setValue($keyJumpTo)->setLabel('Add as JumpTo Section');

            $removeFaq = new Zend_Form_Element_Button('remove');
            $removeFaq->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');

            $elements = array($question, $answer, $jumpTo, $resourceIdDom);
            if($product !== 'new') {
                $elements[] = $removeFaq;
            }

            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());

            if($rowForm->getElement('remove')) {
                $rowForm->getElement('remove')->removeDecorator('Label');
            }

            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        }

        $subForm->setDecorators($this->getSubFormDecoratorsMain('course-faq-editor', 'aboutCourse'));

        $addFaq = new Zend_Form_Element_Button('add');
        $addFaq->setLabel('Add More')->setAttrib('class', 'btn btn-warning add');
        $subForm->addElement($addFaq);

        $subForm->setElementDecorators($this->getElementDecorators());
        $subForm->getElement('add')->removeDecorator('Label');
        $this->addSubForm($subForm, 'aboutCourse');


        $this->addElement('submit','Save',array(
          'ignore'=>true,
          'label'=>'Save'
         ));
    }

    protected function getSubFormDecoratorsMain($className, $id) {
        return array(
            'FormElements',
            array(
                'HtmlTag', array('tag' => 'ul')
            ),
            array(
                array('row' => 'HtmlTag'),
                array('tag' => 'li', 'class' => $className, 'id' => $id)
            )
        );
    }

    protected function getSubFormDecorators($className = 'subform')
    {
        return array(
            'FormElements',
            array('HtmlTag', array('tag' => 'ul'/*, 'data-role' => 'fieldset', 'role' => 'listitem'*/)),
            'Fieldset',
            array(
                array('row' => 'HtmlTag'),
                array('tag' => 'li', 'class' => $className)
            )
//             array('HtmlTag', array('tag' => 'li'/*, 'data-role' => 'listview', 'role' => 'list'*/))
        );
    }

    public function removeUneditableElements(){
        return false;
    }

    public function isValid($data, &$errorMessage='') {
        $status = parent::isValid($data);
        if(!$data['previewFromElearning']) {
            foreach($data['coursePreview'] as $topic => $videoData) {
                foreach($videoData as $videoDataSingle) {
                    if(!is_array($videoDataSingle)) {
                        if(!$videoDataSingle) {
                            $errorMessage = 'chapter name can not be empty';
                            return false;
                        }
                        continue;
                    }
                    if(!$videoDataSingle['name']) {
                        $errorMessage = 'video name can not be empty';
                        return false;
                    }
                    if(!$videoDataSingle['url']) {
                        $errorMessage = 'video url name can not be empty';
                        return false;
                    }
                    if(!preg_match("/^(\d\d\:)?(\d\d)\:(\d\d)$/", $videoDataSingle['duration'], $match)) {
                        $errorMessage = 'course preview duration is invalid. It should be HH:MM:SS format';
                        return false;
                    }
                }
            }
        }
        if($data['videoLink']){
            if (strpos( strtolower($data['videoLink']),'https://www.youtube.com/embed/' ) === false) {
                $this->getElement('videoLink')->setErrors(array("Link should be Https and also Emebed  "));
                $status = false;
            }
            elseif(!isset($data['dateCreated']) || !$data['dateCreated'] || !preg_match("/^(\d\d\d\d)-(\d\d)-(\d\d)(\s\d\d\:\d\d:\d\d)?$/", $data['dateCreated'])) {
                $this->getElement('dateCreated')->setErrors(array("You Tube uploaded date required in YYYY-MM-DD format"));
                $status = false;
            }

            if(!$data['videoThumbnail']){
                $this->getElement('videoThumbnail')->setErrors(array("video thumb nail image required"));
                $status = false;
            }elseif (strpos( strtolower($data['videoThumbnail']),'https://img.youtube.com' ) === false) {
                $this->getElement('videoThumbnail')->setErrors(array("Link should be Https and also a Youtube link"));
                $status = false;
            }
        }

        if (!empty($data['pre_run_video'])) {
            if (strpos( strtolower($data['pre_run_video']),'https://www.youtube.com/embed/' ) === false) {
                $this->getElement('pre_run_video')->setErrors(array("Link should be Https and also Emebed "));
                $status = false;
            }
        }

        if (!empty($data['flexi_pass_video'])) {
            if (strpos( strtolower($data['flexi_pass_video']),'https://www.youtube.com/embed/' ) === false) {
                $this->getElement('flexi_pass_video')->setErrors(array("Link should be Https and also Emebed "));
                $status = false;
            }
        }
        return $status;
    }
}

