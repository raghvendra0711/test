
<?php

class Form_CourseMoreDetail extends BaseApp_Form
{
    public function init() {
        $this->setName('CourseMoreDetail');
        $this->setMethod('post');
        $validatorsProjectSectionTitle = array(new Zend_Validate_StringLength(array('max' => 23)));
        $validatorsProjectTitle = array(new Zend_Validate_StringLength(array('max' => 63)));
        $validatorsProjectContent = array(new Zend_Validate_StringLength(array('max' => 183)));
        $validatorsSkillsCovered = array(new Zend_Validate_StringLength(array('max' => 48)));
        $session = new Zend_Session_Namespace('form');

        $subForm = new Zend_Form_SubForm();
        $subForm->setName('skills');
        $i=0;
        foreach ($session->skills as $product) {
            $keyName = isset($session->skillsData[$product]['name']) ? $session->skillsData[$product]['name'] : '';
            $sectionId = isset($session->skillsData[$product]['section_id']) ? $session->skillsData[$product]['section_id'] : '';
             $skillLabel = 'Skills Covered';
            if($i!=0){
            $skillLabel = 'Skills Covered '.$i;
            }              
            $resourceIdDom = new Zend_Form_Element_Hidden('sectionId');
            $resourceIdDom->addFilter('stringTrim')->setValue($sectionId)->clearDecorators();
            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);
            if ($product === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
            }
            $name = new Zend_Form_Element_Text('name');
            $name->addFilter('stringTrim')->setValue($keyName)->setAttrib('class', 'keyName longtext')->setLabel($skillLabel)->addValidators($validatorsSkillsCovered);
            $i++;
            $removeKeyFeatures = new Zend_Form_Element_Button('remove');
            $removeKeyFeatures->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');

            if ($product !== 'new') {
                $elements = array($name,$resourceIdDom ,$removeKeyFeatures);
            } else {
                $elements = array($name,$resourceIdDom);
            }

            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());

            if ($rowForm->getElement('remove')) {
                $rowForm->getElement('remove')->removeDecorator('Label');
            }

            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        }       
        $subForm->setDecorators($this->getSubFormDecoratorsMain('skills', 'skills'));
        $addPrice = new Zend_Form_Element_Button('add');
        $addPrice->setLabel('Add More Skills')->setAttrib('class', 'btn btn-warning add');
        $subForm->addElement($addPrice);

        $subForm->setElementDecorators($this->getElementDecorators());
        $subForm->getElement('add')->removeDecorator('Label');
        $this->addSubForm($subForm, 'skills');

        $this->addElement('text', 'projectsDescription', array(
            'label' => 'Project Section Heading',
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'validators' => $validatorsProjectSectionTitle
        ));
        $this->addElement('hidden', 'projectTitleSectionId', array(
            'required' => false,
            'value' => ''
        ));
        $subForm = new Zend_Form_SubForm();
        $subForm->setName('projects');
        $i = 0;
        foreach ($session->projects as $product) {
            $projectName = isset($session->projectsData[$product]['name']) ? $session->projectsData[$product]['name'] : '';
            $content = isset($session->projectsData[$product]['content']) ? $session->projectsData[$product]['content'] : '';
            $companyIds = isset($session->projectsData[$product]['companyIds']) ? $session->projectsData[$product]['companyIds'] : '';
            $sectionId = isset($session->projectsData[$product]['sectionId']) ? $session->projectsData[$product]['sectionId'] : '';
            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);
            if ($product === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
            }
            $lableName = 'Project';
            if(!empty($i)){
                $lableName = 'Project '.$i;
            }
            $name = new Zend_Form_Element_Text('name');
            $name->addFilter('stringTrim')->setValue($projectName)->setAttrib('class', 'question longtext')->setAttrib('placeholder', '')->setLabel('Name of the Project')->addValidators($validatorsProjectTitle);
            $i++;
            $companyContent = new Zend_Form_Element_Textarea('content');
            $companyContent->addFilter('stringTrim')->setValue($content)->setAttrib('class', 'faqDescription longtext')->setAttrib('placeholder', 'Project Content')->setLabel('Project Content')->addValidators($validatorsProjectContent);
            $companies = new Zend_Form_Element_Select('companyIds');
            $companies->setOptions(array('multioptions' => array(0=>'--Select--')+$this->getProjectCompanies()))->setValue($companyIds)->setAttrib('class', 'companyIds')->setLabel('Select Company Logo');
            $resourceIdDom = new Zend_Form_Element_Hidden('sectionId');
            $resourceIdDom->addFilter('stringTrim')->setValue($sectionId)->clearDecorators();

            $removeSetsNumber = new Zend_Form_Element_Button('remove');
            $removeSetsNumber->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove pro-btn-remove')->setAttrib('onclick', 'removeSubFormElement(this)');
            if ($product !== 'new') {
                $elements = array($name, $companyContent, $companies,$resourceIdDom, $removeSetsNumber);
            } else {
                $elements = array($name, $companyContent, $companies,$resourceIdDom);
            }
            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());
            if ($rowForm->getElement('remove')) {
                $rowForm->getElement('remove')->removeDecorator('Label');
            }
            $rowForm->setDecorators($this->getSubFormDecorators());
            $rowForm->setLegend($lableName);
            $subForm->addSubForm($rowForm, $product);
        }
        $subForm->setDecorators($this->getSubFormDecoratorsMain('projects', 'projects'));
        $addPrice = new Zend_Form_Element_Button('add');
        $addPrice->setLabel('Add Projects')->setAttrib('class', 'btn btn-warning add last-btn');
        $subForm->addElement($addPrice);

        $subForm->setElementDecorators($this->getElementDecorators());
        $subForm->getElement('add')->removeDecorator('Label');
        $this->addSubForm($subForm, 'projects');
        $eligibilityId = null;
        $eligibility = '';
        if ($session->eligibility) {
            $eligibilityId = isset($session->eligibility['course_faq_id'])? $session->eligibility['course_faq_id']:null;
            $eligibility = isset($session->eligibility['question'])? $session->eligibility['question']: null;
        }
        $this->addElement('textarea', 'eligibility', array(
            'label' => 'Eligibility',
            'filter' => array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class' => 'fck-enable',
            'value' => $eligibility
        ));       
        $this->addElement('hidden', 'eligibility_id', array(
            'required' => false,
            'value' => $eligibilityId 
        ));
        $prerequisitesId = null;
        $prerequisites = '';
        if ($session->prerequisites) {
            $prerequisitesId = isset($session->prerequisites['course_faq_id'])?$session->prerequisites['course_faq_id']:null;
            $prerequisites = isset($session->prerequisites['question'])? $session->prerequisites['question']: null;
        }
        $this->addElement('textarea', 'Pre-requisites', array(
            'label' => 'Pre-requisites',
            'filter' => array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class' => 'fck-enable',
            'value' => $prerequisites
        ));
        $this->addElement('hidden', 'prerequisites_id', array(
            'required' => false,
            'value' => $prerequisitesId
        ));
        $batchbenefitsId = null;
        $batchbenefits ='';
        if ($session->batchBenefits) {
            $batchbenefitsId = isset($session->batchBenefits['course_faq_id'])? $session->batchBenefits['course_faq_id']:null;
            $batchbenefits = isset($session->batchBenefits['question'])? $session->batchBenefits['question']:null ;
        }
        $this->addElement('textarea', 'batchbenefits', array(
            'label' => ' Batch benefits *',
            'filter' => array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class' => 'fck-enable',
            'value' => !empty($batchbenefits)? $batchbenefits : '<ul><li>Learn from the world-class instructors with years of experience</li><li>Flexible learning schedule that works well with your busy schedule. Never miss a class!</li><li>Study and connect with peers around the world</li></ul>'
            
        ));
        $this->addElement('hidden', 'batchbenefits_id', array(
            'required' => false,
            'value' => $batchbenefitsId 
        ));
        
        $this->addElement('submit', 'save & proceed', array(
            'ignore' => true,
            'label' => 'Save & Proceed',
            'class' => 'btn btn-info'
        ));
    }

    /**
     * Get All companies
     * @return array
     */
    private function getProjectCompanies()
    {
        $modelProductSectionData = new Model_ProductSectionData();
        $projectList = $modelProductSectionData->fetchAll(array('sectionType = ?' => BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE_HIRING_COMPANIES, 'long_description LIKE ?' => '%projects%'));
        $returnArr = array();
        if (!empty($projectList)) {
            foreach ($projectList as $key => $value) {
                $returnArr[$value['id']] = $value['id'].' - '.$value['name'];
            }
        }
        if (!empty($returnArr)) {
            $returnArr = array_unique($returnArr);
        }
        return $returnArr;
    }

    protected function getSubFormDecoratorsMain($className, $id) {
        return array(   
            'FormElements',                        
            array(                
                'HtmlTag', array('tag' => 'ul')
            ),
            array(
                array('row' => 'HtmlTag'),                
                array('tag' => 'li', 'class' => $className, 'id' => $id)
            )
        );
    }
    protected function getElementDecorators(){
        $elementDecorators = array('ViewHelper',array(
                                                    array('data' => 'HtmlTag'),
                                                    array('tag' =>'div', 'class'=> 'element')
                                                ),
                                                'Errors',
                                                array(
                                                    'Label',
                                                     array('tag' => 'div')
                                                ),
                                                array(
                                                    array('row' => 'HtmlTag'),
                                                    array('tag' => 'li')
                                                )
                                );

        return $elementDecorators;
    }
    protected function getSubFormDecorators($className = 'subform')
    {
        return array(
            'FormElements',
            array('HtmlTag', array('tag' => 'ul'/*, 'data-role' => 'fieldset', 'role' => 'listitem'*/)),
            'Fieldset',
            array(
                array('row' => 'HtmlTag'),
                array('tag' => 'li', 'class' => $className)
            )
//             array('HtmlTag', array('tag' => 'li'/*, 'data-role' => 'listview', 'role' => 'list'*/))
        );
    }
    public function isValid($data)
    {
        $return = parent::isValid($data);
        $status = true;
        if(empty($data['batchbenefits'])){
            $this->getElement('batchbenefits')->setErrors(array("section should not be empty"));
                $status = false;
        }
         $return = $status;
        return $return;
    }
}

