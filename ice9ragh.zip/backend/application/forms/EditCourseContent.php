<?php

class Form_EditCourseContent extends BaseApp_Form
{
    private $_courseId;

    public function init(){
       
    }
    public function editCourseContent($courseId){
        $this->_courseId = $courseId;
        $this->setName('CourseContent');
        $this->setMethod('post');
         //adding Label name element
        $objCs = new Model_CourseSections();
        $sectionTemplates =$objCs->fetchAll(array('course_id = ?'=>$this->_courseId));
        foreach($sectionTemplates as $key => $value){
            $this->addElement('text',"inclusions_".$value['section_id'],array(
                'label'=>'Section Titles Within Pages',
                'required'=>true,
                'value'=>$value['name'],
                'class'=>'inclusions',
                'filter'=>array('StringTrim')
            ));
            $this->addElement('text',"inclusions_menu".$value['section_id'],array(
                'label'=>'Corressponding Menu Item',
                'required'=>true,
                'class'=>'inclusions',
                'value'=>$value['menuItem'],
                'filter'=>array('StringTrim')
            ));
         }

         $this->addElement('submit','Save',array(
            'ignore'=>true,
            'label'=>'Next',
            'class'=>'btn btn-info'
        ));
    }
    
}

