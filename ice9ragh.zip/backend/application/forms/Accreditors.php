<?php

class Form_Accreditors extends BaseApp_Form
{
    const TYPE_COURSE_PAGE='coursepage';
    const TYPE_NEW_COURSE_PAGE='newcoursepage';
    const TYPE_MASTER_COURSE_PAGE='mastercoursepage';
    const TYPE_CATEGORY_COURSE_PAGE='categorycoursepage';
    const TYPE_VENDOR_COURSE_PAGE='vendorcoursepage';
    protected $pageTypes = array();
    public function init(){

        $this->setName('Accreditors');
        $this->setMethod('post');
        $this->pageTypes=array(
                                self::TYPE_COURSE_PAGE=>'Course Page'
                               ,self::TYPE_NEW_COURSE_PAGE=>'New Course Page'
                               ,self::TYPE_CATEGORY_COURSE_PAGE=>'Category Course Page'
                               ,self::TYPE_VENDOR_COURSE_PAGE=>'Vendor Course Page'
                               ,self::TYPE_MASTER_COURSE_PAGE=>'Master Course Page'
                            );
        $this->addElement('text','name',array(
            'label'=>'Name',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('text','imagePath',array(
            'label'=>'Image Url',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                new BaseApp_Validate_Image('accreditors', 'imagePath', true)
            )
        ));

        $this->addElement('text','semImagePath',array(
            'label'=>'SEM Page Image Url',
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
        ));
        $this->addElement('select', 'page_type', array(
            'label' => 'Page Type',
            'required' => true,
            'class' => 'multiple skipPreviousClick',
            'multiple' => true,
            'registerInArrayValidator' => false,
            'multioptions' => $this->pageTypes
        ));
        $this->addElement('textarea','details',array(
            'label'=>'Details',
            'required'=>false,
            'cols' => 60,
            'rows' => 6,
            'class' =>'fck-enable'
        ));

        $this->addElement('text','link',array(
            'label'=>'Link',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                new BaseApp_Validate_Url()
            )
        ));

        $this->addElement('checkbox','isPromoted',array(
            'label'=>'Is Promoted','value'=>0
        ));
        
        $this->addElement('text','className',array(
            'label'=>'Class Name',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('checkbox','isDefault',array(
            'label'=>'Is Default','value'=>1
        ));

        $this->addElement('text','label',array(
            'label'=>'Label',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('text','eep_id',array(
            'label'=>'Eep Id',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));
        $this->addElement('submit','Add Accreditor',array(
          'ignore'=>true,
          'label'=>'Add Accreditor',
          'class'=>'btn btn-info'
         ));
         
         $validatorsName = array(new Zend_Validate_StringLength(array('max' => 100)));
         $this->getElement('name')->addValidators($validatorsName);         
    }
}