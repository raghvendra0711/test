<?php

class Form_CourseContentBenefits extends BaseApp_SubForm {
    
    private $_trainingId = '';
    private $_showAnswerField = true;
    public $isCityForm = false;
    
    public function __construct($isCityForm = false) {
        $this->isCityForm = $isCityForm;
        parent::__construct();
    }
    
    public function init() {
        $this->setName('courseBenefits');
        $this->setMethod('post');
        //adding Label name element
        
        $session = new Zend_Session_Namespace('form');
        $subForm = new Zend_Form_SubForm();
        $subForm->setName('contentCourse');     
        $product = 'new';   
        $faqId = isset($session->contentCourseData[$product]['faq_id']) ? $session->contentCourseData[$product]['faq_id'] : '';
        $keyQuestion = isset($session->contentCourseData[$product]['question']) ? $session->contentCourseData[$product]['question'] : '';
        $keyAnswer = isset($session->contentCourseData[$product]['answer']) ? $session->contentCourseData[$product]['answer'] : '';
        $keyJumpTo = isset($session->contentCourseData[$product]['jump_to_section']) ? $session->contentCourseData[$product]['jump_to_section'] : '';
        $keyCountryIds = isset($session->contentCourseData[$product]['countryIds']) ? $session->contentCourseData[$product]['countryIds'] : array();
        $allCountriesFlag = isset($session->contentCourseData[$product]['allCountries']) ? $session->contentCourseData[$product]['allCountries'] : 0;
        
        $rowForm = new Zend_Form_SubForm();
        $rowForm->setName($product);
        
        $classfck = 'fck-enable';
        if ($product === '__template__') {
            $rowForm->setAttrib('style', 'display: none;');
            $classfck = '';
        }
        
        $resourceIdDom = new Zend_Form_Element_Hidden('course_faq_id');
        if(! $this->isCityForm){
            $resourceIdDom->setValue($faqId)->clearDecorators();
        }else{
            $resourceIdDom->setValue($faqId)->setLabel('Job positions:')->setDecorators(array(
                array('Label',
                        array('class' => 'job-profiles-label'))
            ));
        }
        
        //Country
        if(! $this->isCityForm){
            $country = new Zend_Form_Element_Select('country_id');
            $countryModel = new Model_Country();
            $keyCountry = !empty($keyCountryIds) ? explode(',', $keyCountryIds) : array();
            $country->setOptions(array('required' => true))
            ->setValue($keyCountry)
            ->setLabel('Country')
            ->setRegisterInArrayValidator(false)
            ->setAttrib('onClick', 'clearSalaries()')
            ->setAttrib('options', array(0=> 'United States', 6=> 'India'));                                       
        }

        if($this->_showAnswerField){
            $answer = new Zend_Form_Element_Textarea('answer');
            $answer->addFilter('stringTrim')
            ->setValue($keyAnswer)
            ->setAttrib('class', !$this->isCityForm ? $classfck :'fck-enable-intro')
            ->setAttrib('rows', 5)
            ->setAttrib('cols', 60)
            ->setAttrib('required', true)
            ->setLabel('Intro');
        }
        
        $removeFaq = new Zend_Form_Element_Button('remove');
        $removeFaq->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');
               
        $elements = array();
        if($this->_showAnswerField){
            if($this->isCityForm){
                $elements = array($answer, $resourceIdDom);
            }else{
                $elements = array($country, $answer, $resourceIdDom);
            }
        }else{
            if($this->isCityForm){
                $elements = array($answer, $resourceIdDom);
            }else{
                $elements = array($country, $answer, $resourceIdDom);
            }
        }
        if ($product !== 'new') {
            $elements[] = $removeFaq;
        }
        
        $rowForm->addElements($elements);
        $rowForm->setElementDecorators($this->getElementDecorators());
        
        if ($rowForm->getElement('remove')) {
            $rowForm->getElement('remove')->removeDecorator('Label');
        }
        
        if ($rowForm->getElement('invert')) {
            $rowForm->getElement('invert')->removeDecorator('Label');
        }
        //Adding job desgnation sub form
        $jdSubForm = $this->_createJobDesignationSubForm($session->contentCourse, $session->contentCourseData);
        $rowForm->addSubForm($jdSubForm, 'job designation');
        
        $rowForm->setDecorators($this->getSubFormDecorators());
        $subForm->addSubForm($rowForm, $product);                                  
        $subForm->setDecorators($this->getSubFormDecoratorsMain('course-faq-editor', 'contentCourse'));
        
        $this->addSubForm($subForm, 'contentCourse');
        
        if($this->isCityForm){
            $this->addElement('button', 'Save', array(
                'ignore' => true,
                'class' => 'btn btn-success',
                'label' => 'Save',
            ));
        }else{
            $this->addElement('submit', 'Save', array(
                'ignore' => true,
                'label' => 'Save',
            ));
        }
        $this->addElement('button', 'Cancel', array(
            'label' => 'Cancel',
            'ignore' => true,
            'id' => 'cancel_form',
            'class' => 'btn btn-warning'
        ));
    }
    
    /**
    * Creates a sub form which is going to encapsulate the individual subforms of each Job Designation
    * @formTypes include _template_ and new
    * We create the subform for _template_ and hide it and use it to add more rows
    * When you click on the add Job , the subform created for _template_ will be copied , form names changed
    * and added back to the form. 
    * @return jdSubForm subform with two forms for jobs one is _template_ which will be hidden and other visible.
    */
    private function _createJobDesignationSubForm($formTypes, $data) {
        $jdSubForm = new Zend_Form_SubForm();
        $jdSubForm->setName('jobs Container');
        foreach ($formTypes as $product) {
            if (!empty($product)){
                $formData = isset($data[$product]) ? $data[$product]: array();
                if(!empty($formData['jobdesignation'])){
                    foreach($formData['jobdesignation'] as $key => $jobData){
                        if ($key === '__template__') {
                            continue;
                        }
                        $jdSubForm->addSubForm($this->_getJobDesignationSubForm($key, $jobData), $key);
                    }                
                } else {
                    $jdSubForm->addSubForm($this->_getJobDesignationSubForm($product), $product);
                }
            }
        }
        $jdSubForm->setDecorators($this->getSubFormDecoratorsMain('job-designation-container', 'jobs'));         
        if(!$this->isCityForm){
            $addJob = new Zend_Form_Element_Button('add');
            $addJob->setLabel('Add Job')->setAttrib('class', 'btn btn-success add');
            $jdSubForm->addElement($addJob);  
        }

        return $jdSubForm;
    }
    
    /**
    * Function to create the individual subform of each job description. 
    * Which will be copied later on clicking add job
    * @return jdForm sub form of job designation. salary and company fields.
    */
    private function _getJobDesignationSubForm($type, $values= array()) {
            $jdForm = new Zend_Form_SubForm();
            $jdForm->setElementDecorators($this->getJobFormElementDecorators());        
            $jdForm->setName($type);
            
            if ($type === '__template__') {
                $jdForm->setAttrib('style', 'display: none;');
            }

            //Elements
            if($this->isCityForm){
                $jdForm->addElement('text', 'designation', array(
                    'label' => ($type === '__template__') ? 'Job position ':  (isset($values['designation']) && !empty($values['designation']) ? $values['designation']: 'Job position '. ($type+ 1)),
                    'required' => ($type === '__template__') ? false : true,
                    'filters' => array('StringTrim'),
                    'placeholder' => 'Job Designation',
                    'readonly' => true,
                    'class' => 'sal-req jobDesignation hide',
                    //'value' => isset($values['designation']) && !empty($values['designation']) ? $values['designation']: '' ,
                    'validators' => array(
                        array(new Zend_Validate_StringLength(array('max' => 32)))
                    )
                ));

                $designationElement = $jdForm->getElement('designation')->setDecorators(array(
                    array('Label',
                            array('class' => 'designation-label'))
                ));
            }else{
                $jdForm->addElement('text', 'designation', array(
                    'label' => ($type === '__template__') ? 'Job position ':  'Job position '. ($type+ 1),
                    'required' => ($type === '__template__') ? false : true,
                    'filters' => array('StringTrim'),
                    'placeholder' => 'Job Designation',
                    'class' => 'sal-req jobDesignation',
                    'value' => isset($values['designation']) ? $values['designation']: '' ,
                    'validators' => array(
                        array(new Zend_Validate_StringLength(array('max' => 32)))
                    )
                ));
            }
            if(! $this->isCityForm){
                $jdForm->addElement('button', 'get-salary', array(
                    'label'=> 'Get Salary',
                    'class' => 'btn btn-info get-salary',
                    'onClick' => 'getSalaryDetails(this, "'.JOB_SALARIES_API.'")'
                ));
            }

            $jdForm->addElement('text', 'min', array(
                'filters' => array('StringTrim'),
                'required' => ($type === '__template__') ? false : true,
                'class' => 'shorttext min-salary sal-req',
                'placeholder' => 'Min Salary',
                'value' => isset($values['min']) ? $values['min']: ''
            ));
            
            $jdForm->addElement('text', 'avg', array(
                'filters' => array('StringTrim'),
                'required' => ($type === '__template__') ? false : true,
                'class' => 'shorttext avg-salary sal-req',
                'placeholder' => 'Average Salary',
                'value' => isset($values['avg']) ? $values['avg']: ''
            ));
            
            $jdForm->addElement('text', 'max', array(
                'filters' => array('StringTrim'),
                'required' => ($type === '__template__') ? false : true,
                'class' => 'shorttext max-salary sal-req',
                'placeholder' => 'Max Salary',
                'value' => isset($values['max']) ? $values['max']: ''
            ));       
                  
            if(!$this->isCityForm){
                $selectHiringCompanies= $this->_getHiringCompaniesForSelect();
                $jdForm->addElement('select', 'hiring_companies', array(
                    //'required' => ($type === '__template__') ? false : true,
                    'label' => 'Hiring Companies',
                    'size' => 12,
                    'data-name'=> $type,
                    'class' => 'multiple',
                    'registerInArrayValidator' => false,
                    //'value' => isset($values['hiring_companies']) ? $values['hiring_companies']: '',
                    'multioptions' => $selectHiringCompanies
                ));
            
                $jdForm->addElement('hidden', 'company_ids', array(
                    'required' => ($type === '__template__') ? false : true,
                    'value' => !empty($values['company_ids']) ? $values['company_ids']: '',
                ));
            }

            $jdForm->addElement('hidden', 'section_id', array(
                'required' => false,
                'class'=>'hidSectionId',
                'value' => isset($values['section_id']) ? $values['section_id']: ''
            ));

            $jdForm->addElement('hidden', 'section_map_id', array(
                'required' => false,
                'class'=>'hidSectionMapId',
                'value' => isset($values['section_map_id']) ? $values['section_map_id']: ''
            ));

            if(! $this->isCityForm){
                $removeForm = new Zend_Form_Element_Button('remove');
                $removeForm->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');
                if ($type !== 'new') {
                    $jdForm->addElement($removeForm);
                }
            }
            
            $jdForm->setDecorators($this->getSubFormDecorators());
        return $jdForm;
        
    }

    private function _getHiringCompaniesForSelect(){
        $obj = new Model_ProductSectionData();
        $cond = array(
            'sectionType = ?' => BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_HIRING_COMPANIES, 
            'long_description like ?' => '%'.BaseApp_Dao_ProductTypes::DESCRIPTION_VALUE_FOR_BENIFIT_COMAPNIES.'%',
            'status = ?' => 1
        );
        $hiringCompanies = $obj->fetchAll($cond);
        $returnSelectArray = array();
        if (!empty($hiringCompanies)){
            foreach( $hiringCompanies as $company) {
                $returnSelectArray[$company['id']] = $company['name'] .' - '. $company['id']; 
            }

        }
       return $returnSelectArray;
    }

    protected function getJobFormElementDecorators()
    {
        $elementDecorators = array(
            'ViewHelper',
            array(
                array('data' => 'HtmlTag'),
                array('tag' =>'div', 'class'=> 'element')
            ),
            'Errors',
            array(
                'Label',
                array('tag' => 'div')
            ),
            array(
                array('row' => 'HtmlTag'),
                //array('tag' => 'li')
            )
        );

        return $elementDecorators;
    }
    
    protected function getBenefitsFormDecorators($className, $id)
    {
        return array(
            'FormElements',
        array('HtmlTag', array('tag' => 'ul'/*, 'data-role' => 'fieldset', 'role' => 'listitem'*/)),
        'Fieldset',
        array(
            array('row' => 'HtmlTag'),
            array('tag' => 'li',  'class' => $className, 'id' => $id)
            )
            //             array('HtmlTag', array('tag' => 'li'/*, 'data-role' => 'listview', 'role' => 'list'*/))
        );
    }
    
    
    protected function getSubFormDecoratorsMain($className, $id) {
        return array(
            'FormElements',
            array(
                'HtmlTag', array('tag' => 'ul')
            ),
            array(
                array('row' => 'HtmlTag'),
                array('tag' => 'li', 'class' => $className, 'id' => $id)
                )
            );
        }
        
        public function removeUneditableElements() {
            return false;
        }
        
        public function isValid($data, &$errorMessage='',$showAnswerField=true) {
            $status = parent::isValid($data);
            if (!empty($data['contentCourse'])) {
                $subForm = 'contentCourse';
                foreach ($data['contentCourse'] as $key => $row) {                                                   
                    if (empty($row['answer'])) {
                        $status = false;
                        $this->getSubForm($subForm)->getSubForm($key)->getElement('answer')->setErrors(array("Please enter answer."));                        
                    } else {
                        //Removing &nbsp and html tags and replacing new lines with spaces to count the number of characters
                        $answerText = trim(preg_replace('/\s+/', ' ', strip_tags(html_entity_decode($row['answer']))));
                        if (strlen($answerText) > 320) {
                            $status = false;
                            $this->getSubForm($subForm)->getSubForm($key)->getElement('answer')->setErrors(array("Value is more than 320 characters long"));
                        }
                    }                    
                    if (isset($row['jobdesignation'])){
                        foreach($row['jobdesignation'] as $jobKey=>$job){
                            if (!($job['max']>$job['avg']) && !($job['avg']>$job['min'])){                                
                                $status = false;
                                $this->getSubForm($subForm)->getSubForm($key)->getSubForm('job designation')->getSubForm($jobKey)->getElement('designation')->setErrors(array("Salary values must be incremental"));
                            }  
                            
                        }
                    }
                }
                return $status;
            }
        }
    }
    