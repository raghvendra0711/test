
<?php

class Form_SeoUrls extends BaseApp_Form
{

    private $_courseId = null;

    const LABEL_SEO_URLS = 'seo _urls';

    public function __construct($courseId = false, $new = true)
    {
        if ($courseId) {
            $this->_courseId = $courseId;
        }
        $this->init($courseId);
        $this->loadDefaultDecorators();
    }

    public function init($courseId)
    {
        $this->setName('SeoUrls');
        $this->setMethod('post');
        $this->setAttrib('class', 'courseForm');

        $this->addElement('textarea', self::LABEL_SEO_URLS, array(
            'label' => 'Add Urls',
            'filter' => array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class' => 'faqDescription longtext',
        ));
        $this->getElement(self::LABEL_SEO_URLS)->setDescription('eg : /pmp-plus-bundle-masters-program(No special characters) To add more urls press Enter.');
        $this->addElement('file', 'seoUrlsCsv', array(
            'label' => 'Or Upload A csv File',
            'required' => false,
            'destination' => sys_get_temp_dir(),
            'validators' => array(array('Extension', true, 'csv'))
        ));
        $this->getElement('seoUrlsCsv')->setDescription('List of all urls must be in a single column.');
        $this->addElement('checkbox', 'reindex', array(
            'label' => 'Reindex',
            'required' => false
        ));
        $this->addElement('checkbox', 'purge', array(
            'label' => 'purge',
            'required' => false
        ));
        $this->addElement('submit', 'Save', array(
            'ignore' => true,
            'label' => 'Save',
            'class' => 'btn btn-info'
        ));
    }

    public function isValid($data)
    {
        $status = parent::isValid($data);
        if (!$data['reindex'] && !$data['purge']) {
            $this->getElement('purge')->setErrors(array("should check either reindex or purge"));
            $status = false;
        }
        return $status;
    }
}
