<?php

class Form_Banner extends BaseApp_Form
{

    public function __construct($bannerId = false,$bannerData = false) {
        if($bannerId){
            $this->edit($bannerId,$bannerData);
        }else{
            $this->init();    
        }
        $this->setElementDecorators($this->getElementDecorators());
        $this->setupFormDecorators();
    }
    public function init(){

        $this->setName('HomePageOffers');
        $this->setMethod('post');


        $this->addElement('text','banner_name',array(
            'label'=>'Name*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'placeholder'=>'Banner Name'
        ));
        
        $this->addElement('text','coupon_id',array(
            'required'=>true,
            'label' => 'Coupon Id for Banner*', 
            'class'=>'longtext',
            'placeholder'=>'Coupon Id'
        ));
				
				$this->addElement('checkbox','auto_apply_coupon',array(
            'required'=>false,
            'id'=>'auto_apply_coupon',
            'name'=>'auto_apply_coupon',
            'label'=>'Auto Apply Coupon',
						'value'=>0
        ));
				
        $this->addElement('checkbox','offer_bundle_id',array(
            'required'=>false,
            'id'=>'offer_bundle_id',
            'name'=>'offer_bundle_id',
            'label'=>'Is For Bundle',
            'value'=>0
        ));

        $this->addElement('select','offer_bundle_list',array(
            'label'=>'Bundle list (Max 3)',
            'id'=>'offer_bundle_list',
            'size' => 4,
            'registerInArrayValidator' => false,
            'required' => false,
            'class' => 'courseListAll',
        ));

        $this->addElement('hidden', 'bundle_hidden_sort_add', array(
            'required' => false,
            'id'=>'bundle_hidden_sort_add',
            'value'=>''
        ));

        $this->addElement('text','pull_down_image',array(
            'label'=>'Pull down banner Image*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                new BaseApp_Validate_Image('ebooks', 'thumb_image')
            )
        ));


         $this->addElement('text','horizontalstrip_desktop',array(
            'label'=>'Horizontal Strip Image For Desktop*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                new BaseApp_Validate_Image('ebooks', 'thumb_image')
            )
        ));


         $this->addElement('text','horizontalstrip_ipad',array(
            'label'=>'Horizontal Strip For Ipad*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                new BaseApp_Validate_Image('ebooks', 'thumb_image')
            )
        ));

         $this->addElement('text','horizontalstrip_mobile',array(
            'label'=>'Horizontal Strip For Mobile*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                new BaseApp_Validate_Image('ebooks', 'thumb_image')
            )
        ));


         $this->addElement('text','large_popup_image',array(
            'label'=>'large Pop up Image*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                new BaseApp_Validate_Image('ebooks', 'thumb_image')
            )
        ));

         $this->addElement('text','small_popup_image',array(
            'label'=>'Small Pop up Image*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                new BaseApp_Validate_Image('ebooks', 'thumb_image')
            )
        ));

         $this->addElement('text','validFrom',array(
            'label'=>'Banner Start Date*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'datepicker'
        ));

        $this->addElement('text','validto',array(
            'label'=>'Banner End Date*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'datepicker'
        ));
         
         $this->addElement('submit','Save Banner',array(
          'ignore'=>true,
          'class'=>'btn btn-info',
          'label'=>'Submit'
         ));
    }

    public function edit($bannerId,$bannerData){

        $this->setName('HomePageOffers');
        $this->setMethod('post');

        $this->addElement('text','banner_name',array(
            'label'=>'Name*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'placeholder'=>'Banner Name'
        ));
        
        $this->addElement('text','coupon_id',array(
            'required'=>true,
            'label' => 'Coupon Id for Banner*', 
            'class'=>'longtext',
            'placeholder'=>'Coupon Id'
        ));

				$this->addElement('checkbox','auto_apply_coupon',array(
            'required'=>false,
            'id'=>'auto_apply_coupon',
            'name'=>'auto_apply_coupon',
            'label'=>'Auto Apply Coupon',
						'value'=>isset($bannerData['auto_apply_coupon']) ? $bannerData['auto_apply_coupon'] : 0
        ));
				
        $this->addElement('checkbox','offer_bundle_id_selected',array(
            'id'=>'offer_bundle_id_selected',
            'name'=>'offer_bundle_id_selected',
            'label'=>'Is For Bundle',
            'value'=>0
        ));

        $bundleIds = array();
        $bundleData = array();
        if($bannerData['offer_bundle_id_selected']){
            $couponObj =new Model_Coupons();
            $couponData = current($couponObj->fetchAll(array('coupon_id =?'=>$bannerData['coupon_id'],'validto >= ?' => time()),array('columns'=>'bundle_id'),false));
            if(!empty($couponData)){
                $bundleIds = explode(',',$couponData['bundle_id']);
                $objBundle = new Model_Bundles();
                $bundleData = $objBundle->fetchForSelect(array('bundle_id in (?)'=>$bundleIds),array('order' => array('name DESC')));
            }
        }
        
        $this->addElement('select','offer_bundle_list_selected',array(
            'label'=>'Bundle list (Max 3)',
            'id'=>'offer_bundle_list_selected',
            'size' => 4,
            'class' => 'courseListAll',
            'registerInArrayValidator' => false,
            'multioptions'=> empty($bundleData) ? array('No Bundles Selected') : $bundleData,
            'value'=>isset($bannerData['offer_bundle_list']) ? $bannerData['offer_bundle_list'] : ''
        ));
        
        $this->addElement('hidden', 'bundle_hidden_sort', array(
            'required' => false,
            'id'=>'bundle_hidden_sort',
            'value' =>isset($bannerData['offer_bundle_list']) ? implode(',', $bannerData['offer_bundle_list']) : ''
        ));
        

        $this->addElement('text','pull_down_image',array(
            'label'=>'Pull down banner Image*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                new BaseApp_Validate_Image('ebooks', 'thumb_image')
            )
        ));


         $this->addElement('text','horizontalstrip_desktop',array(
            'label'=>'Horizontal Strip Image For Desktop*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                new BaseApp_Validate_Image('ebooks', 'thumb_image')
            )
        ));


         $this->addElement('text','horizontalstrip_ipad',array(
            'label'=>'Horizontal Strip For Ipad*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                new BaseApp_Validate_Image('ebooks', 'thumb_image')
            )
        ));

         $this->addElement('text','horizontalstrip_mobile',array(
            'label'=>'Horizontal Strip For Mobile*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                new BaseApp_Validate_Image('ebooks', 'thumb_image')
            )
        ));


         $this->addElement('text','large_popup_image',array(
            'label'=>'large Pop up Image*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                new BaseApp_Validate_Image('ebooks', 'thumb_image')
            )
        ));

         $this->addElement('text','small_popup_image',array(
            'label'=>'Small Pop up Image*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                new BaseApp_Validate_Image('ebooks', 'thumb_image')
            )
        ));

         $this->addElement('text','validFrom',array(
            'label'=>'Banner Start Date*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'datepicker'
        ));

        $this->addElement('text','validto',array(
            'label'=>'Banner End Date*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'datepicker'
        ));
         
         $this->addElement('submit','Save Banner',array(
          'ignore'=>true,
          'class'=>'btn btn-info',
          'label'=>'Submit'
         ));
    }

    protected function getElementDecorators(){
        $elementDecorators = array('ViewHelper',array(
                                                    array('data' => 'HtmlTag'),
                                                    array('tag' =>'div', 'class'=> 'element')
                                                ),
                                                'Errors',
                                                array(
                                                    'Label',
                                                     array('tag' => 'div')
                                                ),
                                                array(
                                                    array('row' => 'HtmlTag'),
                                                    array('tag' => 'li')
                                                )
                                );

        return $elementDecorators;
    }

    protected function setupFormDecorators(){
        $this->setDecorators(array('FormElements',
                                    array('HtmlTag', array('tag' => 'ul'/*, 'data-role' => 'listview', 'role' => 'list'*/)),
                                    'Form'
                                  )
                            );
    }

    /**
     * Overwrite parent function
     * Format data: trim csv
     * @return array
     */
    public function getValues($suppressArrayNotation = false) {
        $values = parent::getValues($suppressArrayNotation = false);
        $couponIds = array_map('trim', explode(',',$values['coupon_id']));
        $values['coupon_id'] = implode(',', $couponIds);
        return $values;
    }
    
    public function isValid($data) {   
        $status = parent::isValid($data);
        $objCoupon = new Model_Coupons();
        $couponIds = array_map('trim', explode(',',$data['coupon_id']));
        $condition = array('coupon_id in (?)' => $couponIds, 'validto >= ?' => time());
        $couponData = $objCoupon->fetchAll($condition);
        $errorMessage = array();
        $status = true;

        // Change array to associative array with key coupon_id
        foreach($couponData as $i=>$coupon) {
            $couponId = $coupon['coupon_id'];
            $couponData[$couponId] = $coupon;
            unset($couponData[$i]);
        }
        $coutryList = array();
        foreach($couponIds as $couponId) {
            // coupon validation
            if(empty($couponData[$couponId])){
                $errorMessage[] = "Invalid Coupon '$couponId' selected.!!!\n";
                $status = false;
                continue;
            }
            $coupon = $couponData[$couponId];
            
            // Country validation
            $currentCountry = array();
            if(!empty($coupon['country_id'])) {
                $currentCountry = explode(",", $coupon['country_id']);
            }
            if(empty($coutryList)) {
                $coutryList = $currentCountry;
            } else {
                if(count($coutryList) != count($currentCountry) || !empty(array_diff($coutryList, $currentCountry))) {
                    $errorMessage[] = "All Coupon should have same set of country list '$couponId'.!!!\n";
                    $status = false;
                    continue;
                }
            }
            if(strtotime($data['validFrom']) < $coupon['validFrom']){
                $errorMessage[] = "Banner Start Date cannot be less than coupon '$couponId' start date.!!!\n";
                $status = false;      
                continue;
            }

            if(strtotime($data['validto']) > $coupon['validto']){
                $errorMessage[] = "Banner End Date cannot be greater than coupon '$couponId' end date.!!!";
                $status = false;      
                continue;
            }
        }
        if(!$status) {
            $this->getElement('coupon_id')->setErrors($errorMessage);
        }
        
        return $status;
    }
}