<?php

class Form_TrustedBy extends BaseApp_Form
{

    public function init(){

        $this->setName('CourseAdvisors');
        $this->setMethod('post');
         //adding Label name element

        $this->addElement('text','name',array(
            'label'=>'Name*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'placeholder'=>'Name'
        ));

        $this->addElement('text','imageUrl',array(
            'label'=>'Logo Image Url*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'placeholder'=>'Image',
            'validators' => array(
                new BaseApp_Validate_Image('bundles', 'imageUrl')
            )
        ));

        $this->addElement('text','designation',array(
            'label'=>'Designation*',
            'required'=>true,
            'placeholder'=>'Designation',
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('text','alt_text',array(
            'label'=>'Alt Text',
            'required'=>false,
            'placeholder'=>'Alt text',
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
            
        ));

        $this->addElement('textarea','description',array(
            'label'=>'Description*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'class' =>'fck-enable'
        ));
        
        $bundle = new Model_Bundles();
        $this->addElement('select','bundle_id_arr',array(
                'label'=>'Associated Bundles*',
                'required'=>true,
                'multiple' => true,
                'registerInArrayValidator' => false,
                'class' => 'courseListAll',
                'multioptions'=>$bundle->fetchForSelect()
        ));
        
        $this->addElement('hidden','bundle_id_err',array(
                'required'=>false,
                'value'=>''
        ));

         $this->addElement('submit','Add Trusted By Logos',array(
          'ignore'=>true,
          'label'=>'Submit',
          'class'=>'btn btn-info'
         ));
        
        $validatorsLogoAndDirectorDesig = array(new Zend_Validate_StringLength(array('min' => 2,'max'=>40)));
        $validatorsDirectorDesc = array(new Zend_Validate_StringLength(array('min' => 2,'max'=>280)));
        $validatorsName = array(new Zend_Validate_StringLength(array('min' => 2,'max'=>40)));
        
        $this->getElement('name')->addValidators($validatorsName);
        $this->getElement('designation')->addValidators($validatorsLogoAndDirectorDesig);
        $this->getElement('description')->addValidators($validatorsDirectorDesc);
        
    }

    public function isValid($data) {
        $status = parent::isValid($data);
        if(!$status)
            return false;
            if(!empty($data['imageUrl'])){
                $data['imageUrl'] = trim($data['imageUrl']);
                $file_headers = @get_headers($data['imageUrl']);
                if(!$file_headers || $file_headers[0] == 'HTTP/1.1 404 Not Found') {
                    $this->getElement('imageUrl')->setErrors(array("'{$data['imageUrl']}' is not a valid image url"));
                    $status = false;
                }
            }
            if(!empty($data['bundle_id_arr'])){
                $obj =new Model_SectionMapping();
                $recordCount = $obj->getSectionCountByProduct($data['bundle_id_arr'], BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES,'trustedByLogos');
                $obj = new Model_Bundles();
                $bundles = $obj->fetchForSelect();
                $consumedBundles = array();
                if(!empty($recordCount)){
                    foreach ($recordCount as $record){
                        if($record['count'] >= 4)
                            $consumedBundles[] = $bundles[$record['linkable_id']];
                    }
                }
                if(!empty($consumedBundles)){
                    $this->getElement('bundle_id_err')->setErrors(array("4 trusted by logos already added to: ".implode(', ', $consumedBundles)."."));
                    $status = false;
                }
            }
        return $status;
    }
}