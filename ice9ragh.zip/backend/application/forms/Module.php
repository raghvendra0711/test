<?php

class Form_Module extends BaseApp_Form {

    public function init() {
        $this->addElement('text', 'name', array(
            'label' => 'Name'
        ));
        $this->addElement('textarea', 'url', array(
            'label' => 'Url'
        ));
        $this->addElement('submit', 'submit', array(
            'label' => 'Save'
        ));
    }

}
