<?php
/**
 * 
 */
class Form_Melvin_MarketingPage extends BaseApp_Form{
    public function init(){
        $this->setMethod('post');
        $this->setName('dripLeadForm');
        
        $courseMdl = new Model_Courses();
        $this->addElement('select','course_id',array(
            'label'=>'Select Course',
            'required'=>true,
            'multioptions'=>array(''=>'--Select--')+$courseMdl->fetchForSelect(array('is_dummy = ?' => 0, 'is_free = ?' => 0))
        ));

        $this->addElement('select','layout_id',array(
            'label'=>'Select Style',
            'required'=>true,
            'multioptions'=>array(
                0 =>'Generic',
                10 => 'PMP',
                12 => 'PRINCE2',
                15 => 'Big data and Hadoop',
                18 => 'ITIL',
                43 => 'Six Sigma',
                
            )
        ));
        
        $this->addElement('text','title',array(
            'label'=>'Title',
            'required'=>true,
            'class'=>'longtext'
        ));
        
        $this->addElement('text','headline',array(
            'label'=>'Headline',
            'required'=>true,
            'class'=>'longtext'
        ));
        
        $this->addElement('textarea','description',array(
            'label'=>'Description Top',
            'required'=>true,
            'rows'=>5,
            'cols'=>81
        ));
        
        for($i=1;$i<=15;$i++){
            $this->addElement('text','bullet'.$i,array(
                'label'=>'Bullet '.$i,
                'class'=>'longtext dripBullets'.($i>3?' hiddenElement':''),
                'serial'=>$i
            ));
        }
        
        $this->addElement('button','addDripBullets',array(
            'label'=>'Add Bullet'
        ));
        
        $this->addElement('textarea','bottomDescription',array(
            'label'=>'Bottom Description',
            'required'=>true,
            'rows'=>5,
            'cols'=>81
        ));

        $this->addElement('file','image',array(
            'label'=>'Lead Page Image',
            'required'=>true,
            'ValueDisabled'=>true,
            'validators'=>array('Extension'=>array('jpeg','png','jpg','gif'),
                          array('ImageSize',false,array('minwidth'=>271,'maxwidth'=>271,'minheight'=>220,'maxheight'=>220)),
                          array('Size', false, array('max' => 30720)))
        ));
        
        $this->addElement('select','pageType',array(
            'label'=>'Page Type',
            'required'=>true,
            'multioptions'=>array('download'=>'Downloadable', 'submit' => 'Submit Only')
        ));

        $this->addElement('file','downloadableFile',array(
            'label'=>'Downloadable File',
            'required'=>false,
            'ValueDisabled'=>true,
            'data-showif' => 'pageType=download'
        ));
        
        $this->addElement('select','testimonialType',array(
            'label'=>'Testimonial Type',
            'required'=>true,
            'multioptions'=>array('static'=>'Static')
        ));
        
        $this->addElement('text','formTitle',array(
            'label'=>'Form Title',
            'required'=>true,
            'class'=>'longtext'
        ));
        
        $this->addElement('text','submitButtonText',array(
            'label'=>'Submit Button Text',
            'required'=>true
        ));
        
        $this->addElement('submit','saveDripLead',array(
            'label'=>'Proceed',
            'ignore'=>true
        ));
    }
    
    public function removeOptionalValidators(){
        $this->getElement('image')->setRequired(false);
    }
}