<?php

class Form_Ios extends BaseApp_Form
{

    public function init(){

        $this->setName('Ios');
        $this->setMethod('post');

        $course = new Model_Courses();
        $this->addElement('select','ios_course_id',array(
            'required'=>true,
            'label' => 'Courses', 
            'registerInArrayValidator' => false,
            'multioptions'=>array('0' => '--Select--')+$course->fetchForSelect(array('is_dummy = ?' => 0, 'is_free = ?' => 0))
        ));
        

        $this->addElement('select','ios_access_days',array(
            'label'=>'Access Days',
            'required'=>true,
            'registerInArrayValidator' => false,
            'fetchDisabled' => 'true'
        ));
        
        $this->addElement('text','course_price',array(
            'label'=>'Price',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('submit','Save',array(
          'ignore'=>true,
          'label'=>'Save',
          'class'=>'btn btn-info'
         ));
    }

     public function removeUneditableElements(){
        $this->getElement('ios_course_id')->setAttrib('disabled', 'disabled');
        $this->getElement('ios_course_id')->setRequired(false);
        $this->removeElement('ios_access_days');
    }

    public function removeOptionalElements() {
        $this->removeElement('ios_course_id');
        $this->removeElement('ios_access_days');
    }
}

