<?php

class Form_Articles extends BaseApp_SubForm
{

    public function init(){
        $this->setName('Articles');
        $this->setMethod('post');
        
        $validatorsName = array(new Zend_Validate_StringLength(array('max' => 100)));
        $validatorsDescription = array(new Zend_Validate_StringLength(array('max' => 1000)));

        $this->addElement('text','name',array(
            'label'=>'Title of the Article*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('text','displayName',array(
            'label'=>'Display Name*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('textarea','shortDescription',array(
            'label'=>'Small Description',
            'required'=>false,
            'cols' => 60,
            'rows' => 6,
            'class'=>'longtext'
        ));

        $this->addElement('text','url',array(
            'label'=>'URL*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
        ));

        $this->addElement('text','imageUrl',array(
            'label'=>'Image URL*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                new BaseApp_Validate_Image('articles', 'imageUrl', true)
            )
        ));

        $course =new Model_Courses();
        $this->addElement('select','course_id',array(
            'label'=>'Courses (Maximum allowed '.Model_Articles::MAX_COURSES_ALLOWED_LINK.')',
            'required'=>false,
            'multiple' => true,
            'class' => 'multiple',
            'registerInArrayValidator' => false,
            'multioptions'=>$course->fetchForSelect(array('is_dummy = ?' => 0, 'is_free = ?' => 0))
        ));

        $label =new Model_Labels();
        $this->addElement('select','vertical',array(
            'label'=>'Verticals',
            'required'=>false,
            'multiple' => true,
            'class' => 'multiple',
            'registerInArrayValidator' => false,
            'multioptions'=>$label->getParentLabels()
        ));

        $this->addElement('select','label_id',array(
            'label'=>'Labels (Maximum allowed '.Model_Articles::MAX_CATEGORIES_ALLOWED_LINK.')*',
            'required'=>true,
            'multiple' => true,
            'class' => 'multiple',
            'registerInArrayValidator' => false,
            'multioptions'=>$label->fetchForSelect()
        ));
        

        $this->addElement('text','searchTags',array(
            'label'=>'Search Tags (comma separated)',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));        

        $this->addElement('text','authorName',array(
            'label'=>'Author Name',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));
        
        $this->addElement('text','authorDescription',array(
            'label'=>'About the Author',
            'required'=>false,
            'cols' => 60,
            'rows' => 6
        ));
        
        $this->addElement('text','authorImage',array(
            'label'=>'Author Image',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                new BaseApp_Validate_Image('articles', 'authorImage', true)
            )
        ));
        
        $this->addElement('text','authorLinkedinProfile',array(
            'label'=>'Author Linkedin Profile',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('text','authorTwitterProfile',array(
            'label'=>'Author Twitter Profile',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));
        
        
        $this->addElement('textarea','articleContent',array(
            'label'=>'Content*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class' =>'fck-enable'
        ));
        
        $this->addElement('checkbox','is_featured',array(
            'label'=>'Is Featured?',
            'required'=>false
        ));
        
        /*
        $this->addElement('checkbox','isInfographicUrlExists',array(
            'label'=>'Have Infographic URL?',
            'required'=>false
        ));
        
        $this->addElement('text','infographicUrl',array(
            'label'=>'Infographic URL',
            'placeholder'=>'Infographic URL',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                new BaseApp_Validate_Url()
            )
        ));
        
         * 
         */
        
        $session = new Zend_Session_Namespace('form');
        
        /**
         * Start: sub form for related Articles
         * 
         */
        
         $subForm = new Zend_Form_SubForm();
         $subForm->setName('relatedArticles');   
         foreach ($session->relatedArticles as $product) {
            $articleId = isset($session->relatedArticlesData[$product]['articleId'])?$session->relatedArticlesData[$product]['articleId']:'';
            $articleName = isset($session->relatedArticlesData[$product]['articleName'])?$session->relatedArticlesData[$product]['articleName']:'';
            
            
            
            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);  
            
            if ($product === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
            }
            
            $relatedArticleName = new Zend_Form_Element_Text('articleName');
            $relatedArticleName->addFilter('stringTrim')->setValue($articleName)->setAttrib('class', 'relatedArticle longtext')->setAttrib('placeholder', 'Article Name')->setAttrib('autocomplete', 'off')->setLabel('Article');
            
            $relatedArticleId = new Zend_Form_Element_Hidden('articleId');
            $relatedArticleId->addFilter('stringTrim')->setValue($articleId)->setAttrib('class', 'relatedArticleId longtext');
            
            $removeArticle = new Zend_Form_Element_Button('remove');
            $removeArticle->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');        
         
            if ($product !== 'new') {
                $elements = array($relatedArticleName, $relatedArticleId, $removeArticle);            
            }
            else {
                $elements = array($relatedArticleName, $relatedArticleId);            
            }            

            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());

            if($rowForm->getElement('remove')) {
                $rowForm->getElement('remove')->removeDecorator('Label');
            }
            
            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        }
        
        $subForm->setDecorators($this->getSubFormDecoratorsMain('relatedArticles', 'relatedArticles', 'relatedArticlesSectionMain'));

        $addPrice = new Zend_Form_Element_Button('add');
        $addPrice->setLabel('Add Article')->setAttrib('class', 'btn btn-warning add');
        $subForm->addElement($addPrice);

        $subForm->setElementDecorators($this->getElementDecorators());
        $subForm->getElement('add')->removeDecorator('Label');
        $subForm->setLegend('Related Articles');
        $this->addSubForm($subForm, 'relatedArticles');
        /**
         * End: sub form for related Articles
         * 
         */
        
        
        /**
         * Start: sub form for related Ebooks
         * 
         */
        
        
         $subForm = new Zend_Form_SubForm();
         $subForm->setName('relatedEBooks');   
         foreach ($session->relatedEbooks as $product) {
            $ebookId = isset($session->relatedEbooksData[$product]['ebookId'])?$session->relatedEbooksData[$product]['ebookId']:'';
            $ebookName = isset($session->relatedEbooksData[$product]['ebookName'])?$session->relatedEbooksData[$product]['ebookName']:'';
            
            
            
            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);  
            
            if ($product === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
            }
            
            $relatedEbookName = new Zend_Form_Element_Text('ebookName');
            $relatedEbookName->addFilter('stringTrim')->setValue($ebookName)->setAttrib('class', 'relatedEbook longtext')->setAttrib('placeholder', 'Ebook Name')->setAttrib('autocomplete', 'off')->setLabel('Ebook');
            
            $relatedEbookId = new Zend_Form_Element_Hidden('ebookId');
            $relatedEbookId->addFilter('stringTrim')->setValue($ebookId)->setAttrib('class', 'relatedEbookId longtext');
            
            $removeEbook = new Zend_Form_Element_Button('remove');
            $removeEbook->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');        
         
            if ($product !== 'new') {
                $elements = array($relatedEbookName, $relatedEbookId, $removeEbook);            
            }
            else {
                $elements = array($relatedEbookName, $relatedEbookId);            
            }            

            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());

            if($rowForm->getElement('remove')) {
                $rowForm->getElement('remove')->removeDecorator('Label');
            }
            
            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        }
        
        $subForm->setDecorators($this->getSubFormDecoratorsMain('relatedEbooks', 'relatedEbooks', 'relatedEbookSectionMain'));

        $addPrice = new Zend_Form_Element_Button('add');
        $addPrice->setLabel('Add Ebook')->setAttrib('class', 'btn btn-warning add');
        $subForm->addElement($addPrice);

        $subForm->setElementDecorators($this->getElementDecorators());
        $subForm->getElement('add')->removeDecorator('Label');
        $subForm->setLegend('Related Ebooks');
        $this->addSubForm($subForm, 'relatedEbooks');
        /**
         * End: sub form for related Ebooks
         * 
         */
        
        
         /**
         * Start: sub form for related Ebooks
         * 
         */        
         $subForm = new Zend_Form_SubForm();
         $subForm->setName('relatedWebinars');   
         foreach ($session->relatedWebinars as $product) {
            $webinarId = isset($session->relatedWebinarsData[$product]['webinarId'])?$session->relatedWebinarsData[$product]['webinarId']:'';
            $webinarName = isset($session->relatedWebinarsData[$product]['webinarName'])?$session->relatedWebinarsData[$product]['webinarName']:'';
            
            
            
            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);  
            
            if ($product === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
            }
            
            $relatedWebinarName = new Zend_Form_Element_Text('webinarName');
            $relatedWebinarName->addFilter('stringTrim')->setValue($webinarName)->setAttrib('class', 'relatedWebinar longtext')->setAttrib('placeholder', 'Webinar Name')->setAttrib('autocomplete', 'off')->setLabel('Webinar');
            
            $relatedWebinarId = new Zend_Form_Element_Hidden('webinarId');
            $relatedWebinarId->addFilter('stringTrim')->setValue($webinarId)->setAttrib('class', 'relatedWebinarId longtext');
            
            $removeWebinar = new Zend_Form_Element_Button('remove');
            $removeWebinar->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');        
         
            if ($product !== 'new') {
                $elements = array($relatedWebinarName, $relatedWebinarId, $removeWebinar);            
            }
            else {
                $elements = array($relatedWebinarName, $relatedWebinarId);            
            }            

            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());

            if($rowForm->getElement('remove')) {
                $rowForm->getElement('remove')->removeDecorator('Label');
            }
            
            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        }
        
        $subForm->setDecorators($this->getSubFormDecoratorsMain('relatedWebinars', 'relatedWebinars', 'relatedWebinarSectionMain'));

        $addPrice = new Zend_Form_Element_Button('add');
        $addPrice->setLabel('Add Webinar')->setAttrib('class', 'btn btn-warning add');
        $subForm->addElement($addPrice);

        $subForm->setElementDecorators($this->getElementDecorators());
        $subForm->getElement('add')->removeDecorator('Label');
        $subForm->setLegend('Related Webinars');
        $this->addSubForm($subForm, 'relatedWebinars');
        $this->postSetup(); 
        /**
         * End: sub form for related Webinars
         * 
         */
      
        $this->getElement('name')->addValidators($validatorsName);         
        $this->getElement('displayName')->addValidators($validatorsName);         
        $this->getElement('shortDescription')->addValidators($validatorsDescription);         
    }
    
    public function removeUneditableElements(){
        $this->removeElement('url');
        return false;
    }
    
    public function isValid($data) {        
        $status = parent::isValid($data);
        if(!empty($data['url'])){
            $data['url'] = trim($data['url']);
            $checkSlash = substr($data['url'], 0,1);
            if($checkSlash != '/'){
                $data['url'] = trim('/'.$data['url']);
            }
            $objSeo = new Model_Seo();
            if(false === $objSeo->validateUrl($data['url'])){
                $this->getElement('url')->setErrors(array("'{$data['url']}' is not a valid article url"));
                $status = false;   
            }
        }
        /*
        if($data['isInfographicUrlExists'] && !$data['infographicUrl']) {
            $this->getElement('infographicUrl')->setErrors(array("This value required"));
            $status = false;   
        }
         * 
         */
        
        $thumbImage = preg_replace("/(.*?).(jpg|png|gif|svgz|svg)/", "$1_th.$2",$data['imageUrl']);
        if($thumbImage == $data['imageUrl']) {
            $this->getElement('imageUrl')->setErrors(array("we do not support this file format. We support jpg,png,gif,svgz and svg. Please contact tech team"));
            $status = false;   
        }
        $pageHeaders = get_headers($thumbImage, 1);
        if(!preg_match("/HTTP\/(\d+)\.(\d+)(\s+)200(\s+)OK/", $pageHeaders[0])) {
            $this->getElement('imageUrl')->setErrors(array("Added url is invalid or thumbnail image of added url is missing"));
            $status = false;   
        }
        
        return $status;
    }
    
    protected function getSubFormDecoratorsMain($className, $id, $mainClass = '') {
        return array(   
            'FormElements',                        
            array(                
                'HtmlTag', array('tag' => 'ul', 'class' => $mainClass, 'id' => $mainClass)
            ),
            'Fieldset',
            array(
                array('row' => 'HtmlTag'),                
                array('tag' => 'li', 'class' => $className, 'id' => $id)
            )
        );
    }       
}