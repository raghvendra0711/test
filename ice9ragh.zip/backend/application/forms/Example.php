<?php

class Form_Example extends BaseApp_Form {
    
}
