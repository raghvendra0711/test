<?php

class Form_HiringCompanies extends BaseApp_Form
{
    const TYPE_BENEFITS_SECTION='benefitssection';
    const TYPE_PROJECTS_SECTION='projectssection';
    const TYPE_APP_INDUSTRY_SECTION ='universityindustrysection';
    const TYPE_MASTER_INDUSTRY_TRENDS='masterindustrytrends';
    
    protected $sectionTypes = array();
    
    public function __construct($data) {
         $this->init($data);
    }
    
    public function init($data){
        $this->setName('Hiring Companies');
        $this->setMethod('post');
        $this->loadDefaultDecorators();
        
        $this->sectionTypes = array(
            self::TYPE_BENEFITS_SECTION => 'Course Benefits Section', 
            self::TYPE_PROJECTS_SECTION => 'Projects Section',
            self::TYPE_APP_INDUSTRY_SECTION => 'University Learners Profile',
            self::TYPE_MASTER_INDUSTRY_TRENDS=>'Masters Program Industry Trends',
        );

        $this->addElement('text','name',array(
            'label'=>'Name of the company*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        )); 
        
        $this->addElement('text','alt_text',array(
            'label'=>'Image Alt tag*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));
        
        $this->addElement('text','description',array(
            'label'=>'Image Link (Optional)',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                new BaseApp_Validate_Url()
            )
        ));

        $this->addElement('select', 'long_description', array(
            'label' => 'Select where this will be shown*',
            'required' => true,
            'class' => 'multiple skipPreviousClick',
            'multiple' => true,
            'registerInArrayValidator' => false,
            'multioptions' => $this->sectionTypes
        ));

        if(!empty($data['imageUrl'])){
            $this->addElement('file','logo',array(
                'label'=>'Company Logo* (height:40px, 10kb)',
                'required'=>false,
                'destination'=>sys_get_temp_dir(),
                'validators' => array(
                    array('Extension', true, array('jpeg','png','jpg','gif')),
                    array('ImageSize',false, array('maxheight'=>40)),
                    array('Size',false, array('useByteString'=> true, 'max' => '10240')) 
            )));
            $this->addElement('text', 'logo_value', array(
                'label' => 'Company Logo Url',                
                'value' => @$data['imageUrl'],
                'helper' => 'formNote'                
            ));
        }else{
            $this->addElement('file','logo',array(
                'label'=>'Company Logo* (height:40px, 10kb)',
                'required'=>true,
                'destination'=>sys_get_temp_dir(),
                'validators' => array(
                    array('Extension', true, array('jpeg','png','jpg','gif')),
                    array('ImageSize',false, array('maxheight'=>40)),
                    array('Size',false, array('useByteString'=> true, 'max' => '10240')) 
            )));
        }
        
        
//        $this->addElement($this->createElement('file','certificate_image',array(
//            'label'=>'Certificate image',
//            'required'=>false,
//            'destination'=>sys_get_temp_dir(),
//            'validators'=>array('Extension'=>array('jpeg','png','jpg','gif'))
//        )));

        $this->addElement('submit','Add Hiring Companies',array(
          'ignore'=>true,
          'label'=>'Save',
          'class'=>'btn btn-info'
        ));
         
        $validatorsName = array(new Zend_Validate_StringLength(array('max' => 100)));
        $this->getElement('name')->addValidators($validatorsName);         
    }
    
    public function isValid($data) {
        $status = parent::isValid($data);
        if (!$status){
            return false;
        }
        if ( isset($data['logo']) && !empty($data['logo']['name']) ){
            $fileName = $data['logo']['name'];
            $fileName = explode(".", $fileName)[0];            
            if(!@preg_match('/^[A-Za-z0-9_-]+$/', $fileName)){
                $this->getElement('logo')->setErrors(array("File name can only be Alpha numerics with _ and - "));
                $status = false;
            }
        }
        return $status;
    }
}