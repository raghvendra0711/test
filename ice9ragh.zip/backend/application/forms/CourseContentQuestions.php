<?php

class Form_CourseContentQuestions extends BaseApp_SubForm {

    private $_trainingId = '';
    private $_showAnswerField = true;
    private $_allCountryDisable = false;
    private $_showB2bB2c = true;

    public function __construct($trainingId,$showAnswerField=true,$allCountryDisable = false,$showB2bB2c=true) {
        $this->_trainingId = $trainingId;
        $this->_showAnswerField = $showAnswerField;
        $this->_allCountryDisable = $allCountryDisable;
        $this->_showB2bB2c = $showB2bB2c;
        parent::__construct();
    }

    public function init() {
        $this->setName('courseContent');
        $this->setMethod('post');
        //adding Label name element

        $session = new Zend_Session_Namespace('form');

        $subForm = new Zend_Form_SubForm();
        $subForm->setName('contentCourse');
        foreach ($session->contentCourse as $product) {
            $faqId = isset($session->contentCourseData[$product]['faq_id']) ? $session->contentCourseData[$product]['faq_id'] : '';
            $keyQuestion = isset($session->contentCourseData[$product]['question']) ? $session->contentCourseData[$product]['question'] : '';
            $keyAnswer = isset($session->contentCourseData[$product]['answer']) ? $session->contentCourseData[$product]['answer'] : '';
            $keyJumpTo = isset($session->contentCourseData[$product]['jump_to_section']) ? $session->contentCourseData[$product]['jump_to_section'] : '';
            $isB2BValue = isset($session->contentCourseData[$product]['is_b2b']) ? $session->contentCourseData[$product]['is_b2b'] : null;
            $isB2CValue = isset($session->contentCourseData[$product]['is_b2c']) ? $session->contentCourseData[$product]['is_b2c'] : 1;
            $keyCountryIds = isset($session->contentCourseData[$product]['countryIds']) ? $session->contentCourseData[$product]['countryIds'] : array();
            $keyClusterIds = isset($session->contentCourseData[$product]['clusterIds']) ? $session->contentCourseData[$product]['clusterIds'] : array();
            $allCountriesFlag = isset($session->contentCourseData[$product]['allCountries']) ? $session->contentCourseData[$product]['allCountries'] : 0;

            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);

            $classfck = 'fck-enable';
            if ($product === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
                $classfck = '';
            }

            $resourceIdDom = new Zend_Form_Element_Hidden('course_faq_id');
            $resourceIdDom->setValue($faqId)->clearDecorators();



            //Country
            $country = new Zend_Form_Element_Select('country_id');
            $countryModel = new Model_Country();
            $keyCountry = !empty($keyCountryIds) ? explode(',', $keyCountryIds) : array();
            $country->setOptions(array('required' => false, 'multiple' => true, 'multioptions' => $countryModel->getListDisplay()))
                    ->setValue($keyCountry)->setAttrib('class', 'courseListAll countryListAll skipPreviousClick')
                    ->setLabel('Country')
                    ->setRegisterInArrayValidator(false);

            //Cluster
            $cluster = new Zend_Form_Element_Select('cluster_id');
            $clusterModel = new Model_Clusters();
            $keyCluster = !empty($keyClusterIds) ? explode(',', $keyClusterIds) : array();
            $cluster->setOptions(array('required' => false, 'multiple' => true, 'multioptions' => $clusterModel->fetchForSelect()))
                    ->setValue($keyCluster)->setAttrib('class', 'multiple clusterListAll selectedCluster')
                    ->setLabel('Cluster')
                    ->setAttrib('data-last-selected',$keyClusterIds)
                    ->setAttrib('onchange', 'countryByClusterSelect(this)')
                    ->setAttrib('data-isedit',!empty($faqId) ? true : false)
                    ->setRegisterInArrayValidator(false);

            //Check All Countries
            $allCountryChecked = 0;
            $isClusterCountryDisabled = false;
            if (empty($keyCluster) && empty($keyCountry)) {
                $allCountryChecked = 1;
                $isClusterCountryDisabled = true;
            }
            if (!empty($allCountriesFlag) && $allCountriesFlag == 1) {
                $allCountryChecked = 1;
            }
            $checkAllCountry = new Zend_Form_Element_Checkbox('all_country');
            $checkAllCountry->setValue($allCountryChecked)->setLabel('All Countries')->setAttrib('onclick', 'checkAllCountry(this)')->setAttrib('class','allCountry');

            if ($isClusterCountryDisabled) {
                $cluster->setOptions(array('disabled' => true));
                $country->setOptions(array('disabled' => true));
            }
            if($this->_allCountryDisable){
                $checkAllCountry->setAttrib('onclick','return false')->setAttrib('style', 'opacity: 0.5;');;
            }

            $question = new Zend_Form_Element_Text('question');
            $question->addFilter('stringTrim')->setValue($keyQuestion)->setAttrib('class', 'longtext')->setLabel('Question');

            $isB2b = new Zend_Form_Element_Checkbox('is_b2b');
            $isB2b->addFilter('stringTrim')->setValue($isB2BValue)->setAttrib('class', '')->setLabel('Is B2B');

            $isB2C = new Zend_Form_Element_Checkbox('is_b2c');
            $isB2C->addFilter('stringTrim')->setValue($isB2CValue)->setAttrib('class', '')->setLabel('Is B2C');

            if(!$this->_showB2bB2c){
                $isB2b->setAttrib('class','hideB2bB2c'); //class added to hide this dom
                $isB2C->setAttrib('class','hideB2bB2c');
            }

            if($this->_showAnswerField){
                $answer = new Zend_Form_Element_Textarea('answer');
                $answer->addFilter('stringTrim')->setValue($keyAnswer)->setAttrib('class', $classfck)->setAttrib('rows', 5)->setAttrib('cols', 60)->setLabel('Answer');
            }

            $jumpTo = new Zend_Form_Element_Checkbox('jump_to_section');
            $jumpTo->setValue($keyJumpTo)->setLabel('Add as JumpTo Section');

            $removeFaq = new Zend_Form_Element_Button('remove');
            $removeFaq->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');

            //Invert Selection
            $invertBtn = new Zend_Form_Element_Button('invert');
            $invertBtn->setLabel('Invert Countries')->setAttrib('class', 'btn btn-warning remove invert-all')->setAttrib('onclick', 'invertSelection(this)');
            if($allCountryChecked){
                $invertBtn->setOptions(array('disabled' => true));
            }
            $elements = array();
            if($this->_showAnswerField){
                $elements = array($checkAllCountry, $cluster, $country, $invertBtn, $question, $answer, $isB2C, $isB2b, $jumpTo, $resourceIdDom);
            }else{
                $elements = array($checkAllCountry, $cluster, $country, $invertBtn, $question, $isB2C, $isB2b, $jumpTo, $resourceIdDom);
            }
            if ($product !== 'new') {
                $elements[] = $removeFaq;
            }

            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());

            if ($rowForm->getElement('remove')) {
                $rowForm->getElement('remove')->removeDecorator('Label');
            }

            if ($rowForm->getElement('invert')) {
                $rowForm->getElement('invert')->removeDecorator('Label');
            }

            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        }

        $subForm->setDecorators($this->getSubFormDecoratorsMain('course-faq-editor', 'contentCourse'));
        /* if ($this->_addMoreButton) {
            $addFaq = new Zend_Form_Element_Button('add');
            $addFaq->setLabel('Add More')->setAttrib('class', 'btn btn-warning add');
            $subForm->addElement($addFaq);

            $subForm->setElementDecorators($this->getElementDecorators());
            $subForm->getElement('add')->removeDecorator('Label');
        } */

        $this->addSubForm($subForm, 'contentCourse');


        $this->addElement('submit', 'Save', array(
            'ignore' => true,
            'label' => 'Save'
        ));
        $this->addElement('button', 'Cancel', array(
            'label' => 'Cancel',
            'ignore' => true,
            'id' => 'cancel_form',
            'class' => 'btn btn-warning'
        ));
    }

    protected function getSubFormDecoratorsMain($className, $id) {
        return array(
            'FormElements',
            array(
                'HtmlTag', array('tag' => 'ul')
            ),
            array(
                array('row' => 'HtmlTag'),
                array('tag' => 'li', 'class' => $className, 'id' => $id)
            )
        );
    }

    public function removeUneditableElements() {
        return false;
    }

    public function isValid($data, &$errorMessage='',$showAnswerField=true) {
        $status = parent::isValid($data);
        // prd($data);
        if (!empty($data['contentCourse'])) {
            $subForm = 'contentCourse';
            foreach ($data['contentCourse'] as $key => $row) {
                if (empty($row['all_country']) && !isset($row['cluster_id']) && !isset($row['country_id'])) {
                    $status = false;
                    $this->getSubForm($subForm)->getSubForm($key)->getElement('all_country')->setErrors(array(" Please select either All Countries or Cluser & Country"));
                }
                /* if (isset($row['cluster_id']) && !isset($row['country_id'])) {
                    $status = false;
                    $this->getSubForm($subForm)->getSubForm($key)->getElement('country_id')->setErrors(array(" Please select country"));
                } */
                if (empty($row['question'])) {
                    $status = false;
                    $this->getSubForm($subForm)->getSubForm($key)->getElement('question')->setErrors(array("Please enter question."));
                }
                if (empty($row['answer']) && $showAnswerField) {
                    $status = false;
                    $this->getSubForm($subForm)->getSubForm($key)->getElement('answer')->setErrors(array("Please enter answer."));
                }
                if (empty($row['is_b2c']) && empty($row['is_b2b'])) {
                    $status = false;
                    $this->getSubForm($subForm)->getSubForm($key)->getElement('is_b2b')->setErrors(array("Please select atleast one of Is B2C or Is B2B."));
                }
            }
            return $status;
        }
    }
}
