<?php

class Form_FptFaqs extends BaseApp_SubForm {

    public function init() {

        $this->setName('FptFaqsForm');
        $this->setMethod('post');

        /**
         * Primary Courses
         */
        $this->addElement('hidden', 'city_page_product_id', array(
            'required' => false,
            'value' => '',
            'attribs' => array('readonly' => 'true')
        ));
        $this->addElement('hidden', 'city_page_product_type', array(
            'required' => false,
            'value' => '',
            'attribs' => array('readonly' => 'true')
        ));
        $this->addElement('text', 'fpt_page_product_name', array(
            'label' => 'Product Name*',
            'required' => false,
            'class' => 'text'
        ));
    }

}
