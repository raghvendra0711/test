<?php

class Form_MobileAppHorizontalLists extends BaseApp_Form
{
    const TYPE_COURSE='course';
    const TYPE_FREE_COURSE='free_course';   
    const TYPE_MASTERS='master_program';
    
    protected $productTypes = array();
    
    public function __construct($data) {
         $this->init($data);
    }

    public function init($data)
    {
        $this->setName('Mobile App');
        $this->setMethod('post');
        $this->loadDefaultDecorators();

        $this->productTypes =   array(  '0'                    => '---Select Product Type---', 
                                        self::TYPE_COURSE      => 'Course',
                                        self::TYPE_FREE_COURSE => 'Free Course',
                                        self::TYPE_MASTERS     => 'Master Program'
                                    );
        $widgetInfo = !empty($data['info']) ? $data['info'] : array();
        $widget_type = !empty($data['widget_type']) ? $data['widget_type'] : '';
        $data = !empty($data['data']) ? $data['data'] : array();              
        $this->addElement('text','widget_type',array(
            'label'=>'Widget Type*',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'attribs' => array('readonly' => 'readonly'),
            'autocomplete' => 'off',
            'value'     =>  $widget_type
        ));

        $this->addElement('text','name',array(
                                'label'     =>  'Name of the Widget',
                                'required'  =>  true,
                                'filters'   =>  array('StringTrim'),
                                'class'     =>  'longtext',
                                'value'     =>  !empty($widgetInfo['title']) ? $widgetInfo['title'] : ''
                        ));
        $this->getElement('name')->setDescription('Character limit is 30 for name');
        $this->addElement('text', 'limit', array(
            'label' => 'Limit *',
            'filters' => array('StringTrim'),
            'class' => 'number',
            'required' => true,
            'value'=>!empty($widgetInfo['limit']) ? $widgetInfo['limit'] : ''
                        ));
        $this->addElement('select', 'product_type', array(
                            'label'                     => 'Choose Product Type',
                            'required'                  => true,
                            'registerInArrayValidator'  => false,
                            'value'                     => !empty($widgetInfo['product_type']) ? $widgetInfo['product_type'] : $this->productTypes[0],
                            'multioptions'              => $this->productTypes,
                        ));
        $obj = new Model_Labels();
        $this->addElement('select', 'category_id', array(
            'label' => 'Choose Category',
            'required' => false,           
            'registerInArrayValidator' => false,
            'multioptions' => array( '0' => '---Select Category---')+$obj->getPrimaryLableData()
        ));

        $this->addElement('select', 'product_id_temp', array(
            'label' => 'Choose Product',
            'required' => false,
            'size' => 12,
            // 'multiple' => true,
            'class' => 'multiple',
            'registerInArrayValidator' => false,
            //'multioptions' => 
        ));

        $products = !empty($data['content_ids_sorted_list']) ? $data['content_ids_sorted_list'] : '';
        $this->addElement('hidden', 'product_ids', array('required' => false, 'value' => $products));
        $prodGroup = array('product_id_temp');
        $this->addDisplayGroup($prodGroup, 'product_group');
        $this->getDisplayGroup('product_group')
            ->clearDecorators()
            ->addDecorator('FormElements')
            ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper'));


        $validatorsName = array(new Zend_Validate_StringLength(array('max' => 30)));
        $this->getElement('name')->addValidators($validatorsName);
        $this->addElement('submit', 'Add Mobile App', array(
            'ignore' => true,
            'label' => 'Save',
            'class' => 'btn btn-info'
        ));
    }

    public function removeUneditableElements(){
        $this->getElement('name')->setAttrib('disabled', 'disabled');
        $this->getElement('name')->setRequired(false);
    }

    public function isValid($data) {
        $status = parent::isValid($data);
        if (!$status){
            return false;
        }
        $sequenceObj         = new Model_WidgetSequence();
        $title = !empty($data['name']) ? $data['name'] : '';
        if(empty($data['limit'])){
            $this->getElement('limit')->setErrors(array("limit should be greater than zero"));
            return false;
        } else{
            if ( ! preg_match('/^\d+$/', $data['limit']) ) {
                $this->getElement('limit')->setErrors(array("limit should be number "));
                return false;
              }
        }
        $widgetData = $sequenceObj->getSectionContentByTitle($title);
        if (!empty($widgetData)&&empty($data['widget_id'])) {
            $this->getElement('name')->setErrors(array("duplicate widget title"));
            return false;
        }
        if (empty($data['product_type'])) {
            $this->getElement('product_type')->setErrors(array("field should not be empty"));
            return false;
        }
        if (empty($data['product_ids'])) {
            $this->getElement('product_id_temp')->setErrors(array("select atleast one product"));
            return false;
        }
        return $status;
    }
}
