<?php
class Form_Webinars extends BaseApp_SubForm
{       

    protected $submitName = 'Save Webinar';
    
    public function init(){

        $this->setName('Webinars');
        $this->setMethod('post');
         //adding Label name element
        $validatorsName = array(new Zend_Validate_StringLength(array('max' => 100)));
        $validatorsDescription = array(new Zend_Validate_StringLength(array('max' => 1000)));

        $course =new Model_Courses();
        $this->addElement('select','course_id',array(
            'label'=>'Courses (Maximum allowed '. Model_Webinars::MAX_COURSES_ALLOWED_LINK.')',
            'required'=>false,
            'multiple' => true,
            'class' => 'multiple',
            'registerInArrayValidator' => false,
            'multioptions'=>$course->fetchForSelect(array('is_dummy = ?' => 0, 'is_free = ?' => 0))
        ));
        
        $label =new Model_Labels();
        $this->addElement('select','label_id',array(
            'label'=>'Labels (Maximum allowed '.  Model_Webinars::MAX_CATEGORIES_ALLOWED_LINK.')*',
            'required'=>true,
            'multiple' => true,
            'class' => 'multiple',
            'registerInArrayValidator' => false,
            'multioptions'=>$label->fetchForSelect()
        ));
        
        $this->addElement('select','lead_course_id',array(
            'required'=>true,
            'label' => 'Course For Lead*', 
            'multioptions'=>array('0'=>'--Select--') +$course->fetchForSelect()
         ));
        
        $this->addElement('checkbox','isDemo',array(
            'label'=>'is this A demo class webinar?',
            'value'=>0
        ));

        $this->addElement('text','name',array(
            'label'=>'Name',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off'
        ));                                
        
        $this->addElement('text','url',array(
            'label'=>'Url',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));
        
         $this->addElement('text','webinar_ident',array(
             'label'=>'Webinar ID',
             'required'=>true,
             'filters'=>array('StringTrim'),
             'class'=>'longtext'
         ));

        /*
        $objWebinar = new Model_Webinars();
        $this->addElement('select','webx_user_id',array(
            'label'=>'Webx User Id',
            'required'=>true,
            'multioptions' => array('0'=>'--Select--')+$objWebinar->getWebexUserslist()
            
        ));
        
        $this->addElement('text','webx_session_id',array(
            'label'=>'Webx Session Id',
            'required'=>true,
            'registerInArrayValidator' => false,
            'fetchDisabled' => 'true'
        ));
         * 
         */
        
        $this->addElement('text','authorName',array(
            'label'=>'Author Name',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off'
        ));
        
        $obj = new Model_Country();
        $this->addElement('select','timeZone',array(
            'label'=>'Time Zone',
            'required'=>true,
            'multioptions' => array('0'=>'--Select--')+$obj->getAllTimezonesWithAbbr()
        ));
        
        // $this->addElement('text','urlJoin',array(
        //     'label'=>'URL to attend the webinar',
        //     'required'=>true,
        //     'filters'=>array('StringTrim'),
        //     'class'=>'longtext',
        //     'validators' => array(
        //         new BaseApp_Validate_Url()
        //     )
        // ));
        
        $this->addElement('text','date',array(
            'label'=>'Date',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'datepicker'
        ));
        
        $this->addElement('text','time',array(
            'label'=>'Time',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'readonly' => 'readonly',
            'class'=>'timepicker'
        ));
        
        $this->addElement('text','duration',array(
            'label'=>'Duration',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'placeholder' => 'HH:MM'
        ));
        
        
        /*
         * Start: Sub form for price
         */
         $session = new Zend_Session_Namespace('form');
         $subForm = new Zend_Form_SubForm();
         $subForm->setName('countryPrice');   
         foreach ($session->countryPrice as $product) {
            $keyCountry = isset($session->countryPriceData[$product]['country_id'])?$session->countryPriceData[$product]['country_id']:'';
            $keyCurrency = isset($session->countryPriceData[$product]['currency_id'])?$session->countryPriceData[$product]['currency_id']:'';    
            $keyDiscount = isset($session->countryPriceData[$product]['discountValue'])?$session->countryPriceData[$product]['discountValue']:'';    
            $keySubscriptionPrice = isset($session->countryPriceData[$product]['subscriptionPrice'])?$session->countryPriceData[$product]['subscriptionPrice']:'';
            
            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);  
            
            if ($product === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
            }
            
            $country = new Zend_Form_Element_Select('country_id');
            $countryModel = new Model_Country();
            $country->setOptions(array('multioptions' => array(0=>'--Select--')+$countryModel->getListDisplay()))->setValue($keyCountry)->setAttrib('class', 'country')->setLabel('Country');
            
            $currency = new Zend_Form_Element_Select('currency_id');
            $currencyModel = new Model_Currency();
            $currency->setOptions(array('multioptions' => $currencyModel->getCurrencyToDisplay()))->setValue($keyCurrency)->setAttrib('class', 'currency')->setLabel('Currency');

            $discount = new Zend_Form_Element_Text('discountValue');
            $discount->addFilter('stringTrim')->setValue($keyDiscount)->setAttrib('class', 'discountValue')->setLabel('Discount(%)');
            
            $subscriptionPrice = new Zend_Form_Element_Text('subscriptionPrice');
            $subscriptionPrice->addFilter('stringTrim')->setValue($keySubscriptionPrice)->setAttrib('class', 'subscriptionPrice')->setLabel('Price');
            /*
            if ($product !== '__template__') {
                $country->setRequired(true);
                $currency->setRequired(true);
                $discount->setRequired(true);
                $subscriptionPrice->setRequired(true);
            }            
            */
            $removeCountryPrice = new Zend_Form_Element_Button('remove');
            $removeCountryPrice->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');        
         
            $elements = array($country, $currency, $discount, $subscriptionPrice);            
            if ($product !== 'new') {
                $elements[] = $removeCountryPrice;            
            }
            
            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());

            if($rowForm->getElement('remove')) {
                $rowForm->getElement('remove')->removeDecorator('Label');
            }
            
            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        }
        
        $subForm->setDecorators($this->getSubFormDecoratorsMain('countryPrice', 'countryPrice'));

        $addPrice = new Zend_Form_Element_Button('add');
        $addPrice->setLabel('Add More')->setAttrib('class', 'btn btn-warning add');
        $subForm->addElement($addPrice);

        $subForm->setElementDecorators($this->getElementDecorators());
        $subForm->getElement('add')->removeDecorator('Label');
        $this->addSubForm($subForm, 'countryPrice');
        
        /*
         * End: Sub form for price
         */
        
        $this->addElement('textarea','shortDescription',array(
            'label'=>'Description',
            'required'=>true,
            'filter'=>array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class'=>'description'
        ));
        
        $this->addElement('text','searchTags',array(
            'label'=>'Search tags (comma separated)',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));
        
        $this->addElement('textarea','longDescription',array(
            'label'=>'Description about webinar',
            'required'=>true,
            'filter'=>array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class'=>'description'
        ));
        
        $this->addElement('checkbox','is_featured',array(
            'label'=>'Is Featured?',
            'required'=>false
        ));
        
        /**
         * Start: sub form for faqs
         * 
         */
        
         $subForm = new Zend_Form_SubForm();
         $subForm->setName('webinarFaq');   
         foreach ($session->webinarFaq as $product) {
            $keyQuestion = isset($session->webinarFaqData[$product]['question'])?$session->webinarFaqData[$product]['question']:'';
            $keyAnswer = isset($session->webinarFaqData[$product]['answer'])?$session->webinarFaqData[$product]['answer']:'';
            
            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);  
            
            if ($product === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
            }
            
            $question = new Zend_Form_Element_Text('question');
            $question->addFilter('stringTrim')->setValue($keyQuestion)->setAttrib('class', 'question')->setAttrib('placeholder', 'Full Length simulation tests');
            
            $answer = new Zend_Form_Element_Text('answer');
            $answer->addFilter('stringTrim')->setValue($keyAnswer)->setAttrib('class', 'faqDescription')->setAttrib('placeholder', 'This includes full length, timed simulation teste as prescribed by PMI');
            
            $removeSetsNumber = new Zend_Form_Element_Button('remove');
            $removeSetsNumber->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');        
         
            if ($product !== 'new') {
                $elements = array($question, $answer, $removeSetsNumber);            
            }
            else {
                $elements = array($question, $answer);            
            }            

            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());

            if($rowForm->getElement('remove')) {
                $rowForm->getElement('remove')->removeDecorator('Label');
            }
            
            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        }
        
        $subForm->setDecorators($this->getSubFormDecoratorsMain('webinarFaq', 'webinarFaq'));

        $addPrice = new Zend_Form_Element_Button('add');
        $addPrice->setLabel('Add More')->setAttrib('class', 'btn btn-warning add');
        $subForm->addElement($addPrice);

        $subForm->setElementDecorators($this->getElementDecorators());
        $subForm->getElement('add')->removeDecorator('Label');
        $this->addSubForm($subForm, 'webinarFaq');
        
        /**
         * End: sub form for faqs
         * 
         */
        
        /**
         * Start: sub form for suggestions
         * 
         */
        
        $subForm = new Zend_Form_SubForm();
         $subForm->setName('recommendations');   
         foreach ($session->recommendations as $product) {
            $keyApplicableEntity = isset($session->recommendationsData[$product]['applicableEntity'])?$session->recommendationsData[$product]['applicableEntity']:'';
            $keyElementName = isset($session->recommendationsData[$product]['applicableEntityId'])?$session->recommendationsData[$product]['applicableEntityId']:'';
            $keyTrainingType = isset($session->recommendationsData[$product]['trainingType'])?$session->recommendationsData[$product]['trainingType']:'';
            
            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);  
            
            if ($product === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
            }
            
            $modelRecommend = new Model_Recommendations();
            $modelTraining = new Model_TrainingTypes();
            $applicableEntity = new Zend_Form_Element_Select('applicableEntity');
            $applicableEntity->setOptions(array('multioptions' => array(0=>'--Select--')+$modelRecommend->getRecommendElements()))->setValue($keyApplicableEntity)->setAttrib('class', 'applicableEntity')->setLabel('Also Consider');
            $elementList = array();
            if($keyApplicableEntity) {
                $modelRecommend = new Model_Recommendations();
                $elementList = $modelRecommend->getByElement($keyApplicableEntity); 
            } 
            $elementName = new Zend_Form_Element_Select('applicableEntityId');
            $elementName->setOptions(array('multioptions' => array(0=>'--Element Name--')+$elementList, 'registerInArrayValidator' => false))->setValue($keyElementName)->setAttrib('class', 'elementName');
            
            $trainingType = new Zend_Form_Element_Select('trainingType');
            $trainingType->setOptions(array('multioptions' => array(0=>'Training Type')+$modelTraining->getTrainingTypes(), 'registerInArrayValidator' => false))->setValue($keyTrainingType)->setAttrib('class', 'trainingType');
           
            $removeSuggestions = new Zend_Form_Element_Button('remove');
            $removeSuggestions->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');        
            if ($product !== 'new') {
                $elements = array($applicableEntity, $elementName, $trainingType, $removeSuggestions);            
            }
            else {
                $elements = array($applicableEntity, $elementName, $trainingType);            
            }
            
            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());

            if($rowForm->getElement('remove')) {
                $rowForm->getElement('remove')->removeDecorator('Label');
            }
            
            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        }
        
        $subForm->setDecorators($this->getSubFormDecoratorsMain('recommendations', 'recommendations'));

        $addPrice = new Zend_Form_Element_Button('add');
        $addPrice->setLabel('Add More')->setAttrib('class', 'btn btn-warning add');
        $subForm->addElement($addPrice);

        $subForm->setElementDecorators($this->getElementDecorators());
        $subForm->getElement('add')->removeDecorator('Label');
        $this->addSubForm($subForm, 'recommendations');
        $this->postSetup();
        
        /**
         * End: sub form for suggestions
         * 
         */     
        
        $this->getElement('name')->addValidators($validatorsName);         
        $this->getElement('shortDescription')->addValidators($validatorsDescription);
    }
    
    protected function getSubFormDecoratorsMain($className, $id) {
        return array(   
            'FormElements',                        
            array(                
                'HtmlTag', array('tag' => 'ul')
            ),
            array(
                array('row' => 'HtmlTag'),                
                array('tag' => 'li', 'class' => $className, 'id' => $id)
            )
        );
    }  
    
    public function removeUneditableElements(){
        $this->removeElement('url');
        $this->getElement('webinar_ident')->setAttrib('disabled', 'disabled');
        $this->getElement('webinar_ident')->setRequired(false);
        $this->getElement('isDemo')->setAttrib('disabled', 'disabled');
        $this->getElement('isDemo')->setRequired(false);
        return false;
    }
    
    public function isValid($data) {        
        $status = parent::isValid($data);
        if(!empty($data['url'])){
            $data['url'] = trim($data['url']);
            $checkSlash = substr($data['url'], 0,1);
            if($checkSlash != '/'){
                $data['url'] = trim('/'.$data['url']);
            }
            $objSeo = new Model_Seo();
            if(!$data['isDemo']){
                if(false === $objSeo->validateUrl($data['url'])){
                    $this->getElement('url')->setErrors(array("'{$data['url']}' is not a valid Webinar url"));
                    $status = false;   
                }
            }else{
                if($data['url'] && preg_match("/([^a-z0-9A-Z\-\/]+)/", $data['url'])) {
                    $this->getElement('url')->setErrors(array("'{$data['url']}' is not a valid group url"));
                    $status = false;
                }
                $seoData = $objSeo->getDataByUrl($data['url']);
                if(!empty($seoData)){
                    $this->getElement('url')->setErrors(array("'{$data['url']}' does exists and cannot be re-used"));
                    $status = false;
                }
            }
        }
        if(isset($data['duration']) && $data['duration'] && !preg_match("/^(\d){1,2}\:(\d\d)$/", $data['duration'], $match)) {
            $this->getElement('duration')->setErrors(array("duration should be in HH:MM format. Ex: 2:05"));
            $status = false;
        }
        if(!$data['lead_course_id']) {
            $this->getElement('lead_course_id')->setErrors(array("Value is required and can't be empty"));
            $status = false;
        }
        if (!$data['timeZone']) {
            $this->getElement('timeZone')->setErrors(array("Value is required and can't be empty"));
            $status = false;
        }

        if (isset($data['webinar_ident']) && preg_match("/[^0-9A-Za-z]/", $data['webinar_ident'])) {
            $this->getElement('webinar_ident')->setErrors(array("Special characters and spaces not allowed"));
            $status = false;
        }
        return $status;
    }
}