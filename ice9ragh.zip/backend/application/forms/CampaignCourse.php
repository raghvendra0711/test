<?php

class Form_CampaignCourse extends BaseApp_SubForm
{
    public function init(){


        $this->setName('CampaignCourse');
        $this->setMethod('post');
         //adding Label name element

         $this->addElement('radio','campaign_source',array(
            'label' =>'for',
            'required'=>false,
            'multioptions'=>array('1' => 'Course','2' => 'Subscription'),
            'value' => '1' 
         ));
         
         $validatorsName = array(new Zend_Validate_StringLength(array('max' => 100)));
         
        $this->addElement('text','displayName',array(
            'label'=>'Name',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off'
        ));
         
        $labelModel = new Model_Labels();
        $this->addElement('select','label_id',array(
            'label'=>'Labels',
            'required'=>false,
            'multiple' => true,
            'class' => 'courseListAll', 
            'registerInArrayValidator' => false,
            'multioptions'=>$labelModel->fetchForSelect()
        ));
        
        $this->addElement('button','label_inward',array(
            'label'=>'Invert Labels',
            'ignore'=>true,
            'class'=>'btn btn-warning'
        ));
        
        $courseModel = new Model_Courses();
         $this->addElement('select','course_id',array(
            'label'=>'Courses',
            'required'=>false,
            'multiple' => true,
            'registerInArrayValidator' => false,
            'class' => 'courseListAll',  
            'multioptions'=> $courseModel->fetchForSelect(array('is_dummy = ?' => 0, 'is_free = ?' => 0))
        ));
         
        $this->addElement('button','course_inward',array(
            'label'=>'Invert Courses',
            'ignore'=>true,
            'class'=>'btn btn-warning'
        )); 
         
        $bundle = new Model_Bundles();
        $this->addElement('select','bundle_id',array(
            'label'=>'Bundles',
            'required'=>false,
            'multiple' => true,
            'registerInArrayValidator' => false,
            'class' => 'courseListAll', 
            'multioptions'=>$bundle->fetchForSelect()
        )); 
        
        $this->addElement('button','bundle_inward',array(
            'label'=>'Invert Bundles',
            'ignore'=>true,
            'class'=>'btn btn-warning'
        ));
                  
        $objtrainingTypes= new Model_TrainingTypes();
        foreach($objtrainingTypes->fetchAll() as $trainingData) {
            $this->addElement('multiCheckbox','training_id',array(
                'label' =>'Training Type',
                'required'=>true,
                'multioptions'=>$objtrainingTypes->fetchForSelect(),
                'separator' => ' '
             ));
        } 
        
        /*
        $session = new Zend_Session_Namespace('form');
        
        
        
        $subForm = new Zend_Form_SubForm();
        $subForm->setName('trainingTypes'); 
        
        $traingType = new Model_TrainingTypes();
        $trainingTypeIds = $traingType->loadAll();
            
        $keyOSL = isset($session->trainingTypesData['osl2'])?$session->trainingTypesData['osl2']:'';
        $keyOSLAccessdays = isset($session->trainingTypesData['oslAccessDays'])?$session->trainingTypesData['oslAccessDays']:'';
        $keyClassRoom = isset($session->trainingTypesData['ilt1'])?$session->trainingTypesData['ilt1']:'';
        $keyClassRoomFromDate = isset($session->trainingTypesData['classRoomFromDate'])?$session->trainingTypesData['classRoomFromDate']:'';
        $keyClassRoomToDate = isset($session->trainingTypesData['classRoomToDate'])?$session->trainingTypesData['classRoomToDate']:'';
        $keyClassRoomAccessDays = isset($session->trainingTypesData['classRoomAccessDays'])?$session->trainingTypesData['classRoomAccessDays']:'';
        $keyILO = isset($session->trainingTypesData['ilt3'])?$session->trainingTypesData['ilt3']:'';
        $keyILOFromDate = isset($session->trainingTypesData['iloFromDate'])?$session->trainingTypesData['iloFromDate']:'';
        $keyILOToDate = isset($session->trainingTypesData['iloToDate'])?$session->trainingTypesData['iloToDate']:'';
        $keyILOAccessDays = isset($session->trainingTypesData['iloAccessDays'])?$session->trainingTypesData['iloAccessDays']:'';

        
        $trainingTypeOsl = new Zend_Form_Element_Checkbox('osl2');
        $trainingTypeOsl->setLabel($trainingTypeIds[2]['name']);
        if($keyOSL) {
           $trainingTypeOsl->setAttrib('checked', true); 
        }
                
        $oslAccessdays = new Zend_Form_Element_Select('oslAccessDays');
        $oslAccessdays->setLabel('for access days')->setOptions(array('multioptions' => array(0=>'--Select--', '30'=>'30','90'=>'90','180'=>'180')))->setValue($keyOSLAccessdays)->setAttrib('class', 'oslAccessDays');

        $trainingTypeClassRoom = new Zend_Form_Element_Checkbox('ilt1');
        $trainingTypeClassRoom->setLabel($trainingTypeIds[1]['name']);
        if($keyClassRoom) {
            $trainingTypeClassRoom->setAttrib('checked', true); 
        }
        
        $classRoomFromDate = new Zend_Form_Element_Text('classRoomFromDate');
        $classRoomFromDate->setLabel('from')->addFilter('stringTrim')->setValue($keyClassRoomFromDate)->setAttrib('class', 'classRoomFromDate');

        $classRoomToDate = new Zend_Form_Element_Text('classRoomToDate');
        $classRoomToDate->setLabel('To')->addFilter('stringTrim')->setValue($keyClassRoomToDate)->setAttrib('class', 'classRoomToDate');

        $classRoomAccessDays = new Zend_Form_Element_Select('classRoomAccessDays');
        $classRoomAccessDays->setLabel('Workshop days')->setOptions(array('multioptions' => array(0=>'--Select--', '2'=>'2','4'=>'4')))->setValue($keyClassRoomAccessDays)->setAttrib('class', 'classRoomAccessDays');

        $trainingTypeIlo = new Zend_Form_Element_Checkbox('ilt3');
        $trainingTypeIlo->setLabel($trainingTypeIds[3]['name']);
        if($keyILO) {
            $trainingTypeIlo->setAttrib('checked', true); 
        }
        
        $iloFromDate = new Zend_Form_Element_Text('iloFromDate');
        $iloFromDate->setLabel('from ')->addFilter('stringTrim')->setValue($keyILOFromDate)->setAttrib('class', 'iloFromDate');

        $iloToDate = new Zend_Form_Element_Text('iloToDate');
        $iloToDate->setLabel('To')->addFilter('stringTrim')->setValue($keyILOToDate)->setAttrib('class', 'iloToDate');

        $iloAccessDays = new Zend_Form_Element_Select('iloAccessDays');
        $iloAccessDays->setLabel('Workshop days')->setOptions(array('multioptions' => array(0=>'--Select--', '8'=>'8','16'=>'16')))->setValue($keyILOAccessDays)->setAttrib('class', 'iloAccessDays');

        $elements = array($trainingTypeOsl, $oslAccessdays, $trainingTypeClassRoom, $classRoomFromDate, $classRoomToDate, $classRoomAccessDays, $trainingTypeIlo, $iloFromDate, $iloToDate, $iloAccessDays);            

        $subForm->addElements($elements);
        $subForm->setElementDecorators($this->getElementDecorators());
        $subForm->setDecorators($this->getSubFormDecorators());            
        $subForm->setLegend('Training Types');
        $this->addSubForm($subForm, 'trainingTypes');
        
        
         */
         
        $this->addElement('text','specialText',array(
            'label'=>'Special Text',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off'
        ));
        
        $this->addElement('text','topBannerPath',array(
            'label'=>'Top Banner',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off',
            'validators' => array(
                new BaseApp_Validate_Image('campaignCourse', 'topBannerPath', true)
            )
        ));
        
        $this->addElement('text','smallBannerPath',array(
            'label'=>'Offer Page Banner',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off',
            'validators' => array(
                new BaseApp_Validate_Image('campaignCourse', 'smallBannerPath', true)
            )
        ));
        
        $clusterModel = new Model_Clusters();
        $this->addElement('select','cluster_id',array(
            'label'=>'Clusters/BU',
            'required'=>true,
            'multiple' => true,
            'registerInArrayValidator' => false,
            'multioptions'=>$clusterModel->fetchForSelect()                  
        ));
        
        $this->addElement('button','cluster_inward',array(
            'label'=>'Invert Clusters',
            'ignore'=>true,
            'class'=>'btn btn-warning'
        ));
        
        $countryModel = new Model_Country();
        $this->addElement('select','country_id',array(
            'label'=>'Country/Clusters/BU',
            'required'=>false,
            'multiple' => true,
            'class' => 'courseListAll', 
            'registerInArrayValidator' => false,
            'multioptions'=>$countryModel->getListDisplay()                   
        ));
        
        $this->addElement('button','country_inward',array(
            'label'=>'Invert Countries',
            'ignore'=>true,
            'class'=>'btn btn-warning'
        ));
        
        $this->addElement('text','validFrom',array(
            'label'=>'Offers valid for purchases from',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off'
        ));
        
        $this->addElement('text','validto',array(
            'label'=>'To',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off'
        ));
        
        $this->addElement('text','alert',array(
            'label'=>'Alert',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off',
            'validators' => array(
                new BaseApp_Validate_EmailAddress()
            )
        ));
        
        $this->addElement('text','percentage',array(
            'label'=>'Percentage',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off',
            'validators' => array(
                new Zend_Validate_Digits()
            )
        ));
        
         
        $this->addElement('submit','Save',array(
           'ignore'=>true,
           'label'=>'Save',
           'class'=>'btn btn-info'
        ));        
        $this->getElement('displayName')->addValidators($validatorsName);         
    }
    
    protected function getSubFormDecoratorsMain() {
        return array(   
            'FormElements',                        
            array(                
                'HtmlTag', array('tag' => 'ul')
            ),
            array(
                array('row' => 'HtmlTag'),                
                array('tag' => 'li', 'class' => 'trainingTypes', 'id' => 'trainingTypes')
            )
        );
    }
    
    public function removeUneditableElements(){
        $this->removeElement('campaign_source');
    }
    
    public function isValid($data) {
        $return = parent::isValid($data);
        if($return){
            if(!isset($data['label_id']) && !isset($data['course_id']) && !isset($data['bundle_id'])) {
                $this->getElement('label_id')->setErrors(array("label or course or bundle required"));
                $this->getElement('course_id')->setErrors(array("label or course or bundle required"));
                $this->getElement('bundle_id')->setErrors(array("label or course or bundle required"));
                return false;
            }
        }        
        return $return;
    }
}