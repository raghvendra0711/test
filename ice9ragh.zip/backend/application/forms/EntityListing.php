<?php

class Form_EntityListing extends BaseApp_Form
{

    public function init(){
        $this->setName('EntityListing');
        $this->setMethod('post');
        
        $validatorsName = array(new Zend_Validate_StringLength(array('max' => 512)));
        $validatorsDescription = array(new Zend_Validate_StringLength(array('max' => 512)));

        $this->addElement('text','name',array(
            'label'=>'Name',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('text','displayName',array(
            'label'=>'Display Name',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('textarea','shortDescription',array(
            'label'=>'A Small Description',
            'required'=>true,
            'cols' => 60,
            'rows' => 6,
            'class'=>'longtext'
        ));

        $this->addElement('textarea','longDescription',array(
            'label'=>'Detailed Description',
            'required'=>true,
            'rows' => 21,
            'cols' => 68,
            'class'=> 'fck-enable'     
        ));

        $this->addElement('text','url',array(
            'label'=>'Url for Page ( e.g. /project-management )',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $course =new Model_Courses();
        $this->addElement('select','course_id',array(
            'label'=>'Courses',
            'required'=>true,
            'multiple' => true,
            'class' => 'multiple',
            'registerInArrayValidator' => false,
            'multioptions'=>$course->fetchForSelect()
        ));
        
        $objTrTp = new Model_TrainingTypes();
        $this->addElement('multiCheckbox','training_id',array(
            'label' =>'Training Type',
            'required'=>true,
            'multioptions'=>$objTrTp->fetchForSelect(),
            'separator' => ' '
         ));

        $this->addElement('text','imageUrl',array(
            'label'=>'Banner Url',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                new BaseApp_Validate_Image('EntityListing','imageUrl',true)
            )
        ));
        
        $this->addElement('submit','Save',array(
           'ignore'=>true,
           'label'=>'Save',
           'class'=>'btn btn-info'
        ));

        $this->getElement('name')->addValidators($validatorsName);         
        $this->getElement('displayName')->addValidators($validatorsName);         
        $this->getElement('shortDescription')->addValidators($validatorsDescription);         
    }
    
    public function removeUneditableElements(){
        $this->getElement('url')->setAttrib('disabled', 'disabled');
        $this->getElement('url')->setRequired(false);
    }
    
    public function isValid($data) {        
        $status = parent::isValid($data);
        return $status;
    }
}