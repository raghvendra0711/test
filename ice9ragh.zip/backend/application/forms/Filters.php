<?php

class Form_Filters extends BaseApp_Form
{

    private $_tableName;
    private $_labels;
    

    public function __construct($param1,$labels = array()) {
        $this->_tableName = $param1;
        $this->_labels = $labels;
        parent::__construct();
    }

    public function init(){
      $this->setName('Filters');
      $this->setMethod('post');
      $searchObj = new Model_SearchField();
      $data = $searchObj->fetchAll(array('TableName =? '=>$this->_tableName));
        foreach ($data as $key => $value) {
            $test = $value['searchColumnName'];
            if(is_array($this->_labels) && !empty($this->_labels)){
              if(trim($this->_labels['searchColumnName']) == trim($test)){
                $value['searchColumnDisplayName'] = $this->_labels['searchColumnDisplayName'];
              }
            }
            $elementType = 'text';
            $queryDataArr = $value;
            $elementArr = array(
                            'label'=>$value['searchColumnDisplayName'],
                            'required'=>false,
                            'filters'=>array('StringTrim'),
                            'class'=>$value['searchClass'],
                            'data-table'=>$queryDataArr
                          );
            if(isset($value['getModel'])){
              if(!empty($value['getModel'])){
                $obj = new $value['getModel'] ();
                if(!empty($value['modelFunction'])){
                  $data = $obj->$value['modelFunction']();
                  $elementArr['registerInArrayValidator'] = false;
                  $elementArr['multioptions'] = array('0'=>'All','tbp'=>'To be Approved') + $data;
                  $elementType = 'select';
                }else{
                  $data = $obj->fetchForSelect();
                  $elementArr['registerInArrayValidator'] = false;
                  $elementArr['multioptions'] = array('0'=>'--Select--') + $data;
                  $elementType = 'select';
                }
              }
            }
            if($value['searchElement'] == 'checkbox')
              $elementType = 'checkbox';
            $this->addElement($elementType,$test,$elementArr);
        }
        if(!empty($data)){
            $this->addElement('submit','Search',array(
            'ignore'=>true,
            'label'=>'Search'
         )); 
        }
         
    }

    public function getSearchFields($searchId){
      $searchObj = new Model_SearchField();
      $returnData = $searchObj->fetchAll(array('search_id =? '=>$searchId));
      return $returnData;
    }
}