
<?php

class Form_ReferralData extends BaseApp_SubForm
{

    private $_courseId = null;

    public function __construct($courseId = false, $new = true)
    {
        $this->init();
        $this->loadDefaultDecorators();
    }

    public function init()
    {
        $this->setName('ReferralData');
        $this->setMethod('post');
        $this->setAttrib('class', 'courseForm');

        $this->addElement('file', 'referrealData', array(
            'label' => 'Upload Referral Data csv File',
            'required' => false,
            'destination' => sys_get_temp_dir(),
            'validators' => array(array('Extension', true, 'csv'))
        ));
       
        $this->addElement('submit', 'Save', array(
            'ignore' => true,
            'label' => 'Save',
            'class' => 'btn btn-info'
        ));
        $this->addElement('hidden', 'tempreferrealData', array(
            'label' => '',
            'required' => false,
        ));
        $this->getElement('tempreferrealData')->setDescription('INSTRUCTIONS : <br>1.Please add unique order ids only and remove any duplicate entries<br>2.The format of the CSV file can be seen in the link <a href =https://docs.google.com/spreadsheets/d/1wOGVBgnZnzzuynNItFL8q9eFMKl0XH-dXiZgPX7JV2c/edit?usp=sharing> Sample CSV format </a><br>3.At one point of time we can update 1000 entries only')
        ->setDecorators(array(
            'ViewHelper',
            array('Description', array('escape' => false, 'tag' => 'p','class' => 'description-note')),
            array('HtmlTag', array('tag' => 'div','class' => 'element')),
            array('Label', array('tag' => 'div')),
            array('Errors'),
            array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
));
    }

    public function isValid($data)
    {
        $status = parent::isValid($data);
        return $status;
    }
}
