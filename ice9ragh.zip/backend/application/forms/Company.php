<?php

class Form_Company extends BaseApp_SubForm {

    protected $_domains;
    private $_companyId = null;
    public function __construct($companyId) {
        if ($companyId) {
            $this->_companyId = $companyId;
        }
        $this->init($companyId);
        $this->loadDefaultDecorators();
    }

    public function init($companyId) {
        $this->setName('Company');
        $this->setMethod('post');
        $session = new Zend_Session_Namespace('form');

        $objSection = new Model_SectionMapping();
        $partnershipcomapnyData = $objSection->getpartnershipDataByProduct($companyId, 'company', 'partnership_heading');
        $partnershipAdvData = $objSection->getpartnershipDataByProduct($companyId, 'company', 'partnership_advantage');
        $partnershipGetstartData = $objSection->getpartnershipDataByProduct($companyId, 'company', 'partnership_get_start');

        $this->addElement('text', 'name', array(
            'label' => 'Name*',
            'required' => true,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'placeholder' => 'Company Name'
        ));

        $this->addElement('text', 'imageUrl', array(
            'label' => 'Image Url for Company*',
            'required' => true,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'placeholder' => 'Company Logo',
            'validators' => array(
                new BaseApp_Validate_Image('category', 'company_logo')
            )
        ));
        $this->addElement('text', 'bannerImageUrl', array(
            'label' => 'Banner Image Url for Company',
//            'required'=>true,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'placeholder' => 'Banner Image Url',
            'validators' => array(
                new BaseApp_Validate_Image('category', 'company_banner')
            )
        ));
        $this->addElement('text', 'bannerSectionText', array(
            'label' => 'Banner Text for Company',
//                'required'=>true,
            'placeholder' => 'Banner Text for Company',
            'filters' => array('StringTrim'),
            'class' => 'longtext'
        ));

        $this->addElement('text', 'alt_text', array(
            'label' => 'Alt Text*',
            'required' => true,
            'placeholder' => 'Alt text',
            'filters' => array('StringTrim'),
            'class' => 'longtext'
        ));

        $this->addElement('text', 'description', array(
            'label' => 'Company Identifier*',
            'required' => true,
            'placeholder' => 'Company Identifier',
            'filters' => array('StringTrim'),
            'class' => 'longtext',
        ));
        $this->addElement('text', 'company_sf_acc_id', array(
            'label' => 'Company SF Account ID*',
            'required' => true,
            'description' => '*If you don\'t have an SF account ID, please provide some dummy value.',
            'placeholder' => 'Company SF Account ID',
            'filters' => array('StringTrim'),
            'class' => 'longtext',
        ));

        $this->getElement('description')->addValidator('regex', false, array(
            '/^\w+$/u',
            'messages' => array(
                'regexNotMatch' => 'Invalid Identifier'
            )
        ));
        $subForm1 = new Zend_Form_SubForm();

        $subForm1->setName('companyAgencies');
        foreach ($session->companyAgencies as $agency) {
            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($agency);
            $elements = array();
            if ($agency === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
            }
            $name = new Zend_Form_Element_Text('agencyName');
            $name->addFilter('stringTrim')->setValue('')->setAttrib('class', 'agencyName')->setAttrib('placeholder', 'Agency Name')->setLabel('Agency Name');
            $elements[] = $name;
            $url = new Zend_Form_Element_Text('lmsurl');
            $url->addFilter('stringTrim')->setValue('')->setAttrib('class', 'lmsurl')->setAttrib('placeholder', 'Lms Url')->setLabel('Lms Url')->setAttrib('readonly' , 'true');
            $url->addValidator('regex', false, array(
                '/^[\w]*-?[\w]+$/u', //'/^\w+$/u',
                'messages' => array(
                    'regexNotMatch' => 'Invalid Url'
                )
            ));
            $elements[] = $url;

            $agen_sf = new Zend_Form_Element_Text('company_sf_acc_id');
            $agen_sf->addFilter('stringTrim')->setValue('')->setAttrib('placeholder', 'Agency SF ID')->setLabel('Agency SF ID');
            $elements[] = $agen_sf;

            for ($i = 1; $i < 20; $i++) {
                $domain = new Zend_Form_Element_Text('domain' . $i);
                $domain->addFilter('stringTrim')->setValue('')->setAttrib('class', 'domain')->setAttrib('placeholder', 'Agency Domain')->setLabel('Agency Domain')->addValidators(array(new Zend_Validate_Hostname(Zend_Validate_Hostname::ALLOW_LOCAL)));
                $elements[] = $domain;
            }

            $removeSetsNumber = new Zend_Form_Element_Button('remove');
            $removeSetsNumber->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this);');

            if ($agency !== 'new') {
                $elements[] = $removeSetsNumber;
            }
            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());

            if ($rowForm->getElement('remove')) {
                $rowForm->getElement('remove')->removeDecorator('Label');
            }

            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm1->addSubForm($rowForm, $agency);
        }

        $subForm1->setDecorators($this->getSubFormDecoratorsMain('companyAgencies', 'companyAgencies'));

        // "Add Agency" button has been disabled as per product call since SPRINT VERSION 71
        /*
        $addAgency = new Zend_Form_Element_Button('add');
        $addAgency->setLabel('Add Agency')->setAttrib('class', 'btn btn-warning add');
        $subForm1->addElement($addAgency);

        $subForm1->setElementDecorators($this->getElementDecorators());
        $subForm1->getElement('add')->removeDecorator('Label');
        */
        $this->addSubForm($subForm1, 'companyAgencies');

        $obj = new Model_Labels();
        // $categoryList = $obj->fetchForSelect(array(''));

        $this->addElement('text', 'heading', array(
            'label' => ' 1st Heading*',
            'required' => true,
            'placeholder' => 'Heading',
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'value' => !empty($partnershipcomapnyData[0]) && !empty($partnershipcomapnyData[0]['name']) ? $partnershipcomapnyData[0]['name']:'',
        ));
        $this->getElement('heading')->setDescription('example : <company name> And Simplilearn');
        $this->addElement('textarea', 'heading_content', array(
            'label' => '1st Heading Content*',
            'filter' => array('StringTrim'),
            'required' => true,
            'rows' => 5,
            'cols' => 60,
            'class' => 'fck-enable',
            'value' =>  !empty($partnershipcomapnyData[0]) && !empty($partnershipcomapnyData[0]['description']) ? $partnershipcomapnyData[0]['description']:'',
        ));
        $this->addElement('text', 'advantage_section', array(
            'label' => '2nd Heading*',
            'required' => true,
            'placeholder' => 'Heading',
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'value' => !empty($partnershipAdvData[0]) && !empty($partnershipAdvData[0]['name']) ? $partnershipAdvData[0]['name']:'',
        ));
        $this->getElement('advantage_section')->setDescription('example : The Simplilearn Advantage
        ');
        $this->addElement('textarea', 'advantage_content', array(
            'label' => '2nd Heading Content*',
            'filter' => array('StringTrim'),
            'required' => true,
            'rows' => 5,
            'cols' => 60,
            'class' => 'fck-enable',
            'value' =>  !empty($partnershipAdvData[0]) && !empty($partnershipAdvData[0]['description']) ? $partnershipAdvData[0]['description']:'',
        ));
        $this->addElement('text', 'getting_started_section', array(
            'label' => '3rd Heading*',
            'required' => true,
            'placeholder' => 'Heading',
            'required' => true,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'value' => !empty($partnershipGetstartData[0]) && !empty($partnershipGetstartData[0]['name']) ? $partnershipGetstartData[0]['name']:'',
        ));
        $this->getElement('getting_started_section')->setDescription('example : Getting Started
        ');
        $this->addElement('textarea', 'get_start_content', array(
            'label' => '3rd Heading Content*',
            'required' => true,
            'filter' => array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class' => 'fck-enable',
            'value' => !empty($partnershipGetstartData[0]) && !empty($partnershipGetstartData[0]['description']) ? $partnershipGetstartData[0]['description']:'',
        ));
        $partnership_group = array('heading','heading_content','advantage_section','advantage_content','getting_started_section','get_start_content');
        $this->addDisplayGroup($partnership_group, 'partnershi_group');
        $this->getDisplayGroup('partnershi_group')
                ->setLegend('Details Of Partnership')
                ->clearDecorators()                                
                ->addDecorator('FormElements')
                ->addDecorator('Fieldset', array('class'=>'deeplink-form-contents','style' => 'padding: 4px 300px 10px 10px;'));
        $this->addElement('select', 'category_id_tmp', array(
            'required' => true,
            'size' => 12,
            'label' => 'Categories*',
            'class' => 'categoryListAll',
            'registerInArrayValidator' => false,
            'multioptions' => array('0' => '--Select--') + $obj->getLabelsToshow()
        ));

        $this->addElement('hidden', 'category_id', array(
            'required' => false,
            'value' => ''
        ));
        $this->addElement('select', 'category_filter', array(
            'required' => false,
            'label' => 'Filter Category',
            'multioptions' => array('0' => '--Select--') + array()
        ));

        $this->addElement('select', 'exclusion_courses', array(
            'required' => false,
            'size' => 12,
            'label' => 'Excluded Courses',
            'class' => 'categoryListAll',
            'multioptions' => array('0' => '--All Courses--')
        ));

        $this->addElement('hidden', 'excluded_course_ids', array(
            'required' => false,
            'value' => ''
        ));
        $this->addElement('checkbox', 'isBundle', array(
            'label' => 'Show Master Program On Portal',
            'class' => 'enable_master_programs ',
        ));
        // Master Program List
        $this->addElement('select', 'exclusion_master_program', array(
            'required' => false,
            'style' => 'pointer-events: none; cursor: default;',
            'size' => 12,
            'label' => 'Excluded Master Program',
            'class' => 'mpListAll blur_dropdown',
            'multioptions' => array('0' => '--All Master Programs--')
        ));
        $this->addElement('hidden', 'excluded_masterprogram_ids', array(
            'required' => false,
            'value' => ''
        ));
        /**
         * Start: sub form for key features
         * 
         */
        $subForm = new Zend_Form_SubForm();
        $subForm->setName('learnerRange');
        foreach ($session->learnerRange as $product) {
            //$keyName = isset($session->learnerRangeData[$product]['name']) ? $session->learnerRangeData[$product]['name'] : '';
            //$keyFeatureText = isset($session->learnerRangeData[$product]['featureText']) ? $session->learnerRangeData[$product]['featureText'] : '';
            $rangeId = isset($session->learnerRangeData[$product]['learners_range_id']) ? $session->learnerRangeData[$product]['learners_range_id'] : 0;
            $rangeCompanyId = isset($session->learnerRangeData[$product]['company_id']) ? $session->learnerRangeData[$product]['company_id'] : 0;
            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);
            if ($product === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
            }
            $learnerRangeMin = new Zend_Form_Element_Text('min');
            $learnerRangeMin->addFilter('stringTrim')
                    ->setValue('')
                    ->setAttribs(array('class' => 'learner_min_range learner_range', 'data-range-type' => 'min'))
                    ->setLabel('Min');

            $learnerRangeMax = new Zend_Form_Element_Text('max');
            $learnerRangeMax->addFilter('stringTrim')
                    ->setValue('')
                    ->setAttribs(array('class' => 'learner_max_range learner_range', 'data-range-type' => 'max'))
                    ->setLabel('Max');

            $learnerRangeId = new Zend_Form_Element_Text('learners_range_id');
            $learnerRangeId->addFilter('stringTrim')->setValue(0)->setAttribs(array('class' => 'learner_range_id hide-form-el learner_range'))->setLabel('');

            $learnerRangeRemoveBtn = new Zend_Form_Element_Button('learners_range_remove');
            $learnerRangeRemoveBtn->setLabel('Remove')
                    ->setAttribs(array('class' => 'btn btn-danger remove',
                        'onclick' => 'disableRangeInfo(event);',
                        'data-learners-range-id' => $rangeId,
                        'data-company-id' => $rangeCompanyId));
            if ($product !== 'new') {
                $elements = array($learnerRangeMin, $learnerRangeMax, $learnerRangeRemoveBtn, $learnerRangeId);
            } else {
                $elements = array($learnerRangeMin, $learnerRangeMax, $learnerRangeId);
            }

            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());
            if ($rowForm->getElement('remove')) {
                $rowForm->getElement('remove')->removeDecorator('Label');
            }
            if ($rowForm->getElement('learners_range_remove')) {
                $rowForm->getElement('learners_range_remove')->removeDecorator('Label');
            }

            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        }

        $subForm->setDecorators($this->getSubFormDecoratorsMain('learnerRange', 'learnerRange'));

        $addPrice = new Zend_Form_Element_Button('add');
        $addPrice->setLabel('Add')->setAttrib('class', 'btn btn-warning add');
        $subForm->addElement($addPrice);

        $subForm->setElementDecorators($this->getElementDecorators());
        $subForm->getElement('add')->removeDecorator('Label');
        $this->addSubForm($subForm, 'learnerRange');

        /**
         * End: sub form for key features
         * 
         */
        /**
         * Price Plans
         */
        $modelProductSection = new Model_ProductSectionData();
        $pricePlans = $modelProductSection->getCompanyPricePalns();
        $this->addElement('select', 'company_price_plans', array(
            'required' => true,
            'label' => 'Price Plans*',
            'multioptions' => $pricePlans
        ));

        $this->addElement('hidden', 'company_id', array(
            'required' => false,
        ));

        $this->addElement('text', 'company_existing_price_plan', array(
            'required' => false,
            'class' => 'hide-form-el'
        ));

        $this->addElement('checkbox', 'isOsl', array(
            'label' => 'Osl',
            'class' => 'sl-training-types',
            'data-training-type' => BaseApp_Dao_TrainingTypes::TYPE_ELEARNING
        ));

        $this->addElement('checkbox', 'isLvc', array(
            'label' => 'Lvc',
            'class' => 'sl-training-types',
            'data-training-type' => BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS,
        ));
        $this->addElement('submit', 'Save Company', array(
            'ignore' => true,
            'label' => 'Save Company Info',
            'class' => 'btn btn-info'
        ));

        $this->addElement('button', 'Next Tab', array(
            'ignore' => true,
            'label' => 'Next',
            'class' => 'btn next_tab btn-info',
        ));
        
        $validatorsName = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 30)));
        $this->getElement('name')->addValidators($validatorsName);
        $validatorsNameBanner = array(new Zend_Validate_StringLength(array('max' => 90)));
        $this->getElement('bannerSectionText')->addValidators($validatorsNameBanner);
    }

    public function isValid($data) {
        
        $status = parent::isValid($data);
        if (!$status) {
            return false;
        }
       
        if(!empty($data['description'])){
            $obj = new Model_ProductSectionData();
            if(!empty($data['Isedit']) && $data['Isedit'] == 1){
    
                $sendData = array(
                    'data' => $data['description'],
                    'id' => $data['company_id']
                );
                $descCount = $obj->getDescription($sendData);    
            }
            else{
                
                $sendData = array(
                    'data' => $data['description']
                );
                $descCount = $obj->getDescription($sendData);
            }
             
            if($descCount > 0){
                $this->getElement('description')->setErrors(array("This Company identifier already exists. Please enter a new identifier."));
                $status = false;
            }
        }
        
        
        if (!empty($data['category_id'])) {
            $course = new Model_Courses();
            $courseData = $course->fetchCoursesByLabels(explode(',', $data['category_id']));
            $diff = array_diff(array_keys($courseData), explode(',', $data['excluded_course_ids']));
            if (empty($diff)) {
                $this->getElement('category_id')->setErrors(array("Cannot exclude all courses for selected categories"));
                $status = false;
            }
        }

        $status = $this->validateLearnerRange($data['learnerRange'], $status, 'learnerRange');
        $dataArr = array('agencyName' => array(), 'lmsurl' => array(), 'company_sf_acc_id' => array());
        if (!empty($data['companyAgencies'])) {
            foreach ($data['companyAgencies'] as $key => $value) {
                if ($key != '__template__') {
                    if (!empty($value)) {
                        $agencyName = '';
                        $url = '';
                        foreach ($value as $keyA => $valueA) {
                            if (!empty($valueA)) {
                                if (array_key_exists($keyA, $dataArr) && in_array($valueA, $dataArr[$keyA])) {
                                    if ($keyA == 'agencyName') {
                                        $this->getSubForm('companyAgencies')->getSubForm($key)->getElement($keyA)->setErrors(array("Agency " . $valueA . " cannot be added twice."));
                                        $status = false;
                                        break;
                                    } elseif ($keyA == 'lmsurl') {
                                        $this->getSubForm('companyAgencies')->getSubForm($key)->getElement($keyA)->setErrors(array("Lms Url " . $valueA . " cannot be added twice."));
                                        $status = false;
                                        break;
                                    } else if ($keyA == 'company_sf_acc_id') {
                                        $this->getSubForm('companyAgencies')->getSubForm($key)->getElement($keyA)->setErrors(array("SF ID " . $valueA . " cannot be added twice."));
                                        $status = false;
                                        break;
                                    }
                                    // else {
                                    //     $this->getSubForm('companyAgencies')->getSubForm($key)->getElement($keyA)->setErrors(array("Domain ".$valueA." cannot be added to two agencies."));
                                    //     $status = false;
                                    //     break;
                                    // }
                                } else {
                                    $dataArr[$keyA][] = $valueA;
                                }

                                if ($keyA == 'agencyName') {
                                    $agencyName = $valueA;
                                }
                                if ($keyA == 'lmsurl') {
                                    $url = $valueA;
                                }
                            } else {
                                if (!empty($agencyName) && $keyA == 'lmsurl') {
                                    $this->getSubForm('companyAgencies')->getSubForm($key)->getElement($keyA)->setErrors(array("Lms Url " . $valueA . " cannot be empty."));
                                    $status = false;
                                    break;
                                }
                                if (!empty($agencyName) && $keyA == 'company_sf_acc_id') {
                                    $this->getSubForm('companyAgencies')->getSubForm($key)->getElement($keyA)->setErrors(array("SF ID " . $valueA . " cannot be empty."));
                                    $status = false;
                                    break;
                                }
                            }
                        }
                        if ($url != '') {
                            $obj = new Model_ProductSectionData();
                            $objSM = new Model_SectionMapping();
                            $urlData = $obj->fetchAll(array('name = ?' => $url, 'sectionType = ?' => 'lmsurl', 'status = ?' => 1));
                            if (!empty($urlData)) {
                                $urlData = current($urlData);
                                $mapData = $objSM->getByProductSection('agency', $urlData['id']);
                                if (!empty($mapData)) {
                                    $id = current($mapData);
                                    $idData = $obj->fetchAll(array('id = ?' => $id));
                                    $idData = current($idData);
                                    if (!empty($idData) && $agencyName != '' && $idData['name'] != $agencyName) {
                                        $this->getSubForm('companyAgencies')->getSubForm($key)->getElement($keyA)->setErrors(array("Lms Url " . $url . " is already used for agency " . $idData['name']));
                                        $status = false;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        $defPricingCountries = array();
        $accessObj = new Model_AccessDays();
        $accessDaysIds = $accessObj->getAccessDaysById('osl');
        $catPriceSet = false;
        $allCatPriceSet = false;
        if (!empty($data['companyPricingCat'])) {
            $defCountries = array();
            $countries = array();
            $learnerRArr = array();
            foreach ($data['companyPricingCat'] as $key => $value) {
                if ($key != '__template__' && $value['location_mode'] != 0) {
                    if (!empty($value)) {
                        if ($value['linkable_id_prod'] == 0) {
                            $allCatPriceSet = true;
                        }
                        if (empty($value['flat_price'])) {
                            $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('flat_price')->setErrors(array("Flatprice is required."));
                            $status = false;
                        }
                        if (!empty($value['flat_price']) && $value['flat_price'] < 0) {
                            $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('flat_price')->setErrors(array("Flatprice cannot be negative."));
                            $status = false;
                        } else {
                            $catPriceSet = true;
                        }
                        if (!empty($value['flat_discount']) && $value['flat_discount'] < 0) {
                            $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('flat_discount')->setErrors(array("Discount cannot be negative."));
                            $status = false;
                        }
                        if (!empty($value['access_day_id']) && $value['access_day_id'] != array_search(ENTERPRISE_ACCESS_DAYS, $accessDaysIds)) {
                            $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('access_day_id')->setErrors(array("Access Days can only be " . ENTERPRISE_ACCESS_DAYS));
                            $status = false;
                        }
                        if ($value['location_mode'] == 0) {
                            $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('location_mode')->setErrors(array("location_mode is required."));
                            $status = false;
                        } elseif ($value['location_mode'] > 0) {
                            if ($value['location_mode'] == 1 && $value['cluster_id'] == 0) {
                                $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('cluster_id')->setErrors(array("Please select cluster for pricing."));
                                $status = false;
                            }
                            if ($value['location_mode'] == 2 && $value['country_id'] == 0) {
                                $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('country_id')->setErrors(array("Please select country for pricing."));
                                $status = false;
                            }
                        }

                        if ($value['def_country_id'] == 0) {
                            $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('def_country_id')->setErrors(array("Please select default country for pricing."));
                            $status = false;
                        } else {
                            if (count($defCountries) >= 1 && !in_array($value['def_country_id'], $defCountries)) {
                                $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('def_country_id')->setErrors(array("Default country has to be same accross multiple pricings."));
                                $status = false;
                            }
                            if (count($defPricingCountries) >= 1 && !in_array($value['def_country_id'], $defPricingCountries)) {
                                $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('def_country_id')->setErrors(array("Default country has to be same accross multiple pricings."));
                                $status = false;
                            }
                            $defCountries[] = $value['def_country_id'];
                            $defPricingCountries[] = $value['def_country_id'];
                        }
                        if (empty($learnerRArr[$value['linkable_id_prod']])) {
                            $learnerRArr[$value['linkable_id_prod']] = array(
                                'data' => array(),
                                'maxVals' => array(),
                            );
                        }
                        $status = $this->validateLRCat($status, $value, $key, $learnerRArr[$value['linkable_id_prod']], 'companyPricingCat');
                        if (!$status) {
                            break;
                        }
                        $learnerRArr[$value['linkable_id_prod']]['data'][$value['learners_range_min']] = $value['learners_range_min'] . '_' . $value['learners_range_max'] . '_' . $key;
                        $learnerRArr[$value['linkable_id_prod']]['maxVals'][$value['learners_range_max']] = 1;

                        /* if ($value['country_id'] != US_COUNTRY_ID) {
                          $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('country_id')->setErrors(array("Country other than US not allowed."));
                          $status = false;
                          break;
                          } */
                        $countries[] = $value['country_id'];

                        if ($value['access_day_id'] == 0) {
                            $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('access_day_id')->setErrors(array("Please select accessDays for pricing."));
                            $status = false;
                        }
                    }
                }
            }
            if ($status && !empty($learnerRArr)) {
                foreach ($learnerRArr as $key => $value) {
                    $catData = $value['data'];
                    if (empty($catData[1])) {
                        $data = array_shift($catData);
                        $data = explode('_', $data);
                        $this->getSubForm('companyPricingCat')->getSubForm($data[2])->getElement('learners_range_min')->setErrors(array("Learners range min has to start with 1."));
                        $status = false;
                        break;
                    }
                    ksort($catData);
                    $catDataMax = array_pop($catData);
                    $catDataMax = explode('_', $catDataMax);
                    if (!empty($catDataMax[1]) && $catDataMax[1] != 0) {
                        $this->getSubForm('companyPricingCat')->getSubForm($catDataMax[2])->getElement('learners_range_max')->setErrors(array("Learners range max for last range has to be zero(0)."));
                        $status = false;
                        break;
                    }
                    $catData = $value['data'];
                    ksort($catData);
                    $lastMax = 0;
                    foreach ($catData as $key => $value) {
                        $catDataVal = explode('_', $value);
                        if ($key != 1 && !empty($catDataVal[0]) && $catDataVal[0] != ++$lastMax) {
                            $this->getSubForm('companyPricingCat')->getSubForm($catDataVal[2])->getElement('learners_range_min')->setErrors(array("Learners range min has to be max + 1 for previous range."));
                            $status = false;
                            break;
                        }
                        $lastMax = $catDataVal[1];
                    }
                }
            }
            if (!empty($defCountries) && !empty($countries)) {
                if (!empty(array_diff($countries, $defCountries))) {
                    $this->getSubForm('companyPricingCat')->getSubForm('new')->getElement('country_id')->setErrors(array("Default Country has to match country in all category pricings."));
                    $status = false;
                }
            }
            if ($status && !$allCatPriceSet && !empty($learnerRArr)) {
                $this->getSubForm('companyPricingCat')->getSubForm('new')->getElement('linkable_id_prod')->setErrors(array("Please set All Category Pricing."));
                $status = false;
            }
        }
        $coursePriceSet = false;
        if (!empty($data['companyPricingCourse'])) {
            $defCountries = array();
            $countries = array();
            $learnerRArr = array();
            $discount_or_price = array();
            foreach ($data['companyPricingCourse'] as $key => $value) {
                if ($key != '__template__' && $value['location_mode'] != 0) {
                    if (!empty($value)) {
                        if (empty($value['flat_price']) && empty($value['flat_discount'])) {
                            $this->getSubForm('companyPricingCourse')->getSubForm($key)->getElement('flat_price')->setErrors(array("Flatprice or Flatdiscount is required."));
                            $status = false;
                        } elseif (empty($value['flat_price']) && !empty($value['flat_discount'])) {
                            if (!empty($discount_or_price[$value['training_id']])) {
                                if ($discount_or_price[$value['training_id']] != 'discount') {
                                    $this->getSubForm('companyPricingCourse')->getSubForm($key)->getElement('flat_discount')->setErrors(array("Please fill either Discount or FlatPrice in all sections."));
                                    $status = false;
                                }
                            } else {
                                $discount_or_price[$value['training_id']] = 'discount';
                            }
                            if ($value['flat_discount'] < 0) {
                                $this->getSubForm('companyPricingCourse')->getSubForm($key)->getElement('flat_discount')->setErrors(array("Discount cannot be negative."));
                                $status = false;
                            } else {
                                $coursePriceSet = true;
                            }
                        } elseif (empty($value['flat_discount']) && !empty($value['flat_price'])) {
                            if (!empty($discount_or_price[$value['training_id']])) {
                                if ($discount_or_price[$value['training_id']] != 'flatprice') {
                                    $this->getSubForm('companyPricingCourse')->getSubForm($key)->getElement('flat_discount')->setErrors(array("Please fill either Discount or FlatPrice in all sections."));
                                    $status = false;
                                }
                            } else {
                                $discount_or_price[$value['training_id']] = 'flatprice';
                            }
                            if ($value['flat_price'] < 0) {
                                $this->getSubForm('companyPricingCourse')->getSubForm($key)->getElement('flat_price')->setErrors(array("Flatprice cannot be negative."));
                                $status = false;
                            } else {
                                $coursePriceSet = true;
                            }
                        } else {
                            $this->getSubForm('companyPricingCourse')->getSubForm($key)->getElement('flat_price')->setErrors(array("Flatprice and Flatdiscount both can't be filled."));
                            $status = false;
                        }


                        if (!empty($value['access_day_id']) && $value['access_day_id'] != array_search(ENTERPRISE_ACCESS_DAYS, $accessDaysIds)) {
                            $this->getSubForm('companyPricingCourse')->getSubForm($key)->getElement('access_day_id')->setErrors(array("Access Days can only be " . ENTERPRISE_ACCESS_DAYS));
                            $status = false;
                        }
                        if ($value['location_mode'] == 0) {
                            $this->getSubForm('companyPricingCourse')->getSubForm($key)->getElement('location_mode')->setErrors(array("location_mode is required."));
                            $status = false;
                        } elseif ($value['location_mode'] > 0) {
                            if ($value['location_mode'] == 1 && $value['cluster_id'] == 0) {
                                $this->getSubForm('companyPricingCourse')->getSubForm($key)->getElement('cluster_id')->setErrors(array("Please select cluster for pricing."));
                                $status = false;
                            }
                            if ($value['location_mode'] == 2 && $value['country_id'] == 0) {
                                $this->getSubForm('companyPricingCourse')->getSubForm($key)->getElement('country_id')->setErrors(array("Please select country for pricing."));
                                $status = false;
                            }
                        }

                        if ($value['def_country_id'] == 0) {
                            $this->getSubForm('companyPricingCourse')->getSubForm($key)->getElement('def_country_id')->setErrors(array("Please select default country for pricing."));
                            $status = false;
                        } else {
                            if (count($defCountries) >= 1 && !in_array($value['def_country_id'], $defCountries)) {
                                $this->getSubForm('companyPricingCourse')->getSubForm($key)->getElement('def_country_id')->setErrors(array("Default country has to be same accross multiple pricings."));
                                return false;
                            }
                            if (count($defPricingCountries) >= 1 && !in_array($value['def_country_id'], $defPricingCountries)) {
                                $this->getSubForm('companyPricingCourse')->getSubForm($key)->getElement('def_country_id')->setErrors(array("Default country has to be same accross multiple pricings."));
                                $status = false;
                            }
                            $defPricingCountries[] = $value['def_country_id'];
                            $defCountries[] = $value['def_country_id'];
                        }

                        if (empty($learnerRArr)) {
                            $learnerRArr = array(
                                'data' => array(),
                                'maxVals' => array(),
                            );
                        }
                        if (empty($learnerRArr['data'][$value['training_id']])) {
                            $learnerRArr['data'][$value['training_id']] = array();
                        }
                        if (empty($learnerRArr['maxVals'][$value['training_id']])) {
                            $learnerRArr['maxVals'][$value['training_id']] = array();
                        }
                        $status = $this->validateLRCourse($status, $value, $key, $learnerRArr, 'companyPricingCourse');
                        if (!$status) {
                            break;
                        }
                        $learnerRArr['data'][$value['training_id']][$value['learners_range_min']] = $value['learners_range_min'] . '_' . $value['learners_range_max'] . '_' . $key;
                        $learnerRArr['maxVals'][$value['training_id']][$value['learners_range_max']] = 1;

                        // if ($value['country_id'] != US_COUNTRY_ID) {
                        //     $this->getSubForm('companyPricingCourse')->getSubForm($key)->getElement('country_id')->setErrors(array("Country other than US not allowed."));
                        //      $status = false;
                        //      break;
                        // }
                        $countries[] = $value['country_id'];
                        // if (count($learnerRArr) >= 1 && in_array($value['learners_range_id'], $learnerRArr)) {
                        //         $this->getSubForm('companyPricingCourse')->getSubForm($key)->getElement('learners_range_id')->setErrors(array("Pricing already set for this learners range."));
                        //          $status = false;
                        //          break;
                        //     } else{
                        //         $learnerRArr[] = $value['learners_range_id'];
                        //     }

                        if ($value['access_day_id'] == 0) {
                            $this->getSubForm('companyPricingCourse')->getSubForm($key)->getElement('access_day_id')->setErrors(array("Please select accessDays for pricing."));
                            $status = false;
                        }
                    }
                }
            }
            if ($status && !empty($learnerRArr['data'])) {
                $value = $learnerRArr;
                $catData = $value['data'];
                foreach ($catData as $key => $valT) {
                    if (!empty($valT) && empty($valT[1])) {
                        $data = array_shift($valT);
                        $data = explode('_', $data);
                        if (!empty($data[2])) {
                            $this->getSubForm('companyPricingCourse')->getSubForm($data[2])->getElement('learners_range_min')->setErrors(array("Learners range min has to start with 1."));
                            $status = false;
                        }
                    }
                    ksort($valT);
                    $catDataMax = array_pop($valT);
                    $catDataMax = explode('_', $catDataMax);
                    if (!empty($catDataMax[1]) && $catDataMax[1] != 0) {
                        if (!empty($catDataMax[2])) {
                            $this->getSubForm('companyPricingCourse')->getSubForm($catDataMax[2])->getElement('learners_range_max')->setErrors(array("Learners range max for last range has to be zero(0)."));
                            $status = false;
                        }
                    }
                }

                $catData = $value['data'];
                foreach ($catData as $key => $valT) {
                    $lastMax = 0;
                    ksort($valT);
                    foreach ($valT as $key => $valP) {
                        $catDataVal = explode('_', $valP);
                        if ($key != 1 && !empty($catDataVal[0]) && $catDataVal[0] != ++$lastMax && !empty($catDataVal[2])) {
                            $this->getSubForm('companyPricingCourse')->getSubForm($catDataVal[2])->getElement('learners_range_min')->setErrors(array("Learners range min has to be max + 1 for previous range."));
                            $status = false;
                            break;
                        }
                        $lastMax = $catDataVal[1];
                    }
                }
            }
            if (!empty($defCountries) && !empty($countries)) {
                if (!empty(array_diff($countries, $defCountries))) {
                    $this->getSubForm('companyPricingCourse')->getSubForm('new')->getElement('country_id')->setErrors(array("Default Country has to match country in all course pricings."));
                    $status = false;
                }
            }
            if ($catPriceSet && !$coursePriceSet) {
                $this->getSubForm('companyPricingCourse')->getSubForm('new')->getElement('flat_price')->setErrors(array("Please set course pricing."));
                $status = false;
            }
        }

        // if (!empty($data['company_domains'])) {
        //     $obj = new Model_SectionMapping();
        //     foreach ($data['company_domains'] as $record) {
        //         $records = $obj->getBySectionId($record);
        //         if (!empty($records) && !empty($records['company']) && $records['company'][0] != $data['company_id']) {
        //             $this->getElement('company_domains_err')->setErrors(array("Domain ".$this->_domains[$record]." already added to another company"));
        //             $status = false;
        //         }
        //     }
        //     $obj =new Model_Labels();
        //     $labels = $obj->fetchForSelect();
        //     $consumedCategories = array();
        //     if (!empty($recordCount)) {
        //         foreach ($recordCount as $record) {
        //             if ($record['count'] >= 4) {
        //                 $consumedCategories[] = $labels[$record['linkable_id']];
        //             }
        //         }
        //     }
        //     if (!empty($consumedCategories)) {
        //         $this->getElement('label_id_err')->setErrors(array("4 alumni already added to: ".implode(', ', $consumedCategories)."."));
        //         $status = false;
        //     }
        // }
        //if(empty($data['isOsl']) && empty($data['isLvc']) && empty($data['isBundle']))
        if (empty($data['isOsl']) && empty($data['isLvc']) && empty($data['isBundle'])) {
            $this->getElement('isOsl')->setErrors(array("Atleast one training type required"));
            $status = false;
        }
        return $status;
    }

    public function validateLearnerRange($data, $status, $name) { //prd($data);
        $last = 0;
        $first = 0;
        $size = sizeof($data);
        $i = 0;
        foreach ($data as $key => $value) {
            $first++;
            if ($value['min'] < 0 || !filter_var($value['min'], FILTER_VALIDATE_INT)) {
                if ($value['min'] <= 0 && $i < 1) {
                    $this->getSubForm($name)->getSubForm($key)->getElement('min')->setErrors(array("Learners range should be an integer."));
                    $status = false;
                } else {
                    $this->getSubForm($name)->getSubForm($key)->getElement('min')->setErrors(array("Learners range min for next range should be previous range max+1."));
                    $status = false;
                }
                $this->getSubForm($name)->getSubForm($key)->getElement('min')->setErrors(array("Learners range should be an integer."));
                $status = false;
            }
            if ($first == 1) {
                if ($value['min'] != 1) {
                    $this->getSubForm($name)->getSubForm($key)->getElement('min')->setErrors(array(" Learner Min has to be start from 1"));
                    $status = false;
                }
            }
            if ($value['max'] !== '0') {
                if ($value['max'] < 0 || !filter_var($value['max'], FILTER_VALIDATE_INT)) {
                    $this->getSubForm($name)->getSubForm($key)->getElement('max')->setErrors(array("Learners range has to be integer."));
                    $status = false;
                }
            }
            if ($value['max'] != 0 && $value['min'] >= $value['max'] && $first < $size) {
                $this->getSubForm($name)->getSubForm($key)->getElement('max')->setErrors(array("Learners range max has to be greater than min."));
                $status = false;
            }
            if ($value['min'] != $last + 1) {
                $this->getSubForm($name)->getSubForm($key)->getElement('min')->setErrors(array("Learners range min for this range should be previous range max+1"));
                $status = false;
            }
            if ($status && $value['max'] == 0) {
                $status = true;
                break;
            }
            if ($first == $size) {
                if ($value['max'] != 0) {
                    $this->getSubForm($name)->getSubForm($key)->getElement('max')->setErrors(array("Learners range max for last range has to be zero(0)"));
                    $status = false;
                }
            }
            $last = $value['max'];
            $i++;
        }

        return $status;
    }

    public function validateLRCourse($status, $value, $key, $learnerRArr, $name) {
        if ($value['learners_range_min'] < 0 || !filter_var($value['learners_range_min'], FILTER_VALIDATE_INT)) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_min')->setErrors(array("Learners range has to be integer."));
            return false;
        }
        if ($value['learners_range_max'] > 0 && !filter_var($value['learners_range_max'], FILTER_VALIDATE_INT)) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_max')->setErrors(array("Learners range has to be integer."));
            return false;
        }
        if ($value['learners_range_max'] != 0 && $value['learners_range_min'] >= $value['learners_range_max']) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_max')->setErrors(array("Learners range max has to be greater than min."));
            return false;
        }

        if (!empty($learnerRArr['data'][$value['training_id']][$value['learners_range_min']])) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_min')->setErrors(array("Learners range min cannot be same for a category."));
            return false;
        }
        if (!empty($learnerRArr['data'][$value['training_id']][$value['learners_range_max']])) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_max')->setErrors(array("Learners range max cannot be same as min for a category."));
            return false;
        }
        if (!empty($learnerRArr['maxVals'][$value['training_id']][$value['learners_range_min']])) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_min')->setErrors(array("Learners range min cannot be same as max for a category."));
            return false;
        }
        if (!empty($learnerRArr['maxVals'][$value['training_id']][$value['learners_range_max']])) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_max')->setErrors(array("Learners range max cannot be same for a category."));
            return false;
        }
        return $status;
    }

    public function validateLRCat($status, $value, $key, $learnerRArr, $name) {
        if ($value['learners_range_min'] < 0 || !filter_var($value['learners_range_min'], FILTER_VALIDATE_INT)) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_min')->setErrors(array("Learners range has to be integer."));
            return false;
        }
        if ($value['learners_range_max'] > 0 && !filter_var($value['learners_range_max'], FILTER_VALIDATE_INT)) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_max')->setErrors(array("Learners range has to be integer."));
            return false;
        }
        if ($value['learners_range_max'] != 0 && $value['learners_range_min'] >= $value['learners_range_max']) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_max')->setErrors(array("Learners range max has to be greater than min."));
            return false;
        }

        if (!empty($learnerRArr['data'][$value['learners_range_min']])) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_min')->setErrors(array("Learners range min cannot be same for a category."));
            return false;
        }
        if (!empty($learnerRArr['data'][$value['learners_range_max']])) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_max')->setErrors(array("Learners range max cannot be same as min for a category."));
            return false;
        }
        if (!empty($learnerRArr['maxVals'][$value['learners_range_min']])) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_min')->setErrors(array("Learners range min cannot be same as max for a category."));
            return false;
        }
        if (!empty($learnerRArr['maxVals'][$value['learners_range_max']])) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_max')->setErrors(array("Learners range max cannot be same for a category."));
            return false;
        }
        return $status;
    }

    protected function getSubFormDecoratorsMain($className, $id) {
        return array(
            'FormElements',
            array(
                'HtmlTag', array('tag' => 'ul')
            ),
            array(
                array('row' => 'HtmlTag'),
                array('tag' => 'li', 'class' => $className, 'id' => $id)
            )
        );
    }

    public function removeUneditableElements() {
        $this->removeElement('url');
        return false;
    }

    public function subFormValidations($data, $subForm, $status) {
        $count = 0;
        $accessDays = $data;
        end($accessDays);
        $keyA = key($accessDays);
        if ($subForm == 'accessDays' && count($data) > 2) {
            $this->getSubForm($subForm)->getSubForm($keyA)->getElement('accessDays')->setErrors(array("Only 2 bundle prices are allowed."));
            $status = false;
        }
        return $status;
    }

    public function _decorate() {
        
    }

}
