<?php

class Form_MediaCoverage extends BaseApp_Form
{

    public function init(){

        $this->setName('MediaCoverage');
        $this->setMethod('post');
         //adding Label name element

        $this->addElement('text','name',array(
            'label'=>'Name',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('text','title',array(
            'label'=>'Title',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('text','imagePath',array(
            'label'=>'Image Url',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                new BaseApp_Validate_Image('mediaCoverage', 'imagePath', true)
            )
        ));

        $this->addElement('textarea','details',array(
            'label'=>'Details',
            'required'=>true,
            'cols' => 60,
            'rows' => 6,
            'class' =>'fck-enable'
        ));

        $this->addElement('text','link',array(
            'label'=>'Link',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('checkbox','isPromoted',array(
            'label'=>'Is Promoted','value'=>0
        ));

        $this->addElement('text','publishDate',array(
            'label'=>'Published Date',
            'required'=>true,
            'class'=>'datepicker'
        ));

         $this->addElement('submit','Add Media Coverage',array(
          'ignore'=>true,
          'label'=>'Add Media Coverage',
          'class'=>'btn btn-info'
         ));
         
         $validatorsName = array(new Zend_Validate_StringLength(array('max' => 100)));
         $this->getElement('name')->addValidators($validatorsName);         
    }
}