
<?php

class Form_University extends BaseApp_Form
{
    const TYPE_UNIVERSITY_MASTERS_PAGE='university_masters_page';
        
    protected $pageTypes = array();
    public function init(){
        
        $this->setName('University');
        $this->setMethod('post');
        $this->pageTypes=array(
                                self::TYPE_UNIVERSITY_MASTERS_PAGE=>'University Master Page'                                
                            );
        //name - text 
                         

        $this->addElement('text','name',array(
            'label'=>'University Name *',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
        ));
        //alt text - text
        $this->addElement('text','alt_text',array(
            'label'=>'Image Alt-Text *',
            'required'=>true,
            'class'=>'longtext'           
        ));
        //link - text
        $this->addElement('text','link',array(
            'label'=>'Image Link ',            
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                new BaseApp_Validate_Url()
            )
        ));
        //page type  dropdown list
        $this->addElement('select', 'page_type', array(
            'label' => 'Page Type *',
            'required' => true,
            'class' => 'multiple skipPreviousClick',
            'multiple' => true,
            'registerInArrayValidator' => false,
            'multioptions' => $this->pageTypes
        ));
        $basicGroup = array('name','alt_text','link','page_type');
        $this->addDisplayGroup($basicGroup, 'basic_group');
        $this->getDisplayGroup('basic_group')
                ->setLegend('Partnering University')
                ->clearDecorators()
                ->addDecorator('FormElements')
                ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper'));
        //image upload

        // logo colored
        $this->addElement($this->createElement('file','logo_colored',
        array(
            'label'=>'University Logo(Colored)(Max Height 30px, 10Kb)*',            
            'destination'=>sys_get_temp_dir(),
        //     'validators'=>array('Extension' => array('png','svgz'),
        //                 array('ImageSize',false, array('maxheight'=>38)),
        //                 array('Size',false, array('useByteString'=> true, 'max' => '10kb'))                        
        // )
        )
    ));
        $this->addElement('text','university_logo_colored',array(                        
            'helper' => 'formNote' ,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'readonly' => true,
            'style' => array(
                'border: 0 solid;'
            ),
            //'label'=>'Existing Banner Logo',
        ));

        //bw image 
        $this->addElement($this->createElement('file','logo_bw',array(
            'label'=>'University Logo(B/W)(Max Height 38px, 10Kb)*',                        
            'destination'=>sys_get_temp_dir(),
        //     'validators'=>array('Extension' => array('png','svgz'),
        //                 array('ImageSize',false, array('maxheight'=>38)),
        //                 array('Size',false, array('useByteString'=> true, 'max' => '10kb'))                        
        // )
    )));
        $this->addElement('text','university_logo_bw',array(                        
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'readonly' => true,
            'helper' => 'formNote' ,
            'style' => array(
                'border: 0 solid;'
            )
            //'label'=>'Existing Thumb Image',
        ));

        
 

        $link_group = array('logo_colored', 'university_logo_colored','logo_bw','university_logo_bw');
        $this->addDisplayGroup($link_group, 'link_group');
        $this->getDisplayGroup('link_group')
                ->setLegend('Add Logo')
                ->clearDecorators()                                
                ->addDecorator('FormElements')
                ->addDecorator('Fieldset', array());

        $this->addElement('submit','Add University',array(
          'ignore'=>true,
          'label'=>'Save University',
          'class'=>'btn btn-info'
         ));
         
        //image
       
        //image
        //$complexityValidator = new Zend_Validate_Regex('/^[A-Za-z 0-9_-]+$/');
        //$complexityValidator->setMessage('Name cannot contain special characters');
        $validatorsName = array(new Zend_Validate_StringLength(array('max' => 100)));
        $this->getElement('name')->addValidators(array($validatorsName));  
    }

    public function isValid($data){         

        $status = parent::isValid($data);
        if(!$status){
            return $status;
        }
        $bwLogoType = $_FILES['logo_bw']; 
        $colorLogoType = $_FILES['logo_colored'];        
        if($bwLogoType['type'] == ""){
            $status = true;
        }else if($bwLogoType['type'] == "image/svg+xml"){
            if($bwLogoType['size'] > 10000){
                $this->getElement('logo_bw')->setErrors(array("Image size cannot exceed 10kb"));
                $status = false;
            }             
        }else if($bwLogoType['type'] == "image/png"){
            if($bwLogoType['size'] > 10000){
                $this->getElement('logo_bw')->setErrors(array("Image size cannot exceed 10kb"));
                $status = false;
            }             
            list($width, $height) = getimagesize($bwLogoType['tmp_name']);
             
            if($height > 38){
                $this->getElement('logo_bw')->setErrors(array("Image max height allowed is 38px"));
                $status = false;
            }            
        }
        else{
            $this->getElement('logo_bw')->setErrors(array("Invalid Image type provided"));             
            $status = false; 
        }
         
        
        
         
        if($colorLogoType['type'] == ""){
            $status = true;
        }else if($colorLogoType['type'] == "image/svg+xml"){
            if($colorLogoType['size'] > 10000){
                $this->getElement('logo_colored')->setErrors(array("Image size cannot exceed 10kb"));
                $status = false;
            }             
        }else if($colorLogoType['type'] == "image/png"){
             
            if($colorLogoType['size'] > 10000){
                
                $this->getElement('logo_colored')->setErrors(array("Image size cannot exceed 10kb"));
                $status = false;
            }             
            list($width, $height) = getimagesize($colorLogoType['tmp_name']);
             
            if($height > 30){
                $this->getElement('logo_colored')->setErrors(array("Image max height allowed is 30px"));
                $status = false;
            }            
        }
        else{
            $this->getElement('logo_colored')->setErrors(array("Invalid Image type provided"));             
            $status = false; 
        }
        
        
        if (!empty($bwLogoType['name']) && ($bwLogoType['name'] != '')) {
            $fileName = $bwLogoType['name'];
            $fileName = explode(".", $fileName)[0];
            if (!@preg_match('/^[A-Za-z0-9_-]+$/', $fileName)) {                
                $this->getElement('logo_bw')->setErrors(array("File name can only be Alpha numerics with _ and - "));
                $status = false;
            }
        }        
        if (!empty($colorLogoType['name']) && ($colorLogoType['name'] != '')) {
            $fileName1 = $colorLogoType['name'];             
            $fileName1 = explode(".", $fileName1)[0];             
            if (!@preg_match('/^[A-Za-z0-9_-]+$/', $fileName1)) {                 
                $this->getElement('logo_colored')->setErrors(array("File name can only be Alpha numerics with _ and - "));
                $status = false;
            }
        } 
        return $status;          
    }
}