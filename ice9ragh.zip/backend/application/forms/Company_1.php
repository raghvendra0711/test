<?php

class Form_Company extends BaseApp_SubForm {

    protected $_domains;

    public function init() {
        $this->setName('Company');
        $this->setMethod('post');
        $session = new Zend_Session_Namespace('form');
        //adding Label name element

        $this->addElement('text', 'name', array(
            'label' => 'Name*',
            'required' => true,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'placeholder' => 'Company Name'
        ));

        $this->addElement('text', 'imageUrl', array(
            'label' => 'Image Url for Company*',
            'required' => true,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'placeholder' => 'Company Logo',
            'validators' => array(
                new BaseApp_Validate_Image('category', 'company_logo')
            )
        ));
        $this->addElement('text', 'bannerImageUrl', array(
            'label' => 'Banner Image Url for Company',
//            'required'=>true,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'placeholder' => 'Banner Image Url',
            'validators' => array(
                new BaseApp_Validate_Image('category', 'company_banner')
            )
        ));
        $this->addElement('text', 'bannerSectionText', array(
            'label' => 'Banner Text for Company',
//                'required'=>true,
            'placeholder' => 'Banner Text for Company',
            'filters' => array('StringTrim'),
            'class' => 'longtext'
        ));

        $this->addElement('text', 'alt_text', array(
            'label' => 'Alt Text*',
            'required' => true,
            'placeholder' => 'Alt text',
            'filters' => array('StringTrim'),
            'class' => 'longtext'
        ));

        $this->addElement('text', 'description', array(
            'label' => 'Company Identifier*',
            'required' => true,
            'placeholder' => 'Company Identifier',
            'filters' => array('StringTrim'),
            'class' => 'longtext',
        ));
        $this->addElement('text', 'company_sf_acc_id', array(
            'label' => 'Company SF Account ID*',
            'required' => true,
            'description' => '*If you don\'t have an SF account ID, please provide some dummy value.',
            'placeholder' => 'Company SF Account ID',
            'filters' => array('StringTrim'),
            'class' => 'longtext',
        ));

        $this->getElement('description')->addValidator('regex', false, array(
            '/^\w+$/u',
            'messages' => array(
                'regexNotMatch' => 'Invalid Identifier'
            )
        ));





        $obj = new Model_Labels();
        // $categoryList = $obj->fetchForSelect(array(''));
        $this->addElement('select', 'category_id_tmp', array(
            'required' => false,
            'size' => 12,
            'label' => 'Categories*',
            'class' => 'categoryListAll',
            'registerInArrayValidator' => false,
            'multioptions' => array('0' => '--Select--') + $obj->getLabelsToshow()
        ));

        $this->addElement('hidden', 'category_id', array(
            'required' => false,
            'value' => ''
        ));



        $this->addElement('select', 'exclusion_courses', array(
            'required' => false,
            'size' => 12,
            'label' => 'Excluded Courses',
            'class' => 'categoryListAll',
            'multioptions' => array('0' => '--All Courses--')
        ));

        $this->addElement('hidden', 'excluded_course_ids', array(
            'required' => false,
            'value' => ''
        ));
        // Master Program List
        $this->addElement('select', 'exclusion_master_program', array(
            'required' => false,
            'size' => 12,
            'label' => 'Excluded Master Program',
            'class' => 'mpListAll',
            'multioptions' => array('0' => '--All Master Programs--')
        ));
        $this->addElement('hidden', 'excluded_masterprogram_ids', array(
            'required' => false,
            'value' => ''
        ));
        /**
         * Price Plans
         */
        $pricePlans = array('1' => 'Discount Price Plan', '2' => 'Fixed Price Plans');
        $this->addElement('select', 'price_plans', array(
            'required' => true,
            'label' => 'Price Plans*',
            'multioptions' => array('0' => '--Select--') + $pricePlans
        ));
        $formElements = array('name', 'imageUrl', 'bannerImageUrl', 'bannerSectionText', 'alt_text', 'description', 'company_sf_acc_id', 'category_id_tmp', 'exclusion_courses', 'exclusion_master_program', 'price_plans');
        // Create a display group within a form
        $this->addDisplayGroup($formElements, 'company-details');

        // Retrive the display group to apply decorators
        $this->getDisplayGroup('company-details')
                ->setLegend('Details')
                ->clearDecorators()
                ->addDecorator('FormElements')
                ->addDecorator('Fieldset', array('class' => 'company-details-group'));

        $subForm1 = new Zend_Form_SubForm();

        $subForm1->setName('companyAgencies');
        foreach ($session->companyAgencies as $agency) {
            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($agency);
            $elements = array();
            if ($agency === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
            }
            $name = new Zend_Form_Element_Text('agencyName');
            $name->addFilter('stringTrim')->setValue('')->setAttrib('class', 'agencyName')->setAttrib('placeholder', 'Agency Name')->setLabel('Agency Name');
            $elements[] = $name;
            $url = new Zend_Form_Element_Text('lmsurl');
            $url->addFilter('stringTrim')->setValue('')->setAttrib('class', 'lmsurl')->setAttrib('placeholder', 'Lms Url')->setLabel('Lms Url');
            $url->addValidator('regex', false, array(
                '/^[\w]*-?[\w]+$/u', //'/^\w+$/u',
                'messages' => array(
                    'regexNotMatch' => 'Invalid Url'
                )
            ));
            $elements[] = $url;

            $agen_sf = new Zend_Form_Element_Text('company_sf_acc_id');
            $agen_sf->addFilter('stringTrim')->setValue('')->setAttrib('placeholder', 'Agency SF ID')->setLabel('Agency SF ID');
            $elements[] = $agen_sf;

            for ($i = 1; $i < 20; $i++) {
                $domain = new Zend_Form_Element_Text('domain' . $i);
                $domain->addFilter('stringTrim')->setValue('')->setAttrib('class', 'domain')->setAttrib('placeholder', 'Agency Domain')->setLabel('Agency Domain')->addValidators(array(new Zend_Validate_Hostname(Zend_Validate_Hostname::ALLOW_DNS)));
                $elements[] = $domain;
            }

            $removeSetsNumber = new Zend_Form_Element_Button('remove');
            $removeSetsNumber->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');

            if ($agency !== 'new') {
                $elements[] = $removeSetsNumber;
            }
            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());

            if ($rowForm->getElement('remove')) {
                $rowForm->getElement('remove')->removeDecorator('Label');
            }

            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm1->addSubForm($rowForm, $agency);
        }

        $subForm1->setDecorators($this->getSubFormDecoratorsMain('companyAgencies', 'companyAgencies'));

        $addAgency = new Zend_Form_Element_Button('add');
        $addAgency->setLabel('Add Agency')->setAttrib('class', 'btn btn-warning add');
        $subForm1->addElement($addAgency);

        $subForm1->setElementDecorators($this->getElementDecorators());
        $subForm1->getElement('add')->removeDecorator('Label');
        $this->addSubForm($subForm1, 'companyAgencies');

        // category pricing subform begin
        $subForm = new Zend_Form_SubForm();
        $subForm->setName('companyPricingCat');
        foreach ($session->companyPricingCat as $pricing) {
            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($pricing);
            $elements = array();
            if ($pricing === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
            }
            $linkableType = new Zend_Form_Element_Hidden('linkable_type');
            $linkableType->setRequired(false)->setValue('category');

            $pricingCategory = new Zend_Form_Element_Select('linkable_id_prod');
            $pricingCategory->setOptions(array('multioptions' => array('0' => '--All--') + $obj->getLabelsToshow(), 'registerInArrayValidator' => false))->setValue('')->setAttrib('class', 'pricingCategory')->setLabel('Category');

            $locationMode = new Zend_Form_Element_Select('location_mode');
            $locationMode->setOptions(array('multioptions' => array(0 => '--Select--', 2 => 'By Country')))->setValue('')->setAttrib('class', 'pricingLevel')->setLabel('Pricing Level');
            // $locationMode->setOptions(array('multioptions' => array(0=>'--Select--',1=>'By Cluster',2=>'By Country')))->setValue('')->setAttrib('class', 'pricingLevel')->setLabel('Pricing Level');

            $country = new Zend_Form_Element_Select('country_id');
            $countryList = array();
            $countryModel = new Model_Country();
            $countryList = $countryModel->fetchForSelect();
            $country->setOptions(array('multioptions' => array('0' => '--Select--') + $countryList, 'registerInArrayValidator' => false))->setValue('')->setAttrib('class', 'country')->setLabel('Country');

            /* $cluster = new Zend_Form_Element_Select('cluster_id');
              $clusterList = array();
              $obj = new Model_Clusters();
              $clusterList = $obj->fetchForSelect();
              $cluster->setOptions(array('multioptions' => array('0' => '--Select--') + $clusterList, 'registerInArrayValidator' => false))->setValue('')->setAttrib('class', 'cluster')->setLabel('Cluster'); */

            $defCountry = new Zend_Form_Element_Select('def_country_id');
            $countryList = array();
            $countryModel = new Model_Country();
            $countryList = $countryModel->fetchForSelect();
            $defCountry->setOptions(array('multioptions' => array('0' => '--Select--') + $countryList, 'registerInArrayValidator' => false))->setValue('')->setAttrib('class', 'country')->setLabel('Default Country');

            $learnerRangeMin = new Zend_Form_Element_Text('learners_range_min');
            $learnerRangeMin->addFilter('stringTrim')->setValue('')->setAttrib('class', 'learnerRangeMin')->setLabel('Learner Range Min');

            $learnerRangeMax = new Zend_Form_Element_Text('learners_range_max');
            $learnerRangeMax->addFilter('stringTrim')->setValue('')->setAttrib('class', 'learnerRangeMax')->setLabel('Learner Range Max');

            $setsNumber = new Zend_Form_Element_Select('access_day_id');
            $accessObj = new Model_AccessDays();
            $setsNumber->addFilter('stringTrim')->setValue('')->setAttrib('class', 'accessDaysCount')->setAttrib('placeholder', 'Access Days')->setLabel('Access Days')->setOptions(array('multioptions' => array('0' => '--Select--') + $accessObj->getAccessDaysById('osl'), 'registerInArrayValidator' => false));

            $trainingType = new Zend_Form_Element_Select('training_id');
            $trainingType->setOptions(array('multioptions' => array(BaseApp_Dao_TrainingTypes::TYPE_ELEARNING => 'Online Self Learning')))->setValue(BaseApp_Dao_TrainingTypes::TYPE_ELEARNING)->setAttrib('class', 'trainingId')->setLabel('Training Type');

            $flatPrice = new Zend_Form_Element_Text('flat_price');
            $flatPrice->addFilter('stringTrim')->setValue('')->setAttrib('class', 'flat_price')->setLabel('Flat Price')->setAttrib('placeholder', 'Flat Price*');

            $discount = new Zend_Form_Element_Text('flat_discount');
            $discount->addFilter('stringTrim')->setValue('')->setAttrib('class', 'flat_discount')->setLabel('Discount(%)')->setAttrib('placeholder', 'Discount (%)');


            $elements = array($pricingCategory, $linkableType, $locationMode, $country, $defCountry, $learnerRangeMin, $learnerRangeMax, $setsNumber, $trainingType, $flatPrice, $discount);

            $removeSetsNumber = new Zend_Form_Element_Button('remove');
            $removeSetsNumber->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');

            if ($pricing !== 'new') {
                $elements[] = $removeSetsNumber;
            }
            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());

            if ($rowForm->getElement('remove')) {
                $rowForm->getElement('remove')->removeDecorator('Label');
            }

            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $pricing);
        }

        $subForm->setDecorators($this->getSubFormDecoratorsMain('companyPricingCat company-page-tabber-hide', 'companyPricingCat'));

        $addPricing = new Zend_Form_Element_Button('add');
        $addPricing->setLabel('Add Pricing')->setAttrib('class', 'btn btn-warning add');
        $subForm->addElement($addPricing);

        $subForm->setElementDecorators($this->getElementDecorators());
        $subForm->getElement('add')->removeDecorator('Label');
        $this->addSubForm($subForm, 'companyPricingCat');
        // category pricing subform end
        // course pricing subform begin
        $subForm = new Zend_Form_SubForm();
        $subForm->setName('companyPricingCourse');
        foreach ($session->companyPricingCourse as $pricing) {
            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($pricing);
            $elements = array();

            if ($pricing === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
            }
            $linkableType = new Zend_Form_Element_Hidden('linkable_type');
            $linkableType->setRequired(false)->setValue('course');

            $locationMode = new Zend_Form_Element_Select('location_mode');
            $locationMode->setOptions(array('multioptions' => array(0 => '--Select--', 2 => 'By Country')))->setValue('')->setAttrib('class', 'location')->setLabel('Pricing Level');
            // $locationMode->setOptions(array('multioptions' => array(0=>'--Select--',1=>'By Cluster',2=>'By Country')))->setValue('')->setAttrib('class', 'location')->setLabel('Pricing Level');

            $country = new Zend_Form_Element_Select('country_id');
            $countryList = array();
            $countryModel = new Model_Country();
            $countryList = $countryModel->fetchForSelect();
            $country->setOptions(array('multioptions' => array('0' => '--Select--') + $countryList, 'registerInArrayValidator' => false))->setValue('')->setAttrib('class', 'country')->setLabel('Country');

            /* $cluster = new Zend_Form_Element_Select('cluster_id');
              $clusterList = array();
              $obj = new Model_Clusters();
              $clusterList = $obj->fetchForSelect();
              $cluster->setOptions(array('multioptions' => array('0' => '--Select--') + $clusterList, 'registerInArrayValidator' => false))->setValue('')->setAttrib('class', 'cluster')->setLabel('Cluster'); */

            $defCountry = new Zend_Form_Element_Select('def_country_id');
            $countryList = array();
            $countryModel = new Model_Country();
            $countryList = $countryModel->fetchForSelect();
            $defCountry->setOptions(array('multioptions' => array('0' => '--Select--') + $countryList, 'registerInArrayValidator' => false))->setValue('')->setAttrib('class', 'country')->setLabel('Default Country');

            $learnerRangeMin = new Zend_Form_Element_Text('learners_range_min');
            $learnerRangeMin->addFilter('stringTrim')->setValue('')->setAttrib('class', 'learnerRangeMin')->setLabel('Learner Range Min');

            $learnerRangeMax = new Zend_Form_Element_Text('learners_range_max');
            $learnerRangeMax->addFilter('stringTrim')->setValue('')->setAttrib('class', 'learnerRangeMax')->setLabel('Learner Range Max');

            $setsNumber = new Zend_Form_Element_Select('access_day_id');
            $accessObj = new Model_AccessDays();
            $setsNumber->addFilter('stringTrim')->setValue('')->setAttrib('class', 'accessDaysCount')->setAttrib('placeholder', 'Access Days')->setLabel('Access Days')->setOptions(array('multioptions' => array('0' => '--Select--') + $accessObj->getAccessDaysById('osl'), 'registerInArrayValidator' => false));

            $trainingType = new Zend_Form_Element_Select('training_id');
            $trainingType->setOptions(array('multioptions' => array(BaseApp_Dao_TrainingTypes::TYPE_ELEARNING => 'Online Self Learning', BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS => 'LVC')))->setValue(BaseApp_Dao_TrainingTypes::TYPE_ELEARNING)->setAttrib('class', 'trainingId')->setLabel('Training Type');

            $flatPrice = new Zend_Form_Element_Text('flat_price');
            $flatPrice->addFilter('stringTrim')->setValue('')->setAttrib('class', 'flat_price')->setLabel('Flat Price')->setAttrib('placeholder', 'Flat Price');

            $discount = new Zend_Form_Element_Text('flat_discount');
            $discount->addFilter('stringTrim')->setValue('')->setAttrib('class', 'flat_discount')->setLabel('Discount(%)')->setAttrib('placeholder', 'Discount (%)');


            $elements = array($linkableType, $locationMode, $country, $defCountry, $learnerRangeMin, $learnerRangeMax, $setsNumber, $trainingType, $flatPrice, $discount);

            $removeSetsNumber = new Zend_Form_Element_Button('remove');
            $removeSetsNumber->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');

            if ($pricing !== 'new') {
                $elements[] = $removeSetsNumber;
            }
            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());

            if ($rowForm->getElement('remove')) {
                $rowForm->getElement('remove')->removeDecorator('Label');
            }

            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $pricing);
        }

        $subForm->setDecorators($this->getSubFormDecoratorsMain('companyPricingCourse company-page-tabber-hide', 'companyPricingCourse'));

        $addPricing = new Zend_Form_Element_Button('add');
        $addPricing->setLabel('Add Pricing')->setAttrib('class', 'btn btn-warning add');
        $subForm->addElement($addPricing);

        $subForm->setElementDecorators($this->getElementDecorators());
        $subForm->getElement('add')->removeDecorator('Label');
        $this->addSubForm($subForm, 'companyPricingCourse');
        // course pricing subform end




        $this->addElement('hidden', 'company_id', array(
            'required' => false,
        ));

        $this->addElement('submit', 'Save Company', array(
            'ignore' => true,
            'label' => 'Save And Continue',
            'class' => 'btn btn-info'
        ));

        $validatorsName = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 30)));
        $this->getElement('name')->addValidators($validatorsName);
        $validatorsNameBanner = array(new Zend_Validate_StringLength(array('max' => 90)));
        $this->getElement('bannerSectionText')->addValidators($validatorsNameBanner);
    }

    public function isValid($data) {
        $status = parent::isValid($data);
        if (!$status) {
            return false;
        }

        if (!empty($data['category_id'])) {
            $course = new Model_Courses();
            $courseData = $course->fetchCoursesByLabels(explode(',', $data['category_id']));
            $diff = array_diff(array_keys($courseData), explode(',', $data['excluded_course_ids']));
            if (empty($diff)) {
                $this->getElement('category_id')->setErrors(array("Cannot exclude all courses for selected categories"));
                $status = false;
            }
        }
        $dataArr = array();
        if (!empty($data['companyAgencies'])) {
            foreach ($data['companyAgencies'] as $key => $value) {
                if ($key != '__template__') {
                    if (!empty($value)) {
                        $agencyName = '';
                        $url = '';
                        foreach ($value as $keyA => $valueA) {
                            if (!empty($valueA)) {
                                if (in_array($valueA, $dataArr)) {
                                    if ($keyA == 'agencyName') {
                                        $this->getSubForm('companyAgencies')->getSubForm($key)->getElement($keyA)->setErrors(array("Agency " . $valueA . " cannot be added twice."));
                                        $status = false;
                                        break;
                                    } elseif ($keyA == 'lmsurl') {
                                        $this->getSubForm('companyAgencies')->getSubForm($key)->getElement($keyA)->setErrors(array("Lms Url " . $valueA . " cannot be added twice."));
                                        $status = false;
                                        break;
                                    } else if ($keyA == 'company_sf_acc_id') {
                                        $this->getSubForm('companyAgencies')->getSubForm($key)->getElement($keyA)->setErrors(array("SF ID " . $valueA . " cannot be added twice."));
                                        $status = false;
                                        break;
                                    }
                                    // else {
                                    //     $this->getSubForm('companyAgencies')->getSubForm($key)->getElement($keyA)->setErrors(array("Domain ".$valueA." cannot be added to two agencies."));
                                    //     $status = false;
                                    //     break;
                                    // }
                                } else {
                                    $dataArr[] = $valueA;
                                }

                                if ($keyA == 'agencyName') {
                                    $agencyName = $valueA;
                                }
                                if ($keyA == 'lmsurl') {
                                    $url = $valueA;
                                }
                            } else {
                                if (!empty($agencyName) && $keyA == 'lmsurl') {
                                    $this->getSubForm('companyAgencies')->getSubForm($key)->getElement($keyA)->setErrors(array("Lms Url " . $valueA . " cannot be empty."));
                                    $status = false;
                                    break;
                                }
                                if (!empty($agencyName) && $keyA == 'company_sf_acc_id') {
                                    $this->getSubForm('companyAgencies')->getSubForm($key)->getElement($keyA)->setErrors(array("SF ID " . $valueA . " cannot be empty."));
                                    $status = false;
                                    break;
                                }
                            }
                        }
                        if ($url != '') {
                            $obj = new Model_ProductSectionData();
                            $objSM = new Model_SectionMapping();
                            $urlData = $obj->fetchAll(array('name = ?' => $url, 'sectionType = ?' => 'lmsurl', 'status = ?' => 1));
                            if (!empty($urlData)) {
                                $urlData = current($urlData);
                                $mapData = $objSM->getByProductSection('agency', $urlData['id']);
                                if (!empty($mapData)) {
                                    $id = current($mapData);
                                    $idData = $obj->fetchAll(array('id = ?' => $id));
                                    $idData = current($idData);
                                    if (!empty($idData) && $agencyName != '' && $idData['name'] != $agencyName) {
                                        $this->getSubForm('companyAgencies')->getSubForm($key)->getElement($keyA)->setErrors(array("Lms Url " . $url . " is already used for agency " . $idData['name']));
                                        $status = false;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        $defPricingCountries = array();
        $accessObj = new Model_AccessDays();
        $accessDaysIds = $accessObj->getAccessDaysById('osl');
        $catPriceSet = false;
        $allCatPriceSet = false;
        if (!empty($data['companyPricingCat'])) {
            $defCountries = array();
            $countries = array();
            $learnerRArr = array();
            foreach ($data['companyPricingCat'] as $key => $value) {
                if ($key != '__template__' && $value['location_mode'] != 0) {
                    if (!empty($value)) {
                        if ($value['linkable_id_prod'] == 0) {
                            $allCatPriceSet = true;
                        }
                        if (empty($value['flat_price'])) {
                            $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('flat_price')->setErrors(array("Flatprice is required."));
                            $status = false;
                        }
                        if (!empty($value['flat_price']) && $value['flat_price'] < 0) {
                            $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('flat_price')->setErrors(array("Flatprice cannot be negative."));
                            $status = false;
                        } else {
                            $catPriceSet = true;
                        }
                        if (!empty($value['flat_discount']) && $value['flat_discount'] < 0) {
                            $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('flat_discount')->setErrors(array("Discount cannot be negative."));
                            $status = false;
                        }
                        if (!empty($value['access_day_id']) && $value['access_day_id'] != array_search(ENTERPRISE_ACCESS_DAYS, $accessDaysIds)) {
                            $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('access_day_id')->setErrors(array("Access Days can only be " . ENTERPRISE_ACCESS_DAYS));
                            $status = false;
                        }
                        if ($value['location_mode'] == 0) {
                            $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('location_mode')->setErrors(array("location_mode is required."));
                            $status = false;
                        } elseif ($value['location_mode'] > 0) {
                            if ($value['location_mode'] == 1 && $value['cluster_id'] == 0) {
                                $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('cluster_id')->setErrors(array("Please select cluster for pricing."));
                                $status = false;
                            }
                            if ($value['location_mode'] == 2 && $value['country_id'] == 0) {
                                $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('country_id')->setErrors(array("Please select country for pricing."));
                                $status = false;
                            }
                        }

                        if ($value['def_country_id'] == 0) {
                            $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('def_country_id')->setErrors(array("Please select default country for pricing."));
                            $status = false;
                        } else {
                            if (count($defCountries) >= 1 && !in_array($value['def_country_id'], $defCountries)) {
                                $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('def_country_id')->setErrors(array("Default country has to be same accross multiple pricings."));
                                $status = false;
                            }
                            if (count($defPricingCountries) >= 1 && !in_array($value['def_country_id'], $defPricingCountries)) {
                                $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('def_country_id')->setErrors(array("Default country has to be same accross multiple pricings."));
                                $status = false;
                            }
                            $defCountries[] = $value['def_country_id'];
                            $defPricingCountries[] = $value['def_country_id'];
                        }
                        if (empty($learnerRArr[$value['linkable_id_prod']])) {
                            $learnerRArr[$value['linkable_id_prod']] = array(
                                'data' => array(),
                                'maxVals' => array(),
                            );
                        }
                        $status = $this->validateLRCat($status, $value, $key, $learnerRArr[$value['linkable_id_prod']], 'companyPricingCat');
                        if (!$status) {
                            break;
                        }
                        $learnerRArr[$value['linkable_id_prod']]['data'][$value['learners_range_min']] = $value['learners_range_min'] . '_' . $value['learners_range_max'] . '_' . $key;
                        $learnerRArr[$value['linkable_id_prod']]['maxVals'][$value['learners_range_max']] = 1;

                        /* if ($value['country_id'] != US_COUNTRY_ID) {
                          $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('country_id')->setErrors(array("Country other than US not allowed."));
                          $status = false;
                          break;
                          } */
                        $countries[] = $value['country_id'];

                        if ($value['access_day_id'] == 0) {
                            $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('access_day_id')->setErrors(array("Please select accessDays for pricing."));
                            $status = false;
                        }
                    }
                }
            }
            if ($status && !empty($learnerRArr)) {
                foreach ($learnerRArr as $key => $value) {
                    $catData = $value['data'];
                    if (empty($catData[1])) {
                        $data = array_shift($catData);
                        $data = explode('_', $data);
                        $this->getSubForm('companyPricingCat')->getSubForm($data[2])->getElement('learners_range_min')->setErrors(array("Learners range min has to start with 1."));
                        $status = false;
                        break;
                    }
                    ksort($catData);
                    $catDataMax = array_pop($catData);
                    $catDataMax = explode('_', $catDataMax);
                    if (!empty($catDataMax[1]) && $catDataMax[1] != 0) {
                        $this->getSubForm('companyPricingCat')->getSubForm($catDataMax[2])->getElement('learners_range_max')->setErrors(array("Learners range max for last range has to be zero(0)."));
                        $status = false;
                        break;
                    }
                    $catData = $value['data'];
                    ksort($catData);
                    $lastMax = 0;
                    foreach ($catData as $key => $value) {
                        $catDataVal = explode('_', $value);
                        if ($key != 1 && !empty($catDataVal[0]) && $catDataVal[0] != ++$lastMax) {
                            $this->getSubForm('companyPricingCat')->getSubForm($catDataVal[2])->getElement('learners_range_min')->setErrors(array("Learners range min has to be max + 1 for previous range."));
                            $status = false;
                            break;
                        }
                        $lastMax = $catDataVal[1];
                    }
                }
            }
            if (!empty($defCountries) && !empty($countries)) {
                if (!empty(array_diff($countries, $defCountries))) {
                    $this->getSubForm('companyPricingCat')->getSubForm('new')->getElement('country_id')->setErrors(array("Default Country has to match country in all category pricings."));
                    $status = false;
                }
            }
            if ($status && !$allCatPriceSet && !empty($learnerRArr)) {
                $this->getSubForm('companyPricingCat')->getSubForm('new')->getElement('linkable_id_prod')->setErrors(array("Please set All Category Pricing."));
                $status = false;
            }
        }
        $coursePriceSet = false;
        if (!empty($data['companyPricingCourse'])) {
            $defCountries = array();
            $countries = array();
            $learnerRArr = array();
            $discount_or_price = array();
            foreach ($data['companyPricingCourse'] as $key => $value) {
                if ($key != '__template__' && $value['location_mode'] != 0) {
                    if (!empty($value)) {
                        if (empty($value['flat_price']) && empty($value['flat_discount'])) {
                            $this->getSubForm('companyPricingCourse')->getSubForm($key)->getElement('flat_price')->setErrors(array("Flatprice or Flatdiscount is required."));
                            $status = false;
                        } elseif (empty($value['flat_price']) && !empty($value['flat_discount'])) {
                            if (!empty($discount_or_price[$value['training_id']])) {
                                if ($discount_or_price[$value['training_id']] != 'discount') {
                                    $this->getSubForm('companyPricingCourse')->getSubForm($key)->getElement('flat_discount')->setErrors(array("Please fill either Discount or FlatPrice in all sections."));
                                    $status = false;
                                }
                            } else {
                                $discount_or_price[$value['training_id']] = 'discount';
                            }
                            if ($value['flat_discount'] < 0) {
                                $this->getSubForm('companyPricingCourse')->getSubForm($key)->getElement('flat_discount')->setErrors(array("Discount cannot be negative."));
                                $status = false;
                            } else {
                                $coursePriceSet = true;
                            }
                        } elseif (empty($value['flat_discount']) && !empty($value['flat_price'])) {
                            if (!empty($discount_or_price[$value['training_id']])) {
                                if ($discount_or_price[$value['training_id']] != 'flatprice') {
                                    $this->getSubForm('companyPricingCourse')->getSubForm($key)->getElement('flat_discount')->setErrors(array("Please fill either Discount or FlatPrice in all sections."));
                                    $status = false;
                                }
                            } else {
                                $discount_or_price[$value['training_id']] = 'flatprice';
                            }
                            if ($value['flat_price'] < 0) {
                                $this->getSubForm('companyPricingCourse')->getSubForm($key)->getElement('flat_price')->setErrors(array("Flatprice cannot be negative."));
                                $status = false;
                            } else {
                                $coursePriceSet = true;
                            }
                        } else {
                            $this->getSubForm('companyPricingCourse')->getSubForm($key)->getElement('flat_price')->setErrors(array("Flatprice and Flatdiscount both can't be filled."));
                            $status = false;
                        }


                        if (!empty($value['access_day_id']) && $value['access_day_id'] != array_search(ENTERPRISE_ACCESS_DAYS, $accessDaysIds)) {
                            $this->getSubForm('companyPricingCourse')->getSubForm($key)->getElement('access_day_id')->setErrors(array("Access Days can only be " . ENTERPRISE_ACCESS_DAYS));
                            $status = false;
                        }
                        if ($value['location_mode'] == 0) {
                            $this->getSubForm('companyPricingCourse')->getSubForm($key)->getElement('location_mode')->setErrors(array("location_mode is required."));
                            $status = false;
                        } elseif ($value['location_mode'] > 0) {
                            if ($value['location_mode'] == 1 && $value['cluster_id'] == 0) {
                                $this->getSubForm('companyPricingCourse')->getSubForm($key)->getElement('cluster_id')->setErrors(array("Please select cluster for pricing."));
                                $status = false;
                            }
                            if ($value['location_mode'] == 2 && $value['country_id'] == 0) {
                                $this->getSubForm('companyPricingCourse')->getSubForm($key)->getElement('country_id')->setErrors(array("Please select country for pricing."));
                                $status = false;
                            }
                        }

                        if ($value['def_country_id'] == 0) {
                            $this->getSubForm('companyPricingCourse')->getSubForm($key)->getElement('def_country_id')->setErrors(array("Please select default country for pricing."));
                            $status = false;
                        } else {
                            if (count($defCountries) >= 1 && !in_array($value['def_country_id'], $defCountries)) {
                                $this->getSubForm('companyPricingCourse')->getSubForm($key)->getElement('def_country_id')->setErrors(array("Default country has to be same accross multiple pricings."));
                                return false;
                            }
                            if (count($defPricingCountries) >= 1 && !in_array($value['def_country_id'], $defPricingCountries)) {
                                $this->getSubForm('companyPricingCourse')->getSubForm($key)->getElement('def_country_id')->setErrors(array("Default country has to be same accross multiple pricings."));
                                $status = false;
                            }
                            $defPricingCountries[] = $value['def_country_id'];
                            $defCountries[] = $value['def_country_id'];
                        }

                        if (empty($learnerRArr)) {
                            $learnerRArr = array(
                                'data' => array(),
                                'maxVals' => array(),
                            );
                        }
                        if (empty($learnerRArr['data'][$value['training_id']])) {
                            $learnerRArr['data'][$value['training_id']] = array();
                        }
                        if (empty($learnerRArr['maxVals'][$value['training_id']])) {
                            $learnerRArr['maxVals'][$value['training_id']] = array();
                        }
                        $status = $this->validateLRCourse($status, $value, $key, $learnerRArr, 'companyPricingCourse');
                        if (!$status) {
                            break;
                        }
                        $learnerRArr['data'][$value['training_id']][$value['learners_range_min']] = $value['learners_range_min'] . '_' . $value['learners_range_max'] . '_' . $key;
                        $learnerRArr['maxVals'][$value['training_id']][$value['learners_range_max']] = 1;

                        // if ($value['country_id'] != US_COUNTRY_ID) {
                        //     $this->getSubForm('companyPricingCourse')->getSubForm($key)->getElement('country_id')->setErrors(array("Country other than US not allowed."));
                        //      $status = false;
                        //      break;
                        // }
                        $countries[] = $value['country_id'];
                        // if (count($learnerRArr) >= 1 && in_array($value['learners_range_id'], $learnerRArr)) {
                        //         $this->getSubForm('companyPricingCourse')->getSubForm($key)->getElement('learners_range_id')->setErrors(array("Pricing already set for this learners range."));
                        //          $status = false;
                        //          break;
                        //     } else{
                        //         $learnerRArr[] = $value['learners_range_id'];
                        //     }

                        if ($value['access_day_id'] == 0) {
                            $this->getSubForm('companyPricingCourse')->getSubForm($key)->getElement('access_day_id')->setErrors(array("Please select accessDays for pricing."));
                            $status = false;
                        }
                    }
                }
            }
            if ($status && !empty($learnerRArr['data'])) {
                $value = $learnerRArr;
                $catData = $value['data'];
                foreach ($catData as $key => $valT) {
                    if (!empty($valT) && empty($valT[1])) {
                        $data = array_shift($valT);
                        $data = explode('_', $data);
                        if (!empty($data[2])) {
                            $this->getSubForm('companyPricingCourse')->getSubForm($data[2])->getElement('learners_range_min')->setErrors(array("Learners range min has to start with 1."));
                            $status = false;
                        }
                    }
                    ksort($valT);
                    $catDataMax = array_pop($valT);
                    $catDataMax = explode('_', $catDataMax);
                    if (!empty($catDataMax[1]) && $catDataMax[1] != 0) {
                        if (!empty($catDataMax[2])) {
                            $this->getSubForm('companyPricingCourse')->getSubForm($catDataMax[2])->getElement('learners_range_max')->setErrors(array("Learners range max for last range has to be zero(0)."));
                            $status = false;
                        }
                    }
                }

                $catData = $value['data'];
                foreach ($catData as $key => $valT) {
                    $lastMax = 0;
                    ksort($valT);
                    foreach ($valT as $key => $valP) {
                        $catDataVal = explode('_', $valP);
                        if ($key != 1 && !empty($catDataVal[0]) && $catDataVal[0] != ++$lastMax && !empty($catDataVal[2])) {
                            $this->getSubForm('companyPricingCourse')->getSubForm($catDataVal[2])->getElement('learners_range_min')->setErrors(array("Learners range min has to be max + 1 for previous range."));
                            $status = false;
                            break;
                        }
                        $lastMax = $catDataVal[1];
                    }
                }
            }
            if (!empty($defCountries) && !empty($countries)) {
                if (!empty(array_diff($countries, $defCountries))) {
                    $this->getSubForm('companyPricingCourse')->getSubForm('new')->getElement('country_id')->setErrors(array("Default Country has to match country in all course pricings."));
                    $status = false;
                }
            }
            if ($catPriceSet && !$coursePriceSet) {
                $this->getSubForm('companyPricingCourse')->getSubForm('new')->getElement('flat_price')->setErrors(array("Please set course pricing."));
                $status = false;
            }
        }

        // if (!empty($data['company_domains'])) {
        //     $obj = new Model_SectionMapping();
        //     foreach ($data['company_domains'] as $record) {
        //         $records = $obj->getBySectionId($record);
        //         if (!empty($records) && !empty($records['company']) && $records['company'][0] != $data['company_id']) {
        //             $this->getElement('company_domains_err')->setErrors(array("Domain ".$this->_domains[$record]." already added to another company"));
        //             $status = false;
        //         }
        //     }
        //     $obj =new Model_Labels();
        //     $labels = $obj->fetchForSelect();
        //     $consumedCategories = array();
        //     if (!empty($recordCount)) {
        //         foreach ($recordCount as $record) {
        //             if ($record['count'] >= 4) {
        //                 $consumedCategories[] = $labels[$record['linkable_id']];
        //             }
        //         }
        //     }
        //     if (!empty($consumedCategories)) {
        //         $this->getElement('label_id_err')->setErrors(array("4 alumni already added to: ".implode(', ', $consumedCategories)."."));
        //         $status = false;
        //     }
        // }
        return $status;
    }

    public function validateLRCourse($status, $value, $key, $learnerRArr, $name) {
        if ($value['learners_range_min'] < 0 || !filter_var($value['learners_range_min'], FILTER_VALIDATE_INT)) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_min')->setErrors(array("Learners range has to be integer."));
            return false;
        }
        if ($value['learners_range_max'] > 0 && !filter_var($value['learners_range_max'], FILTER_VALIDATE_INT)) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_max')->setErrors(array("Learners range has to be integer."));
            return false;
        }
        if ($value['learners_range_max'] != 0 && $value['learners_range_min'] >= $value['learners_range_max']) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_max')->setErrors(array("Learners range max has to be greater than min."));
            return false;
        }

        if (!empty($learnerRArr['data'][$value['training_id']][$value['learners_range_min']])) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_min')->setErrors(array("Learners range min cannot be same for a category."));
            return false;
        }
        if (!empty($learnerRArr['data'][$value['training_id']][$value['learners_range_max']])) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_max')->setErrors(array("Learners range max cannot be same as min for a category."));
            return false;
        }
        if (!empty($learnerRArr['maxVals'][$value['training_id']][$value['learners_range_min']])) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_min')->setErrors(array("Learners range min cannot be same as max for a category."));
            return false;
        }
        if (!empty($learnerRArr['maxVals'][$value['training_id']][$value['learners_range_max']])) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_max')->setErrors(array("Learners range max cannot be same for a category."));
            return false;
        }
        return $status;
    }

    public function validateLRCat($status, $value, $key, $learnerRArr, $name) {
        if ($value['learners_range_min'] < 0 || !filter_var($value['learners_range_min'], FILTER_VALIDATE_INT)) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_min')->setErrors(array("Learners range has to be integer."));
            return false;
        }
        if ($value['learners_range_max'] > 0 && !filter_var($value['learners_range_max'], FILTER_VALIDATE_INT)) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_max')->setErrors(array("Learners range has to be integer."));
            return false;
        }
        if ($value['learners_range_max'] != 0 && $value['learners_range_min'] >= $value['learners_range_max']) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_max')->setErrors(array("Learners range max has to be greater than min."));
            return false;
        }

        if (!empty($learnerRArr['data'][$value['learners_range_min']])) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_min')->setErrors(array("Learners range min cannot be same for a category."));
            return false;
        }
        if (!empty($learnerRArr['data'][$value['learners_range_max']])) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_max')->setErrors(array("Learners range max cannot be same as min for a category."));
            return false;
        }
        if (!empty($learnerRArr['maxVals'][$value['learners_range_min']])) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_min')->setErrors(array("Learners range min cannot be same as max for a category."));
            return false;
        }
        if (!empty($learnerRArr['maxVals'][$value['learners_range_max']])) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_max')->setErrors(array("Learners range max cannot be same for a category."));
            return false;
        }
        return $status;
    }

    protected function getSubFormDecoratorsMain($className, $id) {
        return array(
            'FormElements',
            array(
                'HtmlTag', array('tag' => 'ul')
            ),
            array(
                array('row' => 'HtmlTag'),
                array('tag' => 'li', 'class' => $className, 'id' => $id)
            )
        );
    }

    public function removeUneditableElements() {
        $this->removeElement('url');
        return false;
    }

    public function subFormValidations($data, $subForm, $status) {
        $count = 0;
        $accessDays = $data;
        end($accessDays);
        $keyA = key($accessDays);
        if ($subForm == 'accessDays' && count($data) > 2) {
            $this->getSubForm($subForm)->getSubForm($keyA)->getElement('accessDays')->setErrors(array("Only 2 bundle prices are allowed."));
            $status = false;
        }
        return $status;
    }

    public function _decorate() {
        
    }

}
