<?php

class Form_PromoParams extends BaseApp_Form
{

    public function init(){

        $this->setName('Promo');
        $this->setMethod('post');
         //adding Label name element

        $validatorsLength = array(new Zend_Validate_StringLength(array('max' => 60)));
        $promoLength = array(new Zend_Validate_StringLength(array('max' => 6)));

        $this->addElement('text','promoValue',array(
            'label'=>'Promo Param Value',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));


        $this->addElement('text','topMessage',array(
            'label'=>'Top Call Out',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('text','secondMessage',array(
            'label'=>'Second Message',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $objLabel =new Model_Labels();
        $this->addElement('select','label_id',array(
            'label'=>'Promo Label',
            'required'=>true,
            'registerInArrayValidator' => false,
            'multioptions'=>array('0'=>'--Select--') + $objLabel->fetchForSelect()
        ));

         $this->addElement('submit','Add Promo',array(
          'ignore'=>true,
          'label'=>'Add Promo'
         ));

         $this->getElement('promoValue')->addValidators($promoLength);
         $this->getElement('topMessage')->addValidators($validatorsLength);
         $this->getElement('secondMessage')->addValidators($validatorsLength);
    }

    public function removeUneditableElements(){
        $this->getElement('promoValue')->setAttrib('disabled', 'disabled');
        $this->getElement('promoValue')->setRequired(false);
    }

    public function isValid($data) {   
        $status = parent::isValid($data);
        if(preg_match("/[^a-zA-z0-9]/", $data['promoValue'], $match)) {
            $this->getElement('promoValue')->setErrors(array("Special Character / Space are not allowed"));
            $status = false;
        }
        return $status;
    }

}