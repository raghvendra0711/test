<?php

class Form_CouponCourse extends BaseApp_Form
{
    
    public function init(){

        $this->setName('CouponCourse');
        $this->setMethod('post');
        
        $validatorsDescription = array(new Zend_Validate_StringLength(array('max' => 75)));
        
        
        $this->addElement('radio','type',array(
            'label' =>'for',
            'required'=>false,
            'multioptions'=>array('course' => 'Course','subscription' => 'Subscription'),
            'value' => 'course' 
         ));
        
        $this->addElement('radio','purpose',array(
            'label' =>'for*',
            'required'=>true,
            'multioptions'=>array('sales' => 'Sales','marketing' => 'Marketing','mobile' => 'Mobile'),
            'separator' => ' ',
            'value' => 'marketing' 
         ));

         $this->addElement('text','code',array(
            'label'=>'Coupon Code*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                new Zend_Validate_Db_NoRecordExists(array(
                    'table' => 'coupons',
                    'field' => 'code'
                )),
                new Zend_Validate_NotEmpty()
            )
        ));
         $this->addElement('file','coupoCsv',array(
            'label'=>'Or Upload A csv File',
            'required'=>false,
            //'destination'=>APPLICATION_PATH.'/'.Model_Coupons::COUPON_CSV_PATH,
            'destination'=>sys_get_temp_dir(),
            'validators' => array(array('Extension', true, 'csv')) 
        ));

         $objLabels =new Model_Labels();
         $this->addElement('select','label_id',array(
            'label'=>'Labels',
            'required'=>false,
            'multiple' => true,
            'class' => 'courseListAll', 
            'registerInArrayValidator' => false,
            'multioptions'=>$objLabels->fetchForSelect()
        ));

        $this->addElement('button','label_inward',array(
            'label'=>'Invert Labels',
            'ignore'=>true,
            'class'=>'btn btn-warning'
        ));


        $this->addElement('radio','multi_course',array(
            'label' =>'Course Group',
            'required'=>false,
            'multioptions'=>array('ALL_COURSE' => 'All','COURSE_WITH_EXAM' => 'With Exam','COURSE_WITHOUT_EXAM' => 'Without Exam', 'NONE' => 'None'),
            'separator' => ' ',
            'value' => 'NONE'
         ));

         $course = new Model_Courses();
         $this->addElement('select','course_id',array(
            'label'=>'Courses',
            'required'=>false,
            'multiple' => true,
            'registerInArrayValidator' => false,
            'class' => 'courseListAll', 
            'multioptions'=>$course->fetchForSelect(array('is_dummy = ?' => 0, 'is_free = ?' => 0, 'hideFromSearch = ?' => 0,'status = ?' => 1))
        ));

        $this->addElement('button','course_inward',array(
            'label'=>'Invert Courses',
            'ignore'=>true,
            'class'=>'btn btn-warning'
        ));
         
        $bundle = new Model_Bundles();
        $this->addElement('radio','multi_bundle',array(
            'label' =>'Bundle Group',
            'required'=>false,
            'multioptions'=>array('ALL_BUNDLE' => 'All','BUNDLE_WITH_EXAM' => 'With Exam','BUNDLE_WITHOUT_EXAM' => 'Without Exam', 'NONE' => 'None'),
            'separator' => ' ',
            'value' => 'NONE'
         ));
        
         $this->addElement('select','bundle_id',array(
            'label'=>'Bundles',
            'required'=>false,
            'multiple' => true,
            'registerInArrayValidator' => false,
            'class' => 'courseListAll', 
            'multioptions'=>$bundle->fetchForSelect(array('status = ?' => 1))
        ));

        $this->addElement('button','bundle_inward',array(
            'label'=>'Invert Bundles',
            'ignore'=>true,
            'class'=>'btn btn-warning'
        ));
        
        $bundle = new Model_Bundles();
        $this->addElement('select','mom_id',array(
            'label'=>'Master of Masters',
            'required'=>false,
            'multiple' => true,
            'registerInArrayValidator' => false, 
            'multioptions'=>$bundle->fetchForSelect(array('status = ?' => 1, 'linkable_type = ?' => "master_of_masters"))
        ));

        $pass = new Model_Pass();
        $this->addElement('select','pass_id',array(
            'label'=>'Lvc Pass',
            'required'=>false,
            'multiple' => true,
            'registerInArrayValidator' => false,
            'class' => 'courseListAll', 
            'multioptions'=>$pass->fetchForSelect(array('status = ?' => 1))
        ));
         
        $objtrainingTypes= new Model_TrainingTypes();
        foreach($objtrainingTypes->fetchAll() as $trainingData) {
            $this->addElement('multiCheckbox','training_id',array(
                'label' =>'Training Type*',
                'required'=>true,
                'multioptions'=>$objtrainingTypes->fetchForSelect(),
                'separator' => ' '
             ));
        }

        $this->addElement('hidden','training_id_tmp',array(
            'required'=>false,
             'value'=>''
    ));

        $this->addElement('checkbox','all_countries',array(
            'label' =>'All Countries',
            'required'=>false,
         ));

        $objCluster =new Model_Clusters();
        $this->addElement('select','cluster_id',array(
            'label'=>'Clusters',
            'required'=>false,
            'multiple' => true,
            'class' => 'multiple',
            'registerInArrayValidator' => false,
            'multioptions'=>$objCluster->fetchForSelect()
        ));
        
        $this->addElement('hidden','cluster_id_tmp',array(
        		'required'=>false,
         		'value'=>''
        ));

        $this->addElement('button','cluster_inward',array(
            'label'=>'Invert Clusters',
            'ignore'=>true,
            'class'=>'btn btn-warning'
        ));

        $this->addElement('radio','multi_country',array(
            'label' =>'Country Group',
            'required'=>false,
            'multioptions'=>array('EURO' => 'Euro (countries that have Euro as a currency)','ROW' => 'ROW (All countries excluding US, Canada, Mexico & India)','NONE' => 'None'),
            'separator' => ' ',
            'value' => 'NONE'
         ));

        $objCountry =new Model_Country();
        $this->addElement('select','country_id',array(
            'label'=>'Countries Associated for Course',
            'required'=>false,
            'multiple' => true,
            'class' => 'courseListAll', 
            'registerInArrayValidator' => false,
            'multioptions'=>$objCountry->getListDisplay()  
        ));
        
        $this->addElement('hidden','country_hid',array(
        		'required'=>false,
        		'value'=>''
        ));

        $this->addElement('button','country_inward',array(
            'label'=>'Invert Countries',
            'ignore'=>true,
            'class'=>'btn btn-warning'
        ));

        $this->addElement('text','specialText',array(
            'label'=>'Special Text',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off'
        ));
        
        $this->addElement('text','topBannerPath',array(
            'label'=>'Top Banner (780x192)',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off',
            'validators' => array(
                new BaseApp_Validate_Image('couponCourse', 'topBannerPath')
            )
        ));
        
        $this->addElement('text','smallBannerPath',array(
            'label'=>'Offer Page Banner',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off',
            'validators' => array(
                new BaseApp_Validate_Image('couponCourse', 'smallBannerPath', true)
            )
        ));
        
        $this->addElement('text','discountValue',array(
            'label'=>'Percentage',
            'filters'=>array('StringTrim'),
            'validators'=>array('Int'),
            'class'=>'number',
        ));
        
        $this->addElement('text','discountAmount',array(
        		'label'=>'Discount Amount',
        		'filters'=>array('StringTrim'),
        		'validators'=>array('Int'),
        		'class'=>'number',
        ));

        $this->addElement('text','totalCount',array(
            'label'=>'Usage Count*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'validators'=>array('Int'),
            'class'=>'required number',
        ));

        $this->addElement('text','validFrom',array(
            'label'=>'Start Date*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'datepicker'
        ));

        $this->addElement('text','validto',array(
            'label'=>'End Date*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'datepicker'
        ));
        
        $this->addElement('textarea','shortDescription',array(
            'label'=>'Description*',
            'required'=>true,
            'filter'=>array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class'=>'description'
        ));
        
        $this->addElement('textarea','terms',array(
            'label'=>'Terms and conditions*',
            'required'=>true,
            'cols' => 60,
            'rows' => 6,
            'class'=>'longtext',
            'value'=>''
        ));

        $this->addElement('checkbox','displayFrontend',array(
            'label' => 'To be displayed on website'
        ));

         $this->addElement('submit','Add Coupon',array(
          'ignore'=>true,
          'label'=>'Add Coupon',
          'class'=>'btn btn-info'
         ));
         
         $this->getElement('shortDescription')->addValidators($validatorsDescription);
    }

    public function isValid($data) {
        $return = parent::isValid($data);
        if($return){
        	if( ( isset($data['discountValue']) && ($data['discountValue'] == '' || $data['discountValue'] == 0)
        			&& isset($data['discountAmount']) && ($data['discountAmount'] == '' || $data['discountAmount'] == 0)) ){
        				$this->getElement('discountValue')->setErrors(array("Error..!!! Either discount percentage or amount have to be set."));
        				$return = false;
        	}
        	if( isset($data['discountValue']) && $data['discountValue'] < 0){
        				$this->getElement('discountValue')->setErrors(array("Error..!!! discount percentage cannot be less than zero."));
        				$return = false;
        	}
        	
        	if(isset($data['discountAmount']) && $data['discountAmount'] < 0 ){
        				$this->getElement('discountAmount')->setErrors(array("Error..!!! discount amount cannot be less than zero."));
        				$return = false;
        	}
        	
        	if( ( isset($data['discountValue']) && $data['discountValue'] > 0
        			&& isset($data['discountAmount']) && $data['discountAmount'] > 0) ){
        		$this->getElement('discountValue')->setErrors(array("Error..!!! Both discount percentage and amount cannot be set."));
        		$return = false;
            }
            if(isset($data['discountAmount']) && $data['discountAmount'] > 0){
        	$currencies = array();
            $countriesCurrInClusters = array();
            if(!empty($data['all_countries']) || $data['multi_country'] == 'ROW'){
                $this->getElement('country_hid')->setErrors(
                    array("Error..!!! Discount country cannot be set for more than one currency."));
                    $return = false;
            }
        	if(!empty($data['cluster_id'])){
        		$clustersObj = new Model_Clusters();
        		$currencies = array_unique($clustersObj->getCurrencies($data['cluster_id']));
        		if(count($currencies) > 1){
        			$this->getElement('cluster_id_tmp')->setErrors(
        					array("Error..!!! Discount clusters cannot be set for more than one currency."));
        			$return = false;
        		}
        		$countriesObj = new Model_Country();
        		$countriesCurrInClusters = array_map(function($arrayEl){return substr($arrayEl, 0, 3);} , $countriesObj->getCurrenciesByClusterIds($data['cluster_id']));
        		$countriesCurrInClusters = array_unique($countriesCurrInClusters);
        		if(count($countriesCurrInClusters) > 1){
        			$this->getElement('cluster_id_tmp')->setErrors(
        					array("Error..!!! Discount clusters cannot be set for more than one currency. Selected cluster contains countries with more than one currency"));
        			$return = false;
        		}
        	}
        	$currenciesCountry = array();
        	if(!empty($data['country_id'])){
        		$countriesObj = new Model_Country();
        		$currenciesCountry = array_map(function($arrayEl){return substr($arrayEl, 0, 3);} , $countriesObj->getCurrencies($data['country_id']));
        		$currenciesCountry = array_unique($currenciesCountry);
        		if(count($currenciesCountry) > 1 ){
        			 $this->getElement('country_hid')->setErrors(
        					array("Error..!!! Discount country cannot be set for more than one currency."));
        			$return = false;
        		}
        	}
//         	prd($currenciesCountry, $countriesCurrInClusters);
        	if(!empty($currenciesCountry) && !empty($countriesCurrInClusters) && count($countriesCurrInClusters) == 1){
//         		prd(array_shift(array_values($countriesCurrInClusters)), array_shift(array_values($currenciesCountry)));
        		if(array_shift(array_values($countriesCurrInClusters)) != array_shift(array_values($currenciesCountry))){
        			$this->getElement('country_hid')->setErrors(
        					array("Error..!!! Discount countries cannot be set for more than one currency. Selected countries along with countries from cluster have different currencies."));
        			$return = false;
        		}
            }
        }
        	if( ( isset($data['validFrom']) )){
        		if(strtotime($data['validFrom']) < strtotime(date('Y-m-d', time()). '00:00:00')){
        			$this->getElement('validFrom')->setErrors(array("Error..!!! Start Date cannot be less than today."));
        			$return = false;
        		}
        	}
        	
        	if( ( isset($data['validto']) )){
        		if(strtotime($data['validto']) < strtotime(date('Y-m-d', time()). '00:00:00')){
        			$this->getElement('validto')->setErrors(array("Error..!!! End Date cannot be less than today."));
        			$return = false;
        		}
        	}
        	
            if( ( !isset($data['code']) ) && ( !empty($_FILES['coupoCsv']['name']) ) ){    
                $this->getElement('code')->setErrors(array("Error..!!! Both Code and file Cannot be Processesd"));
                $return = false;
            }
            if(!isset($data['mom_id']) && !isset($data['label_id']) && !isset($data['course_id']) &&  $data['multi_course'] == "NONE" && !isset($data['bundle_id']) && $data['multi_bundle'] == "NONE" && !isset($data['pass_id'])) {
                $this->getElement('label_id')->setErrors(array("label or course or bundle or pass or mom required"));
                $this->getElement('course_id')->setErrors(array("label or course or bundle or pass or mom required"));
                $this->getElement('bundle_id')->setErrors(array("label or course or bundle or pass or mom required"));
                $this->getElement('pass_id')->setErrors(array("label or course or bundle or pass or mom required"));
                $this->getElement('mom_id')->setErrors(array("label or course or bundle or pass or mom required"));
                $return = false;
            }
            if((isset($data['bundle_id']) || $data['multi_bundle'] != 'NONE') && !in_array(BaseApp_Dao_TrainingTypes::TYPE_ELEARNING, $data['training_id'])) {
                $this->getElement('training_id_tmp')->setErrors(array("OSL training type is required for bundles"));
                $return = false;
            }

            

            if(isset($data['pass_id']) && !in_array(BaseApp_Dao_TrainingTypes::TYPE_LVC, $data['training_id'])) {
                $this->getElement('training_id_tmp')->setErrors(array("LVC training type is required for Pass"));
                $return = false;
            }
        }        
        return $return;
    } 
    
    public function removeUneditableElements(){
        $this->removeElement('type');
        $this->removeElement('purpose');
        $this->removeElement('coupoCsv');
        
        $this->addElement('hidden','purpose',array());
        
        $this->getElement('code')->setAttrib('disabled', 'disabled');
        $this->getElement('code')->setRequired(false);
    }
}