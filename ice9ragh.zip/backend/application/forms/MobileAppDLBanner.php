<?php

class Form_MobileAppDLBanner extends BaseApp_Form
{
               
    public function __construct($data) {
         $this->init($data);
    }

    public function init($data)
    {

        $this->setName('Mobile App');
        $this->setMethod('post');
        $this->loadDefaultDecorators();
        
        $widgetInfo = !empty($data['info']) ? $data['info'] : array();
        $data = !empty($data['data']) ? $data['data'] : array();
        
        //test


        

        $this->addElement('submit','Add Mobile App',array(
          'ignore'=>true,
          'label'=>'Add to Sequence List',
          'class'=>'btn btn-info',
          'id'=>'addToSequenceList'
        ));    

        //test


    }

    public function removeUneditableElements(){
        $this->getElement('name')->setAttrib('disabled', 'disabled');
        $this->getElement('name')->setRequired(false);
    }

    public function isValid($data) {
        $status = parent::isValid($data);
        if (!$status){
            return false;
        }
        return $status;
    }
}
