<?php

class Form_ModifyPricings extends BaseApp_Form
{
    private $_courseId = null;
    
    public function __construct($courseId = false) {
        $this->_courseId = $courseId;
        parent::__construct();
    }

    public function init(){

        $this->addElement('text','pricing_id',array(
            'label'=>'Pricing Id',
            'required'=>false,
            'readonly'=>'readonly',
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));        

        $this->addElement('text','price',array(
            'label'=>'Current Price',
            'ignore'=>true,
            'required'=>false,
            'readonly'=>'readonly',
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $inclusionData = array();
        if($this->_courseId) {
            $objInclusion = new Model_CourseInclusions();
            $inclusionData = $objInclusion->getCourseInclusionForSelect($this->_courseId, false, true);
        }
        $this->addElement('select','course_inclusion_id',array(
            'label' => 'Paid Inclusions',
            'required'=>true,
            'multiple' => true,
            'class' => 'multiple',
            'registerInArrayValidator' => false,
            'multioptions'=>$inclusionData
        ));

        $this->addElement('text','discount',array(
            'label'=>'Current Max Discount',
            'ignore'=>true,
            'required'=>false,
            'readonly'=>'readonly',
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('text','newPrice',array(
            'label'=>'New Price',
            'ignore'=>true,
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('text','newDiscount',array(
            'label'=>'New Max Discount',
            'ignore'=>true,
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('submit','SavePricing',array(
            'ignore'=>true,
            'label'=>'Save Price',
            'class'=>'btn btn-info'
        ));
        
    }

}