<?php

class Form_CourseTools extends BaseApp_SubForm {

    const TOOL_NAME_MAX_CHARACTER=50;
    public function init() {

        $this->setName('Tools');
        $this->setMethod('post');


        $this->addElement('text', 'name', array(
            'label' => 'Tool Name*',
            'required' => true,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'placeholder' => 'Tool Name',
            'maxlength'=>self::TOOL_NAME_MAX_CHARACTER
        ));
        $this->addElement('hidden', 'tool_name_err', array(
            'required' => false,
            'value' => ''
        ));
        $this->addElement('text', 'imageUrl', array(
            'label' => 'Logo Url*',
            'required' => true,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'placeholder' => 'Tool Image Url',
        ));
        $this->addElement('hidden', 'tool_image_url_err', array(
            'required' => false,
            'value' => ''
        ));
        $this->addElement('submit', 'Add Tool', array(
            'ignore' => true,
            'label' => 'Add Tool',
            'class' => 'btn btn-info'
        ));
        $validatorsName = array(new Zend_Validate_StringLength(array('max' => self::TOOL_NAME_MAX_CHARACTER)));
        $this->getElement('name')->addValidators($validatorsName,false, array(0, self::TOOL_NAME_MAX_CHARACTER));
    }

    public function isValid($data) {
        $status = parent::isValid($data);
        $oldToolName=!empty($data['originalToolName']) ? $data['originalToolName']:'';
        if (!empty($data['name']) && strcasecmp($data['name'], $oldToolName) !== 0):
            $ifNameExist = $this->_checkIfToolNameExist($data['name']);
            if ($ifNameExist):
                $this->getElement('tool_name_err')->setErrors(array('tool name already exist.please use a different name'));
                $status = false;
            endif;
        endif;
        if (!empty($data['name']) && strlen($data['name']) > self::TOOL_NAME_MAX_CHARACTER):
            $msg='Max character allowed in tool name is only '.self::TOOL_NAME_MAX_CHARACTER;
            $this->getElement('tool_name_err')->setErrors(array($msg));
            $status = false;
        endif;
        if (!empty($data['imageUrl'])):
            $url = $data['imageUrl'];
            if (!preg_match("/^https:\/\/www.simplilearn.com/", $url, $match)) {
                $this->getElement('tool_image_url_err')->setErrors(array('Image url should have https and should have simplilearn domain'));
                $status = false;
            }
        endif;
        return $status;
    }

    /**
     * Check If Tool Name Exist
     * @param string $sectionName
     * @return boolean
     */
    private function _checkIfToolNameExist($sectionName) {
        $isToolNameExist = false;
        if (!empty($sectionName)):
            $obj = new Model_ProductSectionData();
            $sectionType = 'tools';
            $result = $obj->getBySectionType($sectionType, strtolower($sectionName));
            if (!empty($result)):
                $isToolNameExist = true;
            endif;
        endif;
        return $isToolNameExist;
    }

}
