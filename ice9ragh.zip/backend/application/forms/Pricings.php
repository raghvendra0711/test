<?php

class Form_Pricings extends BaseApp_SubForm
{
    private $_courseId;
    protected $submitName = '';

    public function init(){
        
        
    }


    public function setCourseType($courseId){
        $this->setName('addPricing');
        $this->setMethod('post');
        $this->_courseId = $courseId;
        $objTt = new Model_TrainingTypes();
        $trainingTypes = $objTt->loadById(array(1,2,9));
        $trainingData = array();

        $this->addElement('hidden', 'course_id', array(
            'label' => FALSE,
            'value' => $this->_courseId
        ));
        foreach ($trainingTypes as $key => $value) {
            $trainingData[$value['type'].'_'.$value['training_id']] = $value['training_id'] == 1 ? "Physical ".$value['name']: $value['name'];
        }
        
        ksort($trainingData);
        $this->addElement('select','training_id',array(
            'label'=>'Training Type',
            'required'=>true,
            'multioptions'=>array('0'=>'--Select--') + $trainingData
        ));

        $currencyModel = new Model_Currency();
        $this->addElement('select','Currency',array(
            'label'=>'Select Currency',
            'required'=>true,
            'multioptions'=> $currencyModel->getCurrencyToDisplay()
        ));
        
        $this->addElement('select','locationMode',array(
            'label'=>'Select Pricing Level',
            'required'=>true,
            'multioptions'=>array(0=>'--Select--',1=>'By Cluster',2=>'By Country',3=>'By City')
        ));

                
        $this->addElement('select','cluster_id',array(
            'label'=>'Cluster',
            'required'=>false,
            'registerInArrayValidator' => false,
            'fetchDisabled' => 'true' 
        ));

        $this->addElement('select','country_id',array(
            'required'=>false,
            'label' => 'Country',
            'registerInArrayValidator' => false,
            'fetchDisabled' => 'true' 
        ));

        $this->addElement('select','countryCityMode',array(
            'label' => 'Country',
            'required'=>false,
            'registerInArrayValidator' => false,
            'fetchDisabled' => 'true' 
        ));

        $this->addElement('select','cityId',array(
            'label' => 'City',
            'required'=>false,
            'multiple' => true,
            'class' => 'multiple',
            'registerInArrayValidator' => false,
            'fetchDisabled' => 'true' 
        ));

        $session = new Zend_Session_Namespace('form');
        
        $traingType = new Model_TrainingTypes();
        $trainingTypeIds = $traingType->loadAll();
        
        $accessDays = new Model_AccessDays();
        $accessDaysData = $accessDays->getAccessDaysById(false, true);
        
        $trainingRelation = new Model_TrainingRelations();                
        foreach($trainingRelation->getCourseTrainingData($courseId, 'course') as $trainingId => $trainingData) {
            if($trainingId == BaseApp_Dao_TrainingTypes::TYPE_LVC) {
                continue;
            }
            $counter = 0;
            $trainingData['accessDays'] = explode(",", $trainingData['accessDays']);
            $subForm = new Zend_Form_SubForm();
            $subForm->setName('daysPricing'.$trainingId);             
            foreach($trainingData['accessDays'] as $accessDayNumber) {
                $rowForm = new Zend_Form_SubForm();
                $rowForm->setName('pricing_'.$accessDayNumber.'_'.$trainingId);  
                $heading = '';
                if(!$counter) {
                    $heading = $trainingTypeIds[$trainingId]['name'];
                }
                $rowForm->setLegend($heading.' Days '.$accessDaysData[$accessDayNumber]);
                
                $priceElement = new Zend_Form_Element_Text('price_'.$accessDayNumber.'_'.$trainingId);
                $priceElement->addFilter('stringTrim')->setAttrib('class', 'accessPrice')->setLabel('Price');
                
                $discountElement = new Zend_Form_Element_Text('discount_'.$accessDayNumber.'_'.$trainingId);
                $discountElement->addFilter('stringTrim')->setAttrib('class', 'accessPrice')->setLabel('Discount (%)');
                $elements = array($priceElement, $discountElement);
                
                $rowForm->addElements($elements);
                $rowForm->setElementDecorators($this->getElementDecorators());

                $rowForm->setDecorators($this->getSubFormDecorators());
                $subForm->addSubForm($rowForm, 'pricing_'.$accessDayNumber.'_'.$trainingId);
                $counter++;
            }
            
            $subForm->setDecorators($this->getSubFormDecoratorsMain('daysPricing', 'daysPricing'.$trainingId));
            $subForm->setElementDecorators($this->getElementDecorators());
            $this->addSubForm($subForm, 'daysPricing'.$trainingId);            
        }
        $this->postSetup(); 
        
        
        
        $inclusionData = array();
        $objInclusion = new Model_CourseInclusions();
        $inclusionData = $objInclusion->getCourseInclusionForSelect($this->_courseId, false, true);
        $this->addElement('select','course_inclusion_id',array(
            'required'=>true,
            'label'=>'Paid Inclusions',
            'multiple' => true,
            'class' => 'multiple',
            'registerInArrayValidator' => false,
            'multioptions'=>$inclusionData
        ));


        $this->addElement('submit','AddMorePricing',array(
            'ignore'=>true,
            'label'=>'Add More Pricing',
            'class'=>'btn btn-info'
        ));
    }

    protected function setupButtons()
    {
        return true;
    }
    protected function createButtons()
    {
        return true;
    }
    public function isValid($data) {
        $return = parent::isValid($data);
        if($return){
            if($data['locationMode'] != 0){
                if( ( !isset($data['cluster_id']) ) && ( !isset($data['country_id']) ) && ( !isset($data['city_id']) ) ){    
                    $this->getElement('cluster_id')->setErrors(array("Please Select Any Cluster / Country / City from the List"));
                        return false;
                }
            }
            $allLocation = '';
            $clusterId = '';
            $countryId = '';
            $cityId = '';
            $trainingId = $data['training_id'];
            $accessDayId = $data['access_day_id'];
            if($data['locationMode'] == 0){
                $allLocation =$data['locationMode'];
            }
            if(isset($data['cluster_id']))
                $countryId = $data['country_id'];
            if(isset($data['cluster_id']))
                $countryid = $data['country_id'];
            if(isset($data['city_id']))
                $cityId = $data['city_id'];
            $objPricing =  new Model_Pricings();
            if( false === $objPricing->pricingUnique($this->_courseId,$trainingId,$accessDayId,$allLocation,$clusterId,$countryId,$cityId)){
                $this->getElement('price')->setErrors(array("There exists A row against these Input Values"));
                return false;
            }
        }
        return $return;
    } 
 
    protected function getSubFormDecoratorsMain($className, $id) {
        return array(   
            'FormElements',                        
            array(                
                'HtmlTag', array('tag' => 'ul')
            ),
            array(
                array('row' => 'HtmlTag'),                
                array('tag' => 'li', 'class' => $className, 'id' => $id)
            )
        );
    }
}