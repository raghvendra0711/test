<?php

class Form_CouponSubscription extends BaseApp_Form
{

    public function init(){

        $this->setName('CouponSubscription');
        $this->setMethod('post');
        
        $validatorsDescription = array(new Zend_Validate_StringLength(array('max' => 75)));
        
        
        $this->addElement('radio','type',array(
            'label' =>'for',
            'required'=>false,
            'multioptions'=>array('course' => 'Course','subscription' => 'Subscription'),
            'value' => 'subscription' 
         ));
        
        $this->addElement('radio','purpose',array(
            'label' =>'for',
            'required'=>true,
            'multioptions'=>array('sales' => 'Sales','marketing' => 'Marketing','mobile' => 'Mobile'),
            'separator' => ' ',
            'value' => 'marketing' 
         ));

         $this->addElement('text','code',array(
            'label'=>'Coupon Code',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                new Zend_Validate_Db_NoRecordExists(array(
                    'table' => 'coupons',
                    'field' => 'code'
                )),
                new Zend_Validate_NotEmpty()
            )
        ));

         $this->addElement('file','coupoCsv',array(
            'label'=>'Or Upload A csv File',
            'required'=>false,
            //'destination'=>APPLICATION_PATH.'/'.Model_Coupons::COUPON_CSV_PATH,
            'destination'=>sys_get_temp_dir(),
            'validators' => array(array('Extension', true, 'csv')) 
        ));

         $objLabels =new Model_Labels();
         $this->addElement('select','label_id',array(
            'label'=>'Labels',
            'required'=>false,
            'multiple' => true,
            'registerInArrayValidator' => false,
            'multioptions'=>$objLabels->fetchForSelect()
        ));

         $this->addElement('button','label_inward',array(
            'label'=>'Inward Labels',
            'ignore'=>true,
            'class'=>'btn btn-warning'
        ));
        
        $objCluster =new Model_Clusters();
        $this->addElement('select','cluster_id',array(
            'label'=>'Clusters',
            'required'=>false,
            'multiple' => true,
            'class' => 'multiple',
            'registerInArrayValidator' => false,
            'multioptions'=>$objCluster->fetchForSelect()
        ));

        $this->addElement('button','cluster_inward',array(
            'label'=>'Inward Clusters',
            'ignore'=>true,
            'class'=>'btn btn-warning'
        ));

        $objCountry =new Model_Country();
        $this->addElement('select','country_id',array(
            'label'=>'Countries Associated for Course',
            'required'=>false,
            'multiple' => true,
            'class' => 'multiple',
            'registerInArrayValidator' => false,
            'multioptions'=>$objCountry->getListDisplay()
        ));

        $this->addElement('button','country_inward',array(
            'label'=>'Inward Countries',
            'ignore'=>true,
            'class'=>'btn btn-warning'
        ));

        
        $this->addElement('text','specialText',array(
            'label'=>'Special Text',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off'
        ));
        
        $this->addElement('text','topBannerPath',array(
            'label'=>'Top Banner',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off',
            'validators' => array(
                new BaseApp_Validate_Image('couponSubscription', 'topBannerPath')
            )
        ));
        
        $this->addElement('text','smallBannerPath',array(
            'label'=>'Offer Page Banner',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off',
            'validators' => array(
                new BaseApp_Validate_Image('couponSubscription', 'smallBannerPath', true)
            )
        ));
        
        
        $this->addElement('text','discountValue',array(
            'label'=>'Percentage*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'validators'=>array('Int'),
            'class'=>'required number',
        ));

        $this->addElement('text','totalCount',array(
            'label'=>'Usage Count',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'validators'=>array('Int'),
            'class'=>'required number',
        ));

        $this->addElement('text','validFrom',array(
            'label'=>'Start Date',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'datepicker'
        ));

        $this->addElement('text','validto',array(
            'label'=>'End Date',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'datepicker'
        ));
        
        $this->addElement('textarea','shortDescription',array(
            'label'=>'Description*',
            'required'=>true,
            'filter'=>array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class'=>'description'
        ));
        
        $this->addElement('textarea','terms',array(
            'label'=>'Terms and conditions',
            'required'=>true,
            'cols' => 60,
            'rows' => 6,
            'class'=>'longtext',
            'value'=>''
        ));

        $this->addElement('checkbox','displayFrontend',array(
            'label' => 'To be displayed on website'
        ));

         $this->addElement('submit','Add Coupon',array(
          'ignore'=>true,
          'label'=>'Add Coupon',
            'class'=>'btn btn-info'
         ));
         
         $this->getElement('shortDescription')->addValidators($validatorsDescription);
    }

    public function isValid($data) {
        $return = parent::isValid($data);
        if($return){
            if( ( !isset($data['code']) ) && ( !empty($_FILES['coupoCsv']['name']) ) ){    
                $this->getElement('code')->setErrors(array("Error..!!! Both Code and file Cannot be Processesd"));
                return false;
            }
        }
        return $return;
    } 
    
    public function removeUneditableElements(){
        $this->removeElement('type');
        $this->removeElement('purpose');
        $this->removeElement('coupoCsv');
        
        $this->getElement('code')->setAttrib('disabled', 'disabled');
        $this->getElement('code')->setRequired(false);
    }
}