<?php

class Form_Trainers extends BaseApp_Form
{
    public function init(){
        $this->setName('trainers');
        $this->setMethod('post');
        
        $validatorsEmail = array(new BaseApp_Validate_EmailAddress());
        
        $this->addElement('text','name',array(
            'label'=>'Trainer Name ',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

         $this->addElement('text','specialization',array(
            'label'=>'Specialization ',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

         $this->addElement('text','email',array(
            'label'=>'Trainer Email ',
            'required'=>true,
            'validators'=>array("EmailAddress"),
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                new BaseApp_Validate_EmailAddress()
            )
        ));

         $this->addElement('text','phone',array(
            'label'=>'Trainer Phone ',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        
        $this->addElement('text','region',array(
            'label'=>'Region ',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

         $this->addElement('text','currency',array(
            'label'=>'Currency ',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

         $this->addElement('text','costType',array(
            'label'=>'Cost Type ',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));
          
        $this->addElement('submit','Add a New Trainer',array(
          'ignore'=>true,
          'label'=>'Add a New Trainer',
          'class'=>'btn btn-info'
         ));
        
        $this->getElement('email')->addValidators($validatorsEmail);
    }
}

