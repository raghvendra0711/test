<?php

class Form_InclusionTemplates extends BaseApp_Form
{
    public static $learningElements = array(
//        'Model_CostTableText',
        'Model_Cost',
        'Model_PracticeTest',
        'Model_Testimonials',
        'Model_Webinars'
    );
    
    private $_courseId = false;
    
    private $_trainingId = false;

    public function __construct($courseId, $trainingId=false) {
        $this->_courseId = $courseId;
        $this->_trainingId = $trainingId;
        parent::__construct();
    }
    
    public function init(){
        $this->setName('InclusionTemplates');
        $this->setMethod('post');
        $objInclusion = new Model_CourseInclusions();
        
        $inclusionData = $objInclusion->getCourseInclusionForSelect($this->_courseId, $this->_trainingId);
        if(!$inclusionData) {
            $inclusionData = array(
                'inclusion' => array(),
                'learning' => array()
            );
        }
                              
        //adding Label name element
        $objInclusionTemp = new Model_InclusionTemplates();
        $this->addElement('select','imp_inclusions',array(
            'label'=>'Important Inclusions',
            'required'=>false,
            'multiple' => true,
            'class' => 'multiple',
            'registerInArrayValidator' => false,
            'multioptions'=>$objInclusionTemp->fetchForSelect(),
            'value' => array_slice($inclusionData['inclusion'], 0, 2)
        ));

        $this->addElement('select','other_inclusions',array(
            'label'=>'Other Inclusions',
            'required'=>false,
            'multiple' => true,
            'class' => 'multiple',
            'registerInArrayValidator' => false,
            'multioptions'=>$objInclusionTemp->fetchForSelect(),
            'value' => array_slice($inclusionData['inclusion'], 2)
        ));
        
        $learningElements = array();
        foreach(self::$learningElements as $model) {
            $obj = new $model();
            foreach($obj->getForInclusion($this->_courseId, 0) as $type => $data) {
                $learningElements[$type] = $data;
            }            
        }
        
        $this->addElement('select','learningElements',array(
            'label'=>'Active Leaning Elements',
            'required'=>false,
            'multiple' => true,
            'class' => 'multiple',
            'registerInArrayValidator' => false,
            'multioptions'=>$learningElements,
            'value' => @$inclusionData['learning']
                
        ));
        
        $this->addElement('submit','Save',array(
            'ignore'=>true,
            'label'=>'Save'
         ));
    }
}

