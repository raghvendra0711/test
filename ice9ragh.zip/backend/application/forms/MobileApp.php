<?php

class Form_MobileApp extends BaseApp_Form
{
    const TYPE_COURSE='course';
    const TYPE_ARTICLE='article';
    const TYPE_EBOOK='ebook';
    const TYPE_WEBINAR='webinar';
    
    protected $productTypes = array();
    
    public function __construct($data) {
         $this->init($data);
    }
    
    public function init($data){       
        $this->setName('Mobile App');
        $this->setMethod('post');
        $this->loadDefaultDecorators();
        
        $this->productTypes=   array(
            self::TYPE_COURSE=>'Course'
           ,self::TYPE_ARTICLE=>'Article'
           ,self::TYPE_EBOOK=>'Ebook'
           ,self::TYPE_WEBINAR=>'Webinar'
        );
        $this->addElement('button','Add New Widget',array(
            'ignore'=>true,
            'label'=>'+ Add New Widget',            
            'class'=>'btn btn-info'
          ));
        $this->addElement('select', 'dd_widget', array(
            'style' => 'display:none',
            'required' => false,
            'registerInArrayValidator' => false,
            'multioptions' => array(
                '0'     => '--Select widget type--',
                'horizontal_cards' => 'Horizontal Listing',
                'vertical_list' => 'Vertical Listing',
                'banner' => 'Banner',
                'grid' => 'Grid',
                'free_resources' => 'FRS'
            ),
        ));
        
        //Hidden element to store created widget and change sort order        
        if(!empty($data['content'])){   
        $this->addElement('select', 'widget_items_temp', array(
            'required' => false,            
            'multiple' => true,
            'class' => 'multiple widget_items',
            'style'   => 'display:none;',
            'registerInArrayValidator' => false,            
            'multioptions' => !empty($data['content'])? $data['content']:array(),
        ));  
        $this->getElement('widget_items_temp')->removeDecorator('Label');
        $widgetGroup = array('widget_items_temp');
        $widgets = !empty($data['content_ids_sorted_list'])?$data['content_ids_sorted_list']:'';
        $this->addElement('hidden', 'widgets_ids', array('required' => false, 'value' => $widgets));
        $this->addDisplayGroup($widgetGroup, 'widget_group');
        $this->getDisplayGroup('widget_group')
                ->setLegend('Widget Lists')
                ->clearDecorators()
                ->addDecorator('FormElements')
                ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper'));    
        
            $this->addElement('submit','Add Mobile App',array(
                'ignore'=>true,
                'label'=>'Reorder & Save',
                'class'=>'btn btn-info'
            ));
        }
          
        $element = $this->getElement('dd_widget');
        $element->removeDecorator('label');
    }
}
