<?php

class Form_Role extends BaseApp_Form {

    public function init() {
        $this->addElement('text', 'name', array(
            'label' => 'Name'
        ));
        $this->addElement('submit', 'submit', array(
            'label' => 'Save'
        ));
    }

    public function userAction() {
        $this->view->form = new Form_Role_User;
    }

}
