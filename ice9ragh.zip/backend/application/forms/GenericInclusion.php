<?php

class Form_GenericInclusion extends BaseApp_SubForm
{
    private $_sessionName = '';
    
    public function __construct($sessionName) {
        $this->_sessionName = $sessionName;
        parent::__construct();
    }
    
    public function init(){
        $this->setName('GenericInclusion');
        $this->setMethod('post');
         //adding Label name element

        $session = new Zend_Session_Namespace('form');
        
         $subForm = new Zend_Form_SubForm();
         $sessionName = $this->_sessionName;
         $sessionNameData = $sessionName."Data";
         $subForm->setName($sessionName);   
         foreach ($session->$sessionName as $product) {             
            $dataSessionFinal = $session->$sessionNameData;             
            $keyQuestion = isset($dataSessionFinal[$product]['question'])?$dataSessionFinal[$product]['question']:'';
            $keyAnswer = isset($dataSessionFinal[$product]['answer'])?$dataSessionFinal[$product]['answer']:'';
            
            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);  
            
            if ($product === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
            }
            
            
            $question = new Zend_Form_Element_Text('question');
            $question->addFilter('stringTrim')->setValue($keyQuestion)->setAttrib('class', 'question')->setLabel('Question');
            
            $answer = new Zend_Form_Element_Textarea('answer');
            $answer->addFilter('stringTrim')->setValue($keyAnswer)->setAttrib('class', '')->setAttrib('rows', 5)->setAttrib('cols', 60)->setLabel('Answer');
            
            $removeFaq = new Zend_Form_Element_Button('remove');
            $removeFaq->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');        
         
            $elements = array($question, $answer);            
            if($product !== 'new') {
                $elements[] = $removeFaq;            
            }
            
            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());

            if($rowForm->getElement('remove')) {
                $rowForm->getElement('remove')->removeDecorator('Label');
            }            

            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        }
        
        $subForm->setDecorators($this->getSubFormDecoratorsMain('genericInclusionFaq', $sessionName));

        $addFaq = new Zend_Form_Element_Button('add');
        $addFaq->setLabel('Add More')->setAttrib('class', 'btn btn-warning add');
        $subForm->addElement($addFaq);

        $subForm->setElementDecorators($this->getElementDecorators());
        $subForm->getElement('add')->removeDecorator('Label');
        $this->addSubForm($subForm, $sessionName);
        
        $this->addElement('submit','Save',array(
          'ignore'=>true,
          'label'=>'Save'
         ));
    }
    
    protected function getSubFormDecoratorsMain($className, $id) {
        return array(   
            'FormElements',                        
            array(                
                'HtmlTag', array('tag' => 'ul')
            ),
            array(
                array('row' => 'HtmlTag'),                
                array('tag' => 'li', 'class' => $className, 'id' => $id)
            )
        );
    }       
    
    public function removeUneditableElements(){
        return false;
    }
}

