<?php

class Form_CostSearch extends BaseApp_Form {
    public function init() {
       $course = new Model_Courses();
        $this->setName('CostSearchForm');
        $this->addElement('text', 'primary_course_name', array(
            'required' => false,
            'label' => 'Course',
            'class' => 'text',
         //   'multioptions' => array('0' => '--Select--') + $course->fetchForSelect(array('is_dummy = ?' => 0, 'is_free = ?' => 0))
        ));
        $this->addElement('hidden', 'primary_course_id', array(
            'required' => false,
            'value' => '',
            'attribs' => array('readonly' => 'true')
        ));
        $this->addElement('submit', 'search', array(
            'label' => 'Search'
        ));
    }

    public function isValid($data) {
        $return = parent::isValid($data);
        if (isset($data['search']) && $data['search'] == 'Search') {
            if (empty($data['primary_course_id'])) {
                $this->getElement('primary_course_id')->setErrors(array("Please select a course"));
                $return = false;
                return $return;
            }

            $courseId = $data['primary_course_id'];
            $objPricing = new Model_Pricings();
            $priceData = $objPricing->fetchAll(array('course_id =?' => $courseId));
            //$trainingObj = new BaseApp_Dao_Courses();
            //$training_types = $trainingObj->getTrainingTypes($courseId);

            if (empty($priceData)) {
                $this->getElement('primary_course_id')->setErrors(array("Selected course dont have any Pricing Data. Please select other course"));
                $return = false;
                return $return;
            }
        }
        
        if (isset($data['submit']) && $data['submit'] == 'Save') {
            $return = true;
            return $return;
        }

        return $return;
    }

}
