<?php

class Form_ApplicationUniversity extends BaseApp_SubForm
{
    const FINANCING_REPLACE_TEXT = '#price#';

    private $_bundleId = false;

    public $dataToPrefill = [
        'app_learner_intro' => 'This program caters to working professionals from a variety of industries and backgrounds; the diversity of our students adds richness to class discussions and interactions.',
        'app_industry_intro' => 'The class consists of learners from excellent organizations and diverse industries',
        'app_industry_title_1' => 'Industry',
        'app_industry_title_2' => 'Companies',
        'app_we_intro' => 'The class maintains an impressive diversity across work experience and roles',
        'app_we_title_1' => 'Designation Breakup',
        'app_we_title_2' => 'Total Years of Experience',
        'app_ed_intro' => 'The class has learners with varied educational qualifications from excellent institutions',
        'app_ed_title_1' => 'Qualification',
        'app_ed_title_2' => 'Universities',
        'app_process_intro' => 'The application process consists of three simple steps. An offer of admission will be made to the selected candidates and accepted by the candidates by paying the admission fee.',
        'app_process_submit_text' => 'Tell us a bit about yourself and why you want to do this program',
        'app_process_review_text' => 'An admission panel will shortlist candidates based on their application',
        'app_process_text' => 'Selected candidates can begin the program within 1-2 weeks',
        'app_eligibility_intro' => 'For admission to this Post Graduate Program in Data Science, candidates should have:',
        'app_eligibility_work_exp' => '2+ years of work experience preferred',
        'app_eligibility_degree' => 'A bachelor\'s degree with an average of 50% or higher marks',
        'app_eligibility_basic' => 'Basic understanding of programming concepts and mathematics',
        'app_counselors_intro' => 'We have a team of dedicated admissions counselors who are available to guide you as you apply to the program. They are available to:',
        'app_counselors_point_1' => 'Address questions related to your application',
        'app_counselors_point_2' => 'Provide guidance regarding financial aid (if required)',
        'app_counselors_point_3' => 'Help answer questions and understand the program',
        'app_financing_intro' => 'The admission fee for this program is #price#',
        'app_program_benefit_1' => 'Complete this program while you work',
        'app_program_benefit_2' => 'Rigorous curriculum designed by industry experts',
        'app_program_benefit_3' => 'Purdue Alumni Association Membership from Purdue University',
        'app_program_benefit_4' => '28% annual growth in job openings',
        'app_program_benefit_5' => 'Active recruiters include Google, Microsoft, IBM and more',
    ];

    public function __construct($isNew = false, $bundleId = false)
    {
        if ($bundleId && !$isNew) {
            $this->_bundleId = $bundleId;
            $this->init($isNew);
        } else {
            $this->init($isNew);
        }
        $this->loadDefaultDecorators();
    }

    public function init($isNew = true)
    {
        $this->setName('application');
        $this->setMethod('post');
        $this->setAttrib('class', 'applicationForm');

        $validators25Text = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 25)));
        $validators100Text = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 100)));
        $validators180Text = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 180)));

        $mArrBundleAppData = [];
        if (!$isNew) {
            $session = new Zend_Session_Namespace('form');
            $sections = [
                BaseApp_Dao_ApplicationSectionData::SECTION_TYPE_APP_LEARNER_INTRO,
                BaseApp_Dao_ApplicationSectionData::SECTION_TYPE_APP_INDUSTRY,
                BaseApp_Dao_ApplicationSectionData::SECTION_TYPE_APP_WORK_EXPERIENCE,
                BaseApp_Dao_ApplicationSectionData::SECTION_TYPE_APP_EDUCATIONAL,
                BaseApp_Dao_ApplicationSectionData::SECTION_TYPE_APP_ADMISSION_PROCESS,
                BaseApp_Dao_ApplicationSectionData::SECTION_TYPE_APP_ADMISSION_ELIGIBILITY,
                BaseApp_Dao_ApplicationSectionData::SECTION_TYPE_APP_ADMISSION_COUNSELORS,
                BaseApp_Dao_ApplicationSectionData::SECTION_TYPE_APP_FINANCIAL_INTRO,
                BaseApp_Dao_ApplicationSectionData::SECTION_TYPE_APP_PROGRAM_BENEFITS
            ];
            foreach ($sections as $sectionName) {
                $mArrBundleAppData[$sectionName] = $session->$sectionName;
            }
        }

        // prd($mArrBundleAppData);
        $app_learner_intro = !empty($mArrBundleAppData['app_learner_intro']['intro']) ? $mArrBundleAppData['app_learner_intro']['intro'] : $this->prefillField('app_learner_intro', $isNew);
        $app_learner_aid = !empty($mArrBundleAppData['app_learner_intro']['id']) ? $mArrBundleAppData['app_learner_intro']['id'] : null;

        // $product_section_id = !empty($mArrBundleAppData['app_industry']['product_section_id']) ? $mArrBundleAppData['app_industry']['product_section_id'] : null;
        $app_industry_aid = !empty($mArrBundleAppData['app_industry']['id']) ? $mArrBundleAppData['app_industry']['id'] : null;
        $app_industry_intro = !empty($mArrBundleAppData['app_industry']['intro']) ? $mArrBundleAppData['app_industry']['intro'] : $this->prefillField('app_industry_intro', $isNew);
        $app_industry_title_1 = !empty($mArrBundleAppData['app_industry']['first_sec_title']) ? $mArrBundleAppData['app_industry']['first_sec_title'] : $this->prefillField('app_industry_title_1', $isNew);
        $app_industry_data = !empty($mArrBundleAppData['app_industry']['industry_data']) ? $mArrBundleAppData['app_industry']['industry_data'] : [];
        $app_industry_title_2 = !empty($mArrBundleAppData['app_industry']['second_sec_title']) ? $mArrBundleAppData['app_industry']['second_sec_title'] : $this->prefillField('app_industry_title_2', $isNew);
        // $app_hiring_companies = !empty($mArrBundleAppData['app_industry']['details2']) ? json_decode($mArrBundleAppData['app_industry']['details2'], true) : [];
        $app_hiring_companies_id = !empty($mArrBundleAppData['app_industry']['hiring_companies']) ? $mArrBundleAppData['app_industry']['hiring_companies'] : [];

        $app_work_experience_aid = !empty($mArrBundleAppData['app_work_experience']['id']) ? $mArrBundleAppData['app_work_experience']['id'] : null;
        $app_we_intro = !empty($mArrBundleAppData['app_work_experience']['intro']) ? $mArrBundleAppData['app_work_experience']['intro'] : $this->prefillField('app_we_intro', $isNew);
        $app_we_title_1 = !empty($mArrBundleAppData['app_work_experience']['first_sec_title']) ? $mArrBundleAppData['app_work_experience']['first_sec_title'] : $this->prefillField('app_we_title_1', $isNew);
        $app_we_designation_data = !empty($mArrBundleAppData['app_work_experience']['designation_data']) ? $mArrBundleAppData['app_work_experience']['designation_data'] : [];
        $app_we_title_2 = !empty($mArrBundleAppData['app_work_experience']['second_sec_title']) ? $mArrBundleAppData['app_work_experience']['second_sec_title'] : $this->prefillField('app_we_title_2', $isNew);
        $app_we_exp_data = !empty($mArrBundleAppData['app_work_experience']['exp_data']) ? $mArrBundleAppData['app_work_experience']['exp_data'] : [];

        $app_educational_aid = !empty($mArrBundleAppData['app_educational']['id']) ? $mArrBundleAppData['app_educational']['id'] : null;
        $app_ed_intro = !empty($mArrBundleAppData['app_educational']['intro']) ? $mArrBundleAppData['app_educational']['intro'] : $this->prefillField('app_ed_intro', $isNew);
        $app_ed_title_1 = !empty($mArrBundleAppData['app_educational']['first_sec_title']) ? $mArrBundleAppData['app_educational']['first_sec_title'] : $this->prefillField('app_ed_title_1', $isNew);
        $app_ed_industry_data = !empty($mArrBundleAppData['app_educational']['industry_data']) ? $mArrBundleAppData['app_educational']['industry_data'] : [];
        $app_ed_title_2 = !empty($mArrBundleAppData['app_educational']['second_sec_title']) ? $mArrBundleAppData['app_educational']['second_sec_title'] : $this->prefillField('app_ed_title_2', $isNew);
        $app_ed_logo_data = !empty($mArrBundleAppData['app_educational']['college_logos']) ? $mArrBundleAppData['app_educational']['college_logos'] : [];

        // hidden fields id's
        $app_admission_process_aid = !empty($mArrBundleAppData['app_admission_process']['id']) ? $mArrBundleAppData['app_admission_process']['id'] : null;
        $app_admission_eligibility_aid = !empty($mArrBundleAppData['app_admission_eligibility']['id']) ? $mArrBundleAppData['app_admission_eligibility']['id'] : null;
        $app_admission_counselors_aid = !empty($mArrBundleAppData['app_admission_counselors']['id']) ? $mArrBundleAppData['app_admission_counselors']['id'] : null;

        $app_financing_aid = !empty($mArrBundleAppData['app_financing_intro']['id']) ? $mArrBundleAppData['app_financing_intro']['id'] : null;
        $app_program_benifits_aid = !empty($mArrBundleAppData['app_program_benefits']['id']) ? $mArrBundleAppData['app_program_benefits']['id'] : null;


        //****************************** Learners Profile Starts *****************************

        $this->addElement('textarea', 'app_learner_intro', array(
            'label' => 'Intro*',
            'required' => true,
            'filter' => array('StringTrim'),
            'rows' => 5,
            'value' => $app_learner_intro,
            'cols' => 60,
            'class' => 'description',
            'validators' => $validators180Text
        ));

        /**
         * Industry Info Starts
         */
        $this->addElement('text', 'app_industry_intro', array(
            'label' => 'Intro Text*',
            'required' => true,
            'value' => $app_industry_intro,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'validators' => $validators100Text
        ));

        $this->addElement('text', 'app_industry_title_1', array(
            'label' => 'Industry Section Title*',
            'required' => true,
            'value' => $app_industry_title_1,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'validators' => $validators25Text
        ));

        $this->addElement('text', 'industry_name', array(
            'label' => 'Industry Data*',
            'placeholder' => "Industry Name",
            'filters' => array('StringTrim'),
            'class' => ''
        ));

        $this->addElement('text', 'industry_ratio', array(
            'label' => 'Market Ratio',
            'placeholder' => "Market Ratio",
            'filters' => array('StringTrim'),
            'class' => ''
        ));

        $this->addElement('button', 'industry_add', array(
            'label' => '+',
            'class' => 'btn btn-success'
        ));

        $this->addElement('hidden', 'app_industry_data', array('required' => false, 'value' => !empty($app_industry_data) ? json_encode($app_industry_data) : json_encode([])));

        $this->addElement('text', 'app_industry_title_2', array(
            'label' => 'Company Section Title*',
            'required' => true,
            'value' => $app_industry_title_2,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'validators' => $validators25Text
        ));

        $this->addElement('select', 'app_hiring_companies', array(
            'label' => 'Hiring Companies* (Max 12)',
            'size' => '12',
            'required' => false,
            'multiple' => false,
            'class' => 'multiple SearchBoxPlugin',
            'registerInArrayValidator' => false,
            'multioptions' => $this->_getHiringCompaniesForSelect()
        ));
        $this->addElement('hidden', 'app_hiring_companies_id', array(
            'required' => false,
            'value' => !empty($app_hiring_companies_id) ? implode(",",$app_hiring_companies_id) : ''
        ));
        /**
         * Industry Info Ends
         */

        /**
         * Work Exp Info Starts
         */
        $this->addElement('text', 'app_we_intro', array(
            'label' => 'Intro Text',
            'value' => $app_we_intro,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'validators' => $validators100Text
        ));

        $this->addElement('text', 'app_we_title_1', array(
            'label' => 'Designation Section Title',
            'value' => $app_we_title_1,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'validators' => $validators25Text
        ));

        $this->addElement('text', 'we_designation_name', array(
            'label' => 'Designation Data',
            'placeholder' => "Designation",
            'filters' => array('StringTrim'),
            'class' => '',
        ));

        $this->addElement('text', 'we_designation_ratio', array(
            'label' => 'Learner Breakup',
            'placeholder' => "Learner Breakup",
            'filters' => array('StringTrim'),
            'class' => ''
        ));

        $this->addElement('button', 'we_designation_add', array(
            'label' => '+',
            'class' => 'btn btn-success'
        ));

        $this->addElement('hidden', 'app_we_designation_data', array('required' => false, 'value' => !empty($app_we_designation_data) ? json_encode($app_we_designation_data) : json_encode([])));

        $this->addElement('text', 'app_we_title_2', array(
            'label' => 'Experience Section Title',
            'value' => $app_we_title_2,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'validators' => $validators25Text
        ));

        $this->addElement('text', 'we_years_name', array(
            'label' => 'Experience Data',
            'placeholder' => "# Years",
            'filters' => array('StringTrim'),
            'class' => '',
        ));

        $this->addElement('text', 'we_years_ratio', array(
            'label' => 'Market Ratio',
            'placeholder' => "Market Ratio",
            'filters' => array('StringTrim'),
            'class' => ''
        ));

        $this->addElement('button', 'we_years_add', array(
            'label' => '+',
            'class' => 'btn btn-success'
        ));

        $this->addElement('hidden', 'app_we_exp_data', array('required' => false, 'value' => !empty($app_we_exp_data) ? json_encode($app_we_exp_data) : json_encode([])));
        /**
         * Work Exp Info Ends
         */

        /**
         * Education Info Starts
         */
        $this->addElement('text', 'app_ed_intro', array(
            'label' => 'Intro Text',
            'value' => $app_ed_intro,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'validators' => $validators100Text
        ));

        $this->addElement('text', 'app_ed_title_1', array(
            'label' => 'Industry Section Title',
            'value' => $app_ed_title_1,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'validators' => $validators25Text
        ));

        $this->addElement('text', 'ed_industry_name', array(
            'label' => 'Industry Data',
            'placeholder' => "Industry Name",
            'filters' => array('StringTrim'),
            'class' => '',
        ));

        $this->addElement('text', 'ed_industry_ratio', array(
            'label' => 'Market Ratio',
            'placeholder' => "Market Ratio",
            'filters' => array('StringTrim'),
            'class' => ''
        ));

        $this->addElement('button', 'ed_industry_add', array(
            'label' => '+',
            'class' => 'btn btn-success'
        ));

        $this->addElement('hidden', 'app_ed_industry_data', array('required' => false, 'value' => !empty($app_ed_industry_data) ? json_encode($app_ed_industry_data) : json_encode([])));

        $this->addElement('text', 'app_ed_title_2', array(
            'label' => 'College Section Title',
            'value' => $app_ed_title_2,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'validators' => $validators25Text
        ));

        $this->addElement('text', 'ed_logo_name', array(
            'label' => 'Top Colleges (Max 12)',
            'placeholder' => "Logo Text",
            'filters' => array('StringTrim'),
            'class' => ''
        ));

        $this->addElement('text', 'ed_logo_url', array(
            'placeholder' => "Logo Url",
            'filters' => array('StringTrim'),
            'class' => ''
        ));

        $this->addElement('button', 'ed_logo_add', array(
            'label' => '+',
            'class' => 'btn btn-success'
        ));

        $this->addElement('hidden', 'app_ed_logo_data', array('required' => false, 'value' => !empty($app_ed_logo_data) ? json_encode($app_ed_logo_data) : json_encode([])));
        /**
         * Education Info Ends
         */

        /**
         * Formatting in Group Starts
         */

        $learnerGroup = array('app_learner_intro');
        $this->addDisplayGroup($learnerGroup, 'learner_group');
        $this->getDisplayGroup('learner_group')
            ->setLegend("Learner's Profile")
            ->clearDecorators()
            ->addDecorator('FormElements')
            ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper'));

        $industryGroup = array('app_industry_intro', 'app_industry_title_1', 'industry_name', 'industry_ratio', 'industry_add', 'app_industry_data', 'app_industry_title_2', 'app_hiring_companies','app_hiring_companies_id');
        $this->addDisplayGroup($industryGroup, 'industry_group');
        $this->getDisplayGroup('industry_group')
            ->setLegend('Industry Tab (Compulsory)')
            ->clearDecorators()
            ->addDecorator('FormElements')
            ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper internalHeading'));

        $weGroup = array('app_we_intro', 'app_we_title_1', 'we_designation_name', 'we_designation_ratio', 'we_designation_add', 'app_we_designation_data', 'app_we_title_2', 'we_years_name', 'we_years_ratio', 'we_years_add', 'app_we_exp_data');
        $this->addDisplayGroup($weGroup, 'we_group');
        $this->getDisplayGroup('we_group')
            ->setLegend('Work Experience (Optional)')
            ->clearDecorators()
            ->addDecorator('FormElements')
            ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper internalHeading'));

        $edGroup = array('app_ed_intro', 'app_ed_title_1', 'ed_industry_name', 'ed_industry_ratio', 'ed_industry_add', 'app_ed_industry_data', 'app_ed_title_2', 'ed_logo_name', 'ed_logo_url', 'ed_logo_add', 'app_ed_logo_data');
        $this->addDisplayGroup($edGroup, 'ed_group');
        $this->getDisplayGroup('ed_group')
            ->setLegend('Educational (Optional)')
            ->clearDecorators()
            ->addDecorator('FormElements')
            ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper internalHeading'));

        $this->applicationProcessSection($mArrBundleAppData, $isNew);
        $this->eligibilitySection($mArrBundleAppData, $isNew);
        $this->counselorsSection($mArrBundleAppData, $isNew);
        $this->financingSection($mArrBundleAppData, $isNew);
        $this->programBenefitsSection($mArrBundleAppData, $isNew);
        /** Formatting in Group Ends */

        /**
         * End Of Sub-Form
         */
        $this->postSetup();


        $this->getElement('app_learner_intro')
            ->setDescription("Max: 180 characters")
            ->setDecorators(array(
                'ViewHelper',
                array('Description', array('escape' => false, 'tag' => 'p', 'class' => 'description-note')),
                array('HtmlTag', array('tag' => 'div', 'class' => 'element')),
                array('Label', array('tag' => 'div')),
                array('Errors'),
                array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
            ));

        $this->getElement('app_industry_intro')
            ->setDescription("Max: 100 characters")
            ->setDecorators(array(
                'ViewHelper',
                array('Description', array('escape' => false, 'tag' => 'p', 'class' => 'description-note')),
                array('HtmlTag', array('tag' => 'div', 'class' => 'element')),
                array('Label', array('tag' => 'div')),
                array('Errors'),
                array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
            ));

        $this->getElement('app_industry_title_1')
            ->setDescription("Max: 25 characters")
            ->setDecorators(array(
                'ViewHelper',
                array('Description', array('escape' => false, 'tag' => 'p', 'class' => 'description-note')),
                array('HtmlTag', array('tag' => 'div', 'class' => 'element')),
                array('Label', array('tag' => 'div')),
                array('Errors'),
                array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
            ));

        $this->getElement('app_industry_title_2')
            ->setDescription("Max: 25 characters")
            ->setDecorators(array(
                'ViewHelper',
                array('Description', array('escape' => false, 'tag' => 'p', 'class' => 'description-note')),
                array('HtmlTag', array('tag' => 'div', 'class' => 'element')),
                array('Label', array('tag' => 'div')),
                array('Errors'),
                array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
            ));

        $this->getElement('app_we_intro')
            ->setDescription("Max: 100 characters")
            ->setDecorators(array(
                'ViewHelper',
                array('Description', array('escape' => false, 'tag' => 'p', 'class' => 'description-note')),
                array('HtmlTag', array('tag' => 'div', 'class' => 'element')),
                array('Label', array('tag' => 'div')),
                array('Errors'),
                array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
            ));

        $this->getElement('app_we_title_1')
            ->setDescription("Max: 25 characters")
            ->setDecorators(array(
                'ViewHelper',
                array('Description', array('escape' => false, 'tag' => 'p', 'class' => 'description-note')),
                array('HtmlTag', array('tag' => 'div', 'class' => 'element')),
                array('Label', array('tag' => 'div')),
                array('Errors'),
                array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
            ));

        $this->getElement('app_we_title_2')
            ->setDescription("Max: 25 characters")
            ->setDecorators(array(
                'ViewHelper',
                array('Description', array('escape' => false, 'tag' => 'p', 'class' => 'description-note')),
                array('HtmlTag', array('tag' => 'div', 'class' => 'element')),
                array('Label', array('tag' => 'div')),
                array('Errors'),
                array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
            ));

        $this->getElement('app_ed_intro')
            ->setDescription("Max: 100 characters")
            ->setDecorators(array(
                'ViewHelper',
                array('Description', array('escape' => false, 'tag' => 'p', 'class' => 'description-note')),
                array('HtmlTag', array('tag' => 'div', 'class' => 'element')),
                array('Label', array('tag' => 'div')),
                array('Errors'),
                array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
            ));

        $this->getElement('app_ed_title_1')
            ->setDescription("Max: 25 characters")
            ->setDecorators(array(
                'ViewHelper',
                array('Description', array('escape' => false, 'tag' => 'p', 'class' => 'description-note')),
                array('HtmlTag', array('tag' => 'div', 'class' => 'element')),
                array('Label', array('tag' => 'div')),
                array('Errors'),
                array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
            ));

        $this->getElement('app_ed_title_2')
            ->setDescription("Max: 25 characters")
            ->setDecorators(array(
                'ViewHelper',
                array('Description', array('escape' => false, 'tag' => 'p', 'class' => 'description-note')),
                array('HtmlTag', array('tag' => 'div', 'class' => 'element')),
                array('Label', array('tag' => 'div')),
                array('Errors'),
                array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
            ));

        $this->getElement('app_process_intro')
            ->setDescription("Max: 180 characters")
            ->setDecorators(array(
                'ViewHelper',
                array('Description', array('escape' => false, 'tag' => 'p', 'class' => 'description-note')),
                array('HtmlTag', array('tag' => 'div', 'class' => 'element')),
                array('Label', array('tag' => 'div')),
                array('Errors'),
                array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
            ));

        $this->getElement('app_process_submit_text')
            ->setDescription("Max: 75 characters")
            ->setDecorators(array(
                'ViewHelper',
                array('Description', array('escape' => false, 'tag' => 'p', 'class' => 'description-note')),
                array('HtmlTag', array('tag' => 'div', 'class' => 'element')),
                array('Label', array('tag' => 'div')),
                array('Errors'),
                array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
            ));

        $this->getElement('app_process_review_text')
            ->setDescription("Max: 75 characters")
            ->setDecorators(array(
                'ViewHelper',
                array('Description', array('escape' => false, 'tag' => 'p', 'class' => 'description-note')),
                array('HtmlTag', array('tag' => 'div', 'class' => 'element')),
                array('Label', array('tag' => 'div')),
                array('Errors'),
                array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
            ));

        $this->getElement('app_process_text')
            ->setDescription("Max: 75 characters")
            ->setDecorators(array(
                'ViewHelper',
                array('Description', array('escape' => false, 'tag' => 'p', 'class' => 'description-note')),
                array('HtmlTag', array('tag' => 'div', 'class' => 'element')),
                array('Label', array('tag' => 'div')),
                array('Errors'),
                array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
            ));

        $this->getElement('app_eligibility_intro')
            ->setDescription("Max: 90 characters")
            ->setDecorators(array(
                'ViewHelper',
                array('Description', array('escape' => false, 'tag' => 'p', 'class' => 'description-note')),
                array('HtmlTag', array('tag' => 'div', 'class' => 'element')),
                array('Label', array('tag' => 'div')),
                array('Errors'),
                array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
            ));

        $this->getElement('app_eligibility_work_exp')
            ->setDescription("Max: 70 characters")
            ->setDecorators(array(
                'ViewHelper',
                array('Description', array('escape' => false, 'tag' => 'p', 'class' => 'description-note')),
                array('HtmlTag', array('tag' => 'div', 'class' => 'element')),
                array('Label', array('tag' => 'div')),
                array('Errors'),
                array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
            ));

        $this->getElement('app_eligibility_degree')
            ->setDescription("Max: 70 characters")
            ->setDecorators(array(
                'ViewHelper',
                array('Description', array('escape' => false, 'tag' => 'p', 'class' => 'description-note')),
                array('HtmlTag', array('tag' => 'div', 'class' => 'element')),
                array('Label', array('tag' => 'div')),
                array('Errors'),
                array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
            ));

        $this->getElement('app_eligibility_basic')
            ->setDescription("Max: 70 characters")
            ->setDecorators(array(
                'ViewHelper',
                array('Description', array('escape' => false, 'tag' => 'p', 'class' => 'description-note')),
                array('HtmlTag', array('tag' => 'div', 'class' => 'element')),
                array('Label', array('tag' => 'div')),
                array('Errors'),
                array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
            ));

        $this->getElement('app_counselors_intro')
            ->setDescription("Max: 140 characters")
            ->setDecorators(array(
                'ViewHelper',
                array('Description', array('escape' => false, 'tag' => 'p', 'class' => 'description-note')),
                array('HtmlTag', array('tag' => 'div', 'class' => 'element')),
                array('Label', array('tag' => 'div')),
                array('Errors'),
                array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
            ));

        $this->getElement('app_counselors_point_1')
            ->setDescription("Max: 60 characters")
            ->setDecorators(array(
                'ViewHelper',
                array('Description', array('escape' => false, 'tag' => 'p', 'class' => 'description-note')),
                array('HtmlTag', array('tag' => 'div', 'class' => 'element')),
                array('Label', array('tag' => 'div')),
                array('Errors'),
                array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
            ));

        $this->getElement('app_counselors_point_2')
            ->setDescription("Max: 60 characters")
            ->setDecorators(array(
                'ViewHelper',
                array('Description', array('escape' => false, 'tag' => 'p', 'class' => 'description-note')),
                array('HtmlTag', array('tag' => 'div', 'class' => 'element')),
                array('Label', array('tag' => 'div')),
                array('Errors'),
                array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
            ));

        $this->getElement('app_counselors_point_3')
            ->setDescription("Max: 60 characters")
            ->setDecorators(array(
                'ViewHelper',
                array('Description', array('escape' => false, 'tag' => 'p', 'class' => 'description-note')),
                array('HtmlTag', array('tag' => 'div', 'class' => 'element')),
                array('Label', array('tag' => 'div')),
                array('Errors'),
                array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
            ));

        $this->getElement('app_program_benefit_1')
            ->setDescription("Max: 60 characters")
            ->setDecorators(array(
                'ViewHelper',
                array('Description', array('escape' => false, 'tag' => 'p', 'class' => 'description-note')),
                array('HtmlTag', array('tag' => 'div', 'class' => 'element')),
                array('Label', array('tag' => 'div')),
                array('Errors'),
                array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
            ));

        $this->getElement('app_program_benefit_2')
            ->setDescription("Max: 60 characters")
            ->setDecorators(array(
                'ViewHelper',
                array('Description', array('escape' => false, 'tag' => 'p', 'class' => 'description-note')),
                array('HtmlTag', array('tag' => 'div', 'class' => 'element')),
                array('Label', array('tag' => 'div')),
                array('Errors'),
                array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
            ));

        $this->getElement('app_program_benefit_3')
            ->setDescription("Max: 60 characters")
            ->setDecorators(array(
                'ViewHelper',
                array('Description', array('escape' => false, 'tag' => 'p', 'class' => 'description-note')),
                array('HtmlTag', array('tag' => 'div', 'class' => 'element')),
                array('Label', array('tag' => 'div')),
                array('Errors'),
                array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
            ));

        $this->getElement('app_program_benefit_4')
            ->setDescription("Max: 60 characters")
            ->setDecorators(array(
                'ViewHelper',
                array('Description', array('escape' => false, 'tag' => 'p', 'class' => 'description-note')),
                array('HtmlTag', array('tag' => 'div', 'class' => 'element')),
                array('Label', array('tag' => 'div')),
                array('Errors'),
                array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
            ));

        $this->getElement('app_program_benefit_5')
            ->setDescription("Max: 60 characters")
            ->setDecorators(array(
                'ViewHelper',
                array('Description', array('escape' => false, 'tag' => 'p', 'class' => 'description-note')),
                array('HtmlTag', array('tag' => 'div', 'class' => 'element')),
                array('Label', array('tag' => 'div')),
                array('Errors'),
                array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
            ));


        $this->getElement('app_financing_intro')
            ->setDescription("Max: 180 characters. Financing Intro should contain " . $this::FINANCING_REPLACE_TEXT . " for fee to be added")
            ->setDecorators(array(
                'ViewHelper',
                array('Description', array('escape' => false, 'tag' => 'p', 'class' => 'description-note')),
                array('HtmlTag', array('tag' => 'div', 'class' => 'element')),
                array('Label', array('tag' => 'div')),
                array('Errors'),
                array(array('divWrapper' => 'HtmlTag'), array('tag' => 'li')),
            ));

        $this->addElement('hidden', 'isNewEntry', array('required' => false, 'value' => !empty($app_learner_aid) ? false : true));

        $this->addElement('hidden', 'app_industry_aid', array('required' => false, 'value' => !empty($app_industry_aid) ? $app_industry_aid : null));
        $this->addElement('hidden', 'app_work_experience_aid', array('required' => false, 'value' => !empty($app_work_experience_aid) ? $app_work_experience_aid : null));
        $this->addElement('hidden', 'app_educational_aid', array('required' => false, 'value' => !empty($app_educational_aid) ? $app_educational_aid : null));
        $this->addElement('hidden', 'app_admission_process_aid', array('required' => false, 'value' => !empty($app_admission_process_aid) ? $app_admission_process_aid : null));
        $this->addElement('hidden', 'app_admission_eligibility_aid', array('required' => false, 'value' => !empty($app_admission_eligibility_aid) ? $app_admission_eligibility_aid : null));
        $this->addElement('hidden', 'app_admission_counselors_aid', array('required' => false, 'value' => !empty($app_admission_counselors_aid) ? $app_admission_counselors_aid : null));
        $this->addElement('hidden', 'app_program_benifits_aid', array('required' => false, 'value' => !empty($app_program_benifits_aid) ? $app_program_benifits_aid : null));

        $this->addElement('hidden', 'app_learner_aid', array('required' => false, 'value' => !empty($app_learner_aid) ? $app_learner_aid : null));
        // $this->addElement('hidden', 'product_section_id', array('required' => false, 'value' => !empty($product_section_id) ? $product_section_id : null));
        /* $this->addElement('hidden', 'app_work_experience_psid', array('required' => false, 'value' => !empty($app_work_experience_psid) ? $app_work_experience_psid : null)); */
        /* $this->addElement('hidden', 'app_educational_psid', array('required' => false, 'value' => !empty($app_educational_psid) ? $app_educational_psid : null)); */
        /* $this->addElement('hidden', 'app_admission_process_psid', array('required' => false, 'value' => !empty($app_admission_process_psid) ? $app_admission_process_psid : null)); */
        /* $this->addElement('hidden', 'app_admission_eligibility_psid', array('required' => false, 'value' => !empty($app_admission_eligibility_psid) ? $app_admission_eligibility_psid : null));
        $this->addElement('hidden', 'app_admission_counselors_psid', array('required' => false, 'value' => !empty($app_admission_counselors_psid) ? $app_admission_counselors_psid : null));
        $this->addElement('hidden', 'app_program_benifits_psid', array('required' => false, 'value' => !empty($app_program_benifits_psid) ? $app_program_benifits_psid : null)); */
        $this->addElement('hidden', 'app_financing_aid', array('required' => false, 'value' => !empty($app_financing_aid) ? $app_financing_aid : null));


        $hiddenFields = array(
            'app_industry_aid', 'app_work_experience_aid', 'app_educational_aid',
            'app_admission_process_aid', 'app_admission_eligibility_aid', 'app_admission_counselors_aid',
            'app_program_benifits_aid', 'app_learner_aid', 'app_financing_aid'
        );

        foreach ($hiddenFields as $field) {
            $this->getElement($field)->setDecorators(array('ViewHelper'));
        }
    }
    // end of function init

    private function prefillField($fieldName, $isNew)
    {
        return !$isNew ? '' : isset($this->dataToPrefill[$fieldName]) ? $this->dataToPrefill[$fieldName] : '';
    }

    private function applicationProcessSection($mArrBundleAppData, $isNew)
    {
        $validators180Text = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 180)));
        $validatorsPointText = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 75)));

        $this->addElement('textarea', 'app_process_intro', array(
            'label' => 'Admission Intro*',
            'required' => true,
            'filters' => array('StringTrim'),
            'value' => !empty($mArrBundleAppData['app_admission_process']['intro']) ? $mArrBundleAppData['app_admission_process']['intro'] : $this->prefillField('app_process_intro', $isNew),
            'class' => 'description',
            'rows' => 5,
            'cols' => 60,
            'validators' => $validators180Text
        ));

        $this->addElement('text', 'app_process_submit_text', array(
            'label' => 'Submit Application Text*',
            'required' => true,
            'filters' => array('StringTrim'),
            'value' => !empty($mArrBundleAppData['app_admission_process']['submit_text']) ? $mArrBundleAppData['app_admission_process']['submit_text'] : $this->prefillField('app_process_submit_text', $isNew),
            'class' => 'longtext',
            'validators' => $validatorsPointText
        ));

        $this->addElement('text', 'app_process_review_text', array(
            'label' => 'Application Review Text*',
            'required' => true,
            'filters' => array('StringTrim'),
            'value' => !empty($mArrBundleAppData['app_admission_process']['review_text']) ? $mArrBundleAppData['app_admission_process']['review_text'] : $this->prefillField('app_process_review_text', $isNew),
            'class' => 'longtext',
            'validators' => $validatorsPointText
        ));

        $this->addElement('text', 'app_process_text', array(
            'label' => 'Admission Text*',
            'required' => true,
            'filters' => array('StringTrim'),
            'value' => !empty($mArrBundleAppData['app_admission_process']['admission_text']) ? $mArrBundleAppData['app_admission_process']['admission_text'] : $this->prefillField('app_process_text', $isNew),
            'class' => 'longtext',
            'validators' => $validatorsPointText
        ));

        $applicationProcessGroup = array('app_process_intro', 'app_process_submit_text', 'app_process_review_text', 'app_process_text');
        $this->addDisplayGroup($applicationProcessGroup, 'app_process_group');
        $this->getDisplayGroup('app_process_group')
            ->setLegend('Application Process')
            ->clearDecorators()
            ->addDecorator('FormElements')
            ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper internalHeading'));
    }

    private function eligibilitySection($mArrBundleAppData, $isNew)
    {
        $validators90Text = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 90)));
        $validatorsPointText = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 70)));

        $eligibilityGroupData = !empty($mArrBundleAppData['app_admission_eligibility']) ? $mArrBundleAppData['app_admission_eligibility'] : '';
        if (!empty($eligibilityGroupData)) {
            $eligibilityWe =  !empty($eligibilityGroupData['work_exp']) ? $eligibilityGroupData['work_exp'] : '';
            $eligibilityWeOrder =  !empty($eligibilityGroupData['work_exp_order']) ? $eligibilityGroupData['work_exp_order'] : '';
            $eligibilityDegree = !empty($eligibilityGroupData['degree']) ? $eligibilityGroupData['degree'] : '';
            $eligibilityDegreeOrder = !empty($eligibilityGroupData['degree_order']) ? $eligibilityGroupData['degree_order'] : '';
            $eligibilityBasic =  !empty($eligibilityGroupData['basic_concept']) ? $eligibilityGroupData['basic_concept'] : "";
            $eligibilityBasicOrder =  !empty($eligibilityGroupData['basic_concept_order']) ? $eligibilityGroupData['basic_concept_order'] : "";
        }

        $this->addElement('textarea', 'app_eligibility_intro', array(
            'label' => 'Intro*',
            'required' => true,
            'filters' => array('StringTrim'),
            'value' => !empty($mArrBundleAppData['app_admission_eligibility']['intro']) ? $mArrBundleAppData['app_admission_eligibility']['intro'] : $this->prefillField('app_eligibility_intro', $isNew),
            'class' => 'description',
            'rows' => 5,
            'cols' => 60,
            'validators' => $validators90Text
        ));

        $this->addElement('text', 'app_eligibility_work_exp', array(
            'label' => 'Work Experience*',
            'required' => true,
            'filters' => array('StringTrim'),
            'value' => isset($eligibilityWe) && !empty($eligibilityWe) ? $eligibilityWe : $this->prefillField('app_eligibility_work_exp', $isNew),
            'class' => '',
            'validators' => $validatorsPointText
        ));

        $this->addElement('text', 'app_eligibility_work_exp_order', array(
            'label' => 'Position*',
            'placeholder' => "1",
            'required' => true,
            'filters' => array('StringTrim'),
            'value' => isset($eligibilityWeOrder) && !empty($eligibilityWeOrder) ? $eligibilityWeOrder : '',
            'class' => ''
        ));

        $this->addElement('text', 'app_eligibility_degree', array(
            'label' => 'Degree*',
            'required' => true,
            'filters' => array('StringTrim'),
            'value' => isset($eligibilityDegree) && !empty($eligibilityDegree) ? $eligibilityDegree : $this->prefillField('app_eligibility_degree', $isNew),
            'class' => '',
            'validators' => $validatorsPointText
        ));

        $this->addElement('text', 'app_eligibility_degree_order', array(
            'label' => 'Position*',
            'placeholder' => "2",
            'required' => true,
            'filters' => array('StringTrim'),
            'value' => isset($eligibilityDegreeOrder) && !empty($eligibilityDegreeOrder) ? $eligibilityDegreeOrder : '',
            'class' => ''
        ));

        $this->addElement('text', 'app_eligibility_basic', array(
            'label' => 'Basic Concepts*',
            'required' => true,
            'filters' => array('StringTrim'),
            'value' => isset($eligibilityBasic) && !empty($eligibilityBasic) ? $eligibilityBasic : $this->prefillField('app_eligibility_basic', $isNew),
            'class' => '',
            'validators' => $validatorsPointText
        ));

        $this->addElement('text', 'app_eligibility_basic_order', array(
            'label' => 'Position*',
            'placeholder' => "2",
            'required' => true,
            'filters' => array('StringTrim'),
            'value' => isset($eligibilityBasicOrder) && !empty($eligibilityBasicOrder) ? $eligibilityBasicOrder : '',
            'class' => ''
        ));

        $eligibilityGroup = array('app_eligibility_intro', 'app_eligibility_work_exp', 'app_eligibility_work_exp_order', 'app_eligibility_degree', 'app_eligibility_degree_order', 'app_eligibility_basic', 'app_eligibility_basic_order');
        $this->addDisplayGroup($eligibilityGroup, 'app_eligibility_group');
        $this->getDisplayGroup('app_eligibility_group')
            ->setLegend('Eligibility')
            ->clearDecorators()
            ->addDecorator('FormElements')
            ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper internalHeading'));
    }

    private function counselorsSection($mArrBundleAppData, $isNew)
    {
        $validators140Text = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 140)));
        $validatorsPointText = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 60)));

        $this->addElement('textarea', 'app_counselors_intro', array(
            'label' => 'Intro*',
            'required' => true,
            'filters' => array('StringTrim'),
            'value' => !empty($mArrBundleAppData['app_admission_counselors']['intro']) ? $mArrBundleAppData['app_admission_counselors']['intro'] : $this->prefillField('app_counselors_intro', $isNew),
            'class' => 'description',
            'rows' => 5,
            'cols' => 60,
            'validators' => $validators140Text
        ));

        $this->addElement('text', 'app_counselors_point_1', array(
            'label' => 'Point - 1*',
            'required' => true,
            'filters' => array('StringTrim'),
            'value' =>  !empty($mArrBundleAppData['app_admission_counselors']['point_1']) ? $mArrBundleAppData['app_admission_counselors']['point_1'] : $this->prefillField('app_counselors_point_1', $isNew),
            'class' => 'longtext',
            'validators' => $validatorsPointText
        ));

        $this->addElement('text', 'app_counselors_point_2', array(
            'label' => 'Point - 2*',
            'required' => true,
            'filters' => array('StringTrim'),
            'value' => !empty($mArrBundleAppData['app_admission_counselors']['point_2']) ? $mArrBundleAppData['app_admission_counselors']['point_2'] : $this->prefillField('app_counselors_point_2', $isNew),
            'class' => 'longtext',
            'validators' => $validatorsPointText
        ));

        $this->addElement('text', 'app_counselors_point_3', array(
            'label' => 'Point - 3*',
            'required' => true,
            'filters' => array('StringTrim'),
            'value' =>  !empty($mArrBundleAppData['app_admission_counselors']['point_3']) ? $mArrBundleAppData['app_admission_counselors']['point_3'] : $this->prefillField('app_counselors_point_3', $isNew),
            'class' => 'longtext',
            'validators' => $validatorsPointText
        ));

        $counselorsGroup = array('app_counselors_intro', 'app_counselors_point_1', 'app_counselors_point_2', 'app_counselors_point_3',);
        $this->addDisplayGroup($counselorsGroup, 'app_counselors_group');
        $this->getDisplayGroup('app_counselors_group')
            ->setLegend('Admission Counselors')
            ->clearDecorators()
            ->addDecorator('FormElements')
            ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper internalHeading'));
    }

    private function financingSection($mArrBundleAppData, $isNew)
    {
        $validators180Text = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 180)));
        
        $this->addElement('textarea', 'app_financing_intro', array(
            'label' => 'Fees Intro*',
            'required' => true,
            'filters' => array('StringTrim'),
            'value' => !empty($mArrBundleAppData['app_financing_intro']['intro']) ? $mArrBundleAppData['app_financing_intro']['intro'] : $this->prefillField('app_financing_intro', $isNew),
            'class' => 'description',
            'rows' => 5,
            'cols' => 60,
            'required' => true,
            'validators' => $validators180Text
        ));

        $financingGroup = array('app_financing_intro');
        $this->addDisplayGroup($financingGroup, 'financing_group');
        $this->getDisplayGroup('financing_group')
            ->setLegend('Financing')
            ->clearDecorators()
            ->addDecorator('FormElements')
            ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper'));
    }

    private function programBenefitsSection($mArrBundleAppData, $isNew)
    {
        $validatorsPointText = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 60)));

        $this->addElement('text', 'app_program_benefit_1', array(
            'label' => 'Point - 1*',
            'required' => true,
            'filters' => array('StringTrim'),
            'value' => !empty($mArrBundleAppData['app_program_benefits']['benefit_1']) ? $mArrBundleAppData['app_program_benefits']['benefit_1'] : $this->prefillField('app_program_benefit_1', $isNew),
            'class' => 'longtext',
            'validators' => $validatorsPointText
        ));

        $this->addElement('text', 'app_program_benefit_2', array(
            'label' => 'Point - 2*',
            'required' => true,
            'filters' => array('StringTrim'),
            'value' => !empty($mArrBundleAppData['app_program_benefits']['benefit_2']) ? $mArrBundleAppData['app_program_benefits']['benefit_2'] : $this->prefillField('app_program_benefit_2', $isNew),
            'class' => 'longtext',
            'validators' => $validatorsPointText
        ));

        $this->addElement('text', 'app_program_benefit_3', array(
            'label' => 'Point - 3*',
            'required' => true,
            'filters' => array('StringTrim'),
            'value' => !empty($mArrBundleAppData['app_program_benefits']['benefit_3']) ? $mArrBundleAppData['app_program_benefits']['benefit_3'] : $this->prefillField('app_program_benefit_3', $isNew),
            'class' => 'longtext',
            'validators' => $validatorsPointText
        ));

        $this->addElement('text', 'app_program_benefit_4', array(
            'label' => 'Point - 4*',
            'required' => true,
            'filters' => array('StringTrim'),
            'value' => !empty($mArrBundleAppData['app_program_benefits']['benefit_4']) ? $mArrBundleAppData['app_program_benefits']['benefit_4'] : $this->prefillField('app_program_benefit_4', $isNew),
            'class' => 'longtext',
            'validators' => $validatorsPointText
        ));

        $this->addElement('text', 'app_program_benefit_5', array(
            'label' => 'Point - 5*',
            'required' => true,
            'filters' => array('StringTrim'),
            'value' => !empty($mArrBundleAppData['app_program_benefits']['benefit_5']) ? $mArrBundleAppData['app_program_benefits']['benefit_5'] : $this->prefillField('app_program_benefit_5', $isNew),
            'class' => 'longtext',
            'validators' => $validatorsPointText
        ));

        $programBenefitsGroup = array('app_program_benefit_1', 'app_program_benefit_2', 'app_program_benefit_3', 'app_program_benefit_4', 'app_program_benefit_5');
        $this->addDisplayGroup($programBenefitsGroup, 'program_benefits_group');
        $this->getDisplayGroup('program_benefits_group')
            ->setLegend('Program Benefits')
            ->clearDecorators()
            ->addDecorator('FormElements')
            ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper'));
    }

    protected function getSubFormDecoratorsMain($className, $id)
    {
        return array(
            'FormElements',
            array(
                'HtmlTag', array('tag' => 'ul')
            ),
            array(
                array('row' => 'HtmlTag'),
                array('tag' => 'li', 'class' => $className, 'id' => $id)
            )
        );
    }

    public function isAdmissionSectionValid($data)
    {
        $status = true;

        if (!empty($data['app_financing_intro'])) {
            if (strpos($data['app_financing_intro'], $this::FINANCING_REPLACE_TEXT)  === FALSE) {
                $this->getElement('app_financing_intro')->setErrors(array("Financing Intro should contain " . $this::FINANCING_REPLACE_TEXT . " for fee to be added"));
                $status = false;
            }
        }

        $validEligibilityValues = [1, 2, 3];
        $invalidEligibilityOrderError = 'Value should be one of 1, 2, 3';

        if (!empty($data['app_eligibility_work_exp_order'])) {
            if (!in_array($data['app_eligibility_work_exp_order'], $validEligibilityValues)) {
                $this->getElement('app_eligibility_work_exp_order')->setErrors(array($invalidEligibilityOrderError));
                $status = false;
            } else if (
                $data['app_eligibility_work_exp_order'] == $data['app_eligibility_degree_order']
                || $data['app_eligibility_work_exp_order'] == $data['app_eligibility_basic_order']
            ) {
                $this->getElement('app_eligibility_work_exp_order')->setErrors(array('Value should not be equal to degree and/or basic concept order'));
                $status = false;
            }
        }


        if (!empty($data['app_eligibility_degree_order'])) {
            if (!in_array($data['app_eligibility_degree_order'], $validEligibilityValues)) {
                $this->getElement('app_eligibility_degree_order')->setErrors(array($invalidEligibilityOrderError));
                $status = false;
            } else if (
                $data['app_eligibility_degree_order'] == $data['app_eligibility_work_exp_order']
                || $data['app_eligibility_degree_order'] == $data['app_eligibility_basic_order']
            ) {
                $this->getElement('app_eligibility_degree_order')->setErrors(array('Value should not be equal to work experience and/or basic concept order'));
                $status = false;
            }
        }

        if (!empty($data['app_eligibility_basic_order'])) {
            if (!in_array($data['app_eligibility_basic_order'], $validEligibilityValues)) {
                $this->getElement('app_eligibility_basic_order')->setErrors(array($invalidEligibilityOrderError));
                $status = false;
            } else if (
                $data['app_eligibility_basic_order'] == $data['app_eligibility_degree_order']
                || $data['app_eligibility_basic_order'] == $data['app_eligibility_work_exp_order']
            ) {
                $this->getElement('app_eligibility_basic_order')->setErrors(array('Value should not be equal to work experience and/or degree order'));
                $status = false;
            }
        }

        return $status;
    }

    public function isValid($data)
    {
        $status = parent::isValid($data);
        // if (!$status)
        //     return false;

        $learnerStatus = $this->isLearnerSectionValid($data);
        $admissionStatus = $this->isAdmissionSectionValid($data);

        return ($status && $learnerStatus && $admissionStatus);
    }

    public function isLearnerSectionValid($data)
    {
        $status = true;
        $industryData = json_decode($data['app_industry_data'], true);
        if (!empty($industryData)) {
            $sum = array_sum(array_column($industryData, 'value'));
            if ($sum > 100 || $sum < 100) {
                $this->getElement('industry_name')->setErrors(array("Sum of Market Ratio should be 100"));
                $status = false;
            } else if (count($industryData) > 6) {
                $this->getElement('industry_name')->setErrors(array("Maximum 6 can be added"));
                $status = false;
            }
        }else{
            $this->getElement('industry_name')->setErrors(array("Industry Data is Mandatory"));
            $status = false;
        }

        $designationData = json_decode($data['app_we_designation_data'], true);
        if (!empty($designationData)) {
            $sum = array_sum(array_column($designationData, 'value'));
            if ($sum > 100 || $sum < 100) {
                $this->getElement('we_designation_name')->setErrors(array("Sum of Learner Breakup should be 100"));
                $status = false;
            }
        }

        $weData = json_decode($data['app_we_exp_data'], true);
        if (!empty($weData)) {
            $sum = array_sum(array_column($weData, 'value'));
            if ($sum > 100 || $sum < 100) {
                $this->getElement('we_years_name')->setErrors(array("Sum of Market Ratio should be 100"));
                $status = false;
            }
        }

        $edIndustryData = json_decode($data['app_ed_industry_data'], true);
        if (!empty($edIndustryData)) {
            $sum = array_sum(array_column($edIndustryData, 'value'));
            if ($sum > 100 || $sum < 100) {
                $this->getElement('ed_industry_name')->setErrors(array("Sum of Market Ratio should be 100"));
                $status = false;
            }
        }
        
        if(empty($data['app_hiring_companies_id'])){
            // prd($data['app_hiring_companies_id']);
            $this->getElement('app_hiring_companies_id')->setErrors(array("Value is required and can't be empty"));
            $status = false;
        }else if(isset($data['app_hiring_companies']) && count(explode(',',$data['app_hiring_companies_id'])) > 12 ){
            $this->getElement('app_hiring_companies_id')->setErrors(array("Maximum 12 can be selected"));
            $status = false;
        }
        return $status;
    }

    private function _getHiringCompaniesForSelect()
    {
        $obj = new Model_ProductSectionData();
        $cond = array(
            'sectionType = ?' => BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_HIRING_COMPANIES,
            'long_description like ?' => '%' . BaseApp_Dao_ProductTypes::DESCRIPTION_UNIVERSITY_INDUSTRY_SECTION . '%',
            'status = ?' => 1
        );
        $hiringCompanies = $obj->fetchAll($cond);
        $returnSelectArray = array();
        if (!empty($hiringCompanies)) {
            foreach ($hiringCompanies as $company) {
                $returnSelectArray[$company['id']] = $company['name'] . ' - ' . $company['id'];
            }
        }
        return $returnSelectArray;
    }
}
