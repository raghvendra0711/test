<?php

class Form_Addons extends BaseApp_Form
{

    public function init(){

        $this->setName('Addons');
        $this->setMethod('post');
         //adding Label name element

        $this->addElement('text','addonNo',array(
            'label'=>'Add On Number',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

         $this->addElement('submit','Add Addon',array(
          'ignore'=>true,
          'label'=>'Add Addon'
         ));
    }
}