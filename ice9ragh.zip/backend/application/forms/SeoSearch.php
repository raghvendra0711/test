<?php

class Form_SeoSearch extends BaseApp_Form {

    public function init() {
        $this->addElement('text', 'url', array(
            'label' => 'URL'
        ));
        $this->addElement('submit', 'search', array(
            'label' => 'Search'
        ));
    }
    
    public function isValid($data) {        
        $return = parent::isValid($data);
        if($data['url']) {
            if(preg_match("/([^a-z0-9\-\/]+)/", $data['url'])) {
                $this->getElement('url')->setErrors(array("'{$data['url']}' is not a valid group url"));
                $return = false;
            }    
            if(preg_match("/^(http|https|www)/", $data['url'])) {
                $this->getElement('url')->setErrors(array("'{$data['url']}' is not a valid group url"));
                $return = false;
            }    
            if(preg_match("/\/\//", $data['url'])) {
                $this->getElement('url')->setErrors(array("'{$data['url']}' is not a valid group url"));
                $return = false;
            }    
        }        
        return $return;
    }
}
