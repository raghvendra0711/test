<?php

class Form_Workshop extends BaseApp_Form
{
    private $_countryId = false;
    private $_cityId = false;

    private $_trainingType = false;


    public function __construct($countryId=false, $cityId=false, $trainingType=false) {
        $this->_countryId = $countryId;
        $this->_cityId = $cityId;
        $this->_trainingType = $trainingType;
        if($this->_countryId || $this->_cityId) {
            $this->edit();
        }else{
            $this->init();
        }
        $this->setElementDecorators($this->getElementDecorators());
        $this->setupFormDecorators();
    }

    public function init(){
        $this->setName('workshop');
        $this->setMethod('post');
        $traingTypes = new Model_TrainingTypes();
        $objPricing = new Model_Pricings();
        $trainingData = $traingTypes->fetchForSelect(array('type =?'=> 'ilt', 'training_id != ?' => BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS));
        $trainingIds = array_keys($trainingData);
        $trainingIds[] = BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS;
        $courseIds = $objPricing->getCourseIds($trainingIds,'workshop');
        if(empty($courseIds)){
            echo "No Record Found in Pricing Tables";
            return false;
        }
        $course = new Model_Courses();
        $this->addElement('select','course_id',array(
            'label'=>'Course',
            'required'=>true,
            'multioptions'=>array('0'=>'--Select--') + $course->fetchForSelect(array('is_dummy = ?' => 0, 'is_free = ?' => 0, 'course_id in (?)' => $courseIds))
        ));

        $this->addElement('select','training_id',array(
            'label'=>'Training Type',
            'required'=>true,
            'multioptions'=>array('0'=>'--Select--') +$trainingData
        ));

        $objAccessDays = new Model_AccessDays();
        $this->addElement('select','access_day_id',array(
            'label'=>'No Of Days',
            'required'=>true,
            'multioptions'=>array('0'=>'--Select--') + $objAccessDays->getAccessDaysById('ilt')
        ));

        $this->addElement('radio','isCorporate',array(
            'required' => true,
            'class' =>'is_b2b_workshop',
            'label'=>'Is B2B Workshop ?',
            'multiOptions'=>array(0 => 'No', 1 => 'Yes'),
            'separator'=>'',
            'registerInArrayValidator' => false,
            'value' => 0
        ));

        $this->addElement('text','webx_user_id',array(
            'label'=>'Webx User Id',
            'required'=>false,
            'registerInArrayValidator' => false,
            'fetchDisabled' => 'true'
        ));

        $this->addElement('text','webx_session_id',array(
            'label'=>'Webx Session Id',
            'required'=>false,
            'registerInArrayValidator' => false,
            'fetchDisabled' => 'true'
        ));

        $this->addElement('radio','webx_version_id',array(
            'required' => false,
            'class' =>'webx_version_id',
            'label'=>'Webex Version',
            'multiOptions'=>array(1 => 'Current Version', 2 => 'New Version'),
            'registerInArrayValidator' => false,
            'value' => 2
        ));


        $this->addElement('text','CorporateName',array(
            'label'=>'B2B Corporate Name',
            'required'=>false,
            'registerInArrayValidator' => false,
            'fetchDisabled' => 'true',
            'validators' => array(
                new Zend_Validate_StringLength(array('max' => 256))
            )
        ));

        $obj =new Model_Country();
        $countryData = array();
        foreach($obj->fetchAll(array(), array('columns'=>array('id' =>'country_id', 'name'), 'order' => array('orderNo DESC'))) as $countrySingle) {
            $countryData[$countrySingle['id']] = $countrySingle['name'];
        }
        $this->addElement('select','countries',array(
            'required'=>false,
            'multiple' => true,
            'class' => 'multiple',
            'label' => 'Countries Consider',
            'registerInArrayValidator' => false,
            'multioptions'=> $countryData,
            'disable' => array(1)
        ));

        if($this->country_id) {
            $this->addElement('select','country_id',array(
                'label'=>'Country',
                'required'=>false,
                'multioptions'=>array('0'=>'--Select--') + $countryData,
                'value' => $this->country_id,
                'disabled' => true,
                'disable' => array(1)
            ));
        }
        else {
            $this->addElement('select','country_id',array(
                'label'=>'Country',
                'required'=>false,
                'multioptions'=>array('0'=>'--Select--') + $countryData,
                'disable' => array(1)
            ));
        }

        if($this->country_id && $this->city_id) {
            $city = new Model_City;
            $this->addElement('select','city_id',array(
                'label'=>'City',
                'required'=>false,
                'multioptions' => $city->fetchForSelect(array('country_id=?'=>$this->country_id)),
                'value' => $this->city_id,
                'disabled' => true
            ));
        }else {
            $this->addElement('select','city_id',array(
                'label'=>'City',
                'required'=>false,
                'registerInArrayValidator' => false,
                'fetchDisabled' => 'true'
            ));
        }

        $this->addElement('select','venue_id',array(
            'label'=>'Vennue',
            'required'=>false,
            'registerInArrayValidator' => false,
            'fetchDisabled' => 'true'
        ));

        $trainer =new Model_Trainers();
        $this->addElement('select','trainer_id',array(
            'label'=>'Trainer',
            'required'=>false,
            'registerInArrayValidator' => false,
            'multioptions' => array('0'=>'--Select--') + $trainer->fetchForSelect()
        ));

        $this->addElement('text', 'dates', array(
            'class' => 'multidatepicker',
            'label' => 'Select Dates',
            'required' => true,
            'maxlength' => 0
        ));

        $this->addElement('text','fromTime',array(
            'label'=>'Time From',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'readonly' => 'readonly',
            'class'=>'timepicker'
        ));

        $this->addElement('text','toTime',array(
            'label'=>'Time To',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'readonly' => 'readonly',
            'class'=>'timepicker'
        ));

        $obj = new Model_Country();
        $this->addElement('select','timeZone',array(
            'label'=>'Time Zone',
            'required'=>false,
            'multioptions' => array('0'=>'--Select--')+$obj->getAllTimezones()
        ));

        $this->addElement('text','maxHeadCount',array(
            'label'=>'Max Head Count',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('text','minHeadCount',array(
            'label'=>'Min Head Count',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $workshop =new Model_Workshop();
        $this->addElement('select','workshopStatus',array(
            'label'=>'Workshop Status',
            'required'=>false,
            'multioptions'=>array('0'=>'--Select--') + $workshop->getStatus()
        ));

        $this->addElement('submit','Create New Workshop',array(
            'ignore'=>true,
            'label'=>'Create New Workshop',
            'class'=>'btn btn-info'
        ));

    }


    public function edit(){
        $this->setName('workshop');
        $this->setMethod('post');
        $traingTypes = new Model_TrainingTypes();
        $objPricing = new Model_Pricings();
        $trainingData = $traingTypes->fetchForSelect(array('type =?'=> 'ilt'));
        $trainingIds = array_keys($trainingData);
        $courseIds = $objPricing->getCourseIds($trainingIds,'workshop');
        if(empty($courseIds)){
            echo "No Record Found in Pricing Tables";
            return false;
        }
        $course = new Model_Courses();
        $this->addElement('select','course_id',array(
            'label'=>'Course',
            'required'=>false,
            'multioptions'=>array('0'=>'--Select--') + $course->fetchForSelect(array('is_dummy = ?' => 0, 'is_free = ?' => 0, 'course_id in (?)' => $courseIds))
        ));

        $this->addElement('select','training_id',array(
            'label'=>'Training Type',
            'required'=>false,
            'multioptions'=>array('0'=>'--Select--') +$trainingData
        ));

        $objAccessDays = new Model_AccessDays();
        $this->addElement('select','access_day_id',array(
            'label'=>'No Of Days',
            'required'=>false,
            'multioptions'=>array('0'=>'--Select--') + $objAccessDays->getAccessDaysById('ilt')
        ));
        $this->addElement('radio','isCorporate',array(
            'required' => false,
            'label'=>'Is B2B Workshop ?',
            'multiOptions'=>array(0 => 'No', 1 => 'Yes'),
            'separator'=>'',
            'registerInArrayValidator' => false,
            'value' => $this->_isCorporate,
            'disabled' => true
        ));

        $this->addElement('text','CorporateName',array(
            'label'=>'B2B Corporate Name',
            'required'=>false,
            'registerInArrayValidator' => false,
            'fetchDisabled' => 'true',
            'value' => $this->_CorporateName,
            'disabled' => true
        ));

        if($this->_trainingType == BaseApp_Dao_TrainingTypes::TYPE_LVC && !$this->_isCorporate) {

            $this->addElement('text','webx_user_id',array(
                'label'=>'Webx User Id',
                'required'=>false,
                'registerInArrayValidator' => false,
                'value' => $this->webx_user_id,
                'fetchDisabled' => 'true'
            ));

            $this->addElement('text','webx_session_id',array(
                'label'=>'Webx Session Id',
                'required'=>false,
                'registerInArrayValidator' => false,
                'value' => $this->webx_session_id,
                'fetchDisabled' => 'true'
            ));

            $this->addElement('radio','webx_version_id',array(
                'required' => false,
                'class' =>'webx_version_id',
                'label'=>'Webex Version',
                'multiOptions'=>array(1 => 'Current Version', 2 => 'New Version'),
                'fetchDisabled' => 'true',
                'registerInArrayValidator' => false,
                'value' => $this->webex_version
            ));
        }


        $obj =new Model_Country();
        $countryData = array();
        foreach($obj->fetchAll(array(), array('columns'=>array('id' =>'country_id', 'name'), 'order' => array('orderNo DESC'))) as $countrySingle) {
            $countryData[$countrySingle['id']] = $countrySingle['name'];
        }
        if($this->_trainingType == BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM) {
            $this->addElement('select','country_id',array(
                'label'=>'Country',
                'required'=>false,
                'multioptions'=>array('0'=>'--Select--') + $countryData,
                'value' => $this->_countryId,
                'disabled' => true
            ));
            if($this->_cityId) {
                $city = new Model_City;
                $this->addElement('select','city_id',array(
                    'label'=>'City',
                    'required'=>false,
                    'multioptions' => $city->fetchForSelect(array('country_id=?'=>$this->_countryId)),
                    'value' => $this->_cityId,
                    'disabled' => true
                ));
            }else {
                $this->addElement('select','city_id',array(
                    'label'=>'City',
                    'required'=>false,
                    'style' => 'display: none;',
                    'registerInArrayValidator' => false,
                    'fetchDisabled' => 'true'
                ));
            }
            $venues =new Model_Venues();
            $venueData = $venues->fetchForSelect(array('country_id=?'=>$this->_countryId,'city_id =?'=>$this->_cityId));
            $this->addElement('select','ven_id',array(
                'label'=>'Vennue',
                'required'=>false,
                'registerInArrayValidator' => false,
                'multioptions' => $venueData,
                'value' => $this->_venue_id,
                'fetchDisabled' => 'true'
            ));
        }else if($this->_trainingType == BaseApp_Dao_TrainingTypes::TYPE_LVC) {
            $this->addElement('select','countries',array(
                'required'=>false,
                'multiple' => true,
                'class' => 'multiple',
                'label' => 'Countries Consider',
                'registerInArrayValidator' => false,
                'multioptions'=> $countryData,
                'disable' => array(1)
            ));
        }
        $trainer =new Model_Trainers();
        $this->addElement('select','trainer_id',array(
            'label'=>'Trainer',
            'required'=>false,
            'registerInArrayValidator' => false,
            'multioptions' => array('0'=>'--Select--') + $trainer->fetchForSelect()
        ));

        $this->addElement('text', 'dates_edit', array(
            'label' => 'Select Dates',
            'class' => 'multidatepicker',
            'required' => false,
            'maxlength' => 0
        ));

        $this->addElement('text','fromTime',array(
            'label'=>'Time From',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'readonly' => 'readonly',
            'class'=>'timepicker'
        ));

        $this->addElement('text','toTime',array(
            'label'=>'Time To',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'readonly' => 'readonly',
            'class'=>'timepicker'
        ));

        if($this->_trainingType == 3) {
            $obj = new Model_Country();
            $this->addElement('select','timeZone',array(
                'label'=>'Time Zone',
                'required'=>true,
                'multioptions' => array('0'=>'--Select--')+$obj->getAllTimezones()
            ));
        }

        $this->addElement('text','maxHeadCount',array(
            'label'=>'Max Head Count',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('text','minHeadCount',array(
            'label'=>'Min Head Count',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $workshop =new Model_Workshop();
        $this->addElement('select','workshopStatus',array(
            'label'=>'Workshop Status',
            'required'=>false,
            'multioptions'=>array('0'=>'--Select--') + $workshop->getStatus()
        ));

        $this->addElement('submit','Save',array(
            'ignore'=>true,
            'label'=>'Save',
            'class'=>'btn btn-info'
        ));
    }

    public function removeUneditableElements($training_id=0){

        $this->getElement('course_id')->setAttrib('disabled', 'disabled');
        $this->getElement('course_id')->setRequired(false);
        $this->getElement('training_id')->setAttrib('disabled', 'disabled');
        $this->getElement('training_id')->setRequired(false);
        if(!empty($training_id) && $training_id == BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM){
            $this->getElement('access_day_id')->setAttrib('disabled', 'disabled');
            $this->getElement('access_day_id')->setRequired(false);
        }
        $this->getElement('isCorporate')->setRequired(false);
    }

    public function removeOptionalElements() {
        $this->removeElement('course_id');
        $this->removeElement('training_id');
        $this->removeElement('access_day_id');
        $this->removeElement('isCorporate');
    }

    protected function getElementDecorators(){
        $elementDecorators = array('ViewHelper',array(
                                                    array('data' => 'HtmlTag'),
                                                    array('tag' =>'div', 'class'=> 'element')
                                                ),
                                                'Errors',
                                                array(
                                                    'Label',
                                                     array('tag' => 'div')
                                                ),
                                                array(
                                                    array('row' => 'HtmlTag'),
                                                    array('tag' => 'li')
                                                )
                                );

        return $elementDecorators;
    }

    protected function setupFormDecorators(){
        $this->setDecorators(array('FormElements',
                                    array('HtmlTag', array('tag' => 'ul'/*, 'data-role' => 'listview', 'role' => 'list'*/)),
                                    'Form'
                                  )
                            );
    }

    public function isValid($data) {
        $objAccessDays = new Model_AccessDays();
        $accDays = $objAccessDays->getAccessDaysById('ilt');
        $status = parent::isValid($data);
        $dates = !empty($data['dates_edit']) ? explode(',',$data['dates_edit']):array();
        if(!empty($data['access_day_id']) && !empty($accDays[$data['access_day_id']]) && (count($dates) > $accDays[$data['access_day_id']])) {
            $this->getElement('access_day_id')->setErrors(array("Number of days selected from datepicker cannot be more than access days"));
                $status = false;
        }
        if (isset($data['city_id']) && empty($data['city_id'])) {
            $this->getElement('city_id')->setErrors(array("city is required"));
            $status = false;
        }
        if(!empty($data['training_id']) && !$data['isCorporate'] && $data['training_id'] == BaseApp_Dao_TrainingTypes::TYPE_LVC) {
            if(!isset($data['webx_user_id']) || !$data['webx_user_id']) {
                $this->getElement('webx_user_id')->setErrors(array("This value required"));
                $status = false;
            }

            if(!isset($data['webx_session_id']) || !$data['webx_session_id'] || !$data['webx_version_id'] ) {
                $this->getElement('webx_session_id')->setErrors(array("This value required"));
                $status = false;
            }
        }
        return $status;
    }
}

