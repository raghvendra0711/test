<?php

class Form_MobileAppCategory extends BaseApp_Form
{
    const TYPE_COURSE='course';
    const TYPE_ARTICLE='article';
    const TYPE_EBOOK='ebook';
    const TYPE_WEBINAR='webinar';
    
    protected $productTypes = array();
    
    public function __construct($data) {
         $this->init($data);
    }

    public function init($data)
    {
        $this->setName('Mobile App');
        $this->setMethod('post');
        $this->loadDefaultDecorators();
        $this->productTypes =   array(
            self::TYPE_COURSE => 'Course', self::TYPE_ARTICLE => 'Article', self::TYPE_EBOOK => 'Ebook', self::TYPE_WEBINAR => 'Webinar'
        );
        $widgetInfo = !empty($data['info']) ? $data['info'] : array();
        $widget_type = !empty($data['widget_type']) ? $data['widget_type'] : '';
        $data = !empty($data['data']) ? $data['data'] : array();
        $this->addElement('text','widget_type',array(
            'label'=>'Widget Type*',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'attribs' => array('readonly' => 'readonly'),
            'autocomplete' => 'off',
            'value'     => $widget_type
        ));

        $this->addElement('text','name',array(
            'label'=>'Name of the Widget',
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'required' => true,
            'value'=>!empty($widgetInfo['title']) ? $widgetInfo['title'] : ''
        ));
        $this->getElement('name')->setDescription('Character limit is 30 for name');
        $this->addElement('text','limit',array(
            'label'=>'Limit *',
            'filters'=>array('StringTrim'),
            'class'=>'number',
            'required' => true,
            'value'=>!empty($widgetInfo['limit']) ? $widgetInfo['limit'] : ''
        ));
        $obj = new Model_Labels();
        $this->addElement('select', 'category_id_temp', array(
            'label' => 'Category Section',
            'required' => false,
            'size' => 12,
            // 'multiple' => true,
            'class' => 'multiple',
            'registerInArrayValidator' => false,
            'multioptions' => $obj->getPrimaryLableData()
        ));

        $categories = !empty($data['content_ids_sorted_list']) ? $data['content_ids_sorted_list'] : '';
        $this->addElement('hidden', 'category_ids', array('required' => false, 'value' => $categories));
        $catGroup = array('category_id_temp');
        $this->addDisplayGroup($catGroup, 'cat_group');
        $this->getDisplayGroup('cat_group')
            ->clearDecorators()
            ->addDecorator('FormElements')
            ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper'));

        $validatorsName = array(new Zend_Validate_StringLength(array('max' => 30)));
        $this->getElement('name')->addValidators($validatorsName);
        
        $this->addElement('submit', 'Add Mobile App', array(
            'ignore' => true,
            'label' => 'Save',
            'class' => 'btn btn-info'
        ));
    }
    public function removeUneditableElements(){
        $this->getElement('name')->setAttrib('disabled', 'disabled');
        $this->getElement('name')->setRequired(false);
    }

    public function isValid($data)
    {
        $status = parent::isValid($data);
        if (!$status) {
            return false;
        }
        $sequenceObj         = new Model_WidgetSequence();
        $title = !empty($data['name']) ? $data['name'] : '';
        $widgetData = $sequenceObj->getSectionContentByTitle($title);
        if (empty($data['limit'])) {
            $this->getElement('limit')->setErrors(array("limit should be greater than zero"));
            return false;
        } else {
            if (!preg_match('/^\d+$/', $data['limit'])) {
                $this->getElement('limit')->setErrors(array("limit should be number "));
                return false;
            }
        }
        if (!empty($widgetData)&&empty($data['widget_id'])) {
            $this->getElement('name')->setErrors(array("duplicate widget title"));
            return false;
        }        
        if (empty($data['category_ids'])) {
            $this->getElement('category_id_temp')->setErrors(array("select atleast one category"));
            return false;
        }
        return $status;
    }
}