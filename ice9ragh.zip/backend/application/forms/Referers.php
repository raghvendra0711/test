<?php

class Form_Referers extends BaseApp_Form
{

    public function init(){
        
    }
}