<?php

class Form_GenericFaq extends BaseApp_SubForm {

    private $_addMoreButton = true;

    public function __construct($addMoreButton = true) {
        $this->_addMoreButton = $addMoreButton;
        parent::__construct();
    }

    public function init() {
        $this->setName('ExamCertification');
        $this->setMethod('post');
        //adding Label name element

        $session = new Zend_Session_Namespace('form');

        $subForm = new Zend_Form_SubForm();
        $subForm->setName('genericCourseFaq');
        foreach ($session->genericCourseFaq as $product) {
            $faqId = isset($session->genericCourseFaqData[$product]['faq_id']) ? $session->genericCourseFaqData[$product]['faq_id'] : '';
            $keyQuestion = isset($session->genericCourseFaqData[$product]['question']) ? $session->genericCourseFaqData[$product]['question'] : '';
            $keyAnswer = isset($session->genericCourseFaqData[$product]['answer']) ? $session->genericCourseFaqData[$product]['answer'] : '';
            $keyJumpTo = isset($session->genericCourseFaqData[$product]['jump_to_section']) ? $session->genericCourseFaqData[$product]['jump_to_section'] : '';
            $keyCountryIds = isset($session->genericCourseFaqData[$product]['countryIds']) ? $session->genericCourseFaqData[$product]['countryIds'] : array();
            $keyClusterIds = isset($session->genericCourseFaqData[$product]['clusterIds']) ? $session->genericCourseFaqData[$product]['clusterIds'] : array();

            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);

            $classfck = 'fck-enable';
            if ($product === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
                $classfck = '';
            }

            $resourceIdDom = new Zend_Form_Element_Hidden('course_faq_id');
            $resourceIdDom->addFilter('stringTrim')->setValue($faqId)->clearDecorators();

            //Country
            $country = new Zend_Form_Element_Select('country_id');
            $countryModel = new Model_Country();
            $keyCountry = !empty($keyCountryIds) ? explode(',', $keyCountryIds) : array();
            $country->setOptions(array('required' => false, 'multiple' => true, 'multioptions' => $countryModel->getListDisplay()))
                    ->setValue($keyCountry)->setAttrib('class', 'courseListAll countryListAll skipPreviousClick')
                    ->setLabel('Country')
                    ->setRegisterInArrayValidator(false);
            //Cluster
            $cluster = new Zend_Form_Element_Select('cluster_id');
            $clusterModel = new Model_Clusters();
            $keyCluster = !empty($keyClusterIds) ? explode(',', $keyClusterIds) : array();
            $cluster->setOptions(array('required' => false, 'multiple' => true, 'multioptions' => $clusterModel->fetchForSelect()))
                    ->setValue($keyCluster)->setAttrib('class', 'multiple clusterListAll')
                    ->setLabel('Cluster')
                    ->setAttrib('onchange', 'countryByClusterSelect(this)')
                    ->setAttrib('data-last-selected',$keyClusterIds)
                    ->setRegisterInArrayValidator(false);
            //Check All Countries
            $allCountryChecked = 0;
            $isClusterCountryDisabled = false;
            if (empty($keyCluster) && empty($keyCountry)) {
                $allCountryChecked = 1;
                $isClusterCountryDisabled = true;
            }
            $checkAllCountry = new Zend_Form_Element_Checkbox('all_country');
            $checkAllCountry->setValue($allCountryChecked)->setLabel('All Countries')->setAttrib('onclick', 'checkAllCountry(this)');

            if ($isClusterCountryDisabled) {
                $cluster->setOptions(array('disabled' => true));
                $country->setOptions(array('disabled' => true));
            }


            $question = new Zend_Form_Element_Text('question');
            $question->addFilter('stringTrim')->setValue($keyQuestion)->setAttrib('class', 'longtext')->setLabel('Question');

            $answer = new Zend_Form_Element_Textarea('answer');
            $answer->addFilter('stringTrim')->setValue($keyAnswer)->setAttrib('class', $classfck)->setAttrib('rows', 5)->setAttrib('cols', 60)->setLabel('Answer');

            $jumpTo = new Zend_Form_Element_Checkbox('jump_to_section');
            $jumpTo->setValue($keyJumpTo)->setLabel('Add as JumpTo Section');

            $removeFaq = new Zend_Form_Element_Button('remove');
            $removeFaq->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');

            //Invert Selection
            $invertBtn = new Zend_Form_Element_Button('invert');
            $invertBtn->setLabel('Invert Countries')->setAttrib('class', 'btn btn-warning remove invert-all')->setAttrib('onclick', 'invertSelection(this)');
            if($allCountryChecked){
                $invertBtn->setOptions(array('disabled' => true));
            }
            $elements = array($checkAllCountry, $cluster, $country, $invertBtn, $question, $answer, $jumpTo, $resourceIdDom);
            if ($product !== 'new') {
                $elements[] = $removeFaq;
            }

            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());

            if ($rowForm->getElement('remove')) {
                $rowForm->getElement('remove')->removeDecorator('Label');
            }

            if ($rowForm->getElement('invert')) {
                $rowForm->getElement('invert')->removeDecorator('Label');
            }
            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        }

        $subForm->setDecorators($this->getSubFormDecoratorsMain('course-faq-editor', 'genericCourseFaq'));
        if ($this->_addMoreButton) {
            $addFaq = new Zend_Form_Element_Button('add');
            $addFaq->setLabel('Add More')->setAttrib('class', 'btn btn-warning add');
            $subForm->addElement($addFaq);
            $subForm->setElementDecorators($this->getElementDecorators());
            $subForm->getElement('add')->removeDecorator('Label');
        }
        $this->addSubForm($subForm, 'genericCourseFaq');
        $this->addElement('submit', 'Save', array(
            'ignore' => true,
            'label' => 'Save'
        ));
        $this->addElement('button', 'Cancel', array(
            'label' => 'Cancel',
            'ignore' => true,
            'id' => 'cancel_form',
            'class' => 'btn btn-warning'
        ));
    }

    protected function getSubFormDecoratorsMain($className, $id) {
        return array(
            'FormElements',
            array(
                'HtmlTag', array('tag' => 'ul')
            ),
            array(
                array('row' => 'HtmlTag'),
                array('tag' => 'li', 'class' => $className, 'id' => $id)
            )
        );
    }

    public function removeUneditableElements() {
        return false;
    }

}
