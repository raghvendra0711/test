<?php

class Form_BundleMoreDetail extends BaseApp_SubForm
{
    public function __construct($bundleId= false) {
        $this->init($bundleId);
        $this->loadDefaultDecorators();
    }
    public function init($bundleId)
    {
        $this->setName('BundleMoreDetail');
        $this->setMethod('post');

        $session = new Zend_Session_Namespace('form');

        $this->setAttrib("class","form-width");
        
        $objBundle = new Model_Bundles();
        $bundleData = $objBundle->getBundleById($bundleId);        
        $bundleType = !empty($bundleData['master_type']) ? $bundleData['master_type'] : '';

        /**
         * program adavantage section
         */
        $this->skillSets($session);
        $this->programAdvantageSection();
        $this->projectSection();
        if($bundleType == BaseApp_Dao_Bundles::MASTER_TYPE_COHORT){
            $this->idealCandidateSection();
        }
        $this->addElement('submit', 'Save', array(
            'ignore' => true,
            'label' => 'Save',
            'class' => 'btn btn-info'
        ));
    }

    private function skillSets($session){
        // prd($session);
        $validatorsSkillsCovered = array(new Zend_Validate_StringLength(array('min'=>1,'max' => 37)),new Zend_Validate_NotEmpty());       
        //$validatorsSkillsCovered = [new Zend_Validate_NotEmpty()];
        $subForm = new Zend_Form_SubForm();
        $subForm->setName('skills');
        $i=0;        
        if(count($session->skills) == 2){
            $session->skills[2] = '2';
        }           
        foreach ($session->skills as $product) {            
            $keyName = isset($session->skillsData[$product]['name']) ? $session->skillsData[$product]['name'] : '';
            $sectionId = isset($session->skillsData[$product]['section_id']) ? $session->skillsData[$product]['section_id'] : '';
             $skillLabel = 'Skills Covered';
            if($i!=0){
            $skillLabel = 'Skills Covered '.$i;
            }              
            $resourceIdDom = new Zend_Form_Element_Hidden('sectionId');
            $resourceIdDom->addFilter('stringTrim')->setValue($sectionId)->clearDecorators();
            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);
            if ($product === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
            }
            $name = new Zend_Form_Element_Text('name');
            if ($product != '__template__') {
                $name->setAttrib('required','required');
            }
            
            $name->addFilter('stringTrim')->setValue($keyName)->setAttrib('class', 'keyName longtext')->setLabel($skillLabel)->addValidators($validatorsSkillsCovered);
            $i++;
            $removeKeyFeatures = new Zend_Form_Element_Button('remove');
            $removeKeyFeatures->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');

            if ($product !== 'new') {
                $elements = array($name,$resourceIdDom ,$removeKeyFeatures);
            } else {
                $elements = array($name,$resourceIdDom);
            }

            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());

            if ($rowForm->getElement('remove')) {
                $rowForm->getElement('remove')->removeDecorator('Label');
            }

            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        }       
        $subForm->setDecorators($this->getSubFormDecoratorsMain('skills', 'skills'));
        $addPrice = new Zend_Form_Element_Button('add');
        $addPrice->setLabel('Add More Skills')->setAttrib('class', 'btn btn-warning add');
        $subForm->addElement($addPrice);

        $subForm->setElementDecorators($this->getElementDecorators());
        $subForm->getElement('add')->removeDecorator('Label');
        $this->addSubForm($subForm, 'skills');
    }
    private function programAdvantageSection()
    {
        $this->addElement('textarea', 'Intro', array(
            'label' => 'Intro',
            'required' => false,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'autocomplete' => 'off'
        ));
        $this->addElement('hidden', 'introSectionId', array(
            'required' => false,
            'value' => ''
        ));
        $programAdvantage = array('Intro');
        $this->addDisplayGroup($programAdvantage, 'programAdvantage');
        $this->getDisplayGroup('programAdvantage')
            ->setLegend('Program Advantage')
            ->clearDecorators()
            ->addDecorator('FormElements')
            ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper'));
    }
    private function idealCandidateSection()
    {
        $validatorsTargetAud = array(new Zend_Validate_StringLength(array('min'=>1,'max' => 170)),new Zend_Validate_NotEmpty());    
        $validators120Text = array(new Zend_Validate_StringLength(array('min' => 1, 'max' => 120))); 
        $this->addElement('textarea','ideal_intro',array(
            'label' => 'Intro *',
            'require' => true,
            'filter' => array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class' => 'description',
            'validators' => $validators120Text

        ));

        $this->addElement('hidden', 'intro_id', array(
            'required' => false,
            'value' => ''
        ));

        $this->addElement('textarea', 'audience', array(
            'label' => 'Target Audience *',
            'required' => true,
            'filter' => array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class' => 'fck-enable',
            'validators' => $validatorsTargetAud,
        ));

        $this->addElement('hidden', 'audience_id', array(
            'required' => false,
            'value' => '' 
        ));

        $this->addElement('textarea', 'eligibility', array(
            'label' => 'Eligibility *',
            'required' => true,
            'filter' => array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'validators' => $validatorsTargetAud,
            'class' => 'fck-enable',
        ));

        $this->addElement('hidden', 'eligibility_id', array(
            'required' => false,
            'value' => '' 
        ));
        $idealCandidateSection = array('ideal_intro','audience','eligibility');
        $this->addDisplayGroup($idealCandidateSection, 'ideal_candidate');
        $this->getDisplayGroup('ideal_candidate')
            ->setLegend('Ideal Candidates')
            ->clearDecorators()
            ->addDecorator('FormElements')
            ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper'));

    }
     
    
    public function isValid($data){
        $status = parent::isValid($data);     
        if(isset($data['ideal_intro'])&& empty($data['ideal_intro'])){
            $this->getElement('ideal_intro')->setErrors(array("Value is required and can't be empty"));
            $status = false;
        }
           
        return $status;
    }

    protected function getSubFormDecoratorsMain($className, $id)
    {
        return array(
            'FormElements',
            array(
                'HtmlTag', array('tag' => 'ul')
            ),
            array(
                array('row' => 'HtmlTag'),
                array('tag' => 'li', 'class' => $className, 'id' => $id)
            )
        );
    }

    protected function getElementDecorators()
    {
        $elementDecorators = array(
            'ViewHelper', array(
                array('data' => 'HtmlTag'),
                array('tag' => 'div', 'class' => 'element')
            ),
            'Errors',
            array(
                'Label',
                array('tag' => 'div')
            ),
            array(
                array('row' => 'HtmlTag'),
                array('tag' => 'li')
            )
        );

        return $elementDecorators;
    }

    protected function getSubFormDecorators($className = 'subform')
    {
        return array(
            'FormElements',
            array('HtmlTag', array('tag' => 'ul'/*, 'data-role' => 'fieldset', 'role' => 'listitem'*/)),
            'Fieldset',
            array(
                array('row' => 'HtmlTag'),
                array('tag' => 'li', 'class' => $className)
            )
        );
    }

    /**
     * Get All companies
     * @return array
     */
    private function getProjectCompanies()
    {
        $modelProductSectionData = new Model_ProductSectionData();
        $projectList = $modelProductSectionData->fetchAll(array('sectionType = ?' => BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE_HIRING_COMPANIES, 'long_description LIKE ?' => '%projects%'));
        $returnArr = array();
        if (!empty($projectList)) {
            foreach ($projectList as $key => $value) {
                $returnArr[$value['id']] = $value['id'] . ' - ' . $value['name'];
            }
        }
        if (!empty($returnArr)) {
            $returnArr = array_unique($returnArr);
        }
        return $returnArr;
    }
    private function projectSection()
    {
        $validatorsProjectSectionTitle = array(new Zend_Validate_StringLength(array('max' => 23)));
        $validatorsProjectTitle = array(new Zend_Validate_StringLength(array('max' => 63)));
        $validatorsProjectContent = array(new Zend_Validate_StringLength(array('max' => 183)));
        $session = new Zend_Session_Namespace('form');

        $this->addElement('text', 'bundleProjectsDescription', array(
            'label' => 'Project Section Heading',
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'validators' => $validatorsProjectSectionTitle
        ));
        $this->addElement('hidden', 'projectTitleSectionId', array(
            'required' => false,
            'value' => ''
        ));

        $subForm = new Zend_Form_SubForm();
        $subForm->setName('projects');
        $i = 0;
        foreach ($session->projects as $product) {
            $projectName = isset($session->projectsData[$product]['name']) ? $session->projectsData[$product]['name'] : '';
            $content = isset($session->projectsData[$product]['content']) ? $session->projectsData[$product]['content'] : '';
            $companyIds = isset($session->projectsData[$product]['companyIds']) ? $session->projectsData[$product]['companyIds'] : '';
            $sectionId = isset($session->projectsData[$product]['sectionId']) ? $session->projectsData[$product]['sectionId'] : '';
            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);
            if ($product === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
            }
            $lableName = 'Project';
            if (!empty($i)) {
                $lableName = 'Project ' . $i;
            }
            $name = new Zend_Form_Element_Text('name');
            $name->addFilter('stringTrim')->setValue($projectName)->setAttrib('class', 'question longtext')->setAttrib('placeholder', '')->setLabel('Name of the Project')->addValidators($validatorsProjectTitle);
            $i++;
            $companyContent = new Zend_Form_Element_Textarea('content');
            $companyContent->addFilter('stringTrim')->setValue($content)->setAttrib('class', 'faqDescription longtext')->setAttrib('placeholder', 'Project Content')->setLabel('Project Content')->addValidators($validatorsProjectContent);
            $companies = new Zend_Form_Element_Select('companyIds');
            $companies->setOptions(array('multioptions' => array(0 => '--Select--') + $this->getProjectCompanies()))->setValue($companyIds)->setAttrib('class', 'companyIds')->setLabel('Select Company Logo');
            $resourceIdDom = new Zend_Form_Element_Hidden('sectionId');
            $resourceIdDom->addFilter('stringTrim')->setValue($sectionId)->clearDecorators();

            $removeSetsNumber = new Zend_Form_Element_Button('remove');
            $removeSetsNumber->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove pro-btn-remove')->setAttrib('onclick', 'removeSubFormElement(this)');
            if ($product !== 'new') {
                $elements = array($name, $companyContent, $companies, $resourceIdDom, $removeSetsNumber);
            } else {
                $elements = array($name, $companyContent, $companies, $resourceIdDom);
            }
            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());
            if ($rowForm->getElement('remove')) {
                $rowForm->getElement('remove')->removeDecorator('Label');
            }
            $rowForm->setDecorators($this->getSubFormDecorators());
            $rowForm->setLegend($lableName);
            $subForm->addSubForm($rowForm, $product);
        }
        $subForm->setDecorators($this->getSubFormDecoratorsMain('projects', 'projects'));
        $addPrice = new Zend_Form_Element_Button('add');
        $addPrice->setLabel('Add Projects')->setAttrib('class', 'btn btn-warning add last-btn');
        $subForm->addElement($addPrice);

        $subForm->setElementDecorators($this->getElementDecorators());
        $subForm->getElement('add')->removeDecorator('Label');
        $this->addSubForm($subForm, 'projects');
    }
}
