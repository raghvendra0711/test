<?php

class Form_Discounts extends BaseApp_Form
{

    public function init(){

        $this->setName('Discounts');
        $this->setMethod('post');
         //adding Label name element

         $this->addElement('text','name',array(
            'label'=>'Discount Name',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

         $course =new Model_Courses();
         $this->addElement('select','course_id',array(
            'label'=>'Course Id',
            'required'=>false,
            'multiple' => true,
            'registerInArrayValidator' => false,
            'multioptions'=>array('0'=>'--Select--') + $course->fetchForSelect(array('is_dummy = ?' => 0, 'is_free = ?' => 0))
        ));

        $workshop = new Model_Workshop();
        $this->addElement('select','workshop_id',array(
            'label'=>'Workshop Id',
            'multiple' => true,
            'registerInArrayValidator' => false,
            'required'=>false,
            'multioptions'=>array('0'=>'--Select--') + $workshop->fetchForSelect()
        ));

        $workshop = new Model_Workshop();
        $this->addElement('select','country_id',array(
            'label'=>'Country Id',
            'multiple' => true,
            'registerInArrayValidator' => false,
            'required'=>false,
            'multioptions'=>array('0'=>'--Select--') + $workshop->fetchForSelect()
        ));

        $trainingTypes= new Model_TrainingTypes();
        $this->addElement('select','training_id',array(
            'label'=>'Training Id',
            'multiple' => true,
            'registerInArrayValidator' => false,
            'required'=>false,
            'multioptions'=>array('0'=>'--Select--') + $trainingTypes->fetchForSelect()
        ));

        $this->addElement('text','discountType',array(
            'label'=>'Discount Type',
            'required'=>true,
            'class'=>'longtext'
        ));

        $this->addElement('text','discountValue',array(
            'label'=>'Discount Value',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'validators'=>array('Float'),
            'class'=>'required number',
        ));

        $this->addElement('text','totalCount',array(
            'label'=>'Total Count',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'validators'=>array('Int'),
            'class'=>'required number',
        ));

        $this->addElement('text','dateStart',array(
            'label'=>'Start Date',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('text','dateEnd',array(
            'label'=>'End Date',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('text','minAmount',array(
            'label'=>'Minimum Amount',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'validators'=>array('Float'),
            'class'=>'required number',
        ));

        $this->addElement('checkbox','autoApply',array(
            'label'=>'Auto Apply',
            'ignore'=>false,
           ));

         $this->addElement('submit','Add Discount',array(
          'ignore'=>true,
          'label'=>'Add Discount'
         ));
    }
}