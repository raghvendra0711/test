<?php

class Form_LecturePages extends BaseApp_Form {

    public function init() {

        $this->setName('lecturePages');
        $this->setMethod('post');
        $order = range(0, Model_LecturePages::ORDER_LIMIT);
        $key = range(0,Model_LecturePages::KEY_LIMIT);
        //adding Label name element

        $this->addElement('text', 'title', array(
            'label' => 'Title',
            'required' => true,
            'filters' => array('StringTrim'),
            'class' => 'longtext'
        ));

        $this->addElement('text', 'url', array(
            'label' => 'Url',
            'required' => true,
            'filters' => array('StringTrim'),
            'class' => 'longtext'
        ));

        $this->addElement('text', 'img_url', array(
            'label' => 'image Url',
            'required' => true,
            'filters' => array('StringTrim'),
            'class' => 'longtext',
            'validators' => array(
                new BaseApp_Validate_Image('LecturePages', 'img_url')
            )
        ));

        $course = new Model_Courses();
        $this->addElement('select', 'primary_course_id', array(
            'required' => true,
            'label' => 'Course',
            'multioptions' => array('0' => '--Select--') + $course->fetchForSelect(array('is_dummy = ?' => 0, 'is_free = ?' => 0))
        ));

        $this->addElement('select', 'order', array(
            'label' => 'Order',
            'required' => true,
            'multioptions' => array('0' => '--Select--') + $order
        ));

        $this->addElement('select', 'key', array(
            'label' => 'key',
            'required' => true,
            'multioptions' => array('0' => '--Select--') + $key
        ));
        $this->addElement('textarea', 'content', array(
            'label' => 'Content',
            'required' => false,
            'cols' => 60,
            'rows' => 6,
            'class' => 'fck-enable'
        ));

        $this->addElement('checkbox', 'tableFlag', array(
            'label' => 'Table Flag', 'value' => 1
        ));
        $this->addElement('checkbox', 'schemaFlag', array(
            'label' => 'Schema Flag', 'value' => 0
        ));
        $this->addElement('submit', 'Save SeoCourse', array(
            'ignore' => true,
            'label' => 'Save SeoCourse',
            'class' => 'btn btn-info'
        ));

        $validatorsName = array(new Zend_Validate_StringLength(array('max' => 100)));       
    }

    public function isValid($data) {

        $status = parent::isValid($data);
        if (!$status) {
            return false;
        }
        if (!empty($data)) {
            if (!empty($data['url'])) {
                $data['url'] = trim($data['url']);
                $checkSlash = substr($data['url'], 0, 1);
                if ($checkSlash != '/') {
                    $data['url'] = trim('/' . $data['url']);
                }
                $objSeo = new Model_Seo();
                if (false === $objSeo->validateUrl($data['url'])) {
                    $this->getElement('url')->setErrors(array("'{$data['url']}' is not a valid lecture url"));
                    $status = false;
                }
            }

            if (empty($data['order'])) {
                $this->getElement('order')->setErrors(array("you are not selected the order"));
                $status = false;
            }
            if (empty($data['key'])) {
                $this->getElement('key')->setErrors(array("you did not selected any key"));
                $status = false;
            }
            if (empty($data['primary_course_id'])) {
                $this->getElement('primary_course_id')->setErrors(array("you did not selected course"));
                $status = false;
            }
        } else {
            $status = false;
        }

        return $status;
    }

    public function removeUneditableElements() {
        $this->removeElement('url');
        return false;
    }

}
