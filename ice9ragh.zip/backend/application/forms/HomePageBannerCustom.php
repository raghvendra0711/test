<?php 
class Form_HomePageBannerCustom extends BaseApp_Form
{       
    
    const PATH='images/common';
    
    private $_banners;
    
    private $_indxOrder;
    
    public function __construct($param1, $param2) {
        $this->_banners = $param1;
        $this->_indxOrder = $param2;
        $this->init();
    }

    public function init() {
        $this->setMethod('post');
        $baseObj = new BaseApp_Utility_ReadFileConfig();
        $fileSetting = $baseObj->getFormInputSettings(get_class($this));
        $this->setName('default-banner-form');
        
        $countriesModel=new Model_Country();
        $this->addElement('select','country_ids',array(
             'label'=>'Country',
             'multiple'=>true,
             'required'=>true,
             'registerInArrayValidator' => false,
             'multioptions'=>$countriesModel->getListDisplay(),
        ));

        $files=array();
        foreach (glob(REL_UPLOAD_URL.'/'.self::PATH.'/'.$fileSetting['folderName'].'/'.$fileSetting['width'].'X'.$fileSetting['height'].'*.*') as $filepath) {
            $fileName = pathinfo($filepath);
            $files[$fileName['filename'].'.'.$fileName['extension']]=$fileName['filename'].'.'.$fileName['extension'];
        }
        
        if($this->_banners){
            foreach($this->_banners as $key=>$banners) {
                $this->addElement('select','image_name',array(
                    'label'=>'Image',
                    'multioptions'=>array(''=>'--Select--') + $files,
                    'class'=> 'imageNameSelect no-list mandatory',
                    'filters'=>array('StringTrim'),
                    'value'=>$banners['image_name'],
                    'multiple'=>true,
                    'data-indxorder'=>$this->_indxOrder,
                    'data-imagepath'=>UPLOAD_CDN_URL.'/'.self::PATH.'/'.$fileSetting['folderName'].'/',
                    'description'=>'<a target="blank" id="" href="'.UPLOAD_CDN_URL.'/'.self::PATH.'/'.$fileSetting['folderName'].'/'.$banners['image_name'].'">Preview</a>'
                ));
                $this->addElement('text','image_link',array(
                    'label'=>'Image Link mandatory',
                    'filters'=>array('StringTrim'),
                    'class'=>'longtext',
                    'value'=>$banners['image_link'],
                    'isArray'=>true
                ));
                $this->addElement('text','alt_text',array(
                    'label'=>'Alt Text',
                    'filters'=>array('StringTrim'),
                    'class'=>'longtext mandatory',
                    'value'=>$banners['alt_text'],
                    'isArray'=>true
                ));
                $this->addElement('text','class_name',array(
                    'label'=>'Class Name',
                    'filters'=>array('StringTrim'),
                    'class'=>'longtext',
                    'value'=>$banners['class_name'],
                    'isArray'=>true
                ));
                $this->addElement('hidden','banner_id',array(
                    'value'=>$banners['banner_id'],
                    'isArray'=>true
                ));
                $section1 = array('image_link','image_name','alt_text','class_name','banner_id');
                $this->addDisplayGroup($section1, $key.'imgBanner',array('legend' => ''));
                $this->_decorate();
           }
           $this->addElement('hidden','indexOrder',array(
                 'value'=>$this->_indxOrder,
              ));
        }else{
            $this->addElement('select','image_name',array(
             'label'=>'Select Image',
             'ignore'=>true,
             'class'=> 'imageNameSelect no-list mandatory',
             'filters'=>array('StringTrim'),
             'multioptions'=> array(''=>'--Select--') + $files,
             'multiple'=>true,
             'data-imagepath'=>UPLOAD_CDN_URL.'/'.self::PATH.'/'.$fileSetting['folderName'].'/',
             'description'=>'<a target="blank" id="" href="#">Preview</a>'
             ));

            $this->addElement('text','image_link',array(
             'label'=>'Image Link ',
             'filters'=>array('StringTrim'),
             'class'=>'longtext mandatory' ,
             'isArray' => true
            ));    
             $this->addElement('text','alt_text',array(
                 'label'=>'Alt Text',
                 'filters'=>array('StringTrim'),
                 'class'=>'longtext mandatory',
                 'isArray'=>true
              ));
              $this->addElement('text','class_name',array(
                 'label'=>'Class Name',
                 'filters'=>array('StringTrim'),
                 'class'=>'longtext',
                 'isArray'=>true
              ));
           $section1 = array('image_link','image_name','alt_text','class_name');
           $this->addDisplayGroup($section1, '0imgBanner',array('legend' => ''));
           $this->_decorate();
        }
        $add_more = new Zend_Form_Element_Button('add_more');
        $add_more->setLabel('Add More')->setAttrib('class', 'addmorebtn');
        $this->addElement($add_more);

        $remove_more = new Zend_Form_Element_Button('remove_previous');
        $remove_more->setLabel('Remove')->setAttrib('class', 'addmorebtn');
        $this->addElement($remove_more);

        $this->addElement('submit','uploaddefaultbanners',array(
            'label'=>'Save',
            'ignore'=>true
        ));
        $this->_decorate();
    }
}

