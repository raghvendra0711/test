<?php

class Form_CityPage extends BaseApp_SubForm {

    public function init() {

        $this->setName('CityPageForm');
        $this->setMethod('post');

        /**
         * Primary Courses
         */
        $this->addElement('hidden', 'city_page_course_id', array(
            'required' => false,
            'value' => '',
            'attribs' => array('readonly' => 'true')
        ));
        
        $productTypes = array(
            BaseApp_Dao_Courses::PRODUCT_TYPE_ID => "Courses",
            BaseApp_Dao_Bundles::PRODUCT_TYPE_ID => "Bundles",
        );
        $this->addElement('select', 'prouct_type', array(
            'label' => 'Product Type*',
            'required' => false,
            'class' => 'text',
            'multioptions' => array('0' => '--Select--') + $productTypes
        ));
        
        $this->addElement('text', 'city_page_course_name', array(
            'label' => 'Product Name*',
            'autocomplete'=> false,
            'required' => false,
            'class' => 'text'
        ));

        /**
         * Cities
         */
        $cities = array();
        $this->addElement('select', 'city_page_city_id', array(
            'required' => true,
            'label' => 'City*',
            'multioptions' => array('0' => '--Select--') + $cities
        ));
        /**
         * Training Types
         */
        $trainingTypes = array();
        $this->addElement('select', 'city_page_training_types', array(
            'required' => true,
            'label' => 'Training Types*',
            'multioptions' => array('0' => '--Select--') + $trainingTypes
        ));
    }

}
