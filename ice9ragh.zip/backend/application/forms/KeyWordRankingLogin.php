<?php

class Form_KeyWordRankingLogin extends BaseApp_SubForm {

    public function init() {

        $this->setName('KeyWordRankingLoginForm');
        $this->setMethod('post');


        $this->addElement('text', 'username', array(
            'label' => 'Name*',
            'required' => false,
            'class' => 'text'
        ));

        $this->addElement('password', 'password', array(
            'label' => 'Password*',
            'required' => false,
            'class' => 'text'
        ));

        $this->addElement('submit', 'Login', array(
            'ignore' => true,
            'label' => 'Login',
            'class' => 'btn btn-info'
        ));
    }

}
