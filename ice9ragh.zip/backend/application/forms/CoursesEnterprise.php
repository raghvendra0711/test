
<?php

class Form_CoursesEnterprise extends BaseApp_SubForm {

    private $_courseId = null;

    const LABEL_COMPANY_CARD_OSL_CONTENT = 'company_card_osl_contents';
    const LABEL_COMPANY_CARD_LVC_CONTENT = 'company_card_lvc_contents';

    public function __construct($courseId = false, $new = true) {
        if ($courseId) {
            $this->_courseId = $courseId;
        }
        $this->init($courseId);
        $this->loadDefaultDecorators();
    }

    public function init($courseId) {
        $this->setName('CoursesEnterprise');
        $this->setMethod('post');
        $this->setAttrib('class', 'courseForm');

        $validatorsCompanyCardTextForOSL = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 700)));
        $validatorsCompanyCardTextForLVC = array(new Zend_Validate_StringLength(array('min' => 2, 'max' => 700)));

        $this->addElement('textarea', self::LABEL_COMPANY_CARD_OSL_CONTENT, array(
            'label' => 'Course OSL card',
            'filter' => array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class' => 'b2b_contents fck-enable',
            'validators' => $validatorsCompanyCardTextForOSL,
            'value' => '<ul><li>num_of_days days of access to high-quality, self-paced learning content designed by industry experts</li></ul>'
        ));


        //Company card for LVC
        $this->addElement('textarea', self::LABEL_COMPANY_CARD_LVC_CONTENT, array(
            'label' => 'Course LVC card',
            'filter' => array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class' => 'b2b_contents fck-enable',
            'value' => '<ul><li>num_of_days days of access to high-quality, self-paced learning content designed by industry experts</li></ul>',
            'validators' => $validatorsCompanyCardTextForLVC
        ));
        $this->addElement('submit', 'Save', array(
            'ignore' => true,
            'label' => 'Save & Proceed',
            'class' => 'btn btn-info'
        ));
        $this->getElement(self::LABEL_COMPANY_CARD_OSL_CONTENT)->setDescription('Please use "num_of_days" tag to mention number of days osl elearning access <br><br>')
                ->setDecorators(array(
                    'ViewHelper',
                    array('Description', array('escape' => false, 'tag' => false)),
                    array('HtmlTag', array('tag' => 'dd')),
                    array('Label', array('tag' => 'dt')),
                    'Errors',
        ));
        $this->getElement(self::LABEL_COMPANY_CARD_LVC_CONTENT)->setDescription('Please use "num_of_days" tag to mention number of days osl elearning access <br><br>')
                ->setDecorators(array(
                    'ViewHelper',
                    array('Description', array('escape' => false, 'tag' => false)),
                    array('HtmlTag', array('tag' => 'dd')),
                    array('Label', array('tag' => 'dt')),
                    'Errors',
        ));
        if (!empty($courseId)) {
            // set values
            $objCourse = new Model_Courses();
            $courseData = $objCourse->fetchAll(array('course_id=?' => $courseId), array(), false);
            if (empty($courseData)) {
                return;
            }
            $courseData = $courseData[0];
            $this->getElement(self::LABEL_COMPANY_CARD_OSL_CONTENT)->setValue(!empty($courseData['company_card_osl_contents'])? $courseData['company_card_osl_contents']:'<ul><li>num_of_days days of access to high-quality, self-paced learning content designed by industry experts</li></ul>');
            $this->getElement(self::LABEL_COMPANY_CARD_OSL_CONTENT)->setDescription('Please use "num_of_days" tag to mention number of days osl elearning access <br><br>')
                ->setDecorators(array(
                    'ViewHelper',
                    array('Description', array('escape' => false, 'tag' => false)),
                    array('HtmlTag', array('tag' => 'dd')),
                    array('Label', array('tag' => 'dt')),
                    'Errors',
        ));
            $this->getElement(self::LABEL_COMPANY_CARD_LVC_CONTENT)->setValue(!empty($courseData['company_card_lvc_contents']) ? $courseData['company_card_lvc_contents']:'<ul><li>num_of_days days of access to high-quality, self-paced learning content designed by industry experts</li></ul>');
            $this->getElement(self::LABEL_COMPANY_CARD_LVC_CONTENT)->setDescription('Please use "num_of_days" tag to mention number of days osl elearning access <br><br>')
                ->setDecorators(array(
                    'ViewHelper',
                    array('Description', array('escape' => false, 'tag' => false)),
                    array('HtmlTag', array('tag' => 'dd')),
                    array('Label', array('tag' => 'dt')),
                    'Errors',
        ));
        }
    }

    public function isValid($data) {
        $status = parent::isValid($data);
        return $status;
    }

}
