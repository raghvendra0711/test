<?php

class Form_ExamVenues extends BaseApp_Form
{
    public function __construct() {
        parent::__construct();
    }
    
    const CITY_ID_NAME = 'city_id';

    public function init(){
        
        $cityMdl =new Model_City();
        $city = $cityMdl->fetchForSelect(array('country_id=?'=>INDIA_COUNTRY_ID));

        $validatorsVenueName = array(new Zend_Validate_StringLength(array('min' => 1,'max'=>150)));
        $validatorsVenueAddress = array(new Zend_Validate_StringLength(array('min' => 1,'max'=>400)));
        
        $this->setMethod('post');
        $this->setName('examVenue');    
       
        $this->addElement('text','country_name',array(
//            'required'=>true,
            'label' => 'Country',
            'readonly'=>true,
            'value'=>'India'
            ));
       
        $this->addElement('select',self::CITY_ID_NAME,array(
            'required'=>true,
            'label' => 'City',
            'registerInArrayValidator' => false,
            'multioptions'=>$city
            )); 
        
        $this->addElement('text','venue_name',array(
            'label'=>'Venue Name',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'placeholder'=>'Venue name will be displayed to the customer during venue selection',
            'class'=>'longtext',
            'validators' => $validatorsVenueName
        ));

        $this->addElement('textarea','venue_address',array(
            'label'=>'Venue Address',
            'required'=>true,
            'cols' => 60,
            'rows' => 1,
            'class'=>'longtext',
            'validators' => $validatorsVenueAddress,
            'placeholder'=>'Venue address will be displayed to the customer during venue selection',
        ));
        
        $this->addElement('submit','save',array(
          'ignore'=>true,
          'label'=>'Save',
         ));
    }

    public function setValues($data){
        $this->getElement('city_id')->setValue($data['city_id']);
        $this->getElement('venue_name')->setValue($data['venue_name']);
        $this->getElement('venue_address')->setValue($data['venue_address']);
        $this->getElement('save')->setLabel('Update');
    }

    public function removeUneditableElements() {
        $this->getElement(Form_ExamVenues::CITY_ID_NAME)->setAttrib('disabled', 'disabled');
        $this->getElement(Form_ExamVenues::CITY_ID_NAME)->setRequired(false);
    }

}

