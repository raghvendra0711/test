<?php

class Form_CompanyDomains extends BaseApp_Form
{

    public function init(){

        $this->setName('Company Domains');
        $this->setMethod('post');
         //adding Label name element

        $obj =new Model_ProductSectionData();
        $obj->setDisplayField('name');
        $this->addElement('select','agency',array(
                'label'=>'Agency*',
                'required'=>true,
                'registerInArrayValidator' => false,
                'multioptions'=>array('0'=>'--Select--') + $obj->fetchForSelect(array('sectionType = ?' => "agency"))
        ));

        $this->addElement('text','name',array(
            'label'=>'Domain*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                    new Zend_Validate_Hostname(Zend_Validate_Hostname::ALLOW_DNS)
            )
        ));



         $this->addElement('submit','Add Domain',array(
          'ignore'=>true,
          'label'=>'Add Domain',
          'class'=>'btn btn-info'
         ));

    }

    public function isValid($data) {
        $status = parent::isValid($data);
        if(!$status)
            return false;
            if($data['agency'] == 0){
                $this->getElement('agency')->setErrors(array("Value is required and can't be empty"));
                $status = false;
            }
            if($data['name'] != ''){
                $obj =new Model_ProductSectionData();
                $existData = $obj->getBySectionName($data['name'], 'domain');
                if(!empty($existData) && !empty($existData['agency'])){
                    if(in_array($data['agency'], $existData['agency'])){
                        $this->getElement('name')->setErrors(array("Domain already added to the agency"));
                        $status = false;
                    }
                }
            }
            return $status;
    }
}