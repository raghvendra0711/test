<?php

class Form_BundlePricing extends BaseApp_SubForm
{

    public $bundleStatus = array(
        'no_where' => 'No Where',
        'universal' => 'Universal',
        'b2b_only' => 'B2B Only',
        'private_b2b' => 'Private B2B',
        'b2c_only' => 'B2C Only',
        'complimentary_course' => 'Complimentary Course',
    );
    const ACCESS_DAYS_FACTOR = 30;
    protected $_data;
    public function __construct($data = array())
    {
        $this->_data = $data;
        $this->init();
    }
    public function init()
    {
        $data = $this->_data;
        $this->setName('Bundles');
        $this->setMethod('post');
        $this->setAttrib("class", "form-width");
        $session = new Zend_Session_Namespace('form');
        /*
         * start: Sub form for no. of sets
         */

        $this->addElement('hidden', 'master_type', array(
            'required' => false,
            'value' => !empty($data['master_type']) ? $data['master_type'] : ''
        ));
        $this->addElement('hidden', 'is_part_payment', array(
            'required' => false,
            'value' => !empty($data['is_part_payment']) ? true : false
        ));

        /*
         * start: Sub form for no. of sets
         */

        $subForm = new Zend_Form_SubForm();
        $subForm->setName('accessDays');
        foreach ($session->accessDays as $product) {
            $keyaccessDays = isset($session->accessDaysData[$product]['accessDays']) ? $session->accessDaysData[$product]['accessDays'] : '';
            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);

            if ($product === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
            }

            $setsNumber = new Zend_Form_Element_Select('accessDays');
            $accessObj = new Model_AccessDays();
            $accessDays = $this->getAccessDays($accessObj);
            $setsNumber->addFilter('stringTrim')->setValue($keyaccessDays)->setAttrib('class', 'accessDaysCount')->setAttrib('placeholder', 'Access Days')->setLabel('Program Access Days')->setOptions(array('multioptions' => array('0' => '--Select--') + $accessDays, 'registerInArrayValidator' => false));
            if ($product !== '__template__') {
                $setsNumber->setRequired(true);
            }

            $removeSetsNumber = new Zend_Form_Element_Button('remove');
            $removeSetsNumber->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeAccessDays(this)');

            $elements = array($setsNumber);
            if ($product !== 'new') {
                $elements[] = $removeSetsNumber;
            }

            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());

            if ($rowForm->getElement('remove')) {
                $rowForm->getElement('remove')->removeDecorator('Label');
            }

            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        }

        $subForm->setDecorators($this->getSubFormDecoratorsMain('accessDays', 'accessDays'));

        $addPrice = new Zend_Form_Element_Button('add');
        $addPrice->setLabel('Add More')->setAttrib('class', 'btn btn-warning add hide   ');
        $subForm->addElement($addPrice);

        $subForm->setElementDecorators($this->getElementDecorators());
        $subForm->getElement('add')->removeDecorator('Label');
        $this->addSubForm($subForm, 'accessDays');

        /*
         * end: Sub form for no. of sets
         */


        /*
         * Start: Sub form for price
         */

        $subForm = new Zend_Form_SubForm();
        $subForm->setName('countryPrice');
        foreach ($session->countryPrice as $product) {
            $subscription_id = isset($session->countryPriceData[$product]['subscription_id']) ? $session->countryPriceData[$product]['subscription_id'] : 0;
            $keyCurrency = isset($session->countryPriceData[$product]['currency_id']) ? $session->countryPriceData[$product]['currency_id'] : '';
            $keyCountry = isset($session->countryPriceData[$product]['country_id']) ? $session->countryPriceData[$product]['country_id'] : '';
            $keyCluster = isset($session->countryPriceData[$product]['cluster_id']) ? $session->countryPriceData[$product]['cluster_id'] : '';
            $keyDiscount = isset($session->countryPriceData[$product]['discountValue']) ? $session->countryPriceData[$product]['discountValue'] : '';
            $keySubscriptionId = isset($session->countryPriceData[$product]['subscription_id']) ? $session->countryPriceData[$product]['subscription_id'] : '';
            if (!empty($session->countryPriceData[$product]['partPaymentInfo'])) {
                $partInfo = $session->countryPriceData[$product]['partPaymentInfo'];
                $first_instr_value = isset($partInfo[0]['installment_text']) ? $partInfo[0]['installment_text'] : '';
                $second_instr_value = isset($partInfo[1]['installment_text']) ? $partInfo[1]['installment_text'] : '';
                $third_instr_value = isset($partInfo[2]['installment_text']) ? $partInfo[2]['installment_text'] : '';
                $first_part_amount = isset($partInfo[0]['installment_amount']) ? $partInfo[0]['installment_amount'] : '';
                $second_part_amount = isset($partInfo[1]['installment_amount']) ? $partInfo[1]['installment_amount'] : '';
                $third_part_amount = isset($partInfo[2]['installment_amount']) ? $partInfo[2]['installment_amount'] : '';
            } else {
                $first_instr_value = '';
                $second_instr_value = '';
                $third_instr_value = '';
                $first_part_amount = '';
                $second_part_amount = '';
                $third_part_amount = '';
            }

            $keyLocationMode = '';
            if ($keyCountry) {
                $keyLocationMode = 2;
            } else if ($keyCluster) {
                $keyLocationMode = 1;
            }
            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);

            if ($product === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
            }

            $trainingType = new Zend_Form_Element_Select('training_id');
            $trainingType->setOptions(array('multioptions' => array(BaseApp_Dao_TrainingTypes::TYPE_ELEARNING => 'Online Self Learning')))->setValue(BaseApp_Dao_TrainingTypes::TYPE_ELEARNING)->setAttrib('class', 'trainingId')->setLabel('Training Type');

            $currency = new Zend_Form_Element_Select('currency_id');
            $currencyModel = new Model_Currency();
            $currency->setOptions(array('multioptions' => $currencyModel->getCurrencyToDisplay()))->setValue($keyCurrency)->setAttrib('class', 'currency')->setLabel('Currency');

            $locationMode = new Zend_Form_Element_Select('location_mode');
            $locationMode->setOptions(array('multioptions' => array(0 => '--Select--', 1 => 'By Cluster', 2 => 'By Country')))->setValue($keyLocationMode)->setAttrib('class', 'location')->setLabel('Pricing Level');

            $country = new Zend_Form_Element_Select('country_id');
            $countryList = array();
            if ($keyCurrency && $keyLocationMode == 2) {
                $countryModel = new Model_Country();
                $countryList = $countryModel->fetchForSelect(array('currency_id=?' => $keyCurrency));
            }
            $country->setOptions(array('multioptions' => $countryList, 'registerInArrayValidator' => false))->setValue($keyCountry)->setAttrib('class', 'country')->setLabel('Country');

            $cluster = new Zend_Form_Element_Select('cluster_id');
            $clusterList = array();
            if ($keyCurrency && $keyLocationMode == 1) {
                $obj = new Model_Clusters();
                $clusterList = $obj->fetchForSelect(array('currency_id=?' => $keyCurrency));
            }
            $cluster->setOptions(array('multioptions' => $clusterList, 'registerInArrayValidator' => false))->setValue($keyCluster)->setAttrib('class', 'cluster')->setLabel('Cluster');

            $discount = new Zend_Form_Element_Text('discountValue');
            $discount->addFilter('stringTrim')->setValue($keyDiscount)->setAttrib('class', 'discountValue')->setLabel('Discount(%)')->setAttrib('placeholder', 'Discount (%)');

            $subscriptionId = new Zend_Form_Element_Hidden('subscriptionId');
            $subscriptionId->addFilter('stringTrim')->setValue($keySubscriptionId);

            if ($product !== '__template__') {
                $country->setRequired(false);
                $cluster->setRequired(false);
                $locationMode->setRequired(false);
                $currency->setRequired(false);
                $discount->setRequired(false);
                $trainingType->setRequired(false);
                $subscriptionId->setRequired(false);
            }

            $removeCountryPrice = new Zend_Form_Element_Button('remove');
            $removeCountryPrice->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');

            $elements = array($trainingType, $currency, $locationMode, $cluster, $country, $discount, $subscriptionId);

            $accessObj = new Model_AccessDays();
            $accessDaysAll = $this->getAccessDays($accessObj);
            foreach ($session->accessDays as $productAccess) {
                if ($productAccess == '__template__') {
                    continue;
                }
                $showAccessDays = '';
                if (isset($session->accessDaysData[$productAccess]['accessDays']) && isset($accessDaysAll[$session->accessDaysData[$productAccess]['accessDays']])) {
                    $showAccessDays = $accessDaysAll[$session->accessDaysData[$productAccess]['accessDays']];
                }
                $keyPrice = isset($session->countryPriceData[$product]['price' . $productAccess]) ? $session->countryPriceData[$product]['price' . $productAccess] : '';
                $priceElement = new Zend_Form_Element_Text('price' . $productAccess);
                $priceElement->addFilter('stringTrim')->setValue($keyPrice)->setAttrib('class', 'accessPrice')->setLabel('Price ( Access days ' . $showAccessDays . ' )')->setAttrib('placeholder', 'Price');
                $elements[] = $priceElement;
            }

            /*********************** Part Time Payment 2 Installments (Max 3) Start ****************/

            $subscriptionId = new Zend_Form_Element_Hidden('subscription_id');
            $subscriptionId->setValue($subscription_id)->setAttrib('class', 's-Id');
            $elements[] = $subscriptionId;

            $hasPartPayment = new  Zend_Form_Element_Checkbox('hasPartPayment');
            $hasPartPaymentValue = ($first_part_amount + $second_part_amount + $third_part_amount) > 0 ? true : false;

            $hasPartPayment->setValue($hasPartPaymentValue)->setAttrib('class', 'pp-enabled')->setLabel('Part Payment');
            $elements[] = $hasPartPayment;

            $first_installment_text = new Zend_Form_Element_Text('first_installment_text');
            $first_installment_text->addFilter('stringTrim')->setValue($first_instr_value)->setAttrib('class', 'part-installments inst-1')->setLabel('1st Installment')->setAttrib('placeholder', 'Time of Payment');
            $elements[] = $first_installment_text;

            $installment_first = new Zend_Form_Element_Text('installment_first');
            $installment_first->addFilter('stringTrim')->setValue($first_part_amount)->setAttrib('class', 'part-installments amt-1')->setAttrib('placeholder', 'Installment Amount');
            $elements[] = $installment_first;

            $second_installment_text = new Zend_Form_Element_Text('second_installment_text');
            $second_installment_text->addFilter('stringTrim')->setValue($second_instr_value)->setAttrib('class', 'part-installments inst-2')->setLabel('2nd Installment')->setAttrib('placeholder', 'Time of Payment');
            $elements[] = $second_installment_text;

            $installment_second = new Zend_Form_Element_Text('installment_second');
            $installment_second->addFilter('stringTrim')->setValue($second_part_amount)->setAttrib('class', 'part-installments amt-2')->setAttrib('placeholder', 'Installment Amount');
            $elements[] = $installment_second;

            $third_installment_text = new Zend_Form_Element_Text('third_installment_text');
            $third_installment_text->addFilter('stringTrim')->setValue($third_instr_value)->setAttrib('class', 'part-installments inst-3')->setLabel('3rd Installment')->setAttrib('placeholder', 'Time of Payment');
            $elements[] = $third_installment_text;

            $installment_third = new Zend_Form_Element_Text('installment_third');
            $installment_third->addFilter('stringTrim')->setValue($third_part_amount)->setAttrib('class', 'part-installments amt-3')->setAttrib('placeholder', 'Installment Amount');
            $elements[] = $installment_third;

            /*********************** Part Time Payment 2 Installments (Max 3) End ****************/

            if ($product !== 'new') {
                $elements[] = $removeCountryPrice;
            }

            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());

            if ($rowForm->getElement('remove')) {
                $rowForm->getElement('remove')->removeDecorator('Label');
            }

            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        }

        $subForm->setDecorators($this->getSubFormDecoratorsMain('countryPrice', 'countryPrice'));

        $addPrice = new Zend_Form_Element_Button('add');
        $addPrice->setLabel('Add More')->setAttrib('class', 'btn btn-warning add');
        $subForm->addElement($addPrice);

        $subForm->setElementDecorators($this->getElementDecorators());
        $subForm->getElement('add')->removeDecorator('Label');
        $this->addSubForm($subForm, 'countryPrice');

        /*
         * End: Sub form for price
         */
        /*
         * End: Sub form for price
         */

        $this->postSetup();
    }

    protected function getSubFormDecoratorsMain($className, $id)
    {
        return array(
            'FormElements',
            array(
                'HtmlTag', array('tag' => 'ul')
            ),
            array(
                array('row' => 'HtmlTag'),
                array('tag' => 'li', 'class' => $className, 'id' => $id)
            )
        );
    }

    public function isValid($data)
    {
        $status = parent::isValid($data);
        if ((isset($data['accessDays']) && $data['accessDays'])) {
            $status = $this->subFormValidations($data['accessDays'], 'accessDays', $status);
        }
        return $status;
    }
    public function getAccessDays($accessObj)
    {
        $data = $accessObj->getAccessDaysById('osl', true, true);
        foreach ($data as $key => $value) {
            $data[$key] = floor($value / self::ACCESS_DAYS_FACTOR) . ' months';
        }
        return $data;
    }
    public function subFormValidations($data, $subForm, $status)
    {
        $count = 0;
        $accessDays = $data;
        end($accessDays);
        $keyA = key($accessDays);
        if ($subForm == 'accessDays' && count($data) > 2) {
            $this->getSubForm($subForm)->getSubForm($keyA)->getElement('accessDays')->setErrors(array("Only 2 bundle prices are allowed."));
            $status = false;
        }
        return $status;
    }
}
