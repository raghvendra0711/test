<?php

class Form_Recommendations extends BaseApp_Form
{
    
    
    public function init(){
        $this->setName('Recommendations');
        $this->setMethod('post');
         //adding Label name element
        $obj = new Model_Courses();
        $this->addElement('select','courses',array(
            'label'=>'Related Courses',
            'required'=>false,
            'multiple' => true,
            'class' => 'multiple',
            'registerInArrayValidator' => false,
            'multioptions'=>array('0'=>'--Select--') + $obj->fetchForSelect(array('is_dummy = ?' => 0, 'is_free = ?' => 0))
        ));

        $this->addElement('submit','Save',array(
          'ignore'=>true,
          'label'=>'Save'
         ));
    }
}

