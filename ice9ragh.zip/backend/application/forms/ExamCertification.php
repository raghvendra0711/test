<?php

class Form_ExamCertification extends BaseApp_SubForm {

    private $_trainingId = '';
    private $_addMoreButton = true;

    public function __construct($trainingId, $addMoreButton = true) {
        $this->_trainingId = $trainingId;
        $this->_addMoreButton = $addMoreButton;
        parent::__construct();
    }

    public function init() {
        $this->setName('ExamCertification');
        $this->setMethod('post');
        //adding Label name element

        $session = new Zend_Session_Namespace('form');

        $subForm = new Zend_Form_SubForm();
        $subForm->setName('examCirtification');
        foreach ($session->examCirtification as $product) {
            $faqId = isset($session->examCirtificationData[$product]['faq_id']) ? $session->examCirtificationData[$product]['faq_id'] : '';
            $keyQuestion = isset($session->examCirtificationData[$product]['question']) ? $session->examCirtificationData[$product]['question'] : '';
            $keyAnswer = isset($session->examCirtificationData[$product]['answer']) ? $session->examCirtificationData[$product]['answer'] : '';
            $keyJumpTo = isset($session->examCirtificationData[$product]['jump_to_section']) ? $session->examCirtificationData[$product]['jump_to_section'] : '';
            $isB2BValue = isset($session->examCirtificationData[$product]['is_b2b']) ? $session->examCirtificationData[$product]['is_b2b'] : null;
            $isB2CValue = isset($session->examCirtificationData[$product]['is_b2c']) ? $session->examCirtificationData[$product]['is_b2c'] : null;
            $keyCountryIds = isset($session->examCirtificationData[$product]['countryIds']) ? $session->examCirtificationData[$product]['countryIds'] : array();
            $keyClusterIds = isset($session->examCirtificationData[$product]['clusterIds']) ? $session->examCirtificationData[$product]['clusterIds'] : array();

            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);

            $classfck = 'fck-enable';
            if ($product === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
                $classfck = '';
            }

            $resourceIdDom = new Zend_Form_Element_Hidden('course_faq_id');
            $resourceIdDom->setValue($faqId)->clearDecorators();



            //Country
            $country = new Zend_Form_Element_Select('country_id');
            $countryModel = new Model_Country();
            $keyCountry = !empty($keyCountryIds) ? explode(',', $keyCountryIds) : array();
            $country->setOptions(array('required' => false, 'multiple' => true, 'multioptions' => $countryModel->getListDisplay()))
                    ->setValue($keyCountry)->setAttrib('class', 'courseListAll countryListAll skipPreviousClick')
                    ->setLabel('Country')
                    ->setRegisterInArrayValidator(false);

            //Cluster
            $cluster = new Zend_Form_Element_Select('cluster_id');
            $clusterModel = new Model_Clusters();
            $keyCluster = !empty($keyClusterIds) ? explode(',', $keyClusterIds) : array();
            $cluster->setOptions(array('required' => false, 'multiple' => true, 'multioptions' => $clusterModel->fetchForSelect()))
                    ->setValue($keyCluster)->setAttrib('class', 'multiple clusterListAll')
                    ->setLabel('Cluster')
                    ->setAttrib('data-last-selected',$keyClusterIds)
                    ->setAttrib('onchange', 'countryByClusterSelect(this)')
                    ->setRegisterInArrayValidator(false);

            //Check All Countries
            $allCountryChecked = 0;
            $isClusterCountryDisabled = false;
            if (empty($keyCluster) && empty($keyCountry)) {
                $allCountryChecked = 1;
                $isClusterCountryDisabled = true;
            }
            $checkAllCountry = new Zend_Form_Element_Checkbox('all_country');
            $checkAllCountry->setValue($allCountryChecked)->setLabel('All Countries')->setAttrib('onclick', 'checkAllCountry(this)');

            if ($isClusterCountryDisabled) {
                $cluster->setOptions(array('disabled' => true));
                $country->setOptions(array('disabled' => true));
            }

            $question = new Zend_Form_Element_Text('question');
            $question->addFilter('stringTrim')->setValue($keyQuestion)->setAttrib('class', 'longtext')->setLabel('Question');

            $isB2b = new Zend_Form_Element_Checkbox('is_b2b');
            $isB2b->addFilter('stringTrim')->setValue($isB2BValue)->setAttrib('class', '')->setLabel('Is B2B');

            $isB2C = new Zend_Form_Element_Checkbox('is_b2c');
            $isB2C->addFilter('stringTrim')->setValue($isB2CValue)->setAttrib('class', '')->setLabel('Is B2C');

            $answer = new Zend_Form_Element_Textarea('answer');
            $answer->addFilter('stringTrim')->setValue($keyAnswer)->setAttrib('class', $classfck)->setAttrib('rows', 5)->setAttrib('cols', 60)->setLabel('Answer');

            $jumpTo = new Zend_Form_Element_Checkbox('jump_to_section');
            $jumpTo->setValue($keyJumpTo)->setLabel('Add as JumpTo Section');

            $removeFaq = new Zend_Form_Element_Button('remove');
            $removeFaq->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');

            //Invert Selection
            $invertBtn = new Zend_Form_Element_Button('invert');
            $invertBtn->setLabel('Invert Countries')->setAttrib('class', 'btn btn-warning remove invert-all')->setAttrib('onclick', 'invertSelection(this)');
            if($allCountryChecked){
                $invertBtn->setOptions(array('disabled' => true));
            }
            $elements = array($checkAllCountry, $cluster, $country, $invertBtn, $question, $answer, $isB2C, $isB2b, $jumpTo, $resourceIdDom);
            if ($product !== 'new') {
                $elements[] = $removeFaq;
            }

            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());

            if ($rowForm->getElement('remove')) {
                $rowForm->getElement('remove')->removeDecorator('Label');
            }

            if ($rowForm->getElement('invert')) {
                $rowForm->getElement('invert')->removeDecorator('Label');
            }

            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        }

        $subForm->setDecorators($this->getSubFormDecoratorsMain('course-faq-editor', 'examCirtification'));
        if ($this->_addMoreButton) {
            $addFaq = new Zend_Form_Element_Button('add');
            $addFaq->setLabel('Add More')->setAttrib('class', 'btn btn-warning add');
            $subForm->addElement($addFaq);

            $subForm->setElementDecorators($this->getElementDecorators());
            $subForm->getElement('add')->removeDecorator('Label');
        }

        $this->addSubForm($subForm, 'examCirtification');

        $this->addElement('text', 'completion_cirtificate_image', array(
            'label' => "Completion Certificate Image Link",
            'required' => false,
            'filters' => array('StringTrim'),
            'class' => 'longtext'
        ));

        $this->addElement('textarea', 'completion_cirtificate_description', array(
            'label' => 'Type Regarding Certification',
            'required' => false,
            'class' => 'multiple',
            'cols' => 60,
            'rows' => 6,
            'class' => 'fck-enable'
        ));


        $this->addElement('text', 'pdu_cirtificate_image', array(
            'label' => "PDU certificate Image",
            'required' => false,
            'class' => 'multiple',
            'class' => 'longtext'
        ));

        $this->addElement('textarea', 'pdu_cirtificate_description', array(
            'label' => 'PDU certificate Description',
            'required' => false,
            'class' => 'multiple',
            'cols' => 60,
            'rows' => 6,
            'class' => 'fck-enable'
        ));


        if ($this->_trainingId == BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM) {
            /* Start From ClassRoom Certificates */

            /* Start PDU Certificates for Class Room */

            $this->addElement('text', 'classroom_header', array(
                'label' => '',
                'required' => false,
                'value' => 'Certificate Details for Class Room',
                'disabled' => true,
                'ignore' => true,
                'disable' => array(1)
            ));

            $this->addElement('text', 'pdu_classroom_name', array(
                'label' => 'PDU Certificate Name - Class Room',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $this->addElement('text', 'pdu_classroom_displayName', array(
                'label' => 'PDU Certificate Display Name - Class Room',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $obj = new Model_Accreditors();
            $this->addElement('select', 'pdu_classroom_accreditor_id_1', array(
                'label' => 'PDU Certifcate Accreditors 1 - Class Room',
                'registerInArrayValidator' => false,
                'required' => false,
                'multioptions' => array('0' => '--Select--') + $obj->fetchForSelect()
            ));

            $this->addElement('select', 'pdu_classroom_accreditor_id_2', array(
                'label' => 'PDU Certifcate Accreditors 2 - Class Room',
                'registerInArrayValidator' => false,
                'required' => false,
                'multioptions' => array('0' => '--Select--') + $obj->fetchForSelect()
            ));

            $this->addElement('text', 'pdu_classroom_activityNumber', array(
                'label' => 'PDU Certificate Activity Number - Class Room',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $this->addElement('text', 'pdu_classroom_pdu', array(
                'label' => 'PDU Certificate PDU Number - Class Room',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $this->addElement('text', 'pdu_classroom_oneLiner', array(
                'label' => 'PDU Certificate Message - Class Room',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $this->addElement('hidden', 'pdu_classroom_certificateType', array(
                'required' => false,
                'value' => 'pdu'
            ));

            $this->addElement('hidden', 'pdu_classroom_training_id', array(
                'required' => true,
                'value' => BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM
            ));

            /* Ends PDU Certificates for Class Room */

            /* Start Completion Certificates for Class Room */

            $this->addElement('text', 'completion_classroom_name', array(
                'label' => 'Completion Certificate Name - Class Room',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $this->addElement('text', 'completion_classroom_displayName', array(
                'label' => 'Completion Certificate Display Name - Class Room',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $obj = new Model_Accreditors();
            $this->addElement('select', 'completion_classroom_accreditor_id_1', array(
                'label' => 'Completion Certificate Accreditors 1- Class Room',
                'registerInArrayValidator' => false,
                'required' => false,
                'multioptions' => array('0' => '--Select--') + $obj->fetchForSelect()
            ));

            $this->addElement('select', 'completion_classroom_accreditor_id_2', array(
                'label' => 'Completion Certificate Accreditors 2- Class Room',
                'registerInArrayValidator' => false,
                'required' => false,
                'multioptions' => array('0' => '--Select--') + $obj->fetchForSelect()
            ));

            $this->addElement('text', 'completion_classroom_activityNumber', array(
                'label' => 'Completion Certificate Activity Number - Class Room',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $this->addElement('text', 'completion_classroom_pdu', array(
                'label' => 'Ceompletion Certificate PDU Number- Class Room',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $this->addElement('text', 'completion_classroom_oneLiner', array(
                'label' => 'Completion Certificate Message - Class Room',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $this->addElement('hidden', 'completion_classroom_certificateType', array(
                'required' => false,
                'value' => 'completion'
            ));

            $this->addElement('hidden', 'completion_classroom_training_id', array(
                'required' => true,
                'value' => BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM
            ));


            /* Ends Completion Certificates for Class Room */

            /* LVC Starts */

            $this->addElement('text', 'lvc_header', array(
                'label' => '',
                'required' => false,
                'value' => 'Certificate Details for LVC',
                'disabled' => true,
                'ignore' => true,
                'disable' => array(1)
            ));

            /* PDU Certificates for LVC */

            $this->addElement('text', 'pdu_lvc_name', array(
                'label' => 'PDU Certificate Name - LVC',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $this->addElement('text', 'pdu_lvc_displayName', array(
                'label' => 'PDU Certificate Display Name - LVC',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $obj = new Model_Accreditors();
            $this->addElement('select', 'pdu_lvc_accreditor_id_1', array(
                'label' => 'PDU Certificate Accreditors 1- LVC',
                'registerInArrayValidator' => false,
                'required' => false,
                'multioptions' => array('0' => '--Select--') + $obj->fetchForSelect()
            ));

            $this->addElement('select', 'pdu_lvc_accreditor_id_2', array(
                'label' => 'PDU Certificate Accreditors 2- LVC',
                'registerInArrayValidator' => false,
                'required' => false,
                'multioptions' => array('0' => '--Select--') + $obj->fetchForSelect()
            ));

            $this->addElement('text', 'pdu_lvc_activityNumber', array(
                'label' => 'PDU Certificate Activity Number -LVC',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $this->addElement('text', 'pdu_lvc_pdu', array(
                'label' => 'PDU Certificate PDU Number - LVC',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $this->addElement('text', 'pdu_lvc_oneLiner', array(
                'label' => 'PDU Certificate Message - LVC',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $this->addElement('hidden', 'pdu_lvc_certificateType', array(
                'required' => false,
                'value' => 'pdu'
            ));

            $this->addElement('hidden', 'pdu_lvc_training_id', array(
                'required' => true,
                'value' => BaseApp_Dao_TrainingTypes::TYPE_LVC
            ));

            /* Ends PDU Certificates for LVC */

            /* Starts Completion Certificates for LVC */

            $this->addElement('text', 'completion_lvc_name', array(
                'label' => 'Completion Certificate Name -LVC ',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $this->addElement('text', 'completion_lvc_displayName', array(
                'label' => 'Completion Certificate Display Name -LVC',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $obj = new Model_Accreditors();
            $this->addElement('select', 'completion_lvc_accreditor_id_1', array(
                'label' => 'Completion Certificate Accreditors -LVC',
                'required' => false,
                'registerInArrayValidator' => false,
                'multioptions' => array('0' => '--Select--') + $obj->fetchForSelect()
            ));

            $this->addElement('select', 'completion_lvc_accreditor_id_2', array(
                'label' => 'Completion Certificate Accreditors 2-LVC',
                'required' => false,
                'registerInArrayValidator' => false,
                'multioptions' => array('0' => '--Select--') + $obj->fetchForSelect()
            ));

            $this->addElement('text', 'completion_lvc_activityNumber', array(
                'label' => 'Completion Certificate Activity Number -LVC',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $this->addElement('text', 'completion_lvc_pdu', array(
                'label' => 'Completion Certificate PDU Number -LVC',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $this->addElement('text', 'completion_lvc_oneLiner', array(
                'label' => 'Completion Certificate Message -LVC',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $this->addElement('hidden', 'completion_lvc_certificateType', array(
                'required' => false,
                'value' => 'completion'
            ));

            $this->addElement('hidden', 'completion_lvc_training_id', array(
                'required' => true,
                'value' => BaseApp_Dao_TrainingTypes::TYPE_LVC
            ));

            /* Ends Completion Certificates for LVC */
        } elseif ($this->_trainingId == BaseApp_Dao_TrainingTypes::TYPE_ELEARNING) {
            /* PDU for Online */

            $this->addElement('text', 'pdu_osl_name', array(
                'label' => 'PDU Certificate Name',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $this->addElement('text', 'pdu_osl_displayName', array(
                'label' => 'PDU Certificate Display Name',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $obj = new Model_Accreditors();
            $this->addElement('select', 'pdu_osl_accreditor_id_1', array(
                'label' => 'PDU Certificate Accreditors 1',
                'required' => false,
                'registerInArrayValidator' => false,
                'multioptions' => array('0' => '--Select--') + $obj->fetchForSelect()
            ));

            $this->addElement('select', 'pdu_osl_accreditor_id_2', array(
                'label' => 'PDU Certificate Accreditors 2',
                'required' => false,
                'registerInArrayValidator' => false,
                'multioptions' => array('0' => '--Select--') + $obj->fetchForSelect()
            ));

            $this->addElement('text', 'pdu_osl_activityNumber', array(
                'label' => 'PDU Certificate Activity Number',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $this->addElement('text', 'pdu_osl_pdu', array(
                'label' => 'PDU Certificate PDU Number',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $this->addElement('text', 'pdu_osl_oneLiner', array(
                'label' => 'PDU Certificate PDU Message',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext',
            ));

            $this->addElement('hidden', 'pdu_osl_certificateType', array(
                'required' => false,
                'value' => 'pdu'
            ));

            $this->addElement('hidden', 'pdu_osl_training_id', array(
                'required' => true,
                'value' => BaseApp_Dao_TrainingTypes::TYPE_ELEARNING
            ));

            /* Ends PDU for Online */

            /* Starts Completion for Online */

            $this->addElement('text', 'completion_osl_name', array(
                'label' => 'Completion Certificate Name',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $this->addElement('text', 'completion_osl_displayName', array(
                'label' => 'Completion Certificate Display Name',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $obj = new Model_Accreditors();
            $this->addElement('select', 'completion_osl_accreditor_id_1', array(
                'label' => 'Completion Certificate Accreditors 1',
                'required' => false,
                'registerInArrayValidator' => false,
                'multioptions' => array('0' => '--Select--') + $obj->fetchForSelect()
            ));

            $this->addElement('select', 'completion_osl_accreditor_id_2', array(
                'label' => 'Completion Certificate Accreditors 1',
                'required' => false,
                'registerInArrayValidator' => false,
                'multioptions' => array('0' => '--Select--') + $obj->fetchForSelect()
            ));

            $this->addElement('text', 'completion_osl_activityNumber', array(
                'label' => 'Completion Certificate Activity Number',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $this->addElement('text', 'completion_osl_pdu', array(
                'label' => 'Completion Certificate PDU Number',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $this->addElement('text', 'completion_osl_oneLiner', array(
                'label' => 'Completion Certificate Message',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $this->addElement('hidden', 'completion_osl_certificateType', array(
                'required' => false,
                'value' => 'completion'
            ));

            $this->addElement('hidden', 'completion_osl_training_id', array(
                'required' => true,
                'value' => BaseApp_Dao_TrainingTypes::TYPE_ELEARNING
            ));
            /* Ends Completion for Online */
        } elseif ($this->_trainingId == BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS) {
            /* PDU for Online */

            $this->addElement('text', 'pdu_slvc_name', array(
                'label' => 'PDU Certificate Name',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $this->addElement('text', 'pdu_slvc_displayName', array(
                'label' => 'PDU Certificate Display Name',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $obj = new Model_Accreditors();
            $this->addElement('select', 'pdu_slvc_accreditor_id_1', array(
                'label' => 'PDU Certificate Accreditors 1',
                'required' => false,
                'registerInArrayValidator' => false,
                'multioptions' => array('0' => '--Select--') + $obj->fetchForSelect()
            ));

            $this->addElement('select', 'pdu_slvc_accreditor_id_2', array(
                'label' => 'PDU Certificate Accreditors 2',
                'required' => false,
                'registerInArrayValidator' => false,
                'multioptions' => array('0' => '--Select--') + $obj->fetchForSelect()
            ));

            $this->addElement('text', 'pdu_slvc_activityNumber', array(
                'label' => 'PDU Certificate Activity Number',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $this->addElement('text', 'pdu_slvc_pdu', array(
                'label' => 'PDU Certificate PDU Number',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $this->addElement('text', 'pdu_slvc_oneLiner', array(
                'label' => 'PDU Certificate PDU Message',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext',
            ));

            $this->addElement('hidden', 'pdu_slvc_certificateType', array(
                'required' => false,
                'value' => 'pdu'
            ));

            $this->addElement('hidden', 'pdu_slvc_training_id', array(
                'required' => true,
                'value' => BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS
            ));

            /* Ends PDU for Online */

            /* Starts Completion for Online */

            $this->addElement('text', 'completion_slvc_name', array(
                'label' => 'Completion Certificate Name',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $this->addElement('text', 'completion_slvc_displayName', array(
                'label' => 'Completion Certificate Display Name',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $obj = new Model_Accreditors();
            $this->addElement('select', 'completion_slvc_accreditor_id_1', array(
                'label' => 'Completion Certificate Accreditors 1',
                'required' => false,
                'registerInArrayValidator' => false,
                'multioptions' => array('0' => '--Select--') + $obj->fetchForSelect()
            ));

            $this->addElement('select', 'completion_slvc_accreditor_id_2', array(
                'label' => 'Completion Certificate Accreditors 1',
                'required' => false,
                'registerInArrayValidator' => false,
                'multioptions' => array('0' => '--Select--') + $obj->fetchForSelect()
            ));

            $this->addElement('text', 'completion_slvc_activityNumber', array(
                'label' => 'Completion Certificate Activity Number',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $this->addElement('text', 'completion_slvc_pdu', array(
                'label' => 'Completion Certificate PDU Number',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $this->addElement('text', 'completion_slvc_oneLiner', array(
                'label' => 'Completion Certificate Message',
                'required' => false,
                'filters' => array('StringTrim'),
                'class' => 'longtext'
            ));

            $this->addElement('hidden', 'completion_slvc_certificateType', array(
                'required' => false,
                'value' => 'completion'
            ));

            $this->addElement('hidden', 'completion_slvc_training_id', array(
                'required' => true,
                'value' => BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS
            ));
            /* Ends Completion for Online */
        }
        $this->addElement('submit', 'Save', array(
            'ignore' => true,
            'label' => 'Save'
        ));
        $this->addElement('button', 'Cancel', array(
            'label' => 'Cancel',
            'ignore' => true,
            'id' => 'cancel_form',
            'class' => 'btn btn-warning'
        ));
    }

    protected function getSubFormDecoratorsMain($className, $id) {
        return array(
            'FormElements',
            array(
                'HtmlTag', array('tag' => 'ul')
            ),
            array(
                array('row' => 'HtmlTag'),
                array('tag' => 'li', 'class' => $className, 'id' => $id)
            )
        );
    }

    public function removeUneditableElements() {
        return false;
    }

}
