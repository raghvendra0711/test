<?php
class Form_UploadForm extends BaseApp_Form{
    const RESOURCE_PHOTO_PATH = 'images/common';
    public function init(){
        $this->setName('uploadform');
        $this->addAttribs(array('action' => BACKEND_URL . "/api/v3/upload-file"));
        $this->addAttribs(array('enctype' => 'multipart/form-data'));
       
        $this->addElement('file','uploadfile',array(
            'label'=>'Add Image',
        ));
        
        $this->addElement('submit','uploadimagebtn',array(            
            'ignore'=>true,
            'label' => 'Upload'
        )); 
        $this->addElement('hidden','sourceform');
        $this->addElement('hidden','form_name');        
    }
}