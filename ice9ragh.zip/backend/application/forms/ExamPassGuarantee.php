<?php

class Form_ExamPassGuarantee extends BaseApp_SubForm {

    private $_trainingId = '';
    private $_showAnswerField = true;
    private $_allCountryDisable = false;
    private $_showB2bB2c = true;

    public function __construct($trainingId ='',$showAnswerField=true,$allCountryDisable = false,$showB2bB2c=true) {
        $this->_trainingId = $trainingId;
        $this->_showAnswerField = $showAnswerField;
        $this->_allCountryDisable = $allCountryDisable;
        $this->_showB2bB2c = $showB2bB2c;
        parent::__construct();
    }

    public function init() {
        $this->setName('courseContent');
        $this->setMethod('post');
        $validatorsExamPassText = array(new Zend_Validate_StringLength(array('max' => 700)));
        //adding Label name element
        $session = new Zend_Session_Namespace('form');
        $subForm = new Zend_Form_SubForm();
        $subForm->setName('contentCourse');
        foreach ($session->contentCourse as $product) {
            $examPassId =  isset($session->contentCourseData[$product]['faq_id']) ? $session->contentCourseData[$product]['faq_id'] : '';
            /**
             * we are saving exam pass text in courseFaq table in question field
             */
            $keyAnswer =  isset($session->contentCourseData[$product]['question']) ? $session->contentCourseData[$product]['question'] : '';

            $isB2BValue = isset($session->contentCourseData[$product]['is_b2b']) ? $session->contentCourseData[$product]['is_b2b'] : null;
            $isB2CValue = isset($session->contentCourseData[$product]['is_b2c']) ? $session->contentCourseData[$product]['is_b2c'] : 1;
            $keyCountryIds = isset($session->contentCourseData[$product]['countryIds']) ? $session->contentCourseData[$product]['countryIds'] : array();
            $keyClusterIds = isset($session->contentCourseData[$product]['clusterIds']) ? $session->contentCourseData[$product]['clusterIds'] : array();
            $allCountriesFlag = isset($session->contentCourseData[$product]['allCountries']) ? $session->contentCourseData[$product]['allCountries'] : 0;
            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);
            $classfck = 'fck-enable';
            if ($product === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
                $classfck = '';
            }
            $resourceIdDom = new Zend_Form_Element_Hidden('course_faq_id');
            $resourceIdDom->setValue($examPassId)->clearDecorators();
            //Country
            $country = new Zend_Form_Element_Select('country_id');
            $countryModel = new Model_Country();
            $keyCountry = !empty($keyCountryIds) ? explode(',', $keyCountryIds) : array();
            $country->setOptions(array('required' => false, 'multiple' => true, 'multioptions' => $countryModel->getListDisplay()))
                    ->setValue($keyCountry)->setAttrib('class', 'courseListAll countryListAll skipPreviousClick')
                    ->setLabel('Country')
                    ->setRegisterInArrayValidator(false);

            //Cluster
            $cluster = new Zend_Form_Element_Select('cluster_id');
            $clusterModel = new Model_Clusters();
            $keyCluster = !empty($keyClusterIds) ? explode(',', $keyClusterIds) : array();
            $cluster->setOptions(array('required' => false, 'multiple' => true, 'multioptions' => $clusterModel->fetchForSelect()))
                    ->setValue($keyCluster)->setAttrib('class', 'multiple clusterListAll selectedCluster')
                    ->setLabel('Cluster')
                    ->setAttrib('data-last-selected',$keyClusterIds)
                    ->setAttrib('onchange', 'countryByClusterSelect(this)')
                    ->setAttrib('data-isedit',!empty($faqId) ? true : false)
                    ->setRegisterInArrayValidator(false);

            //Check All Countries
            $allCountryChecked = 0;
            $isClusterCountryDisabled = false;
            if (empty($keyCluster) && empty($keyCountry)) {
                $allCountryChecked = 1;
                $isClusterCountryDisabled = true;
            }
            if (!empty($allCountriesFlag) && $allCountriesFlag == 1) {
                $allCountryChecked = 1;
            }
            $checkAllCountry = new Zend_Form_Element_Checkbox('all_country');
            $checkAllCountry->setValue($allCountryChecked)->setLabel('All Countries')->setAttrib('onclick', 'checkAllCountry(this)')->setAttrib('class','allCountry');

            if ($isClusterCountryDisabled) {
                $cluster->setOptions(array('disabled' => true));
                $country->setOptions(array('disabled' => true));
            }
            if($this->_allCountryDisable){
                $checkAllCountry->setAttrib('onclick','return false')->setAttrib('style', 'opacity: 0.5;');;
            }
            $isB2b = new Zend_Form_Element_Checkbox('is_b2b');
            $isB2b->addFilter('stringTrim')->setValue($isB2BValue)->setAttrib('class', '')->setLabel('Is B2B');
            $isB2C = new Zend_Form_Element_Checkbox('is_b2c');
            $isB2C->addFilter('stringTrim')->setValue($isB2CValue)->setAttrib('class', '')->setLabel('Is B2C');
            
            /**
             * we are saving is Exam enabled status in courseFaq table in isProplus field
             */

            $is_exam =  isset($session->contentCourseData[$product]['isProplus']) ? $session->contentCourseData[$product]['isProplus'] : '';
            $is_exam_pass = new Zend_Form_Element_Checkbox('isProplus');
            $is_exam_pass->addFilter('stringTrim')->setValue($is_exam)->setAttrib('class', '')->setLabel('Enable Exam Pass Guarantee');

            if(!$this->_showB2bB2c){
                $isB2b->setAttrib('class','hideB2bB2c'); //class added to hide this dom
                $isB2C->setAttrib('class','hideB2bB2c');
            }

            $answer = new Zend_Form_Element_Textarea('question');
            $answer->addFilter('stringTrim')->setValue($keyAnswer)->setAttrib('class','longtext examPass')->setAttrib('rows', 5)->setAttrib('cols', 60)->setLabel('Exam Pass Guarantee Text*')->addValidators($validatorsExamPassText);

            $removeFaq = new Zend_Form_Element_Button('remove');
            $removeFaq->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');
            //Invert Selection
            $invertBtn = new Zend_Form_Element_Button('invert');
            $invertBtn->setLabel('Invert Countries')->setAttrib('class', 'btn btn-warning remove invert-all')->setAttrib('onclick', 'invertSelection(this)');
            if($allCountryChecked){
                $invertBtn->setOptions(array('disabled' => true));
            }
            $elements = array();
            if($this->_showAnswerField){
                $elements = array( $is_exam_pass,$answer, $checkAllCountry, $cluster, $country, $invertBtn,$isB2C, $isB2b,$resourceIdDom);
            }else{
                $elements = array($is_exam_pass,$checkAllCountry, $cluster, $country, $invertBtn, $isB2C, $isB2b, $resourceIdDom);
            }
            if ($product !== 'new') {
                $elements[] = $removeFaq;
            }
            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());
            if ($rowForm->getElement('remove')) {
                $rowForm->getElement('remove')->removeDecorator('Label');
            }
            if ($rowForm->getElement('invert')) {
                $rowForm->getElement('invert')->removeDecorator('Label');
            }
            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        }
        $subForm->setDecorators($this->getSubFormDecoratorsMain('course-faq-editor', 'contentCourse'));
        $this->addSubForm($subForm, 'contentCourse');
        $this->addElement('submit', 'Save', array(
            'ignore' => true,
            'label' => 'Save'
        ));
    }

    protected function getSubFormDecoratorsMain($className, $id) {
        return array(
            'FormElements',
            array(
                'HtmlTag', array('tag' => 'ul')
            ),
            array(
                array('row' => 'HtmlTag'),
                array('tag' => 'li', 'class' => $className, 'id' => $id)
            )
        );
    }

    public function removeUneditableElements() {
        return false;
    }

    public function isValid($data, &$errorMessage='',$showAnswerField=true) {
        $status = parent::isValid($data);
        if (!empty($data['contentCourse'])) {
            $subForm = 'contentCourse';
            foreach ($data['contentCourse'] as $key => $row) {
                if (empty($row['all_country']) && !isset($row['cluster_id']) && !isset($row['country_id'])) {
                    $status = false;
                    $this->getSubForm($subForm)->getSubForm($key)->getElement('all_country')->setErrors(array(" Please select either All Countries or Cluser & Country"));
                }
                if (empty($row['question'])) {
                    $status = false;
                    $this->getSubForm($subForm)->getSubForm($key)->getElement('question')->setErrors(array("Exam Pass Guarantee Text."));
                }
                if (empty($row['is_b2c']) && empty($row['is_b2b'])) {
                    $status = false;
                    $this->getSubForm($subForm)->getSubForm($key)->getElement('is_b2b')->setErrors(array("Please select atleast one of Is B2C or Is B2B."));
                }
            }
        }
        return $status;
    }
}
