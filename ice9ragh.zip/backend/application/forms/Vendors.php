<?php

class Form_Vendors extends BaseApp_Form
{
    private $_vData = array();
    public function init(){
        $this->setName('Venues');
        $this->setMethod('post');

        $validatorsShortDesc = array(new Zend_Validate_StringLength(array('min' => 2,'max'=>70)));
        $validatorsIntroText = array(new Zend_Validate_StringLength(array('min' => 2,'max'=>500)));

        $this->addElement('text','name',array(
            'label'=>'Name',
            'required'=>true,
            'cols' => 60,
            'rows' => 6,
            'class'=>'longtext',
            'validators' => array(
                new Zend_Validate_Db_NoRecordExists(array(
                    'table' => 'vendors',
                    'field' => 'name'
                )),
                new Zend_Validate_NotEmpty()
            )
        ));

         $this->addElement('textarea','shortDescription',array(
            'label'=>'A small description*',
            'required'=>true,
            'rows' => 5,
            'cols' => 60,
            'filters'=>array('StringTrim'),
            'class'=>'description',
            'validators' => $validatorsShortDesc
        ));

        $this->addElement('textarea','introText',array(
                'label'=>'Intro Text for Vendor*',
                'required'=>true,
                'filter'=>array('StringTrim'),
                'rows' => 5,
                'cols' => 60,
                'class'=>'description',
                'validators' => $validatorsIntroText
        ));

        $this->addElement('checkbox','isApproved',array(
                'label'=>'is Approved ?',
                'required'=>false
        ));

        $this->addElement('checkbox','isListView',array(
                'label'=>'Display List View ?',
                'required'=>false
        ));

         $this->addElement('text','imagePath',array(
            'label'=>'Image',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                new BaseApp_Validate_Image('labels', 'imagePath')
            )
        ));

        $this->addElement('text','imageDescription',array(
            'label'=>'Alt text',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

         $this->addElement('text','url',array(
            'label'=>'Url*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));


        $this->addElement('text','imagePath',array(
            'label'=>'Image',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                new BaseApp_Validate_Image('labels', 'imagePath')
            )
        ));

        $this->addElement('text','imageDescription',array(
            'label'=>'Alt text',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('text','videoLink',array(
            'label' => 'Embeded You Tube',
            'placeholder'=>" Please Enter A Embeded You Tube video Link",
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'description',
        ));

        $this->addElement('text','dateCreated',array(
            'label' => 'Video Uploaded date',
            'placeholder'=>"YYYY-MM-DD",
            'required'=>false,
            'filters'=>array('StringTrim'),
            'attribs' => array('readonly' => 'readonly'),
            'class'=>'longtext',
        ));

        $this->addElement('text','videoThumbnail',array(
            'label' => 'Video Thumbnail Image',
            'placeholder'=>" Please Enter video Thumbnail Image",
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
        ));

        $this->addElement('textarea','videoDescription',array(
            'label'=>'Video Description',
            'filter'=>array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'attribs' => array('readonly' => 'readonly'),
            'class'=>'description'
        ));

        $accreditorObj = new Model_Accreditors();
        $accreditorCond = array('isVendorCoursePage'=>1);
        $this->addElement('select', 'accreditor_id', array(
            'label' => 'Is the Course Accredited ?(Max 3 allowed)',
            'required' => false,
            'class' => 'multiple',
            'multiple' => true,
            'registerInArrayValidator' => false,
            'multioptions' => $accreditorObj->fetchForSelect($accreditorCond)
        ));

        $obj =new Model_ProductSectionData();
        $obj->setDisplayField('name');
        $this->addElement('select','company',array(
                'label'=>'Company Section(Max 5 allowed)',
                'required'=>false,
                'multiple' => true,
                'class' => 'multiple',
                'registerInArrayValidator' => false,
                'multioptions'=>array('0'=>'--Select--') + $obj->fetchForSelect(array('sectionType = ?' => "company"))
        ));

        $obj->setDisplayField('name');
        $this->addElement('select','course_advisor',array(
                'label'=>'Course Advisor Section',
                'required'=>false,
                'multiple' => true,
                'class' => 'multiple',
                'registerInArrayValidator' => false,
                'multioptions'=>array('0'=>'--Select--') + $obj->fetchForSelect(array('sectionType = ?' => "directors"))
        ));


        $obj->setDisplayField('name');
        $this->addElement('select','alumni',array(
                'label'=>'Alumni Section(Max 4 allowed)',
                'required'=>false,
                'multiple' => true,
                'class' => 'multiple',
                'registerInArrayValidator' => false,
                'multioptions'=>array('0'=>'--Select--') + $obj->fetchForSelect(array('sectionType = ?' => "Alumni"))
        ));

        $this->addElement('submit','AddVendor',array(
          'ignore'=>true,
          'label'=>'Add Vendor',
          'class'=>'btn btn-info'
         ));
    }

    public function removeOptionalValidators() {
        $this->getElement('name')->removeValidator('Db_NoRecordExists');
    }

    public function removeUneditableElements(){
        $this->removeElement('url');
        return false;
    }

    public function removeVideoElements(){
        $this->removeElement('dateCreated');
        $this->removeElement('videoDescription');
   }
    public function isValid($data) {
        $status = parent::isValid($data);
        if(!empty($data['url'])){
            $data['url'] = trim($data['url']);
            $checkSlash = substr($data['url'], 0,1);
            if($checkSlash != '/'){
                $data['url'] = trim('/'.$data['url']);
            }
            $objSeo = new Model_Seo();
            if(false === $objSeo->validateUrl($data['url'])){
                $this->getElement('url')->setErrors(array("'{$data['url']}' is not a valid article url"));
                return false;
            }
        }
        if($data['videoLink']){
            $videoLink = "";
            if (!empty($this->getView()->vendorId)) {
                $vendorId = $this->getView()->vendorId;
                $modelVideo = new Model_Videos();
                $videoData = $modelVideo->getByLinkableId($vendorId,'vendor', false, 'about_vendor');
                $videoLink = isset($videoData['videoLink']) ? $videoData['videoLink'] : "";
            }
            if (strpos( strtolower($data['videoLink']),'https://www.youtube.com/embed/' ) === false) {
                $this->getElement('videoLink')->setErrors(array("Link should be Https and also Emebed link"));
                $status = false;
            }else if($data['videoLink'] != $videoLink){
                $youtubeApi = new BaseApp_Utility_YoutubeApi();
                $this->_vData = $youtubeApi->getVideoDetails($data['videoLink'],"snippet,contentDetails");
                if(!is_array($this->_vData)){
                    if($this->_vData == BaseApp_Utility_YoutubeApi::INVALID_VIDEO){
                    $this->getElement('videoLink')->setErrors(array("Please enter valid youtube video link"));
                    }
                    else if ($this->_vData == BaseApp_Utility_YoutubeApi::LIMIT_ERROR) {
                        $this->getElement('videoLink')->setErrors(array("Daily limit for authenticated use exceeded"));
                    } else {
                        $this->getElement('videoLink')->setErrors(array("Something is wrong with api."));
                    }
                    $status = false;
                }
            }

            if(!$data['videoThumbnail']){
                $this->getElement('videoThumbnail')->setErrors(array("video thumb nail image required"));
                $status = false;
            }elseif (strpos( strtolower($data['videoThumbnail']),'https://img.youtube.com/' ) === false) {
                $this->getElement('videoThumbnail')->setErrors(array("Link should be Https and also Youtube link"));
                $status = false;
            }
        }
        return $status;
    }

    public function getVideoData(){
        return $this->_vData;
    }
}

