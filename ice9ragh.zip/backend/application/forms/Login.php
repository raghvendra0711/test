<?php

class Form_Login extends BaseApp_Form {

    public function init() {
        $this->setName('simplexLoginForm');
        $this->addElement('text', 'email', array(
            'label' => 'Email',
            'required' => true
        ));
        
        $this->addElement('password', 'password', array(
            'label' => 'Password',
            'required' => true
        ));
        
        $this->addElement('submit', 'submit', array(
            'label' => 'Login'
        ));
    }

}
