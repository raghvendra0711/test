<?php

class Form_CourseConversion extends BaseApp_SubForm
{
    public function init(){

        $this->setName('CourseConversion');
        $this->setMethod('post');
        
        $validatorsData = array(new Zend_Validate_StringLength(array('max' => 50)));
        $validatorsSource = array(new Zend_Validate_StringLength(array('max' => 30)));
        $validateUrl = array(new BaseApp_Validate_Url());
        
        $course = new Model_Courses();
        $this->addElement('select','linkable_id',array(
            'required'=>true,
            'label' => 'Primary Course*', 
            'multioptions'=>array('0'=>'--Select--') +$course->fetchForSelect(array('is_dummy = ?' => 0, 'is_free = ?' => 0))
         ));
        
        $this->addElement('checkbox','for_india',array(
            'label' => 'Show Data For India'
        ));
        $session = new Zend_Session_Namespace('form');
        
        $session->conversionIndiaData = array(
            'industry' => array(
                    'data' => '',
                    'source' => '',
                    'link' => ''
                ),
            'job' => array(
                    'data' => '',
                    'source' => '',
                    'link' => ''
                ),
            'salary' => array(
                    'data' => '',
                    'source' => '',
                    'link' => ''
                )
        );

         $subForm = new Zend_Form_SubForm();
         $subForm->setName('conversionForIndia');   
         foreach ($session->conversionIndiaData as $product => $productData) {
            $keyData = isset($productData['data'])?$productData['data']:'';
            $keySource = isset($productData['source'])?$productData['source']:'';
            $keyLink = isset($productData['link'])?$productData['link']:'';
            
            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);  
            
            
            $data = new Zend_Form_Element_Text('data');
            $data->addFilter('stringTrim')->setValue($keyData)->setAttrib('class', 'longtext')->setLabel('Data*')->addValidators($validatorsData);
            
            $source = new Zend_Form_Element_Text('source');
            $source->addFilter('stringTrim')->setValue($keySource)->setAttrib('class', 'longtext')->setLabel('Source*')->addValidators($validatorsSource);
            
            $link = new Zend_Form_Element_Text('link');
            $link->addFilter('stringTrim')->setValue($keyLink)->setAttrib('class', 'longtext')->setLabel('Link')->addValidators($validateUrl);
            

            
            $elements = array($data, $source, $link);            
            
            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());
            $rowForm->setLegend($product);
            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        }

        $subForm->setDecorators($this->getSubFormDecoratorsMain('course-conversion', 'conversionForIndia'));

        $subForm->setElementDecorators($this->getElementDecorators());
        $this->addSubForm($subForm, 'conversionForIndia');


        /* Start For Us */
        $this->addElement('checkbox','for_us',array(
            'label' => 'Show Data For Us/Row'
        ));

         $subForm = new Zend_Form_SubForm();
         $subForm->setName('conversionForUs');   
         foreach ($session->conversionIndiaData as $product => $productData) {
            $keyData = isset($productData['data'])?$productData['data']:'';
            $keySource = isset($productData['source'])?$productData['source']:'';
            $keyLink = isset($productData['link'])?$productData['link']:'';
            
            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);  
            
            
            $data = new Zend_Form_Element_Text('data');
            $data->addFilter('stringTrim')->setValue($keyData)->setAttrib('class', 'longtext')->setLabel('Data*')->addValidators($validatorsData);
            
            $source = new Zend_Form_Element_Text('source');
            $source->addFilter('stringTrim')->setValue($keySource)->setAttrib('class', 'longtext')->setLabel('Source*')->addValidators($validatorsSource);
            
            $link = new Zend_Form_Element_Text('link');
            $link->addFilter('stringTrim')->setValue($keyLink)->setAttrib('class', 'longtext')->setLabel('Link')->addValidators($validateUrl);
            
            $elements = array($data, $source, $link);            
            
            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());
            $rowForm->setLegend($product);
            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        }

        $subForm->setDecorators($this->getSubFormDecoratorsMain('course-conversion', 'conversionForUs'));

        $subForm->setElementDecorators($this->getElementDecorators());
        $this->addSubForm($subForm, 'conversionForUs');

        /* Ends For Us */

        $this->addElement('submit','AddConversion',array(
            'ignore'=>true,
            'label'=>'Add Course Conversion',
            'class'=>'btn btn-info'
        ));
    }

    protected function getSubFormDecoratorsMain($className, $id) {
        return array(   
            'FormElements',                        
            array(                
                'HtmlTag', array('tag' => 'ul')
            ),
            array(
                array('row' => 'HtmlTag'),                
                array('tag' => 'li', 'class' => $className, 'id' => $id)
            )
        );
    }

    public function isValid($data) {
        $status = parent::isValid($data);
        if(empty($data['linkable_id'])){
            $this->getElement('linkable_id')->setErrors(array("Course is Mandatory"));
            return false;
        }
        if( empty($data['for_india']) && empty($data['for_us'])){
            if(empty($data['for_india']))
                $this->getElement('for_india')->setErrors(array("Please select one or more countries to show data"));
            else
                $this->getElement('for_us')->setErrors(array("Please select one or more countries to show data"));
            return false;   
        }
        return $status;
    }
}
