<?php

class Form_KeyWordRankingCourse extends BaseApp_SubForm {

    public function init() {

        $this->setName('KeyWordRankingCourseForm');
        $this->setMethod('post');

        $this->addElement('text','coursename',array(
            'label'=>'Course Name*',
            'required'=>true,
            'class'=>'longtext',
           
        ));
              
        $this->addElement('submit','savecourse',array(
          'ignore'=>true,
          'label'=>'Save',
          'class'=>'btn btn-info'
         ));
        
        $this->addElement('submit','cancelcourse',array(
          'ignore'=>true,
          'label'=>'Cancel',
          'class'=>'btn btn-info'
         ));
        
        
        
      }
    
   

}
