<?php

class Form_CourseLinkBlock extends BaseApp_SubForm {
    private $_courseId  = 0;
    private $_countryId = 0;
    private $_clusterId = 0;

    public function __construct($courseId,$countryId=0,$clusterId=0) {
        $this->_courseId  = $courseId;
        $this->_countryId = $countryId;
        $this->_clusterId = $clusterId;
        parent::__construct();
    }

    public function init() {
        $this->setName('courseLinkBlock');
        $this->setMethod('post');
        //adding Label name element
        $session = new Zend_Session_Namespace('form');

        $subForm = new Zend_Form_SubForm();
        $subForm->setName('contentCourse');
        foreach ($session->contentCourse as $product) {
            //$keyCountryIds      = isset($session->contentCourseData[$product]['country_id']) ? $session->contentCourseData[$product]['country_id'] : array();
            $keyClusterIds        = isset($session->contentCourseData[$product]['cluster_id']) ? $session->contentCourseData[$product]['cluster_id'] : array();
            //$allCountriesFlag   = isset($session->contentCourseData[$product]['allCountries']) ? $session->contentCourseData[$product]['allCountries'] : 0;
            if(!empty($keyClusterIds) && is_array($keyClusterIds)){
                $keyClusterIds    = implode(',',$keyClusterIds);
            }
            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);

            $classfck = 'fck-enable';
            if ($product === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
                $classfck = '';
            }

            $clusterModel = new Model_Clusters();
            $countryModel = new Model_Country();
            if( empty($this->_countryId) && empty($this->_clusterId) ){
                //Country
                $country = new Zend_Form_Element_Select('country_id');
                $keyCountry = !empty($keyCountryIds) ? explode(',', $keyCountryIds) : array();
                $countryList = $countryModel->getListDisplay();
                $country->setOptions(array('required' => false, 'multiple' => true, 'multioptions' => $countryList))
                        ->setValue($keyCountry)->setAttrib('class', 'courseListAll countryListAll skipPreviousClick')
                        ->setLabel('Country')
                        ->setRegisterInArrayValidator(false);
                
                $countryErrHidden = new Zend_Form_Element_Hidden('country_id_err');

                $keyCluster = !empty($keyClusterIds) ? explode(',', $keyClusterIds) : array();
                //Cluster
                $cluster = new Zend_Form_Element_Select('cluster_id');
                $clusterList = $clusterModel->fetchForSelect();
                $cluster->setOptions(array('required' => false, 'multiple' => true, 'multioptions' => $clusterList))
                        ->setValue($keyCluster)->setAttrib('class', 'multiple clusterListAll selectedCluster')
                        ->setLabel('Cluster')
                        ->setAttrib('data-last-selected',$keyClusterIds)
                        ->setAttrib('onchange', 'countryByClusterSelect(this)')
                        ->setAttrib('data-isedit',!empty($faqId) ? true : false)
                        ->setRegisterInArrayValidator(false);
                
                $clusterErrHidden = new Zend_Form_Element_Hidden('cluster_id_err');
                
                //Check All Countries
                $allCountryChecked = 0;
                $isClusterCountryDisabled = false;
                if (empty($keyCluster) && empty($keyCountry)) {
                    $allCountryChecked = 1;
                    $isClusterCountryDisabled = true;
                }
                if (!empty($allCountriesFlag) && $allCountriesFlag == 1) {
                    $allCountryChecked = 1;
                }
                //$checkAllCountry = new Zend_Form_Element_Checkbox('all_country');
                //$checkAllCountry->setValue($allCountryChecked)->setLabel('All Countries')->setAttrib('onclick', 'checkAllCountry(this)')->setAttrib('class','allCountry');

                if ($isClusterCountryDisabled) {
                    $cluster->setOptions(array('disabled' => true));
                    $country->setOptions(array('disabled' => true));
                }
            }else{
                if(!empty($this->_countryId)){
                    $countryInfo    = $countryModel->getById($this->_countryId);
                    if(isset($countryInfo[$this->_countryId])){
                        $countryName    = $countryInfo[$this->_countryId];
                        $countryText    = new Zend_Form_Element_Text('country_text');
                        $countryText->addFilter('stringTrim')
                                ->setValue($countryName)
                                ->setAttrib('helper', 'formNote')
                                ->setLabel('Country');
                    }
                }
            
                if(!empty($this->_clusterId)){
                    $clusterInfo    = $clusterModel->getById($this->_clusterId);
                    if(isset($clusterInfo[$this->_clusterId])){
                        $clusterName    = $clusterInfo[$this->_clusterId];
                        $clusterText    = new Zend_Form_Element_Text('cluster_text');
                        $clusterText->addFilter('stringTrim')
                                ->setValue($clusterName)
                                ->setAttrib('helper', 'formNote')
                                ->setLabel('Cluster');
                    }
                }
            }
            
            $course = new Zend_Form_Element_Select('course_id');
            $courseModel = new Model_Courses();
            $keyCourse = !empty($keyCourseIds) ? explode(',', $keyCourseIds) : array();
            //$coursesList =  $courseModel->getCoursesByPricing();
            $coursesList =  $courseModel->fetchForSelect(array('is_dummy = ?' => 0, 'is_free = ?' => 0));
            array_walk($coursesList, function(&$item,$key){$item = $item.' ('.$key.')';});
            $course->setOptions(array('required' => false, 'multiple' => true, 'multioptions' => $coursesList))
                    ->setValue($keyCourse)->setAttrib('class', 'courseListAll countryListAll skipPreviousClick')
                    ->setLabel('Select Related Course (Max 5)')
                    ->setRegisterInArrayValidator(false);
            $courseHidden = new Zend_Form_Element_Hidden('course_id_sorted_list');
            $bundle = new Zend_Form_Element_Select('bundle_id');
            $bundleModel = new Model_Bundles();
            $keyBundle = !empty($keyBundleIds) ? explode(',', $keyBundleIds) : array();
            //$bundlessList = $bundleModel->getBundlesByPricings();
            $bundlessList = $bundleModel->fetchForSelect();
            array_walk($bundlessList, function(&$item,$key){$item = $item.' ('.$key.')';});
            $bundle->setOptions(array('required' => false, 'multiple' => true, 'multioptions' => $bundlessList))
                    ->setValue($keyBundle)->setAttrib('class', 'courseListAll countryListAll skipPreviousClick')
                    ->setLabel('Select Related Masters Programs (Max 2)')
                    ->setRegisterInArrayValidator(false);
            $bundleHidden = new Zend_Form_Element_Hidden('bundle_id_sorted_list');

            if( empty($this->_countryId) && empty($this->_clusterId) ){
                $elements = array($cluster,$country,$clusterErrHidden,$countryErrHidden,$bundle, $course,$courseHidden,$bundleHidden);
            }else{
                if(!empty($this->_countryId)){
                    $elements = array($countryText,$bundle,$course,$courseHidden,$bundleHidden);
                }else{
                    $elements = array($clusterText,$bundle,$course,$courseHidden,$bundleHidden);
                }
            }
            

            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());

            if ($rowForm->getElement('remove')) {
                $rowForm->getElement('remove')->removeDecorator('Label');
            }

            if ($rowForm->getElement('invert')) {
                $rowForm->getElement('invert')->removeDecorator('Label');
            }

            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        }

        $subForm->setDecorators($this->getSubFormDecoratorsMain('course-faq-editor', 'contentCourse'));
        /* if ($this->_addMoreButton) {
            $addFaq = new Zend_Form_Element_Button('add');
            $addFaq->setLabel('Add More')->setAttrib('class', 'btn btn-warning add');
            $subForm->addElement($addFaq);

            $subForm->setElementDecorators($this->getElementDecorators());
            $subForm->getElement('add')->removeDecorator('Label');
        } */

        $this->addSubForm($subForm, 'contentCourse');


        $this->addElement('submit', 'Save', array(
            'ignore' => true,
            'label' => 'Save'
        ));
        $this->addElement('button', 'Cancel', array(
            'label' => 'Cancel',
            'ignore' => true,
            'id' => 'cancel_form',
            'class' => 'btn btn-warning'
        ));
    }

    protected function getSubFormDecoratorsMain($className, $id) {
        return array(
            'FormElements',
            array(
                'HtmlTag', array('tag' => 'ul')
            ),
            array(
                array('row' => 'HtmlTag'),
                array('tag' => 'li', 'class' => $className, 'id' => $id)
            )
        );
    }

    public function removeUneditableElements() {
        return false;
    }

    public function isValid($data, &$errorMessage='',$showAnswerField=true) {
        $status = parent::isValid($data);
        if (!empty($data['contentCourse'])) {
            $subForm = 'contentCourse';
            foreach ($data['contentCourse'] as $key => $row) {
                if( empty($this->_countryId) && empty($this->_clusterId) && !isset($row['cluster_id']) && !isset($row['country_id']) ) {
                    $status = false;
                    $this->getSubForm($subForm)->getSubForm($key)->getElement('country_id')->setErrors(array(" Please select Cluster or Country"));
                }
                if(empty($row['course_id_sorted_list']) && empty($row['bundle_id_sorted_list'])) {
                    $status = false;
                    $this->getSubForm($subForm)->getSubForm($key)->getElement('course_id')->setErrors(array(" Please select Course or Master Program"));
                }
            }
        }
        if (!empty($data['contentCourse']) && empty($this->_countryId) && empty($this->_clusterId)) {
            if(!empty($data['contentCourse']['new']['cluster_id']) && !empty($data['contentCourse']['new']['country_id'])) {
                $countryObj = new Model_Country();
                $data['contentCourse']['new']['country_id'] =  $countryObj->removeClusterCountries($data['contentCourse']['new']['cluster_id'], $data['contentCourse']['new']['country_id']);
            }
            $objCourselinkBlock = new Model_CourseLinkBlock();
            $clusterModel       = new Model_Clusters();
            $countryModel       = new Model_Country();
            $countryList    = $countryModel->getListDisplay();
            $clusterList    = $clusterModel->fetchForSelect();
            if(!empty($data['contentCourse']['new']['country_id'])){
                $countryIds     = $data['contentCourse']['new']['country_id'];
            }
            if(!empty($data['contentCourse']['new']['cluster_id'])){
                $clusterIds     = $data['contentCourse']['new']['cluster_id'];
            }
            
            $relCourseIds   = explode(',', $data['contentCourse']['new']['course_id_sorted_list']);
            $relBundleIds   = explode(',', $data['contentCourse']['new']['bundle_id_sorted_list']);

            $subForm = 'contentCourse';
            if (!empty($countryIds)) {
                foreach ($countryIds as $countryId) {
                    $existRelCourses = $objCourselinkBlock->getCourseContent($this->_courseId,$countryId,0);
                    $allRelCourses   = array_filter(array_unique (array_merge ($relCourseIds, $existRelCourses['course_id'])));
                    if( count($allRelCourses) > 5 ){
                        $status = false;
                        $this->getSubForm($subForm)->getSubForm('new')->getElement('country_id_err')->setErrors(array(" Course limit exceeded for country ".$countryList[$countryId].", please deselect ".$countryList[$countryId]));
                    }
                    $allRelBundles   = array_filter(array_unique (array_merge ($relBundleIds, $existRelCourses['bundle_id'])));
                    if( count($allRelBundles) > 2 ){
                        $status = false;
                        $this->getSubForm($subForm)->getSubForm('new')->getElement('country_id_err')->setErrors(array(" Master program limit exceeded for country ".$countryList[$countryId].", please deselect ".$countryList[$countryId]));
                    }
                }
            }
            
            if (!empty($clusterIds)) {
                foreach ($clusterIds as $clusterId) {
                    $existRelCourses = $objCourselinkBlock->getCourseContent($this->_courseId,0,$clusterId);
                    $allRelCourses   = array_filter(array_unique (array_merge ($relCourseIds, $existRelCourses['course_id'])));
                    if( count($allRelCourses) > 5 ){
                        $status = false;
                        $this->getSubForm($subForm)->getSubForm('new')->getElement('cluster_id_err')->setErrors(array(" Course limit exceeded for cluster ".$clusterList[$clusterId].", please deselect ".$clusterList[$clusterId]));
                    }
                    $allRelBundles   = array_filter(array_unique (array_merge ($relBundleIds, $existRelCourses['bundle_id'])));
                    if( count($allRelBundles) > 2 ){
                        $status = false;
                        $this->getSubForm($subForm)->getSubForm('new')->getElement('cluster_id_err')->setErrors(array(" Master program limit exceeded for cluster ".$clusterList[$clusterId].", please deselect ".$clusterList[$clusterId]));
                    }
                }
            }
        }
        return $status;
    }
}
