<?php 
class Form_PracticeTest extends BaseApp_SubForm
{       
    protected $submitName = 'Save';
    
    public function init(){
        $this->setName('practicetests');
        $this->setMethod('post');
        
         //adding Label name element
        $validatorsMetaDescription = array(new Zend_Validate_StringLength(array('max' => 120)));
        $validatorsDescription = array(new Zend_Validate_StringLength(array('max' => 1000)));
        
        $model_pt = new Model_FreePracticeTest();
        $course = new Model_Courses();
        $bundle = new Model_Bundles();       

        $courseArr = $course->fetchForSelect(array('is_dummy = ?' => 0, 'is_free = ?' => 0));
        $courses = array();
        foreach ($courseArr as $key => $value) {
            $nKey = $key . '#'.Model_Courses::PRODUCT_TYPE_NAME;
            $courses[$nKey] = $value . ' || ' . Model_Courses::PRODUCT_TYPE_NAME . ' || ' . $key;
        }
        $bundleArr = $bundle->fetchForSelect(array());
        $bundles = array();
        foreach ($bundleArr as $key => $value) {
            $nKey = $key . '#'.Model_Bundles::PRODUCT_TYPE_NAME;
            $bundles[$nKey] = $value . ' || ' . Model_Bundles::PRODUCT_TYPE_NAME . ' || ' . $key;
        }
        unset($courseArr,$bundleArr);
        $this->addElement('radio','test_type',array(
            'label' =>'type',
            'required'=>true,
            'separator' => '',
            'multioptions'=>array('free_practice_test' => 'Free Practice Test','scholarship_test' => 'Scholarship Test'),
            'value' => 'free_practice_test' 
        ));
        $this->addElement('select','primary_product_id',array(
            'required'=>false,
            'label' => 'Primary Product*',
            'onchange' => 'SimplexFptCrud.getSearchTags(this)', 
            'registerInArrayValidator' => false,
            'multioptions'=>array('' => '--Select--')+$courses+$bundles,
            'class'=>'fpt-type'
        ));

        $this->addElement('select','primary_bundle_id',array(
            'required'=>false,
            'label' => 'Primary Product*',
            'onchange' => 'SimplexFptCrud.getSearchTags(this)', 
            'registerInArrayValidator' => false,
            'multioptions'=>array('' => '--Select--')+$bundles,
            'class'=>'scholar-type'
        ));
        
        $this->addElement('select','secondary_product',array(
            'required'=>false,
            'label' => 'Secondary Product', 
            'registerInArrayValidator' => false,
            'multiple' => 'multiple',
            'attribs' => array ('style' => 'height: 150px'),
            'multioptions'=>$courses+$bundles,
            'class'=>'fpt-type'
        ));

        $this->addElement('select','secondary_bundle_id',array(
            'required'=>false,
            'label' => 'Secondary Product', 
            'registerInArrayValidator' => false,
            'multiple' => 'multiple',
            'attribs' => array ('style' => 'height: 150px'),
            'multioptions'=>$bundles,
            'class'=>'scholar-type'
        ));
        
        $this->addElement('select','paperclip_testId',array(
            'required'=>true,
            'label' => 'Paper Clip Test*', 
            'registerInArrayValidator' => false,
            'multioptions'=>array('' => '--Select--')+$model_pt->paperclip_fpt_forselect()
        ));
        
        $this->addElement('text','name',array(
            'label'=>'Name of Test*',
            'required'=>true,
            'class'=>'longtext'
        ));  
        
        $this->addElement('textarea','shortDescription',array(
            'label'=>'Description*',
            'required'=>true,
            'filter'=>array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class'=>'description'
        )); 

        $this->addElement('textarea','metaDescription',array(
            'label'=>'Meta Description*',
            'required'=>false,
            'filter'=>array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'maxlength' => 120,
            'class'=>'description fpt-type',
        ));

        $this->addElement('text','noOfQuestions',array(
            'label'=>'No. of Questions*',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'shorttext scholar-type',
        )); 
        
        $this->addElement('text','testTime',array(
            'label'=>'Test Time (Minutes)*',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'shorttext scholar-type',
        ));  
        
        $this->addElement('text','url',array(
            'label'=>'URL for Practice Test*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));  

        $this->addElement('text','tag',array(
            'label'=>'Tags',
            'id'=>'fptSearchtag',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext fpt-type'
        ));  
        $this->postSetup();
        $this->getElement('shortDescription')->addValidators($validatorsDescription);
        $this->getElement('metaDescription')->addValidators($validatorsMetaDescription);
    }      
    
    public function removeUneditableElements(){
        $this->removeElement('url');
        $this->removeElement('paperclip_testId');
        return false;
    }
    
    public function removeTestElements($testType){
        $this->removeElement('test_type');
        if($testType == "scholarship_test"){
            $this->removeElement('metaDescription');
            $this->removeElement('tag');
            $this->removeElement('primary_product_id');
            $this->removeElement('secondary_product');
        }
        else{
            $this->removeElement('noOfQuestions');
            $this->removeElement('testTime');
            $this->removeElement('primary_bundle_id');
            $this->removeElement('secondary_bundle_id');
        }
        return false;
    } 
    
    public function isValid($data) { 
        $primaryProduct = "";
        $hasErrors = false;
        if(!empty($data['test_type'])){
            if($data['test_type'] == "free_practice_test"){
                $this->getElement('metaDescription')->setRequired(true);
                $this->getElement('primary_product_id')->setRequired(true);
            }
            else if($data['test_type'] == "scholarship_test"){
                $this->getElement('noOfQuestions')->setRequired(true);
                $this->getElement('testTime')->setRequired(true);
                $this->getElement('primary_bundle_id')->setRequired(true);
                $primaryProduct = explode('#',$data['primary_bundle_id']);               
            }
        }  
        $status = parent::isValid($data);
        $practicetestModel = new Model_FreePracticeTest();
        if (!empty($primaryProduct[0])) {            
            $scholarshipTests = $practicetestModel->fetchAll(array('test_type =? ' => "scholarship_test", 'status =? ' => 1, 'primary_product_id =?' => $primaryProduct[0]), array('columns' => array('free_practice_test_id')));
            if (count($scholarshipTests) > 0 && (!isset($data['previous_product']) || $data['previous_product'] != $primaryProduct[0])) {
                $this->getElement('primary_bundle_id')->setErrors(array("product with id '{$primaryProduct[0]}' is already tagged with other test. Please select different product"));
                $hasErrors = true;
            }
        }
        if(!empty($data['url'])){
            $data['url'] = trim($data['url']);
            $checkSlash = substr($data['url'], 0,1);
            if($checkSlash != '/'){
                $data['url'] = trim('/'.$data['url']);
            }
            $objSeo = new Model_Seo();
            if(false === $objSeo->validateUrl($data['url'])){
                $this->getElement('url')->setErrors(array("'{$data['url']}' is not a valid Practice Test url"));
                $hasErrors = true;  
            }
        }
        if ($data['test_type'] == "scholarship_test"){ 
            $noOfQuestions = $data['noOfQuestions'];
            $testTime = $data['testTime'];
            if (trim($testTime) != "" && intVal($testTime) < 1){
                $this->getElement('testTime')->setErrors(array("Test time should be more than '0'"));
                $hasErrors = true;
            }            
            if (trim($noOfQuestions) != "" && intVal($noOfQuestions) < 1) {
                $this->getElement('noOfQuestions')->setErrors(array("Number of questions should be more than '0'"));
                $hasErrors = true;
            } else if(!isset($data['previous_noOfQuestions']) || $data['previous_noOfQuestions'] != $noOfQuestions)  {
                $paperclipTest = $practicetestModel->paperclipById($data['paperclip_testId']);
                $totalQuestions = (!empty($paperclipTest) && !empty($paperclipTest['numberOfQuestions'])) ? $paperclipTest['numberOfQuestions'] : '';
                if (!empty($totalQuestions) && $noOfQuestions > $totalQuestions) {
                    $this->getElement('noOfQuestions')->setErrors(array("Number of questions can not be more than '{$paperclipTest['numberOfQuestions']}'"));
                    $hasErrors = true;                    
                }
            }
        }
        if($hasErrors == true){
            return false;
        }        
        return $status;
    }
}

