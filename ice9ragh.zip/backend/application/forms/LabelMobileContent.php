
<?php

class Form_LabelMobileContent extends BaseApp_Form
{

    private $_labelId = null;

    public function __construct($labelId = false, $new = true)
    {
        if ($labelId) {
            $this->_labelId = $labelId;
        }
        $this->init($labelId);
        $this->loadDefaultDecorators();
    }

    public function init($labelId)
    {
        $this->setName('LabelMobileContent');
        $this->setMethod('post');
        $this->setAttrib('class', 'courseForm');


        //Image upload for rectangular


        $imageModel = new Model_Images();
        $imageData = $imageModel->getInclusionImages($labelId, 'label');

        $this->addElement($this->createElement('file', 'rect_image', array(
            'label' => 'Upload banner image* (360px X 194px, 380kb)',
            'required' => false,
            'destination' => sys_get_temp_dir(),
            'validators' => array(
                'Extension' => array('jpeg', 'png', 'jpg'),
                array('ImageSize', false, array('maxwidth' => 360, 'maxheight' => 194)),
                array('Size', false, array('useByteString' => true, 'max' => '380kb'))
            )
        )));
        if (!empty($imageData['rectangular_image'])) {
            $this->addElement('text', 'rectangular_value', array(
                'label' => 'Banner image Url',
                'value' => @$imageData['rectangular_image']['imagePath'],
                'helper' => 'formNote'
            ));
        }
        //Image upload for square image

        $this->addElement($this->createElement('file', 'square_image', array(
            'label' => 'Upload icon image* (288px X 288px, 380kb)',
            'required' => false,
            'destination' => sys_get_temp_dir(),
            'validators' => array(
                'Extension' => array('jpeg', 'png', 'jpg'),
                array('ImageSize', false, array('maxwidth' => 288, 'maxheight' => 288)),
                array('Size', false, array('useByteString' => true, 'max' => '380kb'))
            )
        )));
        if (!empty($imageData['square_image'])) {
            $this->addElement('text', 'square_value', array(
                'label' => 'icon Image Url',
                'value' => @$imageData['square_image']['imagePath'],
                'helper' => 'formNote'
            ));
        }

        $this->addElement('submit', 'Save', array(
            'ignore' => true,
            'label' => 'Upload',
            'class' => 'btn btn-info'
        ));
        $this->getElement('rect_image')->setDecorators(
            array(
                'File',
                array('Errors', array('class' => 'errors error-file')),
                array(
                    array('data' => 'HtmlTag'),
                    array('tag' => 'div', 'class' => 'element')
                ),
                array(
                    'Label',
                    array('tag' => 'div')
                ),
                array(
                    array('row' => 'HtmlTag'),
                    array('tag' => 'li')
                )
            )
        );
    }
    public function isValid($data)
    {
        $status = parent::isValid($data);
        if (!$status)
            return false;

        if ($data['rect_image']['name'] != '' && !empty($data['rect_image']['name'])) {
            $fileName = $data['rect_image']['name'];
            $fileName = explode(".", $fileName)[0];
            if (!@preg_match('/^[A-Za-z0-9_-]+$/', $fileName)) {
                $this->getElement('rect_image')->setErrors(array("File name can only be Alpha numerics with _ and - "));
                $status = false;
            }
        }
        if ($data['square_image']['name'] != '' && !empty($data['square_image']['name'])) {
            $fileName = $data['square_image']['name'];
            $fileName = explode(".", $fileName)[0];
            if (!@preg_match('/^[A-Za-z0-9_-]+$/', $fileName)) {
                $this->getElement('square_image')->setErrors(array("File name can only be Alpha numerics with _ and - "));
                $status = false;
            }
        }
        return $status;
    }
}
