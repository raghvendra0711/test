<?php

class Form_User extends BaseApp_Form {

    public function init() {
        $this->addElement('text', 'email', array(
            'label' => 'User Email',
            'required'=>true,
            'validators' => array(
                new BaseApp_Validate_EmailAddress()
            )
        ));
        $this->addElement('submit', 'submit', array(
            'label' => 'Save'
        ));
    }   
}
