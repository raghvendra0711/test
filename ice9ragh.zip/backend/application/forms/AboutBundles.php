<?php

class Form_AboutBundles extends BaseApp_SubForm
{

    private $_displayAboutBundleForm = true;
    private $_addMoreButton = true;
    public function __construct($displayAboutBundleForm=true,$addMoreBtn=true) {
        $this->_displayAboutBundleForm =  $displayAboutBundleForm;
        $this->_addMoreButton = $addMoreBtn;
        parent::__construct();
    }
    
    public function init(){
        $this->setName('BundleFaq');
        $this->setMethod('post');        
        $session = new Zend_Session_Namespace('form');
        
        /**
         * Start: About bundle
         *
         */

        $subForm = new Zend_Form_SubForm();
        $subForm->setName('aboutBundle'); 
        // prd($session->aboutBundleData);  
         foreach ($session->aboutBundle as $product) {
            $faqId = isset($session->aboutBundleData[$product]['faq_id']) ? $session->aboutBundleData[$product]['faq_id'] : '';
            $keyName = isset($session->aboutBundleData[$product]['question']) ? $session->aboutBundleData[$product]['question'] : '';
            $keyFeatureText = isset($session->aboutBundleData[$product]['answer']) ? $session->aboutBundleData[$product]['answer'] : '';
            $keyCountryIds = isset($session->aboutBundleData[$product]['countryIds']) ? $session->aboutBundleData[$product]['countryIds'] : '';
            $keyClusterIds = isset($session->aboutBundleData[$product]['clusterIds']) ? $session->aboutBundleData[$product]['clusterIds'] : '';
            $allCountriesFlag = isset($session->aboutBundleData[$product]['allCountries']) ? $session->aboutBundleData[$product]['allCountries'] : 0; 
            $isB2BValue = isset($session->aboutBundleData[$product]['is_b2b']) ? $session->aboutBundleData[$product]['is_b2b'] : null;
            $isB2CValue = isset($session->aboutBundleData[$product]['is_b2c']) ? $session->aboutBundleData[$product]['is_b2c'] : 1;
            
            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);

            $classfck = 'fck-enable';
            if ($product === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
                $classfck = '';
            }
            $resourceIdDom = new Zend_Form_Element_Hidden('course_faq_id');
            $resourceIdDom->addFilter('stringTrim')->setValue($faqId)->clearDecorators();

            $isB2b = new Zend_Form_Element_Checkbox('is_b2b');
            $isB2b->addFilter('stringTrim')->setValue($isB2BValue)->setAttrib('class', '')->setLabel('Is B2B');

            $isB2C = new Zend_Form_Element_Checkbox('is_b2c');
            $isB2C->addFilter('stringTrim')->setValue($isB2CValue)->setAttrib('class', '')->setLabel('Is B2C');

            $name = new Zend_Form_Element_Text('question');
            $name->addFilter('stringTrim')->setValue($keyName)->setAttrib('class', 'longtext')->setAttrib('placeholder', 'Question')->setLabel('Question');

            $featureText = new Zend_Form_Element_Textarea('answer');
            $featureText->addFilter('stringTrim')->setValue($keyFeatureText)->setAttrib('class', $classfck)->setAttrib('placeholder', 'Answer')->setLabel('Answer');

            $objCluster =new Model_Clusters();
            $featureCluster = new Zend_Form_Element_Select('cluster_id');
            $keyCluster = !empty($keyClusterIds) ? explode(',',$keyClusterIds):array();
            $featureCluster->setOptions(array('required'=>false,'multiple' => true,'multioptions' => $objCluster->fetchForSelect()))
            ->setValue($keyCluster)->setAttrib('class', 'multiple clusterListAll selectedCluster')
            ->setLabel('Cluster')->setAttrib('onchange', 'countryByClusterSelect(this,"aboutBundle-new-country")')->setAttrib('data-last-selected',$keyClusterIds)
            ->setAttrib('data-isedit',!empty($faqId) ? true : false)
            ->setRegisterInArrayValidator(false);

            $objCountry = new Model_Country();
            $featureCountry = new Zend_Form_Element_Select('country_id');
            $keyCountry = !empty($keyCountryIds) ? explode(',',$keyCountryIds):array();
            $featureCountry->setOptions(array('required'=>false,'multiple' => true,'multioptions' => $objCountry->getListDisplay()))
                    ->setValue($keyCountry)->setAttrib('class', 'courseListAll countryListAll skipPreviousClick')
                    ->setLabel('Country')
                    ->setRegisterInArrayValidator(false);

            //Check All Countries
            $allCountryChecked = 0;
            $isClusterCountryDisabled = false;
            if (empty($keyCluster) && empty($keyCountry)) {
                $allCountryChecked = 1;
                $isClusterCountryDisabled = true;
            }
            if (!empty($allCountriesFlag) && $allCountriesFlag == 1) {
                $allCountryChecked = 1;
            }
            $checkAllCountry = new Zend_Form_Element_Checkbox('all_country');
            $checkAllCountry->setValue($allCountryChecked)->setLabel('All Countries')->setAttrib('onclick', 'checkAllCountry(this)')->setAttrib('class','allCountry');

            if ($isClusterCountryDisabled) {
                $featureCluster->setOptions(array('disabled' => true));
                $featureCountry->setOptions(array('disabled' => true));
            }
            //Invert Selection
            $invertBtn = new Zend_Form_Element_Button('invert');
            $invertBtn->setLabel('Invert countries')->setAttrib('class', 'btn btn-warning remove')->setAttrib('onclick', 'invertSelection(this)');

            $removeKeyFeatures = new Zend_Form_Element_Button('remove');
            $removeKeyFeatures->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');

            if ($product !== 'new') {
                $elements = array($checkAllCountry,$featureCluster,$featureCountry,$invertBtn,$resourceIdDom,$name, $featureText, $isB2C, $isB2b,$removeKeyFeatures);
            } else {
                $elements = array($checkAllCountry,$featureCluster,$featureCountry,$invertBtn,$resourceIdDom,$name, $featureText, $isB2C, $isB2b);
            }

            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());

            if ($rowForm->getElement('remove')) {
                $rowForm->getElement('remove')->removeDecorator('Label');
            }
            if ($rowForm->getElement('invert')) {
                $rowForm->getElement('invert')->removeDecorator('Label');
            }

            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        
         }
        
         $subForm->setDecorators($this->getSubFormDecoratorsMain('course-faq-editor', 'aboutBundle'));

         /* if($this->_addMoreButton){
            $addPrice = new Zend_Form_Element_Button('add');
            $addPrice->setLabel('Add About Bundle')->setAttrib('class', 'btn btn-warning add');
            $subForm->addElement($addPrice);
 
            $subForm->setElementDecorators($this->getElementDecorators());
            $subForm->getElement('add')->removeDecorator('Label');
         } */
         $this->addSubForm($subForm, 'aboutBundle');
         
         $this->addElement('submit','Save',array(
            'ignore'=>true,
            'label'=>'Save'
           ));
        $this->addElement('button', 'Cancel', array(
            'label' => 'Cancel',
            'ignore' => true,
            'id'=>'cancel_form',  
            'class' => 'btn btn-warning'
        ));
 
         /**
          * End: sub form for about bundle
          *
          */
    }
    
    protected function getSubFormDecoratorsMain($className, $id) {
        return array(   
            'FormElements',                        
            array(                
                'HtmlTag', array('tag' => 'ul')
            ),
            array(
                array('row' => 'HtmlTag'),                
                array('tag' => 'li', 'class' => $className, 'id' => $id)
            )
        );
    }       
    
    protected function getSubFormDecorators($className = 'subform')
    {
        return array(
            'FormElements',
            array('HtmlTag', array('tag' => 'ul'/*, 'data-role' => 'fieldset', 'role' => 'listitem'*/)),
            'Fieldset',
            array(
                array('row' => 'HtmlTag'),
                array('tag' => 'li', 'class' => $className)
            )
//             array('HtmlTag', array('tag' => 'li'/*, 'data-role' => 'listview', 'role' => 'list'*/))
        );
    }
    
    public function removeUneditableElements(){
        return false;
    }
    
    public function isValid($data, &$errorMessage='') {
        // prd($data);
        $status = parent::isValid($data);
        if (!empty($data['aboutBundle'])) {
            $subForm = 'aboutBundle';
            foreach ($data['aboutBundle'] as $key => $row) {
                if (empty($row['all_country']) && !isset($row['cluster_id']) && !isset($row['country_id'])) {
                    $status = false;
                    $this->getSubForm($subForm)->getSubForm($key)->getElement('all_country')->setErrors(array(" Please select either All Countries or Cluser & Country"));
                }
                /* if (isset($row['cluster_id']) && !isset($row['country_id'])) {
                    $status = false;
                    $this->getSubForm($subForm)->getSubForm($key)->getElement('country_id')->setErrors(array(" Please select country"));
                } */
                if (empty($row['question'])) {
                    $status = false;
                    $this->getSubForm($subForm)->getSubForm($key)->getElement('question')->setErrors(array("Please enter question."));
                }
                if (empty($row['answer'])) {
                    $status = false;
                    $this->getSubForm($subForm)->getSubForm($key)->getElement('answer')->setErrors(array("Please enter answer."));
                }

                if (empty($row['is_b2c']) && empty($row['is_b2b'])) {
                    $status = false;
                    $this->getSubForm($subForm)->getSubForm($key)->getElement('is_b2b')->setErrors(array("Please select atleast one of Is B2C or Is B2B."));
                }
            }
            return $status;
        }
    }
}

