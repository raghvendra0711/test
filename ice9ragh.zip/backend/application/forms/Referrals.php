<?php

class Form_Referrals extends BaseApp_Form
{

    public function init(){
        
    }
}