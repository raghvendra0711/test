<?php

class Form_Scaffold extends BaseApp_Form {

    protected $_definition;

    public function __construct($definition, $options = null) {
        $this->_definition = $definition;
        parent::__construct($options);
    }

    public function init() {
        foreach ($this->_definition as $field => $data) {
            if ($data['Extra'] == 'auto_increment')
                continue;
            if ($data['Field'] == 'status')
                continue;
            if ($data['Type'] == 'text') {
                $this->addElement('textarea', $data['Field'], array(
                    'label' => ucwords($data['Field'])
                ));
            } elseif ($data['Type'] == 'tinyint(1)') {
                $this->addElement('checkbox', $data['Field'], array(
                    'label' => ucwords($data['Field'])
                ));
            } else {
                prd($data);
                break;
            }
        }

        $this->addElement('submit', 'Save', array(
            'ignore' => true,
            'label' => 'Save'
        ));
    }

}
