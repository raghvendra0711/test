<?php

class Form_Groups extends BaseApp_SubForm
{
   
    public function init(){
        $this->setName('Groups');
        $this->setMethod('post');

        $validatorsName = array(new Zend_Validate_StringLength(array('max' => 100)));
        $validatorsDescription = array(new Zend_Validate_StringLength(array('max' => 1000)));
        
        $this->addElement('text','name',array(
            'label'=>'Group Name',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off'
        ));
         
        $this->addElement('text','label_name',array(
            'label'=>'Label',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'autocomplete' => 'off'
        ));
        
        $this->addElement('hidden','label_id',array(
            'required'=>true,
            'value'=> ''
        ));

        $obj =new Model_Vendors();
        $this->addElement('select','vendor_id',array(
            'label'=>'Vendor',
            'required'=>false,
            'multioptions'=>array('0'=>'--Select--') + $obj->fetchForSelect()
        ));
        
        $this->addElement('textarea','shortDescription',array(
            'label'=>'Description',
            'required'=>true,
            'filter'=>array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class'=>'shortDescription'     
        ));
        
        $this->addElement('text','url',array(
            'label'=>'url',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));
        
        $course = new Model_Courses();
        $this->addElement('select','course_id',array(
            'label'=>'Courses',
            'required'=>true,
            'multiple' => true,
            'registerInArrayValidator' => false,
            'multioptions'=>$course->fetchForSelect(array('is_dummy = ?' => 0, 'is_free = ?' => 0)) 
        ));
         
        $this->addElement('textarea','learningPath',array(
            'label'=>'Learning Path',
            'required'=>false,
            'filter'=>array('StringTrim'),
            'rows' => 21,
            'cols' => 68,
            'class'=> 'fck-enable'     
        ));
        
        $this->addElement('text','searchTags',array(
            'label'=>'Search tags (comma separated)',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));
        
        $session = new Zend_Session_Namespace('form');
        
        
        /**
         * Start: sub form for key features
         * 
         */
        
         $subForm = new Zend_Form_SubForm();
         $subForm->setName('keyFeatures');
         foreach ($session->keyFeatures as $product) {
            $keyName = isset($session->keyFeaturesData[$product]['name'])?$session->keyFeaturesData[$product]['name']:'';
            $keyFeatureText = isset($session->keyFeaturesData[$product]['featureText'])?$session->keyFeaturesData[$product]['featureText']:'';
            
            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);  
            
            if ($product === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
            }
            
            $name = new Zend_Form_Element_Text('name');
            $name->addFilter('stringTrim')->setValue($keyName)->setAttrib('class', 'keyName')->setAttrib('placeholder', 'Full Length simulation tests');
            
            $featureText = new Zend_Form_Element_Text('featureText');
            $featureText->addFilter('stringTrim')->setValue($keyFeatureText)->setAttrib('class', 'keyFeatureText')->setAttrib('placeholder', 'This includes full length, timed simulation teste as prescribed by PMI');
            
            $removeKeyFeatures = new Zend_Form_Element_Button('remove');
            $removeKeyFeatures->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');        
         
            if ($product !== 'new') {
                $elements = array($name, $featureText, $removeKeyFeatures);            
            }
            else {
                $elements = array($name, $featureText);            
            }
            
            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());

            if($rowForm->getElement('remove')) {
                $rowForm->getElement('remove')->removeDecorator('Label');
            }
            
            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        }
        
        $subForm->setDecorators($this->getSubFormDecoratorsMain('keyFeatures', 'keyFeatures'));

        $addPrice = new Zend_Form_Element_Button('add');
        $addPrice->setLabel('Add Key Feature')->setAttrib('class', 'btn btn-warning add');
        $subForm->addElement($addPrice);

        $subForm->setElementDecorators($this->getElementDecorators());
        $subForm->getElement('add')->removeDecorator('Label');
        $this->addSubForm($subForm, 'keyFeatures');
        
        /**
         * End: sub form for key features
         * 
         */
        
        /**
         * Start: sub form for faqs
         * 
         */
        
         $subForm = new Zend_Form_SubForm();
         $subForm->setName('groupFaq');   
         foreach ($session->groupFaq as $product) {
            $keyQuestion = isset($session->groupFaqData[$product]['question'])?$session->groupFaqData[$product]['question']:'';
            $keyAnswer = isset($session->groupFaqData[$product]['answer'])?$session->groupFaqData[$product]['answer']:'';
            
            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);  
            
            if ($product === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
            }
            
            $question = new Zend_Form_Element_Text('question');
            $question->addFilter('stringTrim')->setValue($keyQuestion)->setAttrib('class', 'question')->setAttrib('placeholder', 'Full Length simulation tests');
            
            $answer = new Zend_Form_Element_Text('answer');
            $answer->addFilter('stringTrim')->setValue($keyAnswer)->setAttrib('class', 'faqDescription')->setAttrib('placeholder', 'This includes full length, timed simulation teste as prescribed by PMI');

            $removeSetsNumber = new Zend_Form_Element_Button('remove');
            $removeSetsNumber->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');        
         
            if ($product !== 'new') {
                $elements = array($question, $answer, $removeSetsNumber);            
            }
            else {
                $elements = array($question, $answer);            
            }            

            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());

            if($rowForm->getElement('remove')) {
                $rowForm->getElement('remove')->removeDecorator('Label');
            }
            
            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        }
        
        $subForm->setDecorators($this->getSubFormDecoratorsMain('examFaq', 'groupFaq'));

        $addPrice = new Zend_Form_Element_Button('add');
        $addPrice->setLabel('Add Faq')->setAttrib('class', 'btn btn-warning add');
        $subForm->addElement($addPrice);

        $subForm->setElementDecorators($this->getElementDecorators());
        $subForm->getElement('add')->removeDecorator('Label');
        $this->addSubForm($subForm, 'groupFaq');
        
        /**
         * End: sub form for faqs
         * 
         */
        
        
        /**
         * Start: sub form for suggestions
         * 
         */
        
        $subForm = new Zend_Form_SubForm();
         $subForm->setName('recommendations');   
         foreach ($session->recommendations as $product) {
            $keyApplicableEntity = isset($session->recommendationsData[$product]['applicableEntity'])?$session->recommendationsData[$product]['applicableEntity']:'';
            $keyElementName = isset($session->recommendationsData[$product]['applicableEntityId'])?$session->recommendationsData[$product]['applicableEntityId']:'';
            $keyTrainingType = isset($session->recommendationsData[$product]['trainingType'])?$session->recommendationsData[$product]['trainingType']:'';
            
            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);  
            
            if ($product === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
            }
            
            $modelRecommend = new Model_Recommendations();
            $modelTraining = new Model_TrainingTypes();
            $applicableEntity = new Zend_Form_Element_Select('applicableEntity');
            $applicableEntity->setOptions(array('multioptions' => array(0=>'--Select--')+$modelRecommend->getRecommendElements()))->setValue($keyApplicableEntity)->setAttrib('class', 'applicableEntity')->setLabel('Also Consider');
            $elementList = array();
            if($keyApplicableEntity) {
                $modelRecommend = new Model_Recommendations();
                $elementList = $modelRecommend->getByElement($keyApplicableEntity); 
            } 
            $elementName = new Zend_Form_Element_Select('applicableEntityId');
            $elementName->setOptions(array('multioptions' => array(0=>'--Element Name--')+$elementList, 'registerInArrayValidator' => false))->setValue($keyElementName)->setAttrib('class', 'elementName');
            
            $trainingType = new Zend_Form_Element_Select('trainingType');
            $trainingType->setOptions(array('multioptions' => array(0=>'Training Type')+$modelTraining->getTrainingTypes(), 'registerInArrayValidator' => false))->setValue($keyTrainingType)->setAttrib('class', 'trainingType');
           
            $removeSuggestions = new Zend_Form_Element_Button('remove');
            $removeSuggestions->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');        
            if ($product !== 'new') {
                $elements = array($applicableEntity, $elementName, $trainingType, $removeSuggestions);            
            }
            else {
                $elements = array($applicableEntity, $elementName, $trainingType);            
            }
            
            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());

            if($rowForm->getElement('remove')) {
                $rowForm->getElement('remove')->removeDecorator('Label');
            }
            
            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        }
        
        $subForm->setDecorators($this->getSubFormDecoratorsMain('recommendations', 'recommendations'));

        $addPrice = new Zend_Form_Element_Button('add');
        $addPrice->setLabel('Add More')->setAttrib('class', 'btn btn-warning add');
        $subForm->addElement($addPrice);

        $subForm->setElementDecorators($this->getElementDecorators());
        $subForm->getElement('add')->removeDecorator('Label');
        $this->addSubForm($subForm, 'recommendations');
        $this->postSetup(); 
        
        /**
         * End: sub form for suggestions
         * 
         */
        
        $this->getElement('name')->addValidators($validatorsName);         
        $this->getElement('shortDescription')->addValidators($validatorsDescription);
    }
    
    protected function getSubFormDecoratorsMain($className, $id) {
        return array(   
            'FormElements',                        
            array(                
                'HtmlTag', array('tag' => 'ul')
            ),
            array(
                array('row' => 'HtmlTag'),                
                array('tag' => 'li', 'class' => $className, 'id' => $id)
            )
        );
    }  
    
    public function removeUneditableElements(){
        $this->removeElement('url');
        return false;
    }
    
    public function isValid($data) {        
        $return = parent::isValid($data);
        if(!empty($data['url'])){
            $data['url'] = trim($data['url']);
            $checkSlash = substr($data['url'], 0,1);
            if($checkSlash != '/'){
                $data['url'] = trim('/'.$data['url']);
            }
            $objSeo = new Model_Seo();
            if(false === $objSeo->validateUrl($data['url'])){
                $this->getElement('url')->setErrors(array("'{$data['url']}' is not a valid Group url"));
                return false;   
            }
        }
        return $return;
    }
}
