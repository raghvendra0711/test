<?php

class Form_GeneralFaq extends BaseApp_Form
{
    
    public function init(){
        $this->setName('GeneralFaq');
        $this->setMethod('post');
         //adding Label name element

        $this->addElement('select','section',array(
            'label'=>'Faq Section*',
            'required'=>false,
            'registerInArrayValidator' => false,
            'multioptions'=>array('Customer Support' => 'Customer Support', 'General' => 'General', 'Others' => 'Others', 'Payment & Billing' => 'Payment & Billing', 'subscription' => 'Subscription')
        ));
        
        $this->addElement('text','question',array(
            'label'=>"Question*",
            'required'=>true,
            'class'=>'longtext',
            'value' => ''
        ));

        $this->addElement('textarea','answer',array(
            'label'=>'Answer*',
            'required'=>true,
            'cols' => 60,
            'rows' => 6,
            'value' => ''
        ));

        $this->addElement('submit','Save',array(
            'ignore'=>true,
            'label'=>'Save'
         ));
    }
    
    public function removeUneditableElements(){
        $this->removeElement('section');
    }
}

