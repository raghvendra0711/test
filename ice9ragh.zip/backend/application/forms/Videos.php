<?php

class Form_Videos extends BaseApp_Form
{

    public function init(){

        $this->setName('Videos');
        $this->setMethod('post');
         //adding Label name element


         $course =new Model_Courses();
         $this->addElement('select','course_id',array(
            'label'=>'Course',
            'required'=>false,
            'multioptions'=>array('0'=>'--Select--') + $course->fetchForSelect(array('is_dummy = ?' => 0, 'is_free = ?' => 0))
        ));

        $this->addElement('text','name',array(
            'label'=>'Video Name',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('text','displayName',array(
            'label'=>'Display Name',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('text','url',array(
            'label'=>'Page Url',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'            
        ));
        
        $this->addElement('text','videoLink',array(
            'label'=>'video Url',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                new BaseApp_Validate_Url()
            )
        ));
        
        $this->addElement('text','duration',array(
            'label'=>'Duration',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'placeholder' => 'HH:MM:SS'
        ));
        
        $this->addElement('text','shortDescription',array(
            'label'=>'Short Description',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('text','longDescription',array(
            'label'=>'Long Description',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $videos =new Model_Videos();
         $this->addElement('select','fileFormat',array(
            'label'=>'File Format',
            'required'=>false,
            'multioptions'=>array('0'=>'--Select--') + $videos->getFileFormats()
        ));

         $this->addElement('checkbox','iosCompatible',array(
            'label'=>'Ios Compatible',
            'ignore'=>false,
           ));

         $this->addElement('checkbox','kindleCompatible',array(
            'label'=>'Kindle Compatible',
            'ignore'=>false,
           ));

         $this->addElement('checkbox','androidCompatible',array(
            'label'=>'Android Compatible',
            'ignore'=>false,
           ));

         $this->addElement('checkbox','isAddOn',array(
            'label'=>'Is AddOn',
            'ignore'=>false,
           ));
         
         $this->addElement('submit','Save',array(
            'ignore'=>true,
            'label'=>'Save',
            'class'=>'btn btn-info'
        ));
    }
    
    public function removeUneditableElements(){
        $this->removeElement('url');
        return false;
    }
    
    public function isValid($data) {
        $status = parent::isValid($data);
        if(!empty($data['url'])){
            $data['url'] = trim($data['url']);
            $checkSlash = substr($data['url'], 0,1);
            if($checkSlash != '/'){
                $data['url'] = trim('/'.$data['url']);
            }
            $objSeo = new Model_Seo();
            if(false === $objSeo->validateUrl($data['url'])){
                $this->getElement('url')->setErrors(array("'{$data['url']}' is not a valid Video url"));
                $status = false;   
            }
        }
        
        if($data['duration'] && !preg_match("/^(\d\d\:)?(\d\d)\:(\d\d)$/", $data['duration'], $match)) {
            $this->getElement('duration')->setErrors(array("duration is invalid. It should be in HH:MM:SS format"));
            $status = false;
        }
        return $status;
    }
}