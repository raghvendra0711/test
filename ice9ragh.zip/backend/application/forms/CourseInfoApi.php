<?php

class Form_CourseInfoApi extends BaseApp_Form
{
    public function init()
    {
        $this->setName('CourseInfoApi');
        $this->setMethod('post');

        $validatorsDescription = array(new Zend_Validate_StringLength(array('max' => 50)));

        $this->addElement('text', 'identifier', array(
            'label'=>'Company Identifier',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                new Zend_Validate_NotEmpty()
            )
        ));

        $course = new Model_Courses();
        $coursesList = $course->fetchForSelect(array('is_dummy = ?' => 0, 'is_free = ?' => 0, 'hideFromSearch = ?' => 0));

        $this->addElement('select', 'course_id', array(
            'label'=>'Courses',
            'required'=>false,
            'multiple' => true,
            'registerInArrayValidator' => false,
            'class' => 'courseListAll',
            'multioptions'=>$coursesList
        ));

        $this->addElement('button', 'course_inward', array(
            'label'=>'Invert Courses',
            'ignore'=>true,
            'class'=>'btn btn-warning'
        ));

        $this->addElement('hidden','tmp_id',array(
            'required'=>false,
            'value'=>''
        ));

        $objtrainingTypes= new Model_TrainingTypes();//prd($objtrainingTypes->fetchForSelect());
        foreach ($objtrainingTypes->fetchAll() as $trainingData) {
            $this->addElement('multiCheckbox', 'training_id', array(
                'label' =>'Training Type*',
                'required'=>true,
                'multioptions'=>array(
                    BaseApp_Dao_TrainingTypes::TYPE_ELEARNING => strtoupper(BaseApp_Dao_TrainingTypes::TYPE_ELEARNING_NAME),
                    BaseApp_Dao_TrainingTypes::TYPE_LVC => strtoupper(BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS_NAME)),
                'separator' => ' '
             ));
        }


        $this->addElement('submit', 'Add Mapping', array(
          'ignore'=>true,
          'label'=>'Add Mapping',
          'class'=>'btn btn-info'
         ));

        $this->getElement('identifier')->addValidators($validatorsDescription);
    }

    public function isValid($data)
    {
        $return = parent::isValid($data);
        if ($return) {
            if (!in_array(BaseApp_Dao_TrainingTypes::TYPE_ELEARNING, $data['training_id'])) {
                $this->getElement('training_id')->setErrors(array("OSL training type is required"));
                $return = false;
            }

            $obj =new Model_CourseInfoApi();
            $existData = $obj->getByIdentifier($data['identifier'],$data['tmp_id']);
            if (!empty($existData) && $existData['id'] != $data['tmp_id']) {
                    $this->getElement('identifier')->setErrors(array("identifier already added to another mapping"));
                    $return = false;
            }
        }
        return $return;
    }

    public function removeUneditableElements()
    {
    }
}
