<?php

class Form_CompanyCategoryPricing extends BaseApp_SubForm {

    protected $_domains;
    protected $_companyId;
    protected $_categoryList;
    CONST ACCESS_DAYS_365 = 4;

    public function __construct($companyId = 0, $new = true) {
        $this->_companyId = $companyId;
        $this->_categoryList = $this->_getCategoryList();
        $this->init();
        $this->loadDefaultDecorators();
    }

    public function init() {
        $this->setName('CompanyCategoryPricing');
        $this->setMethod('post');
        $session = new Zend_Session_Namespace('form');
        $obj = new Model_Labels();
        $leanerRangaData = $this->_getCompanyPriceRange();
        // prd($session->learnerRange, $session->learnerRangeData,$session->companyPricingCat,$session->companyPricingCatData);
        // category pricing subform begin
        $subForm = new Zend_Form_SubForm();
        $subForm->setName('companyPricingCat');
        foreach ($session->learnerRange as $rangeIndex => $pricing) {
            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($pricing);
            $elements = array();
            if ($pricing === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
            }
            $linkableType = new Zend_Form_Element_Hidden('linkable_type');
            $linkableType->setRequired(false)->setValue('category');
            $categoryFilter = array('0' => '--All--') + $this->_categoryList;
            $linkableIdProdVal = !empty($session->companyPricingCatData[$pricing]['linkable_id_prod']) ? $session->companyPricingCatData[$pricing]['linkable_id_prod'] : '';
            $pricingCategory = new Zend_Form_Element_Select('linkable_id_prod');
            $pricingCategory->setOptions(array('multioptions' => $categoryFilter, 'registerInArrayValidator' => false))
                    ->setValue($linkableIdProdVal)
                    ->setAttrib('class', 'pricingCategory catPricing')
                    ->setLabel('Category');

            $locationModeVal = !empty($session->companyPricingCatData[$pricing]['location_mode']) ? $session->companyPricingCatData[$pricing]['location_mode'] : '';
            $locationMode = new Zend_Form_Element_Select('location_mode');
            //$locationMode->setOptions(array('multioptions' => array(0 => '--Select--', 2 => 'By Country')))->setValue('')->setAttrib('class', 'pricingLevel')->setLabel('Pricing Level');
            $locationMode->setOptions(array('multioptions' => array(0 => '--Select--', 1 => 'By Cluster', 2 => 'By Country')))
                    ->setValue($locationModeVal)
                    ->setAttrib('class', 'pricingLevel company-pricing-level catpricingLevel')
                    ->setLabel('Pricing Level');
            $countryIdVal = !empty($session->companyPricingCatData[$pricing]['country_id']) ? $session->companyPricingCatData[$pricing]['country_id'] : '';
            $hideCountryClass = 'hide-form-el';
            if (!empty($countryIdVal)) {
                $hideCountryClass = '';
            }
            $country = new Zend_Form_Element_Select('country_id');
            $countryList = array();
            $countryModel = new Model_Country();
            $countryList = $countryModel->fetchForSelect();
            $country->setOptions(array('multioptions' => array('0' => '--Select--') + $countryList, 'registerInArrayValidator' => false))
                    ->setValue($countryIdVal)
                    ->setAttrib('class', "country $hideCountryClass")
                    ->setLabel('Country');

            $clusterIdVal = !empty($session->companyPricingCatData[$pricing]['cluster_id']) ? $session->companyPricingCatData[$pricing]['cluster_id'] : '';
            $hideClusterClass = 'hide-form-el';
            if (!empty($clusterIdVal)) {
                $hideClusterClass = '';
            }
            $clusterElm = new Zend_Form_Element_Select('cluster_id');
            $clusterList = array();
            $clusterObj = new Model_Clusters();
            $clusterList = $clusterObj->fetchForSelect();
            $clusterElm->setOptions(array('multioptions' => array('0' => '--Select--') + $clusterList, 'registerInArrayValidator' => false))
                    ->setValue($clusterIdVal)
                    ->setAttrib('class', "cluster $hideClusterClass")
                    ->setLabel('Cluster');

//            $defCountry = new Zend_Form_Element_Select('def_country_id');
//            $countryList = array();
//            $countryModel = new Model_Country();
//            $countryList = $countryModel->fetchForSelect();
//            $defCountry->setOptions(array('multioptions' => array('0' => '--Select--') + $countryList, 'registerInArrayValidator' => false))->setValue('')->setAttrib('class', 'country')->setLabel('Default Country');

            $learnerRangeMinVal = !empty($leanerRangaData[$rangeIndex]['min']) ? $leanerRangaData[$rangeIndex]['min'] : 0;
            $learnerRangeMaxVal = !empty($leanerRangaData[$rangeIndex]['max']) ? $leanerRangaData[$rangeIndex]['max'] : 0;
            $learnerRangeIdVal  = !empty($leanerRangaData[$rangeIndex]['id']) ? $leanerRangaData[$rangeIndex]['id'] : 0;


            //$learnerRangeMinVal = !empty($session->companyPricingCatData[$pricing]['learners_range_min']) ? $session->companyPricingCatData[$pricing]['learners_range_min'] : '';
            $learnerRangeMin = new Zend_Form_Element_Text('learners_range_min');
            $learnerRangeMin->addFilter('stringTrim')
                    ->setValue($learnerRangeMinVal)
                    ->setAttribs(array('class' => 'learnerRangeMin readonly_input', 'readonly' => 'true'))
                    ->setLabel('Learner Range Min');

            //$learnerRangeMaxVal = !empty($session->companyPricingCatData[$pricing]['learners_range_max']) ? $session->companyPricingCatData[$pricing]['learners_range_max'] : 0;
            $learnerRangeMax = new Zend_Form_Element_Text('learners_range_max');
            $learnerRangeMax->addFilter('stringTrim')
                    ->setValue($learnerRangeMaxVal)
                    ->setAttribs(array('class' => 'learnerRangeMax readonly_input', 'readonly' => 'true'))
                    ->setLabel('Learner Range Max');



            $learnerRangeId = new Zend_Form_Element_Text('learners_range_id');
            $learnerRangeId->addFilter('stringTrim')->setValue($learnerRangeIdVal)->setAttribs(array('class' => ' hide-form-el readonly_input', 'readonly' => 'true'))->setLabel('');
            $accessDaysVal = !empty($session->companyPricingCatData[$pricing]['access_day_id']) ? $session->companyPricingCatData[$pricing]['access_day_id'] : self::ACCESS_DAYS_365;
            $setsNumber = new Zend_Form_Element_Select('access_day_id');
            $accessObj = new Model_AccessDays();
            $arr = $accessObj->getAccessDaysById('osl');
            $con = ['4' => 365];
            $disabled = array_diff($arr,$con);
            $disabled_options = array_keys($disabled);
            $setsNumber->addFilter('stringTrim')
                    ->setValue($accessDaysVal)
                    ->setAttrib('class', 'accessDaysCount')
                    ->setAttrib('disable',$disabled_options)
                    ->setAttrib('placeholder', 'Access Days')
                    ->setLabel('Access Days')
                    ->setOptions(array('multioptions' => array('0' => '--Select--') + $accessObj->getAccessDaysById('osl'), 'registerInArrayValidator' => false));
            //$trainingTypeVal = !empty($session->companyPricingCatData[$pricing]['training_id']) ? $session->companyPricingCatData[$pricing]['training_id'] : 0;
            $trainingType = new Zend_Form_Element_Select('training_id');
            $trainingType->setOptions(array('multioptions' => array(BaseApp_Dao_TrainingTypes::TYPE_ELEARNING => 'Online Self Learning')))
                    ->setValue(BaseApp_Dao_TrainingTypes::TYPE_ELEARNING)
                    ->setAttrib('class', 'trainingId')
                    ->setLabel('Training Type');
            $flatPriceVal = !empty($session->companyPricingCatData[$pricing]['flat_price']) ? $session->companyPricingCatData[$pricing]['flat_price'] : '';
            $flatPrice = new Zend_Form_Element_Text('flat_price');
            $flatPrice->addFilter('stringTrim')
                    ->setValue($flatPriceVal)
                    ->setAttrib('class', 'flat_price')
                    ->setLabel('Flat Price')
                    ->setAttrib('placeholder', 'Flat Price*');
            $flatDiscountVal = !empty($session->companyPricingCatData[$pricing]['flat_discount']) ? $session->companyPricingCatData[$pricing]['flat_discount'] : '';
            $discount = new Zend_Form_Element_Text('flat_discount');
            $discount->addFilter('stringTrim')
                    ->setValue($flatDiscountVal)
                    ->setAttrib('class', 'flat_discount')
                    ->setLabel('Discount(%)')
                    ->setAttrib('placeholder', 'Discount (%)');
            $elements = array($pricingCategory, $linkableType, $locationMode, $country, $clusterElm, $learnerRangeMin, $learnerRangeMax, $learnerRangeId, $setsNumber, $trainingType, $flatPrice, $discount);
            $removeSetsNumber = array();
            //$removeSetsNumber = new Zend_Form_Element_Button('remove');
            //$removeSetsNumber->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');

            if ($pricing !== 'new') {
                $elements[] = $removeSetsNumber;
            }
            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());

            if ($rowForm->getElement('remove')) {
                // $rowForm->getElement('remove')->removeDecorator('Label');
            }

            $label = $rowForm->getElement('cluster_id')->getDecorator('Label');
            $label->setOption('style', 'display: none;');

            $label = $rowForm->getElement('country_id')->getDecorator('Label');
            $label->setOption('style', 'display: none;');

            if (!empty($clusterIdVal)) {
                $label = $rowForm->getElement('cluster_id')->getDecorator('Label');
                $label->setOption('style', 'display: block;');
            }

            if (!empty($countryIdVal)) {
                $label = $rowForm->getElement('country_id')->getDecorator('Label');
                $label->setOption('style', 'display: block;');
            }

            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $pricing);
        }

        $subForm->setDecorators($this->getSubFormDecoratorsMain('companyPricingCat', 'companyPricingCat'));

//        $addPricing = new Zend_Form_Element_Button('add');
//        $addPricing->setLabel('Add Pricing')->setAttrib('class', 'btn btn-warning add');
//        $subForm->addElement($addPricing);

        $subForm->setElementDecorators($this->getElementDecorators());
        // $subForm->getElement('add')->removeDecorator('Label');
        $this->addSubForm($subForm, 'companyPricingCat');

        $this->addElement('hidden', 'company_id', array(
            'required' => false,
        ));

        $this->addElement('submit', 'save_category_pricing', array(
            'ignore' => true,
            'label' => 'Save Pricing',
            'class' => 'btn btn-info'
        ));

        $this->addElement('button', 'Cancel Pricing', array(
            'ignore' => true,
            'label' => 'Cancel',
            'class' => 'btn cancel_category_pricing btn-info',
            'data-company-id' => $this->_companyId
        ));
    }

    public function isValid($data) {
        $status = parent::isValid($data);
        if (!$status) {
            return false;
        }
        $dataArr = array();
        $defPricingCountries = array();
        $accessObj = new Model_AccessDays();
        $accessDaysIds = $accessObj->getAccessDaysById('osl');
        $catPriceSet = false;
        $allCatPriceSet = false;
        if (!empty($data['companyPricingCat'])) {
            $defCountries = array();
            $countries = array();
            $learnerRArr = array();
            $initialCluster = $initialCountry = $initailLocationMode = 0;
            foreach ($data['companyPricingCat'] as $key => $value) {
                if ($key != '__template__') {
                    if (!empty($value)) {
                        if ($value['linkable_id_prod'] == 0) {
                            $allCatPriceSet = true;
//                            $this->getSubForm('companyPricingCat')
//                                 ->getSubForm($key)->getElement('linkable_id_prod')
//                                 ->setErrors(array("Category is required."));
//                            $status = false;
                        }

                        if (empty($value['flat_price'])) {
                            $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('flat_price')->setErrors(array("Flatprice is required."));
                            $status = false;
                        }
                        if (!empty($value['flat_price']) && $value['flat_price'] < 0) {
                            $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('flat_price')->setErrors(array("Flatprice cannot be negative."));
                            $status = false;
                        } else {
                            $catPriceSet = true;
                        }
                        if ($value['flat_discount'] == 0 && $value['flat_discount'] != '') {
                            $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('flat_discount')->setErrors(array("Discount should be between 1-100."));
                            $status = false;
                        }
                        if (!empty($value['flat_discount']) &&  ($value['flat_discount'] < 1 || $value['flat_discount'] > 100)) {
                            $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('flat_discount')->setErrors(array("Discount should be between 1-100."));
                            $status = false;
                        }
                        if (!empty($value['access_day_id']) && $value['access_day_id'] != array_search(ENTERPRISE_ACCESS_DAYS, $accessDaysIds)) {
                            $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('access_day_id')->setErrors(array("Access Days can only be " . ENTERPRISE_ACCESS_DAYS));
                            $status = false;
                        }
                        if ($value['location_mode'] == 0) {
                            $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('location_mode')->setErrors(array("location_mode is required."));
                            $status = false;
                        } elseif ($value['location_mode'] > 0) {

                            if (empty($initailLocationMode)) {
                                $initailLocationMode = $value['location_mode'];
                            }

                            if ($initailLocationMode !== $value['location_mode']) {
                                $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('location_mode')->setErrors(array("Pricing Level mismatch.it should be similar with the previous Pricing Level value."));
                                $status = false;
                            }

                            if ($value['location_mode'] == 1 && $value['cluster_id'] == 0) {
                                $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('cluster_id')->setErrors(array("Please select cluster for pricing."));
                                $status = false;
                            }
                            if ($value['location_mode'] == 1 && $value['cluster_id'] > 0) {
                                if (empty($initialCluster)) {
                                    $initialCluster = $value['cluster_id'];
                                }
                                if ($initialCluster !== $value['cluster_id']) {
                                    $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('cluster_id')->setErrors(array("Cluster Mismatch.It should be similar with the previous Cluster value."));
                                    $status = false;
                                }

                                if (!empty($this->getSubForm('companyPricingCat')->getSubForm($key))) {
                                    $this->getSubForm('companyPricingCat')
                                            ->getSubForm($key)->getElement('cluster_id')
                                            ->setAttrib('style', 'display: block;');
                                    $clusterLabel = $this->getSubForm('companyPricingCat')
                                            ->getSubForm($key)
                                            ->getElement('cluster_id')
                                            ->getDecorator('Label');
                                    $clusterLabel->setOption('style', 'display: block;');
                                }
                            }
                            if ($value['location_mode'] == 2 && $value['country_id'] == 0) {
                                $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('country_id')->setErrors(array("Please select country for pricing."));
                                $status = false;
                            }
                            if ($value['location_mode'] == 2 && $value['country_id'] > 0) {

                                if (empty($initialCountry)) {
                                    $initialCountry = $value['country_id'];
                                }

                                if ($initialCountry !== $value['country_id']) {
                                    $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('country_id')->setErrors(array("Country Mismatch.It should be similar with the previous Country value."));
                                    $status = false;
                                }
                                if (!empty($this->getSubForm('companyPricingCat')->getSubForm($key))) {
                                    $this->getSubForm('companyPricingCat')
                                            ->getSubForm($key)
                                            ->getElement('country_id')
                                            ->setAttrib('style', 'display: block;');
                                    $countrylabel = $this->getSubForm('companyPricingCat')
                                            ->getSubForm($key)
                                            ->getElement('country_id')
                                            ->getDecorator('Label');
                                    $countrylabel->setOption('style', 'display: block;');
                                }
                            }
                        }

//                        if ($value['def_country_id'] == 0) {
//                            $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('def_country_id')->setErrors(array("Please select default country for pricing."));
//                            $status = false;
//                        } else {
//                            if (count($defCountries) >= 1 && !in_array($value['def_country_id'], $defCountries)) {
//                                $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('def_country_id')->setErrors(array("Default country has to be same accross multiple pricings."));
//                                $status = false;
//                            }
//                            if (count($defPricingCountries) >= 1 && !in_array($value['def_country_id'], $defPricingCountries)) {
//                                $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('def_country_id')->setErrors(array("Default country has to be same accross multiple pricings."));
//                                $status = false;
//                            }
//                            $defCountries[] = $value['def_country_id'];
//                            $defPricingCountries[] = $value['def_country_id'];
//                        }
                        if (empty($learnerRArr[$value['linkable_id_prod']])) {
                            $learnerRArr[$value['linkable_id_prod']] = array(
                                'data' => array(),
                                'maxVals' => array(),
                            );
                        }
                        $status = $this->validateLRCat($status, $value, $key, $learnerRArr[$value['linkable_id_prod']], 'companyPricingCat');
                        if (!$status) {
                            break;
                        }
                        $learnerRArr[$value['linkable_id_prod']]['data'][$value['learners_range_min']] = $value['learners_range_min'] . '_' . $value['learners_range_max'] . '_' . $key;
                        $learnerRArr[$value['linkable_id_prod']]['maxVals'][$value['learners_range_max']] = 1;

                        /* if ($value['country_id'] != US_COUNTRY_ID) {
                          $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('country_id')->setErrors(array("Country other than US not allowed."));
                          $status = false;
                          break;
                          } */
                        $countries[] = $value['country_id'];

                        if ($value['access_day_id'] == 0) {
                            $this->getSubForm('companyPricingCat')->getSubForm($key)->getElement('access_day_id')->setErrors(array("Please select accessDays for pricing."));
                            $status = false;
                        }
                    }
                }
            }

            if ($status && !empty($learnerRArr)) {
                foreach ($learnerRArr as $key => $value) {
                    $catData = $value['data'];
                    if (empty($catData[1])) {
                        $data = array_shift($catData);
                        $data = explode('_', $data);
                        $this->getSubForm('companyPricingCat')->getSubForm($data[2])->getElement('learners_range_min')->setErrors(array("Learners range min has to start with 1."));
                        $status = false;
                        break;
                    }
                    ksort($catData);
                    $catDataMax = array_pop($catData);
                    $catDataMax = explode('_', $catDataMax);
                    if (!empty($catDataMax[1]) && $catDataMax[1] != 0) {
                        $this->getSubForm('companyPricingCat')->getSubForm($catDataMax[2])->getElement('learners_range_max')->setErrors(array("Learners range max for last range has to be zero(0)."));
                        $status = false;
                        break;
                    }
                    $catData = $value['data'];
                    ksort($catData);
                    $lastMax = 0;
                    foreach ($catData as $key => $value) {
                        $catDataVal = explode('_', $value);
                        if ($key != 1 && !empty($catDataVal[0]) && $catDataVal[0] != ++$lastMax) {
                            $this->getSubForm('companyPricingCat')->getSubForm($catDataVal[2])->getElement('learners_range_min')->setErrors(array("Learners range min has to be max + 1 for previous range."));
                            $status = false;
                            break;
                        }
                        $lastMax = $catDataVal[1];
                    }
                }
            }
            if (!empty($defCountries) && !empty($countries)) {
                if (!empty(array_diff($countries, $defCountries))) {
                    $this->getSubForm('companyPricingCat')->getSubForm('new')->getElement('country_id')->setErrors(array("Default Country has to match country in all category pricings."));
                    $status = false;
                }
            }
            if ($status && !$allCatPriceSet && !empty($learnerRArr)) {
                //$this->getSubForm('companyPricingCat')->getSubForm('new')->getElement('linkable_id_prod')->setErrors(array("Please set All Category Pricing."));
                //$status = false;
            }
        }
        return $status;
    }

    public function validateLRCourse($status, $value, $key, $learnerRArr, $name) {
        if ($value['learners_range_min'] < 0 || !filter_var($value['learners_range_min'], FILTER_VALIDATE_INT)) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_min')->setErrors(array("Learners range has to be integer."));
            return false;
        }
        if ($value['learners_range_max'] > 0 && !filter_var($value['learners_range_max'], FILTER_VALIDATE_INT)) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_max')->setErrors(array("Learners range has to be integer."));
            return false;
        }
        if ($value['learners_range_max'] != 0 && $value['learners_range_min'] >= $value['learners_range_max']) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_max')->setErrors(array("Learners range max has to be greater than min."));
            return false;
        }

        if (!empty($learnerRArr['data'][$value['training_id']][$value['learners_range_min']])) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_min')->setErrors(array("Learners range min cannot be same for a category."));
            return false;
        }
        if (!empty($learnerRArr['data'][$value['training_id']][$value['learners_range_max']])) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_max')->setErrors(array("Learners range max cannot be same as min for a category."));
            return false;
        }
        if (!empty($learnerRArr['maxVals'][$value['training_id']][$value['learners_range_min']])) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_min')->setErrors(array("Learners range min cannot be same as max for a category."));
            return false;
        }
        if (!empty($learnerRArr['maxVals'][$value['training_id']][$value['learners_range_max']])) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_max')->setErrors(array("Learners range max cannot be same for a category."));
            return false;
        }
        return $status;
    }

    public function validateLRCat($status, $value, $key, $learnerRArr, $name) {
        if ($value['learners_range_min'] < 0 || !filter_var($value['learners_range_min'], FILTER_VALIDATE_INT)) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_min')->setErrors(array("Learners range has to be integer."));
            return false;
        }
        if ($value['learners_range_max'] > 0 && !filter_var($value['learners_range_max'], FILTER_VALIDATE_INT)) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_max')->setErrors(array("Learners range has to be integer."));
            return false;
        }
        if ($value['learners_range_max'] != 0 && $value['learners_range_min'] >= $value['learners_range_max']) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_max')->setErrors(array("Learners range max has to be greater than min."));
            return false;
        }

        if (!empty($learnerRArr['data'][$value['learners_range_min']])) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_min')->setErrors(array("Learners range min cannot be same for a category."));
            return false;
        }
        if (!empty($learnerRArr['data'][$value['learners_range_max']])) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_max')->setErrors(array("Learners range max cannot be same as min for a category."));
            return false;
        }
        if (!empty($learnerRArr['maxVals'][$value['learners_range_min']])) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_min')->setErrors(array("Learners range min cannot be same as max for a category."));
            return false;
        }
        if (!empty($learnerRArr['maxVals'][$value['learners_range_max']])) {
            $this->getSubForm($name)->getSubForm($key)->getElement('learners_range_max')->setErrors(array("Learners range max cannot be same for a category."));
            return false;
        }
        return $status;
    }

    protected function getSubFormDecoratorsMain($className, $id) {
        return array(
            'FormElements',
            array(
                'HtmlTag', array('tag' => 'ul')
            ),
            array(
                array('row' => 'HtmlTag'),
                array('tag' => 'li', 'class' => $className, 'id' => $id)
            )
        );
    }

    public function removeUneditableElements() {
        $this->removeElement('url');
        return false;
    }

    public function subFormValidations($data, $subForm, $status) {
        $count = 0;
        $accessDays = $data;
        end($accessDays);
        $keyA = key($accessDays);
        if ($subForm == 'accessDays' && count($data) > 2) {
            $this->getSubForm($subForm)->getSubForm($keyA)->getElement('accessDays')->setErrors(array("Only 2 bundle prices are allowed."));
            $status = false;
        }
        return $status;
    }

    public function _decorate() {

    }

    private function _getCategoryList() {
        $compProductObj = new Model_CompanyProductMapper();
        $categoryData = $compProductObj->fetchAll(array('company_id =?' => $this->_companyId, 'linkable_type = ?' => 'category', 'status = ?' => 1), array('order' => 'order'));
        $categorieIdArr = array_column($categoryData, 'linkable_id');
        $obj = new Model_Labels();
        $categoryList = $obj->getLabelsToshow();
        $categoryFilter = array_intersect_key($categoryList, array_flip($categorieIdArr));
        return $categoryFilter;
    }

    private function _getCompanyPriceRange() {
        $rangeData = array();
        $learnerRangeObj = new Model_LearnersRange();
        $larnerRangeData = $learnerRangeObj->getByLinkable($this->_companyId);
        if (!empty($larnerRangeData)) {
            $rangeData = array_combine(range(1, count($larnerRangeData)), $larnerRangeData);
        }
        return $rangeData;
    }

}
