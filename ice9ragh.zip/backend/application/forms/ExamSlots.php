<?php

class Form_ExamSlots extends BaseApp_Form
{
    
    public function __construct() {
        parent::__construct();
    }
    
    const COUNTRY_ID_INDIA=6;
    const EXAM_VOUCHER_FEES_COST_LABEL_ID=1;

    public function init(){
        
        $cityMdl =new Model_City();
        $city = $cityMdl->fetchForSelect(array('country_id=?'=>self::COUNTRY_ID_INDIA));
        
        $examDetailsMdl= new Model_ExamDetails();
        $exams = $examDetailsMdl->fetchForSelect(array('status=?'=>1));
        
        $this->setMethod('post');
        $this->setName('examSlot');
        
       $this->addElement('select','exam_id',array(
            'required'=>true,
            'label'=>'Exam',
            'registerInArrayValidator' =>false,
            'multioptions'=>$exams
        ));
        
       
        $this->addElement('text','country_id',array(
            'required'=>true,
            'label' => 'Country',
            'readonly'=>true,
            'value'=>'India'
            ));
       
        $this->addElement('select','exam_slot_city_id',array(
            'required'=>true,
            'label' => 'City',
            'registerInArrayValidator' => false,
            'multioptions'=>$city
            ));

        $this->addElement('select', 'exam_venue_id', array(
            'label' => 'Venue',
            'required' => true,
            'registerInArrayValidator' => false,
        ));

        $this->addElement('text','exam_date',array(
            'label'=>'Date',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'datepicker'
        ));
       
        $this->addElement('text','start_time',array(
            'label'=>'Exam Start Time',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'readonly' => 'readonly',
            'class'=>'timepicker'
        ));
        $this->addElement('text','end_time',array(
            'label'=>'Exam End Time',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'readonly' => 'readonly',
            'class'=>'timepicker'
        ));
       
        /* $this->addElement('text','head_count',array(
            'label'=>"Seats Available",
            'required'=>false
        ));
        */
        
        $this->addElement('submit','save',array(
          'ignore'=>true,
          'label'=>'Save',
          
         ));
    }
       
    
//    public function setValues($data){
//
//        if(!empty($data['exam_slot']))
//        {
//        $exam_slot= explode('-', $data['exam_slot']);
//        $this->getElement('start_time')->setValue($exam_slot[0]);
//        $this->getElement('end_time')->setValue($exam_slot[1]);
//        }
//        $examName = (array)$this->getElement('exam_id');
//        $this->getElement('exam_id')->clearMultiOptions();
//        $this->getElement('exam_id')->addMultiOption($data['exam_id'],$examName['options'][$data['exam_id']]);
//        $this->getElement('exam_slot_city_id')->setValue($data['city_id']);
//        $this->getElement('exam_date')->setValue($data['exam_date']);
//        $this->getElement('save')->setLabel('Update');
//    }
    
}

