<?php

class Form_CourseAdvisors extends BaseApp_Form
{

    public function init(){

        $this->setName('CourseAdvisors');
        $this->setMethod('post');
         //adding Label name element

        $this->addElement('text','name',array(
            'label'=>'Name*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'placeholder'=>'Course Advisors Name'
            // 'validators'=>array(
            //     new Zend_Validate_Db_NoRecordExists(array(
            //     'table' => 'courseAdvisors',
            //     'field' => 'name'
            // )),new Zend_Validate_NotEmpty(), new Zend_Validate_StringLength(array('min' => 2,'max'=>40)))
        ));

        $this->addElement('text','imageUrl',array(
            'label'=>'Image Url*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'placeholder'=>'Course Advisors Image',
            'validators' => array(
                new BaseApp_Validate_Image('courseAdvisor', 'image')
            )
        ));

        $this->addElement('text','designation',array(
            'label'=>'Designation*',
            'required'=>true,
            'placeholder'=>'Course Advisors Designation',
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('text','alt_text',array(
            'label'=>'Alt Text',
            'required'=>false,
            'placeholder'=>'Course Advisors Alt text',
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
            
        ));

        $this->addElement('text','acheivementText',array(
            'label'=>'Acheivements',
            'required'=>false,
            'placeholder'=>'Course Advisors acheivement text',
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));
        
        $this->addElement('text','linkedin_url',array(
                'label'=>'Linked In Url*',
                'required'=>true,
                'filters'=>array('StringTrim'),
                'class'=>'longtext',
                'placeholder'=>'Linked In Url'
        ));
        
        $this->addElement('text','twitter_url',array(
                'label'=>'Twitter Url*',
                'required'=>true,
                'filters'=>array('StringTrim'),
                'class'=>'longtext',
                'placeholder'=>'Twitter Url'
        ));

        $this->addElement('textarea','description',array(
            'label'=>'Bio*',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'class' =>'fck-enable'
        ));

        // $this->addElement('textarea','long_description',array(
        //     'label'=>'Bio For Course',
        //     'required'=>true,
        //     'filters'=>array('StringTrim'),
        //     'class'=>'longtext',
        //     'class' =>'fck-enable'
        // ));

         $obj =new Model_Labels();
         $this->addElement('select','label_id_arr',array(
            'label'=>'Associated Labels',
            'required'=>false,
            'multiple' => true,
            'class' => 'courseListAll', 
            'registerInArrayValidator' => false,
            'multioptions'=>$obj->getLabelsToshow()                 
        ));

        $course = new Model_Courses();
        $this->addElement('select','course_id_arr',array(
            'label'=>'Associated Courses',
            'required'=>false,
            'multiple' => true,
            'class' => 'courseListAll', 
            'registerInArrayValidator' => false,
            'multioptions'=>array('0'=>'--Select--') +$course->fetchForSelect(array('is_dummy = ?' => 0, 'is_free = ?' => 0))
         ));

         $bundle = new Model_Bundles();
         $this->addElement('select','bundle_id_arr',array(
            'label'=>'Associated Bundles',
            'required'=>false,
            'multiple' => true,
            'registerInArrayValidator' => false,
            'class' => 'courseListAll', 
            'multioptions'=>$bundle->fetchForSelect()
        ));
        
         $this->addElement('submit','Add Course Advisors',array(
          'ignore'=>true,
          'label'=>'Add Course Advisors',
          'class'=>'btn btn-info'
         ));
        
        $validatorsLogoAndDirectorDesig = array(new Zend_Validate_StringLength(array('min' => 2,'max'=>80)));
        $validatorsLogoAndDirectorAchie = array(new Zend_Validate_StringLength(array('min' => 2,'max'=>40)));
        $validatorsDirectorDesc = array(new Zend_Validate_StringLength(array('min' => 2,'max'=>300)));
         
        //$this->getElement('name')->addValidators($validatorsLogoAndDirectorName);
        $this->getElement('designation')->addValidators($validatorsLogoAndDirectorDesig);
        $this->getElement('acheivementText')->addValidators($validatorsLogoAndDirectorAchie);
        $this->getElement('description')->addValidators($validatorsDirectorDesc);
        
    }

    public function isValid($data) {
        $status = parent::isValid($data);
        if(!$status)
            return false;
        if(!empty($data['linkedin_url'])){
            $data['linkedin_url'] = trim($data['linkedin_url']);
            $file_headers = @get_headers($data['linkedin_url']);
            if(!$file_headers || $file_headers[0] == 'HTTP/1.1 404 Not Found') {
                $this->getElement('linkedin_url')->setErrors(array("'{$data['linkedin_url']}' is not a valid linked in url"));
                $status = false;
            }
        }
        if(!empty($data['twitter_url'])){
            $data['twitter_url'] = trim($data['twitter_url']);
            $file_headers = @get_headers($data['twitter_url']);
            if(!$file_headers || $file_headers[0] == 'HTTP/1.1 404 Not Found') {
                $this->getElement('twitter_url')->setErrors(array("'{$data['twitter_url']}' is not a valid linked in url"));
                $status = false;
            }
        }
        return $status;
    }
}