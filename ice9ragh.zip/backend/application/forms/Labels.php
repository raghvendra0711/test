<?php
class Form_Labels extends BaseApp_SubForm
{
    protected $submitName = 'Save Label';
    private $_vData = array();

    public function init(){
        $this->setName('labels');
        $this->setMethod('post');

        $validators = array(
    			new Zend_Validate_Db_NoRecordExists(array(
    			'table' => 'labels',
    			'field' => 'name'
    	)),new Zend_Validate_NotEmpty(), new Zend_Validate_StringLength(array('max' => 100)));

        $validateDisplayName = array(
    			new Zend_Validate_Db_NoRecordExists(array(
    			'table' => 'labels',
    			'field' => 'displayName'
    	)),new Zend_Validate_NotEmpty(), new Zend_Validate_StringLength(array('max' => 100)));

        $validatorsIntroText = array(new Zend_Validate_StringLength(array('min' => 2,'max'=>500)));
        $validatorsShortDesc = array(new Zend_Validate_StringLength(array('min' => 2,'max'=>70)));
         //adding Label name element

         $this->addElement('text','name',array(
            'label'=>'Name of the Label',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('text','displayName',array(
            'label'=>'Display Name',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('text','shortDescription',array(
            'label'=>'A small description',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
             'validators' => $validatorsShortDesc
        ));

        $this->addElement('textarea','bannerText',array(
            'label'=>'Intro Text for Label',
            'filter'=>array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'class'=>'description',
            'validators' => $validatorsIntroText
        ));

        $this->addElement('checkbox','isListView',array(
                'label'=>'Display List View ?',
                'required'=>false
        ));

        $this->addElement('text','imagePath',array(
            'label'=>'Image',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext',
            'validators' => array(
                new BaseApp_Validate_Image('labels', 'imagePath')
            )
        ));

        $this->addElement('text','imageDescription',array(
            'label'=>'Alt text',
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('text','url',array(
            'label'=>'URL for the Label',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $obj =new Model_Labels();
        $this->addElement('select','parentLabel',array(
            'label'=>'Vertical',
            'required'=>false,
            'multioptions'=>$obj->getParentLabels(),
            'multiple' => true,
            'class' => 'multiple',
            'registerInArrayValidator' => false
        ));




        $this->addElement('text','videoLink',array(
            'label' => 'Embeded You Tube Video',
            'placeholder'=>" Please Enter A Embeded You Tube video Link",
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('text','dateCreated',array(
            'label' => 'Video Uploaded date',
            'placeholder'=>"YYYY-MM-DD",
            'required'=>false,
            'filters'=>array('StringTrim'),
            'attribs' => array('readonly' => 'readonly'),
            'class'=>'longtext'
        ));

        $this->addElement('text','videoThumbnail',array(
            'label' => 'Video Thumbnail Image',
            'placeholder'=>" Please Enter video Thumbnail Image",
            'required'=>false,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('textarea','videoDescription',array(
            'label'=>'Video Description',
            'filter'=>array('StringTrim'),
            'rows' => 5,
            'cols' => 60,
            'attribs' => array('readonly' => 'readonly'),
            'class'=>'description'
        ));

        $accreditorObj = new Model_Accreditors();
        $accreditorCond = array('isCategoryCoursePage'=>1);
        $this->addElement('select', 'accreditor_id', array(
            'label' => 'Is the Course Accredited ?',
            'required' => false,
            'class' => 'multiple',
            'multiple' => true,
            'registerInArrayValidator' => false,
            'multioptions' => $accreditorObj->fetchForSelect($accreditorCond)
        ));

        $obj =new Model_ProductSectionData();
        $obj->setDisplayField('name');
        $this->addElement('select','company',array(
                'label'=>'Company Section(Max 5 allowed)',
                'required'=>false,
                'multiple' => true,
                'class' => 'multiple',
                'registerInArrayValidator' => false,
                'multioptions'=>array('0'=>'--Select--') + $obj->fetchForSelect(array('sectionType = ?' => "company"))
        ));

        $obj->setDisplayField('name');
        $this->addElement('select','course_advisor',array(
                'label'=>'Course Advisor Section',
                'required'=>false,
                'multiple' => true,
                'class' => 'multiple',
                'registerInArrayValidator' => false,
                'multioptions'=>array('0'=>'--Select--') + $obj->fetchForSelect(array('sectionType = ?' => "directors"))
        ));


        $obj->setDisplayField('name');
        $this->addElement('select','alumni',array(
                'label'=>'Alumni Section(Max 4 allowed)',
                'required'=>false,
                'multiple' => true,
                'class' => 'multiple',
                'registerInArrayValidator' => false,
                'multioptions'=>array('0'=>'--Select--') + $obj->fetchForSelect(array('sectionType = ?' => "Alumni"))
        ));

        $bundleObj = new Model_Bundles();
        $this->addElement('select','default_subscription_id',array(
            'label'=>'Default Subscription',
            'required'=>false,
            'multioptions'=>array('0'=>'--Select--') + $bundleObj->fetchForSelect(array('payment_type_id = ?' => BaseApp_Dao_PaymentType::SUBSCRIPTION_PAYMENT_TYPE_ID))
        ));
        
        $bundleObj = new Model_Bundles();
        $conditions = array(
            'partialView =?' => 0,
            'hideFromSearch =?' => 0,
            'status =?' => 1
        );
        if(!empty($this->getView()->labelId)) {
            $labelId = $this->getView()->labelId;
            $conditions['FIND_IN_SET(?, label_id)>0'] = $labelId;
        }
        $bundleList = $bundleObj->fetchForSelect($conditions);
        $this->addElement('select','default_bundle_id',array(
            'label'=>'Default Master Program',
            'required'=>false,
            'multioptions'=>array('0'=>'--Select--') + $bundleList
        ));

        /* Sub form start*/
        $subForm = new Zend_Form_SubForm();
        $subForm->setName('subscriptionPrice');

        $session = new Zend_Session_Namespace('form');
        foreach ($session->keyfeatures as $product) {
            $keyCountry = isset($session->data[$product]['country_id'])?$session->data[$product]['country_id']:'';
            $keyCurrency = isset($session->data[$product]['currency_id'])?$session->data[$product]['currency_id']:'';
            $keyDays = isset($session->data[$product]['access_day_id'])?$session->data[$product]['access_day_id']:'';
            $keyprice = isset($session->data[$product]['subscriptionPrice'])?$session->data[$product]['subscriptionPrice']:'';

            $rowForm = new Zend_Form_SubForm();
            $rowForm->setName($product);

            if ($product === '__template__') {
                $rowForm->setAttrib('style', 'display: none;');
            }

            $country = new Zend_Form_Element_Select('country_id');
            $countryModel = new Model_Country();
            $country->setOptions(array('multioptions' => array(0=>'--Select--')+$countryModel->getListDisplay()))->setValue($keyCountry)->setAttrib('class', 'country')->setLabel('Country');

            $currency = new Zend_Form_Element_Select('currency_id');
            $currencyModel = new Model_Currency();
            $currency->setOptions(array('multioptions' => $currencyModel->getCurrencyToDisplay()))->setValue($keyCurrency)->setAttrib('class', 'currency')->setLabel('Currency');

            $days = new Zend_Form_Element_Select('access_day_id');
            $accessObj = new Model_AccessDays();
            $days->addFilter('stringTrim')->setValue($keyDays)->setAttrib('class', 'accessDaysCount')->setAttrib('placeholder', 'Access Days')->setLabel('Access Days')->setOptions(array('multioptions' => array('0' => '--Select--') + $accessObj->getAccessDaysById('osl'), 'registerInArrayValidator' => false));

            $price = new Zend_Form_Element_Text('subscriptionPrice');
            $price->addFilter('stringTrim')->setValue($keyprice)->setAttrib('class', 'subscriptionPrice')->setLabel('Price');

            $removePrice = new Zend_Form_Element_Button('remove');
            $removePrice->setLabel('Remove')->setAttrib('class', 'btn btn-danger remove')->setAttrib('onclick', 'removeSubFormElement(this)');

            $elements = array($country, $currency, $days, $price);
            if ($product !== 'new') {
                $elements[] = $removePrice;
            }


            $rowForm->addElements($elements);
            $rowForm->setElementDecorators($this->getElementDecorators());

            if($rowForm->getElement('remove')) {
                $rowForm->getElement('remove')->removeDecorator('Label');
            }

            $rowForm->setDecorators($this->getSubFormDecorators());
            $subForm->addSubForm($rowForm, $product);
        }


        $subForm->setDecorators($this->getSubFormDecoratorsMain());

        $addPrice = new Zend_Form_Element_Button('add');
        $addPrice->setLabel('Add More')->setAttrib('class', 'btn btn-warning add');
        $subForm->addElement($addPrice);

        $subForm->setElementDecorators($this->getElementDecorators());
        $subForm->getElement('add')->removeDecorator('Label');
        $this->addSubForm($subForm, 'subscriptionPrice');
        $this->postSetup();
        /* Sub form end*/

        $this->getElement('name')->addValidators($validators);
        $this->getElement('displayName')->addValidators($validateDisplayName);
//         $this->getElement('bannerText')->addValidators(array(new Zend_Validate_StringLength(array('max' => 150))));
    }

     public function removeOptionalValidators() {
        //$this->getElement('course_name')->removeValidator('Db_NoRecordExists');
        $this->getElement('displayName')->removeValidator('Db_NoRecordExists');
        //$this->getElement('course_name')->setRequired(false);
        $this->getElement('displayName')->setRequired(false);
    }


    protected function getSubFormDecorators()
    {
        return array(
            'FormElements',
            array('HtmlTag', array('tag' => 'ul')),
            'Fieldset',
            array(
                array('row' => 'HtmlTag'),
                array('tag' => 'li', 'class' => 'subform')
            )
        );
    }

    protected function getSubFormDecoratorsMain($Id='subscribePriceContainer',$class='subscribePriceContainer') {
        return array(
            'FormElements',
            array(
                'HtmlTag', array('tag' => 'ul')
            ),
            array(
                array('row' => 'HtmlTag'),
                array('tag' => 'li', 'class' => $class, 'id' => $Id)
            )
        );
    }

    protected function getElementDecorators()
    {
        $elementDecorators = array(
            'ViewHelper',
            'Errors',
            array(
                'Label',
                array('class' => 'lab')
            ),
            array(
                array('row' => 'HtmlTag'),
                array('tag' => 'li'),
            )
        );

        return $elementDecorators;
    }

    public function removeUneditableElements(){
         $this->removeElement('name');
         $this->removeElement('displayName');
         $this->removeElement('orderNo');
         $this->removeElement('url');
    }

    public function removeVideoElements(){
        $this->removeElement('dateCreated');
        $this->removeElement('videoDescription');
   }

    public function isValid($data) {
        $status = parent::isValid($data);
        if(!$status)
            return $status;
        if(!empty($data['url'])){
            $data['url'] = trim($data['url']);
            $checkSlash = substr($data['url'], 0,1);
            if($checkSlash != '/'){
                $data['url'] = trim('/'.$data['url']);
            }
            $objSeo = new Model_Seo();
            if(false === $objSeo->validateUrl($data['url'])){
                $this->getElement('url')->setErrors(array("'{$data['url']}' is not a valid Label url"));
                return false;
            }
        }
        if($data['videoLink']){
            $videoLink = "";
            if (!empty($this->getView()->labelId)) {
                $labelId = $this->getView()->labelId;
                $modelVideo = new Model_Videos();
                $videoData = $modelVideo->getByLinkableId($labelId, 'label', false, 'about_label');
                $videoLink = isset($videoData['videoLink']) ? $videoData['videoLink'] : "";
            }
            if (strpos( strtolower($data['videoLink']),'https://www.youtube.com/embed/' ) === false) {
                $this->getElement('videoLink')->setErrors(array("Link should be Https and also Emebed link"));
                $status = false;
            } else if($data['videoLink'] != $videoLink){
                $youtubeApi = new BaseApp_Utility_YoutubeApi();
                $this->_vData = $youtubeApi->getVideoDetails($data['videoLink'],"snippet,contentDetails");
                if(!is_array($this->_vData)){
                    if($this->_vData == BaseApp_Utility_YoutubeApi::INVALID_VIDEO){
                    $this->getElement('videoLink')->setErrors(array("Please enter valid youtube video link"));
                    }
                    else if ($this->_vData == BaseApp_Utility_YoutubeApi::LIMIT_ERROR) {
                        $this->getElement('videoLink')->setErrors(array("Daily limit for authenticated use exceeded"));
                    } else {
                        $this->getElement('videoLink')->setErrors(array("Something is wrong with api."));
                    }
                    $status = false;
                }
            }
            if(!$data['videoThumbnail']){
                $this->getElement('videoThumbnail')->setErrors(array("video thumb nail image required"));
                $status = false;
            }elseif (strpos( strtolower($data['videoThumbnail']),'https://img.youtube.com/' ) === false) {
                $this->getElement('videoThumbnail')->setErrors(array("Link should be Https and also Youtube link"));
                $status = false;
            }
        }

        return $status;
    }

    public function getVideoData(){
        return $this->_vData;
    }
}

