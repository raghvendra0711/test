<?php

class Form_CourseContent extends BaseApp_Form
{
    public function init(){
        $this->setName('CourseContent');
        $this->setMethod('post');
         //adding Label name element
        
         $this->addElement('textarea','shortDescription',array(
            'label'=>'Short Description for the Course',
            'required'=>true,
            'cols' => 60,
            'rows' => 6,
            'class'=>'longtext'
        ));


         $objSection = new Model_SectionTemplates();
         $sectionTemplates = $objSection->fetchAll();

         foreach($sectionTemplates as $key => $value){
            $this->addElement('text',"inclusions_".$value['section_id'],array(
                'label'=>'Section Titles Within Pages',
                'required'=>true,
                'value'=>$value['name'],
                'class'=>'inclusions',
                'readonly'=>'readonly',
                'filter'=>array('StringTrim')
            ));
            $this->addElement('text',"inclusions_menu".$value['section_id'],array(
                'label'=>'Corressponding Menu Item',
                'required'=>true,
                'class'=>'inclusions',
                'readonly'=>'readonly',
                'value'=>$value['menuItem'],
                'filter'=>array('StringTrim')
            ));
         }
         //adding course submit element
    }
}

