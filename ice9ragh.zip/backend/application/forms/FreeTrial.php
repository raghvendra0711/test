<?php

class Form_FreeTrial extends BaseApp_Form
{
    public function init()
    {
        $this->setName('FreeTrial');
        $this->setMethod('post');

        $validatorsDescription = array(new Zend_Validate_StringLength(array('max' => 50)));
        $validatorsTTText = array(new Zend_Validate_StringLength(array('min' => 2,'max'=>700)));

        $objCluster =new Model_Clusters();
        $this->addElement('select','cluster_id_ft',array(
            'label'=>'Clusters',
            'required'=>false,
            'registerInArrayValidator' => false,
            'multioptions'=> array('0'=>'--Select--') + $objCluster->fetchForSelect()
        ));

        $objCountry =new Model_Country();
        $this->addElement('select','country_id_ft',array(
            'label'=>'Countries Associated for Course',
            'required'=>false,
            'registerInArrayValidator' => false,
            'multioptions'=> array('0'=>'--Select--') + $objCountry->getListDisplay()
        ));

        $objLabels =new Model_Labels();
         $this->addElement('select','label_id_ft',array(
            'label'=>'Labels',
            'required'=>false,
            'registerInArrayValidator' => false,
            'multioptions'=> array('0'=>'--Select All --') +  $objLabels->fetchForSelect()
        ));

        $course = new Model_Courses();
        $this->addElement('select', 'course_id_ft', array(
            'label'=>'Courses',
            'required'=>false,
            'multiple' => true,
            'registerInArrayValidator' => false,
            'class' => 'courseListAll',
            'multioptions'=>array('0'=>'--Select--') + $course->getCoursesByPricing(array('training_id' => array(BaseApp_Dao_TrainingTypes::TYPE_ELEARNING, BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS)))
        ));

        $this->addElement('button', 'course_inward_ft', array(
            'label'=>'Invert Courses',
            'ignore'=>true,
            'class'=>'btn btn-warning'
        ));

        $this->addElement('submit', 'Save Courses', array(
          'ignore'=>true,
          'label'=>'Save Courses',
          'class'=>'btn btn-info'
         ));

        $objCluster =new Model_Clusters();
        $this->addElement('select','cluster_id_mp_ft',array(
            'label'=>'Clusters',
            'required'=>false,
            'registerInArrayValidator' => false,
            'multioptions'=> array('0'=>'--Select--') + $objCluster->fetchForSelect()
        ));

        $objCountry =new Model_Country();
        $this->addElement('select','country_id_mp_ft',array(
            'label'=>'Countries Associated for Bundles',
            'required'=>false,
            'registerInArrayValidator' => false,
            'multioptions'=> array('0'=>'--Select--') + $objCountry->getListDisplay()
        ));

        $bundle = new Model_Bundles();
         $this->addElement('select','bundle_id_ft',array(
            'label'=>'Bundles',
            'required'=>false,
            'multiple' => true,
            'registerInArrayValidator' => false,
            'class' => 'courseListAll',
            'multioptions'=>$bundle->getBundlesByPricings(array('training_id' =>array(BaseApp_Dao_TrainingTypes::TYPE_ELEARNING)))
        ));

        $this->addElement('button','bundle_inward_ft',array(
            'label'=>'Invert Bundles',
            'ignore'=>true,
            'class'=>'btn btn-warning'
        ));

        $this->addElement('submit', 'Save Bundles', array(
          'ignore'=>true,
          'label'=>'Save Bundles',
          'class'=>'btn btn-info'
         ));


        // $this->addElement('hidden','tmp_id',array(
        //     'required'=>false,
        //     'value'=>''
        // ));

        $this->addElement('textarea','freetrial_osl_desc',array(
                'label'=>'Free Trial Text For OSL',
                'filter'=>array('StringTrim'),
                'rows' => 5,
                'cols' => 60,
                'class'=>'b2b_contents fck-enable',
                'validators' => $validatorsTTText,
        ));

        $this->addElement('textarea','freetrial_lvc_desc',array(
                'label'=>'Free Trial Text For LVC',
                'filter'=>array('StringTrim'),
                'rows' => 5,
                'cols' => 60,
                'class'=>'b2b_contents fck-enable',
                'validators' => $validatorsTTText,
        ));

        $this->addElement('textarea','freetrial_mp_osl_desc',array(
                'label'=>'Free Trial OSL Text For Masters Program',
                'filter'=>array('StringTrim'),
                'rows' => 5,
                'cols' => 60,
                'class'=>'b2b_contents fck-enable',
                'validators' => $validatorsTTText,
        ));

        $this->addElement('textarea','freetrial_mp_lvc_desc',array(
                'label'=>'Free Trial LVC Text For Masters Program',
                'filter'=>array('StringTrim'),
                'rows' => 5,
                'cols' => 60,
                'class'=>'b2b_contents fck-enable',
                'validators' => $validatorsTTText,
        ));




        $this->addElement('submit', 'Submit', array(
          'ignore'=>true,
          'label'=>'Submit',
          'class'=>'btn btn-info'
         ));

        // $this->getElement('identifier')->addValidators($validatorsDescription);
    }

    public function isValid($data)
    {
        $return = parent::isValid($data);
        if ($return) {

        }
        return $return;
    }

    public function removeUneditableElements()
    {
    }
}
