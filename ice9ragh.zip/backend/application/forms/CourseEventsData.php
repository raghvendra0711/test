<?php

class Form_CourseEventsData extends BaseApp_Form {

    public function init() {
        $events = array('1' => 'MeraEvents', '2' => 'EventsBrite');
        $this->setName('CourseEventsData');
        $this->setMethod('post');

        $course = $this->workshopData();
        $this->addElement('select', 'primary_course_id', array(
            'required' => false,
            'label' => 'Course',
            'multioptions' => array('0' => '--Select--') + $course
        ));
        /*
          $this->addElement('select', 'event_id', array(
          'required' => true,
          'label' => 'EventType',
          'multioptions' => $events
          )); */

        $this->addElement('multiCheckbox', 'eventSite', array(
            'label' => 'EventSite*',
            'required' => false,
            'multioptions' => $events,
            'separator' => ' '
        ));



        $this->addElement('textarea', 'content', array(
            'label' => 'Content',
            'required' => false,
            'cols' => 60,
            'rows' => 6,
            'class' => 'fck-enable'
        ));
        
        $this->addElement('text', 'imageURL', array(
            'label' => 'ImageURL',
            'required' => false,
            'class'=>'longtext'
            
        ));
        
        $this->addElement('submit', 'Save_Event_Data', array(
            'ignore' => true,
            'label' => 'Save Event Data',
            'class' => 'btn btn-info'
        ));
    }

    public function isValid($data) {
        $status = parent::isValid($data);
        if (!$status) {
            return false;
        }

        unset($data['Save_Event_Data']);
        if (!empty($data)) {
            if (isset($data['action']) && $data['action']=='add') {
                if (!empty($data['primary_course_id']) && !empty($data['eventSite']) && !empty($data['content'])) {
                    $data['eventSite'] = implode(',', $data['eventSite']);
                    $eventObj = new BaseApp_Dao_CourseEventsData();
                    $result = $eventObj->fetchAll(array('primary_course_id =?' => $data['primary_course_id'], 'eventSite =?' => $data['eventSite']));
                    if (isset($data['action']) && $data['action'] == 'add') {
                        if (!empty($result)) {
                            $this->getElement('primary_course_id')->setErrors(array("Selected Course Alreday have course Content,
                       Can you Open In Edit Mode"));
                            return false;
                        } else {
                            return true;
                        }
                    } else {
                        return true;
                    }
                } else {
                    if (empty($data['primary_course_id'])) {
                        $this->getElement('primary_course_id')->setErrors(array("you have not selected any course"));
                    }
                    if (empty($data['eventSite'])) {
                        $this->getElement('eventSite')->setErrors(array("you have not selected any event"));
                    }
                    if (empty($data['content'])) {
                        $this->getElement('content')->setErrors(array("Course content is needed"));
                    }
                    return false;
                }
            }
            else {
                return true;
            }
        } else {
            return false;
        }
    }

    public function removeUneditableElements() {
        $this->getElement('primary_course_id')->setAttrib('disabled', 'disabled');
        $this->getElement('primary_course_id')->setRequired(false);
        $this->getElement('eventSite')->setAttrib('disabled', 'disabled');
        $this->getElement('eventSite')->setRequired(false);
    }

    public function workshopData() {
        $workshop = new BaseApp_Dao_Workshop;
        $db = $workshop->getDb();

        $course = $db->fetchAll(
                $db
                        ->select()
                        ->distinct()
                        ->from('workshop', array('workshop.course_id'))
                        ->joinLeft('courses', 'courses.course_id=workshop.course_id', ['course' => 'name'])
                        ->where('workshop.status <> ?', 0)
                        ->where('isSold <> ?', 1)
                        ->where('isCorporate <> ?', 1)
                        ->where('startDate > now()')
        );

        $coursesData = array();
        foreach ($course as $key => $courseData) {
            $coursesData[$courseData['course_id']] = $courseData['course'];
        }
        return $coursesData;
    }

}
