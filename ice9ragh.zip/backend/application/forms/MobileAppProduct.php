<?php

class Form_MobileAppProduct extends BaseApp_Form
{
    const TYPE_COURSE='course';
    const TYPE_BUNDLE='bundle';
    const TYPE_FREE_COURSES='free_course';

    protected $productTypes = array();
    
    public function __construct($data) {
         $this->init($data);
    }

    public function init($data)
    {
        $this->setName('Mobile App');
        $this->setMethod('post');
        $this->loadDefaultDecorators();

        $this->productTypes =   array(
            self::TYPE_COURSE=>'Course'
           ,self::TYPE_BUNDLE=>'Bundle'
           ,self::TYPE_FREE_COURSES=>'Free Courses'
        );
        $obj = new Model_Labels();

        $this->addElement('text','name',array(
            'label'=>'Name of the Widget',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('select', 'product_type', array(
            'label' => 'Product Type',
            'required' => false,
            'registerInArrayValidator' => false,
            'multioptions' => array('0' => '--Select--') + $this->productTypes,
            'class' => 'primary_label_id product_id_for_product_update'
        ));

        $this->addElement('select', 'product_id_temp', array(
            'required' => false,
            'size' => 12,
            'multiple' => true,
            'class' => 'multiple product_id_for_product',
            'registerInArrayValidator' => false,
            'label' => 'Course Name',
            'multioptions' => array('0' => '--Select--'),
        ));
        $products = !empty($data['products']['content_ids_sorted_list'])?$data['products']['content_ids_sorted_list']:'';
        $this->addElement('hidden', 'products', array('required' => false, 'value' => $products));
        $productGroup = array('product_type','product_id_temp');
        $this->addDisplayGroup($productGroup, 'product_group');
        $this->getDisplayGroup('product_group')
                ->setLegend('Product Names')
                ->clearDecorators()
                ->addDecorator('FormElements')
                ->addDecorator('Fieldset', array('class' => 'form_fields_group_wrapper'));


        $this->addElement('submit', 'Add Mobile App', array(
            'ignore' => true,
            'label' => 'Save',
            'class' => 'btn btn-info'
        ));
    }
    
    public function isValid($data) {
        $status = parent::isValid($data);
        if (!$status){
            return false;
        }
        return $status;
    }
}