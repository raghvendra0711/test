<?php

class Form_CourseDetail extends BaseApp_Form{
    
}

