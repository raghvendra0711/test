<?php

class Form_TrainingTypes extends BaseApp_Form
{
    public function init(){
        $this->setName('trainingTypes');
        $this->setMethod('post');
        
         //adding Label name element
        
         $obj =new Model_Courses();
         $this->addElement('select','course_id',array(
            'label'=>'Courses',
            'required'=>false,
            'multioptions'=>array('0'=>'--Select--') + $obj->fetchForSelect(array('is_dummy = ?' => 0, 'is_free = ?' => 0))
        ));

         $this->addElement('text','trainingName',array(
            'label'=>'Name of Training',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));
        
         //adding course submit element
          $this->addElement('submit','Add Training Type',array(
            'ignore'=>true,
            'label'=>'Add Training Type'
           ));
    }
}

