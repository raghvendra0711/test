<?php

class Form_Schedules extends BaseApp_Form
{

    public function init(){
        $this->setName('schedules');
        $this->setMethod('post');
         //adding Label name element

        $this->addElement('text','scheduleDate',array(
            'label'=>'scheduleDate',
            'required'=>true,
            'class'=>'datepicker',
            'value' => date('Y-m-d', time()),
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('text','scheduleHeadCount',array(
            'label'=>'Total Head Count ',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('text','scheduleTimeZone',array(
            'label'=>'Time Zone ',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));

        $this->addElement('text','scheduledFromTime',array(
            'label'=>'Time From ',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));


        $this->addElement('text','scheduledToTime',array(
            'label'=>'To ',
            'required'=>true,
            'filters'=>array('StringTrim'),
            'class'=>'longtext'
        ));
          
        $this->addElement('submit','Create New Schedule',array(
          'ignore'=>true,
          'label'=>'Create New Schedule'
         ));
    }
}

