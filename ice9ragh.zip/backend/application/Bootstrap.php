<?php

class Bootstrap extends BaseApp_Bootstrap {
    protected function _initAutoloader() {
        $autoloader = Zend_Loader_Autoloader::getInstance();
        $autoloader->registerNamespace('SelfServePortal');
        $autoloader->registerNamespace('CourseCatalogue');
        return $autoloader;
    }
}
