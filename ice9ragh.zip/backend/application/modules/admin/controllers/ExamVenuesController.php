<?php

class Admin_ExamVenuesController extends BaseApp_Controller_Crud{
    
    protected $_model = 'Model_ExamVenues';

    protected function _getForm() {
        $form=new Form_ExamVenues();
        return $form;
    }
    

    public function addAction() {
        if (!$this->_add)
            $this->forward('list');
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $form = $this->_getForm();
        if ($form === false)
            throw new Zend_Exception('_getForm not implemented');
        if ($this->getRequest()->isPost() && $form->isValid($this->getRequest()->getPost())) {
            $request = $this->getRequest()->getPost();
            $form->removeOptionalElements();
            $result = $this->getModel()->setFromArray($form->getValues())->save();
            if (!$result) {
                $this->view->message = "Venue exists already!!";
                $this->view->success = false;
            } else {
                $this->view->message = "Venue added successfully";
                $this->view->success = true;
                $form->reset();
                $module  = $this->getRequest()->getModuleName();
                $controller = $this->getRequest()->getControllerName();
                if($module && $controller )
                    $this->redirect($module.'/'.$controller.'/');
            }
        }
        $this->view->form = $form;
    }


    public function editAction() {
        $id = $this->getRequest()->getParam('id');
        $data = $this->getModel($id);

        if (!empty($data->toArray())) {
            $this->view->postParams = $data;
            $form = $this->_getForm();
            $skipUpdate = false;

            $form->removeOptionalValidators();
            $form->removeUneditableElements();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            if ($this->getRequest()->isPost() && $form->isValid($this->getRequest()->getPost())) {
                $form->removeOptionalElements();
                $venueData = $data->toArray();
                $formData = $form->getValues();
                $checkVenueExists = Model_ExamVenues::isVenueExists(array('city_id'=>$venueData['city_id'],'venue_name'=>$formData['venue_name'],'venue_id'=>$venueData['venue_id']));
                if (!$checkVenueExists) {
                    $examSlotMdl = new Model_ExamSlots();
                    $existingFutureSlotCnt = $examSlotMdl->fetchFutureSlotCountHavingVenue($venueData['venue_id']);
                    if ($existingFutureSlotCnt > 0) {
                        $this->view->message = $existingFutureSlotCnt . " future exam slots exists for this venue, delete slots first.";
                        $this->view->success = true;
                        $skipUpdate = true;
                    }
                } else {
                    $this->view->message = "Venue Name must be unique.";
                    $this->view->success = true;
                    $skipUpdate = true;
                }
                if (!$skipUpdate) {
                    $result = $data->setFromArray($form->getValues())->update();
                    if (!$result) {
                        $this->view->message = "Some Error Occurred.";
                        $this->view->success = true;
                    } else {
                        // for making message page specific
                        $this->view->message = ucwords($this->getRequest()->getControllerName()) . " Data successfully updated";
                        $this->view->success = false;
                        $module = $this->getRequest()->getModuleName();
                        $controller = $this->getRequest()->getControllerName();
                        if ($module && $controller)
                            $this->redirect($module . '/' . $controller . '/');
                    }
                    //$this->forward('list');
                }
            }
            $form->setValues($data->toArray());
            $this->view->form = $form;
        }
    }

    public function deleteAction() {
        $venueId = $this->getRequest()->getParam('id');
        if (empty($venueId)) {
            $this->view->message = "Error : Please pass Venue Id";
            return;
        }
        $examSlotMdl =  new Model_ExamSlots();
        $countOfSlots = $examSlotMdl->fetchFutureSlotCountHavingVenue($venueId);
        if(!empty($countOfSlots)) {
            $this->view->message = "Error : {$countOfSlots} exam slot(s) exists with this venue. Please delete the slots now";
            return;
        }
        $data = $this->getModel($venueId);
        $result = $data->delete();
        if ($result) {
//            $this->forward('list');
            $module = $this->getRequest()->getModuleName();
            $controller = $this->getRequest()->getControllerName();
            if ($module && $controller)
                $this->redirect($module . '/' . $controller . '/');
        } else {
            $this->view->message = "Error : Unable to delete. Please try again later";
            return;
        }
    }
}