<?php

/*
 * Contains the CRUD actions of Accreditors table
 * 
 */

class Admin_MobileAppController extends BaseApp_Controller_Crud {

    protected $_model = 'Model_WidgetContent';
    protected $_descriptions = array(
        'edit' => 'Edit Mobile App homepage',
    );
    protected function _getWidgetForm($data = array())
    {       
        $form = false;
        $widget_type = isset($data['widget_type']) ? $data['widget_type'] : "";
        $widget_type = strtolower($widget_type);
        $data = isset($data['data']) ? $data['data'] : array(); 
        $data['widget_type'] =  !empty(Model_WidgetSequence::$wigetKeyMapper[$widget_type])?Model_WidgetSequence::$wigetKeyMapper[$widget_type]:'';     
        switch ($widget_type) {
            case Model_WidgetSequence::TYPE_BANNER:
                $form = new Form_MobileDeepLink($data);
                break;
            case Model_WidgetSequence::TYPE_GRID:
            case Model_WidgetSequence::TYPE_FRS:
                $form = new Form_MobileAppCategory($data);
                break;
            case Model_WidgetSequence::TYPE_HORIZONTAL_LIST:                
                $form = new Form_MobileAppHorizontalLists($data);
                break;
            case Model_WidgetSequence::TYPE_VERTICAL_LIST:
                $form = new Form_MobileAppHorizontalLists($data);
            break;
            default:
                $form = new Form_MobileApp($data);
                break;
        }
        return $form;
    }

    public function editAction() {               
        $sequenceObj         = new Model_WidgetSequence();
        $data                = array();
        $data['widget_type'] = Model_WidgetSequence::TYPE_HORIZONTAL_LIST;
        $request = $this->getRequest()->getParams();        
        $widget_type = !empty($request['widget_type']) ? $request['widget_type'] : "";
        $widget_id = '';
        $cObj =  new Model_WidgetContent();
        if (!empty($request['widget_id'])) {
            $widget_id            = $this->getRequest()->getParam('widget_id', "");
            $widgetInfo  = $sequenceObj->getSectionContent($widget_id);            
            $data['data']["info"] = $widgetInfo;
            $data['data']["data"]  = $this->getModel()->getSectionContent($request['widget_id']);
            $widget_type           = !empty($widgetInfo['widget_type']) ? $widgetInfo['widget_type'] : '';
            $data['widget_type']   = $widget_type;            
        } elseif (!empty($widget_type)) {
            $data['widget_type']   = $widget_type;
        }
        
        
        $oldData = array();
        if (!empty($data['data']) && !empty($data['data']["data"])) {
            $oldData = $data['data']["data"];
            unset($oldData['content_ids']);
            unset($oldData['content_ids_sorted_list']);
            unset($oldData['contentitems']);
            unset($oldData['sequence_ids']);
            unset($oldData['sequence_ids_sorted_list']);
        }
        $widget_type = strtolower($widget_type);          
        foreach($oldData as $key => &$oldTemp){
             $oldTemp['key'] = $oldTemp['content_type'].'_'.$oldTemp['content_id'];
        }        
        $form  = false;
        
        if ($this->getRequest()->isPost()) {
            $requestPost = $this->getRequest()->getPost();
            $postData = array_merge_recursive($requestPost, $_FILES);

            $fromData = $data;
            if(!empty($requestPost['widgets_ids'])) {
                $fromData['data']['data']['sequence_ids_sorted_list'] = $requestPost['widgets_ids'];
            }         
            $form = $this->_getWidgetForm($fromData);
        }else{
            $form = $this->_getWidgetForm($data);
        }        
        if ($form === false)
            throw new Zend_Exception('_getForm not implemented');

        $postData['widget_id'] = $widget_id;
        $formValues = $form->getValues();    

        if ($this->getRequest()->isPost() && $form->isValid($postData)) {
            $requestPost = $this->getRequest()->getPost();
            $formValues = $form->getValues();            
            if(empty($formData)){
                $formValues = $postData;
            }          
            $saveData = array();
            $title = !empty($formValues['name']) ? $formValues['name'] : '';
            /*
            save widget Data
            */
            $content_type = '';
            //prd($widget_type);
            switch ($widget_type) {
                case Model_WidgetSequence::TYPE_BANNER:
                    $content_type = Model_WidgetSequence::CONTENT_TYPE_DEEPLINK;
                    break;
                case Model_WidgetSequence::TYPE_GRID:
                    $content_type = Model_WidgetSequence::CONTENT_TYPE_GRID;
                    break;
                case Model_WidgetSequence::TYPE_FRS:
                    $content_type = Model_WidgetSequence::CONTENT_TYPE_FRS;
                    break;
                case Model_WidgetSequence::TYPE_HORIZONTAL_LIST:
                case Model_WidgetSequence::TYPE_VERTICAL_LIST:
                    $content_type = !empty($formValues['product_type']) ? $formValues['product_type'] : '';
                    break;
                default:
                    break;
            }
            if (empty($widget_id)) {
                $mapper = Model_WidgetSequence::$widgetMapper;
                $widgetData = array();
                if (!empty($mapper[$widget_type])) {
                    $widgetData = $mapper[$widget_type];
                }                
                $widgetData['title'] = $title;
                $widgetData['status'] = 1;
                $widgetData['limit'] = !empty($formValues['limit']) ? $formValues['limit'] : ''; 
                $widgetData['product_type'] = $content_type;
                $widgetData['last_updated_timestamp'] = time();                
                $widget_id = $sequenceObj->saveWidget($widgetData);
            } else {
                $data = array();
                $data['last_updated_timestamp'] = time();
                $data['limit'] = !empty($formValues['limit']) ? $formValues['limit'] : '';
                $data['title'] = $title;
                $product_type = !empty($formValues['product_type']) ? $formValues['product_type'] : '';
                if (!empty($product_type)) {
                    $data['product_type'] = $product_type;
                }
                $segModel = new Model_WidgetSequence();
                if (!empty($widget_id)) {
                    $segModel->setId($widget_id);
                    $segModel->setFromArray($data)->update();
                }
            }
            if (!empty($formValues)) {                
                $newPos =null;
                switch ($widget_type) {
                    case Model_WidgetSequence::TYPE_BANNER:                        
                        $productData    = explode(',', $formValues['product_ids']);
                        $productName = explode(',',$formValues['product_name']);
                        $bannerContentList = [];
                        $bannerItems = !empty($formValues['widgets_ids']) ? $formValues['widgets_ids'] : null;                        
                        if($bannerItems != null)
                            $bannerContentList = explode(',',$bannerItems);
                    
                        $bannerOrder = [];
                        if(count($bannerContentList)>0){
                            foreach($bannerContentList as $index => $val)
                                $bannerOrder[$val] = $index+1;
                        }                        

                        $status =  $cObj->updateBannerOrder($bannerOrder); 
                        $newPos = count($oldData) +1 ;
                        if($formValues['product_type'] != 'deeplink'){
                         $newPos = null;   
                        }                     
                        $bannerImgUrl = null;
                        //image upload s3
                        
                        if (isset($_FILES['image_url']['name']) && $_FILES['image_url']['name'] != '') {
                            $fileName = $_FILES['image_url']['name'];
                            $absFilePath = sys_get_temp_dir().DIRECTORY_SEPARATOR.$fileName; //sys_get_temp_dir().DIRECTORY_SEPARATOR.$fileName;                            
                            //$absFilePath = $_FILES['image_url']['tmp_name'];                           
                            $s3path = AWS_S3_IMAGES_PATH . '/app';
                            $bannerImgUrl = BaseApp_Utility_ImageProcessing::transformAndUploadToS3($absFilePath, $fileName, $s3path);                            
                        }
                        //end image upload
                        $widgetContentTitle = null;
                        $i = 0;
                        $oldKeys = array_column($oldData,'key');                         
                        if(!empty($formValues['product_ids'])|| $formValues['product_type'] == 'deeplink'){
                            foreach($productData as $key => $value){
                                
                                if(empty($formValues['title'])){
                                    $widgetContentTitle = !empty($productName[$i])?$productName[$i]:'';
                                }else{
                                    $widgetContentTitle = $formValues['title'];
                                }
                                $i++;                                
                                $product_type_key = !empty($formValues['product_type']) ? $formValues['product_type'] : '';
                                if (empty($product_type_key)) {
                                    $product_type_key = !empty($formValues['product_type_old']) ? $formValues['product_type_old'] : '';
                                }
                                $saveData[] = array(
                                                    'key'           =>  $product_type_key,                                                
                                                    'deep_link'     =>  !empty($formValues['deep_link']) ? $formValues['deep_link'] : null,
                                                    'image_url'     =>  $bannerImgUrl,
                                                    'title'         =>  $widgetContentTitle,
                                                    'content_key'   =>  $product_type_key.'_'.$value,
                                                    'value'         =>  $value,                                                   
                                                );                                                                        
                            }                            
                        }                                                                                  
                    break;
                    case Model_WidgetSequence::TYPE_GRID:
                    case Model_WidgetSequence::TYPE_FRS:
                        unset($formValues['category_id_temp']);
                        $categoriesData    = explode(',', $formValues['category_ids']);
                        foreach($categoriesData as $key => $value){
                            $saveData[] = array('key'=>'category','value'=>$value,'content_key'=>'category'.'_'.$value);
                        }
                        break;
                    case Model_WidgetSequence::TYPE_HORIZONTAL_LIST:                                               
                    case Model_WidgetSequence::TYPE_VERTICAL_LIST:
                        unset($formValues['product_id_temp']);
                        $productData    = explode(',', $formValues['product_ids']);
                        foreach($productData as $key => $value){
                            $saveData[] = array('key'           =>  $formValues['product_type'],
                                                'value'         =>  $value,
                                                'content_key'   =>  $formValues['product_type'].'_'.$value
                                                   
                                            );
                        }     
                        break;
                    default:                        
                        break;
                }
            }  
            $module = $this->getRequest()->getModuleName();
            $controller = $this->getRequest()->getControllerName();

            if (!empty($widget_id)) {
                if ($widget_type ==='banner') {
                    $this->getModel()->saveContentAdd($saveData, $oldData, $widget_id, $newPos);
                } else {
                    $this->getModel()->saveContent($saveData, $oldData, $widget_id, $newPos);
                }
            }
            if ($widget_type ==='banner') {
                if ($module && $controller)
                    $this->redirect($module . '/' . $controller . '/edit?widget_id='.$widget_id);
            } else{
                if ($module && $controller)
                    $this->redirect($module . '/' . $controller . '/list');
            }
            
        }
        $this->view->form = $form;
    }
    /**
     * List widgets
     * @author Sreerag@simpilearn.net
     */

    public function listAction() {        
        $hsObj =  new Model_WidgetSequence();
        $data = $hsObj->fetchAllWidgets();
        $data['formId'] = '';
        $form = $this->_getWidgetForm($data);
        if ($form === false)
            throw new Zend_Exception('_getForm not implemented');
        if ($this->getRequest()->isPost()) {
            $request = $this->getRequest()->getPost();       
            $postData = array_merge_recursive($request, $_FILES);
        }
        if ($this->getRequest()->isPost() && $form->isValid($postData)) {
            $request = $this->getRequest()->getPost();
            $formValues = $form->getValues();
            unset($formValues['dd_widget']);
            unset($formValues['widget_items_temp']);           
            $widgetOrder = []; //index => sequenceId and val => position
            if(!empty($formValues['widgets_ids'])){
                $sortItems = explode(",",$formValues['widgets_ids']);
                if(count($sortItems)>0){
                    foreach($sortItems as $index => $val)
                    $widgetOrder[$val] = $index+1;
                }                
                $status = $hsObj->updateWidgetOrder($widgetOrder);
                $module = $this->getRequest()->getModuleName();
                $controller = $this->getRequest()->getControllerName();
                if ($module && $controller)
                    $this->redirect($module . '/' . $controller . '/list');
            }            
        }
        $this->view->form = $form;
    }

    /**
     * delete widget
     */
    public function deleteAction(){

        $hsObj =  new Model_WidgetSequence();
        $sId = $this->getRequest()->getParam('sequence_id');        
        if(!$sId)
            throw new BaseApp_Exception('Item not found!');        
        
        $widgetData['status'] = 0;
        $status = $hsObj->delete($sId);
        $module  = $this->getRequest()->getModuleName();
        $controller = $this->getRequest()->getControllerName();
        if($status){
            $this->view->message = "Deleted SuccessFully";
            $this->view->success = false;

        }else{
            $this->view->message = "An error has occured while saving";
            $this->view->success = true;           
        }
        if($module && $controller)
            $this->redirect($module.'/'.$controller.'/list');
    }

    public function deleteBannerContentAction(){
        $hsObj =  new Model_WidgetContent();
        $sId = $this->getRequest()->getParam('sequence_id');                
        if(!$sId)
            throw new BaseApp_Exception('Item not found!');        
        
        $widgetData['status'] = 0;
        $status = $hsObj->delete($sId);        
        if($status){            
            $this->view->message = "Deleted SuccessFully";
            $this->view->success = false;

        }else{
            $this->view->message = "An error has occured while saving";
            $this->view->success = true;            
        }
    }

    public function uploadImageContentsAction(){
        $sId = $this->getRequest()->getParam('content_id');
        $hsObj =  new Model_WidgetContent();           
        if (isset($_FILES['file']['name']) && $_FILES['file']['name'] != '') {
            $fileName = $_FILES['file']['name'];
            //$absFilePath = sys_get_temp_dir().DIRECTORY_SEPARATOR.$fileName; //sys_get_temp_dir().DIRECTORY_SEPARATOR.$fileName;        
            $absFilePath    = $_FILES['file']['tmp_name'];   
            $s3path = AWS_S3_IMAGES_PATH . '/app';
            $bannerImgUrl = BaseApp_Utility_ImageProcessing::transformAndUploadToS3($absFilePath, $fileName, $s3path);                            
        }
        if(!$sId)
            throw new BaseApp_Exception('Item not found!');        
        
        //$widgetData['image_url'] = $bannerImgUrl;
        $status = $hsObj->updateImageUrl($bannerImgUrl,$sId);        
        if($status){            
            $this->view->message = "Uploaded SuccessFully";
            $this->view->success = false;

        }else{
            $this->view->message = "An error has occured while saving";
            $this->view->success = true;            
        }        
    }
    
}
