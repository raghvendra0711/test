<?php
/*
 * Contains the CRUD actions of Exams table
 * 
 */

class Admin_ExamController extends BaseApp_Controller_Crud {
    protected $_model = 'Model_Exams';
    protected $_descriptions = array(
        'list' => 'List of Existing Exams',
        'index' => 'List of Existing Exams',
        'add' => 'Add New Exams',
        'edit' => 'Make the required changes then click on "Save Exams" to update the Exams',
        'view' => 'View Selected Exams'
    );

    protected function _getForm() {
        $form = new Form_Exams();
        return $form;
    }
    
    public function addAction() {        
        $request = $this->getRequest()->getPost();       
        $this->_setCountryPrice($request);//pending
        $this->_setExamFaq($request);
        $this->_setRecommendations($request);
        
        if (!$this->_add)
            $this->forward('list');
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $form = $this->_getForm();        
        if ($form === false)
            throw new Zend_Exception('_getForm not implemented');
        if ($request && $form->isValid($request)) {
            $request = $form->getValues(); 
            $splitData = $this->_handleDataAfterSubmit($request);              
            $result = false;
            if($examId = $this->getModel()->createExam($request)) {
                $result = true;
                        
                $pricing = new Model_SubscriptionPricing();
                if($result && !$pricing->savePricing($examId, 'exam', $splitData['countryPrice'])) {
                    $result = false;
                }
                
                $faq = new Model_PracticeFaq();
                if($result && !$faq->saveFaq($examId, 'exam', $splitData['examFaq'])) {
                    $result = false;
                }

                $recommend = new Model_Recommendations();
                if($result && !$recommend->saveRecommendations($examId, 'exam', $splitData['recommendations'])) {
                    $result = false;
                }

                $tags = new Model_Tags();
                if($result && !$tags->saveTags($examId, 'exam', $splitData['searchTags'])) {
                    $result = false;
                }

                $image = new Model_Images();
                if($result && !$image->saveImage($examId, 'exam', $splitData['imagePath'], $splitData['imageDescription'])) {
                    $result = false;
                }
            }                                    
            
            if (!$result) {
                $this->view->message = "An error has occured while saving";
                $this->view->success = true;
            } else {                
                $this->view->message = "Data successfully added";
                $this->view->success = false;
                $form->reset();
                $module  = $this->getRequest()->getModuleName();
                $controller = $this->getRequest()->getControllerName();
                $action = $this->getRequest()->getActionName();
                if($module && $controller && $action)
                    $this->redirect($module.'/'.$controller.'/');
            }
        }
        $this->view->form = $form;
    }
    
    
    public function editAction() {  
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
                        
        if ($this->getRequest()->isPost()) {
            $request = $this->getRequest()->getPost();       
            $this->_setCountryPrice($request);//pending
            $this->_setExamFaq($request);
            $this->_setRecommendations($request);

            $form = $this->_getForm();
            $form->removeUneditableElements();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            
            if($form->isValid($request)) {
                $data = $form->getValues();
                $splitData = $this->_handleDataAfterSubmit($data);
                $data['exam_id'] = $this->getRequest()->getParam('id');   
                
                
                if($this->getModel()->updateExam($data)) {
                    $result = true;

                    $pricing = new Model_SubscriptionPricing();
                    if($result && !$pricing->savePricing($data['exam_id'], 'exam', $splitData['countryPrice'])) {
                        $result = false;
                    }

                    $faq = new Model_PracticeFaq();
                    if($result && !$faq->saveFaq($data['exam_id'], 'exam', $splitData['examFaq'])) {
                        $result = false;
                    }

                    $recommend = new Model_Recommendations();
                    if($result && !$recommend->saveRecommendations($data['exam_id'], 'exam', $splitData['recommendations'])) {
                        $result = false;
                    }

                    $tags = new Model_Tags();
                    if($result && !$tags->saveTags($data['exam_id'], 'exam', $splitData['searchTags'])) {
                        $result = false;
                    }
                    
                    $imageModel = new Model_Images();
                    if($result && !$imageModel->saveImage($data['exam_id'], 'exam', $splitData['imagePath'], $splitData['imageDescription'])) {
                        $result = false;
                    }                    
                }
                
                
                $result = false;
                if (!$result) {
                    $this->view->message = "An error has occured while saving";
                    $this->view->success = true;
                } else {
                    // for making message page specific
                    $this->view->message = ucwords($this->getRequest()->getControllerName())." Data successfully updated";
                    $this->view->success = false;
                }
                $this->_redirect('/admin/exam/list');
            }
        }    
        elseif($examId = $this->getRequest()->getParam('id')) {            
            $examModel = new Model_Exams($examId);
            if(!$examModel->toArray()) {
                $this->_redirect('/admin/exam/list');
            }
            $session = new Zend_Session_Namespace('form'); 
            /*
             * pricing model
             */
            $priceModel = new Model_SubscriptionPricing();
            $priceData = array(
                'countryPrice' => $priceModel->getByLinkable($examId, 'exam')
            );
            $this->_setCountryPrice($priceData);            
            
            /*
             * faq model
             */           
            $faq = new Model_PracticeFaq();
            $faqData = array(
                'examFaq' => $faq->getByLinkable($examId, 'exam')
            );
            if(isset($faqData['examFaq']) && $faqData['examFaq']) {
                foreach($faqData['examFaq'] as $indexTemp => $dataReal) {
                    $faqQuestion = array_search($dataReal['question'], Form_Exams::$faqQuestions);
                    if($faqQuestion !== false) {
                        $examModel->$faqQuestion = $dataReal['answer'];
                        unset($faqData['examFaq'][$indexTemp]);
                    }
                }
            }
            $this->_setExamFaq($faqData);

            
            /*
             * recommendation model
             */
            $recommend = new Model_Recommendations();
            $recommendData = array(
                'recommendations' => $recommend->getByLinkable($examId, 'exam')
            );
            $this->_setRecommendations($recommendData);    

            /*
             * faq model
             */
            $tags = new Model_Tags();
            if($tagData = $tags->getByLinkable($examId, 'exam')) {
                $examModel->searchTags = $tagData['tag'];
            }

            /*
             * faq model
             */
            $imageModel = new Model_Images();
            if($imageData = $imageModel->getByLinkable($examId, 'exam')) {
                $examModel->imagePath = $imageData['imagePath'];
            }
                        
            $courseModel = new Model_Courses();        
            $examModel->course_name =  $courseModel->getNameById($examModel->course_id);      

            $this->view->postParams = $examModel;
            $form = $this->_getForm();
            $form->removeUneditableElements();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            $form->setDefaults($examModel->toArray());            
        }
        else {
            $this->_redirect('/admin/exam/list');
        }
        $this->view->form = $form;
    }
    
    private function _handleDataAfterSubmit(&$data) {
        $returnData = array(
            'countryPrice' => array(),
            'examFaq' => array(),
            'recommendations' => array(),
            'searchTags' => false,
            'imagePath' => false,
            'imageDescription' => false
        );
        
        unset($data['course_name']);
        if(isset($data['countryPrice'])) {
            unset($data['countryPrice']['__template__']);
            $returnData['countryPrice'] = $data['countryPrice'];
            unset($data['countryPrice']);
        }
        $returnData['examFaq'] = $this->_collectFaq($data);           

        if(isset($data['recommendations'])) {
            unset($data['recommendations']['__template__']);
            $returnData['recommendations'] = $data['recommendations'];
            unset($data['recommendations']);
        }
        if(isset($data['searchTags'])) {
            $returnData['searchTags'] = $data['searchTags'];
            unset($data['searchTags']);
        }     

        if(isset($data['imagePath'])) {
            $returnData['imagePath'] = $data['imagePath'];
            $returnData['imageDescription'] = '';
            if(isset($data['imageDescription'])) {
                $returnData['imageDescription'] = $data['imageDescription'];
            }
            unset($data['imageDescription']);
            unset($data['imagePath']);
        }
        return $returnData;
    }
    
    private function _setCountryPrice(&$request) {
        $session = new Zend_Session_Namespace('form'); 
        if(isset($request['countryPrice']) && count($request['countryPrice'])) {
            $request['countryPrice'] = $this->_updateFirstElement($request['countryPrice']);        
            $session->countryPrice = array_keys($request['countryPrice']);
            array_unshift($session->countryPrice, '__template__');
            $session->countryPriceData =  $request['countryPrice'];
        }
        else {
            $session->countryPrice = array('__template__', 'new');
            $session->countryPriceData = array();
        }        
    }
    
    private function _setExamFaq(&$request) {
        $session = new Zend_Session_Namespace('form'); 
        if(isset($request['examFaq']) && count($request['examFaq'])) {
            $request['examFaq'] = $this->_updateFirstElement($request['examFaq']);        
            $session->examFaq = array_keys($request['examFaq']);
            array_unshift($session->examFaq, '__template__');
            $session->examFaqData =  $request['examFaq'];
        }
        else {
            $session->examFaq = array('__template__', 'new');
            $session->examFaqData = array();
        }
    }
    
    private function _setRecommendations(&$request) {
        $session = new Zend_Session_Namespace('form'); 
        if(isset($request['recommendations']) && count($request['recommendations'])) {
            $request['recommendations'] = $this->_updateFirstElement($request['recommendations']);        
            $session->recommendations = array_keys($request['recommendations']);
            array_unshift($session->recommendations, '__template__');
            $session->recommendationsData =  $request['recommendations'];
        }
        else {
            $session->recommendations = array('__template__', 'new');
            $session->recommendationsData = array();
        }
    }
    
    private function _collectFaq(&$request) {
        $faq = array();
        if(isset($request['examFaq'])) {
            $faq = $request['examFaq'];
            unset($request['examFaq']);
        }  
        foreach(Form_Exams::$faqQuestions as $element => $question) {
            if(isset($request[$element]) && $request[$element]) {
                $faq[] = array(
                    'question' => $question,
                    'answer' => $request[$element]
                );
            }
            unset($request[$element]);
        }
        return $faq;
    }       
    
    private function _updateFirstElement($elementArray) {
        $keys = array_keys( $elementArray );
        $keys[ array_search( '0', $keys ) ] = 'new';
        return array_combine( $keys, $elementArray );    
    }
}
