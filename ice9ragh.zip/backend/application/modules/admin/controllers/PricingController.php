<?php
/*
 * Contains the CRUD actions of Pricings table
 * 
 */

class Admin_PricingController extends BaseApp_Controller_Crud {
    protected $_model = 'Model_Pricings';
    protected $_descriptions = array(
        'list' => 'List of Existing Pricings',
        'index' => 'List of Existing Pricings',
        'add' => 'Add New Pricings',
        'edit' => 'Make the required changes then click on "Save Pricings" to update the Pricings',
        'view' => 'View Selected Pricings',
        'delete-price' => 'Delete Selected Pricings id',
        'delete-price' => 'Delete Selected Pricings id',
    );

    protected function _getForm() {
        $form = new Form_ModifyPricings();
        return $form;
    }
    
    public function addAction(){
        $form = new Form_Pricings();
        $objCourse = new Model_Courses();
        $objPricing = new Model_Pricings();
        $courseId = $this->getRequest()->getParam('courseId');
        
        if(empty($courseId)){
            $this->view->message = "Invalid Course Id";
            $this->view->success = true;
            return;
        }
        
        if(!$courseData = $objCourse->getCourseById($courseId)) {
            $this->view->message = "Invalid Course Id";
            $this->view->success = false;
            return;
        }
        
        if($courseData['is_free']) {
            $this->view->message = "Its a free course";
            $this->view->success = false;
            return;
        }
        
        $priceData = $objPricing->fetchAll(array('course_id =?' => $courseId));        
        $this->_processDataDisplay($priceData);
        $form->setCourseType($courseId);        
        $this->view->form = $form;
        $this->view->priceData = $priceData;
        $this->view->pricingTableName = $objPricing->getName();
        $modelTraining = new Model_TrainingRelations();
        if(!$modelTraining->getCourseTrainingData($courseId, 'course')) {
            $this->view->message = "Please select at least one training type from Basics page";
            $this->view->form = null;
            
        }
    } // end of function courseContentAction

    
    private function _processDataDisplay(&$priceData) {
        $dataFetch = array(
            'course_id' => array(),
            'training_id' => array(),
            'access_day_id' => array(),
            'cluster_id' => array(),
            'country_id' => array(),
            'city_id' => array()
        );
        foreach($priceData as $priceDataSingle) {
            foreach($dataFetch as $fieldName => $fieldData) {
                if(isset($priceDataSingle[$fieldName]) && $priceDataSingle[$fieldName]) {
                    $dataFetch[$fieldName][] = $priceDataSingle[$fieldName];
                }
            }
        }
        $forCurrency = array(
            'countries' => array(),
            'clusters' => array()
        );
        foreach($dataFetch as $fieldName => $fieldData) {
            if(!$fieldData) {
                continue;                
            }            
            $fieldData = array_unique($fieldData);
            switch($fieldName) {
                case 'course_id':                    
                    $modelCourses = new Model_Courses();
                    $dataFetch[$fieldName] = $modelCourses->getCourseByIdMultiple($fieldData);
                    break;                
                case 'training_id':
                    $modelTraining = new Model_TrainingTypes();
                    $dataFetch[$fieldName] = $modelTraining->getTrainingTypes();
                    break;
                case 'access_day_id':
                    $access = new Model_AccessDays();
                    $dataFetch[$fieldName] = $access->getAccessDaysById(false, true);
                    break;
                case 'cluster_id':
                    $cluster = new Model_Clusters();
                    $dataFetch[$fieldName] = $cluster->getListDisplay($fieldData);
                    $forCurrency['clusters'] = $cluster->getCurrencies($fieldData); 
                    break;
                case 'country_id':                    
                    $country = new Model_Country();
                    $dataFetch[$fieldName] = $country->getById($fieldData);
                    $forCurrency['countries'] = $country->getCurrencies($fieldData); 
                    break;
                case 'city_id':
                    $city = new Model_City();
                    $dataFetch[$fieldName] = array();
                    if($fieldData) {
                        $dataFetch[$fieldName] = $city->getNameById($fieldData);
                    }                    
                    break;                
            }
        }        
        
        $fieldMap = array(
            'course_id' => 'course name',
            'training_id' => 'training type',
            'access_day_id' => 'access days',
            'cluster_id' => 'cluster',
            'country_id' => 'country',
            'city_id' => 'city',
            'minPrice' => 'actual price'            
        );
        foreach($priceData as $tempId => $priceDataSingle) {
            unset($priceData[$tempId]['allLocation']);
            unset($priceData[$tempId]['type']);
            unset($priceData[$tempId]['course_inclusion_id']);
            unset($priceData[$tempId]['status']);
            if($priceData[$tempId]['country_id']) {
                $priceData[$tempId]['Currency'] = $forCurrency['countries'][$priceData[$tempId]['country_id']];
            }
            if($priceData[$tempId]['cluster_id']) {
                $priceData[$tempId]['Currency'] = $forCurrency['clusters'][$priceData[$tempId]['cluster_id']];
            }
            foreach($priceDataSingle as $fieldName => $fieldData) {
                if($fieldData && isset($dataFetch[$fieldName])) {
                    $priceData[$tempId][$fieldName] =  $dataFetch[$fieldName][$fieldData];                
                }
                if(isset($fieldMap[$fieldName])) {
                    $priceData[$tempId][$fieldMap[$fieldName]] = $priceData[$tempId][$fieldName];
                    unset($priceData[$tempId][$fieldName]);
                }                
            }            
        }       
        unset($dataFetch);
        unset($fieldMap);
    }
    
    public function deletePriceAction(){
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $pricingId = $this->getRequest()->getParam('pricing_id');
        if(!$pricingId)
            throw new BaseApp_Exception(' item not selected properly');
        $pricingData = $this->getModel($pricingId);        
        $form = new Form_DeletePrice();
        if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
        $form->setDefaults($pricingData->toArray());
        $this->view->form = $form;
    }

    public function editAction(){
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $pricingId = $this->getRequest()->getParam('id');
        $pricingData = $this->getModel($pricingId);
        $pricingData->cityId = $pricingData->city_id; 
        if(!$pricingId)
            throw new BaseApp_Exception('Editable item not selected properly');
        $form = new Form_ModifyPricings($pricingData->course_id);
        if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
        $form->setDefaults($pricingData->toArray());
        $this->view->form = $form;
    }
 
    public function listOtherAction() {
        $page = $this->view->navigatorPage;

        $model = new Model_SubscriptionPricing();
        $orderby = $model->getPk() . ' DESC';
        $page = (int)$this->getRequest()->getParam('page');
        if ($page <= 1) {
            $this->view->firstpage = true;
            $page = 1;
        } else {
            $this->view->firstpage = false;
        }
        $offset = ($page - 1) * self::ROWS_PER_PAGE;   
        $limit = array(self::ROWS_PER_PAGE,$offset);
        $this->view->page = $page;
        
        $conds = array();
        if($this->getRequest()->getParam('id') && $this->getRequest()->getParam('type')) {
            $conds = array(
                'linkable_id=?' => $this->getRequest()->getParam('id'),
                'linkable_type=?' => $this->getRequest()->getParam('type')
            );
        }
        $data = $model->fetchAll($conds, array('order' => array($orderby), 'limit' => $limit));
        if (count($data) < self::ROWS_PER_PAGE) {
            $this->view->lastpage = true;
        } else {
            $this->view->lastpage = false;
        }
        $total = $model->fetchCount();
        $pk = $model->getPk();
        $table = $model->getName();
        if(isset($data[0])){
            $original = array_keys($data[0]);
        }else{
            $original = array();
        }
        $as = ($this->_displayInDataTable);
        //new datatable   
        //need to define path in ini file after discussion
        $datatableFilePath = '../../library/BaseApp/Datatable/'.ucfirst($table).'.php';       
        if(file_exists($datatableFilePath)) {
            $dataTableClass = 'BaseApp_Datatable_'.ucfirst($table);               
        }
        else{
            $dataTableClass = 'BaseApp_Datatable_Default';                            
        }

        $dataTable = new $dataTableClass;
        $dataTable->setData($data);

        $this->view->data = $dataTable;
        //------
        //$this->view->data = $data;
        $this->view->original = $original;
        $this->view->displayInDataTable = $as;
        $this->view->navigatorTotal = ceil($total / BACKEND_ROWS_PER_PAGE);
    }
}
