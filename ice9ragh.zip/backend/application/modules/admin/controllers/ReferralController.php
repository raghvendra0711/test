<?php
/*
 * Contains the CRUD actions of Reviews table
 * 
 */

class Admin_ReferralController extends BaseApp_Controller_Crud {
    protected $_model = 'Model_Referrals';
    protected $_descriptions = array(
        'list' => 'List of Existing Referrals',
        'index' => 'List of Existing Referrals',
        'add' => 'Add New Referrals',
        'edit' => 'Make the required changes then click on "Save Reviews" to update the Referrals',
        'view' => 'View Selected Referrals'
    );

    protected function _getForm() {
        $form = new Form_Referrals();
        return $form;
    }
    
    public function listAction() {
        $table = $this->getModel()->getName();
        $filterForm = new Form_Filters($table);
        $requestData = array();
        $queryParamsArr = array();
        $page = '';
        if($this->getRequest()->isPost()){
            $filterForm->populate($this->getRequest()->getPost());
            $page = 1;
            $requestData = $filterForm->getValues();
            foreach($requestData as $elementName => $elementValue) {
                if(!empty($elementValue)){
                    $queryData = $filterForm->getElement($elementName)->getAttrib('data-table');
                    $queryData['searchValue'] = $elementValue;
                    $this->queryBuilder($queryData);
                    $queryParamsArr[$queryData['search_id']] = $elementValue;
                } // end of !empty elementValue
            } // end of foreach RequestData
        } // end of if isPost
        if(empty($page)){
            $page = $this->view->navigatorPage;
            $page = (int)$this->getRequest()->getParam('page');
        }
        $orderby = $this->getModel()->getPk() . ' DESC';
        if(empty($this->_queryParams)){
            $getData = $this->getRequest()->getQuery();
            unset($getData['page']);
            if(!empty($getData)){
                foreach ($getData as $key => $value) {
                    $queryParamsArr[$key] = $value;
                    $returnData = $filterForm->getSearchFields($key);
                    if(!empty($returnData)){
                        $returnData = $returnData[0];
                        $filterForm->getElement($returnData['searchColumnName'])->setValue($value);
                        $returnData['searchValue'] = $value;
                        $this->queryBuilder($returnData);
                    }
                }
            }
        }
        if ($page <= 1) {
            $this->view->firstpage = true;
            $page = 1;
        } else {
            $this->view->firstpage = false;
        }
        $offset = ($page - 1) * self::ROWS_PER_PAGE;
        $limit = array(self::ROWS_PER_PAGE,$offset);
        $this->view->page = $page;
        $model = $this->getModel();
        $data = $model->fetchAll($this->_queryParams, array('order' => array($orderby), 'limit' => $limit));
        $perPageData = count($data);
        $total = $model->fetchCount($this->_queryParams);
        if (count($data) < self::ROWS_PER_PAGE) {
            $this->view->lastpage = true;
        } else {
            $this->view->lastpage = false;
        }
        $numberOfPages = ceil($total / self::ROWS_PER_PAGE);
        if($page < $numberOfPages){
            $this->view->currentPageRecord = self::ROWS_PER_PAGE * $page;    
        }else{
            $this->view->currentPageRecord = $total;    
        }
        $this->view->diffPageRecord = $this->view->currentPageRecord - self::ROWS_PER_PAGE;
        if(count($data) < self::ROWS_PER_PAGE){
            $this->view->diffPageRecord = $total - count($data);
        }
        $this->view->totalCount = $total;
        $this->view->totalPages = $numberOfPages;
        $this->view->lastPage = $numberOfPages;
        $pk = $model->getPk();
        
        foreach ($data as &$row) {
            if(!empty($row['datetime']))
                $row['datetime'] = gmdate("Y-m-d H:i:s", $row['datetime']);
            if(!empty($row['orderDate']))
                $row['orderDate'] = gmdate("Y-m-d H:i:s", $row['orderDate']);
            $row['Action'] = "<a href='" . $this->view->url(array('action' => 'view', 'id' => $row[$pk])) . "'>View</a> ";
        }
        if(isset($data[0])){
            $original = array_keys($data[0]);
        }else{
            $original = array();
        }
        $as = ($this->_displayInDataTable);
        $datatableFilePath = '../../library/BaseApp/Datatable/'.ucfirst($table).'.php';       
        if(file_exists($datatableFilePath)) {
            $dataTableClass = 'BaseApp_Datatable_'.ucfirst($table);               
        }
        else{
            $dataTableClass = 'BaseApp_Datatable_Default';                            
        }

        $dataTable = new $dataTableClass;
        $dataTable->setData($data);
        $this->view->queryParams = http_build_query($queryParamsArr);
        $this->view->form = $filterForm;
        $this->view->data = $dataTable;
        $this->view->original = $original;
        $this->view->displayInDataTable = $as;
        $this->view->navigatorTotal = ceil($total / BACKEND_ROWS_PER_PAGE);        
    }
    public function uploadAction()
    {
        $form = new Form_ReferralData();
        $paymentReconcile = new BaseApp_Dao_Melvin_PaymentReconcile();
        $referalInsert = new BaseApp_Dao_ManualReferralUpdate();
        $referrerRefereeObj = new BaseApp_Dao_ReferrerRefereeMapping();
        if ($form === false) {
            throw new Zend_Exception('_getForm not implemented');
        }
        if ($this->getRequest()->isPost()) {
            $postInfo = $this->getRequest()->getPost();
            $postData = array_merge_recursive($postInfo, $_FILES);
            if ($form->isValid($postData)) {
                $fileData = $_FILES['referrealData'];
                $fileReferrealData = array();
                if (!empty($fileData['name'])) {
                    $fileReferrealData = $this->_processFile($fileData);
                    if (false ===  $fileReferrealData) {
                        $this->view->message = "1000 is the Limit.";
                        $this->view->success = false;
                        $this->view->form = $form;
                        return false;
                    }
                }
                $UploadedEntryId = array();
                $failedEntryId = array();
                $response = array();
                $orderNumber = array();
                $csvObj = new BaseApp_Csv();
                //mapper for payment reconsilation table
                $paymentRecosilationMapper = array(
                    //csv  column key => payment Reconsilation table fieldname  
                    0 => 'referrer_email',
                    1 => 'referrer_name',
                    6 => 'orderNumber',
                    10 => 'salesOwnerEmail',
                    12 => 'referrer_status',
                    13 => 'referrer_commission_note',
                );
                //mapper for referrer_referee table
                $referrerRefereeMapper =  array(
                    //csv file column key => referrer_referee table fieldname  
                    0 => 'referrer_email',
                    1 => 'referrer_name',
                    2 => 'referee_email',
                    3 => 'referee_name',
                    4 => 'commission',
                    5 => 'country',
                    6 => 'order_id',
                    7 => 'currency',
                    8 => 'ssvc_amount',
                    9 => 'product_name',
                    10 => 'ism_mail',
                    11 => 'transaction_date',
                    12 => 'referral_status',
                    13 => 'referral_note',
                    14 => 'date_of_entry_in_spreadsheet',
                );
                //manual_referral_update mapper
                $manualUpdateMapper =  array(
                    //csv file column key => manual_referral_upload table fieldname  
                    0 => 'referrer_email',
                    1 => 'referrer_name',
                    2 => 'referee_email',
                    3 => 'referee_name',
                    4 => 'no_of_vouchers',
                    5 => 'country',
                    6 => 'order_id',
                    7 => 'currency',
                    8 => 'ssvc_amount',
                    9 => 'product_name',
                    10 => 'ism_mail',
                    11 => 'transaction_date',
                    12 => 'referral_status',
                    13 => 'referral_note',
                    14 => 'date_of_entry_in_spreadsheet',
                );
                foreach ($fileReferrealData as $i => $data) {
                    if ($i == 0) continue;
                    if (!empty($data)) {
                        $referralInfo =  str_getcsv($data, ",", "");
                        $csvObj->setMapper($paymentRecosilationMapper);
                        $updateData = $csvObj->getMappedData($referralInfo);

                        //updating in  payment reconsilation table                   
                        if (!empty($updateData)) {
                            $paymentReconsilationresponse = $paymentReconcile->updateReferalStatus($updateData);
                        }
                        if (!empty($paymentReconsilationresponse)) {
                            //inserting/updating in referrer-referee-mapping
                            $csvObj->setMapper($referrerRefereeMapper);
                            $insertData = $csvObj->getMappedData($referralInfo);
                            if (!empty($insertData)) {
                                $referrerRefereeresponse = $referrerRefereeObj->saveData($insertData);
                            }
                        }
                            //inserting in manual_referral_update table
                            $csvObj->setMapper($manualUpdateMapper);
                            $data = $csvObj->getMappedData($referralInfo);
                            $result = $referalInsert->saveData(($data));
                        if (!empty($paymentReconsilationresponse)) {
                            $UploadedEntryId[] = $i;
                        } else {
                            $failedEntryId[] = $i;
                            $orderNumber[] = !empty($referralInfo[6]) ? $referralInfo[6] : '';
                        }
                    }
                }
                $csvEntries = array();
                $csvEntries  = array_merge($UploadedEntryId, $failedEntryId);
                $orderNo = 'null';
                $orderNo = implode(",", $orderNumber);
                if (!empty($csvEntries)) {
                    $this->view->message = count($UploadedEntryId) . "  rows uploaded successfully and " . count($failedEntryId) . " failed uploads . <br>Failed order numbers :" . $orderNo;
                    return;
                }
            }
        }
        $this->view->success = true;
        $this->view->form = $form;
    }
    private function _processFile($fileData)
    {
        $fileDataArr = array();
        if ($fileData['tmp_name']) {
            $fileName = $fileData['name'];
            // $absFilePath = sys_get_temp_dir() . DIRECTORY_SEPARATOR . $fileName;
            $absFilePath =  $fileData['tmp_name'];
            $fileInfo = file_get_contents($absFilePath);
            if (!empty($fileInfo)) {
                $fileDataArr =  explode("\n", $fileInfo);
                if (count($fileDataArr) > 1000) {
                    return false;
                }
                return $fileDataArr;
            }
        }
        return $fileDataArr;
    }
}
