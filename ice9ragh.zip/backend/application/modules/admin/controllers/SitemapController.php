<?php

/*
 * Contains the CRUD actions of Accreditors table
 * 
 */

class Admin_SitemapController extends BaseApp_Controller_Crud {

    protected $_model = 'Model_Sitemap';
    protected $_descriptions = array(
        'list' => 'List of Existing Accreditors',
        'index' => 'List of Existing Accreditors',
        'add' => 'Add New Accreditors',
        'edit' => 'Make the required changes then click on "Save Accreditors" to update the Accreditors',
        'view' => 'View Selected Accreditors'
    );

    protected function _getForm() {
        $form = new Form_Scaffold($this->getModel()->getDefinition());
        return $form;
    }

    public function setIncludedAction() {
        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender();
        $model = new Model_Sitemap($this->getRequest()->getPost('sitemap_id'));
        if ($this->getRequest()->getPost('included') == 'true') {
            $model->included = 1;
        } else {
            $model->included = 0;
        }
        $model->update();
        print "success";
    }

    public function listAction() {
        parent::listAction();
        $this->_helper->viewRenderer->setRender('sitemap/list');
    }
    
}
