<?php
/*
 * Contains the CRUD actions of Label table
 * 
 */

class Admin_PracticeTestController extends BaseApp_Controller_Crud {
    protected $_model = 'Model_FreePracticeTest';
    protected $_descriptions = array(
        'list' => 'List Data Table',
        'index' => 'Display',
        'add' => 'Add new ',
        'edit' => 'Edit entry',
        'view' => 'View entry',
        'add-replica' => 'Copy to New row',
        'delete' => 'to prevent unable to delete error.'
    );
        
    protected function _getForm() {
        $form = new Form_PracticeTest();
        return $form;
    }    
    
    public function addAction() {
        $request = $this->getRequest()->getPost();    
//        $this->_setNumberSets($request);
//        $this->_setCountryPrice($request);//pending
//        $this->_setKeyFeatures($request);
//        $this->_setPracticeFaq($request);
//        $this->_setRecommendations($request);
        
        if (!$this->_add)
            $this->forward('list');
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');        
        $form = $this->_getForm();
        if ($form === false)
            throw new Zend_Exception('_getForm not implemented');
        if ($request && $form->isValid($request)) {           
            $request = $form->getValues();
            if ($request['test_type'] == "scholarship_test") {
                $primaryBundle = $request['primary_bundle_id'];
                $secondaryBundle = $request['secondary_bundle_id'];
                $request['primary_product_id'] = $primaryBundle;
                $request['secondary_product'] = $secondaryBundle;
            } 

            unset($request['primary_bundle_id']);
            unset($request['secondary_bundle_id']); 
            if(!empty($request['primary_product_id'])){
                $primaryProduct = explode('#',$request['primary_product_id']);
                $request['primary_product_id'] = $primaryProduct[0];
                $request['primary_product_type'] = $primaryProduct[1];
            }
            if(!empty($request['secondary_product']) && $request['secondary_product'] != null){
                $secondryProduct = array_map(function($val){
                    $product = explode('#',$val);
                    return array('id' => $product[0], 'type' => $product[1]);
                }, $request['secondary_product']);
                $request['secondary_product'] = json_encode($secondryProduct);
            }

            if ($category_id = $this->getCategoryIdByProductId($request['primary_product_id'],$request['primary_product_type'])) {
                $request['category_id'] = $category_id;
            }
             
            //$splitData = $this->_handleDataAfterSubmit($request);
            $result = false;
            $searchTags = $request['tag'];
            unset($request['tag']);
                   
            if($practiceTestId = $this->getModel()->createPracticeTest($request)) {
                $result = true;
            }

            if ( $result) {
                $tags = new Model_Tags();
                $tags->saveTags($practiceTestId, 'freePractice', $searchTags);
                $result = true;
            }

            if (!$result) {
                $this->view->message = "An error has occured while saving";
                $this->view->success = true;
            } else {                
                $this->view->message = "Data successfully added";
                $this->view->success = false;
                $form->reset();
                $module  = $this->getRequest()->getModuleName();
                $controller = $this->getRequest()->getControllerName();
                $action = $this->getRequest()->getActionName();
                if($module && $controller && $action)
                    $this->redirect($module.'/'.$controller.'/');
            }
        }
        $this->view->form = $form;
    }
    
    
    public function editAction() {  
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $tags = new Model_Tags();
        if ($this->getRequest()->isPost()) {
            $request = $this->getRequest()->getPost();
            $form = $this->_getForm();
            $form->removeUneditableElements();  
            $practicetestId = $this->getRequest()->getParam('id');
            $practicetestModel = new Model_FreePracticeTest($practicetestId);
            $form->removeTestElements($practicetestModel->test_type);   
            $request['test_type'] = $practicetestModel->test_type;
            $request['previous_product'] = $practicetestModel->primary_product_id;
            if ($request['test_type'] == "scholarship_test") {
                $request['previous_noOfQuestions'] = $practicetestModel->noOfQuestions;
            }
            $request['paperclip_testId'] = $practicetestModel->paperclip_testId;     
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            if($form->isValid($request)) {
                $data = $form->getValues();
                if ($request['test_type'] == "scholarship_test") {
                    $primaryBundle = $data['primary_bundle_id'];
                    $secondaryBundle = $data['secondary_bundle_id'];
                    $data['primary_product_id'] = $primaryBundle;
                    $data['secondary_product'] = $secondaryBundle;
                } 
                
                unset($data['primary_bundle_id']);
                unset($data['secondary_bundle_id']);  
                if(!empty($data['primary_product_id'])){
                    $primaryProduct = explode('#',$data['primary_product_id']);
                    $data['primary_product_id'] = $primaryProduct[0];
                    $data['primary_product_type'] = $primaryProduct[1];
                    if ($category_id =$this->getCategoryIdByProductId($data['primary_product_id'],$data['primary_product_type'])) {
                        $data['category_id'] = $category_id;
                    }
                }
                if(!empty($data['secondary_product']) && $data['secondary_product'] != null){
                    $secondryProduct = array_map(function($val){
                        $product = explode('#',$val);
                        return array('id' => $product[0], 'type' => $product[1]);
                    }, $data['secondary_product']);
                    $data['secondary_product'] = json_encode($secondryProduct);
                }

                if ($category_id =$this->getCategoryIdByProductId($data['primary_product_id'],$data['primary_product_type'])) {
                    $data['category_id'] = $category_id;
                }
                
                //$splitData = $this->_handleDataAfterSubmit($data);
                $result = false;

                $data['free_practice_test_id'] = $this->getRequest()->getParam('id');
                $searchTags = $data['tag'];
                unset($data['tag']);                 

                if ($tags->saveTags( $data['free_practice_test_id'], 'freePractice', $searchTags)) {
                    $result = true;
                }
                if($this->getModel()->updatePracticeTest($data)) {
                    $result = true;
                }
                if (!$result) {
                    $this->view->message = "An error has occured while saving";
                    $this->view->success = true;
                } else {
                    // for making message page specific
                    $this->view->message = ucwords($this->getRequest()->getControllerName())." Data successfully updated";
                    $this->view->success = false;
                }
                $this->_redirect('/admin/practice-test/list');
            }
        }    
        elseif($practicetestId = $this->getRequest()->getParam('id')) {            
            $practicetestModel = new Model_FreePracticeTest($practicetestId);
            if(!$practicetestModel->toArray()) {
                $this->_redirect('/admin/practice-test/list');
            }
            $session = new Zend_Session_Namespace('form'); 

//            $courseModel = new Model_Courses();        
//            $practicetestModel->course_name =  $courseModel->getNameById($practicetestModel->primary_course_id);
            $form = $this->_getForm();
            $formValues = $practicetestModel->toArray();
            $secondaryProducts = $practicetestModel->select_multiple_pre_select($practicetestModel->secondary_product);
            $primaryProduct = "";
            if(!empty($formValues['primary_product_id']) && !empty($formValues['primary_product_type'])){
                $primaryProduct = $formValues['primary_product_id'].'#'.$formValues['primary_product_type'];
                unset($formValues['primary_product_type']);
            }
            if ($practicetestModel->test_type == "scholarship_test") {
                $practicetestModel->secondary_bundle_id =  $secondaryProducts;
                $formValues['primary_bundle_id'] = $primaryProduct;
                $formValues['secondary_bundle_id'] = $secondaryProducts;
            } else {
                $practicetestModel->secondary_product = $secondaryProducts;
                $formValues['primary_product_id'] = $primaryProduct;
                $formValues['secondary_product'] = $secondaryProducts;
            }
            $this->view->postParams = $practicetestModel;            
            
            $form->removeUneditableElements();
            $form->removeTestElements($practicetestModel->test_type);
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            
            $tagDetail = $tags->getByLinkable($practicetestId, 'freePractice');
            if(isset($tagDetail['tag'])){
                $formValues['tag'] = $tagDetail['tag'];
            }else {
                $courseTagDetail = $tags->getByLinkable($practicetestModel->primary_product_id, $practicetestModel->primary_product_type);
                $formValues['tag'] = $courseTagDetail['tag'];
            }
            $form->setDefaults($formValues);
        }
        else {
            $this->_redirect('/admin/practice-test/list');
        }
        $this->view->form = $form;
    }

    public function getCategoryIdByProductId ($productId,$productType) {
        if($productType == Model_Courses::PRODUCT_TYPE_NAME){
            $course = new Model_Courses();
            $courseDetail = $course->getCourseById($productId,$productType);
            return isset($courseDetail['primary_label_id']) ? $courseDetail['primary_label_id'] : 0;
        }elseif ($productType == Model_Bundles::PRODUCT_TYPE_NAME) {
            $bundle = new Model_Bundles();
            $bundleDetail = $bundle->getBundleById($productId,$productType);
            return isset($bundleDetail['primary_label_id']) ? $bundleDetail['primary_label_id'] : 0;
        }
    }
    
//    private function _setNumberSets(&$request) {
//        $session = new Zend_Session_Namespace('form'); 
//        if(isset($request['paperclip_testid']) && count($request['paperclip_testid'])) {
//            $request['paperclip_testid'] = $this->_updateFirstElement($request['paperclip_testid']);        
//            $session->noOfSets = array_keys($request['paperclip_testid']);
//            array_unshift($session->noOfSets, '__template__');
//            $session->setsNumberData =  $request['paperclip_testid'];
//        }
//        else {
//            $session->noOfSets = array('__template__', 'new');
//            $session->setsNumberData = array();
//        }
//    }
    
//    private function _setCountryPrice(&$request) {
//        $session = new Zend_Session_Namespace('form'); 
//        if(isset($request['countryPrice']) && count($request['countryPrice'])) {
//            $request['countryPrice'] = $this->_updateFirstElement($request['countryPrice']);        
//            $session->countryPrice = array_keys($request['countryPrice']);
//            array_unshift($session->countryPrice, '__template__');
//            $session->countryPriceData =  $request['countryPrice'];
//        }
//        else {
//            $session->countryPrice = array('__template__', 'new');
//            $session->countryPriceData = array();
//        }        
//    }
//    
//    private function _setKeyFeatures(&$request) {
//        $session = new Zend_Session_Namespace('form'); 
//        if(isset($request['keyFeatures']) && count($request['keyFeatures'])) {
//            $request['keyFeatures'] = $this->_updateFirstElement($request['keyFeatures']);        
//            $session->keyFeatures = array_keys($request['keyFeatures']);
//            array_unshift($session->keyFeatures, '__template__');
//            $session->keyFeaturesData =  $request['keyFeatures'];
//        }
//        else {
//            $session->keyFeatures = array('__template__', 'new');
//            $session->keyFeaturesData = array();
//        }
//    }
//    
//    private function _setPracticeFaq(&$request) {
//        $session = new Zend_Session_Namespace('form'); 
//        if(isset($request['practiceFaq']) && count($request['practiceFaq'])) {
//            $request['practiceFaq'] = $this->_updateFirstElement($request['practiceFaq']);        
//            $session->practiceFaq = array_keys($request['practiceFaq']);
//            array_unshift($session->practiceFaq, '__template__');
//            $session->practiceFaqData =  $request['practiceFaq'];
//        }
//        else {
//            $session->practiceFaq = array('__template__', 'new');
//            $session->practiceFaqData = array();
//        }
//    }
//    
//    private function _setRecommendations(&$request) {
//        $session = new Zend_Session_Namespace('form'); 
//        if(isset($request['recommendations']) && count($request['recommendations'])) {
//            $request['recommendations'] = $this->_updateFirstElement($request['recommendations']);        
//            $session->recommendations = array_keys($request['recommendations']);
//            array_unshift($session->recommendations, '__template__');
//            $session->recommendationsData =  $request['recommendations'];
//        }
//        else {
//            $session->recommendations = array('__template__', 'new');
//            $session->recommendationsData = array();
//        }
//    } 
    
    private function _updateFirstElement($elementArray) {
        $keys = array_keys( $elementArray );
        $keys[ array_search( '0', $keys ) ] = 'new';
        return array_combine( $keys, $elementArray );    
    }
    
    private function _handleDataAfterSubmit(&$request) {        
        $returnData = array(
            'countryPrice' => array(),
            'keyFeatures' => array(),
            'practiceFaq' => array(),
            'recommendations' => array(),
            'searchTags' => false
        );
        
        unset($request['course_name']);        
        if(isset($request['keyFeatures'])) {
            unset($request['keyFeatures']['__template__']);
            $returnData['keyFeatures'] = $request['keyFeatures'];
            unset($request['keyFeatures']);
        }
        if(isset($request['practiceFaq'])) {
            unset($request['practiceFaq']['__template__']);
            $returnData['practiceFaq'] = $request['practiceFaq'];
            unset($request['practiceFaq']);
        }
        if(isset($request['recommendations'])) {
            unset($request['recommendations']['__template__']);
            $returnData['recommendations'] = $request['recommendations'];
            unset($request['recommendations']);
        }

        if(isset($request['searchTags'])) {
            $returnData['searchTags'] = $request['searchTags'];
            unset($request['searchTags']);
        }
        unset($request['noOfSets']['__template__']);                
        if(isset($request['countryPrice'])) {
            unset($request['countryPrice']['__template__']);
            $counter = 0;
            foreach($request['countryPrice'] as $elementKey => $data) {                
                foreach($request['noOfSets'] as $setKey => $setValue) {
                    $returnData['countryPrice'][$counter] = array(
                        'country_id' => $data['country_id'],  
                        'currency_id' => $data['currency_id']      
                    );
                    $returnData['countryPrice'][$counter]['setNumber'] = $setValue['setsNumber'];
                    $returnData['countryPrice'][$counter]['subscriptionPrice'] = $data['price'.$setKey];
                    $counter++;
                }                
            }            
            unset($request['noOfSets']);
            unset($request['countryPrice']);
        }        
        return $returnData;
    }
    
//    private function _preparePricing($practicetestId) {
//        $priceModel = new Model_SubscriptionPricing();
//        $countryPrice = array();
//        $sets = array();
//        foreach($priceModel->getByLinkable($practicetestId, 'practice_test') as $indexTemp => $data) {
//            $countryPrice[$data['country_id']]['country_id'] = $data['country_id'];
//            $countryPrice[$data['country_id']]['currency_id'] = $data['currency_id'];
//            $countryPrice[$data['country_id']]['price'.$data['setNumber']] = $data['subscriptionPrice'];
//            $sets[$data['setNumber']] = array(
//                'setsNumber' => $data['setNumber']
//            );
//        }
//        foreach($countryPrice as $key => $data) {
//            foreach($data as $keyElement => $keyData) {                                    
//                if(preg_match("/price(.*)/", $keyElement, $match)) {
//                    $keys = array_keys( $countryPrice[$key] );
//                    $keys[ array_search( $match[0], $keys ) ] = 'pricenew';
//                    $countryPrice[$key] = array_combine( $keys, $countryPrice[$key] );  
//                    break;
//                }                
//            }
//        }
//        return array(
//            'countryPrice' => $countryPrice,
//            'noOfSets' => $sets
//        );
//    }
}
