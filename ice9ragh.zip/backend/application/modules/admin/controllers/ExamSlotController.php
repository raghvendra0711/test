<?php

class Admin_ExamSlotController extends BaseApp_Controller_Crud{
    
    protected $_model = 'Model_ExamSlots';
    protected $_descriptions = array(
        'list' => 'List of Existing Accreditors',
        'index' => 'List of Existing Accreditors',
        'add' => 'Add new Exam Slot',
        'edit' => 'Edit Exam Slot',
        'delete' => 'to prevent unable to delete error.'
    );
    
    
    protected function _getForm() {
        $form=new Form_ExamSlots();
        return $form;
    }
    

    public function addAction() {
        if (!$this->_add)
            $this->forward('list');
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $form = $this->_getForm();
        if ($form === false)
            throw new Zend_Exception('_getForm not implemented');
        if ($this->getRequest()->isPost() && $form->isValid($this->getRequest()->getPost())) {
            $request = $this->getRequest()->getPost();
            $form->removeOptionalElements();
            $result = $this->getModel()->setFromArray($form->getValues())->save();
            if (!$result) {
                $this->view->message = "Error : Exam Slot Already Exists!!";
                $this->view->success = false;
            } else {
                $this->view->message = "Data successfully added";
                $this->view->success = true;
                $form->reset();
                $module  = $this->getRequest()->getModuleName();
                $controller = $this->getRequest()->getControllerName();
                if($module && $controller )
                    $this->redirect($module.'/'.$controller.'/');
            }
        }
        $this->view->form = $form;
    }

    public function editAction() {
        /*
        The CODE remains commented, Do not Uncomment.
        
        $id = $this->getRequest()->getParam('id');
        $data = $this->getModel($id);
        
        if ($data) {
            $this->view->postParams = $data;
            $form = $this->_getForm();
            $form->removeOptionalValidators();
            $form->removeUneditableElements();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            if ($this->getRequest()->isPost() && $form->isValid($this->getRequest()->getPost())) {
                $form->removeOptionalElements();
                $result = $data->setFromArray($form->getValues())->update();
                if (!$result) {
                    $this->view->message = "Time Slot Clashes With Existing Slot";
                    $this->view->success = true;
                } else {
                    // for making message page specific
                    $this->view->message = ucwords($this->getRequest()->getControllerName())." Data successfully updated";
                    $this->view->success = false;
                    $module  = $this->getRequest()->getModuleName();
                    $controller = $this->getRequest()->getControllerName();
                    if($module && $controller )
                        $this->redirect($module.'/'.$controller.'/');
                }
                //$this->forward('list');
            }
            $form->setValues($data->toArray());
            $this->view->form = $form;
        }
         */
    }

    public function deleteAction() {
        $slotId = $this->getRequest()->getParam('id');
        if (empty($slotId)) {
            $this->view->message = "Error : Please pass Slot Id";
            return;
        }

        $examModel = new Model_ExamSlots();
        $examName = $examModel->fetchExamNameFromSlot($slotId);
        if (empty($examName)) {
            $this->view->message = "Error : Exam name is empty.";
            return;
        }

        $data = $this->getModel($slotId);
        $currentDate = time();
        $examDate = strtotime($data['exam_date']);
        if ($examDate < $currentDate) {
            $this->view->message = "Error : Exam Slot can not be deleted now!!";
            return;
        }

        $looperCom = new BaseApp_Communication_Looper();
        $response = $looperCom->scheduleExamSlotCancel($slotId, $examName);
        if (!empty($response['status']) && $response['status'] === true) {
            $result = $data->delete();
            $this->forward('list');
        } else {
            $this->view->message = "Error : Exam Slot can not be deleted,try again!!";
            return;
        }
    }

}