<?php
/*
 * Contains the CRUD actions of Exams table
 * 
 */

class Admin_LectureController extends BaseApp_Controller_Crud {
    protected $_model = 'Model_Lecture';
    protected $_descriptions = array(
        'list' => 'List of Existing Exams',
        'index' => 'List of Existing Exams',
        'add' => 'Add New Exams',
        'edit' => 'Make the required changes then click on "Save Exams" to update the Exams',
        'view' => 'View Selected Exams'
    );
    private $_threshHoldPercent = 70;
    
    public function indexAction() {
        $lectureModel = new Model_Lecture();
        $this->view->courses = $lectureModel->getCoursesToDisplay();        
        $request = $this->getRequest()->getPost();
        
        if ($this->getRequest()->isPost()) {
            foreach($request as $fieldName => $fieldValue) {
                $this->view->$fieldName = $fieldValue;
            }                
            if(isset($request['Go'])) {
                if(!$request['lectureCourse']) {
                    $this->view->errorMessage = 'Please Select a Course';
                    return false;
                }                
                $this->view->coursePreviewData = $lectureModel->getCoursePreviewData($request['lectureCourse']);
                $this->view->lectureData = array();
                if($this->view->coursePreviewData['sections']) {
                    if($this->view->coursePreviewData['preview_type'] == Model_Lecture::COURSE_PREVIEW_TYPE_ELEARNING) {
                        $this->view->lectureData = $lectureModel->getElearningLectureDataByCourse($request['lectureCourse']);
                    }
                    elseif($this->view->coursePreviewData['preview_type'] == Model_Lecture::COURSE_PREVIEW_TYPE_MANUAL) {
                        $this->view->lectureData = $lectureModel->getManualLectureDataByCourse($request['lectureCourse']);
                    }                    
                }       
            }           
        }        
        elseif($courseId = $this->getRequest()->getParam('courseId')){            
            $this->view->lectureCourse = $courseId;
            $this->view->coursePreviewData = $lectureModel->getCoursePreviewData($courseId);            
            $this->view->lectureData = array();            
            if($this->view->coursePreviewData && $this->view->coursePreviewData['sections']) {
                if($this->view->coursePreviewData['preview_type'] == Model_Lecture::COURSE_PREVIEW_TYPE_ELEARNING) {
                    $this->view->lectureData = $lectureModel->getElearningLectureDataByCourse($courseId);
                }
                elseif($this->view->coursePreviewData['preview_type'] == Model_Lecture::COURSE_PREVIEW_TYPE_MANUAL) {
                    $this->view->lectureData = $lectureModel->getManualLectureDataByCourse($courseId);
                }          
            }       
        }
    }
    
    public function saveLectureAction() {
        $lectureModel = new Model_Lecture();
        $request = $this->getRequest()->getPost();   
        if($request['preview_type'] == BaseApp_Dao_Lecture::COURSE_PREVIEW_TYPE_ELEARNING) {
            $result = $lectureModel->saveElearningLecture($request);
        }
        elseif($request['preview_type'] == BaseApp_Dao_Lecture::COURSE_PREVIEW_TYPE_MANUAL) {
            $result = $lectureModel->saveManualLecture($request);
        }        
        $this->_helper->layout->disableLayout();
        $this->view->saveLecture = array(
            'status' => 'success'
        );
        if(!$result) {
            $this->view->saveLecture = array(
                'status' => 'failure',
                'message' => 'Some error occured while saving'
            );
        }else{

        }
    }
    
    /**
     * for plagarism. We are not using it now
     * 
     * 
     * @param type $request
     * @return boolean
     */
    private function _similarities($request) {
        $topics = $request['topics'];
        $array = array();
        foreach($topics as $key => $t) {
            if(is_array($t)) {
                foreach($t as $k => $a) {
                    $array[$key . '-' . $k] = $a;
                }
            }
        }
        
        $similar = array();
        
        foreach($array as $key => $a) {
            if($a == '') {
                continue;
            }
            foreach($array as $k => $aa) {
                if($k == $key) 
                    continue;
                $percent = 0;
                similar_text($a, $aa, $percent);
                if($percent > $this->_threshHoldPercent) {
                    if(isset($similar[$key])) {
                        $similar[$key][$k] = $percent;
                    } else {
                        $similar[$key] = array($k => $percent);
                    }
                }
            }
        }
        
        $lectureKeys = array_keys($topics); 
        $topicKeysByLecture = array();
        foreach($lectureKeys as $temp) {
            $topicKeysByLecture[$temp] = array_keys($topics[$temp]);
        }
        $statements = array();
        $string = array();
        
        $visitedKeys = array();
        
        foreach($similar as $key => $sim) {
            array_push($visitedKeys, $key);
            $temp = explode('-', $key);
            $chapterPosition = array_search($temp[0], $lectureKeys);
            $topicPosition = array_search($temp[1], $topicKeysByLecture[$temp[0]]);
            $str = 'chapter ' . ($chapterPosition + 1) . ' topicPosition ' . ($topicPosition + 1) . ' matching at ';
            foreach($sim as $k => $t) {
                if(in_array($k, $visitedKeys))
                    continue;
                $temp = explode('-', $k);
                $toChapterPosition = array_search($temp[0], $lectureKeys);
                $toTopicPosition = array_search($temp[1], $topicKeysByLecture[$temp[0]]);
                $loopStr = $str;
                $loopStr .= ' ' . round($t) . ' percent with chapter ' . ($toChapterPosition + 1) . ' topic ' . ($toTopicPosition + 1);
                array_push($string, $loopStr);
            }
        }
        if(!empty($string)) {
            $this->view->errorMessage = implode('<br/>', $string);
            return false;            
        } else {
            return true;
        }
    }
    
    private function _isValid($request, &$message='') {        
        $message = 'Some error occured';        
        if($request['preview_type'] == BaseApp_Dao_Lecture::COURSE_PREVIEW_TYPE_MANUAL) {
            foreach($request['urls'] as $chapterId => $url) {
                if(!$url) {
                    $chapterDao = new Model_CoursePreviewChapter($chapterId);
                    $message = "URL missing for chapter '".$chapterDao->chapter_name."'";
                    return false;
                }
                if(preg_match("/([^a-z0-9\-\/]+)/", $url, $match)) {
                    $chapterDao = new Model_CoursePreviewChapter($chapterId);
                    $message = "URL is invalid for chapter '".$chapterDao->chapter_name."'";
                    return false;
                }
            }
        }
        else {
            foreach($request['urls'] as $sectionId => $urls) {
                foreach($urls as $chapterId => $url) {
                    if(!$url) {
                        $chapterDao = new Model_CoursePreviewChapter($chapterId);
                        $message = "URL missing for chapter '".$chapterDao->chapter_name."'";
                        return false;
                    }
                    if(preg_match("/([^a-z0-9\-\/]+)/", $url, $match)) {
                        $chapterDao = new Model_CoursePreviewChapter($chapterId);
                        $message = "URL is invalid for chapter '".$chapterDao->chapter_name."'";
                        return false;
                    }
                }
            }        
        }
        /*
        foreach($request['intro'] as $chapterId => $introText) {            
            $noTopicTranscript = true; 
            foreach($request['topics'][$chapterId] as $topicId => $transcript) {
                if(trim($transcript)) {
                    $noTopicTranscript = false;                        
                    break; 
                }                                                    
            }
            
            if(!trim($introText) && !$noTopicTranscript) {
                $chapterDao = new Model_CoursePreviewChapter($chapterId);
                $message = "Introduction missing for chapter '".$chapterDao->chapter_name."'";
                return false;
            }
            elseif(trim($introText) && isset($request['topics'][$chapterId]) && $noTopicTranscript){
                if($request['preview_type'] == BaseApp_Dao_Lecture::COURSE_PREVIEW_TYPE_MANUAL) {
                    $message = "No Topic Transcript added for chapter '{$chapterId}'";
                }
                else {
                    $chapterDao = new Model_CoursePreviewChapter($chapterId);
                    $message = "No Topic Transcript added for chapter '".$chapterDao->chapter_name."'";
                }                
                return false;
            }
        }
         */
        return true;
    }
    
    public function listAction() {
        $model = new Model_Lecture();
        $table = $model->getName();
        $filterForm = new Form_Filters($table);
        $requestData = array();
        $queryParamsArr = array();
        $page = '';
        if($this->getRequest()->isPost()){
            $filterForm->populate($this->getRequest()->getPost());
            $page = 1;
            $requestData = $filterForm->getValues();
            foreach($requestData as $elementName => $elementValue) {
                if(!empty($elementValue)){
                    $queryData = $filterForm->getElement($elementName)->getAttrib('data-table');
                    $queryData['searchValue'] = $elementValue;
                    $this->queryBuilder($queryData);
                    $queryParamsArr[$queryData['search_id']] = $elementValue;
                } // end of !empty elementValue
            } // end of foreach RequestData
        } // end of if isPost
        if(empty($page)){
            $page = $this->view->navigatorPage;
            $page = (int)$this->getRequest()->getParam('page');
        }
        $orderby = $this->getModel()->getPk() . ' DESC';
        
        if(empty($this->_queryParams)){
            $getData = $this->getRequest()->getQuery();
            unset($getData['page']);
            if(!empty($getData)){
                foreach ($getData as $key => $value) {
                    $queryParamsArr[$key] = $value;
                    $returnData = $filterForm->getSearchFields($key);
                    if(!empty($returnData)){
                        $returnData = $returnData[0];
                        $filterForm->getElement($returnData['searchColumnName'])->setValue($value);
                        $returnData['searchValue'] = $value;
                        $this->queryBuilder($returnData);
                    }
                }
            }
        }
        
        if ($page <= 1) {
            $this->view->firstpage = true;
            $page = 1;
        } else {
            $this->view->firstpage = false;
        }
        $offset = ($page - 1) * self::ROWS_PER_PAGE;   
        $limit = array(self::ROWS_PER_PAGE,$offset);
        $this->view->page = $page;
        $data = $model->fetchAll($this->_queryParams, array('order' => array($orderby), 'limit' => $limit, 'group' => 'course_id'));        
        $perPageData = count($data);
        $total = $model->fetchCount($this->_queryParams);
        if (count($data) < self::ROWS_PER_PAGE) {
            $this->view->lastpage = true;
        } else {
            $this->view->lastpage = false;
        }
        $numberOfPages = ceil($total / self::ROWS_PER_PAGE);
        if($page < $numberOfPages){
            $this->view->currentPageRecord = self::ROWS_PER_PAGE * $page;    
        }else{
            $this->view->currentPageRecord = $total;    
        }
        $this->view->diffPageRecord = $this->view->currentPageRecord - self::ROWS_PER_PAGE;
        if(count($data) < self::ROWS_PER_PAGE){
            $this->view->diffPageRecord = $total - count($data);
        }
        $this->view->totalCount = $total;
        $this->view->totalPages = $numberOfPages;
        $this->view->lastPage = $numberOfPages;
        $pk = $model->getPk();
        foreach ($data as &$row) {
            $row['Action'] = "<a href='" . $this->view->url(array('controller' => 'changelog', 'action' => 'index', 'row' => $row[$pk], 'table' => $table)) . "'>ChangeLog</a> " .
                    "<a href='" . $this->view->url(array('controller' => 'lecture', 'action' => 'index', 'courseId' => $row['course_id'])) . "'>Edit</a> ";
        }
        if(isset($data[0])){
            $original = array_keys($data[0]);
        }else{
            $original = array();
        }
        $as = ($this->_displayInDataTable);
        //new datatable   
        //need to define path in ini file after discussion
        $datatableFilePath = '../../library/BaseApp/Datatable/'.ucfirst($table).'.php';       
        if(file_exists($datatableFilePath)) {
            $dataTableClass = 'BaseApp_Datatable_'.ucfirst($table);               
        }
        else{
            $dataTableClass = 'BaseApp_Datatable_Default';                            
        }

        $dataTable = new $dataTableClass;
        $dataTable->setData($data);
        $this->view->queryParams = http_build_query($queryParamsArr);
        $this->view->form = $filterForm;
        $this->view->data = $dataTable;
        $this->view->original = $original;
        $this->view->displayInDataTable = $as;
        $this->view->navigatorTotal = ceil($total / BACKEND_ROWS_PER_PAGE);
    }           
}
