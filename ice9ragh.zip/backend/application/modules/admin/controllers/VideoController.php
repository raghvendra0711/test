<?php
/*video
 * Contains the CRUD actions of Videos table
 * 
 */

class Admin_VideoController extends BaseApp_Controller_Crud {
    protected $_model = 'Model_Videos';
    protected $_descriptions = array(
        'list' => 'List of Existing Videos',
        'index' => 'List of Existing Videos',
        'add' => 'Add New Videos',
        'edit' => 'Make the required changes then click on "Save Videos" to update the Videos',
        'view' => 'View Selected Videos'
    );

    protected function _getForm() {
        $form = new Form_Videos();
        return $form;
    }
    
    public function addAction() {
        $request = $this->getRequest()->getPost(); 
        if (!$this->_add)
            $this->forward('list');
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $form = $this->_getForm();
        if ($form === false)
            throw new Zend_Exception('_getForm not implemented');
        if ($this->getRequest()->isPost() && $form->isValid($request)) {
            $request = $form->getValues(); 
            $result = $this->getModel()->createVideo($request);
            
            if (!$result) {
                $this->view->message = "An error has occured while saving";
                $this->view->success = true;
            } else {
                $this->view->message = "Data successfully added";
                $this->view->success = false;
                $form->reset();
                $module  = $this->getRequest()->getModuleName();
                $controller = $this->getRequest()->getControllerName();
                $action = $this->getRequest()->getActionName();
                if($module && $controller && $action)
                    $this->redirect($module.'/'.$controller.'/'.$action.'/list');
            }
        }
        $this->view->form = $form;
    }
    
    public function editAction() {
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $id = $this->getRequest()->getParam('id');
        if ($this->getRequest()->isPost()) {
            $request = $this->getRequest()->getPost();   
            $form = $this->_getForm();
            $form->removeUneditableElements();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            if($form->isValid($request)) {
                $data = $form->getValues();                
                $data['video_id'] = $this->getRequest()->getParam('id');  
                $result = $this->getModel()->updateVideo($data);
                        
                if (!$result) {
                    $this->view->message = "An error has occured while saving";
                    $this->view->success = true;
                } else {
                    // for making message page specific
                    $this->view->message = ucwords($this->getRequest()->getControllerName())." Data successfully updated";
                    $this->view->success = false;
                }
                $this->_redirect('/admin/video/list');
            }
        }
        elseif($videoId = $this->getRequest()->getParam('id')) {        
            $videoModel = new Model_Videos($videoId);
            if(!$videoModel->toArray()) {
                $this->_redirect('/admin/video/list');
            }
            
            $this->view->postParams = $videoModel;            
            
            $form = $this->_getForm();
            $form->removeUneditableElements();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            $form->setDefaults($videoModel->toArray());   
        }
        else {
            $this->_redirect('/admin/bundle/list');
        }
        $this->view->form = $form;
    }
}
