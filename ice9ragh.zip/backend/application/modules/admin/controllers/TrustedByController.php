<?php
/*
 * Contains the CRUD actions of Accreditors table
 * 
 */

class Admin_TrustedByController extends BaseApp_Controller_Crud {
    protected $_model = 'Model_ProductSectionData';
    protected $_descriptions = array(
        'list' => 'List of Existing Trusted By Logos',
        'index' => 'List of Existing Trusted By Logos',
        'add' => 'Add New Trusted By Logo',
        'edit' => 'Make the required changes then click on "Save Trusted By Logo" to update the Trusted By Logo',
        'view' => 'View Selected Trusted By Logo'
    );

    protected function _getForm() {
        $form = new Form_TrustedBy();
        return $form;
    }

    public function addAction() {
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $form = $this->_getForm();
        $request = $this->getRequest()->getPost();
        if($this->getRequest()->isPost() && $form->isValid($request)) {
            $obj = new Model_ProductSectionData();
            $data = $form->getValues();
            $data['sectionType'] = 'trustedByLogos';
            $data['sectionTitle'] = '';
            unset($data['bundle_id_err']);
            if(!empty($data['bundle_id_arr'])){
                $labels = $data['bundle_id_arr'];
                unset($data['bundle_id_arr']);
                $resultId = $obj->saveProductSectionData($data);
                if($resultId){
                    $smObj = new Model_SectionMapping();
                    $result = $smObj->saveProductSectionDataBySectionId($labels, BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES, $resultId);
                }
            }
            if (!$result) {
                $this->view->message = "An error has occured while saving";
                $this->view->success = false;
                $this->view->form = $form;
                return false;
            } else {
                $this->view->message = "Saved SuccessFully";
                $this->view->success = false;
                $this->_redirect("/admin/trusted-by/list");
            }
        }
        $this->view->success = true;
        $this->view->form = $form;
    }

    public function editAction() {
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        
        $id = $this->getRequest()->getParam('id');
        $smObj = new Model_SectionMapping();
        if(!$id)
            throw new BaseApp_Exception('Editable item not selected properly');        
        $courseAdvisorData = current($this->getModel()->fetchAll(array('id =?'=>$id)));
        $courseAdvisorData['bundle_id_arr'] = $smObj->getByProductSection(BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES, $id);
        if (empty($courseAdvisorData))
            throw new BaseApp_Exception('Editable item not selected properly');
        
        $form = $this->_getForm();
        
        if ($this->getRequest()->isPost()) { 
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            if ($form->isValid($this->getRequest()->getPost())) {
                $obj = new Model_ProductSectionData();
                $data = $form->getValues(); 
                unset($data['bundle_id_err']);
                if(!empty($data['bundle_id_arr'])){
                    $labels = $data['bundle_id_arr'];
                    unset($data['bundle_id_arr']);
                    $data['bundle_id_arr'] = $labels;
                    $result = $obj->updateProductSectionData($id, $data);                    
                }
                
                if (!$result) {
                    $this->view->message = "An error has occured while saving";
                    $this->view->success = false;
                    $this->view->form = $form;
                    return false;
                } else {
                    $form->reset();
                    $module  = $this->getRequest()->getModuleName();
                    $controller = $this->getRequest()->getControllerName();
                    $action = $this->getRequest()->getActionName();
                    if($module && $controller && $action)
                        $this->redirect($module.'/'.$controller.'/list');
                }
            }
            else {                                
                $form->setDefaults($courseAdvisorData);
            }
        }        
        else {     
            $form->setDefaults($courseAdvisorData);
        }
        $this->view->form = $form;
    }

    /* delete function Calls an Api to check whether Payment Exists against it */
     public function deleteAction(){
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $form = $this->_getForm();
        $Id = $this->getRequest()->getParam('id');
        if(!$Id)
            throw new BaseApp_Exception('Editable item not selected properly');
        
        $courseAdvisorData = current($this->getModel()->fetchAll(array('id =?'=>$Id)));
        if (empty($courseAdvisorData))
            throw new BaseApp_Exception('No Data found');

        $data['status'] = 0;
        $result = $this->getModel()->updateProductSectionData($Id, $data);
        if (!$result) {
            $this->view->message = "An error has occured while saving";
            $this->view->success = true;
            $module  = $this->getRequest()->getModuleName();
            $controller = $this->getRequest()->getControllerName();
            $action = $this->getRequest()->getActionName();
            if($module && $controller && $action)
                $this->redirect($module.'/'.$controller.'/'.$action.'/id/'.$Id);
        } else {
            $this->view->message = "Saved SuccessFully";
            $this->view->success = false;
            $form->reset();
            $module  = $this->getRequest()->getModuleName();
            $controller = $this->getRequest()->getControllerName();
            $action = $this->getRequest()->getActionName();
            if($module && $controller && $action)
                $this->redirect($module.'/'.$controller.'/list');
        }
    }

   public function listAction() {
        $this->_helper->viewRenderer->setRender('common/list')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');

        $table = $this->getModel()->getName();
        $filterForm = new Form_Filters($table);
        $requestData = array();
        $queryParamsArr = array();
        $page = '';
        if($this->getRequest()->isPost()){
            $filterForm->populate($this->getRequest()->getPost());
            $page = 1;
            $requestData = $filterForm->getValues();
            foreach($requestData as $elementName => $elementValue) {
                if(!empty($elementValue)){
                    $queryData = $filterForm->getElement($elementName)->getAttrib('data-table');
                    $queryData['searchValue'] = $elementValue;
                    $this->queryBuilder($queryData);
                    $queryParamsArr[$queryData['search_id']] = $elementValue;    
                }
            }
        }
        if(empty($page)){
            $page = $this->view->navigatorPage;
            $page = (int)$this->getRequest()->getParam('page');
        }
        $orderby = $this->getModel()->getPk() . ' DESC';
        if(empty($this->_queryParams)){
            $getData = $this->getRequest()->getQuery();
            unset($getData['page']);
            if(!empty($getData)){
                foreach ($getData as $key => $value) {
                    $queryParamsArr[$key] = $value;
                    $returnData = $filterForm->getSearchFields($key);
                    if(!empty($returnData)){
                        $returnData = $returnData[0];
                        $filterForm->getElement($returnData['searchColumnName'])->setValue($value);
                        $returnData['searchValue'] = $value;
                        $this->queryBuilder($returnData);
                    }
                }
            }
        }
        if ($page <= 1) {
            $this->view->firstpage = true;
            $page = 1;
        } else {
            $this->view->firstpage = false;
        }
        $offset = ($page - 1) * self::ROWS_PER_PAGE;
        $limit = array(self::ROWS_PER_PAGE,$offset);
        $this->view->page = $page;
        $model = $this->getModel();
        $this->_queryParams['sectionType =?'] = 'trustedByLogos';
        $data = $model->fetchAll($this->_queryParams, array('order' => array($orderby), 'limit' => $limit));

        $perPageData = count($data);
        if (count($data) < self::ROWS_PER_PAGE) {
            $this->view->lastpage = true;
        } else {
            $this->view->lastpage = false;
        }
        $total = $model->fetchCount($this->_queryParams);
        $numberOfPages = ceil($total / self::ROWS_PER_PAGE);
        if($page < $numberOfPages){
            $this->view->currentPageRecord = self::ROWS_PER_PAGE * $page;    
        }else{
            $this->view->currentPageRecord = $total;    
        }
        $this->view->diffPageRecord = $this->view->currentPageRecord - self::ROWS_PER_PAGE;
        if(count($data) < self::ROWS_PER_PAGE){
            $this->view->diffPageRecord = $total - count($data);
        }
        $this->view->totalCount = $total;
        $this->view->totalPages = $numberOfPages;
        $this->view->lastPage = $numberOfPages;
        $pk = $model->getPk();
        foreach ($data as $key => &$row) {
            $row['Action'] = "<a href='" . $this->view->url(array('action' => 'view', 'id' => $row[$pk])) . "'>View</a> " ."<a href='" . $this->view->url(array('controller' => 'changelog', 'action' => 'index', 'row' => $row[$pk], 'table' => $table)) . "'>ChangeLog</a> " ."<a href='#' onclick='deleteConfirmShow(\"" . $this->view->url(array('controller' => 'trusted-by', 'action' => 'delete', 'id' => $row[$pk])) . "\")'>Delete</a> " .
                    "<a href='" . $this->view->url(array('action' => 'edit', 'id' => $row[$pk])) . "'>Edit</a> " ;
        }
        if(isset($data[0])){
            $original = array_keys($data[0]);
        }else{
            $original = array();
        }
        $as = ($this->_displayInDataTable);
        $datatableFilePath = '../../library/BaseApp/Datatable/'.ucfirst('Alumni').'.php';       
        if(file_exists($datatableFilePath)) {
            $dataTableClass = 'BaseApp_Datatable_TrustedBy';
        }
        else{
            $dataTableClass = 'BaseApp_Datatable_Default';                            
        }

        $dataTable = new $dataTableClass;
        $dataTable->setData($data);
        $this->view->data = $dataTable;
        $this->view->original = $original;
        $this->view->displayInDataTable = $as;
        $this->view->queryParams = http_build_query($queryParamsArr);
        $this->view->form = $filterForm;
        $this->view->navigatorTotal = ceil($total / BACKEND_ROWS_PER_PAGE);
    }

}
