<?php

class Admin_FptFaqsController extends BaseApp_Controller_Crud {

    protected $_model = 'Model_FptFaqs';
    protected $_descriptions = array(
        'add' => 'Add New CityPage',
    );
    protected $coursesWithCitPage = array();

    public function init() {
        parent::init();
        $this->_getCourseWithCityPage();
    }

    /**
     * Get Course With City
     */
    private function _getCourseWithCityPage() {
        $cityPageModel = new Model_CityPage();
        $seoCourseList = $cityPageModel->getCourseList();
        $seoBundleList = $cityPageModel->getBundleList();
        $courseList = array();
        $bundleList = array();
        if (!empty($seoCourseList)) {
            $courseList = array_column($seoCourseList, 'name', 'linkable_id');
        }
        if (!empty($seoBundleList)) {
            $bundleList = array_column($seoBundleList, 'name', 'linkable_id');
        }

        $this->courseList = $courseList;
        $this->bundleList = $bundleList;
    }

    /**
     * Get Form
     * @return \Form_CityPage
     */
    protected function _getForm() {
        $form = new Form_FptFaqs();
        return $form;
    }

    public function addAction() {
        $form = $this->_getForm();
        $this->view->form = $form;
        $this->view->courseList = $this->courseList;
        $this->view->bundleList = $this->bundleList;
    }

    /**
     * Get Course Cities and Countries
     */
    public function getCourseCitiesAction() {
        $courseId = $this->getRequest()->get('courseId');
        $cityList = $cityCountryList = $sortedCityList = array();
        if ($courseId && is_numeric($courseId)) {
            $cityPageModel = new Model_CityPage();
            $cityList = $cityPageModel->getCourseCities($courseId);
            if (!empty($cityList)) {
                $cityIds = array_keys($cityList);
                $countryData = $cityPageModel->countryDataByCityId($cityIds);
                $cityCountryNameMapping = array_column($countryData, 'name', 'city_id');
                $cityCountryIdMapping = array_column($countryData, 'country_id', 'city_id');
                if (!empty($cityCountryNameMapping)) {
                    foreach ($cityList as $id => $cityName) {
                        if (!empty($cityCountryNameMapping[$id])) {
                            $countryName = $cityCountryNameMapping[$id];
                            $countryCityName = $countryName . ' - ' . $cityName;
                            $cityCountryList[$id] = $countryCityName;
                        }
                    }
                    asort($cityCountryList);
                    foreach ($cityCountryList as $key => $val) {
                        $sortedCityList[] = array('id' => $key, 'name' => $val, 'country_id' => $cityCountryIdMapping[$key]);
                    }
                }
            }
        }
        $this->_helper->layout->disableLayout();
        $this->view->courseCities = $sortedCityList;
    }

    /**
     * Get Country By City Id
     */
    public function getCountryByCityIdAction() {
        $cityId = $this->getRequest()->get('cityId');
        $result = array();
        if ($cityId && is_numeric($cityId)) {
            $cityPageModel = new Model_CityPage();
            $result = $cityPageModel->getCountryByCityId($cityId);
        }
        $this->_helper->layout->disableLayout();
        $this->view->countryId = $result;
    }

    public function getCourseDataAction() {
        $result = array();
        $productId = $this->getRequest()->get('productId');
        $productType = $this->getRequest()->get('productType');
        $fptFaqs = new Model_FptFaqs();
        $courseFaqRes = $fptFaqs->getCourseFaqs($productId,$productType);
        $result['courseFaqs'] = !empty($courseFaqRes['courseFaqs']) ? $courseFaqRes['courseFaqs'] : array();
        
        //$courseIntroText = $cityPageModel->getCourseIntroText($cityId, $courseId, $trainingTypeId);
        $result['courseIntro'] = !empty($courseIntroText) ? $courseIntroText : array();
        $this->_helper->layout->disableLayout();
        $this->view->data = $result;
    }

    /**
     * Update Course Intro Text
     */
    public function updateCourseIntroTextAction() {
        $result = array('status' => false, 'msg' => null);
        $id = $this->getRequest()->get('id');
        $courseIntrotext = $this->getRequest()->get('introText');
        if ($id && !empty($courseIntrotext)) {
            $cityPageModel = new Model_CityPage();
            $courseFaqRes = $cityPageModel->updateCourseIntroText($id, $courseIntrotext);
            if ($courseFaqRes) {
                $result['status'] = true;
                $result['msg'] = 'Success';
                $result['id'] = $id;
            } else {
                $result['status'] = false;
                $result['msg'] = 'Failed';
                $result['id'] = $id;
            }
        }
        echo json_encode($result);
        exit;
    }

    /**
     * Update City Page Question & Answer 
     */
    public function updateFptPageFaqsAction() {
        $this->_helper->layout->disableLayout();
        $result = array('status' => false, 'msg' => null, 'data' => array());
        $courseDesription = array();
        $id = $this->getRequest()->get('id');
        $question = $this->getRequest()->get('question');
        $answer = $this->getRequest()->get('answer');
        $answer = preg_replace('/[\x{200B}-\x{200D}\x{FEFF}]/u', '', $answer);
        $productId = $this->getRequest()->get('productId');
        $productTypeId = $this->getRequest()->get('productTypeId');
        $type = BaseApp_Dao_FptFaqs::FPT_FAQ_TYPE;
        $lookupId = $this->getRequest()->get('lookupId');
        $mapId = $this->getRequest()->get('mapId');
        if ($id && !empty($question) && !empty($answer) && !empty($type) && !empty($productId) && !empty($productTypeId)) {
            $fptFaqs = new Model_FptFaqs();
            $productType = $fptFaqs->getLinkableTypeByProductTypeId($productTypeId);
            $courseFaqRes = $fptFaqs->updateFptPageFaqs($id, $answer, $question, $type, $productId, $productType, $lookupId, $mapId);
            if (!empty($courseFaqRes['status']) && $courseFaqRes['status']) {
                $this->view->updateStatus = true;
                $result['status'] = true;
                $result['msg'] = 'Success';
                $result['id'] = $id;
                $result['data'] = $courseFaqRes['data'];
                $output = $this->view->render('fpt-faqs/partial/update-fpt-page-faq.phtml');
                $result['template'] = $output;
            } else {
                $result['status'] = false;
                $result['msg'] = !empty($courseFaqRes['msg']) ? $courseFaqRes['msg'] : 'Failed';
                $result['id'] = $id;
                $this->view->result = $result;
                $this->view->updateStatus = false;
            }
            echo json_encode($result);
            exit;
        }
    }

    /**
     * Add More Question
     */
    public function addMoreQuestionAnswerAction() {
        $this->_helper->layout->disableLayout();
        $result = array('status' => false, 'msg' => null, 'data' => array());
        $question = $this->getRequest()->get('question');
        $answer = $this->getRequest()->get('answer');
        $answer = preg_replace('/[\x{200B}-\x{200D}\x{FEFF}]/u', '', $answer);
        $productId = $this->getRequest()->get('productId');
        $productTypeId = $this->getRequest()->get('productTypeId');
        if (!empty($question) && !empty($answer) && !empty($productId) && !empty($productTypeId)) {
            $fptFaqsModel = new Model_FptFaqs();
            $courseFaqRes = $fptFaqsModel->addMoreQuestionAnswer($answer, $question, $productId,$productTypeId);
            if (!empty($courseFaqRes['status']) && $courseFaqRes['status']) {
                $this->view->updateStatus = true;
                $result['status'] = true;
                $result['msg'] = 'Success';
                $result['data'] = $courseFaqRes['data'];
                $output = $this->view->render('fpt-faqs/partial/update-fpt-page-faq.phtml');
                $result['template'] = $output;
            } else {
                $result['status'] = false;
                $result['msg'] = !empty($courseFaqRes['msg']) ? $courseFaqRes['msg'] : 'Failed';
                $this->view->result = $result;
                $this->view->updateStatus = false;
            }
            echo json_encode($result);
            exit;
        }
    }
    /**
     * Toogle Question Status
     */
    public function updateFaqStatusAction() {
        $productId = $this->getRequest()->get('productId');
        $productTypeId = $this->getRequest()->get('productTypeId');
        
        $faqId = $this->getRequest()->get('faqId');
        $result = array('status' => false, 'msg' => 'Failed', 'mappingIdUpdated' => array());
        if (!empty($faqId) && !empty($productId)) {
            $objCourseCityLookUp = new Model_CourseCityLookup();
            $productType = $objCourseCityLookUp->getLinkableTypeByProductTypeId($productTypeId);
            $lookupResult = $objCourseCityLookUp->getLookUpIdOfCourseId($productId,$productType);
            if (!empty($lookupResult)) {
                $row = current($lookupResult);
                $lookupId = $row['id'];
                $objCourseResourceMapping = new Model_CourseResourceMapping ();
                $faqData = $objCourseResourceMapping->getResouceMapByFaqAndLookup($faqId, $lookupId);
                if (!empty($faqData)) {
                    $faqData = current($faqData);
                    $mappingId = (int) $faqData['id'];
                    $status = (int) $faqData['status'];
                    if (!empty($mappingId)) {
                        $newStatus = $status ? 0 : 1;
                        $updateCourseMappingData = array('status' => (int) $newStatus);
                        $objCourseResourceMapping->setId($mappingId);
                        if ($objCourseResourceMapping->setFromArray($updateCourseMappingData)->update()) {
                            $result['status'] = true;
                            $result['msg'] = 'Success';
                            $result['newStatus'] = $newStatus;
                            $result['mappingIdUpdated'] = $mappingId;
                        }
                    }
                }
            }
        }
        echo json_encode($result);
        exit;
    }

    public function getAllTrainingTypesAction() {
        $result = array('status' => false, 'message' => '', 'data' => array());
        $trainingTypes = array();
        $courseId = $this->getRequest()->get('product_id');
        if (!empty($courseId)) {
            $courseObj = new BaseApp_Dao_Courses();
            $data = $courseObj->getTrainingTypes($courseId);
            if (!empty($data)) {
                $trainingIds = $data[$courseId];
                if (in_array(BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM, $trainingIds)) {
                    $trainingTypes[BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM] = "Classroom";
                }
                if (in_array(BaseApp_Dao_TrainingTypes::TYPE_ELEARNING, $trainingIds)) {
                    $trainingTypes[BaseApp_Dao_TrainingTypes::TYPE_ELEARNING] = "Online Self Learning";
                }
                if (in_array(BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS, $trainingIds)) {
                    $trainingTypes[BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS] = BaseApp_Dao_TrainingTypes::CART_ONLINE_CLASSROOM_PASS;
                }

                $result['status'] = true;
                $result['message'] = 'success';
                $result['data'] = $trainingTypes;
            }
        }
        echo json_encode($result);
        exit;
    }

    /**
     * Change Order For Faq 
    */
    public function faqMoveAction() {

        $this->_helper->layout->disableLayout();
        $data = array();
        $result = array('status' => false, 'msg' => null);
        $finalPosition = $this->getRequest()->get('toMovePos');
        $currentPos = $this->getRequest()->get('currentPos');
        $linkableType = $this->getRequest()->get('linkableType');
        $linkableId = $this->getRequest()->get('linkableId');
        $courseFaqId = $this->getRequest()->get('courseFaqId');
        $clusterId = 0;
        $countryId = 0;
        $cityId = 0;
        $trainingTypeId = 0;
        $contentType = $this->getRequest()->get('contentType');
        
        if (empty($courseFaqId) || empty($currentPos) || empty($finalPosition)) {
            $result = array('status' => false, 'msg' => 'Missing data');
        }else{
            $data['to_move_pos'] = $finalPosition;
            $data['current_pos'] = $currentPos;
            $data['linkable_id'] = $linkableId;
            $data['linkable_type'] = $linkableType;
            $data['course_faq_id'] = $courseFaqId;
            $data['cluster_id'] = $clusterId;
            $data['country_id'] = $countryId;
            $data['city_id'] = $cityId;
            $data['training_id'] = $trainingTypeId;
            $data['content_type'] = $contentType;
            $objCourseFaq = new Model_CourseFaq();
            if ($currentPos != $finalPosition) {
                if ($objCourseFaq->changeFaQOrder($data, $currentPos, $finalPosition)) {
                    $result['status'] = true;
                    $result['msg'] = 'Success';
                }
            }
        }
        echo json_encode($result);
        exit;
    }

}
