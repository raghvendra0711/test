<?php
/*
 * Contains the CRUD actions of Media table
 * 
 */

class Admin_MediaCoverageController extends BaseApp_Controller_Crud {
    protected $_model = 'Model_MediaCoverage';
    protected $_descriptions = array(
        'list' => 'List of Existing Media',
        'index' => 'List of Existing Media',
        'add' => 'Add New Media',
        'edit' => 'Make the required changes then click on "Save Media" to update the Media',
        'view' => 'View Selected Media'
    );

    protected function _getForm() {
        $form = new Form_MediaCoverage();
        return $form;
    }
}
