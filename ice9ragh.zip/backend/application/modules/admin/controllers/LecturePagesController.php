<?php

/*
 * Contains the CRUD actions of Accreditors table
 * 
 */

class Admin_LecturePagesController extends BaseApp_Controller_Crud {

    protected $_model = 'Model_LecturePages';   
    protected $_columns = array('id', 'key', 'content', 'order', 'linkable_id', 'linkable_type');
    protected $_descriptions = array(
        'list' => 'List of Existing SeoLecturePages',
        'index' => 'List of Existing SeoLecturePages',
        'add' => 'Add New LecturePages',
        'edit' => 'Make the required changes then click on "Save LecturePages" to update the Accreditors',
        'view' => 'View Selected LecturePages'
    );

    protected function _getForm() {
        $form = new Form_LecturePages();
        return $form;
    }

    public function listAction() {
        $this->_helper->viewRenderer->setRender('common/list')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $table = $this->getModel()->getName();
        $filterForm = new Form_Filters($table);
        $requestData = array();
        $queryParamsArr = array();
        $page = '';
        if ($this->getRequest()->isPost()) {
            $filterForm->populate($this->getRequest()->getPost());
            $page = 1;
            $requestData = $filterForm->getValues();
            foreach ($requestData as $elementName => $elementValue) {
                if (!empty($elementValue)) {
                    $queryData = $filterForm->getElement($elementName)->getAttrib('data-table');
                    $queryData['searchValue'] = $elementValue;
                    $this->queryBuilder($queryData);
                    $queryParamsArr[$queryData['search_id']] = $elementValue;
                }
            }
        }
        if (empty($page)) {
            $page = $this->view->navigatorPage;
            $page = (int) $this->getRequest()->getParam('page');
        }
        $orderby = $this->getModel()->getPk() . ' DESC';
        if (empty($this->_queryParams)) {
            $getData = $this->getRequest()->getQuery();
            unset($getData['page']);
            if (!empty($getData)) {
                foreach ($getData as $key => $value) {
                    $queryParamsArr[$key] = $value;
                    $returnData = $filterForm->getSearchFields($key);
                    if (!empty($returnData)) {
                        $returnData = $returnData[0];
                        $filterForm->getElement($returnData['searchColumnName'])->setValue($value);
                        $returnData['searchValue'] = $value;
                        $this->queryBuilder($returnData);
                    }
                }
            }
        }
        if ($page <= 1) {
            $this->view->firstpage = true;
            $page = 1;
        } else {
            $this->view->firstpage = false;
        }
        $offset = ($page - 1) * self::ROWS_PER_PAGE;
        $limit = array(self::ROWS_PER_PAGE, $offset);
        $this->view->page = $page;
        $model = $this->getModel();
        $options = array('order' => array($orderby), 'limit' => $limit);
        if (!empty($this->_columns)) {
            $options['columns'] = $this->_columns;
        }
        $data = $model->fetchAll($this->_queryParams, $options);
        $perPageData = count($data);
        $total = $model->fetchCount($this->_queryParams);
        if (count($data) < self::ROWS_PER_PAGE) {
            $this->view->lastpage = true;
        } else {
            $this->view->lastpage = false;
        }
        $numberOfPages = ceil($total / self::ROWS_PER_PAGE);
        if ($page < $numberOfPages) {
            $this->view->currentPageRecord = self::ROWS_PER_PAGE * $page;
        } else {
            $this->view->currentPageRecord = $total;
        }
        $this->view->diffPageRecord = $this->view->currentPageRecord - self::ROWS_PER_PAGE;
        if (count($data) < self::ROWS_PER_PAGE) {
            $this->view->diffPageRecord = $total - count($data);
        }

        $this->view->totalCount = $total;
        $this->view->totalPages = $numberOfPages;
        $this->view->lastPage = $numberOfPages;
        $pk = $model->getPk();
        //@TODO: Remove from controller and create an action helper.
        foreach ($data as &$row) {
            $row['Action'] = "<a href='" . $this->view->url(array('action' => 'view', 'id' => $row[$pk])) . "'>View</a> " . "<a href='" . $this->view->url(array('controller' => 'changelog', 'action' => 'index', 'row' => $row[$pk], 'table' => $table)) . "'>ChangeLog</a> " .
                    "<a href='" . $this->view->url(array('action' => 'edit', 'id' => $row[$pk])) . "'>Edit</a> " .
                    "<a class='delete-crud-item' href='#' onclick='deleteConfirmShow(\"" . $this->view->url(array('action' => 'delete', 'id' => $row[$pk])) . "\");'>Delete</a> " .
                    "<a href='" . $this->view->url(array('action' => 'add-replica', 'id' => $row[$pk])) . "'>Replicate</a> ";
        }
        //================
        if (isset($data[0])) {
            $original = array_keys($data[0]);
        } else {
            $original = array();
        }
        $as = ($this->_displayInDataTable);
        //new datatable   
        //need to define path in ini file after discussion
        $datatableFilePath = '../../library/BaseApp/Datatable/' . ucfirst($table) . '.php';
        if (file_exists($datatableFilePath)) {
            $dataTableClass = 'BaseApp_Datatable_' . ucfirst($table);
        } else {
            $dataTableClass = 'BaseApp_Datatable_Default';
        }
        $dataTable = new $dataTableClass;
        $dataTable->setData($data);
        $this->view->queryParams = http_build_query($queryParamsArr);
        $this->view->form = $filterForm;
        $this->view->data = $dataTable;
        $this->view->original = $original;
        $this->view->displayInDataTable = $as;
        $this->view->navigatorTotal = ceil($total / BACKEND_ROWS_PER_PAGE);
    }

    public function addAction() {
        $modelSeo = new Model_Seo();
        $request = $this->getRequest()->getPost();
        if (!$this->_add)
            $this->forward('list');
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $form = $this->_getForm();
        $data = $form->getValues();       
        if ($form === false)
            throw new Zend_Exception('_getForm not implemented');

        if ($request && $form->isValid($request)) {
            $lecturePageUrl = $request['url'];
            $lecturePageObj = new Model_LecturePages();
            $result1 = $modelSeo->getDataByUrl($lecturePageUrl);
            if (!empty($result1)) {
                $result = $lecturePageObj->saveLecturePagesData($request);
                $Id = $result;
                $seoData = array();
                $para = array();
                $para['lecture_id'] = $Id;
                $seoData['controller'] = 'lecture-page';
                $seoData['linkable_id'] = $Id;
                $seoData['linkable_type'] = 'lecture_pages';
                $seoData['params'] = json_encode($para);
                $modelSeo->setId($result1['seo_id']);
                $modelSeo->setFromArray($seoData)->update();
                $this->view->success = false;
                $objCdn = new Model_CdnPurgeLog();
                $objCdn->InsertCdnPurgeLog($cdnPurgeData);
                $module = $this->getRequest()->getModuleName();
                $controller = $this->getRequest()->getControllerName();
                if ($module && $controller)
                    $this->redirect($module . '/' . $controller . '/list');
            }
            else {
                $this->view->message = " Url is not found";
                $this->view->success = true;
            }
        }
        $this->view->form = $form;
    }

    public function editAction() {
        $lectureUrl = new Model_Seo();
        $courseName = new Model_Courses();
        $formData = array();
        $form = $this->_getForm();
        $form->removeUneditableElements();
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $id = $this->getRequest()->getParam('id');
        $data = $this->getModel($id);
        $data1 = array();
        if ($data) {
            $data1 = $lectureUrl->getDataByLinkable($id, 'lecture_pages');
            $this->view->postParams = $data;
            if ($this->getRequest()->isPost()) {

                $request = $this->getRequest()->getPost();
                $form = $this->_getForm();
                $form->removeUneditableElements();
                if ($form === false)
                    throw new Zend_Exception('_getForm not implemented');
                if ($form->isValid($request)) {
                    $form->removeOptionalElements();
                    $dataSave = $form->getValues();

                    $linkable_id = $dataSave['primary_course_id'];
                    unset($dataSave['url']);
                    unset($dataSave['primary_course_id']);
                    $dataSave['linkable_id'] = $linkable_id;
                    try {
                        $result = $data->setFromArray($dataSave)->update();
                    } catch (Exception $e) {
                        $this->view->message = "there is a issue while updating data";
                    }
                    if (!$result) {
                        $this->view->message = "An error has occured while saving";
                        $this->view->success = true;
                    } else {
                        $this->view->message = ucwords($this->getRequest()->getControllerName()) . " Data successfully updated";
                        $this->view->success = false;
                        $objCdn = new Model_CdnPurgeLog();
                        $objCdn->InsertCdnPurgeLog($cdnPurgeData);
                        $module = $this->getRequest()->getModuleName();
                        $controller = $this->getRequest()->getControllerName();
                        if ($module && $controller)
                            $this->redirect($module . '/' . $controller . '/list');
                    }
                }
                else {
                    $dataSave = $form->getValues();
                    $form->setDefaults($dataSave);
                }
            } else {
                $lecturePageData = array();
                $lecturePageData = $data->toArray();
                $Id = $lecturePageData['linkable_id'];
                $lecturePageData['url'] = $data1['url'];
                $lecturePageData['primary_course_id'] = $Id;
                if ($form === false)
                    throw new Zend_Exception('_getForm not implemented');
                $form->setDefaults($lecturePageData);
            }
            $this->view->form = $form;
        }
    }

}
