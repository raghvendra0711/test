<?php
/*
 *CRUD for banners
 * 
 */

class Admin_PassController extends BaseApp_Controller_Crud {
    protected $_model = 'Model_Pass';            
    
    //protected $_add = false;
    
    protected $_descriptions = array(
        'list' => 'List of Existing Pass',
        'index' => 'List of Existing Pass',
        'add' => 'Add New Pass',
        'edit' => 'Make the required changes then click on "Save Pass" to update the Pass',
        'view' => 'View Selected Pass'
    );

    public function indexAction() {
        
    }
    
    protected function _getForm() {
        $form = new Form_PassPricings();
        return $form;
    }
    
    public function addAction() {                
        $request = $this->getRequest()->getPost();
        $this->_setPassPrice($request);
        if (!$this->_add)
            $this->forward('list');
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $form = $this->_getForm();                
        if ($form === false)
            throw new Zend_Exception('_getForm not implemented');
        
        if($this->getModel()->fetchAll()) {
            throw new Zend_Exception('you can not add more than one pass');
        }
        
        if ($request && $form->isValid($request)) {
            $request = $form->getValues(); 
            if(!$this->_isValid($request, $message)) {
                $this->view->message = $message;
                $this->view->success = false;
                $this->view->form = $form;
                return;
            }
            $splitData = $this->_handleAfterSubmit($request);
            $result = false;
            if($passId = $this->getModel()->createPass($request)) {
                $result = true;
                
                $pricing = new Model_PassPricings();
                if($result && !$pricing->savePricing($passId, $splitData['countryPrice'])) {
                    $result = false;
                }                                               
            }  
            
            if (!$result) {
                $this->view->message = "An error has occured while saving";
                $this->view->success = true;
            } else {                
                $this->view->message = "Data successfully added";
                $this->view->success = false;
                $form->reset();
                $module  = $this->getRequest()->getModuleName();
                $controller = $this->getRequest()->getControllerName();
                $action = $this->getRequest()->getActionName();
                if($module && $controller && $action)
                    $this->redirect($module.'/'.$controller.'/list');
            }
        }
        $this->view->form = $form;
    }
    
    public function editAction() {  
        if ($this->getRequest()->isPost()) {
            $request = $this->getRequest()->getPost();       
            $this->_setPassPrice($request);
            $form = $this->_getForm();
            $form->removeUneditableElements();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            
            if($form->isValid($request)) {
                $data = $form->getValues();
                if(!$this->_isValid($data, $message)) {
                    $this->view->message = $message;
                    $this->view->success = false;
                    $this->view->form = $form;
                    return;
                }
                $splitData = $this->_handleAfterSubmit($data);
                $data['pass_id'] = $this->getRequest()->getParam('id');                   
                $result = false;
                if($this->getModel()->updatePass($data)) {
                    $result = true;
                    $pricing = new Model_PassPricings();
                    if($result && !$pricing->savePricing($data['pass_id'], $splitData['countryPrice'])) {
                        $result = false;
                    }
                }
                if (!$result) {
                    $this->view->message = "An error has occured while saving";
                    $this->view->success = true;
                } else {
                    // for making message page specific
                    $cdnPurgeData  = $this->getModel()->buildCdnPurgeData($data['pass_id'],'All Season Pass Modified');
                    $objCdn = new Model_CdnPurgeLog();
                    if(!empty($cdnPurgeData))
                    $objCdn->InsertCdnPurgeLog($cdnPurgeData);
                    $this->view->message = ucwords($this->getRequest()->getControllerName())." Data successfully updated";
                    $this->view->success = false;
                }
                $this->_redirect('/admin/pass/list');
            }
        }    
        elseif($passId = $this->getRequest()->getParam('id')) {            
            $passModel = new Model_Pass($passId);
            if(!$passModel->toArray()) {
                $this->_redirect('/admin/pass/list');
            }
            
            $session = new Zend_Session_Namespace('form'); 
            
            $priceData = $this->_preparePricing($passId);
            $this->_setPassPrice($priceData);  
            
            $this->view->postParams = $passModel;            
            
            $form = $this->_getForm();
            $form->removeUneditableElements();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            
            $form->setDefaults($passModel->toArray());            
        }
        else {
            $this->_redirect('/admin/pass/list');
        }
        $this->view->form = $form;
    }
    
    private function _handleAfterSubmit(&$request) {
        $returnData = array(
            'countryPrice' => array()
        );
        
        if(isset($request['countryPrice'])) {
            unset($request['countryPrice']['__template__']);
            $counter = 0;
            foreach($request['countryPrice'] as $elementKey => $data) {                
                $returnData['countryPrice'][$counter] = array(
                    'currency_id' => $data['currency_id'],
                    'discount' => $data['discount']
                );
                if($data['country_id']) {
                    $returnData['countryPrice'][$counter]['country_id'] = $data['country_id'];
                }
                if($data['cluster_id']) {
                    $returnData['countryPrice'][$counter]['cluster_id'] = $data['cluster_id'];
                }
                $returnData['countryPrice'][$counter]['price'] = $data['price'];
                $counter++;
            }            
            unset($request['countryPrice']);
        }   
        return $returnData;
    }
    
    private function _setPassPrice(&$request) {
        $session = new Zend_Session_Namespace('form'); 
        if(isset($request['countryPrice']) && count($request['countryPrice'])) {
            $request['countryPrice'] = $this->_updateFirstElement($request['countryPrice']);        
            $session->countryPrice = array_keys($request['countryPrice']);
            array_unshift($session->countryPrice, '__template__');
            $session->countryPriceData =  $request['countryPrice'];
        }
        else {
            $session->countryPrice = array('__template__', 'new');
            $session->countryPriceData = array();
        }  
    }
    
    private function _updateFirstElement($elementArray) {
        $keys = array_keys( $elementArray );
        $keys[ array_search( '0', $keys ) ] = 'new';
        return array_combine( $keys, $elementArray );    
    } 
    
    public function _isValid($data, &$message) { 
        $countryList = array();
        $clusterList = array();
        foreach($data['countryPrice'] as $elementKey => $dataSingle) {
            if($elementKey == '__template__') {
                continue;
            }
            if((!isset($dataSingle['cluster_id']) && !isset($dataSingle['country_id'])) 
                    || (!$dataSingle['cluster_id'] && !$dataSingle['country_id'])) {
                $message = "location missing for price";
                return false;
            }
            
            foreach($dataSingle as $fieldName => $fieldValue) {
                if(!preg_match("/price/", $fieldName)) {
                    continue;
                }
                if(!is_numeric($fieldValue) && !is_float($fieldValue)) {
                    $message = "Invalid price provided";
                    return false;
                }
            }
            if(isset($dataSingle['country_id']) && $dataSingle['country_id']) {
                if(in_array($dataSingle['country_id'], $countryList)) {
                    $message = "Same location selected multiple times";
                    return false;
                }    
                $countryList[] = $dataSingle['country_id'];
            }
            if(isset($dataSingle['cluster_id']) && $dataSingle['cluster_id']) {
                if(in_array($dataSingle['cluster_id'], $clusterList)) {
                    $message = "Same location selected multiple times";
                    return false;
                }    
                $clusterList[] = $dataSingle['cluster_id'];
            }
        }
        unset($countryList);
        unset($clusterList);
        return true;
    }
    
    private function _preparePricing($passId) {
        $priceModel = new Model_PassPricings();
        $countryPrice = array();
        
        foreach($priceModel->getByPassId($passId) as $index => $data) {                        
            if($data['country_id']) {
                $countryPrice[$index]['location_mode'] = 2;                                                
            } 
            else {
                $countryPrice[$index]['location_mode'] = 1;
            }
            
            $countryPrice[$index]['country_id'] = $data['country_id'];
            $countryPrice[$index]['cluster_id'] = $data['cluster_id'];
            $countryPrice[$index]['currency_id'] = $data['currency_id'];
            $countryPrice[$index]['discount'] = $data['discount'];            
            $countryPrice[$index]['price'] = $data['price'];            
        }
        return array(
            'countryPrice' => $countryPrice
        );
    }
    
    public function listAction() {
        $this->_helper->viewRenderer->setRender('common/list')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $table = $this->getModel()->getName();
        $filterForm = new Form_Filters($table);
        $requestData = array();
        $queryParamsArr = array();
        $page = '';
        if($this->getRequest()->isPost()){
            $filterForm->populate($this->getRequest()->getPost());
            $page = 1;
            $requestData = $filterForm->getValues();
            foreach($requestData as $elementName => $elementValue) {
                if(!empty($elementValue)){
                    $queryData = $filterForm->getElement($elementName)->getAttrib('data-table');
                    $queryData['searchValue'] = $elementValue;
                    $this->queryBuilder($queryData);
                    $queryParamsArr[$queryData['search_id']] = $elementValue;    
                }
            }
        }
        if(empty($page)){
            $page = $this->view->navigatorPage;
            $page = (int)$this->getRequest()->getParam('page');
        }
        $orderby = $this->getModel()->getPk() . ' DESC';
        if(empty($this->_queryParams)){
            $getData = $this->getRequest()->getQuery();
            unset($getData['page']);
            if(!empty($getData)){
                foreach ($getData as $key => $value) {
                    $queryParamsArr[$key] = $value;
                    $returnData = $filterForm->getSearchFields($key);
                    if(!empty($returnData)){
                        $returnData = $returnData[0];
                        $filterForm->getElement($returnData['searchColumnName'])->setValue($value);
                        $returnData['searchValue'] = $value;
                        $this->queryBuilder($returnData);
                    }
                }
            }
        }
        if ($page <= 1) {
            $this->view->firstpage = true;
            $page = 1;
        } else {
            $this->view->firstpage = false;
        }
        $offset = ($page - 1) * self::ROWS_PER_PAGE;
        $limit = array(self::ROWS_PER_PAGE,$offset);
        $this->view->page = $page;
        $model = $this->getModel();
        $data = $model->fetchAll($this->_queryParams, array('order' => array($orderby), 'limit' => $limit));
        $perPageData = count($data);
        $total = $model->fetchCount($this->_queryParams);
        if (count($data) < self::ROWS_PER_PAGE) {
            $this->view->lastpage = true;
        } else {
            $this->view->lastpage = false;
        }
        $numberOfPages = ceil($total / self::ROWS_PER_PAGE);
        if($page < $numberOfPages){
            $this->view->currentPageRecord = self::ROWS_PER_PAGE * $page;    
        }else{
            $this->view->currentPageRecord = $total;    
        }
        $this->view->diffPageRecord = $this->view->currentPageRecord - self::ROWS_PER_PAGE;
        if(count($data) < self::ROWS_PER_PAGE){
            $this->view->diffPageRecord = $total - count($data);
        }

        $this->view->totalCount = $total;
        $this->view->totalPages = $numberOfPages;
        $this->view->lastPage = $numberOfPages;
        $pk = $model->getPk();
        //@TODO: Remove from controller and create an action helper.
        foreach ($data as &$row) {
            $row['Action'] = "<a href='" . $this->view->url(array('action' => 'view', 'id' => $row[$pk])) . "'>View</a> " . "<a href='" . $this->view->url(array('controller' => 'changelog', 'action' => 'index', 'row' => $row[$pk], 'table' => $table)) . "'>ChangeLog</a> " .
                    "<a href='" . $this->view->url(array('action' => 'edit', 'id' => $row[$pk])) . "'>Edit</a> " ./*
                    "<a class='delete-crud-item' href='#' onclick='deleteConfirmShow(\"" . $this->view->url(array('action' => 'delete', 'id' => $row[$pk])) . "\");'>Delete</a> " . */
                "<a href='" . $this->view->url(array('module' => 'admin', 'controller' => 'pass', 'action' => 'list-price', 'id' => $row[$pk]),null,true) . "' target='_blank'>View Price</a> ";
        }
        //================
        if(isset($data[0])){
            $original = array_keys($data[0]);
        }else{
            $original = array();
        }
        $as = ($this->_displayInDataTable);
        //new datatable   
        //need to define path in ini file after discussion
        $datatableFilePath = '../../library/BaseApp/Datatable/'.ucfirst($table).'.php';       
        if(file_exists($datatableFilePath)) {
            $dataTableClass = 'BaseApp_Datatable_'.ucfirst($table);               
        }
        else{
            $dataTableClass = 'BaseApp_Datatable_Default';                            
        }
        $dataTable = new $dataTableClass;
        $dataTable->setData($data);
        $this->view->queryParams = http_build_query($queryParamsArr);
        $this->view->form = $filterForm;
        $this->view->data = $dataTable;
        $this->view->original = $original;
        $this->view->displayInDataTable = $as;
        $this->view->navigatorTotal = ceil($total / BACKEND_ROWS_PER_PAGE);
    }
    
    public function deleteAction() {
        $this->_helper->viewRenderer->setRender('common/delete')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $id = $this->getRequest()->getParam('id');
        
        $dataDelete = $this->getModel($id);        
        if(!$dataDelete->toArray()) {
            $this->view->message = "Invalid Pass";
            $this->view->success = false;
            return;
        }
        //delete course
        if(!$this->getModel()->deletePass($id, $message)) {
            $this->view->message = $message;
            $this->view->success = false;
            return;
        }        
        $this->_redirect("/admin/pass/list");
    }    
    
    public function listPriceAction() {
        $page = $this->view->navigatorPage;

        $model = new Model_PassPricings();
        $orderby = $model->getPk() . ' DESC';
        $page = (int)$this->getRequest()->getParam('page');
        if ($page <= 1) {
            $this->view->firstpage = true;
            $page = 1;
        } else {
            $this->view->firstpage = false;
        }
        $offset = ($page - 1) * self::ROWS_PER_PAGE;   
        $limit = array(self::ROWS_PER_PAGE,$offset);
        $this->view->page = $page;
        
        $conds = array();
        if($this->getRequest()->getParam('id')) {
            $conds = array(
                'pass_id=?' => $this->getRequest()->getParam('id')
            );
        }
        $data = $model->fetchAll($conds, array('order' => array($orderby), 'limit' => $limit));
        if (count($data) < self::ROWS_PER_PAGE) {
            $this->view->lastpage = true;
        } else {
            $this->view->lastpage = false;
        }
        $total = $model->fetchCount();
        $pk = $model->getPk();
        $table = $model->getName();
        if(isset($data[0])){
            $original = array_keys($data[0]);
        }else{
            $original = array();
        }
        $as = ($this->_displayInDataTable);
        //new datatable   
        //need to define path in ini file after discussion
        $datatableFilePath = '../../library/BaseApp/Datatable/'.ucfirst($table).'.php';       
        if(file_exists($datatableFilePath)) {
            $dataTableClass = 'BaseApp_Datatable_'.ucfirst($table);               
        }
        else{
            $dataTableClass = 'BaseApp_Datatable_Default';                            
        }

        $dataTable = new $dataTableClass;
        $dataTable->setData($data);

        $this->view->data = $dataTable;
        //------
        //$this->view->data = $data;
        $this->view->original = $original;
        $this->view->displayInDataTable = $as;
        $this->view->navigatorTotal = ceil($total / BACKEND_ROWS_PER_PAGE);
    }
}
