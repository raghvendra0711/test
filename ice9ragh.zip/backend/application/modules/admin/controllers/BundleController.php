<?php

/*
 * Contains the CRUD actions of Exams table
 *
 */

class Admin_BundleController extends BaseApp_Controller_Crud {

    CONST STR_MODIFIED = 'Seo Url Does Not Exist to Convert Again ( Already Converted Only Price can be Edited)';

    protected $_model = 'Model_Bundles';
    protected $_descriptions = array(
        'list' => 'List of Existing Bundles',
        'index' => 'List of Existing Bundles',
        'add' => 'Add New Bundles',
        'edit' => 'Make the required changes then click on "Save" to update the Bundles',
        'view' => 'View Selected Bundles'
    );
    protected $_certificateData = array(
        'certificateFeature' => array(
            0 => array('header_text' => 'Earn your certificate', 'short_description' => 'Our Masters program is exhaustive and this certificate is proof that you have taken a big leap in mastering the domain.'),
            1 => array('header_text' => 'Differentiate yourself with a Masters Certificate', 'short_description' => "The knowledge and skills you've gained working on projects, simulations, case studies will set you ahead of competition."),
            2 => array('header_text' => 'Share your achievement', 'short_description' => "Talk about it on Linkedin, Twitter, Facebook, boost your resume or frame it - tell your friends and colleagues about it.")
        )
    );
    protected function _getForm($bundleId = false) {
        $form = new Form_Bundles($bundleId);
        return $form;
    }

    public function addAction() {

        $request = $this->getRequest()->getPost();
        //$this->_setAccessDays($request);
        // $sectionTitle = isset($request['section_title']) ? $request['section_title'] : '';
        //$this->_setCountryPrice($request); //pending
        $this->_setCountrySubscriptionPrice($request); //pending
        //$this->_setKeyFeatures($request);
        // $this->_setBundleFaq($request);
        $this->_setCertificate($request,true);
        //$this->_setCourseDirectors($request);
        // $this->_setAboutBundle($request);
        //Add : Load Bundle Tools
        // $this->_setBundleTools($request);

        // fetch enterprise list
        $groupsObj = new Model_Groups();
        $this->view->enterpriseList = json_encode($groupsObj->getEnterpriseList());
        $request = array_merge_recursive($request, $_FILES);
        if (!$this->_add)
            $this->forward('list');
        $form = $this->_getForm();
        if ($form === false)
            throw new Zend_Exception('_getForm not implemented');
        $form->removeVideoElements();
        if ($request && $form->isValid($request)) {
            $request = $form->getValues();
            $imageData = array();
            $data = $form->getValues();
            unset($request['course_id_tmp']);
            unset($request['course_or_tmp']);
            unset($request['cluster_id_bundle_tmp']);
            //get selected courses for a bundle
            if (!empty($request['course_id']))
                $coursesSel = explode(',', $request['course_id']);
            //get selected alternate courses for a bundle
            if (!empty($request['course_or_id']))
                $coursesSelAlt = explode(',', $request['course_or_id']);
            //move alternate course to step 1 if course on same step is empty
            if (!empty($coursesSelAlt)) {
                foreach ($coursesSelAlt as $key => $courseIdAlt) {
                    if (empty($coursesSel[$key])) {
                        if ($courseIdAlt != 0)
                            $coursesSel[$key] = $courseIdAlt;
                        unset($coursesSelAlt[$key]);
                    }
                }
            }
            if (!empty($coursesSel))
                $request['course_id'] = implode(',', $coursesSel);
            if (!empty($coursesSelAlt))
                $request['course_id'] = $request['course_id'] . ',' . implode(',', $coursesSelAlt);
            if (isset($request['course_or_id']))
                unset($request['course_or_id']);
            $electives = $request['bundle_electives'];
            if (!empty($request['bundle_electives']))
                $request['course_id'] = $request['course_id'] . ',' . $request['bundle_electives'];
            if ($request['course_id'] != '')
                $request['course_id'] = implode(',', array_filter(array_unique(explode(',', $request['course_id']))));
            unset($request['bundle_electives_keys']);
            unset($request['bundle_elec_md5']);
            unset($request['bundle_electives']);
            unset($request['bundle_electives_temp']);
            unset($request['trusted_by_err']);
            unset($request['course_advisor_err']);
            unset($request['alumni_err']);
            unset($request['bundle_tool_err']);
            if (!$this->_isValid($request, $message)) {
                $this->view->message = $message;
                $this->view->success = false;
                $this->view->form = $form;
                return;
            }
            $uniMapping = new Model_University();
            if(!empty($request['university'])){
                 $univerity = $uniMapping->getUniversityContent($request['university']);
                 $univerityName = $univerity['name'];
            }

            if(!empty($request['courseToolsFeatureSortedList'])) {
                $toolList = explode(",", $request['courseToolsFeatureSortedList']);
            }
            unset($request['courseToolsFeature']);
            unset($request['courseToolsFeatureSortedList']);
            
            $videoData = array();
            if(!empty($request['videoLink'])) {
                $vData = $form->getVideoData();
                if(!empty($vData) && is_array($vData)){
                $videoData['videoDescription'] = isset($vData['shortDescription']) ? $vData['shortDescription'] : NULL;
                $videoData['dateCreated'] = isset($vData['dateCreated']) ? $vData['dateCreated'] : NULL;
                $videoData['duration'] = isset($vData['duration']) ? $vData['duration'] : NULL;
                $videoData['displayName'] = isset($vData['displayName']) ? $vData['displayName'] : $request['display_name'];
                }                
                $videoData['videoLink'] = $request['videoLink'];
                $videoData['videoThumbnail'] = !empty($request['videoThumbnail']) ? $request['videoThumbnail']: "";
            }
            unset($request['dateCreated']);
            unset($request['duration']);
            unset($request['videoLink']);
            unset($request['videoThumbnail']);
            unset($request['videoDescription']);
            $splitData = $this->_handleDataAfterSubmit($request);
            if (isset($request['master_type']) && $request['master_type'] != BaseApp_Dao_Bundles::MASTER_TYPE_CLASSIC) {
                $splitData['certificateFeature'] = array();
                $splitData['certificate_data'] = array();
            }
            if (!$request['partialView']) {
                if (!empty($request['certificate_header_text'])) {
                    if (empty($splitData['certificateFeature']['new']['header_text']) || empty($splitData['certificateFeature']['new']['short_description'])) {
                        $this->view->message = 'Certifcate Sub Headers and Text cannot be Empty';
                        $this->view->success = false;
                        $this->view->form = $form;
                        return;
                    }
                }
            }

            $agencyList = array();
            if(isset($request['enterprise_list_bundle'])) {
                $enterpriseCourseMappingArr = explode(",",$request['enterprise_list_bundle']);
                $agencyList = $enterpriseCourseMappingArr;
                if($request['bundle_available_for'] == 'private_b2b' && $request['enterprise_list_bundle'] == '') {
                    $this->view->message = "Please select at least one Enterprise for Private B2B";
                    $this->view->success = false;
                    $form->getElement('enterprise_list_bundle')->setErrors(array("Please select at least one Enterprise for Private B2B"));
                    $this->view->form = $form;
                    return false;
                }
                
                unset($request['enterprise_list_bundle']);
            }

            /**
             * Add : Bundle Accreditors Primary & Secondary
            */
            $bundleAccreditors = array();
            /**
             * Validation Of Bundle Accreditors
             */
            if (!empty($request['primary_accreditor_label'])) {
                $isAccreditorLabelValid = $form->validateAcceditorLabel('Primary Accreditor',$request['primary_accreditor_label']);
                if(!empty($isAccreditorLabelValid) && !$isAccreditorLabelValid['isValid']) {
                    $errMsg = $isAccreditorLabelValid['message'];
                    $form->getElement('primary_accreditor_label')->setErrors(array($errMsg));
                    $this->view->success = false;
                    $this->view->form = $form;
                    return;
                } 
            }
            if(!empty($request['primary_accreditor_label']) && empty($request['primary_accreditor_logo'])){
                $form->getElement('primary_accreditor_logo')->setErrors(array("Primary logo cannot be Empty if Primary Accreditor Text is added."));
                $this->view->success = false;
                $this->view->form = $form;
                return;
            }
            if(empty($request['primary_accreditor_label']) && !empty($request['primary_accreditor_logo'])){
                $form->getElement('primary_accreditor_label')->setErrors(array("Primary Accreditor cannot be Empty if Primary logo is added."));
                $this->view->success = false;
                $this->view->form = $form;
                return;
            }
            if (!empty($request['secondary_accreditor_label'])) {
                $isAccreditorLabelValid = $form->validateAcceditorLabel('Secondary Accreditor',$request['secondary_accreditor_label']);
                if(!empty($isAccreditorLabelValid) && !$isAccreditorLabelValid['isValid']) {
                    $errMsg = $isAccreditorLabelValid['message'];
                    $form->getElement('secondary_accreditor_label')->setErrors(array($errMsg));
                    $this->view->success = false;
                    $this->view->form = $form;
                    return;
                } 
            }
            if(!empty($request['secondary_accreditor_label']) && empty($request['secondary_accreditor_logo'])){
                $form->getElement('secondary_accreditor_logo')->setErrors(array("Secondary logo cannot be Empty if Secondary Accreditor Text is added."));
                $this->view->success = false;
                $this->view->form = $form;
                return;
            }
            if(empty($request['secondary_accreditor_label']) && !empty($request['secondary_accreditor_logo'])){
                $form->getElement('secondary_accreditor_label')->setErrors(array("Secondary Accreditor cannot be Empty if Secondary logo is added."));
                $this->view->success = false;
                $this->view->form = $form;
                return;
            }
            if (!empty($request['primary_accreditor_logo'])) {
                $accreditorIds = $request['primary_accreditor_logo'];
                $bundleAccreditors['primary'] = array('accreditorsId' => $accreditorIds, 'label' => $request['primary_accreditor_label']);
            }
            $overview = '';
            if(!empty($request['program_overview'])){
                $overview = $request['program_overview'];
            }

            $programDetails = '';
            if(!empty($request['program_details_intro'])){
                $programDetails = $request['program_details_intro'];
            }

            if(!empty($request['university'])){
                $universityIds[] = $request['university']; 
             }

            unset($request['primary_accreditor_logo']);
            unset($request['primary_accreditor_label']);
            unset($request['university']);
            if (!empty($request['secondary_accreditor_logo'])) {
                $accreditorIds = $request['secondary_accreditor_logo'];
                $bundleAccreditors['secondary'] = array('accreditorsId' => $accreditorIds, 'label' => $request['secondary_accreditor_label']);
            }
            unset($request['secondary_accreditor_logo']);
            unset($request['secondary_accreditor_label']);
            // End of bundle accreditor
            //Bundle Category Name
            $bundleCategoryName='';
            if (isset($request['categoryLabelName'])) {
                if (!empty($request['categoryLabelName'])) {
                    $bundleCategoryName = trim($request['categoryLabelName']);
                }
            }
            if (isset($_FILES['banner_image']['name']) && $_FILES['banner_image']['name'] != '') {
                    
                $fileName = $_FILES['banner_image']['name'];
                $absFilePath = sys_get_temp_dir().DIRECTORY_SEPARATOR.$fileName; //sys_get_temp_dir().DIRECTORY_SEPARATOR.$fileName;                            
                //$absFilePath = $_FILES['image_url']['tmp_name'];                           
                $s3path = AWS_S3_IMAGES_PATH . '/banners';
                $bannerImgUrl = BaseApp_Utility_ImageProcessing::transformAndUploadToS3($absFilePath, $fileName, $s3path); 
                if (isset($bannerImgUrl)) {
                    array_push($imageData, array(
                        'name' => 'banner_image',
                        'imagePath' => $bannerImgUrl,
                    ));
                }
                                          
            }
            if (isset($_FILES['tumbnail_image']['name']) && $_FILES['tumbnail_image']['name'] != '') {
                $fileName = $_FILES['tumbnail_image']['name'];
                $absFilePath = sys_get_temp_dir().DIRECTORY_SEPARATOR.$fileName; //sys_get_temp_dir().DIRECTORY_SEPARATOR.$fileName;                            
                //$absFilePath = $_FILES['image_url']['tmp_name'];                           
                $s3path = AWS_S3_IMAGES_PATH . '/banners';
                $tumbnailImgUrl = BaseApp_Utility_ImageProcessing::transformAndUploadToS3($absFilePath, $fileName, $s3path);
                if (isset($tumbnailImgUrl)) {
                    array_push($imageData, array(
                        'name' => 'tumbnail_image',
                        'imagePath' => $tumbnailImgUrl,
                    ));
                }                       
                
            }
            if (isset($_FILES['home_page_tumbnail_image']['name']) && $_FILES['home_page_tumbnail_image']['name'] != '') {
                $fileName = $_FILES['home_page_tumbnail_image']['name'];
                $absFilePath = sys_get_temp_dir().DIRECTORY_SEPARATOR.$fileName; //sys_get_temp_dir().DIRECTORY_SEPARATOR.$fileName;                            
                //$absFilePath = $_FILES['image_url']['tmp_name'];                           
                $s3path = AWS_S3_IMAGES_PATH . '/banners';
                $homepageTumbImgUrl = BaseApp_Utility_ImageProcessing::transformAndUploadToS3($absFilePath, $fileName, $s3path);     
                if (isset($homepageTumbImgUrl)) {
                    array_push($imageData, array(
                        'name' => 'home_page_tumbnail_image',
                        'imagePath' => $homepageTumbImgUrl,
                    ));
                }                      
            }

            unset($request['categoryLabelName']);
            unset($request['currentBundleName']);
            unset($request['oldCategoryLabelID']);
            unset($request['oldhideFromSearch']);
            unset($request['program_overview']);
            unset($request['program_details_intro']);
            $introText = $request['description'];
            unset($request['description']);
            unset($request['projectTitleSectionIdOverview']);
            unset($request['projectTitleSectionIdDetails']);
            unset($request['banner_image']);
            unset($request['tumbnail_image']);
            unset($request['home_page_tumbnail_image']);
            unset($request['banner_image_value']);
            unset($request['tumbnail_image_value']);
            unset($request['home_page_tumbnail_image_value']);
            unset($request['banner_image_old']);
            unset($request['tumbnail_image_old']);
            unset($request['home_page_tumbnail_image_old']);


            $result = false;
            unset($request['old_bundle_available_for']);

                $request['job_assist_for_ind'] =  !empty($data['job_assist_for_ind']) ? $data['job_assist_for_ind'] : 0; 

            if ($bundleId = $this->getModel()->createBundle($request)) {
                if(!empty($overview)){
                    $param['bundleId'] = $bundleId;
                    $param['sectionType'] = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLE_OVERVIEW_TITLE;
                    $overviewText = !empty($overview) ? $overview : '';
                    $this->handleBundleProjectSectionData($overviewText,'',$param);  
                 }

                 if(!empty($programDetails)){
                     $param['bundleId'] = $bundleId;
                     $param['sectionType'] = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLE_DETAILS_TITLE;
                     $programDetailsText = !empty($programDetails) ? $programDetails : '';
                     $this->handleBundleProjectSectionData($programDetailsText,'',$param);
                     
                 }
                try {
                    // b2b update based on course available for
                    $availableForData = array('old' => array(), 'new' => array());
                    $availableForData['old']['availableFor'] = '';
                    $availableForData['old']['agencies'] = array();
                    $availableForData['new']['availableFor'] = !empty($request['bundle_available_for']) ? $request['bundle_available_for']: '';
                    $availableForData['new']['agencies'] = $agencyList;
                    $b2bHelper = new Helper_B2bHelper();
                    $b2bHelper->processAvaliableForChange(BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES, $bundleId, $availableForData);
                } catch (Exception $e) {
                    file_put_contents(APPLICATION_PATH . '/../error.log', "\n[" .date('Y-m-d H:i:s'). '] ERROR: bundle processAvaliableForChange failed ' . $e->getMessage(), FILE_APPEND);
                    if (APPLICATION_ENV != 'production') throw $e;
                }

                $seoData = array('course_intro_text' => $introText);
                $this->_saveSeoData($bundleId, $seoData, $request['master_type']);
                $result = true;
                $sfParams = array();
                // Sync Product (Bundle Id ) To Sdfc
                if (ctype_digit($bundleId) && !empty($request['name'])) {
                    $nonFoucusBundle=!empty($request['hideFromSearch']) ? $request['hideFromSearch'] : 0;
                    $sfParams['productId'] = (int) $bundleId;
                    $sfParams['productName'] = $request['name'];
                    $sfParams['productType'] = 'bundle';
                    $sfParams['isUniversityProgram'] = $request['master_type']==BaseApp_Dao_Bundles::MASTER_TYPE_UNIVERSITY ? $request['master_type']: "0";
                    $sfParams['universityName'] = $request['master_type']==BaseApp_Dao_Bundles::MASTER_TYPE_UNIVERSITY && !empty($univerityName) ? $univerityName: '';
                    $sfParams['productCategoryId'] = !empty($request['primary_label_id']) ? (int) $request['primary_label_id']:0;
                    $sfParams['productCategoryName'] = !empty($bundleCategoryName) ? $bundleCategoryName : '';
                    $sfParams['nonFocusBundle']=$nonFoucusBundle;
                    $sfParams['product_available_for'] = !empty($request['bundle_available_for']) ? $request['bundle_available_for']: '';
                    $sfParams['action'] = 'add';
                    $salsesforceApi = new BaseApp_Communication_SalesforceApi();
                    $salsesforceApi->SfdcPoductSync($sfParams);
                }
                if (!empty($videoData)) {
                    // add or edit bundle intro video
                    $objVideos = new Model_Videos();
                    $videosArr = array(
                        'linkable_id' => $bundleId,
                        'linkable_type' => 'bundle',
                        'name' => 'about_bundle',
                        'videoLink' => $videoData['videoLink'],
                        'thumbnailImage' => $videoData['videoThumbnail'],
                        'training_id' => BaseApp_Dao_TrainingTypes::TYPE_ELEARNING
                    );
                    if(isset($videoData['videoDescription']) && $videoData['videoDescription']){
                        $videosArr['shortDescription'] = $videoData['videoDescription'];
                    }
                    if (isset($videoData['dateCreated']) && $videoData['dateCreated']) {
                        $videosArr['dateCreated'] = $videoData['dateCreated'];
                    }
                    if(isset($videoData['displayName']) && $videoData['displayName']){
                        $videosArr['displayName'] = $videoData['displayName'];
                    }
                    if(isset($videoData['duration']) && $videoData['duration']){
                        $videosArr['duration'] = $videoData['duration'];
                    }

                    $objVideos->clean();
                    $resultInsert = $objVideos->setFromArray($videosArr)->save();
                    if ($resultInsert) {
                        $this->_saveVideoSeo($objVideos->video_id, $bundleId, $videoData['videoThumbnail']);
                    }
                }

                //deleted pricing

                $tags = new Model_Tags();
                if ($result && !$tags->saveTags($bundleId, 'bundle', $splitData['searchTags'])) {
                    $result = false;
                }

                /* $features = new Model_KeyFeatures();
                if ($result && !$features->saveFeature($bundleId, 'bundle', $splitData['keyFeatures'])) {
                    $result = false;
                } */
             if($request['master_type']==BaseApp_Dao_Bundles::MASTER_TYPE_CLASSIC){
                if(!empty($request['job_assist_for_ind'])){
                    $objCourseFaq = new Model_CourseFaq();
                    $faqArr = $objCourseFaq->checkJobAssistForIndia($request['bundle_tmp_id'], 1);
                    if(empty($faqArr)){
                        $dataToSave[]= array(
                            'cluster_id'=>0,
                            'country_id'=>INDIA_COUNTRY_ID,
                            'course_faq_id'=>'',
                            'question' =>'Get noticed by the top hiring companies',
                            'answer'=>'True',
                            'linkable_id'=>$bundleId,
                            'linkable_type'=>Model_CourseInclusions::LINKABLE_TYPE_BUNDLE,
                            'is_b2c'=>1,
                            'is_b2b'=>0,
                        );
                        $objCourseFaq->addCourseContent($dataToSave,1,$bundleId,0,null,false,'bundle');
                    }else{
                        if(!$faqArr['crmStatus']){
                            $courseFaqId = array(
                                'course_faq_id' => $faqArr['course_faq_id'],
                            );
                            $faqData = array('content_ids' => array($courseFaqId));
                            $faqData['linkable_id'] = $request['bundle_tmp_id'];
                            $faqData['linkable_type'] = Model_CourseInclusions::LINKABLE_TYPE_BUNDLE;
                            $faqData['cluster_id'] = 0;
                            $faqData['country_id'] = INDIA_COUNTRY_ID;
                            $faqData['city_id'] = 0;
                            $crmStatus = !$request['job_assist_for_ind'];
                            $objCourseFaq->disableCourseFaq($faqData, 1,$crmStatus);
                        }
                    }

                }
            }
                $objProductRepo = new Model_ProductRepo();
                if ($result && !$objProductRepo->saveData($bundleId, 'bundle', 'promotional', $splitData['promotional_data'])) {
                    $result = false;
                }

                $certficateSeedData = array_merge($splitData['certificate_data'], $splitData['certificateFeature']);
                if ($result && !$objProductRepo->saveData($bundleId, 'bundle', 'certificate', $certficateSeedData)) {
                    $result = false;
                }

                
                $splitData['imageData'] = array_merge($splitData['imageData'],$imageData);

                $objSectionMapping = new Model_SectionMapping();
                $sectionMappingArr = array();
                if (!empty($splitData['section_id_arr'])) {
                    $status = true;
                    $sectionMappingArr = $splitData['section_id_arr'];
                    $sectionMappingArr = call_user_func_array('array_merge', $sectionMappingArr);
                    if (!$objSectionMapping->saveProductSectionData($bundleId, 'bundle', $sectionMappingArr,"","","",$status))
                        $result = false;
                }
                unset($splitData['section_id_arr']);
                
                if (!empty($splitData['course_advisor_section_id_arr'])) {
                    $status = true;
                    $sectionMappingArr = $splitData['course_advisor_section_id_arr'];
                    $sectionMappingArr = call_user_func_array('array_merge', $sectionMappingArr);
                    if (!$objSectionMapping->saveProductSectionData($bundleId, 'bundle', $sectionMappingArr, null, Model_SectionMapping::HAS_ORDER_TRUE,'directors', $status))
                        $result = false;
                }
                unset($splitData['course_advisor_section_id_arr']);

                $image = new Model_Images();
                foreach ($splitData['imageData'] as $imageData) {
                    if ($result && !$image->saveImageByName($bundleId, 'bundle', $imageData)) {
                        $result = false;
                    }
                }
                $userDetails = BaseApp_Auth::getLoggedInUserData();
                //add-edit-update bundle electives
                if (!empty($electives)) {
                    $electivesObj = new Model_CourseMapping;
                    $_b_id = $bundleId;


                    $electives = explode(',', $electives);
                    $created_by = $userDetails['id'];
                    $e_size = count($electives);
                    if ($e_size > 1) {
                        for ($e = 0; $e < $e_size; $e++) {
                            $electivesObj->saveBundleElectives($_b_id, $electives[$e], $e + 1, $created_by);
                        }
                    } else {
                        $electivesObj->saveBundleElectives($_b_id, $electives[0], 1, $created_by);
                    }
                }
                // save courses selected for a bundle
                if (!empty($coursesSelAlt) || !empty($coursesSel)) {
                    $_b_id = $bundleId;
                    $courseMappingObj = new Model_CourseMapping();
                    // add main courses
                    if (!empty($coursesSel)) {
                        foreach ($coursesSel as $key => $courseId) {
                            $data = array(
                                'linkable_id' => $_b_id,
                                'product_id' => $courseId,
                                'stepNo' => $key + 1,
                                'seq' => 1,
                                'created_by' => $userDetails['id']
                            );
                            $saveCourseMapping = $courseMappingObj->saveBundleCourses($data);
                        }
                    }
                    //add alternate courses
                    if (!empty($coursesSelAlt)) {
                        foreach ($coursesSelAlt as $key => $courseId) {
                            $data = array(
                                'linkable_id' => $_b_id,
                                'product_id' => $courseId,
                                'stepNo' => $key + 1,
                                'seq' => 2,
                                'created_by' => $userDetails['id']
                            );
                            $saveCourseMapping = $courseMappingObj->saveBundleCourses($data);
                        }
                    }
                }
                 /**
                 * Bundle Tool-removed category logic
                 */
                $this->_modifyTools($objSectionMapping, $bundleId, $toolList);

                /**
                 * Bundle Accreditors Save
                 */
                if(!empty($bundleAccreditors)){
                        $parameter = array('bundleId' => $bundleId, 'bundleAccreditors' => $bundleAccreditors);
                        $this->bundleAccreditors($parameter);
                }
                
                if(!empty($universityIds)){
                    $parameter = array('bundleId' => $bundleId, 'bundleUniversity' => $universityIds);
                    $this->bundleUniversityMapping($parameter);
                }

                // save the enterprise mapping for this bundle
                // update enterprise course mapping data in cloud6 api
                if(isset($enterpriseCourseMappingArr)) {
                    $enterpriseCourseData = array(
                        'entity_type' => ENTITY_TYPE_FOR_ENTERPRISE_BUNDLE_MAPPING, // bundle
                        'entity_id' =>  $bundleId,
                        'group_ids' => $enterpriseCourseMappingArr,
                    );
                    $groupsObj = new Model_Groups();
                    $resp = $groupsObj->setEnterpriseList($enterpriseCourseData);
                }
            }
            if (!$result) {
                $this->view->message = "An error has occured while saving";
                $this->view->success = true;
            } else {
                if ($request['payment_type_id'] == BaseApp_Dao_PaymentType::ONETIME_PAYMENT_TYPE_ID)
                    $action = 'New Bundle Got Added';
                elseif ($request['payment_type_id'] == BaseApp_Dao_PaymentType::SUBSCRIPTION_PAYMENT_TYPE_ID)
                    $action = ' New Subscription Got Added';
                $cdnPurgeData = $this->getModel()->buildCdnPurgeData($bundleId, $request['name'] . $action);
                $objCdn = new Model_CdnPurgeLog();
                if (!empty($cdnPurgeData))
                    $objCdn->InsertCdnPurgeLog($cdnPurgeData);
                $this->view->message = "Data successfully added";
                $this->view->success = false;
                $form->reset();
                    $partialView = !empty($request['partialView']) ? $request['partialView'] : 0;
                $this->_redirect("/admin/bundle/bundle-indetail/id/{$bundleId}?partialView={$partialView}");            }
        } else {
            $form->getElement('certificate_header_text')->setValue("Get Ahead with Simplilearn's Master Certificate");
        }
        $this->view->form = $form;
    }
    private function _modifyTools($objSectionMapping, $bundleId, $toolList) {
        if (!empty($toolList)) {
            $sectionMappingArr = $toolList;
            $objSectionMapping->saveProductSectionData($bundleId, BaseApp_Dao_ProductSectionData::LINKABLE_TYPE_BUNDLE, $sectionMappingArr, null, true, BaseApp_Dao_ProductSectionData::SECTION_TYPE_COURSE_TOOLS);
        } else {
            $objSectionMapping->removeProductMappingBySection($bundleId, BaseApp_Dao_ProductSectionData::LINKABLE_TYPE_BUNDLE, BaseApp_Dao_ProductSectionData::SECTION_TYPE_COURSE_TOOLS);
        }
    }

    public function handleBundleProjectSectionData($title = '', $projectTitleSectionId, $parameter = array())
    {
      
        $productId = $parameter['bundleId'];
       
        $sectionType = $parameter['sectionType'];
      
        $objProductSectionData = new Model_ProductSectionData();
        $projectTitle = htmlspecialchars(trim($title));
        $projectTitle = htmlentities($projectTitle, ENT_COMPAT, 'utf-8');
        $projectTitle = preg_replace("/[^ \w]+/", "", $projectTitle);
        $param['bundle_id_arr'] = array($productId);
        $param['sectionType'] = $sectionType;
        $param['sectionTitle'] = '';
        $param['description'] = $projectTitle;
        if (!empty($projectTitleSectionId)) {
          
            if (empty($title)) {
                $linkableId = $projectTitleSectionId;
                $linkableType = $sectionType;
                $objProductSectionData->updateToolProductSectionData($linkableId, $linkableType);
                $objSectionMapping = new Model_SectionMapping();
                $updateStatus = $objSectionMapping->disableSecMapBySectionId($productId, BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES, $linkableId);
            } else {
              
                $objProductSectionData->updatedPSBundleData($projectTitleSectionId, $param);
            }
        } else {
            if (!empty($title)) {
              
                $objProductSectionData->saveProductSectionData($param);
            }
        }
    }



    private function _getSeoData($bundleId, $masterType) {
        //$controller = $isBundleUniversityMaster ? BaseApp_Dao_Bundles::SEO_DEFAULT_CONTROLLER_UNIVERSITY_MASTER : BaseApp_Dao_Bundles::SEO_DEFAULT_CONTROLLER;
        switch($masterType){
            case BaseApp_Dao_Bundles::MASTER_TYPE_UNIVERSITY : 
                $controller = BaseApp_Dao_Bundles::SEO_DEFAULT_CONTROLLER_UNIVERSITY_MASTER;
                break;
            case BaseApp_Dao_Bundles::MASTER_TYPE_COHORT : 
                $controller = BaseApp_Dao_Bundles::SEO_DEFAULT_CONTROLLER_COHORT_MASTER;
                break;
            default:
                $controller = BaseApp_Dao_Bundles::SEO_DEFAULT_CONTROLLER;
                break;
        }
        $modelSeo = new Model_Seo();
        $seoData = $modelSeo->getDataByType($bundleId, BaseApp_Dao_Bundles::SEO_DEFAULT_LINKABLE_TYPE, $controller, BaseApp_Dao_Bundles::SEO_DEFAULT_ACTION);
        return empty($seoData['seo_id'])?array():$seoData;
    }
    private function _getSeoId($bundleId, $masterType) {
        $seoData = $this->_getSeoData($bundleId, $masterType);
        return empty($seoData['seo_id'])?null:$seoData['seo_id'];
    }

    private function _saveSeoData($bundleId, $dataSave, $masterType) {
        $updateStatus = false;
        try {
            $modelSeo = new Model_Seo();
            $id = $this->_getSeoId($bundleId, $masterType);
            if (!empty($id) && !empty($dataSave)) {
                $modelSeo->setId($id);
                if ($modelSeo->setFromArray($dataSave)->update()) {
                    $updateStatus = true;
                }
            }
        } catch (Exception $e) {
            $updateStatus = false;
        }
        return $updateStatus;
    }

    private function _saveVideoSeo($videoId, $labelId, $thumbIMage) {
        $return = false;

        $url = sprintf("/resources/bundle-%d-videos/about-bundle-rrt%d", $labelId, $videoId);

        $seoMd = new Model_Seo();
        $conds = array(
            'controller=?' => Model_Videos::SEO_DEFAULT_CONTROLLER,
            'action=?' => Model_Videos::SEO_DEFAULT_ACTION,
            'linkable_id=?' => $videoId,
            'linkable_type=?' => 'video'
        );
        if ($seoData = current($seoMd->fetchAll($conds, array(), false))) {
            $dataSave = array(
                'url' => $url,
                'thumb_image' => $thumbIMage
            );
            $seoMd->clean();
            $seoMd->setId($seoData['seo_id']);
            $seoMd->setFromArray($dataSave)->update();
            $return = true;
        } else {
            $dataSave = array(
                'url' => $url,
                'thumb_image' => $thumbIMage,
                'controller' => Model_Videos::SEO_DEFAULT_CONTROLLER,
                'action' => Model_Videos::SEO_DEFAULT_ACTION,
                'params' => json_encode(array(Model_Videos::SEO_DEFAULT_PARAM_KEY => $videoId)),
                'linkable_id' => $videoId,
                'linkable_type' => 'video'
            );
            $return = $seoMd->setFromArray($dataSave)->save();
        }
        return $return;
    }

    public function editAction() {
       
        $this->view->bundleId = $this->getRequest()->getParam('id');
        
        if ($this->getRequest()->isPost()) {
            $request = $this->getRequest()->getPost();
            
            //$sectionTitle = isset($request['section_title']) ? $request['section_title'] : '';
            // $this->_setAccessDays($request);
            // $this->_setCountryPrice($request); //pending
            $this->_setCountrySubscriptionPrice($request); //pending
            // $this->_setBundleFaq($request);
            $this->_setCertificate($request);
            // $this->_setAboutBundle($request);
            //$this->_setCourseDirectors($request);
            //Edit : Set bundle Tool
            // $this->_setBundleTools($request);
            
            $form = $this->_getForm($this->view->bundleId);
            $request = array_merge_recursive($request, $_FILES);
            $form->removeUneditableElements();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            if ($form->isValid($request)) {
                $data = $form->getValues();
                $imageData = array();

                //get university name 
                $uniMapping = new Model_University();
                if(!empty($data['university'])){
                     $univerity = $uniMapping->getUniversityContent($data['university']);
                     $univerityName = $univerity['name'];
                }



                $isProductSyncRequired = false;
                $sfParams=array();
                
                $bundleId = $this->getRequest()->getParam('id');
                $objBundle = new Model_Bundles($bundleId);
                $bundleData = $objBundle->toArray();
                
                //$isBundleUniversityMaster = $objBundle->isUniversityMaster;
                $masterType = $objBundle->master_type;
                //$masterType = $data["master_type"];
                
                $introText = $data['description'];
                $seoData = array('course_intro_text' => $introText);
                
                $this->_saveSeoData($bundleId, $seoData, $masterType);
                if (isset($_FILES['banner_image']['name']) && $_FILES['banner_image']['name'] != '') {
                    
                    $fileName = $_FILES['banner_image']['name'];
                    $absFilePath = sys_get_temp_dir().DIRECTORY_SEPARATOR.$fileName; //sys_get_temp_dir().DIRECTORY_SEPARATOR.$fileName;                            
                    //$absFilePath = $_FILES['image_url']['tmp_name'];                           
                    $s3path = AWS_S3_IMAGES_PATH . '/banners';
                    $bannerImgUrl = BaseApp_Utility_ImageProcessing::transformAndUploadToS3($absFilePath, $fileName, $s3path); 
                    if (isset($bannerImgUrl)) {
                        array_push($imageData, array(
                            'name' => 'banner_image',
                            'imagePath' => $bannerImgUrl,
                            // 'linkable_id' => $bundleId,
                            // 'linkable_type' => 'bundle',
                        ));
                    }
                                              
                }
                if (isset($_FILES['tumbnail_image']['name']) && $_FILES['tumbnail_image']['name'] != '') {
                    $fileName = $_FILES['tumbnail_image']['name'];
                    $absFilePath = sys_get_temp_dir().DIRECTORY_SEPARATOR.$fileName; //sys_get_temp_dir().DIRECTORY_SEPARATOR.$fileName;                            
                    //$absFilePath = $_FILES['image_url']['tmp_name'];                           
                    $s3path = AWS_S3_IMAGES_PATH . '/banners';
                    $tumbnailImgUrl = BaseApp_Utility_ImageProcessing::transformAndUploadToS3($absFilePath, $fileName, $s3path);
                    if (isset($tumbnailImgUrl)) {
                        array_push($imageData, array(
                            'name' => 'tumbnail_image',
                            'imagePath' => $tumbnailImgUrl,
                            // 'linkable_id' => $bundleId,
                            // 'linkable_type' => 'bundle',
                        ));
                    }                       
                    
                }
                if (isset($_FILES['home_page_tumbnail_image']['name']) && $_FILES['home_page_tumbnail_image']['name'] != '') {
                    $fileName = $_FILES['home_page_tumbnail_image']['name'];
                    $absFilePath = sys_get_temp_dir().DIRECTORY_SEPARATOR.$fileName; //sys_get_temp_dir().DIRECTORY_SEPARATOR.$fileName;                            
                    //$absFilePath = $_FILES['image_url']['tmp_name'];                           
                    $s3path = AWS_S3_IMAGES_PATH . '/banners';
                    $homepageTumbImgUrl = BaseApp_Utility_ImageProcessing::transformAndUploadToS3($absFilePath, $fileName, $s3path);     
                    if (isset($homepageTumbImgUrl)) {
                        array_push($imageData, array(
                            'name' => 'home_page_tumbnail_image',
                            'imagePath' => $homepageTumbImgUrl,
                            // 'linkable_id' => $bundleId,
                            // 'linkable_type' => 'bundle',
                        ));
                    }                      
                }

                $overview = $data['program_overview'];
                $programDetails = $data['program_details_intro'];
                unset($data['program_overview']);
                unset($data['program_details_intro']);
                unset($data['projectTitleSectionIdOverview']);
                unset($data['projectTitleSectionIdDetails']);
                $isClassic = false;
                // Update controller and params in SEO table on the basis of university master condition
                switch($data["master_type"]){
                    case BaseApp_Dao_Bundles::MASTER_TYPE_UNIVERSITY : 
                        $universityMasterBasedSEOData = [
                            'controller' => BaseApp_Dao_Bundles::SEO_DEFAULT_CONTROLLER_UNIVERSITY_MASTER,
                            'params' => (json_encode(["purdue_masters_id" => (int) $bundleId]))
                        ];
                        break;
                    case BaseApp_Dao_Bundles::MASTER_TYPE_COHORT :
                        $universityMasterBasedSEOData = [
                            'controller' => BaseApp_Dao_Bundles::SEO_DEFAULT_CONTROLLER_COHORT_MASTER,
                            'params' => (json_encode(["bundle_id" => (int) $bundleId]))
                        ];
                        break;
                    default:
                        $isClassic = true;
                        $universityMasterBasedSEOData = [
                            'controller' => BaseApp_Dao_Bundles::SEO_DEFAULT_CONTROLLER,
                            'params' => (json_encode(["bundle_id" => (int) $bundleId]))
                        ];
                        break;
                }
                $this->_saveSeoData($bundleId, $universityMasterBasedSEOData, $masterType);

                unset($data['description']);
                unset($data['program_details_intro']);
                unset($data['course_id_tmp']);
                unset($data['course_or_tmp']);
                unset($data['cluster_id_bundle_tmp']);
                unset($data['course_advisor_sort_list']);
                $electives = $data['bundle_electives'];
                //get selected courses for a bundle
                $coursesSel = explode(',', $data['course_id']);
                //get selected alternate courses for a bundle
                $coursesSelAlt = explode(',', $data['course_or_id']);
                //move alternate course to step 1 if course on same step is empty
                foreach ($coursesSelAlt as $key => $courseIdAlt) {
                    if (empty($coursesSel[$key])) {
                        if ($courseIdAlt != 0)
                            $coursesSel[$key] = $courseIdAlt;
                        unset($coursesSelAlt[$key]);
                    }
                }
                $data['bundle_id'] = $bundleId;

                $groupsObj = new Model_Groups();
                $this->view->enterpriseList = json_encode($groupsObj->getEnterpriseList());
                // fetch mapped enterprise list data
                $this->view->enterprisePrePopulateList = '[]';
                $oldAgencies = array();
                if($data['bundle_id']) {
                    // $groupsObj = new Model_Groups();
                    $prePopulateParams = array('entity_type' => ENTITY_TYPE_FOR_ENTERPRISE_BUNDLE_MAPPING, 'entity_id' => $data['bundle_id'], 'status' => 1);
                    $res = $groupsObj->getPrePolulateEnterpriseList($prePopulateParams);

                    if(empty($res)) {
                        $this->view->enterprisePrePopulateList = '[]';
                    } else {
                        $oldAgencies = array_map(function($temp){return $temp['id'];} , $res);
                        $this->view->enterprisePrePopulateList = json_encode($res);
                    }
                }

                if(isset($data['enterprise_list_bundle'])) {
                    $enterpriseCourseMappingArr = explode(",", $data['enterprise_list_bundle']);
                    
                    if($data['bundle_available_for'] == 'private_b2b' && $data['enterprise_list_bundle'] == '') {
                        $this->view->message = "Please select at least one Enterprise for Private B2B";
                        $this->view->success = false;
                        $form->getElement('enterprise_list_bundle')->setErrors(array("Please select at least one Enterprise for Private B2B"));
                        $this->view->form = $form;
                        return false;
                    }
                    
                    unset($data['enterprise_list_bundle']);
                }
 
                try {
                    // b2b update based on course available for
                    $availableForData = array('old' => array(), 'new' => array());
                    $availableForData['old']['availableFor'] = !empty($request['old_bundle_available_for']) ? $request['old_bundle_available_for']: '';;
                    $availableForData['old']['agencies'] = $oldAgencies;
                    $availableForData['new']['availableFor'] = !empty($request['bundle_available_for']) ? $request['bundle_available_for']: '';
                    $availableForData['new']['agencies'] = empty($enterpriseCourseMappingArr) ? array() : $enterpriseCourseMappingArr;
                    $b2bHelper = new Helper_B2bHelper();
                    $b2bHelper->processAvaliableForChange(BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES, $bundleId, $availableForData);
                } catch (Exception $e) {
                    file_put_contents(APPLICATION_PATH . '/../error.log', "\n[" .date('Y-m-d H:i:s'). '] ERROR: bundle processAvaliableForChange failed ' . $e->getMessage(), FILE_APPEND);
                    if (APPLICATION_ENV != 'production') throw $e;
                }
                unset($request['old_bundle_available_for']);

                
                
                $objProductSectionData = new Model_ProductSectionData();
                // $form = $this->_getForm();

                $pTitleDataOverview = $this->_getCourseProjectsTitle($objProductSectionData,$data['bundle_id'],BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES,BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLE_OVERVIEW_TITLE);
               
                $pTitleDataDetails = $this->_getCourseProjectsTitle($objProductSectionData,$data['bundle_id'],BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES,BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLE_DETAILS_TITLE);
              
                $addtionalContentData = array();
                $addtionalContentData['projectTitleSectionIdOverview'] = !empty($pTitleDataOverview['section_id'])?$pTitleDataOverview['section_id']:'';
                $addtionalContentData['projectTitleSectionIdDetails'] = !empty($pTitleDataDetails['section_id'])?$pTitleDataDetails['section_id']:'';
               
                if ($form === false)
                    throw new Zend_Exception('_getForm not implemented');
                $form->setDefaults($addtionalContentData);
               
                $projectTitleSectionIdOverview = !empty($form->getValue('projectTitleSectionIdOverview')) ? $form->getValue('projectTitleSectionIdOverview') : '';
                
                $projectTitleSectionIdDetails = !empty($form->getValue('projectTitleSectionIdDetails')) ? $form->getValue('projectTitleSectionIdDetails') : '';
              
                if(!empty($data['bundle_id'])){
                    $param['bundleId'] = $data['bundle_id'];
                    $overviewData = $overview;
                    $param['sectionType'] = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLE_OVERVIEW_TITLE;
                  
                    $this->handleBundleProjectSectionData($overviewData,$projectTitleSectionIdOverview,$param);  
                 }

                 if(!empty($data['bundle_id'])){
                    $param['bundleId'] = $data['bundle_id'];
                    $programDetailsData = $programDetails;
                    $param['sectionType'] = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLE_DETAILS_TITLE;
                    $this->handleBundleProjectSectionData($programDetailsData,$projectTitleSectionIdDetails,$param);  
                 }

                


                
                // donot allow all course access bundle to be edited
                if (!empty($data['bundle_id']) && $data['bundle_id'] == 46)
                    throw new Zend_Exception('All course access bundle is not editable.');

                if ($data['videoLink']) {
                    // add or edit course intro video
                    $objVideos = new Model_Videos();
                    $vData = $form->getVideoData();
                    $videoData = array();
                    if(!empty($vData) && is_array($vData)){
                    $videoData['videoDescription'] = isset($vData['shortDescription']) ? $vData['shortDescription'] : NULL;
                    $videoData['dateCreated'] = isset($vData['dateCreated']) ? $vData['dateCreated'] : NULL;
                    $videoData['duration'] = isset($vData['duration']) ? $vData['duration'] : NULL;
                    $videoData['displayName'] = isset($vData['displayName']) ? $vData['displayName'] : $request['display_name'];
                    }
                    $videosArr = array(
                        'linkable_id' => $data['bundle_id'],
                        'linkable_type' => 'bundle',
                        'name' => 'about_bundle',
                        'videoLink' => $data['videoLink'],
                        'thumbnailImage' =>  !empty($data['videoThumbnail']) ? $data['videoThumbnail']: "",                   
                        'training_id' => BaseApp_Dao_TrainingTypes::TYPE_ELEARNING
                    );
                    if(isset($videoData['videoDescription']) && $videoData['videoDescription']){
                        $videosArr['shortDescription'] = $videoData['videoDescription'];
                    }
                    if (isset($videoData['dateCreated']) && $videoData['dateCreated']) {
                        $videosArr['dateCreated'] = $videoData['dateCreated'];
                    }
                    if(isset($videoData['displayName']) && $videoData['displayName']){
                        $videosArr['displayName'] = $videoData['displayName'];
                    }
                    if(isset($videoData['duration']) && $videoData['duration']){
                        $videosArr['duration'] = $videoData['duration'];
                    }
                    if ($videoExists = $objVideos->getByLinkableId($data['bundle_id'], 'bundle', BaseApp_Dao_TrainingTypes::TYPE_ELEARNING, 'about_bundle')) {
                        $videosArr['video_id'] = $videoExists['video_id'];

                        $objVideos->clean();
                        $objVideos->setId($videosArr['video_id']);
                        $resultUpdate = $objVideos->setFromArray($videosArr)->update();
                        $this->_saveVideoSeo($videosArr['video_id'], $data['bundle_id'], $data['videoThumbnail']);
                    } else {
                        $objVideos->clean();
                        $resultInsert = $objVideos->setFromArray($videosArr)->save();
                        if ($resultInsert) {
                            $this->_saveVideoSeo($objVideos->video_id, $data['bundle_id'], $data['videoThumbnail']);
                        }
                    }
                } else {
                    // Delete course intro video
                    $objVideos = new Model_Videos();
                    $objVideos->deleteVideo($data['bundle_id'], 'bundle', BaseApp_Dao_TrainingTypes::TYPE_ELEARNING, 'about_bundle');
                }

                // save the enterprise mapping for this bundle
                // update enterprise course mapping data in cloud6 api
                if(isset($enterpriseCourseMappingArr)) {
                    $enterpriseCourseData = array(
                        'entity_type' => ENTITY_TYPE_FOR_ENTERPRISE_BUNDLE_MAPPING, // bundle
                        'entity_id' =>  $data['bundle_id'],
                        'group_ids' => $enterpriseCourseMappingArr,
                    );
                    
                    $groupsObj = new Model_Groups();
                    $resp = $groupsObj->setEnterpriseList($enterpriseCourseData);
                }
               

                unset($data['dateCreated']);
                unset($data['duration']);
                unset($data['videoLink']);
                unset($data['videoThumbnail']);
                unset($data['videoDescription']);
                if (!empty($coursesSel))
                    $data['course_id'] = implode(',', $coursesSel);
                if (!empty($coursesSelAlt))
                    $data['course_id'] = $data['course_id'] . ',' . implode(',', $coursesSelAlt);
                unset($data['course_or_id']);
                if (!empty($electives))
                    $data['course_id'] = $data['course_id'] . ',' . $electives;
                if (!empty($data['course_id']))
                    $data['course_id'] = implode(',', array_filter(array_unique(explode(',', $data['course_id']))));
                $bundle_electives_keys = $data['bundle_electives_keys'];
                $bundle_elec_md5 = $data['bundle_elec_md5'];
                unset($data['bundle_electives_keys']);
                unset($data['bundle_elec_md5']);
                unset($data['bundle_electives']);
                unset($data['bundle_electives_temp']);
                unset($data['trusted_by_err']);
                unset($data['course_advisor_err']);
                unset($data['alumni_err']);
                unset($data['bundle_tool_err']);
                if (!$this->_isValid($data, $message)) {
                    $this->view->message = $message;
                    $this->view->success = false;
                    $this->view->form = $form;
                    return;
                }


                // $objBundle = new Model_Bundles($data['bundle_id']);
                // $bundleData = $objBundle->toArray();
                if (!empty($bundleData['modified_bundle_id'])) {
                    if ($bundleData['payment_type_id'] == BaseApp_Dao_PaymentType::SUBSCRIPTION_PAYMENT_TYPE_ID && $bundleData['payment_type_id'] != $data['payment_type_id']) {
                        $this->view->message = 'Subscription already Converted into Bundle..Cannot Convert it again';
                        $this->view->success = false;
                        $form->getElement('payment_type_id')->setErrors(array("Subscription already Converted into Bundle..Cannot Convert it again"));
                        $this->view->form = $form;
                        return;
                    }
                }
                $splitData = $this->_handleDataAfterSubmit($data);
                //Edit : Bundle Tool -removed category logic.
                if (!empty($data['courseToolsFeatureSortedList'])) {
                    $toolList = explode(",", $data['courseToolsFeatureSortedList']);
                }
                unset($data['courseToolsFeature']);
                unset($data['courseToolsFeatureSortedList']);

                //Edit : Bundle Accreditors Primary & Secondary
                $bundleAccreditors = array();
                
                /**
                 * Validation Of Bundle Accreditors 
                 */
                
                if (!empty($data['primary_accreditor_label'])) {
                    $isAccreditorLabelValid = $form->validateAcceditorLabel('Primary Accreditor',$data['primary_accreditor_label']);
                    if (!empty($isAccreditorLabelValid) && !$isAccreditorLabelValid['isValid']) {
                        $errMsg = $isAccreditorLabelValid['message'];
                        $form->getElement('primary_accreditor_label')->setErrors(array($errMsg));
                        $this->view->success = false;
                        $this->view->form = $form;
                        return;
                    }
                }
                if (!empty($data['primary_accreditor_label']) && empty($data['primary_accreditor_logo'])) {
                    $form->getElement('primary_accreditor_logo')->setErrors(array("Primary Accreditors cannot be Empty"));
                    $this->view->success = false;
                    $this->view->form = $form;
                    return;
                }
                if (empty($data['primary_accreditor_label']) && !empty($data['primary_accreditor_logo'])) {
                    $form->getElement('primary_accreditor_label')->setErrors(array("Primary Accreditor cannot be Empty if Primary logo is added."));
                    $this->view->success = false;
                    $this->view->form = $form;
                    return;
                }
                
                 if (!empty($data['secondary_accreditor_label'])) {
                    $isAccreditorLabelValid = $form->validateAcceditorLabel('Secondary Accreditor',$data['secondary_accreditor_label']);
                    if (!empty($isAccreditorLabelValid) && !$isAccreditorLabelValid['isValid']) {
                        $errMsg = $isAccreditorLabelValid['message'];
                        $form->getElement('secondary_accreditor_label')->setErrors(array($errMsg));
                        $this->view->success = false;
                        $this->view->form = $form;
                        return;
                    }
                }
                if (!empty($data['secondary_accreditor_label']) && empty($data['secondary_accreditor_logo'])) {
                    $form->getElement('secondary_accreditor_logo')->setErrors(array("Secondary Accreditors cannot be Empty"));
                    $this->view->success = false;
                    $this->view->form = $form;
                    return;
                }
                if (empty($data['secondary_accreditor_label']) && !empty($data['secondary_accreditor_logo'])) {
                    $form->getElement('secondary_accreditor_label')->setErrors(array("Secondary Accreditors cannot be Empty"));
                    $this->view->success = false;
                    $this->view->form = $form;
                    return;
                }
                //Primary
                if(!empty($data['primary_accreditor_logo'])){
                    $accreditorIds = $data['primary_accreditor_logo']; 
                    $bundleAccreditors['primary'] = array('accreditorsId'=>$accreditorIds,'label'=>$data['primary_accreditor_label']);
                }
                //university id
                if(!empty($data['university'])){
                    $universityIds[] = $data['university']; 
                }
                unset($data['primary_accreditor_logo']);
                unset($data['primary_accreditor_label']);
                unset($data['university']);
                //Secondary 
                if(!empty($data['secondary_accreditor_logo'])){
                    $accreditorIds = $data['secondary_accreditor_logo']; 
                    $bundleAccreditors['secondary'] = array('accreditorsId'=>$accreditorIds,'label'=>$data['secondary_accreditor_label']);
                }
                unset($data['secondary_accreditor_logo']);
                unset($data['secondary_accreditor_label']);
                // End of bundle accreditor 
                if (!$data['partialView']) {
                    if (!empty($data['certificate_header_text'])) {
                        if (empty($splitData['certificateFeature']['new']['header_text']) || empty($splitData['certificateFeature']['new']['short_description'])) {
                            $this->view->message = 'Certifcate Sub Headers and Text cannot be Empty';
                            $this->view->success = false;
                            $this->view->form = $form;
                            return;
                        }
                    }
                }
                if (isset($data['oldCategoryLabelID'])) {
                    if (!empty($data['oldCategoryLabelID']) && $data['oldCategoryLabelID'] !== $data['primary_label_id']) {
                        $isProductSyncRequired = true;
                        $bundleCategoryName = trim($data['categoryLabelName']);
                        $productId = $data['bundle_id'];;
                        $productType = 'bundle';
                        $productCategoryId = (int) $data['primary_label_id'];
                        $productCategoryName = $bundleCategoryName;
                        $action = 'mapping';
                        $params = array(
                            'productId' => $productId, 
                            'productCategoryId' => $productCategoryId, 
                            'productCategoryName' => $productCategoryName, 
                            'productType' => $productType, 
                            'action' => $action
                        );
                        $sfParams[] = $params;
                    }
                }

                if (isset($data['currentBundleName'], $data['master_type'])) {
                    if ((
                            !empty($data['currentBundleName']) 
                            && strcmp(strtolower($data['currentBundleName']), strtolower($data['name'])) !== 0
                        ) 
                        || ($bundleData['master_type'] != $data['master_type'] || $bundleData['university_name'] != $univerityName)
                        || ($bundleData['bundle_available_for'] != $data['bundle_available_for'])
                    ) {

                        if (!empty($data['bundle_id']) && !empty($data['name'])) {
                            $isProductSyncRequired = true;
                            $productId = $data['bundle_id'];
                            $productName = $data['name'];
                            $nonFoucusBundle=!empty($data['hideFromSearch']) ? $data['hideFromSearch'] : 0;
                            $action = 'edit';
                            //$isUniversityMaster = $data['isUniversityMaster'] ? $data['isUniversityMaster']: "0";
                            $isUniversityMaster = $data['master_type']==BaseApp_Dao_Bundles::MASTER_TYPE_UNIVERSITY ? $data['master_type']: "0";
                            $universityName = $data['master_type']==BaseApp_Dao_Bundles::MASTER_TYPE_UNIVERSITY && !empty($univerityName) ? $univerityName: '';
                            $product_available_for = !empty($data['bundle_available_for']) ? $data['bundle_available_for'] : '';
                            $productType = 'bundle';
                            $params = array(
                                'productId' => $productId, 
                                'productName' => $productName, 
                                'productType' => $productType,
                                'nonFocusBundle'=>$nonFoucusBundle ,
                                'isUniversityProgram'=> $isUniversityMaster,
                                'universityName'=> $universityName,
                                'product_available_for' => $product_available_for,
                                'action' => $action
                            );
                            $sfParams[] = $params;
                        }
                    }
                }
                if (isset($data['hideFromSearch'])) {
                    if ($data['oldhideFromSearch'] !== $data['hideFromSearch']) {
                        $isProductSyncRequired = true;
                        $productId = $data['bundle_id'];
                        $productName = $data['name'];
                        $nonFoucusBundle = !empty($data['hideFromSearch']) ? $data['hideFromSearch'] : 0;
                        $action = 'edit';
                        //$isUniversityMaster = $data['isUniversityMaster'] ? $data['isUniversityMaster']: "0";
                        $isUniversityMaster = $data['master_type']==BaseApp_Dao_Bundles::MASTER_TYPE_UNIVERSITY ? $data['master_type']: "0";
                        $universityName = $data['master_type']==BaseApp_Dao_Bundles::MASTER_TYPE_UNIVERSITY && !empty($univerityName) ? $univerityName: '';
                        $product_available_for = !empty($data['bundle_available_for']) ? $data['bundle_available_for'] : '';
                        $productType = 'bundle';
                        $params = array(
                            'productId' => $productId, 
                            'productName' => $productName, 
                            'productType' => $productType, 
                            'nonFocusBundle' => $nonFoucusBundle, 
                            'isUniversityProgram'=> $isUniversityMaster,
                            'universityName'=> $universityName,
                            'product_available_for' => $product_available_for,
                            'action' => $action
                        );
                        $sfParams[] = $params;
                    }
                }
                unset($data['oldhideFromSearch']);
                unset($data['oldCategoryLabelID']);
                unset($data['currentBundleName']);
                unset($data['categoryLabelName']);
                unset($data['banner_image']);
                unset($data['tumbnail_image']);
                unset($data['home_page_tumbnail_image']);
                unset($data['old_bundle_available_for']);
                unset($data['banner_image_value']);
                unset($data['tumbnail_image_value']);
                unset($data['home_page_tumbnail_image_value']);
                unset($data['banner_image_old']);
                unset($data['tumbnail_image_old']);
                unset($data['home_page_tumbnail_image_old']);
                $result = false;
                
                $data['job_assist_for_ind'] = !empty($request['job_assist_for_ind']) ? $request['job_assist_for_ind'] : 0;
                if ($bundleData['payment_type_id'] == BaseApp_Dao_PaymentType::SUBSCRIPTION_PAYMENT_TYPE_ID && $bundleData['payment_type_id'] != $data['payment_type_id']) {
                    if ($bundleId = $this->getModel()->convertBundleToSub($data)) {
                        $data['bundle_id'] = $bundleId;
                        $result = true;
                    }
                } else {
                    if ($this->getModel()->updateBundle($data))
                        $result = true;
                }
                if ($result == true) {
                    // SFDC Product Sync On bundle name and category mapping changed.
                    if ($isProductSyncRequired && is_array($sfParams) && !empty($sfParams)) {
                        $salsesforceApi = new BaseApp_Communication_SalesforceApi();
                        foreach ($sfParams as $param):
                           $response = $salsesforceApi->SfdcPoductSync($param);
                        endforeach;
                    }
                    // Bundle Tool category Edit
                    $toolSectionBundleId =$data['bundle_id'];
                    //deleted price
                    $tags = new Model_Tags();
                    if ($result && !$tags->saveTags($data['bundle_id'], 'bundle', $splitData['searchTags'])) {
                        $result = false;
                    }

                    $objCourseFaq = new Model_CourseFaq();
                if($request['master_type']==BaseApp_Dao_Bundles::MASTER_TYPE_CLASSIC){
                    if(!empty($request['job_assist_for_ind'])){
                        $faqArr = $objCourseFaq->checkJobAssistForIndia($request['bundle_tmp_id'], 1);
                        if(empty($faqArr)){
                            $dataToSave[]= array(
                                'cluster_id'=>0,
                                'country_id'=>INDIA_COUNTRY_ID,
                                'course_faq_id'=>'',
                                'question' =>'Get noticed by the top hiring companies',
                                'answer'=>'True',
                                'linkable_id'=>$request['bundle_tmp_id'],
                                'linkable_type'=>Model_CourseInclusions::LINKABLE_TYPE_BUNDLE,
                                'is_b2c'=>1,
                                'is_b2b'=>0,
                            );
                            $objCourseFaq->addCourseContent($dataToSave,1,$request['bundle_tmp_id'],0,null,false,'bundle');
                        }else{
                            if(empty($faqArr['crmStatus'])){
                                $courseFaqId = array(
                                    'course_faq_id' => $faqArr['course_faq_id'],
                                );
                                $faqData = array('content_ids' => array($courseFaqId));
                                $faqData['linkable_id'] = $request['bundle_tmp_id'];
                                $faqData['linkable_type'] = Model_CourseInclusions::LINKABLE_TYPE_BUNDLE;
                                $faqData['cluster_id'] = 0;
                                $faqData['country_id'] = INDIA_COUNTRY_ID;
                                $faqData['city_id'] = 0;
                                $crmStatus = !$request['job_assist_for_ind'];
                                $objCourseFaq->disableCourseFaq($faqData, 1,$crmStatus);
                            }
                        }
                    }else{
                        $faqArr = $objCourseFaq->checkJobAssistForIndia($request['bundle_tmp_id'], 1);
                        if(!empty($faqArr)){
                            // $objCourseFaq->inclusionDelete($faqId);
                            $courseFaqId = array(
                                'course_faq_id' => $faqArr['course_faq_id'],
                            );
                            $faqData = array('content_ids' => array($courseFaqId));
                            $faqData['linkable_id'] = $request['bundle_tmp_id'];
                            $faqData['linkable_type'] = Model_CourseInclusions::LINKABLE_TYPE_BUNDLE;
                            $faqData['cluster_id'] = 0;
                            $faqData['country_id'] = INDIA_COUNTRY_ID;
                            $faqData['city_id'] = 0;
                            $crmStatus = !$request['job_assist_for_ind'];
                            $objCourseFaq->disableCourseFaq($faqData, 1,$crmStatus);
                        }   
                    }
                }

                    $objProductRepo = new Model_ProductRepo();
                    if ($result && !$objProductRepo->saveData($data['bundle_id'], 'bundle', 'promotional', $splitData['promotional_data'])) {
                        $result = false;
                    }
                    $hardWrite=0;
                    if($data['master_type']==BaseApp_Dao_Bundles::MASTER_TYPE_COHORT){
                        $hardWrite = 1;
                    }

                    $certficateSeedData = array_merge($splitData['certificate_data'], $splitData['certificateFeature']);
                    if (!empty($isClassic)) {
                        if ($result && !$objProductRepo->saveData($data['bundle_id'], 'bundle', 'certificate', $certficateSeedData, $hardWrite)) {
                            $result = false;
                        }
                    }
                    $objSectionMapping = new Model_SectionMapping();
                    $sectionMappingArr = array();
                    if (!empty($splitData['section_id_arr'])) {
                        $sectionMappingArr = $splitData['section_id_arr'];
                        $sectionMappingArr = call_user_func_array('array_merge', $sectionMappingArr);
                        $objSectionMapping->saveProductSectionData($data['bundle_id'], 'bundle', $sectionMappingArr,'','','',true);
                    }
                    unset($splitData['section_id_arr']);
                    
                    if (!empty($splitData['course_advisor_section_id_arr'])) {
                        $sectionMappingArr = $splitData['course_advisor_section_id_arr'];
                        $sectionMappingArr = call_user_func_array('array_merge', $sectionMappingArr);
                        $objSectionMapping->saveProductSectionData($data['bundle_id'], 'bundle', $sectionMappingArr, null, Model_SectionMapping::HAS_ORDER_TRUE,'directors',true);
                    }
                    unset($splitData['course_advisor_section_id_arr']);
                    $splitData['imageData'] = array_merge($splitData['imageData'],$imageData);
                    $image = new Model_Images();
                    foreach ($splitData['imageData'] as $imageData) {
                        if ($result && !$image->saveImageByName($data['bundle_id'], 'bundle', $imageData)) {
                            $result = false;
                        }
                    }
                    // delete subscription logo if bundle converted from subscription
                    if ($data['payment_type_id'] == BaseApp_Dao_PaymentType::ONETIME_PAYMENT_TYPE_ID && !$image->deleteByLinkableAndName($data['bundle_id'], 'bundle', 'subscription_logo')) {
                        $result = false;
                    }
                    $userDetails = BaseApp_Auth::getLoggedInUserData();

                    //add-edit-update bundle electives
                    if (!empty($electives) || !empty($bundle_electives_keys)) {
                        $electivesObj = new Model_CourseMapping;
                        $_b_id = $data['bundle_id'];

                        if (md5($electives) != $bundle_elec_md5) {
                            $_ids = array_filter(explode(",", $bundle_electives_keys));
                            $electivesObj->deleteBundleMappingById($_ids);
                            $electives = array_filter(explode(',', $electives));
                            $created_by = $userDetails['id'];
                            $e_size = count($electives);
                            if ($e_size > 1) {
                                for ($e = 0; $e < $e_size; $e++) {
                                    $electivesObj->saveBundleElectives($_b_id, $electives[$e], $e + 1, $created_by);
                                }
                            } elseif ($e_size == 1) {
                                $electivesObj->saveBundleElectives($_b_id, $electives[0], 1, $created_by);
                            }
                        }
                    }
                    // save courses selected for a bundle
                    if (!empty($coursesSelAlt) || !empty($coursesSel)) {
                        $_b_id = $data['bundle_id'];
                        $courseMappingObj = new Model_CourseMapping;
                        $bCourses = $courseMappingObj->getBundleCourses($_b_id);
                        $bundleCoursesData = array();

                        if (count($bCourses))
                            $bundleCoursesData = array_column($bCourses, 'product_id', 'id');
                        $delIds = array();
                        foreach ($bundleCoursesData as $id => $courseId) {
                            $key = -1;
                            if ($courseId == 0) {
                                $key = array_search($id, array_column($bCourses, 'id'));
                                if (!empty($bCourses[$key]) && empty($coursesSel[$bCourses[$key]['stepNo']]))
                                    $delIds[] = $id;
                            } else if (!in_array($courseId, $coursesSelAlt) && !in_array($courseId, $coursesSel))
                                $delIds[] = $id;
                        }
                        // delete not existing ids
                        if (!empty($delIds)) {
                            $courseMappingObj->deleteBundleMappingById($delIds);
                        }

                        // add main courses
                        if (!empty($coursesSel)) {
                            foreach ($coursesSel as $key => $courseId) {
                                $data = array(
                                    'linkable_id' => $_b_id,
                                    'product_id' => $courseId,
                                    'stepNo' => $key + 1,
                                    'seq' => 1
                                );
                                $userId = $userDetails['id'];
                                if (in_array($courseId, $bundleCoursesData)) {
                                    $data['id'] = array_search($courseId, $bundleCoursesData);
                                    unset($bundleCoursesData[$data['id']]);
                                    $data['modified_by'] = $userId;
                                    $data['modifiedDate'] = date('Y-m-d H:i:s');
                                } else {
                                    $data['created_by'] = $userId;
                                }
                                $saveCourseMapping = $courseMappingObj->saveBundleCourses($data);
                            }
                        }

                        //add alternate courses
                        if (!empty($coursesSelAlt)) {
                            foreach ($coursesSelAlt as $key => $courseId) {
                                $data = array(
                                    'linkable_id' => $_b_id,
                                    'product_id' => $courseId,
                                    'stepNo' => $key + 1,
                                    'seq' => 2
                                );
                                $userId = $userDetails['id'];
                                if (in_array($courseId, $bundleCoursesData)) {
                                    $data['id'] = array_search($courseId, $bundleCoursesData);
                                    unset($bundleCoursesData[$data['id']]);
                                    $data['modified_by'] = $userId;
                                    $data['modifiedDate'] = date('Y-m-d H:i:s');
                                } else {
                                    $data['created_by'] = $userId;
                                }
                                $saveCourseMapping = $courseMappingObj->saveBundleCourses($data);
                            }
                        }
                    }
                    /**
                     * Tool Section Edit Save-removed category logic
                     */
                    $this->_modifyTools($objSectionMapping, $request['bundle_tmp_id'], $toolList);

                    /**
                     * Bundle Accreditor Edit Save
                     */
                    if(!empty($request['bundle_tmp_id'])){
                        $parameter = array('bundleId' => $request['bundle_tmp_id'], 'bundleAccreditors' => $bundleAccreditors);
                        $this->bundleAccreditors($parameter);
                    }
                    /**
                     * Univeristy Edit Save
                     */
                    if(!empty($universityIds)){
                        $parameter = array('bundleId' => $request['bundle_tmp_id'], 'bundleUniversity' => $universityIds);
                        $this->bundleUniversityMapping($parameter);
                    }
                }
                if (!$result) {
                    $this->view->message = "An error has occured while saving";
                    $this->view->success = true;
                } else {
                    // for making message page specific
                    if ($bundleData['payment_type_id'] == BaseApp_Dao_PaymentType::ONETIME_PAYMENT_TYPE_ID)
                        $action = ' Bundle Got Added';
                    elseif ($bundleData['payment_type_id'] == BaseApp_Dao_PaymentType::SUBSCRIPTION_PAYMENT_TYPE_ID)
                        $action = ' Subscription Got Added';
                    $cdnPurgeData = $this->getModel()->buildCdnPurgeData($bundleData['bundle_id'], $bundleData['name'] . $action);
                    $objCdn = new Model_CdnPurgeLog();
                    if (!empty($cdnPurgeData))
                        $objCdn->InsertCdnPurgeLog($cdnPurgeData);
                    $this->view->message = ucwords($this->getRequest()->getControllerName()) . " Data successfully updated";
                    $this->view->success = false;
                }
                $partialView = !empty($request['partialView']) ? $request['partialView'] : 0;
                $this->_redirect("/admin/bundle/bundle-indetail/id/{$bundleData['bundle_id']}?partialView={$partialView}");
            }
        }
        elseif ($bundleId = $this->getRequest()->getParam('id')) {
            $bundleId = $this->getRequest()->getParam('id');
            $bundleModel = new Model_Bundles($bundleId);
            if (!$bundleModel->toArray()) {
                $this->_redirect('/admin/bundle/list');
            }
            if (!empty($bundleModel->modified_bundle_id)) {

            }
            
            $masterType = $bundleModel->master_type;
            $jobFlag = $bundleModel->job_assist_for_ind == 1 ? 1 : 0;            
            $seoData = $this->_getSeoData($bundleId, $masterType);
            
            
            $bundleModel->description = empty($seoData['course_intro_text'])?"":$seoData['course_intro_text'];
            $bundleModel->job_assist_for_ind = $jobFlag;
            $modelVideo = new Model_Videos();
            $videoData = $modelVideo->getByLinkableId($bundleId, 'bundle', BaseApp_Dao_TrainingTypes::TYPE_ELEARNING, 'about_bundle');
            if ($videoData) {
                $seoMd = new Model_Seo();
                $conds = array(
                    'controller=?' => Model_Videos::SEO_DEFAULT_CONTROLLER,
                    'action=?' => Model_Videos::SEO_DEFAULT_ACTION,
                    'linkable_id=?' => $videoData['video_id'],
                    'linkable_type=?' => 'video'
                );
                $seoData = current($seoMd->fetchAll($conds, array(), false));
                $bundleModel->videoLink = $videoData['videoLink'];
                $bundleModel->dateCreated = $videoData['dateCreated'];
                $bundleModel->duration = $videoData['duration'];
                $bundleModel->videoUrl = $seoData['url'];
                $bundleModel->videoThumbnail = $seoData['thumb_image'];
                $bundleModel->videoDescription = $videoData['shortDescription'];
            }
            $imageModel = new Model_Images();
            foreach ($imageModel->getAllByLinkable($bundleId, 'bundle') as $imageData) {
                // if ($imageData['name'] == 'bundle_logo') {
                //     $bundleModel->bundle_logo = $imageData['imagePath'];
                // }
                if ($imageData['name'] == 'subscription_logo') {
                    $bundleModel->subscription_logo = $imageData['imagePath'];
                }
                // if ($imageData['name'] == 'banner_image') {
                //     $bundleModel->banner_image = $imageData['imagePath'];
                // }
            }

            $session = new Zend_Session_Namespace('form');
            // if ($bundleModel->payment_type_id == BaseApp_Dao_PaymentType::SUBSCRIPTION_PAYMENT_TYPE_ID) {
            //     $priceData = $this->_prepareSubscriptionPricing($bundleId);
            // } else {
            //     $priceData = $this->_preparePricing($bundleId);
            // }
            $priceData = array();
            $this->_setCountrySubscriptionPrice($priceData);
            // $this->_setAccessDays($priceData);
            // $bundleModel->accessDays = array();
            // $this->_setCountryPrice($priceData);


            /*
             * SectionMapping model
             */
            $objSectionMapping = new Model_SectionMapping();
            $extraConditions = array('sm.show_at_top = ?' => 0);
            $advisorData = $objSectionMapping->getByLinkableIdLinkableType($bundleId, 'bundle', "sm.id ASC", $extraConditions);
            $sectionData = $objSectionMapping->getByLinkableIdLinkableType($bundleId, 'bundle');
           
            // $sectionDataBundle = $objSectionMapping->getByLinkableIdLinkableType($bundleId,'bundle');
            $bundleAccreditorLabel = $objSectionMapping->getByLinkableIdLinkableType($bundleId, BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLE_ACCREDITOR_LABEL);
            $bundleModel->course_advisor = '';
            if (!empty($sectionData)) {
                $courseAdvisors = isset($advisorData['directors']) ? array_column($advisorData['directors'], 'section_id') : array();
                $courseAlumni = isset($sectionData['alumni']) ? array_column($sectionData['alumni'], 'section_id') : array();
                $courseAdvisorsUnq = array_unique($courseAdvisors);
                $bundleModel->course_advisor = implode(",", $courseAdvisorsUnq);
                $bundleModel->alumni = array_unique($courseAlumni);
                $bundleModel->trusted_by = isset($sectionData['trustedByLogos']) ? array_column($sectionData['trustedByLogos'], 'section_id') : array();
            }
            if(!empty($bundleAccreditorLabel)){
                $bundleModel->primary_accreditor_label=isset($bundleAccreditorLabel['bundleprimaryaccreditor']) ? $bundleAccreditorLabel['bundleprimaryaccreditor'][0]['sectionTitle']:'';
                $bundleModel->secondary_accreditor_label=isset($bundleAccreditorLabel['bundlesecondaryaccreditor']) ? $bundleAccreditorLabel['bundlesecondaryaccreditor'][0]['sectionTitle']:'';
            }
            /*
             * SectionMapping model
             */
            
            //Get Bundle Accreditors Primary & Secondary
            $accreditorMappingObj = new Model_AccreditorMapping();
            $sectionTypePrimary = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_PRIMARY_ACCREDITOR;
            $conds = array(
                'linkable_id=?' => $bundleId,
                'linkable_type = ?' => $sectionTypePrimary,
            );
            $bundleAccreditorPrimaryArr = $accreditorMappingObj->fetchAll($conds);
            if(!empty($bundleAccreditorPrimaryArr)){
                $primaryAccreditorLabel = !empty($bundleAccreditorPrimaryArr[0]['label']) ?  $bundleAccreditorPrimaryArr[0]['label'] :''; 
                $primaryAccreditorIds = array_column($bundleAccreditorPrimaryArr, 'accreditor_id');
                $bundleModel->primary_accreditor_logo = $primaryAccreditorIds;
            }
            $sectionTypeSecondary = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_SECONDARY_ACCREDITOR;
            $conds = array(
                'linkable_id=?' => $bundleId,
                'linkable_type = ?' => $sectionTypeSecondary,
            );
            $bundleAccreditorPrimaryArr = $accreditorMappingObj->fetchAll($conds);
            if(!empty($bundleAccreditorPrimaryArr)){
                $primaryAccreditorLabel = !empty($bundleAccreditorPrimaryArr[0]['label']) ?  $bundleAccreditorPrimaryArr[0]['label'] :''; 
                $primaryAccreditorIds = array_column($bundleAccreditorPrimaryArr, 'accreditor_id');
                $bundleModel->secondary_accreditor_logo = $primaryAccreditorIds;
            }

            //get university data
             $universityMappingObj = new Model_UniversityMapping();
             $conds = array(
                'linkable_id=?' => $bundleId,
                'linkable_type = ?' => 'bundle',
            );
            $bundleUniversity = $universityMappingObj->fetchAll($conds);
            $bundleUniversityId = !empty($bundleUniversity[0]) && !empty($bundleUniversity[0]['university_id'])? $bundleUniversity[0]['university_id']:null;
            $tags = new Model_Tags();
            if ($tagData = $tags->getByLinkable($bundleId, 'bundle')) {
                $bundleModel->searchTags = $tagData['tag'];
            }
            $bundleModel->label_id = explode(",", $bundleModel->label_id);

            /*
             *  bundle electives
             */
            $bElectivesObj = new Model_CourseMapping();
            $bElectives = $bElectivesObj->getBundleElectives($bundleId);
            if (count($bElectives)) {
                $bundleElectiveData = array_column($bElectives, 'product_id', 'id');
                $bundleModel->bundle_electives_temp = $bundleElectiveData;
                $bundleModel->bundle_electives = implode(',', $bundleElectiveData);
                $bundleModel->bundle_electives_keys = implode(',', array_keys($bundleElectiveData));
                $bundleModel->bundle_elec_md5 = md5($bundleModel->bundle_electives);
            }
            /** END of electives */
            /*
             * bundle courses and alternate courses
             */
            $courseMappingObj = new Model_CourseMapping();
            $bCourses = $courseMappingObj->getBundleCourses($bundleId);
            $coursesPri = array();
            $coursesAlt = array();
            if (!empty($bCourses)) {
                foreach ($bCourses as $course) {
                    if (!empty($course['seq']) && $course['seq'] == 1)
                        //$coursesPri[$course['stepNo']] = $course['course_id'];
                         $coursesPri[$course['stepNo']] = $course['product_id'];
                    else if (!empty($course['seq']) && $course['seq'] == 2)
                        //$coursesAlt[$course['stepNo']] = $course['course_id'];
                        $coursesAlt[$course['stepNo']] = $course['product_id'];
                }
            }
            ksort($coursesPri);
            ksort($coursesAlt);
            $bundleModel->course_id = "";
            if (!empty($coursesPri)) {
                $bundleModel->course_id_tmp = $coursesPri;
                $bundleModel->course_id = implode(',', $coursesPri);
            }

            if (!empty($coursesAlt)) {
                $bundleModel->course_or_tmp = $coursesAlt;
                $bundleModel->course_or_id = implode(',', $coursesAlt);
            }
            $objCourseFaq = new Model_CourseFaq();
            if ($masterType == BaseApp_Dao_Bundles::MASTER_TYPE_CLASSIC) {
                $faqArr = $objCourseFaq->checkJobAssistForIndia($bundleId, 1);
                $jobFlag = ($faqArr['crmStatus'] == 1) ? true : false;
                $bundleModel->job_assist_for_ind = $jobFlag;
            }
            $objProductRepo = new Model_ProductRepo();
            $producRepoData = $objProductRepo->getByLinkable($bundleId, 'bundle');

            $certificateData = array();
            $bundleModel = $this->_setProductRepoData($producRepoData, $bundleModel);
            if (isset($producRepoData['certificate']))
                $certificateData = $this->_buildCertificateData($producRepoData['certificate']);
            $this->_setCertificate($certificateData);

            /**
             * Edit Action : Get Bundle Tool Categories and tool data.
             */
            $productSecMdl = new Model_ProductSectionData();
            $toolLinkableType = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES;
            $toolSectionType = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE_TOOL_CATEGORY;
            // $bundleTool = $this->_getBundleToolCategories($productSecMdl, $bundleId, $toolLinkableType, $toolSectionType);
            // $this->_setBundleTools($bundleTool);
            //################################################################
            $this->view->postParams = $bundleModel;

            $groupsObj = new Model_Groups();
            $this->view->enterpriseList = json_encode($groupsObj->getEnterpriseList());

            // fetch mapped enterprise list data
            $this->view->enterprisePrePopulateList = '[]';
            if($bundleId) {
                // $groupsObj = new Model_Groups();
                $prePopulateParams = array('entity_type' => ENTITY_TYPE_FOR_ENTERPRISE_BUNDLE_MAPPING, 'entity_id' => $bundleId, 'status' => 1);
                $res = $groupsObj->getPrePolulateEnterpriseList($prePopulateParams);
                
                if(empty($res)) {
                    $this->view->enterprisePrePopulateList = '[]';
                } else {
                    $this->view->enterprisePrePopulateList = json_encode($res);
                }
            }
            $form = $this->_getForm($bundleId);
            $form->removeUneditableElements();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            $bundleModel->bundle_tmp_id = $bundleId;
            $bundleModel->university = $bundleUniversityId;
            $defaultData = $bundleModel->toArray();
            $defaultData['old_bundle_available_for'] = $defaultData['bundle_available_for'];
            $form->setDefaults($defaultData);
            if ($bundleModel->course_id) {
                $form->getElement('course_id')->setAttrib('value', $bundleModel->course_id);
            }
            if($bundleModel->name){
                $form->getElement('currentBundleName')->setValue($bundleModel->name);
            }
            $form->getElement('course_advisor')->setValue($bundleModel->course_advisor);
            if($bundleModel->name){
                $form->getElement('currentBundleName')->setValue($bundleModel->name);
            }


            if($bundleModel->primary_label_id){
                $form->getElement('oldCategoryLabelID')->setValue($bundleModel->primary_label_id);
            }
            $hideFormSearch= $bundleModel->hideFromSearch ? $bundleModel->hideFromSearch : 0;
            $form->getElement('oldhideFromSearch')->setValue($hideFormSearch);
            //$form->getElement('section_title')->setValue($newSectionTitleVal);
        } else {
            $this->_redirect('/admin/bundle/list');
        }
        $this->view->form = $form;
    }
    public function bundleIndetailAction() {
         
        $this->_setContentBundle($this->getRequest()->getPost()); //set session value
        $bundleSectionId = $this->getRequest()->getParam('param');
        $bundleId = $this->getRequest()->getParam('id');
        $countryId = $this->getRequest()->getParam('countryId');
        $clusterId = $this->getRequest()->getParam('clusterId');
        $partialView = $this->getRequest()->getParam('partialView');
        $pageNo = $this->getRequest()->getParam('pageNo');
        $limitPerPage =  BaseApp_Dao_CourseFaq::DEFAULT_COURSE_FAQ_PAGE_LIMIT;
        if (empty($pageNo)) {
            $pageNo = 1;
        }
        $calc = $limitPerPage * $pageNo;
        $offset = $calc - $limitPerPage;
        $this->view->selectedCountryId = $countryId;
        $this->view->selectedClusterId = $clusterId;
        $this->view->partialViewSelected = !empty($partialView) ? $partialView : 0;

        $this->view->curPageNo=$pageNo;
        if (empty($bundleId)) {
            $this->view->message = "Bundle id not given";
            $this->view->success = false;
            return;
        }
        $objBundle = new Model_Bundles();
        if (!$bundleData = $objBundle->getBundleByIds($bundleId)) {
            $this->view->message = "Invalid Bundle Id";
            $this->view->success = false;
            return;
        }
        if ($bundleSectionId) {
            $this->view->sectionIdCurrent = $bundleSectionId;
        }
        
        $bundleData = $objBundle->getBundleById($bundleId);
        $this->view->bundleType = !empty($bundleData['master_type']) ? $bundleData['master_type'] : '';
        $detailSection =  array(
            'INCLUSIONS' => array(
                'name' => 'INCLUSIONS',
                'section_id' => 1,
                'course_section_id' => 1,
            ),
            'ABOUT_BUNDLE' => array(
                'name' => 'ABOUT BUNDLE',
                'section_id' => 2,
                'course_section_id' => 2,
            ),
            'FAQS' => array(
                'name' => 'FAQS',
                'section_id' => 3,
                'course_section_id' => 3
            ),
            'Industry_Trends' => array(
                'name' => 'Industry Trends',
                'section_id' => 4,
                'course_section_id' => 4
            )
        );
        if (!empty($bundleData['master_type']) && $bundleData['master_type'] !== BaseApp_Dao_Bundles::MASTER_TYPE_CLASSIC) {
            unset($detailSection['ABOUT_BUNDLE']);
        } else {
            unset($detailSection['Industry_Trends']);
        }
        $sectionTemplatesData = array(
            'Generic' => $detailSection
        );
        $objCourseFaq = new Model_CourseFaq();
        $objCountry = new Model_Country();
        $countries = $objCountry->getListDisplay();
        $this->view->countryList = $countries;
        $objCluster = new Model_Clusters();
        $cluster = $objCluster->fetchForSelect();
        $this->view->cluster = $cluster;
        $isEdit = false;
        $isNewEntry = false;
        $this->view->training_id = 0;
        if ($bundleSectionId) {
            $bundleId = $this->getRequest()->getParam('id');
            $contentId = $this->getRequest()->getParam('contentId');
            $contentType = '';
            switch ($bundleSectionId) {
                case 1:
                    $contentType = BaseApp_Dao_CourseFaq::COURSE_RESOURCE_KEY_FEATURE;
                    break;
                case 2:
                    $contentType = BaseApp_Dao_CourseFaq::COURSE_RESOURCE_ABOUT_COURSE;
                    break;
                case 3:
                    $contentType = BaseApp_Dao_CourseFaq::COURSE_RESOURCE_FAQ;
                    break;
                case 4:
                    $contentType = BaseApp_Dao_CourseFaq::BUNDLE_INDUSTRY_ID;
                    break;
                default:
                    break;
            }
                    $addMore = $this->getRequest()->getParam('addMore');
                    if (empty($bundleId)) {
                        $this->view->message = "An error has occured while saving";
                        $this->view->success = true;
                        return;
                    }
                    if (!empty($contentId)) {
                        $isEdit = true;
                        $isNewEntry = false;
                    }
                    if (!empty($addMore)) {
                        $isNewEntry = true;
                        $isEdit = false;
                    }
                    $this->view->aboutBundleData = array();
                    $errorMessage = "An error occured";
                    $this->view->showCourseDataListing = false;
                    if ($this->getRequest()->isPost()) {
                        $request = array(); 
                        $request = $this->getRequest()->getPost();    
                                           
                        if(!empty($request['aboutBundle'])){
                            $this->_setAboutBundle($request);
                        }
                         

                        $form = null;
                        switch ($bundleSectionId) {
                            case 4:
                                $form = new Form_BundleContentBenefits();
                                break;
                            default:
                                $form = new Form_AboutBundles(true);
                                break;
                        }
                       
                        $data = $form->getValues();
                                                
                        if ($form->isValid($request, $errorMessage)) {                             
                            $data = $form->getValues();                            
                            if (isset($data['aboutBundle'])) {
                                unset($data['aboutBundle']['__template__']);
                                $data['aboutBundle'] = $data['aboutBundle'];
                                $data['aboutBundle']['linkable_id'] = $bundleId;
                                $data['aboutBundle']['linkable_type'] = "bundle";                            
                            }
                            $result = false;
                            if(!empty($data['aboutBundle']['new']['cluster_id'])) {
                                $countryObj = new Model_Country();
                                $data['aboutBundle']['new']['country_id'] =  $countryObj->removeClusterCountries($data['aboutBundle']['new']['cluster_id'], $data['aboutBundle']['new']['country_id']);
                            }
                           
                    //industry trends
                     
                    try {
                      
                        //All the types which should have only one enty per country
                        $onlyOnePerCountryTypes = array(BaseApp_Dao_CourseFaq::BUNDLE_INDUSTRY_ID);
                        if (in_array($contentType, $onlyOnePerCountryTypes)) {                            
                            //before saving faq check if data exists for country and show error if it does;                               
                           
                            if ($this->_contentExistsForCountry($bundleId, $contentType, 0, $clusterId,  $data['aboutBundle']['new']['country_id']) && empty($contentId)) {
                               
                                $result = false;
                                $errorMessage = "Content already exists for this country . Cannot create another one.";
                            } else {                                
                                //save industry data here
                                $industryName = !empty($data['aboutBundle']['new']['industry_name'])?$data['aboutBundle']['new']['industry_name']:'';
                                $firstPointHeading = !empty($data['aboutBundle']['new']['point_one_heading'])?$data['aboutBundle']['new']['point_one_heading']:'';
                                $firstPointText = !empty($data['aboutBundle']['new']['point_one_text'])?$data['aboutBundle']['new']['point_one_text']:'';
                                $pointTwoHeading = !empty($data['aboutBundle']['new']['point_two_heading'])?$data['aboutBundle']['new']['point_two_heading']:'';
                                $pointTwoText = !empty($data['aboutBundle']['new']['point_two_text'])?$data['aboutBundle']['new']['point_two_text']:'';
                                
                                $designationNew  = !empty($data['aboutBundle']['new']['jobdesignation']['new']['desig_field'])?$data['aboutBundle']['new']['jobdesignation']['new']['desig_field']:$data['aboutBundle']['new']['jobdesignation'][0]['desig_field'];
                                
                                //end industry data
                                $courseFaqId = $data['aboutBundle']['new']['course_faq_id'];
                                $countryId = $data['aboutBundle']['new']['country_id'];
                                            //  prd($data['aboutBundle']);                   
                                if ($faqId = $objCourseFaq->addCourseContent($data['aboutBundle'], $contentType, $bundleId, 0, null, true, "bundle")) {
                                    //save job designations
                                    if (($contentType == BaseApp_Dao_CourseFaq::BUNDLE_INDUSTRY_ID) && !empty($data['aboutBundle']['new']['jobdesignation'])) {
                                        $result = $this->_saveCourseJobDesignations($data['aboutBundle']['new']['jobdesignation'], $faqId);
                                    }
                                     //new designation
                                     if (($contentType == BaseApp_Dao_CourseFaq::BUNDLE_INDUSTRY_ID) &&  $designationNew !="" ) {
                                        $indData['name'] = $designationNew;
                                        $indData['description'] = '';
                                        $indData['sectionType'] = BaseApp_Dao_ProductSectionData::INDUSTRY_TREND_DESIGNATION;                                        
                                        $result = $this->_saveGeoSepecificIndividualData($indData, BaseApp_Dao_ProductSectionData::INDUSTRY_TREND_DESIGNATION,$faqId);
                                        // prd($result);
                                    }

                                    //industry Name                                        
                                    if (($contentType == BaseApp_Dao_CourseFaq::BUNDLE_INDUSTRY_ID) &&  $industryName !="" ) {
                                        $indData['name'] = $industryName;
                                        $indData['description'] = '';
                                        $indData['sectionType'] = BaseApp_Dao_ProductSectionData::INDUSTRY_TREND_NAME;
                                        
                                        $result = $this->_saveGeoSepecificIndividualData($indData, BaseApp_Dao_ProductSectionData::INDUSTRY_TREND_NAME,$faqId);
                                    }

                                    if(($contentType == BaseApp_Dao_CourseFaq::BUNDLE_INDUSTRY_ID) &&  $firstPointHeading !="" && $firstPointText !=
                                    ""){
                                        $indData['name'] = $firstPointHeading;
                                        $indData['description'] = $firstPointText;
                                        $indData['sectionType'] = BaseApp_Dao_ProductSectionData::INDUSTRY_TREND_FIRST_POINT;
                                        $result = $this->_saveGeoSepecificIndividualData($indData, BaseApp_Dao_ProductSectionData::INDUSTRY_TREND_FIRST_POINT,$faqId);
                                    }

                                    if(($contentType == BaseApp_Dao_CourseFaq::BUNDLE_INDUSTRY_ID) &&  $pointTwoHeading !="" && $pointTwoText !=
                                    ""){
                                        $indData['name'] = $pointTwoHeading;
                                        $indData['description'] = $pointTwoText;
                                        $indData['sectionType'] = BaseApp_Dao_ProductSectionData::INDUSTRY_TREND_SECOND_POINT;
                                        $result = $this->_saveGeoSepecificIndividualData($indData,BaseApp_Dao_ProductSectionData::INDUSTRY_TREND_SECOND_POINT,$faqId);
                                    }

                                    // Benefit Data Newly added
                                    if (empty($courseFaqId) && $contentType == BaseApp_Dao_CourseFaq::BUNDLE_INDUSTRY_ID) {
                                        $objCourseFaq->deleteCourseCitiesFaq($bundleId, $contentType, $countryId);
                                    }
                                }
                            }
                        } else {
                            if ($isEdit) {
                                if ($objCourseFaq->addCourseContent($data['aboutBundle'], $contentType, $bundleId, 0, null, true, "bundle")) {
                                    $result = true;
                                }
                            } elseif ($isNewEntry) {
                                if ($objCourseFaq->addCourseContent($data['aboutBundle'], $contentType, $bundleId, 0, null, false, "bundle")) {
                                    $result = true;
                                }
                            }
                        }
                    } catch (exception $e) {
                        //throw exception if env dev                         
                    }
                            

                            if (!$result) {
                                if($errorMessage != ""){
                                    $this->view->message = $errorMessage;
                                }else{
                                    $this->view->message = "An error has occured while saving";
                                }
                                
                                $this->view->success = false;
                            } else {
                                $cdnPurgeData = $objBundle->buildCdnPurgeData($bundleId, $bundleData['name'] . ' About Bundle Section Data Added / Modified ');
                                $objCdn = new Model_CdnPurgeLog();
                                if (!empty($cdnPurgeData))
                                    $objCdn->InsertCdnPurgeLog($cdnPurgeData);
                                $this->view->message = "Saved SuccessFully";
                                $this->view->success = true;
                                $this->_redirect("/admin/bundle/bundle-indetail/id/{$bundleId}/param/{$bundleSectionId}");
                            }
                        }
                        else {
                            $this->view->message = $errorMessage;
                            $this->view->success = false;
                        }
                    } else {
                        if ($countryId == '' && $clusterId == '') {
                            $clusterId = 'all';
                        } else if($countryId == 'all') {
                            $clusterId = 0;
                            $countryId = 0;
                        }

                        $totalResourceCount = count($objCourseFaq->getDataByTypeAndContentId($bundleId, "bundle", $contentType, 0, $clusterId, $countryId, 0, $contentId, $offset, null));
                        $bundleContent = $objCourseFaq->getDataByTypeAndContentId($bundleId, "bundle", $contentType, 0, $clusterId, $countryId, 0, $contentId, $offset, $limitPerPage);
                       
                                                
                        
                        for($i = 0 ; $i<count($bundleContent);$i++){
                            if(!empty($bundleContent[$i]['industry_trends'])){                            
                                foreach($bundleContent[$i]['industry_trends'] as $trends){
                                    if(!empty($trends)){
                                        if($trends['sectionType'] == BaseApp_Dao_ProductSectionData::INDUSTRY_TREND_FIRST_POINT){
                                            $bundleContent[$i]['point_one_heading'] = $trends['name'];
                                            $bundleContent[$i]['point_one_text'] = $trends['description'];
                                        }else if($trends['sectionType'] == BaseApp_Dao_ProductSectionData::INDUSTRY_TREND_SECOND_POINT){
                                            $bundleContent[$i]['point_two_heading'] = $trends['name'];
                                            $bundleContent[$i]['point_two_text'] = $trends['description'];
                                        }else if($trends['sectionType'] == BaseApp_Dao_ProductSectionData::INDUSTRY_TREND_DESIGNATION){                                           
                                            $bundleContent[$i]['designation'] = $trends['name'];
                                        }else{
                                            $bundleContent[$i]['industry_name'] = $trends['name'];
                                        }
                                    }
                                }
                            }
                            unset($bundleContent[$i]['industry_trends']);
                        }
                        // prd($bundleContent);
                        // if(!empty($bundleContent[0]['industry_trends'])){                            
                        //     foreach($bundleContent[0]['industry_trends'] as $trends){
                        //         if(!empty($trends)){
                        //             if($trends['sectionType'] == BaseApp_Dao_ProductSectionData::INDUSTRY_TREND_FIRST_POINT){
                        //                 $bundleContent[0]['point_one_heading'] = $trends['name'];
                        //                 $bundleContent[0]['point_one_text'] = $trends['description'];
                        //             }else if($trends['sectionType'] == BaseApp_Dao_ProductSectionData::INDUSTRY_TREND_SECOND_POINT){
                        //                 $bundleContent[0]['point_two_heading'] = $trends['name'];
                        //                 $bundleContent[0]['point_two_text'] = $trends['description'];
                        //             }else{
                        //                 $bundleContent[0]['industry_name'] = $trends['name'];
                        //             }
                        //         }
                        //     }
                        // }
                        //unset($bundleContent[0]['industry_trends']);
                         
                        $totalPages = ceil($totalResourceCount / $limitPerPage);
                        $this->view->totalPages = $totalPages;
                        $contentBundleData = array(
                            'aboutBundle' => $bundleContent
                        );
                        if (!empty($addMore)) {
                            $contentBundleData = array();
                        }
                         
                        $showCourseFaqForm = empty($contentId) && !empty($contentBundleData) ? false : true;
                        $showCourseDataListing = empty($contentId) && !empty($contentBundleData) ? true : false;
                        
                        $this->view->detailData = !empty($contentBundleData['aboutBundle']) ? $contentBundleData['aboutBundle'] : array();
                        $this->view->detailListing = $showCourseDataListing;
                        $this->view->title = 'About Bundle';
                        $this->view->linkableId = $bundleId;
                        $this->view->linkableType = "bundle";
                        $this->view->sectionType = $contentType;
                        $this->view->addMore = $addMore;
                        $this->view->isEdit = $isEdit;
                        $this->_setAboutBundle($contentBundleData, $showCourseFaqForm);
                        $default = array();
                        if ($showCourseFaqForm) {
                            $this->view->detailListing = false;
                            $addMoreButton = !empty($addMore) ? true : false;
                            $form = null;
                            switch ($bundleSectionId) {
                                case 4:
                                    $form = new Form_BundleContentBenefits();
                                    break;
                                default:
                                    $form = new Form_AboutBundles($showCourseFaqForm, $addMoreButton);
                            break;
                            }
                            $form->setDefaults($default);
                        }
                    }
        }
        $this->view->sectionTemplates = $sectionTemplatesData;
        if (isset($form)) {
            $this->view->form = $form;
        }
    }
    public function bundleMoredetailAction()
    {
        $bundleId = $this->getRequest()->getParam('id');
        if (empty($bundleId)) {
            $this->view->message = "Bundle id not given";
            $this->view->success = false;
            return;
        }
        $objBundle = new Model_Bundles();
        $bundleData = $objBundle->getBundleById($bundleId);
        $bundleType = !empty($bundleData['master_type']) ? $bundleData['master_type'] : '';
        if ($this->getRequest()->isPost()) {
            $postData = $this->getRequest()->getPost();
            $this->_setProjects($postData);
            $this->_setBundleSkills($postData);
            $skillsData['skills'] = isset($postData['skills']) ? $postData['skills'] : array();
            $form = new Form_BundleMoreDetail($bundleId);
            if ($form === false) {
                throw new Zend_Exception('_getForm not implemented');
            }
            if ($form->isValid($postData)) {
                $postData['productId'] = $bundleId;
                $this->handleProjectAdvantageSection($postData);
                $this->bundleProjectSection($postData);
                if (!empty($skillsData['skills'])) {
                    $skillsCovered = array('bundleId' => $bundleId, 'skills' => $skillsData['skills']);
                    $this->handleBundleSkills($skillsCovered); 
                }
                if ($bundleType == BaseApp_Dao_Bundles::MASTER_TYPE_COHORT) {
                    $this->_redirect('/admin/bundle/list');
                }

                $this->_redirect("/admin/bundle/bundle-application/id/$bundleId");
            }
        } elseif ($bundleId = $this->getRequest()->getParam('id')) {
            $order = 'ps.id ASC';
            $sectionMapObj = new Model_SectionMapping();      
            $objProductSectionData = new Model_ProductSectionData();
            /**
             * introData
             */
            $introData = $this->_getSectionData($bundleId,BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES,BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_PROGRAM_INTRO);
            $defaultData['Intro'] = !empty($introData['ps_description'])? $introData['ps_description']:'';
            $defaultData['introSectionId'] = !empty($introData['section_id'])? $introData['section_id']:'';

            $pTitleData = $this->_getCourseProjectsTitle($objProductSectionData, $bundleId, BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES, BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE_PROJECTS_TITLE);
            $courseProjectsData = $this->_getCourseProjects($objProductSectionData, $bundleId, BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES, BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE_PROJECTS, $order);
            $projects = $courseProjectsData;
            $this->_setProjects($projects);
            
            // skill set
            $skillsCoveredData = array(
                'skills' => $objProductSectionData->getDataByType($bundleId,BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES,BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_SKILLS_COVERED,TRUE,$order)
                );
            $this->_setBundleSkills($skillsCoveredData);

            $form = new Form_BundleMoreDetail($bundleId);

            $defaultData['bundleProjectsDescription'] = !empty($pTitleData['sectionTitle']) ? $pTitleData['sectionTitle'] : '';
            $defaultData['projectTitleSectionId'] = !empty($pTitleData['section_id']) ? $pTitleData['section_id'] : '';            
            // 
            $idealInroData = $sectionMapObj->getpartnershipDataByProduct($bundleId,BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES,BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_IDEAL_CANDIDATE_INRO);

            $defaultData['ideal_intro'] = !empty($idealInroData[0]['description'])? $idealInroData[0]['description']:'';
            $defaultData['intro_id'] = !empty($idealInroData[0]['section_id'])? $idealInroData[0]['section_id']:'';

            $idealAudienceData = $sectionMapObj->getpartnershipDataByProduct($bundleId,BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES,BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_IDEAL_CANDIDATE_AUDIENCE);
            $defaultData['audience'] = !empty($idealAudienceData[0]['description'])? $idealAudienceData[0]['description']:'';
            $defaultData['audience_id'] = !empty($idealAudienceData[0]['section_id'])? $idealAudienceData[0]['section_id']:'';

            $idealEligibilityData = $sectionMapObj->getpartnershipDataByProduct($bundleId,BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES,BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_IDEAL_CANDIDATE_ELIGIBILITY);
            $defaultData['eligibility'] = !empty($idealEligibilityData[0]['description'])? $idealEligibilityData[0]['description']:'';
            $defaultData['eligibility_id'] = !empty($idealEligibilityData[0]['section_id'])? $idealEligibilityData[0]['section_id']:'';
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            $form->setDefaults($defaultData);
        }
        $this->view->form = $form;
    }

    private function _setBundleSkills(&$request) {
        $session = new Zend_Session_Namespace('form'); 
        if(isset($request['skills']) && count($request['skills'])) {
            
            $request['skills'] = $this->_updateFirstElement($request['skills']);        
            $session->skills = array_keys($request['skills']);
            array_unshift($session->skills, '__template__');
            $session->skillsData=  $request['skills'];
        }
        else {
            $session->skills = array('__template__', 'new');
            $session->skillsData = array();
        }
    }
    private function handleBundleSkills($data = array())
    {            
        if (!empty($data)) {
            $productId = $data['bundleId'];
            $objProductSectionData = new Model_ProductSectionData();
            $objSectionMapping = new Model_SectionMapping();
            $newProductSectionData = array();
            foreach ($data['skills'] as $key => $project) {
                if ($key === '__template__') {
                    continue;
                };
                $skillsData = htmlspecialchars(trim($project['name']));
                $skillsData = preg_replace("/[^ \w]+/", "", $skillsData);
                $sectionId = !empty($project['sectionId']) ? $project['sectionId'] : '';
                $sectionType = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_SKILLS_COVERED;
                $sectionTitle = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_SKILLS_COVERED_TITLE;
                $param['bundle_id_arr'] = array($productId);
                $param['sectionType'] = $sectionType;
                $param['sectionTitle'] = $sectionTitle;
                $param['name'] = $skillsData;
                $courseIds = array($productId);                            
                if (!empty($sectionId)) {
                    $newProductSectionData[$sectionId] = $sectionId;
                    if (empty($param['name'])) {
                        $linkableId = $sectionId;
                        $linkableType = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_SKILLS_COVERED;
                        $updateResponse = $objProductSectionData->updateToolProductSectionData($linkableId, $linkableType);
                        $updateStatus = $objSectionMapping->disableSecMapBySectionId($productId, BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES, $sectionId);
                    } else {
                        
                        $objProductSectionData->updatedBundleSkillSets($sectionId, $param);
                    }
                } else {
                    if(!empty($param['name'])){
                        $sectionId = $objProductSectionData->saveProductSectionData($param);
                    }
                }
                if (!empty($sectionId)) {
                    $newProductSectionData[$sectionId] = $sectionId;
                }
            }
            $existingSkillsData = $objProductSectionData->getDataByType($productId, BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES, BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_SKILLS_COVERED);            
            $existingSkills = array_keys($existingSkillsData);
            $newBundleCategorySkills = array_keys($newProductSectionData);
            $bundleSkillsCategoryDiff = array_diff($existingSkills, $newBundleCategorySkills);
            if (is_array($bundleSkillsCategoryDiff) && !empty($bundleSkillsCategoryDiff)) {
                foreach ($bundleSkillsCategoryDiff as $sectionId) {                   
                    if (!in_array($sectionId, $newBundleCategorySkills)) {
                        $linkableId = $sectionId;
                        $linkableType = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_SKILLS_COVERED;
                        $updateResponse = $objProductSectionData->updateToolProductSectionData($linkableId, $linkableType);
                        $updateStatus = $objSectionMapping->disableSecMapBySectionId($productId,BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES,$sectionId);
                        
                    }
                }
            }
        }        
    }

    public function pricingAction()
    {
        $this->view->bundleId = $this->getRequest()->getParam('id');
        if (empty($this->view->bundleId)) {
            $this->view->message = "Bundle id not given";
            $this->view->success = false;
            return;
        }
        if ($this->getRequest()->isPost()) {
            $request = $this->getRequest()->getPost();
            $this->_setAccessDays($request);
            $this->_setCountryPrice($request);
            $this->_setCountrySubscriptionPrice($request);
            $form = new Form_BundlePricing($request);
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            if ($form->isValid($request)) {
                $data = $form->getValues();
                $bundleId = $this->getRequest()->getParam('id');
                $objBundle = new Model_Bundles($bundleId);
                $bundleData = $objBundle->toArray();
                $data['payment_type_id'] = !empty($bundleData['payment_type_id'])?$bundleData['payment_type_id']:'';
                $data['master_type'] = !empty($bundleData['master_type'])?$bundleData['master_type']:'';
                $data['bundle_id'] =  $bundleId;
                $data['course_id'] =  !empty($bundleData['course_id'])?$bundleData['course_id']:'';
                if (!$this->_isValid($data, $message)) {
                    $this->view->message = $message;
                    $this->view->success = false;
                    $this->view->form = $form;
                    return;
                }
                $splitData = $this->_handlePricingfterSubmit($data);
                $result = true;
                if ($result == true) {
                    $pricing = new Model_SubscriptionPricing();
                    $linkableType = !empty($bundleData['linkable_type']) ? $bundleData['linkable_type']:'bundle';
                    if ($result && !$pricing->savePricing($data['bundle_id'], $linkableType, $splitData['countryPrice'])) {
                        $result = false;
                    } else {
                        if (!empty($data['bundle_id'])) {
                            $countryDetails = array();
                            if (!empty($splitData['countryPrice'])) {
                                foreach ($splitData['countryPrice'] as $key => $value) {
                                    if (!empty($value['country_id'])) {
                                        $countryDetails[] = $value['country_id'];
                                    } elseif (!empty($value['cluster_id'])) {
                                        $objCountry = new Model_Country();
                                        $countryIds = array();
                                        $countryIdsData = $objCountry->getCountriesByCluster(array($value['cluster_id']));
                                        if (!empty($countryIdsData)) {
                                            $countryIds = array_keys($countryIdsData);
                                        }
                                        $countryDetails = array_merge($countryDetails, $countryIds);
                                    }
                                }
                            }
                            $purgeObj = new Helper_PurgeUrl();
                            $extraData = array('countryIds' => $countryDetails);
                            $purgeUrlData = $purgeObj->submitPurgeData('pricing_bundle', 'master', $data['bundle_id'], $extraData);
                        }
                    }
                }
                if (!$result) {
                    $this->view->message = "An error has occured while saving";
                    $this->view->success = true;
                } else {
                    $action = ' Bundle Price Added';
                    $cdnPurgeData = $this->getModel()->buildCdnPurgeData($bundleData['bundle_id'], $bundleData['name'] . $action);
                    $objCdn = new Model_CdnPurgeLog();
                    if (!empty($cdnPurgeData))
                        $objCdn->InsertCdnPurgeLog($cdnPurgeData);
                    $this->view->message = ucwords($this->getRequest()->getActionName()) . " Price successfully updated";
                    $this->view->success = false;
                }
            }
        } elseif ($bundleId = $this->getRequest()->getParam('id')) {
            $bundleId = $this->getRequest()->getParam('id');
            $bundleModel = new Model_Bundles($bundleId);
            $bundleData = $bundleModel->toArray();
            $linkableType = !empty($bundleData['linkable_type']) ? $bundleData['linkable_type']:'bundle';
            if (!$bundleModel->toArray()) {
                $this->_redirect('/admin/bundle/list');
            }
            $masterType = $bundleModel->master_type;
            if ($bundleModel->payment_type_id == BaseApp_Dao_PaymentType::SUBSCRIPTION_PAYMENT_TYPE_ID) {
                $priceData = $this->_prepareSubscriptionPricing($bundleId);
            } else {
                $priceData = $this->_preparePricing($bundleId,$linkableType);
            }
            $this->_setCountrySubscriptionPrice($priceData);
            $this->_setAccessDays($priceData);
            $bundleModel->accessDays = array();
            $this->_setCountryPrice($priceData);
            $form = new Form_BundlePricing($bundleData);
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
        } else {
            $this->_redirect('/admin/bundle/list');
        }
        $this->view->form = $form;
    }

    public function bundleApplicationAction()
    {
        $bundleId = $this->getRequest()->getParam('id');
        if (empty($bundleId)) {
            $this->view->message = "Invalid/Missing Bundle id";
            $this->view->success = false;
            return;
        }
        $objBundle = new Model_Bundles($bundleId);
        $bundleData = $objBundle->toArray();
        $successSession = new Zend_Session_Namespace('form_status');

        if (!$bundleData || $bundleData['master_type'] != 1) {
            $this->view->message = "Not an University Program";
            $this->view->success = false;
            return;
        }

        if ($this->getRequest()->isPost()) {
            $request = $this->getRequest()->getPost();
            $isNewEntry = !empty($request['isNewEntry']) && $request['isNewEntry'] ? true : false;
            $form = new Form_ApplicationUniversity($isNewEntry, $bundleId);
            if ($request && $form->isValid($request)) {
                $data = $form->getValues();
                if (!empty($data)) {
                    unset(
                        $data['industry_name'], $data['industry_ratio'], 
                        $data['we_designation_name'], $data['we_designation_ratio'], 
                        $data['we_years_name'], $data['we_years_ratio'], 
                        $data['ed_industry_name'], $data['ed_industry_ratio'], 
                        $data['ed_logo_name'], $data['ed_logo_url'],
                        $data['app_hiring_companies']
                    );
                    $data['app_hiring_companies_id'] = explode(',',$data['app_hiring_companies_id']);
                    $appSectionTblFieldsArr = array(
                        'app_learner_intro' => array(
                            'id' => !empty($data['app_learner_aid']) ? $data['app_learner_aid'] : null,
                            'intro' => $data['app_learner_intro'],
                        ),
                        'app_financing_intro' => array(
                            'id' => !empty($data['app_financing_aid']) ? $data['app_financing_aid'] : null,
                            'intro' => $data['app_financing_intro'],
                        ),
                        'app_industry' =>  array(
                            'id' => !empty($data['app_industry_aid']) ? $data['app_industry_aid'] : null,
                            'intro' => $data['app_industry_intro'],
                            'first_sec_title' => $data['app_industry_title_1'],
                            'details1' => json_encode(
                                array(
                                    'industry_data' => json_decode($data['app_industry_data'])
                                )
                            ),
                            'second_sec_title' => $data['app_industry_title_2'],
                            'details2' => json_encode(['hiring_companies' => $data['app_hiring_companies_id']])
                        ),
                        'app_work_experience' => array(
                            'id' => !empty($data['app_work_experience_aid']) ? $data['app_work_experience_aid'] : null,
                            'intro' => $data['app_we_intro'],
                            'first_sec_title' => $data['app_we_title_1'],
                            'details1' => json_encode(
                                array(
                                    'designation_data' => json_decode($data['app_we_designation_data'])
                                )
                            ),
                            'second_sec_title' => $data['app_we_title_2'],
                            'details2' => json_encode(
                                array(
                                    'exp_data' => json_decode($data['app_we_exp_data'])
                                )
                            ),
                        ),
                        'app_educational' => array(
                            'id' => !empty($data['app_educational_aid']) ? $data['app_educational_aid'] : null,
                            'intro' => $data['app_ed_intro'],
                            'first_sec_title' => $data['app_ed_title_1'],
                            'details1' => json_encode(
                                array(
                                    'industry_data' => json_decode($data['app_ed_industry_data'])
                                )
                            ),
                            'second_sec_title' => $data['app_ed_title_2'],
                            'details2' => json_encode(
                                array(
                                    'college_logos' => json_decode($data['app_ed_logo_data'])
                                )
                            ),
                        ),
                        'app_admission_process' => array(
                            'id' => !empty($data['app_admission_process_aid']) ? $data['app_admission_process_aid'] : null,
                            'intro' => $data['app_process_intro'],
                            'details1' => json_encode(
                                array(
                                    'submit_text' => $data['app_process_submit_text'],
                                    'review_text' => $data['app_process_review_text'],
                                    'admission_text' => $data['app_process_text'],
                                )
                            ),
                        ),
                        'app_admission_eligibility' => array(
                            'id' => !empty($data['app_admission_eligibility_aid']) ? $data['app_admission_eligibility_aid'] : null,
                            'intro' => $data['app_eligibility_intro'],
                            'details1' => json_encode(
                                array(
                                    'work_exp' => $data['app_eligibility_work_exp'],
                                    'work_exp_order' => $data['app_eligibility_work_exp_order'],
                                    'degree' => $data['app_eligibility_degree'],
                                    'degree_order' => $data['app_eligibility_degree_order'],
                                    'basic_concept' => $data['app_eligibility_basic'],
                                    'basic_concept_order' => $data['app_eligibility_basic_order']
                                )
                            )
                        ),
                        'app_admission_counselors' => array(
                            'id' => !empty($data['app_admission_counselors_aid']) ? $data['app_admission_counselors_aid'] : null,
                            'intro' => $data['app_counselors_intro'],
                            'details1' => json_encode(
                                array(
                                    'point_1' => $data['app_counselors_point_1'],
                                    'point_2' => $data['app_counselors_point_2'],
                                    'point_3' => $data['app_counselors_point_3']
                                )
                            ),
                        ),
                        'app_program_benefits' => array(
                            'id' => !empty($data['app_program_benifits_aid']) ? $data['app_program_benifits_aid'] : null,
                            'details1' => json_encode(
                                array(
                                    'benefit_1' => $data['app_program_benefit_1'],
                                    'benefit_2' => $data['app_program_benefit_2'],
                                    'benefit_3' => $data['app_program_benefit_3'],
                                    'benefit_4' => $data['app_program_benefit_4'],
                                    'benefit_5' => $data['app_program_benefit_5']
                                )
                            )
                        )
                    );

                    $objAppSecData = new Model_ApplicationSectionData();
                    if ($objAppSecData->manageApplicationSectionData($appSectionTblFieldsArr, $bundleId,BaseApp_Dao_ApplicationSectionData::TYPE_BUNDLE)) {
                        $this->view->message = "Application data saved";
                        $this->view->success = true;
                        $successSession->statusMessage = 'Application data saved';
                        $this->_redirect("/admin/bundle/bundle-application/id/" . $bundleId);
                    } else {
                        $this->view->message = "An error has occured while saving";
                        $this->view->success = false;
                    }
                }
            }
        } elseif ($bundleId = $this->getRequest()->getParam('id')) {
            $default = array();
            $sectionTypes = [
                BaseApp_Dao_ApplicationSectionData::SECTION_TYPE_APP_LEARNER_INTRO,
                BaseApp_Dao_ApplicationSectionData::SECTION_TYPE_APP_INDUSTRY,
                BaseApp_Dao_ApplicationSectionData::SECTION_TYPE_APP_WORK_EXPERIENCE,
                BaseApp_Dao_ApplicationSectionData::SECTION_TYPE_APP_EDUCATIONAL,
                BaseApp_Dao_ApplicationSectionData::SECTION_TYPE_APP_ADMISSION_PROCESS,
                BaseApp_Dao_ApplicationSectionData::SECTION_TYPE_APP_ADMISSION_ELIGIBILITY,
                BaseApp_Dao_ApplicationSectionData::SECTION_TYPE_APP_ADMISSION_COUNSELORS,
                BaseApp_Dao_ApplicationSectionData::SECTION_TYPE_APP_FINANCIAL_INTRO,
                BaseApp_Dao_ApplicationSectionData::SECTION_TYPE_APP_PROGRAM_BENEFITS
            ];
    
            $productSectionData = (new BaseApp_Dao_ApplicationSectionData())->getApplicationData(BaseApp_Dao_ApplicationSectionData::TYPE_BUNDLE, $sectionTypes, $bundleId);
            // prd($productSectionData);
            $productSectionData = (new BaseApp_Dao_ApplicationSectionData())->prepareResponseData($productSectionData);
            $isNewEntry = true;
            if(!empty($productSectionData) && !empty($productSectionData[$bundleId])){
                $isNewEntry = false;
                $session = new Zend_Session_Namespace('form');
                foreach ($productSectionData[$bundleId] as $key => $productSectionInfo) {
                    $session->$key = $productSectionInfo;
                }
            };
            $form = new Form_ApplicationUniversity($isNewEntry, $bundleId);
            $form->setDefaults($default);
            $this->view->statusMessage = $successSession->statusMessage;
            unset($successSession->statusMessage);
        } else {
            $this->_redirect('/admin/bundle/list');
        }
        $this->view->form = $form;
    }

    private function _setCountryPrice(&$request) {
        $session = new Zend_Session_Namespace('form');
        if (isset($request['countryPrice']) && count($request['countryPrice'])) {
            $request['countryPrice'] = $this->_updateFirstElement($request['countryPrice']);
            $session->countryPrice = array_keys($request['countryPrice']);
            array_unshift($session->countryPrice, '__template__');
            $session->countryPriceData = $request['countryPrice'];
        } else {
            $session->countryPrice = array('__template__', 'new');
            $session->countryPriceData = array();
        }
    }

    private function _setCountrySubscriptionPrice(&$request) {
        $session = new Zend_Session_Namespace('form');
        if (isset($request['countrySubscriptionPrice']) && count($request['countrySubscriptionPrice'])) {
            $request['countrySubscriptionPrice'] = $this->_updateFirstElement($request['countrySubscriptionPrice']);
            $session->countrySubscriptionPrice = array_keys($request['countrySubscriptionPrice']);
            array_unshift($session->countrySubscriptionPrice, '__template__');
            $session->countrySubscriptionPriceData = $request['countrySubscriptionPrice'];
        } else {
            $session->countrySubscriptionPrice = array('__template__', 'new');
            $session->countrySubscriptionPriceData = array();
        }
    }

    private function _setAccessDays(&$request) {
        $session = new Zend_Session_Namespace('form');
        if (isset($request['accessDays']) && count($request['accessDays'])) {
            $request['accessDays'] = $this->_updateFirstElement($request['accessDays']);
            $session->accessDays = array_keys($request['accessDays']);
            array_unshift($session->accessDays, '__template__');
            $session->accessDaysData = $request['accessDays'];
        } else {
            $session->accessDays = array('__template__', 'new');
            $session->accessDaysData = array();
        }
    }

    private function _setKeyFeatures($keyFeatureData, $bundleModel) {

        $bundleModel->key_feature_name_1 = isset($keyFeatureData[0]['name']) ? $keyFeatureData[0]['name'] : '';
        $bundleModel->key_feature_text_1 = isset($keyFeatureData[0]['featureText']) ? $keyFeatureData[0]['featureText'] : '';

        $bundleModel->key_feature_name_2 = isset($keyFeatureData[1]['name']) ? $keyFeatureData[1]['name'] : '';
        $bundleModel->key_feature_text_2 = isset($keyFeatureData[1]['featureText']) ? $keyFeatureData[1]['featureText'] : '';

        $bundleModel->key_feature_name_3 = isset($keyFeatureData[2]['name']) ? $keyFeatureData[2]['name'] : '';
        $bundleModel->key_feature_text_3 = isset($keyFeatureData[2]['featureText']) ? $keyFeatureData[2]['featureText'] : '';

        $jobAssitFlag = False;
        if ($keyFeatureData[3]['featureText'] == 'True')
            $jobAssitFlag = True;
        $bundleModel->job_assist_for_ind = $jobAssitFlag;

        if (!empty($keyFeatureData[4]['country_id']) && $keyFeatureData[4]['country_id'] == INDIA_COUNTRY_ID) {
            $bundleModel->salary_feature_name_ind = $keyFeatureData[4]['name'];
            $bundleModel->salary_feature_text_ind = $keyFeatureData[4]['featureText'];
        }

        if (!empty($keyFeatureData[5]['country_id']) && $keyFeatureData[5]['country_id'] == US_COUNTRY_ID) {
            $bundleModel->salary_feature_name_row = $keyFeatureData[5]['name'];
            $bundleModel->salary_feature_text_row = $keyFeatureData[5]['featureText'];
        }
        return $bundleModel;
    }

    private function _setProductRepoData($producRepoData, $bundleModel) {
        if (isset($producRepoData['promotional']) && !empty($producRepoData['promotional'])) {
            $promotionalData = current($producRepoData['promotional']);
            $bundleModel->promotional_short_description = $promotionalData['short_description'];
            $bundleModel->coupon_id = $promotionalData['coupon_id'];
            $bundleModel->promotional_long_description = $promotionalData['long_description'];
            $bundleModel->cluster_id_bundle = explode(",", $promotionalData['cluster_id']);
            $bundleModel->country_id_bundle = explode(",", $promotionalData['country_id']);
            $bundleModel->promotional_image = $promotionalData['image_url'];
        }
        if (isset($producRepoData['certificate']) && !empty($producRepoData['certificate'])) {
            $certificateData = $producRepoData['certificate'];
            $bundleModel->certificate_header_text = $certificateData[0]['header_text'];
            $bundleModel->certificate_image = $certificateData[0]['image_url'];
            $bundleModel->certificate_alt_text = $certificateData[0]['short_description'];
        }
        return $bundleModel;
    }

    private function _buildCertificateData($certificateData) {
        unset($certificateData[0]);
        $setCertifcateArr = array_values($certificateData);
        $setCertifcateArr = array('certificateFeature' => $setCertifcateArr);
        return $setCertifcateArr;
    }

    private function _setBundleFaq(&$request) {
        $session = new Zend_Session_Namespace('form');
        if (isset($request['bundleFaq']) && count($request['bundleFaq'])) {
            $request['bundleFaq'] = $this->_updateFirstElement($request['bundleFaq']);
            $session->bundleFaq = array_keys($request['bundleFaq']);
            array_unshift($session->bundleFaq, '__template__');
            $session->bundleFaqData = $request['bundleFaq'];
        } else {
            $session->bundleFaq = array('__template__', 'new');
            $session->bundleFaqData = array();
        }
    }

    private function _setCertificate(&$request, $add = false)
    {

        $session = new Zend_Session_Namespace('form');
        if (isset($request['certificateFeature']) && count($request['certificateFeature'])) {
            $request['certificateFeature'] = $this->_updateFirstElement($request['certificateFeature']);
            $session->certificateFeature = array_keys($request['certificateFeature']);
            array_unshift($session->certificateFeature, '__template__');
            $session->certificateFeatureData = $request['certificateFeature'];
        } else {
            if (!empty($add) && isset($this->_certificateData['certificateFeature']) && count($this->_certificateData['certificateFeature'])) {
                $this->_certificateData['certificateFeature'] = $this->_updateFirstElement($this->_certificateData['certificateFeature']);
                $session->certificateFeature = array_keys($this->_certificateData['certificateFeature']);
                array_unshift($session->certificateFeature, '__template__');
                $session->certificateFeatureData = $this->_certificateData['certificateFeature'];
            } else {
                $session->certificateFeature = array('__template__', 'new');
                $session->certificateFeatureData = array();
            }
        }
    }
private function _setAboutBundle(&$request,$show=true) {
        $session = new Zend_Session_Namespace('form');
    if ($show) {
        if (isset($request['aboutBundle']) && count($request['aboutBundle'])) {
            $request['aboutBundle'] = $this->_updateFirstElement($request['aboutBundle']);
            $session->aboutBundle = array_keys($request['aboutBundle']);
            array_unshift($session->aboutBundle, '__template__');
            $session->aboutBundleData = $request['aboutBundle'];
        } else {
            $session->aboutBundle = array('__template__', 'new');
            $session->aboutBundleData = array();
        }
    } else {
        $session->aboutBundleData = array();
        $session->aboutBundle = array();
    }
}

    private function _handlePricingfterSubmit(&$request)
    {
        $returnData = array(
            'countryPrice' => array()
        );
        unset($request['accessDays']['__template__']);
        if ($request['payment_type_id'] == BaseApp_Dao_PaymentType::ONETIME_PAYMENT_TYPE_ID && isset($request['countryPrice'])) {
            unset($request['countryPrice']['__template__']);
            $counter = 0;
            foreach ($request['countryPrice'] as $elementKey => $data) {
                foreach ($request['accessDays'] as $setKey => $setValue) {
                    $returnData['countryPrice'][$counter] = array(
                        'currency_id' => $data['currency_id'],
                        'discountValue' => $data['discountValue'],
                        'training_id' => $data['training_id'],
                        'subscriptionId'    => $data['subscriptionId']?$data['subscriptionId']:'' 
                    );
                    if ($request['master_type'] == BaseApp_Dao_Bundles::MASTER_TYPE_UNIVERSITY && $data['hasPartPayment'] == 1) {
                        $returnData['countryPrice'][$counter]['part_payment'][$data['subscription_id']][1] = array("text" => !empty($data['first_installment_text']) ? $data['first_installment_text'] : '', "amount" => !empty($data['installment_first']) ? $data['installment_first'] : '');
                        $returnData['countryPrice'][$counter]['part_payment'][$data['subscription_id']][2] = array("text" => !empty($data['second_installment_text']) ? $data['second_installment_text'] : '', "amount" => !empty($data['installment_second']) ? $data['installment_second'] : '');
                        if (!empty($data['installment_third']) && $data['installment_third'] > 0) {
                            $returnData['countryPrice'][$counter]['part_payment'][$data['subscription_id']][3] = array("text" => !empty($data['third_installment_text']) ? $data['third_installment_text'] : '', "amount" => !empty($data['installment_third']) ? $data['installment_third'] : '');
                        }
                    }

                    if ($data['country_id']) {
                        $returnData['countryPrice'][$counter]['country_id'] = $data['country_id'];
                    }
                    if ($data['cluster_id']) {
                        $returnData['countryPrice'][$counter]['cluster_id'] = $data['cluster_id'];
                    }
                    $returnData['countryPrice'][$counter]['access_day_id'] = $setValue['accessDays'];
                    $returnData['countryPrice'][$counter]['subscriptionPrice'] = $data['price' . $setKey];
                    $counter++;
                }
            }
        }
        return $returnData;
    }
    private function _handleDataAfterSubmit(&$request) {

        $returnData = array(
            'countryPrice' => array(),
            'searchTags' => false,
            'imageData' => array(),
            'promotional_data' => array(),
            'certificateFeature' => array()
        );
        if (isset($request['certificateFeature'])) {
            unset($request['certificateFeature']['__template__']);
            $returnData['certificateFeature'] = $request['certificateFeature'];
            unset($request['certificateFeature']);
        }

        if (isset($request['subscription_logo']) && $request['subscription_logo']) {
            $returnData['imageData'][] = array(
                'imagePath' => $request['subscription_logo'],
                'name' => 'subscription_logo',
                'imageDescription' => ''
            );
        }
        unset($request['subscription_logo']);
        if (isset($request['label_id'])) {
            $request['label_id'] = implode(",", $request['label_id']);
        }
        if (isset($request['course_id']) && is_array($request['course_id'])) {
            $request['course_id'] = implode(",", $request['course_id']);
        }
        if (isset($request['searchTags'])) {
            $returnData['searchTags'] = $request['searchTags'];
            unset($request['searchTags']);
        }

        //price deleted

        if ($request['payment_type_id'] == BaseApp_Dao_PaymentType::SUBSCRIPTION_PAYMENT_TYPE_ID && isset($request['countrySubscriptionPrice'])) {
            $returnData['countryPrice'] = array();
            unset($request['countrySubscriptionPrice']['__template__']);
            $frequency = new Model_PricingFrequency();
            $frequencyData = $frequency->getByToken();
            foreach ($request['countrySubscriptionPrice'] as $elementKey => $data) {
                $priceMonthly = array();
                $priceYearly = array();
                unset($data['location_mode']);
                if (!$data['country_id']) {
                    unset($data['country_id']);
                }
                if (!$data['cluster_id']) {
                    unset($data['cluster_id']);
                }
                $priceMonthly = $data;
                unset($priceMonthly['priceMonthly']);
                unset($priceMonthly['priceYearly']);
                $priceYearly = $data;
                unset($priceYearly['priceMonthly']);
                unset($priceYearly['priceYearly']);
                $priceMonthly['subscriptionPrice'] = $data['priceMonthly'];
                $priceMonthly['frequency_id'] = $frequencyData[Model_PricingFrequency::TOKEN_MONTHLY]['frequency_id'];

                $priceYearly['subscriptionPrice'] = $data['priceYearly'];
                $priceYearly['frequency_id'] = $frequencyData[Model_PricingFrequency::TOKEN_YEARLY]['frequency_id'];
                $returnData['countryPrice'][] = $priceMonthly;
                $returnData['countryPrice'][] = $priceYearly;
            }
        }
        $returnData['section_id_arr'] = array();
        $returnData['course_advisor_section_id_arr'] = array();
        if (isset($request['course_advisor'])) {
            $returnData['course_advisor_section_id_arr'][] = explode(',', $request['course_advisor']);
        }
        if (isset($request['alumni'])) {
            $returnData['section_id_arr'][] = $request['alumni'];
        }
        if (isset($request['trusted_by'])) {
            $returnData['section_id_arr'][] = $request['trusted_by'];
        }

        if ( !empty($request['certificate_header_text']) || $request['master_type']==BaseApp_Dao_Bundles::MASTER_TYPE_COHORT ) {
            $returnData['certificate_data'][] = array('header_text' => $request['certificate_header_text'], 'image_url' => $request['certificate_image'], 'short_description' => $request['certificate_alt_text']);
        }
        unset($request['job_assist_for_ind']);
        unset($request['bundle_tmp_id']);

        unset($request['certificate_header_text']);
        unset($request['certificate_short_description']);
        unset($request['certificate_image']);
        unset($request['certificate_alt_text']);


        unset($request['course_advisor']);
        unset($request['course_advisor_temp']);
        unset($request['alumni']);
        unset($request['trusted_by']);
        unset($request['accessDays']);
        unset($request['countryPrice']);
        unset($request['countrySubscriptionPrice']);

        return $returnData;
    }

    private function _preparePricing($bundleId,$linkableType = 'bundle') {
        $priceModel = new Model_SubscriptionPricing();
        $countryPrice = array();
        $accessDays = array();

        $clusterList = array();
        $countryList = array();
        $counter = -1;
        foreach ($priceModel->getByLinkable($bundleId, $linkableType, 'bundle') as $indexTemp => $data) {
            $accessDays[$data['access_day_id']] = array(
                'accessDays' => $data['access_day_id']
            );

            if ($data['country_id']) {
                $index = array_search($data['country_id'], $countryList);
                if ($index === false) {
                    $counter++;
                    $index = $counter;
                    $countryList[$counter] = $data['country_id'];
                    $countryPrice[$index]['price' . $data['access_day_id']] = $data['subscriptionPrice'];
                } else {
                    $countryPrice[$index]['price' . $data['access_day_id']] = $data['subscriptionPrice'];
                    continue;
                }
                $countryPrice[$index]['location_mode'] = 2;
            } else {
                $index = array_search($data['cluster_id'], $clusterList);
                if ($index === false) {
                    $counter++;
                    $index = $counter;
                    $clusterList[$counter] = $data['cluster_id'];
                    $countryPrice[$index]['price' . $data['access_day_id']] = $data['subscriptionPrice'];
                } else {
                    $countryPrice[$index]['price' . $data['access_day_id']] = $data['subscriptionPrice'];
                    continue;
                }
                $countryPrice[$index]['location_mode'] = 1;
            }

            $partPaymentModel = new Model_PartPaymentBreakups();
            $partPaymentInfo = $partPaymentModel->getBreakUpBySubscriptionId($data['subscription_id']);
            $countryPrice[$index]['partPaymentInfo'] = $partPaymentInfo;
            $countryPrice[$index]['subscription_id'] = $data['subscription_id'];
            $countryPrice[$index]['country_id'] = $data['country_id'];
            $countryPrice[$index]['cluster_id'] = $data['cluster_id'];
            $countryPrice[$index]['currency_id'] = $data['currency_id'];
            $countryPrice[$index]['discountValue'] = $data['discountValue'];
        }
        foreach ($countryPrice as $key => $data) {
            foreach ($data as $keyElement => $keyData) {
                if (preg_match("/price(.*)/", $keyElement, $match)) {
                    $keys = array_keys($countryPrice[$key]);
                    $keys[array_search($match[0], $keys)] = 'pricenew';
                    $countryPrice[$key] = array_combine($keys, $countryPrice[$key]);
                    break;
                }
            }
        }
        return array(
            'countryPrice' => $countryPrice,
            'accessDays' => $accessDays
        );
    }

    private function _prepareSubscriptionPricing($bundleId) {
        $priceModel = new Model_SubscriptionPricing();
        $countryPrice = array();
        $accessDays = array();

        $clusterList = array();
        $countryList = array();
        $counter = -1;
        $frequency = new Model_PricingFrequency();
        $frequencyData = $frequency->getByFrequencyId();
        foreach ($priceModel->getByLinkable($bundleId, 'bundle', 'subscription') as $indexTemp => $data) {
            if ($data['country_id']) {
                $index = array_search($data['country_id'], $countryList);
                if ($index === false) {
                    $counter++;
                    $index = $counter;
                    $countryList[$counter] = $data['country_id'];
                    $subscriptionPrice = $data['subscriptionPrice'];
                } else {
                    $subscriptionPrice = $data['subscriptionPrice'];
                }
                if ($frequencyData[$data['frequency_id']]['name'] == Model_PricingFrequency::TOKEN_MONTHLY) {
                    $countryPrice[$index]['priceMonthly'] = $subscriptionPrice;
                } elseif ($frequencyData[$data['frequency_id']]['name'] == Model_PricingFrequency::TOKEN_YEARLY) {
                    $countryPrice[$index]['priceYearly'] = $subscriptionPrice;
                }
                $countryPrice[$index]['location_mode'] = 2;
            } else {
                $index = array_search($data['cluster_id'], $clusterList);
                if ($index === false) {
                    $counter++;
                    $index = $counter;
                    $clusterList[$counter] = $data['cluster_id'];
                    $subscriptionPrice = $data['subscriptionPrice'];
                } else {
                    $subscriptionPrice = $data['subscriptionPrice'];
                }
                if ($frequencyData[$data['frequency_id']]['name'] == Model_PricingFrequency::TOKEN_MONTHLY) {
                    $countryPrice[$index]['priceMonthly'] = $subscriptionPrice;
                } elseif ($frequencyData[$data['frequency_id']]['name'] == Model_PricingFrequency::TOKEN_YEARLY) {
                    $countryPrice[$index]['priceYearly'] = $subscriptionPrice;
                }
                $countryPrice[$index]['location_mode'] = 1;
            }
            $countryPrice[$index]['country_id'] = $data['country_id'];
            $countryPrice[$index]['cluster_id'] = $data['cluster_id'];
            $countryPrice[$index]['currency_id'] = $data['currency_id'];
        }
        return array(
            'countrySubscriptionPrice' => $countryPrice
        );
    }

    private function _updateFirstElement($elementArray) {
        $keys = array_keys($elementArray);
        $keys[array_search('0', $keys)] = 'new';
        return array_combine($keys, $elementArray);
    }

    public function _isValid($data, &$message) {
        if (!empty($data['payment_type_id']) && $data['payment_type_id'] == BaseApp_Dao_PaymentType::SUBSCRIPTION_PAYMENT_TYPE_ID) {
            $priceData = $data['countrySubscriptionPrice'];
        } else {
            $priceData = $data['countryPrice'];
        }
        $modelCourse = new Model_Courses();
        foreach ($priceData as $priceDataSingle) {
            if ($priceDataSingle['country_id'] == self::COUNTRY_IN && $modelCourse->isErpCourse($data['course_id'])) {
                $message = "SAP courses not allowed in India";
                return false;
            }
        }
        if (!$this->_isPriceValid($priceData, $message)) {
            return false;
        }
        if ($data['payment_type_id'] == BaseApp_Dao_PaymentType::ONETIME_PAYMENT_TYPE_ID) {
            foreach ($data['accessDays'] as $elementKey => $dataAccess) {
                if ($elementKey == '__template__') {
                    continue;
                }
                if (!$dataAccess['accessDays']) {
                    $message = "Access days not selected";
                    return false;
                }
            }
        }

        if (!empty($data['payment_type_id']) && $data['payment_type_id'] == BaseApp_Dao_PaymentType::ONETIME_PAYMENT_TYPE_ID) {
            foreach ($data['accessDays'] as $elementName => $elementValue) {
                if ($elementName == '__template__') {
                    continue;
                }
                if (!is_numeric($elementValue['accessDays']) || $elementValue['accessDays'] <= 0) {
                    $message = "Invalid access days";
                    return false;
                }
            }
        }
        return true;
    }


    private function _getCourseProjectsTitle(Model_ProductSectionData $modelObj, $linkableId, $linkableType, $sectionType)
    {
        $courseProjectTitleData = $modelObj->getDataByType($linkableId, $linkableType, $sectionType);
        $courseProjectTitleData = !empty($courseProjectTitleData)?current($courseProjectTitleData):array();
        return $courseProjectTitleData;
    }

    public function listAction() {
        $this->_helper->viewRenderer->setRender('common/list')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $table = $this->getModel()->getName();
        $filterForm = new Form_Filters($table);
        $requestData = array();
        $queryParamsArr = array();
        $page = '';
        if ($this->getRequest()->isPost()) {
            $filterForm->populate($this->getRequest()->getPost());
            $page = 1;
            $requestData = $filterForm->getValues();
            foreach ($requestData as $elementName => $elementValue) {
                if (!empty($elementValue)) {
                    $queryData = $filterForm->getElement($elementName)->getAttrib('data-table');
                    $queryData['searchValue'] = $elementValue;
                    $this->queryBuilder($queryData);
                    $queryParamsArr[$queryData['search_id']] = $elementValue;
                } // end of !empty elementValue
            } // end of foreach RequestData
        } // end of if isPost
        if (empty($page)) {
            $page = $this->view->navigatorPage;
            $page = (int) $this->getRequest()->getParam('page');
        }
        $orderby = $this->getModel()->getPk() . ' DESC';
        if (empty($this->_queryParams)) {
            $getData = $this->getRequest()->getQuery();
            unset($getData['page']);
            if (!empty($getData)) {
                foreach ($getData as $key => $value) {
                    $queryParamsArr[$key] = $value;
                    $returnData = $filterForm->getSearchFields($key);
                    if (!empty($returnData)) {
                        $returnData = $returnData[0];
                        $filterForm->getElement($returnData['searchColumnName'])->setValue($value);
                        $returnData['searchValue'] = $value;
                        $this->queryBuilder($returnData);
                    }
                }
            }
        }
        if ($page <= 1) {
            $this->view->firstpage = true;
            $page = 1;
        } else {
            $this->view->firstpage = false;
        }
        $offset = ($page - 1) * self::ROWS_PER_PAGE;
        $limit = array(self::ROWS_PER_PAGE, $offset);
        $this->view->page = $page;
        $model = $this->getModel();
        $data = $model->fetchAll($this->_queryParams, array('order' => array($orderby), 'limit' => $limit));
        $perPageData = count($data);
        $total = $model->fetchCount($this->_queryParams);
        if (count($data) < self::ROWS_PER_PAGE) {
            $this->view->lastpage = true;
        } else {
            $this->view->lastpage = false;
        }
        $numberOfPages = ceil($total / self::ROWS_PER_PAGE);
        if ($page < $numberOfPages) {
            $this->view->currentPageRecord = self::ROWS_PER_PAGE * $page;
        } else {
            $this->view->currentPageRecord = $total;
        }
        $this->view->diffPageRecord = $this->view->currentPageRecord - self::ROWS_PER_PAGE;
        if (count($data) < self::ROWS_PER_PAGE) {
            $this->view->diffPageRecord = $total - count($data);
        }
        $this->view->totalCount = $total;
        $this->view->totalPages = $numberOfPages;
        $this->view->lastPage = $numberOfPages;
        $pk = $model->getPk();
        foreach ($data as &$row) {
            $row['isModified'] = '';
            if (!empty($row['modified_bundle_id'])) {
                $row['isModified'] = self::STR_MODIFIED;
            }

            $row['Action'] = "<a href='" . $this->view->url(array('action' => 'view', 'id' => $row[$pk])) . "'>View</a> " . "<a href='" . $this->view->url(array('controller' => 'changelog', 'action' => 'index', 'row' => $row[$pk], 'table' => $table)) . "'>ChangeLog</a> " .
                    "<a href='" . $this->view->url(array('action' => 'edit', 'id' => $row[$pk])) . "'>Edit</a> " .
                    "<a class='delete-crud-item' href='#' onclick='deleteConfirmShow(\"" . $this->view->url(array('action' => 'delete', 'id' => $row[$pk])) . "\");'>Delete</a> " .
                    "<a href='" . $this->view->url(array('module' => 'admin', 'controller' => 'pricing', 'action' => 'list-other', 'id' => $row[$pk], 'type' => 'bundle'), null, true) . "' target='_blank'>View Price</a> ";
            $row['purge'] = "<a  class='purge' data-action='" . $this->view->url(array('action' => 'purgeurl', 'id' => $row[$pk] )) . "' href='" . $this->view->url(array('action' => 'purgeurl', 'id' => $row[$pk] )) . "'>purge</a> ";
            }
        if (isset($data[0])) {
            $original = array_keys($data[0]);
        } else {
            $original = array();
        }
        $as = ($this->_displayInDataTable);
        //new datatable
        //need to define path in ini file after discussion
        $datatableFilePath = '../../library/BaseApp/Datatable/' . ucfirst($table) . '.php';
        if (file_exists($datatableFilePath)) {
            $dataTableClass = 'BaseApp_Datatable_' . ucfirst($table);
        } else {
            $dataTableClass = 'BaseApp_Datatable_Default';
        }

        $dataTable = new $dataTableClass;
        $dataTable->setData($data);
        $this->view->queryParams = http_build_query($queryParamsArr);
        $this->view->form = $filterForm;
        $this->view->data = $dataTable;
        $this->view->original = $original;
        $this->view->displayInDataTable = $as;
        $this->view->navigatorTotal = ceil($total / BACKEND_ROWS_PER_PAGE);
    }

    public function purgeurlAction()
    {
        $Id = $this->getRequest()->getParam('id');
        try {
            $message = '';
            $status = '';
            $response = array();
            $extraData = array();
            $purgeObj = new Helper_PurgeUrl();
            $response = $purgeObj->submitPurgeData('bundle', 'master', $Id, $extraData);
            $data = array();
            if (!empty($response['data']) && !empty($response['data']['data'])) {
                $data = $response['data']['data'];
            }
            if (!empty($data)) {
                $message = "success";
                $status = "success";
            } else {
                http_response_code(404);
                $message = 'Some error occurred while fetching data.';
                $status = "error";
            }
        } catch (Exception $e) {
            http_response_code(401);
            $message = "Error occured." . $e->getMessage();
            $status = "error";
        }
        $this->view->data = array(
            'message' => $message,
            'status' => $status,
            'data' => $data
        );
        die(Zend_Json_Encoder::encode($this->view->data));
    }

    public function deleteAction() {
        $b2bCartPricing = new Model_B2bCartPricing();
        $this->_helper->viewRenderer->setRender('common/delete')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $bundleId = $this->getRequest()->getParam('id');

        $dataDelete = $this->getModel($bundleId);

        if (!$dataDelete->toArray()) {
            $this->view->message = "Invalid Bundle";
            $this->view->success = false;
            return;
        }

        try {
            // b2b update based on course available for
            $groupsObj = new Model_Groups();
            $prePopulateParams = array('entity_type' => ENTITY_TYPE_FOR_ENTERPRISE_BUNDLE_MAPPING, 'entity_id' => $bundleId, 'status' => 1);
            $res = $groupsObj->getPrePolulateEnterpriseList($prePopulateParams);
            $agencies = array_map(function($temp){return $temp['id'];} , $res);
            $availableForData = array('old' => array(), 'new' => array());
            $availableForData['new']['availableFor'] = 'no_where';
            $availableForData['new']['agencies'] = array();
            $availableForData['old']['availableFor'] = !empty($dataDelete['bundle_available_for']) ? $dataDelete['bundle_available_for']: '';
            $availableForData['old']['agencies'] = $agencies;
            $b2bHelper = new Helper_B2bHelper();
            $b2bHelper->processAvaliableForChange(BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES, $bundleId, $availableForData);
        } catch (Exception $e) {
            file_put_contents(APPLICATION_PATH . '/../error.log', "\n[" .date('Y-m-d H:i:s'). '] ERROR: bundle processAvaliableForChange failed ' . $e->getMessage(), FILE_APPEND);
            if (APPLICATION_ENV != 'production') throw $e;
        }

        $modelPrice = new Model_SubscriptionPricing();
        if (!$modelPrice->deleteByLinkable($bundleId, 'bundle')) {
            $this->view->message = 'failed to delete price:';
            $this->view->success = false;
            return;
        }

        $deleteStatus=$dataDelete->delete();
        if ($deleteStatus) {
            $productId = $bundleId;
            $productType = 'bundle';
            $action = 'disable';
            $params = array('productId' => $productId, 'productType' => $productType, 'action' => $action);
            $salsesforceApi = new BaseApp_Communication_SalesforceApi();
            $response = $salsesforceApi->SfdcPoductSync($params);
        }
        if (!$deleteStatus) {
            $this->view->message = 'failed to delete bundle:' . $bundleId;
            $this->view->success = false;
            return;
        }
        $b2bCartPricing->deleteB2bCartProductData('bundle',$bundleId);
        if ($dataDelete['payment_type_id'] == BaseApp_Dao_PaymentType::ONETIME_PAYMENT_TYPE_ID)
            $action = ' Bundle Got Deleted';
        elseif ($dataDelete['payment_type_id'] == BaseApp_Dao_PaymentType::SUBSCRIPTION_PAYMENT_TYPE_ID)
            $action = ' Subscription Got Deleted';
        $cdnPurgeData = $this->getModel()->buildCdnPurgeData($bundleId, $dataDelete['name'] . $action);
        $objCdn = new Model_CdnPurgeLog();
        if (!empty($cdnPurgeData))
            $objCdn->InsertCdnPurgeLog($cdnPurgeData);
        $this->_redirect("/admin/bundle/list");
    }

    private function _isPriceValid($data, &$message = '') {
        $countryList = array();
        $clusterList = array();
        foreach ($data as $elementKey => $dataSingle) {
            if ($elementKey == '__template__') {
                continue;
            }
            if ((!isset($dataSingle['cluster_id']) && !isset($dataSingle['country_id'])) || (!$dataSingle['cluster_id'] && !$dataSingle['country_id'])) {
                $message = "location missing for price";
                return false;
            }

            foreach ($dataSingle as $fieldName => $fieldValue) {
                if (!preg_match("/price/", $fieldName)) {
                    continue;
                }
                if (!is_numeric($fieldValue) && !is_float($fieldValue)) {
                    $message = "Invalid price provided";
                    return false;
                }
            }
            if (isset($dataSingle['country_id']) && $dataSingle['country_id']) {
                if (in_array($dataSingle['country_id'], $countryList)) {
                    $message = "Same location selected multiple times";
                    return false;
                }
                $countryList[] = $dataSingle['country_id'];
            }
            if (isset($dataSingle['cluster_id']) && $dataSingle['cluster_id']) {
                if (in_array($dataSingle['cluster_id'], $clusterList)) {
                    $message = "Same location selected multiple times";
                    return false;
                }
                $clusterList[] = $dataSingle['cluster_id'];
            }

            if(isset($dataSingle['hasPartPayment']) && $dataSingle['hasPartPayment'] == 1){
                $totalPartPayment = $dataSingle['installment_first'] + $dataSingle['installment_second'] + $dataSingle['installment_third'];
                $actualPrice = $dataSingle['pricenew'];
                if(abs($actualPrice-$totalPartPayment) > 1){
                    $message = "Part Amount not Equal to total Pricing";
                    return false;
                }
                if(empty(trim($dataSingle['installment_first'])) || empty(trim($dataSingle['installment_second']))){
                    $message = "Part Amount must have min. 2 Breakups";
                    return false;
                }

                if( ( trim($dataSingle['first_installment_text']) == '' && !empty($dataSingle['installment_first']) && $dataSingle['installment_first'] > 0 )
                    || ( trim($dataSingle['second_installment_text']) == '' && !empty($dataSingle['installment_second']) && $dataSingle['installment_second'] > 0 )
                    || ( trim($dataSingle['third_installment_text']) == '' && !empty($dataSingle['installment_third']) && $dataSingle['installment_third'] > 0 )
                ){
                    $message = "Part Payment Time of Payment is Required";
                    return false;
                }

                if( ( trim($dataSingle['first_installment_text']) != '' 
                        && strlen($dataSingle['first_installment_text']) > 35 
                        && !empty($dataSingle['installment_first']) 
                        && $dataSingle['installment_first'] > 0 
                    )
                    || ( trim($dataSingle['second_installment_text']) != '' 
                            && strlen($dataSingle['second_installment_text']) > 35 
                            && !empty($dataSingle['installment_second']) 
                            && $dataSingle['installment_second'] > 0 
                        )
                    || ( trim($dataSingle['third_installment_text']) != '' 
                            && strlen($dataSingle['third_installment_text']) > 35 
                            && !empty($dataSingle['installment_third']) 
                            && $dataSingle['installment_third'] > 0 
                        )
                ){
                    $message = "'Time of payment' field has 35 character limit";
                    return false;
                }
            }
        }
        unset($countryList);
        unset($clusterList);
        return true;
    }

    /**
     * Set Bundle Tools
     * @param type $request
     */
    // private function _setBundleTools(&$request) {
    //     $session = new Zend_Session_Namespace('form');
    //     if (isset($request['courseToolsFeature']) && count($request['courseToolsFeature'])) {
    //         $request['courseToolsFeature'] = $this->_updateFirstElement($request['courseToolsFeature']);
    //         $session->courseToolsFeature = array_keys($request['courseToolsFeature']);
    //         array_unshift($session->courseToolsFeature, '__template__');
    //         $session->courseToolsFeatureData = $request['courseToolsFeature'];
    //     } else {
    //         $session->courseToolsFeature = array('__template__', 'new');
    //         $session->courseToolsFeatureData = array();
    //     }
    // }

    /**
     * Verify Bundle Tool Category
     * 1. Check if Bundle category tool exist or not.
     * 2. If bundle category tool does not exist create and map to bundle and map to all selected tools.
     * 3. Update tools.
     * 4. Remove tools.
     * @param array $data
     */
    // private function bundleToolCategoryVerify($data = array()) {
    //     if (!empty($data)) {
    //         $bundleId = $data['bundleId'];
    //         $objProductSectionData = new Model_ProductSectionData();
    //         $objSectionMapping = new Model_SectionMapping();
    //         $existingCourseCatToolArr = array();
    //         foreach ($data['courseToolInfo'] as $key => $toolInfo) {
    //             if ($key === '__template__') {
    //                 continue;
    //             }
    //             $courseToolSectionTitle = htmlspecialchars(trim($toolInfo['course_category']));
    //             $courseToolSectionTitle=htmlentities($courseToolSectionTitle, ENT_COMPAT, 'utf-8');
    //             $courseToolSectionTitle=preg_replace("/[^ \w]+/", "", $courseToolSectionTitle);
    //             $toolIdArr = !empty($toolInfo['tool_id']) ? $toolInfo['tool_id'] : array();
    //             if (!empty($courseToolSectionTitle) && is_array($toolIdArr) && !empty($toolIdArr)) {
    //                 /**
    //                  * Check If Bundle Tool Category Exist.
    //                  */
    //                 $toolCategoryRes = $this->_checkIfToolCategoryExist($objProductSectionData, $courseToolSectionTitle, $bundleId);
    //                 if (empty($toolCategoryRes)) {
    //                     /**
    //                      * 1. Create the bundle tool category in productSectionData.
    //                      * 2. Link the bundle tool category to bundle in sectionMapping | linkable type: bundle,linkable_id:course id,section_id : bundle tool category
    //                      * 3. Link the tool ids to bundle tool category id in sectionMapping | linkable type: toolcategory,linkable_id:bundle tool category ,section_id : tool id
    //                      */
    //                     $sectionType = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE_TOOL_CATEGORY;
    //                     $param['bundle_id_arr'] = array($bundleId);
    //                     $param['sectionType'] = $sectionType;
    //                     $param['sectionTitle'] = $courseToolSectionTitle;
    //                     $param['name'] = $courseToolSectionTitle;
    //                     $sectionId = $objProductSectionData->saveProductSectionData($param);
    //                     if (!empty($sectionId)) {
    //                         $linkableId = $sectionId;
    //                         $existingCourseCatToolArr[$linkableId] = $toolIdArr;
    //                         $linkableType = $sectionType;
    //                         $response = $objSectionMapping->saveProductSectionData($linkableId, $linkableType, $toolIdArr, true);
    //                     }
    //                 } else {
    //                     /**
    //                      * Update Tools If Tool Ids Not Empty.
    //                      */
    //                     $linkableId = key($toolCategoryRes);
    //                     $existingCourseCatToolArr[$linkableId] = $toolIdArr;
    //                     $linkableType = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE_TOOL_CATEGORY;
    //                     $objSectionMapping->saveProductSectionData($linkableId, $linkableType, $toolIdArr, false);
    //                     $sectionMapId=!empty($toolCategoryRes[$linkableId][0]['id']) ? $toolCategoryRes[$linkableId][0]['id']:0;
    //                     if($sectionMapId){
    //                         $objSectionMapping->updateProductSectionData($sectionMapId);
    //                     }
    //                 }
    //             } elseif (!empty($courseToolSectionTitle) && empty($toolIdArr)) {
    //                 $sectionRes = $objProductSectionData->getLinkabaleInfoBySectionName($courseToolSectionTitle, BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE_TOOL_CATEGORY, $bundleId);
    //                 if (!empty($sectionRes)) {
    //                     $sectionId = key($sectionRes);
    //                     if (!empty($sectionRes[$sectionId])) {
    //                         $linkableInfo = array_column($sectionRes[$sectionId], 'linkable_id');
    //                         /**
    //                          * Verify If Section Id Belong To The Bundle Id we are updating.
    //                          */
    //                         if (in_array($bundleId, $linkableInfo)) {
    //                             $linkableId = $sectionId;
    //                             $linkableType = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE_TOOL_CATEGORY;
    //                             $updateStatus = $objProductSectionData->updateToolProductSectionData($linkableId, $linkableType);
    //                         }
    //                     }
    //                 }
    //             }
    //         }
    //         /**
    //          * Get all existing Bundle tool categories and tools.
    //          */
    //         $toolLinkableType = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES;
    //         $toolSectionType = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE_TOOL_CATEGORY;
    //         $courseTool = $this->_getBundleToolCategories($objProductSectionData, $bundleId, $toolLinkableType, $toolSectionType);
    //         $courseCategoryToolArr = array();
    //         if (!empty($courseTool['courseToolsFeature']) && !empty($existingCourseCatToolArr)) {
    //             $existingCourseCatKeyArr = array_keys($existingCourseCatToolArr);
    //             $courseCategoryToolArr = $courseTool['courseToolsFeature'];
    //             $courseCategoryToolKeyArr = array_keys($courseCategoryToolArr);
    //             $courseToolCategoryDiff = array_diff($courseCategoryToolKeyArr, $existingCourseCatKeyArr);
    //             if (is_array($courseToolCategoryDiff) && !empty($courseToolCategoryDiff)) {
    //                 foreach ($courseCategoryToolKeyArr as $courseCatToolId) {
    //                     if (!in_array($courseCatToolId, $existingCourseCatKeyArr)) {
    //                         $linkableId = $courseCatToolId;
    //                         $linkableType = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE_TOOL_CATEGORY;
    //                         $toolIdArr = !empty($courseCategoryToolArr[$linkableId]['tool_id']) ? $courseCategoryToolArr[$linkableId]['tool_id'] : array();
    //                         /**
    //                          * Update Bundle Tool Category In Product Section Data and set status to zero(0).
    //                          */
    //                         $updateResponse = $objProductSectionData->updateToolProductSectionData($linkableId, $linkableType);
    //                         if ($updateResponse === TRUE) {
    //                             /**
    //                              * Update Section Mapping and set status to zero(0).
    //                              */
    //                             $objSectionMapping->saveProductSectionData($linkableId, $linkableType, array(), false);
    //                         }
    //                     }
    //                 }
    //             }
    //         };
    //     }
    // }

    /**
     * Check If Bundle Tool Catgeoriy Exist
     * @param Model_ProductSectionData $model
     * @param string $sectionName
     * @return array
     */
    private function _checkIfToolCategoryExist(Model_ProductSectionData $modelObj, $sectionName, $linkableId = 0) {
        $result = array();
        if (!empty($sectionName)) {
            $sectionType = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE_TOOL_CATEGORY;
            $toolLinkableType = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES;
            $data = $modelObj->getLinkabaleInfoBySectionName($sectionName, $sectionType, $linkableId, $toolLinkableType);
            if (!empty($data)) {
                $result = $data;
            }
        }
        return $result;
    }
    public function faqMoveAction() {
        $data = $this->getRequest()->getPost();
        $currentPos = $data['current_pos'];
        $finalPosition = $data['to_move_pos'];
        $message = '';
        $status = 'success';
        if (empty($data['course_faq_id']) || empty($data['current_pos']) || empty($data['to_move_pos'])) {
            $message = 'Missing data';
            $status = 'failed';
        } else {
            $objCourseFaq = new Model_CourseFaq();
            if ($currentPos != $finalPosition) {
                if (!$objCourseFaq->changeFaQOrder($data, $currentPos, $finalPosition)) {
                    $message = 'Failed to update';
                    $status = 'failed';
                }
            }
        }


        $this->_helper->layout->disableLayout();
        $this->view->data = array(
            'message' => $message,
            'status' => $status
        );
        $this->_redirect($_SERVER['HTTP_REFERER']);
    }

    public function faqDeleteAction() {
        $data = $this->getRequest()->getPost();
        $faqId = $data['faq_id'];
        $linkableId = $data['linkable_id'];
        $linkableType = $data['linkable_type'];
        $sectionType = $data['section_type'];
        $courseFaqId = array(
            'course_faq_id' => $faqId,
        );
        $faqData = array($courseFaqId);
        $faqData['linkable_id'] = $linkableId;
        $faqData['linkable_type'] = $linkableType;
        $message = '';
        $status = 'success';
        $objCourseFaq = new Model_CourseFaq();
        if (!$objCourseFaq->deleteCourseFaq($faqData, $sectionType)) {
            $message = 'Failed to update';
            $status = 'failed';
        }
        $this->_helper->layout->disableLayout();
        $this->view->data = array(
            'message' => $message,
            'status' => $status
        );
        die(Zend_Json_Encoder::encode($this->view->data));
    }
    public function faqDisableAction() {
        $data = $this->getRequest()->getPost();
        $faqId = $data['faq_id'];
        $linkableId = $data['linkable_id'];
        $linkableType = $data['linkable_type'];
        $sectionType = $data['section_type'];
        $crmStatus = $data['crmStatus'];
        $courseFaqId = array(
            'course_faq_id' => $faqId,
        );
        $faqData = array('content_ids' => array($courseFaqId));
        $faqData['linkable_id'] = $linkableId;
        $faqData['linkable_type'] = $linkableType;
        $faqData['cluster_id'] = $data['cluster_id'];
        $faqData['country_id'] = $data['country_id'];
        $faqData['city_id'] = 0;
        $message = '';
        $status = 'success';
        $objCourseFaq = new Model_CourseFaq();
        if (!$objCourseFaq->disableCourseFaq($faqData, $sectionType,$crmStatus)) {
            $message = 'Failed to update';
            $status = 'failed';
        }
        $this->_helper->layout->disableLayout();
        $this->view->data = array(
            'message' => $message,
            'status' => $status
        );
        die(Zend_Json_Encoder::encode($this->view->data));
    }
    /**
     * Bundle Accreditor Primary And Secondary
     * @param array $data
     * @return boolean
     */
    public function bundleAccreditors($data = array()) {
        if (!empty($data)) {
            $objSectionMapping = new Model_SectionMapping();
            $objProductSectionData = new Model_ProductSectionData();
            $accreditorMappingObj = new Model_AccreditorMapping();
            $sectionTypePrimary = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_PRIMARY_ACCREDITOR;
            $sectionTypeSecondary = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_SECONDARY_ACCREDITOR;
            $bundleId = (int) $data['bundleId'];
            $accreditors = $data['bundleAccreditors'];
            $bundleAccreditorLabel = $objSectionMapping->getByLinkableIdLinkableType($bundleId, BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLE_ACCREDITOR_LABEL);
            $bundlePrimaryAccreditorLabelArr = $bundleSecondaryAccreditorLabelArr = array();
            if(!empty($bundleAccreditorLabel)){
                // Primary Label
                if(!empty($bundleAccreditorLabel['bundleprimaryaccreditor'])){
                    $bundlePrimaryAccreditorLabelArr = $bundleAccreditorLabel['bundleprimaryaccreditor'][0];
                }
                // Secondary Label
                if(!empty($bundleAccreditorLabel['bundlesecondaryaccreditor'])){
                    $bundleSecondaryAccreditorLabelArr = $bundleAccreditorLabel['bundlesecondaryaccreditor'][0];
                }
            }
            /**
             * Get All Bundle Accreditor Data
             */
            $conds = array(
                'linkable_id=?' => $bundleId,
                'linkable_type IN (?)' => array($sectionTypePrimary, $sectionTypeSecondary),
            );
            $bundleAccreditorArr = $accreditorMappingObj->fetchAll($conds);
            if (!empty($bundleAccreditorArr)) {
                $primaryAccreditorMapping = $secondaryAccreditorMapping = array();
                foreach ($bundleAccreditorArr as $bundleAccreditorRow) {
                    if($bundleAccreditorRow['linkable_type'] == $sectionTypePrimary){
                        $id = $bundleAccreditorRow['id'];
                        $accreditorId = $bundleAccreditorRow['accreditor_id'];
                        $primaryAccreditorMapping[$id]=$accreditorId;
                    }else if($bundleAccreditorRow['linkable_type'] == $sectionTypeSecondary){
                        $id = $bundleAccreditorRow['id'];
                        $accreditorId = $bundleAccreditorRow['accreditor_id'];
                        $secondaryAccreditorMapping[$id]=$accreditorId;
                    }
                }
                // Primary Accreditor
                $primaryAccreditorsToRemove = $primaryAccreditorToAdd = array();
                if(!empty($primaryAccreditorMapping) && !empty($accreditors['primary']) && !empty($accreditors['primary']['accreditorsId'])){
                    $selectedPrimaryAccreditorIds = $accreditors['primary']['accreditorsId']; 
                    $primaryAccreditorsToRemove = array_diff($primaryAccreditorMapping,$selectedPrimaryAccreditorIds);
                    $primaryAccreditorToAdd = array_diff($selectedPrimaryAccreditorIds,$primaryAccreditorMapping);
                    unset($accreditors['primary']['accreditorsId']);
                    if(!empty($primaryAccreditorToAdd)){
                        $accreditors['primary']['accreditorsId'] = array_values($primaryAccreditorToAdd);
                    }
                }else if(!empty($primaryAccreditorMapping) && empty($accreditors['primary'])){
                    $primaryAccreditorsToRemove = $primaryAccreditorMapping;
                }
                // Secondary Accreditor
                $secondaryAccreditorsToRemove = $secondaryAccreditorToAdd = array();
                if(!empty($secondaryAccreditorMapping) && !empty($accreditors['secondary']) && !empty($accreditors['secondary']['accreditorsId'])){
                    $selectedSecondaryAccreditorIds = $accreditors['secondary']['accreditorsId']; 
                    $secondaryAccreditorsToRemove = array_diff($secondaryAccreditorMapping,$selectedSecondaryAccreditorIds);
                    $secondaryAccreditorToAdd = array_diff($selectedSecondaryAccreditorIds,$secondaryAccreditorMapping);
                    unset($accreditors['secondary']['accreditorsId']);
                    if(!empty($secondaryAccreditorToAdd)){
                        $accreditors['secondary']['accreditorsId'] = array_values($secondaryAccreditorToAdd);
                    }
                }else if(!empty($secondaryAccreditorMapping) && empty($accreditors['secondary'])){
                    $secondaryAccreditorsToRemove = $secondaryAccreditorMapping;
                }
                // Merge Primary & Secondary Accreditor To Remove
                $bundleAccreditorToRemove = $primaryAccreditorsToRemove + $secondaryAccreditorsToRemove;
                if (!empty($bundleAccreditorToRemove)){
                    $accreditorIdToRemove = array();
                    foreach ($bundleAccreditorToRemove as $key=>$value) {
                        $rowId = $key;
                        $accreditorIdToRemove[]= $rowId; 
                        $accreditorMappingObj->clean();
                        $accreditorMappingObj->setId($rowId);
                        $accreditorMappingObj->delete();
                    }
                }
            }
            // Add Primary Accreditors
            $primaryAccreditors = !empty($accreditors['primary']) ? $accreditors['primary'] : array();
            $primaryAccreditorLabel = $secondaryAccreditorLabel = '';
            $accreditorIds = !empty($primaryAccreditors['accreditorsId']) ? $primaryAccreditors['accreditorsId']: array();
            $primaryAccreditorLabel = !empty($primaryAccreditors['label']) ? $primaryAccreditors['label']:'';
            // Save Primary Accreditor
            if (!empty($accreditorIds)) {
                foreach ($accreditorIds as $accreditorId) {
                    $accreditorRow = array();
                    $accreditorRow['accreditor_id'] = $accreditorId;
                    $accreditorRow['linkable_type'] = $sectionTypePrimary;
                    $accreditorRow['linkable_id'] = $bundleId;
                    $accreditorMappingObj->setFromArray($accreditorRow)->save();
                }
            }
            //Save Primary Label
            if(empty($bundlePrimaryAccreditorLabelArr) || (!empty($bundlePrimaryAccreditorLabelArr) && !empty($bundlePrimaryAccreditorLabelArr['sectionTitle']) && strcmp($bundlePrimaryAccreditorLabelArr['sectionTitle'],$primaryAccreditorLabel) !==0)){
                if(!empty($bundlePrimaryAccreditorLabelArr['sectionTitle']) && !empty($bundlePrimaryAccreditorLabelArr['section_id'])){
                    $objProductSectionData->disableProductSectionById($bundlePrimaryAccreditorLabelArr['section_id'],$bundleId,BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLE_ACCREDITOR_LABEL);
                }
                if (!empty($primaryAccreditorLabel)) {
                    $param = array();
                    $param['bundle_accreditor_id_arr'] = array($bundleId);
                    $param['sectionType'] = $sectionTypePrimary;
                    $param['sectionTitle'] = $primaryAccreditorLabel;
                    $objProductSectionData->saveProductSectionData($param);
                }
            }
            //Add Secondary Accreditors
            $secondaryAccreditors = !empty($accreditors['secondary']) ? $accreditors['secondary'] : array();
            $accreditorIds = !empty($secondaryAccreditors['accreditorsId']) ? $secondaryAccreditors['accreditorsId']:array();
            $secondaryAccreditorLabel = !empty($secondaryAccreditors['label']) ? $secondaryAccreditors['label'] : '';
            if (!empty($accreditorIds)) {
                foreach ($accreditorIds as $accreditorId) {
                    $accreditorRow = array();
                    $accreditorRow['accreditor_id'] = $accreditorId;
                    $accreditorRow['linkable_type'] = $sectionTypeSecondary;
                    $accreditorRow['linkable_id'] = $bundleId;
                    $accreditorMappingObj->setFromArray($accreditorRow)->save();
                }
            }
            //Save Secondary Label
            if(empty($bundleSecondaryAccreditorLabelArr) || (!empty($bundleSecondaryAccreditorLabelArr) && !empty($bundleSecondaryAccreditorLabelArr['sectionTitle']) && strcmp($bundleSecondaryAccreditorLabelArr['sectionTitle'],$secondaryAccreditorLabel) !==0)){
                if(!empty($bundleSecondaryAccreditorLabelArr['sectionTitle']) && !empty($bundleSecondaryAccreditorLabelArr['section_id'])){
                    $objProductSectionData->disableProductSectionById($bundleSecondaryAccreditorLabelArr['section_id'],$bundleId,BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLE_ACCREDITOR_LABEL);
                }
                if (!empty($secondaryAccreditorLabel)) {
                    $param = array();
                    $param['bundle_accreditor_id_arr'] = array($bundleId);
                    $param['sectionType'] = $sectionTypeSecondary;
                    $param['sectionTitle'] = $secondaryAccreditorLabel;
                    $objProductSectionData->saveProductSectionData($param);
                }
            }
        }
        return;
    }
    public function bundleUniversityMapping($data = array()) {
        if (!empty($data)) {
            $universityMappingObj = new Model_UniversityMapping();
            $sectionTypeBundle = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES;
            $bundleId = (int) $data['bundleId'];
            $universityId = $data['bundleUniversity'];
            /**
             * Get All Bundle university Data
             */
            $conds = array(
                'linkable_id=?' => $bundleId,
                'linkable_type IN (?)' => array($sectionTypeBundle),
            );
            $bundleUniversityArr = $universityMappingObj->fetchAll($conds);
            if (!empty($bundleUniversityArr)) {
                $bundleUniversityMapping = array();
                foreach ($bundleUniversityArr as $universityRow) {
                        $id = $universityRow['id'];
                        $accreditorId = $universityRow['university_id'];
                        $bundleUniversityMapping[$id]=$accreditorId;
                }
                $universitymappingToRemove = $universitymappingToAdd = array();
                if(!empty($bundleUniversityMapping) && !empty($universityId)){
                    $selectedPrimaryAccreditorIds = $universityId; 
                    $universitymappingToRemove = array_diff($bundleUniversityMapping,$selectedPrimaryAccreditorIds);
                    $universitymappingToAdd = array_diff($selectedPrimaryAccreditorIds,$bundleUniversityMapping);
                    unset($universityId);
                    if(!empty($universitymappingToAdd)){
                        $universityId = array_values($universitymappingToAdd);
                    }
                }else if(!empty($bundleUniversityMapping) && empty($universityId)){
                    $universitymappingToRemove = $bundleUniversityMapping;
                }
                if (!empty($universitymappingToRemove)){
                    $universityIdToRemove = array();
                    foreach ($universitymappingToRemove as $key=>$value) {
                        $rowId = $key;
                        $universityIdToRemove[]= $rowId; 
                        $universityMappingObj->clean();
                        $universityMappingObj->setId($rowId);
                        $universityMappingObj->delete();
                    }
                }
            }
            $bundleUniversityId = !empty($universityId) ? $universityId : array();

            // Save university in university_mapping
            if (!empty($bundleUniversityId)) {
                    $univerityData = array();
                    $univerityData['university_id'] = $bundleUniversityId;
                    $univerityData['linkable_type'] = $sectionTypeBundle;
                    $univerityData['linkable_id'] = $bundleId;
                    $universityMappingObj->setFromArray($univerityData)->save();
            }

    }
}

private function _setContentBundle(&$request, $show = true) {
    $session = new Zend_Session_Namespace('form');
    if ($show) {        
        if (isset($request['aboutBundle']) && count($request['aboutBundle'])) {
            $request['aboutBundle'] = $this->_updateFirstElement($request['aboutBundle']);
            $session->contentBundle = array_keys($request['aboutBundle']);
            array_unshift($session->contentBundle, '__template__');
            if (isset($request['aboutBundle']['new']) && isset($request['aboutBundle']['new']['jobdesignation'])){
                unset($request['aboutBundle']['new']['jobdesignation']['__template__']);
            }
            $session->contentBundleData = $request['aboutBundle'];
        } else {
            $session->contentBundle = array('__template__', 'new');
            $session->contentBundleData = array();
        }
    } else {         
        $session->contentBundleData = array();
        $session->contentBundle = array();
    }
}

 /**
     * Saves course job designation if it is benefit type 
     * saves job in Product section Table
     * Maps faq and hiring company in session mapping
     * saves salary in salary table
     */
    private function _saveBundleJobDesignations($data, $faqId){
        try{
            $sessionMapping = new Model_ProductSectionData();
            $existingJobs = $sessionMapping->getDataByType($faqId, BaseApp_Dao_SectionMapping::COURSE_FAQ_LINKABLE_TYPE , BaseApp_Dao_ProductSectionData::JOB_DESIGNATION_SECTION_TYPE, true, 'sm.id ASC');
            //Saving existing and updated jobs to compare and delete the removed jobs.
            $existingJobsArr = array();
            $productMapArr = array();
            $updatedJobsArr = array();
            $newJobsArr = array();
            if (!empty($existingJobs)) {
                foreach($existingJobs as $existingJob){
                    $existingJobsArr[$existingJob['id']] = $existingJob['section_id'];
                    $productMapArr[$existingJob['id']] = $existingJob['section_id'];
                } 
            }

            if(!empty($data)){
                foreach($data as $key => $job){
                    if(!empty($job)){
                        if ($key=== '__template__'){
                            continue;
                        }
                        $productSectionFaq = array(); 
                        $productSection = new Model_ProductSectionData();
                        $productSectionFaq['name'] = $job['designation'];
                        $productSectionFaq['sectionType'] = "job_designation";
                        $productSectionFaq['course_faq_id_arr']= array();
                        $productSectionFaq['hiring_company_arr'] = explode(',',$job['company_ids']);
                        array_push($productSectionFaq['course_faq_id_arr'], $faqId);                        
                        if (empty($job['section_id'])){
                            $produtSectionId = $productSection->saveProductSectionData($productSectionFaq);
                            $produtSectionMapId = $productSection->segmentMapId;
                            $newJobsArr[$produtSectionMapId] = $produtSectionId;
                            $productMapArr[$produtSectionMapId] = $produtSectionId;
                            //no insert to city
                        } else {
                            $produtSectionId = $job['section_id'];
                            $produtSectionMapId = $job['section_map_id'];
                            if (!$productSection->updateProductSectionData($produtSectionId, $productSectionFaq,BaseApp_Dao_CourseFaq::COURSE_RESOURCE_BENEFITS,$produtSectionMapId)){
                                throw new BaseApp_Exception('Job designation culd not be updated');
                            }          
                            
                            $produtSectionMapId = $productSection->segmentMapId;
                            //saving the jobs that are left after update. To compare and delete the removed ones.
                            $updatedJobsArr[$produtSectionMapId] = $produtSectionId;
                            $productMapArr[$produtSectionMapId] = $produtSectionId;
                        }              
                        
                        if ($produtSectionId){
                            //saving job salaries
                            //check if salary exists and delete them 
                            $salaries = new Model_Salaries();
                            $salaryData = array(
                                'min' => $job['min'],
                                'avg' => $job['avg'],
                                'max' => $job['max']                      
                            );                        
                            if (!$salaries->saveSalaries($salaryData, $produtSectionId,$produtSectionMapId)){
                                throw new BaseApp_Exception('Could not save Job salaries  mapping');
                            }

                        } else {
                            throw new BaseApp_Exception('Could not save Job designation');
                        }
                    }                
                }
            }
            $this->_deleteTheRemovedJobs($existingJobsArr, $newJobsArr, $updatedJobsArr,$productMapArr);
            return true;
        }  catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }        
    }


    /**
     * Checks if there is content already existing for the country specified
     * @return boolean
     */
    private function _contentExistsForCountry($courseId, $contentType, $trainingId, $clusterId, $countryId) {         
        $objCourseFaq = new Model_CourseFaq();
        $contentCountryId = !empty($countryId) ? $countryId: 0;
        $countryContent = $objCourseFaq->getDataByTypeAndContentId($courseId, "bundle", $contentType, $trainingId, $clusterId, $contentCountryId);
        if (!empty($countryContent)) {
            foreach($countryContent as $content) {
                if ($content['countryIds'] == $countryId) {                    
                    return true;
                }
            }
        }
        
        return false;
   }

   /**
     * Saves course job designation if it is benefit type 
     * saves job in Product section Table
     * Maps faq and hiring company in session mapping
     * saves salary in salary table
     */
    private function _saveCourseJobDesignations($data, $faqId){
        try{
            $sessionMapping = new Model_ProductSectionData();
            $existingJobs = $sessionMapping->getDataByType($faqId, BaseApp_Dao_SectionMapping::COURSE_FAQ_LINKABLE_TYPE , BaseApp_Dao_ProductSectionData::JOB_DESIGNATION_SECTION_TYPE, true, 'sm.id ASC');
            //Saving existing and updated jobs to compare and delete the removed jobs.
            $existingJobsArr = array();
            $productMapArr = array();
            $updatedJobsArr = array();
            $newJobsArr = array();
            if (!empty($existingJobs)) {
                foreach($existingJobs as $existingJob){
                    $existingJobsArr[$existingJob['id']] = $existingJob['section_id'];
                    $productMapArr[$existingJob['id']] = $existingJob['section_id'];
                } 
            }

            if(!empty($data)){
                foreach($data as $key => $job){
                    if(!empty($job)){
                        if ($key=== '__template__'){
                            continue;
                        }
                        $productSectionFaq = array(); 
                        $productSection = new Model_ProductSectionData();
                        $productSectionFaq['name'] = $job['designation'];
                        $productSectionFaq['sectionType'] = "job_designation";
                        $productSectionFaq['course_faq_id_arr']= array();
                        $productSectionFaq['hiring_company_arr'] = explode(',',$job['company_ids']);
                        array_push($productSectionFaq['course_faq_id_arr'], $faqId);                        
                        if (empty($job['section_id'])){
                            $produtSectionId = $productSection->saveProductSectionData($productSectionFaq);
                            $produtSectionMapId = $productSection->segmentMapId;
                            $newJobsArr[$produtSectionMapId] = $produtSectionId;
                            $productMapArr[$produtSectionMapId] = $produtSectionId;
                            //no insert to city
                        } else {
                            $produtSectionId = $job['section_id'];
                            $produtSectionMapId = $job['section_map_id'];
                            if (!$productSection->updateProductSectionData($produtSectionId, $productSectionFaq,BaseApp_Dao_CourseFaq::COURSE_RESOURCE_BENEFITS,$produtSectionMapId)){
                                throw new BaseApp_Exception('Job designation culd not be updated');
                            }          
                            
                            $produtSectionMapId = $productSection->segmentMapId;
                            //saving the jobs that are left after update. To compare and delete the removed ones.
                            $updatedJobsArr[$produtSectionMapId] = $produtSectionId;
                            $productMapArr[$produtSectionMapId] = $produtSectionId;
                        }              
                        
                        if ($produtSectionId){
                            //saving job salaries
                            //check if salary exists and delete them 
                            $salaries = new Model_Salaries();
                            $salaryData = array(
                                'min' => $job['min'],
                                'avg' => $job['avg'],
                                'max' => $job['max']                      
                            );                        
                            if (!$salaries->saveSalaries($salaryData, $produtSectionId,$produtSectionMapId)){
                                throw new BaseApp_Exception('Could not save Job salaries  mapping');
                            }

                        } else {
                            throw new BaseApp_Exception('Could not save Job designation');
                        }
                    }                
                }
            }
            $this->_deleteTheRemovedJobs($existingJobsArr, $newJobsArr, $updatedJobsArr,$productMapArr);
            return true;
        }  catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }        
    }

    private function _deleteTheRemovedJobs($existingJobsArr, $newJobsArr, $updatedJobsArr,$productMapArr){
        $renewJobsIds = array_diff(array_keys($existingJobsArr),array_keys($updatedJobsArr));
        $removedJobsIds = array_diff(array_values($existingJobsArr),array_values($updatedJobsArr));
        try{
            if (!empty($renewJobsIds)) {
                foreach($renewJobsIds as $renewJobId){
                    $sectionMapObj = new Model_SectionMapping();
                    $sectionMapObj->clean();
                    $sectionMapObj->setId($renewJobId);
                    $sectionMapObj->setFromArray(array('status' => 0))->update();
                    
                    //disable section Mapping by id
                    $salaryObj = new Model_Salaries();
                    $salaryObj->deleteSalaryBySectionMapId($renewJobId);
                }
            }

            if(!empty($removedJobsIds)){
                foreach($removedJobsIds as $removedJobsId){
                    foreach(array(BaseApp_Dao_SectionMapping::COURSE_FAQ_LINKABLE_TYPE ,BaseApp_Dao_SectionMapping::HIRING_COMPANY_LINKABLE_TYPE ) as $linkableTypeNew){
                        $sectionMapObj = new Model_SectionMapping();
                        $checkExisting = $sectionMapObj->fetchAll(array('linkable_type =?'=>$linkableTypeNew,'section_id =?'=> $removedJobsId));
                        if(!empty($checkExisting)){
                            foreach ($checkExisting as $key => $value) {
                                $sectionMapObj->clean();
                                $sectionMapObj->setId($value['id']);
                                $sectionMapObj->setFromArray(array('status'=>0))->update();
                            }
                        }
                    }
                }
            }
        }  catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        } 
    }



    // saveGeoSepecificIndividualData();
    /**
     * @data array key same as in the table strucutre
     */
    private function _saveGeoSepecificIndividualData($data, $sectionType, $faqId) {
        try {
            if(empty($data) || empty($sectionType) || empty($faqId)) {
                return false;
            }
            
            // existing check
            $productSection = new Model_ProductSectionData();
            $sessionMapping = new Model_ProductSectionData();
            $existingData = $sessionMapping->getDataByType($faqId, BaseApp_Dao_SectionMapping::COURSE_FAQ_LINKABLE_TYPE , $sectionType, true, 'sm.id ASC');
             
            if(empty($existingData)) {
                // insert new
                // save product section data & get secction id
                $saveData = array_merge($data, array(
                    'sectionType' => $sectionType,
                    'course_faq_arr' => [$faqId],
                ));                 
                $produtSectionId = $productSection->saveProductSectionData($saveData);                
            } else {
                // update by section id will get from here $existingData
                
                $sectionId = array_values($existingData)[0]['section_id'];
                 
                $productSection->setId($sectionId);
                $setData = $data;
                $productSection->setFromArray($setData)->update();
            }
            return true;
     
            //$existingJobs = $sessionMapping->getDataByType($faqId, BaseApp_Dao_SectionMapping::COURSE_FAQ_LINKABLE_TYPE , $sectionType, true, 'sm.id ASC');
            //Saving existing and updated jobs to compare and delete the removed jobs.
            // $existingJobsArr = array();
 
        }  catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }        
    }
    /**
     * handleProjectAdvantageSection
     */
    private function handleProjectAdvantageSection($data)
    {   
        $this->handleIntroSection($data);
        $this->handleIdealCandidateSection($data);
    }

    /**
     * 
     */

    private function handleIntroSection($data)
    {
        $introSectionData = array();
        $introSectionData['sectionTitle'] = !empty($data['Intro']) ? $data['Intro'] :'';
        $introSectionData['name'] = !empty($data['Intro']) ? $data['Intro'] :'';
        $introSectionData['description'] = !empty($data['Intro']) ? $data['Intro'] :'';
        $introSectionData['productId'] = !empty($data['productId']) ? $data['productId'] :'';
        $introSectionData['sectionType'] = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_PROGRAM_INTRO;
        $introSectionData['sectionId'] = !empty($data['introSectionId']) ? $data['introSectionId'] :'';
        $this->handleProductSectionData($introSectionData,false);
    }
    private function handleIdealCandidateSection($data)
    {
        $idealintroData = array();
        $idealintroData['name'] = !empty($data['ideal_intro']) ? $data['ideal_intro'] :'';
        $idealintroData['description'] = !empty($data['ideal_intro']) ? $data['ideal_intro'] :'';
        $idealintroData['sectionTitle'] = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_IDEAL_CANDIDATE_INRO;
        $idealintroData['productId'] = !empty($data['productId']) ? $data['productId'] :'';
        $idealintroData['sectionType'] = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_IDEAL_CANDIDATE;
        $idealintroData['sectionId'] = !empty($data['intro_id']) ? $data['intro_id'] :'';

        $this->handleProductSectionData($idealintroData,false);
        $idealAudienceData = array();
        $idealAudienceData['name'] = !empty($data['audience']) ? $data['audience'] :'';
        $idealAudienceData['description'] = !empty($data['audience']) ? $data['audience'] :'';
        $idealAudienceData['sectionTitle'] = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_IDEAL_CANDIDATE_AUDIENCE;
        $idealAudienceData['productId'] = !empty($data['productId']) ? $data['productId'] :'';
        $idealAudienceData['sectionType'] = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_IDEAL_CANDIDATE;
        $idealAudienceData['sectionId'] = !empty($data['audience_id']) ? $data['audience_id'] :'';

        $this->handleProductSectionData($idealAudienceData,false);
        $idealEligibilityData = array();
        $idealEligibilityData['name'] = !empty($data['eligibility']) ? $data['eligibility'] :'';
        $idealEligibilityData['description'] = !empty($data['eligibility']) ? $data['eligibility'] :'';
        $idealEligibilityData['sectionTitle'] = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_IDEAL_CANDIDATE_ELIGIBILITY;
        $idealEligibilityData['productId'] = !empty($data['productId']) ? $data['productId'] :'';
        $idealEligibilityData['sectionType'] = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_IDEAL_CANDIDATE;
        $idealEligibilityData['sectionId'] = !empty($data['eligibility_id']) ? $data['eligibility_id'] :'';

        $this->handleProductSectionData($idealEligibilityData,false);

    }
    /**
     * 
     */
    private function handleProductSectionData($data,$isEncode = true){
        $sectionTitle = !empty($data['sectionTitle']) ? $data['sectionTitle'] : '';
        $name = !empty($data['name']) ? $data['name'] : '';
        $productId =    !empty($data['productId']) ? $data['productId'] : '';
        $sectionType =    !empty($data['sectionType']) ? $data['sectionType'] : '';
        $sectionId = !empty($data['sectionId']) ? $data['sectionId'] : '';

        $objProductSectionData = new Model_ProductSectionData();
        
        $saveData  = array();
        if (!empty($name)) {
            $name = !empty($isEncode) ? preg_replace("/[^ \w]+/", "", htmlentities(htmlspecialchars(trim($name)), ENT_COMPAT, 'utf-8')) : $name;       
            $saveData['bundle_id_arr'] = array($productId);
            $saveData['sectionType'] = $sectionType;
            $saveData['sectionTitle'] = $sectionTitle;
            $saveData['name'] = $name;
            $saveData['description'] = !empty($data['description']) ? $data['description'] : '';
        }
        /**
         * edit
         */
        if (!empty($sectionId)) {
            if (empty($name)) {
                $linkableId = $sectionId;
                $linkableType = $sectionType;
                $objProductSectionData->updateToolProductSectionData($linkableId, $linkableType);
                $objSectionMapping = new Model_SectionMapping();
                $updateStatus = $objSectionMapping->disableSecMapBySectionId($productId, BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES, $linkableId);
            } else {
                unset($saveData['bundle_id_arr']);
                $objProductSectionData->updatedPSDataProjects($sectionId, $saveData);
            }
        } else {
            /**
             * Save
             */
            if (!empty($name)) {
                $objProductSectionData->saveProductSectionData($saveData);
            }
        }
    }

    private function _getSectionData($linkableId, $linkableType, $sectionType)
    {
        $objProductSectionData = new Model_ProductSectionData();
        $sectionData = $objProductSectionData->getDataByType($linkableId, $linkableType, $sectionType);
        $sectionData = !empty($sectionData) ? current($sectionData) : array();
        return $sectionData;
    }

    private function _setProjects($request)
    {
        $session = new Zend_Session_Namespace('form');
        if (isset($request['projects']) && count($request['projects'])) {

            $request['projects'] = $this->_updateFirstElement($request['projects']);
            $session->projects = array_keys($request['projects']);
            array_unshift($session->projects, '__template__');
            $session->projectsData =  $request['projects'];
        } else {
            $session->projects = array('__template__', 'new');
            $session->projectsData = array();
        }
    }

    private function handleProjectSection($title = '', $projectTitleSectionId, $parameter = array())
    {
        $productId = $parameter['bundleId'];
        $objProductSectionData = new Model_ProductSectionData();
        $projectTitle = htmlspecialchars(trim($title));
        $projectTitle = htmlentities($projectTitle, ENT_COMPAT, 'utf-8');
        $projectTitle = preg_replace("/[^ \w]+/", "", $projectTitle);
        $param['bundle_id_arr'] = array($productId);
        $param['sectionType'] = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE_PROJECTS_TITLE;
        $param['sectionTitle'] = $projectTitle;
        $param['name'] = $projectTitle;
        if (!empty($projectTitleSectionId)) {
            if (empty($title)) {
                $linkableId = $projectTitleSectionId;
                $linkableType = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE_PROJECTS_TITLE;
                $objProductSectionData->updateToolProductSectionData($linkableId, $linkableType);
                $objSectionMapping = new Model_SectionMapping();
                $updateStatus = $objSectionMapping->disableSecMapBySectionId($productId, BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES, $linkableId);
            } else {
                $objProductSectionData->updatedPSDataProjects($projectTitleSectionId, $param);
            }
        } else {
            if (!empty($title)) {
                $objProductSectionData->saveProductSectionData($param);
            }
        }
        if (!empty($parameter)) {
            $this->handleCourseProjects($parameter);
        }
    }

    private function handleCourseProjects($data = array())
    {  
        $objSectionMapping = new Model_SectionMapping();
        if (!empty($data)) {
            $productId = $data['bundleId'];
            $objProductSectionData = new Model_ProductSectionData();
            $newProductSectionData = array();
            foreach ($data['projects'] as $key => $project) {
                if ($key === '__template__') {
                    continue;
                }
                $companyContent = htmlspecialchars(trim($project['content']));
                $projectTitle = htmlspecialchars(trim($project['name']));
                $projectTitle = htmlentities($projectTitle, ENT_COMPAT, 'utf-8');
                $projectTitle = preg_replace("/[^ \w]+/", "", $projectTitle);
                $companyId = !empty($project['companyIds']) ? $project['companyIds'] : '';
                $sectionId = !empty($project['sectionId']) ? $project['sectionId'] : '';
                $sectionType = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE_PROJECTS;
                $param['bundle_id_arr'] = array($productId);
                $param['sectionType'] = $sectionType;
                $param['sectionTitle'] = $projectTitle;
                $param['name'] = $projectTitle;
                $param['description'] = $companyContent;
                $companyIds = array();
                if(!empty($companyId)){
                    $companyIds = array($companyId);
                }
                $isStatus = false;
                if (!empty($sectionId)) {
                    $newProductSectionData[$sectionId] = $sectionId;
                    if (empty($param['name']) && empty($param['description'])) {
                        $isStatus = true;
                        $linkableId = $sectionId;
                        $linkableType = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE_PROJECTS;
                        $updateResponse = $objProductSectionData->updateToolProductSectionData($linkableId, $linkableType);
                        $updateStatus = $objSectionMapping->disableSecMapBySectionId($productId, BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES, $linkableId);
                        $updateStatus = $objSectionMapping->disableSecMapBySectionId($companyId, 'hiring_company', $linkableId);

                    } else {
                        $objProductSectionData->updatedPSDataProjects($sectionId, $param);
                    }
                } else {
                    if (!(empty($param['name']) && empty($param['description']))) {
                        $sectionId = $objProductSectionData->saveProductSectionData($param);
                    }
                }
                if (!empty($sectionId) && empty($isStatus)) {
                    $newProductSectionData[$sectionId] = $sectionId;
                    $objSectionMapping->saveProductSectionDataBySectionId($companyIds, 'hiring_company', $sectionId);
                }
            }
            $existingProjectsData = $objProductSectionData->getDataByType($productId, BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES, BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE_PROJECTS);
            $existingProjects = array_keys($existingProjectsData);
            $newCourseCategoryProjects = array_keys($newProductSectionData);
            $courseProjectsCategoryDiff = array_diff($existingProjects, $newCourseCategoryProjects);
            if (is_array($courseProjectsCategoryDiff) && !empty($courseProjectsCategoryDiff)) {
                foreach ($courseProjectsCategoryDiff as $projectId) {
                    if (!in_array($projectId, $newCourseCategoryProjects)) {
                        $linkableId = $projectId;
                        $linkableType = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE_PROJECTS;
                        $updateResponse = $objProductSectionData->updateToolProductSectionData($linkableId, $linkableType);
                        $updateStatus = $objSectionMapping->disableSecMapBySectionId($productId, BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES, $linkableId);
                        $updateStatus = $objSectionMapping->disableSecMapBySectionId('', 'hiring_company', $linkableId);
                    }
                }
            }
        }
    }

    private function _getCourseProjects(Model_ProductSectionData $modelObj, $linkableId, $linkableType, $sectionType,$order='')
    {
        $sectionObj = new Model_SectionMapping();
        $formattedData = array();
        $courseProjectCategoryData = $modelObj->getDataByType($linkableId, $linkableType, $sectionType,TRUE,$order);
        if (is_array($courseProjectCategoryData) && !empty($courseProjectCategoryData)) {
            if (!empty($courseProjectCategoryData)) {
                foreach ($courseProjectCategoryData as $key => $value) {
                    $linkableId = $key;
                    $linkableType = 'hiring_company';
                    $toolsData = $sectionObj->getByProductSection($linkableType,$linkableId);
                    $bundleCategoryAndToolMap[$key]['name'] = $value['name'];
                    $bundleCategoryAndToolMap[$key]['content'] = $value['ps_description'];
                    $bundleCategoryAndToolMap[$key]['sectionId'] = $value['section_id'];
                    if(!empty($toolsData)){
                        $bundleCategoryAndToolMap[$key]['companyIds'] = current($toolsData);
                    }
                }
                if (!empty($bundleCategoryAndToolMap)) {
                    $formattedData['projects'] = $bundleCategoryAndToolMap;
                }
            }
        }
        return $formattedData;
    }
    private function bundleProjectSection($postData)
    {
        $parameter = array('bundleId' => $postData['productId']);
        if (!empty($postData['projects'])) {
            $parameter['projects'] = $postData['projects'];
        }
        $projectSectionTitle = !empty($postData['bundleProjectsDescription']) ? $postData['bundleProjectsDescription'] : '';
        $projectTitleSectionId = !empty($postData['projectTitleSectionId']) ? $postData['projectTitleSectionId'] : '';
        $this->handleProjectSection($projectSectionTitle, $projectTitleSectionId, $parameter);
    }
}
