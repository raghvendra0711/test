<?php
/*
 * Contains the CRUD actions of Reviews table
 * 
 */

class Admin_RefererController extends BaseApp_Controller_Crud {
    protected $_model = 'Model_Referers';
    protected $_descriptions = array(
        'list' => 'List of Existing Referers',
        'index' => 'List of Existing Referers',
        'add' => 'Add New Referers',
        'edit' => 'Make the required changes then click on "Save Reviews" to update the Referers',
        'view' => 'View Selected Referers'
    );

    protected function _getForm() {
        $form = new Form_Referers();
        return $form;
    }
    
    public function listAction() {
        $table = $this->getModel()->getName();
        $filterForm = new Form_Filters($table);
        $requestData = array();
        $queryParamsArr = array();
        $page = '';
        if($this->getRequest()->isPost()){
            $filterForm->populate($this->getRequest()->getPost());
            $page = 1;
            $requestData = $filterForm->getValues();
            foreach($requestData as $elementName => $elementValue) {
                if(!empty($elementValue)){
                    $queryData = $filterForm->getElement($elementName)->getAttrib('data-table');
                    $queryData['searchValue'] = $elementValue;
                    $this->queryBuilder($queryData);
                    $queryParamsArr[$queryData['search_id']] = $elementValue;
                } // end of !empty elementValue
            } // end of foreach RequestData
        } // end of if isPost
        if(empty($page)){
            $page = $this->view->navigatorPage;
            $page = (int)$this->getRequest()->getParam('page');
        }
        $orderby = $this->getModel()->getPk() . ' DESC';
        if(empty($this->_queryParams)){
            $getData = $this->getRequest()->getQuery();
            unset($getData['page']);
            if(!empty($getData)){
                foreach ($getData as $key => $value) {
                    $queryParamsArr[$key] = $value;
                    $returnData = $filterForm->getSearchFields($key);
                    if(!empty($returnData)){
                        $returnData = $returnData[0];
                        $filterForm->getElement($returnData['searchColumnName'])->setValue($value);
                        $returnData['searchValue'] = $value;
                        $this->queryBuilder($returnData);
                    }
                }
            }
        }
        if ($page <= 1) {
            $this->view->firstpage = true;
            $page = 1;
        } else {
            $this->view->firstpage = false;
        }
        $offset = ($page - 1) * self::ROWS_PER_PAGE;        
        $limit = array(self::ROWS_PER_PAGE,$offset);
        $this->view->page = $page;
        $model = $this->getModel();
        $data = $model->fetchAll($this->_queryParams, array('order' => array($orderby), 'limit' => $limit));
        $total = $model->fetchCount($this->_queryParams);
        $perPageData = count($data);
        $total = $model->fetchCount($this->_queryParams);
        if (count($data) < self::ROWS_PER_PAGE) {
            $this->view->lastpage = true;
        } else {
            $this->view->lastpage = false;
        }
        $numberOfPages = ceil($total / self::ROWS_PER_PAGE);
        if($page < $numberOfPages){
            $this->view->currentPageRecord = self::ROWS_PER_PAGE * $page;    
        }else{
            $this->view->currentPageRecord = $total;    
        }
        $this->view->diffPageRecord = $this->view->currentPageRecord - self::ROWS_PER_PAGE;
        if(count($data) < self::ROWS_PER_PAGE){
            $this->view->diffPageRecord = $total - count($data);
        }
        $this->view->totalCount = $total;
        $this->view->totalPages = $numberOfPages;
        $this->view->lastPage = $numberOfPages;

        $pk = $model->getPk();
        foreach ($data as &$row) {
            if(!empty($row['datetime']))
                $row['datetime'] = gmdate("Y-m-d H:i:s", $row['datetime']);
            $row['Action'] = "<a href='" . $this->view->url(array('action' => 'view', 'id' => $row[$pk])) . "'>View</a> ";
        }
        //================
        if(isset($data[0])){
            $original = array_keys($data[0]);
        }else{
            $original = array();
        }
        $as = ($this->_displayInDataTable);
        $datatableFilePath = '../../library/BaseApp/Datatable/'.ucfirst($table).'.php';       
        if(file_exists($datatableFilePath)) {
            $dataTableClass = 'BaseApp_Datatable_'.ucfirst($table);               
        }
        else{
            $dataTableClass = 'BaseApp_Datatable_Default';                            
        }

        $dataTable = new $dataTableClass;
        $dataTable->setData($data);
        $this->view->queryParams = http_build_query($queryParamsArr);
        $this->view->form = $filterForm;
        $this->view->data = $dataTable;
        $this->view->original = $original;
        $this->view->displayInDataTable = $as;
        $this->view->navigatorTotal = ceil($total / BACKEND_ROWS_PER_PAGE);
    }
}
