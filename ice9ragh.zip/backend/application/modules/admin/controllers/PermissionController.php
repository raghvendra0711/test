<?php

/*
 * Contains the CRUD actions of Accreditors table
 * 
 */

class Admin_PermissionController extends BaseApp_Controller_Backend {

    protected $_descriptions = array(
        'index' => 'List of Existing Role',
        'save' => 'List of Existing Role'
    );

    public function indexAction() {
        $module = new Model_Module;
        $permission = new Model_Permission;

        $communicator = new BaseApp_Communication_Accounts();
        $roles = $communicator->getSimplexRoles();
        $this->view->roles = array();
        if($roles[BaseApp_Communication_Accounts::STR_RESPONSE_KEY_STATUS] == BaseApp_Communication_Accounts::STR_SUCCESS) {            
            foreach($roles[BaseApp_Communication_Accounts::STR_RESPONSE_KEY_DATA] as $roleData) {
                $roleData['name'] = preg_replace('/'.BaseApp_Communication_Accounts::SIMPLEX_USER_ROLE_PREFIX.'/', '', $roleData['name']);
                $this->view->roles[$roleData['rid']] =$roleData['name'];
            }
        }        
        $this->view->modules = $module->fetchForSelect();
        $this->view->permissions = $permission->fetchAll();
    }

    public function saveAction() {
        $this->_helper->viewRenderer->setNoRender(true);
        $this->_helper->layout()->disableLayout();

        $post = array_keys($this->getRequest()->getPost());       
        if(!$post) {
            die("No data to save");
        }
        error_log(json_encode($post));
        $saveSuccess = false;
        $permission = new Model_Permission;
        $permission->getDb()->beginTransaction();
        $permission->getDb()->query('TRUNCATE TABLE ' . $permission->getName());
        foreach ($post as $permissionStr) {
            $permissionArr = explode('_', $permissionStr);
            $permission->clean();
            $permission->setFromArray(array(
                'module_id' => $permissionArr[1],
                'role_id' => $permissionArr[2],
            ));
            if($permission->save()) {
                $saveSuccess = true;
            }
        }
        if($saveSuccess) {
            $permission->getDb()->commit();
        }
        else {            
            $permission->getDb()->rollBack();
        }
    }
}
