<?php
/*
 * Contains the CRUD actions of Reviews table
 * 
 */

class Admin_ReviewController extends BaseApp_Controller_Crud {
    protected $_model = 'Model_Reviews';
    protected $_descriptions = array(
        'list' => 'List of Existing Reviews',
        'index' => 'List of Existing Reviews',
        'add' => 'Add New Reviews',
        'edit' => 'Make the required changes then click on "Save Reviews" to update the Reviews',
        'view' => 'View Selected Reviews'
    );

    protected function _getForm() {
        $form = new Form_Reviews();
        return $form;
    }
}
