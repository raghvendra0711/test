<?php
/*
 *CRUD for home page banners
 * 
 */

class Admin_HomePageBannerController extends BaseApp_Controller_Crud {
    protected $_model = 'Model_HomePageBanners';
    protected $_descriptions = array(
        'list' => 'List of Existing Banners',
        'add' => 'Add New Banner',
        'edit' => 'Make the required changes then click on "Save Banner" to update the Banner',
        'view' => 'View Selected Banner',
        'delete' => 'delete last displayed banner'
    );
    

    protected function _getForm() {
        $form = new Form_Banner();
        return $form;
    }

     public function addAction() {
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $form = new Form_Banner();
        $request = $this->getRequest()->getPost();
        if ($this->getRequest()->isPost() && $form->isValid($request)) {
            $data = $form->getValues();
            if(!empty($data['offer_bundle_id'])){
                if(isset($data['bundle_hidden_sort_add']) && !empty($data['bundle_hidden_sort_add'])){
                    if(count(explode(',',$data['bundle_hidden_sort_add'])) > 3){
                        $this->view->message = 'Cannot select more than three bundles';
                        $this->view->success = false;
                        $this->view->form = $form;
                        return false;
                    }
                }else{
                    $this->view->message = 'Please select atleast one bundle';
                    $this->view->success = false;
                    $this->view->form = $form;
                    return false;
                }
            }
            if(!$this->_isValidBanner($data, $message)) {
                $this->view->message = $message;
                $this->view->success = false;
                $this->view->form = $form;
                return false;
            }
            
            $result = $this->getModel()->addBanner($data);
            if (!$result) {
                $this->view->message = "An error has occured while saving";
                $this->view->success = true;
            } else {
                $objCourse = New Model_Courses($data['course_id']);
                $cdnPurgeData = $this->getModel()->buildCdnPurgeData($data['course_id'],'course','New workshop added for Course '.$objCourse->name);
                $objCdn = new Model_CdnPurgeLog();
                if(!empty($cdnPurgeData))
                    $objCdn->InsertCdnPurgeLog($cdnPurgeData);
                $this->view->message = "Saved SuccessFully";
                $this->view->success = false;
                $form->reset();
                $module  = $this->getRequest()->getModuleName();
                $controller = $this->getRequest()->getControllerName();
                $action = $this->getRequest()->getActionName();
                if($module && $controller && $action)
                    $this->redirect($module.'/'.$controller.'/list');
            }
        }
        $this->view->form = $form;
    }


    public function editAction() {
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $Id = $this->getRequest()->getParam('id');
        
        if(!$Id)
            throw new BaseApp_Exception('Editable item not selected properly');        
        $bannerData = current($this->getModel()->fetchAll(array('banner_id =?'=>$Id)));
        $bannerData['coupon_id'] = $bannerData['linkable_id'];
        $bannerData['validFrom'] = date('Y-m-d',$bannerData['banner_start_date']);
        $bannerData['validto'] = date('Y-m-d',$bannerData['banner_end_date']);

        $imageObj = new Model_Images();
        $imageData = $imageObj->fetchAll(array('linkable_type =?'=>'home_page_offer_banner','linkable_id =?'=>$Id));
        foreach ($imageData as $key => $value) {
            $bannerData[$value['name']] = $value['imagePath'];
        }
        $bannerData['offer_bundle_id_selected'] = 0;
        $objLookup = new Model_lookUp();
        $bundleBannerData = $objLookup->fetchAll(array('type =?'=>'home_page_offer_banner','name =?'=>$Id));
        if(!empty($bundleBannerData)){
            $bunleIds = array_column($bundleBannerData, 'description');
            $bannerData['offer_bundle_id_selected'] = 1;
            $bannerData['offer_bundle_list'] = $bunleIds;
        }
        unset($bannerData['linkable_id']);
        unset($bannerData['linkable_type']);
        if (!$bannerData) {
            throw new BaseApp_Exception('Editable item not selected properly');
        }
        $form = new Form_Banner($Id,$bannerData);
        if ($this->getRequest()->isPost()) { 
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            if ($form->isValid($this->getRequest()->getPost())) {
                $data = $form->getValues();
            
                if(!empty($data['offer_bundle_id_selected'])){
                    if(!empty($data['bundle_hidden_sort'])){
                        if(count(explode(',',$data['bundle_hidden_sort'])) > 3){
                            $this->view->message = 'Cannot select more than three bundles';
                            $this->view->success = false;
                            $this->view->form = $form;
                            return false;
                        }
                    }else{
                        $this->view->message = 'Please select bundles from the list ...!!';
                        $this->view->success = false;
                        $this->view->form = $form;
                        return false;
                    }
                }
                if(!$this->_isValidBanner($data, $message,$Id)) {
                    $this->view->message = $message;
                    $this->view->success = false;
                    $formData = array_merge($bannerData, $data);
                    $form->setDefaults($formData);
                    $this->view->form = $form;
                    return false;
                }
                $result = $this->getModel()->EditBanner($Id,$data);
                if (!$result) {
                    $this->view->message = "An error has occured while saving";
                    $this->view->success = true;
                    $module  = $this->getRequest()->getModuleName();
                    $controller = $this->getRequest()->getControllerName();
                    $action = $this->getRequest()->getActionName();
                    if($module && $controller && $action)
                        $this->redirect($module.'/'.$controller.'/'.$action.'/id/'.$Id);
                } else {
                    $form->reset();
                    $module  = $this->getRequest()->getModuleName();
                    $controller = $this->getRequest()->getControllerName();
                    $action = $this->getRequest()->getActionName();
                    if($module && $controller && $action)
                        $this->redirect($module.'/'.$controller.'/list');
                }
            }
            else {               
                $data = $form->getValues();
                $formData = array_merge($bannerData, $data);
                $form->setDefaults($formData);
                $form->removeUneditableElements();
            }
        }        
        else {
            $form->setDefaults($bannerData);
        }
        $this->view->form = $form;
    }

    /* delete function Calls an Api to check whether Payment Exists against it */
     public function deleteAction(){
        $this->_helper->viewRenderer->setRender('common/delete')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $Id = $this->getRequest()->getParam('id');
        
        if(!$Id)
            throw new BaseApp_Exception('Editable item not selected properly');        
        $bannerData = current($this->getModel()->fetchAll(array('banner_id =?'=>$Id)));
        if (!$bannerData) {
            throw new BaseApp_Exception('Editable item not selected properly');
        }
        $bannerData['coupon_id'] = $bannerData['linkable_id'];
        $bannerData['validFrom'] = date('Y-m-d',$bannerData['banner_start_date']);
        $bannerData['validto'] = date('Y-m-d',$bannerData['banner_end_date']);

        $imageObj = new Model_Images();
        $imageData = $imageObj->fetchAll(array('linkable_type =?'=>'home_page_offer_banner','linkable_id =?'=>$Id));
        foreach ($imageData as $key => $value) {
            $bannerData[$value['name']] = $value['imagePath'];
        }
        $bannerData['isBundle'] = 0;
        $objLookup = new Model_lookUp();
        $bundleBannerData = $objLookup->fetchAll(array('type =?'=>'home_page_offer_banner','name =?'=>$Id));
        if(!empty($bundleBannerData)){
            $bunleIds = array_column($bundleBannerData, 'description');
            $bannerData['isBundle'] = 1;
            $bannerData['offer_bundle_list'] = $bunleIds;
        }
        unset($bannerData['linkable_id']);
        unset($bannerData['linkable_type']);
        $form = new Form_Banner($Id,$bannerData);
        $result = $this->getModel()->deleteBanner($Id);
        if (!$result) {
            $this->view->message = "An error has occured while saving";
            $this->view->success = true;
            $module  = $this->getRequest()->getModuleName();
            $controller = $this->getRequest()->getControllerName();
            $action = $this->getRequest()->getActionName();
            if($module && $controller && $action)
                $this->redirect($module.'/'.$controller.'/'.$action.'/id/'.$Id);
        } else {
            $this->view->message = "Saved SuccessFully";
            $this->view->success = false;
            $form->reset();
            $module  = $this->getRequest()->getModuleName();
            $controller = $this->getRequest()->getControllerName();
            $action = $this->getRequest()->getActionName();
            if($module && $controller && $action)
                $this->redirect($module.'/'.$controller.'/list');
        }
    }

    public function listAction() {
        $this->_helper->viewRenderer->setRender('common/list')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $page = $this->view->navigatorPage;
        $table = $this->getModel()->getName();
        $filterForm = new Form_Filters($table);
        $requestData = array();
        $queryParamsArr = array();
        $page = '';
        if($this->getRequest()->isPost()){
            $filterForm->populate($this->getRequest()->getPost());
            $page = 1;
            $requestData = $filterForm->getValues();
            foreach($requestData as $elementName => $elementValue) {
                if(!empty($elementValue)){
                    $queryData = $filterForm->getElement($elementName)->getAttrib('data-table');
                    $queryData['searchValue'] = $elementValue;
                    $this->queryBuilder($queryData);
                    $queryParamsArr[$queryData['search_id']] = $elementValue;
                } // end of !empty elementValue
            } // end of foreach RequestData
        } // end of if isPost
        $orderby = $this->getModel()->getPk() . ' DESC';
        if(empty($page)){
            $page = $this->view->navigatorPage;
            $page = (int)$this->getRequest()->getParam('page');
        }
        if(empty($this->_queryParams)){
            $getData = $this->getRequest()->getQuery();
            unset($getData['page']);
            if(!empty($getData)){
                foreach ($getData as $key => $value) {
                    $queryParamsArr[$key] = $value;
                    $returnData = $filterForm->getSearchFields($key);
                    if(!empty($returnData)){
                        $returnData = $returnData[0];
                        $filterForm->getElement($returnData['searchColumnName'])->setValue($value);
                        $returnData['searchValue'] = $value;
                        $this->queryBuilder($returnData);
                    }
                }
            }
        }
        if ($page <= 1) {
            $this->view->firstpage = true;
            $page = 1;
        } else {
            $this->view->firstpage = false;
        }
        $offset = ($page - 1) * self::ROWS_PER_PAGE;        
        $limit = array(self::ROWS_PER_PAGE,$offset);
        $this->view->page = $page;
        $model = $this->getModel();
        $data = $model->fetchAll($this->_queryParams, array('order' => array($orderby), 'limit' => $limit));
        $perPageData = count($data);
        $total = $model->fetchCount($this->_queryParams);
        if (count($data) < self::ROWS_PER_PAGE) {
            $this->view->lastpage = true;
        } else {
            $this->view->lastpage = false;
        }

        $numberOfPages = ceil($total / self::ROWS_PER_PAGE);
        if($page < $numberOfPages){
            $this->view->currentPageRecord = self::ROWS_PER_PAGE * $page;    
        }else{
            $this->view->currentPageRecord = $total;    
        }
        $this->view->diffPageRecord = $this->view->currentPageRecord - self::ROWS_PER_PAGE;
        if(count($data) < self::ROWS_PER_PAGE){
            $this->view->diffPageRecord = $total - count($data);
        }
        $this->view->totalCount = $total;
        $this->view->totalPages = $numberOfPages;
        $this->view->lastPage = $numberOfPages;

        $total = $model->fetchCount();
        $table = $this->getModel()->getName();        
        //@TODO: Remove from controller and create an action helper.

        foreach ($data as $key => &$row) {
            $data[$key]['banner_start_date'] = date('Y-m-d h:i:s',$row['banner_start_date']);
            $data[$key]['banner_end_date'] = date('Y-m-d h:i:s',$row['banner_end_date']);
            $row['Action'] = "<a href='" . $this->view->url(array('action' => 'view', 'id' => $row['banner_id'])) . "'>View</a> " . "<a href='" . $this->view->url(array('controller' => 'changelog', 'action' => 'index', 'row' => $row['banner_id'], 'table' => $table)) . "'>ChangeLog</a> " .
                    "<a href='" . $this->view->url(array('action' => 'edit', 'id' => $row['banner_id'])) . "'>Edit</a> " .
                    "<a class='delete-crud-item' href='#' onclick='deleteConfirmShow(\"" . $this->view->url(array('action' => 'delete', 'id' => $row['banner_id'])) . "\");'>Delete</a> ";
        }
        //================
        if(isset($data[0])){
            $original = array_keys($data[0]);
        }else{
            $original = array();
        }
        $as = ($this->_displayInDataTable);
        //new datatable   
        //need to define path in ini file after discussion
        $datatableFilePath = '../../library/BaseApp/Datatable/'.ucfirst($table).'.php';       
        if(file_exists($datatableFilePath)) {
            $dataTableClass = 'BaseApp_Datatable_'.ucfirst($table);               
        }
        else{
            $dataTableClass = 'BaseApp_Datatable_Default';
        }
        $dataTableClass = 'BaseApp_Datatable_Default';
        $dataTable = new $dataTableClass;
        $dataTable->setData($data);
        $this->view->queryParams = http_build_query($queryParamsArr);
        $this->view->form = $filterForm;
        $this->view->data = $dataTable;
        $this->view->original = $original;
        $this->view->displayInDataTable = $as;
        $this->view->navigatorTotal = ceil($total / BACKEND_ROWS_PER_PAGE);
    }
    
    private function _isValidBanner($data, &$message,$bannerId = false){
    
        $message ='Invalid Selection made';
        // check is coupon is associated with any other active banner

        $conds = array('linkable_id = ?'=>$data['coupon_id'],'banner_end_date >= ?'=>time());        
        if(!empty($bannerId))
            $conds['banner_id <> ?'] = $bannerId;

        $checkFlag = current($this->getModel()->fetchAll($conds,array('order'=>array('banner_end_date DESC'),'limit'=>1),false));
        if(!empty($checkFlag)){
            if(strtotime($data['validFrom']) >= $checkFlag['banner_end_date']){
                // check if there exists a active banner for the country based on coupon's country Id
            }else{
                $message = 'there exists a active banner for this coupon.Refer Banner Id -'.$checkFlag['banner_id'];
                return false;    
            }
        }

        // check if there exists a active banner for the country based on coupon's country Id
        $conds = array('banner_end_date >= ?'=>time());
        if(!empty($bannerId))
            $conds['banner_id <> ?'] = $bannerId;
        $activeBanners = $this->getModel()->fetchAll($conds,array('columns' => array('linkable_id')),false);
        if(empty($activeBanners))
            return true;
        
        $couponObj =new Model_Coupons();
        $couponCountryData = current($couponObj->fetchAll(array('coupon_id =?'=>$data['coupon_id']),array('columns'=>array('country_id')),false));
        $countryCheckId = $couponCountryData['country_id'];
        $countryIdArr = explode(',',$countryCheckId);
        $couponIds = array_column($activeBanners,'linkable_id');
        $couponData = array();
        foreach ($countryIdArr as $key => $value) {
            $conds = array('FIND_IN_SET(?, country_id)>0' => $value,'validto >= ?'=>time(),'coupon_id in (?)'=>$couponIds);
            $couponRes = $couponObj->fetchAll($conds, array('columns' => array('coupon_id')), false);
            if(!empty($couponRes))
                array_push($couponData,current($couponRes));
        }

        if(empty($couponData))
            return true;
        
        $couponIds = array_column($couponData,'coupon_id');
        $conds = array('linkable_id in (?)'=>$couponIds,'banner_end_date >= ?'=>time());
        if(!empty($bannerId))
            $conds['banner_id <> ?'] = $bannerId;
        
        $checkFlag = current($this->getModel()->fetchAll($conds,array('order'=>array('banner_end_date DESC'),'limit'=>1),false));
        if(!empty($checkFlag)){
            if(strtotime($data['validFrom']) >= $checkFlag['banner_end_date']){
                return true;
            }else{
                $message = 'there exists a active banner for selected country.Refer Banner Id -'.$checkFlag['banner_id'];
                return false;    
            }
        }
        return true;
     }

}
