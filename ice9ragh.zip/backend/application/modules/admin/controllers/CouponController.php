<?php
/*
 * Contains the CRUD actions of Coupons table
 * 
 */

use Monolog\Logger;

class Admin_CouponController extends BaseApp_Controller_Crud {

    protected $_model = 'Model_Coupons';
    protected $_descriptions = array(
        'list' => 'List of Existing Coupons',
        'index' => 'List of Existing Coupons',
        'add-subscription' => 'Add New Coupons for Subscription',
        'add-course' => 'Add New Coupons for Course',
        'edit' => 'Make the required changes then click on "Save Coupons" to update the Coupons',
        'view' => 'View Selected Coupons',
        'update-expiry' => 'update validto Field'
    );

    protected function _getForm() {
        $form = new Form_CouponCourse();
        return $form;
    }

    public function addCourseAction() {
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $request = $this->getRequest()->getPost();
        $form = new Form_CouponCourse();
        $objCoupon = new Model_Coupons();
        $resultArr = array();
        if ($form === false)
            throw new Zend_Exception('_getForm not implemented');
                      
        if ($this->getRequest()->isPost() && $form->isValid($this->getRequest()->getPost())) {
            $data = $form->getValues();   
            file_put_contents(APPLICATION_PATH . '/../error.log', __METHOD__ .'add coupon data : '.  
            print_r($data,true), FILE_APPEND);                  
            unset($data['cluster_id_tmp']);
            unset($data['country_hid']); 
            unset($data['training_id_tmp']);         
            $data['validto'] = sprintf("%s 23:59:59", $data['validto']);
            $data['validFrom'] = sprintf("%s 00:00:00", $data['validFrom']);
            $data['validFrom'] = strtotime($data['validFrom']);
            $data['validto'] = strtotime($data['validto']);
            
            $fileData = $_FILES['coupoCsv'];
            $fileCouponCodes = array();
            $failCodesArr = array();
            $loopCount = 1;
            if(!empty($fileData['name'])){
                $fileCouponCodes = $this->_processFile($fileData);
                if(false === $fileCouponCodes){
                    $this->view->message = "5000 is the Limit.";
                    $this->view->success = false;
                    $this->view->form = $form;
                    return false;
                }
                $loopCount = count($fileCouponCodes);
                ini_set('max_execution_time', 300);
            }
            if(isset($data['displayFrontend']) && !empty($data['displayFrontend'])){
                $objCoupon = new Model_Coupons();
                $res = $objCoupon->checkCouponDisplay(   
                                                                !empty($data['course_id']) ? $data['course_id'] : array(),
                                                                !empty($data['country_id']) ? $data['country_id']:array(),
                                                                !empty($data['label_id']) ? $data['label_id'] : array(),
                                                                !empty($data['mom_id']) ? $data['mom_id'] : array(),
                                                                !empty($data['cluster_id']) ? $data['cluster_id'] : array(),
                                                                !empty($data['code']) ? $data['code'] : ''
                                                            );
                if(!empty($res)){
                    $this->view->message = "all these coupon id's are used to display on website".implode(',', $res);
                    $this->view->success = false;
                    $this->view->form = $form;
                    return false;
                }    
            }
            if($data['label_id']) {
                $modelCourses = new Model_Courses();
                $courses = $modelCourses->getbyLables($data['label_id']);
                if($data['course_id']) {
                    $data['course_id'] = array_merge($data['course_id'], array_keys($courses));                
                }
                else {
                    $data['course_id'] = array_keys($courses);
                    unset($courses);
                }
                $modelBundle = new Model_Bundles();
                $bundles = $modelBundle->getbyLables($data['label_id']);
                if($data['bundle_id']) {
                    $data['bundle_id'] = array_merge($data['bundle_id'], array_keys($bundles));                
                }
                else {
                    $data['bundle_id'] = array_keys($bundles);
                    unset($bundles);
                }
            }
            
            if($data['cluster_id']) {
                $modelCountry = new Model_Country();
                $countries = $modelCountry->fetchForSelect(array("cluster_id IN (?)"=>$data['cluster_id']), array(), false);
                if($data['country_id']) {
                    $data['country_id'] = array_merge($data['country_id'], array_keys($countries));
                }
                else {
                    $data['country_id'] = array_keys($countries);
                }  
            } 
            if(!empty($data['multi_bundle']) && $data['multi_bundle'] != "NONE") {
                $bundle = new Model_Bundles();
                if (!empty($data['bundle_id'])) {
                    $data['bundle_id'] = array_unique(array_merge($data['bundle_id'], array_keys($bundle->getAllBundles($data['multi_bundle']))));
                } else {
                    $data['bundle_id'] = array_keys($bundle->getAllBundles($data['multi_bundle']));
                }
            }

            

            if (!empty($data['multi_course']) && $data['multi_course'] != "NONE") {
                $modelCourses = new Model_Courses();
                if (!empty($data['course_id'])) {
                    $data['course_id'] = array_unique(array_merge($data['course_id'], array_keys($modelCourses->getAllCourses($data['multi_course']))));
                } else {
                    $data['course_id'] = array_keys($modelCourses->getAllCourses($data['multi_course']));
                }
            }
            
            if(!empty($data['all_countries']) && $data['all_countries']) {
                $objCluster =new Model_Clusters();
                $objCountry =new Model_Country();
                $data['cluster_id'] = array_keys($objCluster->fetchForSelect());
                $data['country_id'] = array_keys($objCountry->getListDisplay()); 
            }
            else if (!empty($data['multi_country']) && $data['multi_country'] != "NONE"){
                $objCountry = new Model_Country();
                if (!empty($data['country_id'])) {
                    $data['country_id'] = array_unique(array_merge($data['country_id'], array_keys($objCountry->getCountriesByTag($data['multi_country']))));
                } else {
                    $data['country_id'] = array_keys($objCountry->getCountriesByTag($data['multi_country']));
                }
            }            
            if($data['label_id']) {
                $data['label_id'] = implode(",", $data['label_id']);
            }
            if($data['course_id']) {
                $data['course_id'] = implode(",", $data['course_id']);
            }   

            if($data['bundle_id']) {
                $data['bundle_id'] = implode(",",$data['bundle_id']);
            }
            if($data['mom_id']) {
                $data['mom_id'] = implode(",", $data['mom_id']);
            }
            
            if(isset($data['training_id']) && $data['training_id']) {
                $data['training_id'] = implode(",", $data['training_id']);
            }
            if(isset($data['cluster_id']) && $data['cluster_id']) {
                $data['cluster_id'] = implode(",", $data['cluster_id']);
            }
            if(isset($data['country_id']) && $data['country_id']) {
                $data['country_id'] = implode(",", $data['country_id']);
            }
            $bannerData = array();
            if(isset($data['topBannerPath'])) {
                $bannerData[] = array(
                    'banner_type' => 'top',
                    'banner_path' => $data['topBannerPath']
                );
                unset($data['topBannerPath']);
            }
            if(isset($data['smallBannerPath'])) {
                $bannerData[] = array(
                    'banner_type' => 'small',
                    'banner_path' => $data['smallBannerPath']
                );
                unset($data['smallBannerPath']);
            }            
            $paramsData = $data;            
                        
            for($i=0;$i<$loopCount;$i++){
                $objCoupon->clean();
                $paramsData['code'] = trim((empty($data['code'])) ? $fileCouponCodes[$i] : $data['code']);
                if(empty($paramsData['code'])){
                    continue;
                }                
                $couponId = $objCoupon->addCoupon($paramsData);
                
                if($couponId){
                    $modelBanner = new Model_Banners();
                    foreach($bannerData as $bannerDataSingle) {
                        $bannerDataSingle['linkable_id'] = $couponId;
                        $bannerDataSingle['linkable_type'] = 'coupon';
                        if(!$modelBanner->saveBanner($bannerDataSingle)) {
                            array_push($failCodesArr,$paramsData['code']);
                        }
                    }
                    $cdnPurgeData = $objCoupon->buildCdnPurgeData($paramsData['course_id'],$paramsData['bundle_id'],$paramsData['pass_id'],'Coupon Added -'.$data['code']);
                    $objCdn = new Model_CdnPurgeLog();
                    if(!empty($cdnPurgeData))
                        $objCdn->InsertCdnPurgeLog($cdnPurgeData);
                }
                else {
                    array_push($failCodesArr,$paramsData['code']);
                }                                
            }
            if(empty($failCodesArr)){
                $form->reset();
                $module  = $this->getRequest()->getModuleName();
                $controller = $this->getRequest()->getControllerName();
                $action = $this->getRequest()->getActionName();
                if($module && $controller && $action)
                    $this->redirect($module.'/'.$controller.'/');
            }else{
                $this->view->failCodes = $failCodesArr;
            }
        }
        else if ($this->getRequest()->isPost()) {
            $request = $this->getRequest()->getPost();
            if(isset($request['label_id'])) {
                $modelCourse = new Model_Courses();
                $form->getElement('course_id')->setAttrib('options', $modelCourse->getbyLables($request['label_id']));
                $modelBundle = new Model_Bundles();
                $form->getElement('bundle_id')->setAttrib('options', $modelBundle->getbyLables($request['label_id']));
            }
            $form->setDefaults($request);
        } 
        
        $this->view->form = $form;
    }

    public function addSubscriptionAction() {
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $request = $this->getRequest()->getPost();            
        $form = new Form_CouponSubscription();
        $resultArr = array();
        $failCodesArr = array();
        if ($form === false)
            throw new Zend_Exception('_getForm not implemented');
        if ($this->getRequest()->isPost() && $form->isValid($this->getRequest()->getPost())) {
            $data = $form->getValues();
            unset($data['cluster_id_tmp']);
            unset($data['country_hid']);
            $data['validto'] = sprintf("%s 23:59:59", $data['validto']);
            $data['validFrom'] = sprintf("%s 00:00:00", $data['validFrom']);
            $data['validFrom'] = strtotime($data['validFrom']);
            $data['validto'] = strtotime($data['validto']);
            $fileData = $_FILES['coupoCsv'];
            $fileCouponCodes = array();
            $loopCount = 1;
            if(!empty($fileData['name'])){
                $fileCouponCodes = $this->_processFile($fileData);
                if(false === $fileCouponCodes){
                    $this->view->message = "5000 is the Limit.";
                    $this->view->success = false;
                    $this->view->form = $form;
                    return false;
                }
                $loopCount = count($fileCouponCodes);
                ini_set('max_execution_time', 300);
            }
            

            if(isset($data['displayFrontend']) && !empty($data['displayFrontend'])){
                $objCoupon = new Model_Coupons();
                $res = $objCoupon->checkCouponDisplay(   
                                                                !empty($data['course_id']) ? $data['course_id'] : array(),
                                                                !empty($data['country_id']) ? $data['country_id']:array(),
                                                                !empty($data['label_id']) ? $data['label_id'] : array(),
                                                                !empty($data['cluster_id']) ? $data['cluster_id'] : array(),
                                                                !empty($data['code']) ? $data['code'] : ''
                                                            );
                if(!empty($res)){
                    $this->view->message = "all these coupon id's are used to display on website".implode(',', $res);
                    $this->view->success = false;
                    $this->view->form = $form;
                    return false;
                }    
            }

            $modelCountry = new Model_Country();
            $countries = $modelCountry->fetchForSelect(array("cluster_id IN (?)"=>$data['cluster_id']), array(), false);
            if($data['country_id']) {
                $data['country_id'] = array_merge($data['country_id'], array_keys($countries));
            }
            else {
                $data['country_id'] = array_keys($countries);
            } 
            
            $data['label_id'] = implode(",", $data['label_id']);
            $data['cluster_id'] = implode(",", $data['cluster_id']);
            $data['country_id'] = implode(",", $data['country_id']);
            $bannerData = array();
            if(isset($data['topBannerPath'])) {
                $bannerData[] = array(
                    'banner_type' => 'top',
                    'banner_path' => $data['topBannerPath']
                );
                unset($data['topBannerPath']);
            }
            if(isset($data['smallBannerPath'])) {
                $bannerData[] = array(
                    'banner_type' => 'small',
                    'banner_path' => $data['smallBannerPath']
                );
                unset($data['smallBannerPath']);
            }
            
            $objCoupon = new Model_Coupons();
            $paramsData = $data;            
            for($i=0;$i<$loopCount;$i++){
                $paramsData['code'] = trim((empty($data['code'])) ? $fileCouponCodes[$i] : $data['code']);
                if(empty($paramsData['code'])){
                    continue;
                }
                $couponId = $objCoupon->addCoupon($paramsData);
                
                if($couponId){
                    $modelBanner = new Model_Banners();
                    foreach($bannerData as $bannerDataSingle) {
                        $bannerDataSingle['linkable_id'] = $couponId;
                        $bannerDataSingle['linkable_type'] = 'coupon';
                        if(!$modelBanner->saveBanner($bannerDataSingle)) {
                            array_push($failCodesArr,$paramsData['code']);
                        }
                    }
                    $cdnPurgeData = $objCoupon->buildCdnPurgeData($paramsData['course_id'],$paramsData['bundle_id'],$paramsData['pass_id'],'Coupon Added -'.$data['code']);
                    $objCdn = new Model_CdnPurgeLog();
                    if(!empty($cdnPurgeData))
                        $objCdn->InsertCdnPurgeLog($cdnPurgeData);
                }
                else {
                    array_push($failCodesArr,$paramsData['code']);
                }                
            }
            if(empty($failCodesArr)) {
                $form->reset();
                $module  = $this->getRequest()->getModuleName();
                $controller = $this->getRequest()->getControllerName();
                $action = $this->getRequest()->getActionName();
                if($module && $controller && $action)
                    $this->redirect($module.'/'.$controller.'/');
            }else{
                $this->view->failCodes = $failCodesArr;
            }
        }
        $this->view->form = $form;
    }

    private function _processFile($fileData){
        $couponCodeArr = array();
        if($fileData['tmp_name']){
            $fileName = $fileData['name'];
            $absFilePath = sys_get_temp_dir().DIRECTORY_SEPARATOR.$fileName;
            $couponData =file_get_contents($absFilePath);
            if(!empty($couponData)){
                $couponCodeArr =  explode("\n",$couponData);
                if(count($couponCodeArr) > 5000){
                    return false;
                }
                return $couponCodeArr;
            }
        }
        return $couponCodeArr;
    }

    public function editAction(){
        $couponId = $this->getRequest()->getParam('id');
        if(!$couponId)
            throw new BaseApp_Exception(' item not selected properly');
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        
        $couponData = $this->getModel($couponId);
        $couponData = $couponData->toArray();          
        if(!$couponData) {
            $this->view->message = "Invalid Coupon Id";
            $this->view->success = false;
            return false;
        }
        if($couponData['type'] == 'course'){
            $this->_handleEditCourse($couponData);
        }
        else {
            $this->_handleEditSubscription($couponData);
        }        
    }
    
    private function _handleEditCourse($couponData) {
        $form = new Form_CouponCourse();
        $form->removeUneditableElements();
        if ($this->getRequest()->isPost()) {
            if($form->isValid($this->getRequest()->getPost())) {
                $data = $form->getValues();
                file_put_contents(APPLICATION_PATH . '/../error.log', __METHOD__ .'edit coupon data : '. print_r($data,true), FILE_APPEND);  
                unset($data['cluster_id_tmp']);
                unset($data['country_hid']);
                unset($data['training_id_tmp']);  
                $data['validto'] = sprintf("%s 23:59:59", $data['validto']);
                $data['validFrom'] = sprintf("%s 00:00:00", $data['validFrom']);
                $data['validFrom'] = strtotime($data['validFrom']);
                $data['validto'] = strtotime($data['validto']);

                if(isset($data['displayFrontend']) && !empty($data['displayFrontend'])){
                    $objCoupon = new Model_Coupons();
                    $res = $objCoupon->checkCouponDisplay(   
                                                                    !empty($data['course_id']) ? $data['course_id'] : array(),
                                                                    !empty($data['country_id']) ? $data['country_id']: array(),
                                                                    !empty($data['label_id']) ? $data['label_id'] : array(),
                                                                    !empty($data['cluster_id']) ? $data['cluster_id'] : array(),
                                                                    !empty($couponData['code']) ? $couponData['code'] : ''
                                                                );
                    if(!empty($res)){
                        $this->view->message = "Only 2 Marketing coupons can be shown on the  frontend for a category and country combination. Coupon ".implode(',', $res)."have one of the selected categories and country combinations as in this coupon and are also selected to be  displayed on frontend";
                        $this->view->success = false;
                        $this->view->form = $form;
                        return false;
                    }    
                }
                if($data['label_id']) {
                    $modelCourses = new Model_Courses();
                    $courses = $modelCourses->getbyLables($data['label_id']);
                    if($data['course_id']) {
                        $data['course_id'] = array_merge($data['course_id'], array_keys($courses));                
                    }
                    else {
                        $data['course_id'] = array_keys($courses);
                        unset($courses);
                    }
                    $modelBundle = new Model_Bundles();
                    $bundles = $modelBundle->getbyLables($data['label_id']);
                    if($data['bundle_id']) {
                        $data['bundle_id'] = array_merge($data['bundle_id'], array_keys($bundles));                
                    }
                    else {
                        $data['bundle_id'] = array_keys($bundles);
                        unset($bundles);
                    }
                }                

                if($data['cluster_id']) {
                    $modelCountry = new Model_Country();
                    $countries = $modelCountry->fetchForSelect(array("cluster_id IN (?)"=>$data['cluster_id']), array(), false);
                    if($data['country_id']) {
                        $data['country_id'] = array_merge($data['country_id'], array_keys($countries));
                    }
                    else {
                        $data['country_id'] = array_keys($countries);
                    }  
                }
                 
                if(!empty($data['multi_bundle']) && $data['multi_bundle'] != "NONE") {
                    $bundle = new Model_Bundles();
                    if (!empty($data['bundle_id'])) {
                        $data['bundle_id'] = array_unique(array_merge($data['bundle_id'], array_keys($bundle->getAllBundles($data['multi_bundle']))));
                    } else {
                        $data['bundle_id'] = array_keys($bundle->getAllBundles($data['multi_bundle']));
                    }
                }
    
                
    
                if (!empty($data['multi_course']) && $data['multi_course'] != "NONE") {
                    $modelCourses = new Model_Courses();
                    if (!empty($data['course_id'])) {
                        $data['course_id'] = array_unique(array_merge($data['course_id'], array_keys($modelCourses->getAllCourses($data['multi_course']))));
                    } else {
                        $data['course_id'] = array_keys($modelCourses->getAllCourses($data['multi_course']));
                    }
                }
                
                if(!empty($data['all_countries']) && $data['all_countries']) {
                    $objCluster =new Model_Clusters();
                    $objCountry =new Model_Country();
                    $data['cluster_id'] = array_keys($objCluster->fetchForSelect());
                    $data['country_id'] = array_keys($objCountry->getListDisplay()); 
                }
                else if (!empty($data['multi_country']) && $data['multi_country'] != "NONE"){
                    $objCountry = new Model_Country();
                    if (!empty($data['country_id'])) {
                        $data['country_id'] = array_unique(array_merge($data['country_id'], array_keys($objCountry->getCountriesByTag($data['multi_country']))));
                    } else {
                        $data['country_id'] = array_keys($objCountry->getCountriesByTag($data['multi_country']));
                    }
                }            
                $data['mom_id'] = !empty($data['mom_id']) ? implode (",",$data['mom_id']) : 0;        if($data['label_id'])      
                if($data['label_id'])
                $data['label_id'] = implode(",", $data['label_id']);
                if($data['bundle_id'])
                $data['bundle_id'] = implode(",", $data['bundle_id']);
                if($data['course_id'])
                $data['course_id'] = implode(",", $data['course_id']);
                if($data['training_id'])
                $data['training_id'] = implode(",", $data['training_id']);
                if($data['cluster_id'])
                $data['cluster_id'] = implode(",", $data['cluster_id']);
                if($data['country_id'])
                $data['country_id'] = implode(",", $data['country_id']);
                if($data['pass_id'])
                $data['pass_id'] = implode(",", $data['pass_id']);

                $bannerData = array();
                if(isset($data['topBannerPath'])) {
                    $bannerData[] = array(
                        'banner_type' => 'top',
                        'banner_path' => $data['topBannerPath']
                    );
                    unset($data['topBannerPath']);
                }
                if(isset($data['smallBannerPath'])) {
                    $bannerData[] = array(
                        'banner_type' => 'small',
                        'banner_path' => $data['smallBannerPath']
                    );
                    unset($data['smallBannerPath']);
                }
                $result = true;
                $objCoupon = new Model_Coupons();      
                $data['code'] = $couponData['code'];
                if($result = $objCoupon->updateCoupon($couponData['coupon_id'], $data)) {
                    $modelBanner = new Model_Banners();
                    foreach($bannerData as $bannerDataSingle) {
                        $bannerDataSingle['linkable_id'] = $couponData['coupon_id'];
                        $bannerDataSingle['linkable_type'] = 'coupon';
                        if(!$modelBanner->saveBanner($bannerDataSingle)) {
                            $result = false;
                        }
                    }
                }
                if($result) {
                    $cdnPurgeData = $objCoupon->buildCdnPurgeData($couponData['course_id'],$couponData['bundle_id'],$couponData['pass_id'],'Coupon Edited -'.$couponData['code']);
                    $objCdn = new Model_CdnPurgeLog();
                    if(!empty($cdnPurgeData))
                        $objCdn->InsertCdnPurgeLog($cdnPurgeData);
                    $form->reset();
                    $module  = $this->getRequest()->getModuleName();
                    $controller = $this->getRequest()->getControllerName();
                    $action = $this->getRequest()->getActionName();
                    if($module && $controller && $action)
                        $this->redirect($module.'/'.$controller.'/');
                }
            }                         
        }
        else {
            $couponData['label_id'] = explode(",", $couponData['label_id']);
            $couponData['course_id'] = explode(",", $couponData['course_id']);
            $couponData['training_id'] = explode(",", $couponData['training_id']);            
            $couponData['bundle_id'] = explode(",", $couponData['bundle_id']);
            
            $couponData['cluster_id'] = explode(",", $couponData['cluster_id']);
            $couponData['country_id'] = explode(",", $couponData['country_id']);
            $couponData['pass_id'] = explode(",", $couponData['pass_id']);
            $couponData['mom_id'] = explode(",", $couponData['mom_id']);

            $modelBanner = new Model_Banners();
            foreach($modelBanner->getByLinkable($couponData['coupon_id'], 'coupon') as $bannerData) {
                switch($bannerData['banner_type']) {
                    case 'top':
                        $couponData['topBannerPath'] = $bannerData['banner_path'];
                        break;
                    case 'small':    
                        $couponData['smallBannerPath'] = $bannerData['banner_path'];
                        break;
                }
            }
            $couponData['validFrom'] = date("Y-m-d", $couponData['validFrom']);
            $couponData['validto'] = date("Y-m-d", $couponData['validto']);
            $form->setDefaults($couponData);
        }
        
        $this->view->form = $form;
    }
    
    private function _handleEditSubscription($couponData) {
        $form = new Form_CouponSubscription();
        $form->removeUneditableElements();
        if ($this->getRequest()->isPost()) {
            if($form->isValid($this->getRequest()->getPost())) {
                $data = $form->getValues();
                unset($data['cluster_id_tmp']);
                unset($data['country_hid']); 
                $data['validto'] = sprintf("%s 23:59:59", $data['validto']);
                $data['validFrom'] = sprintf("%s 00:00:00", $data['validFrom']);
                $data['validFrom'] = strtotime($data['validFrom']);
                $data['validto'] = strtotime($data['validto']);

                if(isset($data['displayFrontend']) && !empty($data['displayFrontend'])){
                    $objCoupon = new Model_Coupons();
                    $res = $objCoupon->checkCouponDisplay(   
                                                                    !empty($data['course_id']) ? $data['course_id'] : array(),
                                                                    !empty($data['country_id']) ? $data['country_id'] :array(),
                                                                    !empty($data['label_id']) ? $data['label_id'] : array(),
                                                                    !empty($data['cluster_id']) ? $data['cluster_id'] : array(),
                                                                    !empty($couponData['code']) ? $couponData['code'] : ''
                                                                );
                    if(!empty($res)){
                        $this->view->message = "Only 2 Marketing coupons can be shown on the  frontend for a category and country combination. Coupon ".implode(',', $res)."have one of the selected categories and country combinations as in this coupon and are also selected to be  displayed on frontend";
                        $this->view->success = false;
                        $this->view->form = $form;
                        return false;
                    }    
                }
                $modelCountry = new Model_Country();
                $countries = $modelCountry->fetchForSelect(array("cluster_id IN (?)"=>$data['cluster_id']), array(), false);
                if($data['country_id']) {
                    $data['country_id'] = array_merge($data['country_id'], array_keys($countries));
                }
                else {
                    $data['country_id'] = array_keys($countries);
                } 
                $data['label_id'] = implode(",", $data['label_id']);
                $data['cluster_id'] = implode(",", $data['cluster_id']);
                $data['country_id'] = implode(",", $data['country_id']);

                $bannerData = array();
                if(isset($data['topBannerPath'])) {
                    $bannerData[] = array(
                        'banner_type' => 'top',
                        'banner_path' => $data['topBannerPath']
                    );
                    unset($data['topBannerPath']);
                }
                if(isset($data['smallBannerPath'])) {
                    $bannerData[] = array(
                        'banner_type' => 'small',
                        'banner_path' => $data['smallBannerPath']
                    );
                    unset($data['smallBannerPath']);
                }
                $result = true;
                $objCoupon = new Model_Coupons();  
                $data['code'] = $couponData['code'];
                if($result = $objCoupon->updateCoupon($couponData['coupon_id'], $data)) {
                    $modelBanner = new Model_Banners();
                    foreach($bannerData as $bannerDataSingle) {
                        $bannerDataSingle['linkable_id'] = $couponData['coupon_id'];
                        $bannerDataSingle['linkable_type'] = 'coupon';
                        if(!$modelBanner->saveBanner($bannerDataSingle)) {
                            $result = false;
                        }
                    }
                }
                if($result) {
                    $cdnPurgeData = $objCoupon->buildCdnPurgeData($couponData['course_id'],$couponData['bundle_id'],$couponData['pass_id'],'Coupon Edited -'.$couponData['code']);
                    $objCdn = new Model_CdnPurgeLog();
                    if(!empty($cdnPurgeData))
                        $objCdn->InsertCdnPurgeLog($cdnPurgeData);
                    $form->reset();
                    $module  = $this->getRequest()->getModuleName();
                    $controller = $this->getRequest()->getControllerName();
                    $action = $this->getRequest()->getActionName();
                    if($module && $controller && $action)
                        $this->redirect($module.'/'.$controller.'/');
                }
            }
        }
        else {
            $couponData['label_id'] = explode(",", $couponData['label_id']);
            $couponData['cluster_id'] = explode(",", $couponData['cluster_id']);
            $couponData['country_id'] = explode(",", $couponData['country_id']);  
            
            $modelBanner = new Model_Banners();
            foreach($modelBanner->getByLinkable($couponData['coupon_id'], 'coupon') as $bannerData) {
                switch($bannerData['banner_type']) {
                    case 'top':
                        $couponData['topBannerPath'] = $bannerData['banner_path'];
                        break;
                    case 'small':    
                        $couponData['smallBannerPath'] = $bannerData['banner_path'];
                        break;
                }
            }
            $couponData['validFrom'] = date("Y-m-d", $couponData['validFrom']);
            $couponData['validto'] = date("Y-m-d", $couponData['validto']);
            $form->setDefaults($couponData);
        }        
        
        $this->view->form = $form;
    }

    public function listAction() {
        parent::listAction();
        $this->_helper->viewRenderer->setRender('list');
        $this->view->setScriptPath(APPLICATION_PATH . '/modules/'.$this->getRequest()->getModuleName().'/views/scripts');
        $this->_helper->viewRenderer->setNoController(false);
    }
    public function updateExpiryAction(){
        $request = $this->getRequest()->getPost();
        $form = new Form_CouponExpiry();
        $objCoupon = new Model_Coupons();
        $resultArr = array();
        if ($this->getRequest()->isPost() && $form->isValid($this->getRequest()->getPost())) {
            $data = $form->getValues();
            $fileData = $_FILES['coupoCsv'];
            $data['validto'] = strtotime($data['validto']);
            $failCodesArr = array();
            if(!empty($fileData['name'])){
                $fileCouponCodes = $this->_processFile($fileData);
                if(false === $fileCouponCodes){
                    $this->view->message = "5000 is the Limit.";
                    $this->view->success = false;
                    $this->view->form = $form;
                    return false;
                }
                $loopCount = count($fileCouponCodes);
                ini_set('max_execution_time', 300);
                for($i=0;$i<$loopCount;$i++){
                    $objCoupon->clean();
                    $data['code'] = trim($fileCouponCodes[$i]);
                    if(empty($data['code'])){
                        continue;
                    }
                    $couponData = current($objCoupon->fetchAll(array('code =?'=>$data['code'])));
                    if(empty($couponData)){
                        continue;
                    }
                    if(false === $objCoupon->updateExpiryDate($data)){
                        array_push($failCodesArr,$data['code']);
                    }
                    $cdnPurgeData = $objCoupon->buildCdnPurgeData($couponData['course_id'],$couponData['bundle_id'],$couponData['pass_id'],'Coupon Edited -'.$couponData['code']);
                    $objCdn = new Model_CdnPurgeLog();
                    if(!empty($cdnPurgeData))
                        $objCdn->InsertCdnPurgeLog($cdnPurgeData);
                }
                if(empty($failCodesArr)){
                    $form->reset();
                    $module  = $this->getRequest()->getModuleName();
                    $controller = $this->getRequest()->getControllerName();
                    $action = $this->getRequest()->getActionName();
                    if($module && $controller && $action)
                        $this->redirect($module.'/'.$controller.'/');
                }else{
                    $this->view->failCodes = $failCodesArr;
                }
            }
        }
        $this->view->form = $form;
    } // end of function expiryAction
}
