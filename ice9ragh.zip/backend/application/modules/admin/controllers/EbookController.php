<?php
/*
 * Contains the CRUD actions of Ebooks table
 * 
 */

class Admin_EbookController extends BaseApp_Controller_Crud {
    protected $_model = 'Model_Ebooks';
    protected $_descriptions = array(
        'list' => 'List of Existing Ebooks',
        'index' => 'List of Existing Ebooks',
        'add' => 'Add New Ebooks',
        'edit' => 'Make the required changes then click on "Save Ebooks" to update the Ebooks',
        'view' => 'View Selected Ebooks'
    );

    protected function _getForm() {
        $form = new Form_Ebooks();
        return $form;
    }

    public function addAction() {
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $form = new Form_Ebooks();
        $request = $this->getRequest()->getPost();
        if ($this->getRequest()->isPost() && $form->isValid($request)) {
            $data = $form->getValues();
            if(!$this->_isValid($data, $message)) {
                $this->view->message = $message;
                $this->view->success = false;
                $this->view->form = $form;
                return;
            }
            $tags = $data['tags'];
            unset($data['tags']);
            if(isset($data['course_id'])) {
                $data['course_id'] = implode(",", $data['course_id']);
            }
            if(isset($data['label_id'])) {
                $data['label_id'] = implode(",", $data['label_id']);
            }          
            $objEbooks = new Model_Ebooks();
            $result = $objEbooks->addEbooks($data);
            $objTags = new Model_Tags();
            if($result && !$objTags->saveTags($result, 'ebook', $tags)) {
                $result = false;
            }
            if (!$result) {
                $this->view->message = "An error has occured while saving";
                $this->view->success = true;
            } else {
                $cdnPurgeData = $this->getModel()->buildCdnPurgeData($result,$data['name'].' New Ebook Added');
                $objCdn = new Model_CdnPurgeLog();
                if(!empty($cdnPurgeData))
                    $objCdn->InsertCdnPurgeLog($cdnPurgeData);
                $this->view->message = "Saved SuccessFully";
                $this->view->success = false;
                $form->reset();
                $module  = $this->getRequest()->getModuleName();
                $controller = $this->getRequest()->getControllerName();
                $action = $this->getRequest()->getActionName();
                if($module && $controller && $action)
                    $this->redirect($module.'/'.$controller.'/list');
            }
        }
        $this->view->form = $form;
    }

    public function editAction() {
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $Id = $this->getRequest()->getParam('id');
        if(!$Id)
            throw new BaseApp_Exception('Editable item not selected properly');        
        $eBookData = current($this->getModel()->fetchAll(array('ebook_id =?'=>$Id), array(), false));
        if (!$eBookData) {
            throw new BaseApp_Exception('Editable item not selected properly');
        }                
        $form = new Form_Ebooks();
        if ($this->getRequest()->isPost()) { 
            $form->removeOptionalValidators();
            $form->removeUneditableElements();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            if ($form->isValid($this->getRequest()->getPost())) {
                $data = $form->getValues();
                if(!$this->_isValid($data, $message)) {
                    $this->view->message = $message;
                    $this->view->success = false;
                    $this->view->form = $form;
                    return;
                }
                $data['ebook_id'] = $Id;
                $tags = $data['tags'];
                unset($data['tags']);
                if(isset($data['course_id'])) {
                    $data['course_id'] = implode(",", $data['course_id']);
                }
                if(isset($data['label_id'])) {
                    $data['label_id'] = implode(",", $data['label_id']);
                }  
                $result = $this->getModel()->updateEbooks($data);
                $objTags = new Model_Tags();
                if($result && !$objTags->saveTags($data['ebook_id'], 'ebook', $tags)) {
                    $result = false;
                }
                if (!$result) {
                    $this->view->message = "An error has occured while saving";
                    $this->view->success = true;
                    $module  = $this->getRequest()->getModuleName();
                    $controller = $this->getRequest()->getControllerName();
                    $action = $this->getRequest()->getActionName();
                    if($module && $controller && $action)
                        $this->redirect($module.'/'.$controller.'/'.$action.'/id/'.$Id);
                } else {
                    $cdnPurgeData = $this->getModel()->buildCdnPurgeData($Id,$eBookData['name'].' Ebook Modified');
                    $objCdn = new Model_CdnPurgeLog();
                    if(!empty($cdnPurgeData))
                        $objCdn->InsertCdnPurgeLog($cdnPurgeData);
                    $this->view->message = "Saved SuccessFully";
                    $this->view->success = false;
                    $form->reset();
                    $module  = $this->getRequest()->getModuleName();
                    $controller = $this->getRequest()->getControllerName();
                    $action = $this->getRequest()->getActionName();
                    if($module && $controller && $action)
                        $this->redirect($module.'/'.$controller.'/list');
                }
            }          
        } 
        else {   
            $tags = new Model_Tags();
            if($tagData = $tags->getByLinkable($Id, 'ebook')) {
                $eBookData['tags'] = $tagData['tag'];
            }

            $objSeo = new Model_Seo();
            if($seoData = $objSeo->getDataByType($Id, 'ebook', Model_Ebooks::SEO_DEFAULT_CONTROLLER, Model_Ebooks::SEO_DEFAULT_ACTION)){
                $eBookData['thumb_image'] = $seoData['thumb_image'];
            }
            $eBookData['label_id'] = explode(",", $eBookData['label_id']);
            $eBookData['course_id'] = explode(",", $eBookData['course_id']);
            $form->setDefaults($eBookData);
            $form->removeUneditableElements();
        }
        $this->view->form = $form;
    }
    
    public function getByRelatedAction() {
        $arg = $this->getRequest()->get('ebookPart');
        $ebookList = array();
        if($arg) {
            $model = new Model_Ebooks();
            foreach($model->fetchAll( array('name LIKE ?'=>'%'.$arg.'%'), array(), false) as $indexId => $data) {
                $ebookList[$data['ebook_id']] = $data['name'];
            }
        }        
        
        $this->_helper->layout->disableLayout();
        $this->view->ebookList =  $ebookList;
    }
    
    private function _isValid($data, &$message='') {
        if(isset($data['course_id']) && count($data['course_id']) > Model_Ebooks::MAX_COURSES_ALLOWED_LINK) {
            $message = sprintf("Maximum %d courses allowed", Model_Ebooks::MAX_COURSES_ALLOWED_LINK);
            return false;
        }
        
        if(isset($data['label_id']) && count($data['label_id']) > Model_Ebooks::MAX_CATEGORIES_ALLOWED_LINK) {
            $message = sprintf("Maximum %d Categories allowed", Model_Ebooks::MAX_CATEGORIES_ALLOWED_LINK);
            return false;
        }
        return true;
    }
}
