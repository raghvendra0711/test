<?php
/*
 * Contains the CRUD actions of Label table
 * 
 */

class Admin_LabelController extends BaseApp_Controller_Crud {
    protected $_model = 'Model_Labels';
    protected $_descriptions = array(
        'list' => 'List of Existing Labels',
        'index' => 'List of Existing Labels',
        'add' => 'Add New Labels',
        'edit' => 'Make the required changes then click on "Save Labels" to update the Labels',
        'view' => 'View Selected Labels',
        'get-by-part-name' => 'For searching course by name name',
        'order' => 'arrange labels in a proper order',
        'flyout' => 'flyout lable page'
    );
    protected function _getForm() {
        $form = new Form_Labels();
        return $form;
    }
    
    public function addAction() {   
        $request = $this->getRequest()->getPost(); 
        $this->_setSubscriptionPrice($request);
        if (!$this->_add)
            $this->forward('list');
        // $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        // $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $form = $this->_getForm();        
        if ($form === false)
            throw new Zend_Exception('_getForm not implemented');
        $form->removeVideoElements();
        if ($request && $form->isValid($request)) {
            $request = $form->getValues();

            $accreditorsArr = $request['accreditor_id'];
            // Remove 3 accreditors limit
            // if(!empty($accreditorsArr) && count($accreditorsArr) > 3) {
            //     $this->view->message = "Max 3 accreditors allowed";
            //     $this->view->success = false;
            //     $this->view->form = $form;
            //     return false;
            // }

            $companyArr = $request['company'];
            if(!empty($companyArr) && count($companyArr) > 5) {
                $this->view->message = "Max 5 company allowed";
                $this->view->success = false;
                $this->view->form = $form;
                return false;
            }

            $aluminiArr = $request['alumni'];
            if(!empty($aluminiArr) && count($aluminiArr) > 4) {
                $this->view->message = "Max 4 alumni allowed";
                $this->view->success = false;
                $this->view->form = $form;
                return false;
            }

            $splitData = $this->_handleDataAfterSubmit($request);
            $result = false;
           

            $videoData = array();
            if(!empty($request['videoLink'])) {
                $vData = $form->getVideoData();
                if(!empty($vData) && is_array($vData)){
                $videoData['videoDescription'] = isset($vData['shortDescription']) ? $vData['shortDescription'] : NULL;
                $videoData['dateCreated'] = isset($vData['dateCreated']) ? $vData['dateCreated'] : NULL;
                $videoData['displayName'] = isset($vData['displayName']) ? $vData['displayName'] : $request['name'];
                $videoData['duration'] = isset($vData['duration']) ? $vData['duration'] : NULL;
                }
                $videoData['videoLink'] = $request['videoLink'];
                $videoData['videoThumbnail'] = !empty($request['videoThumbnail']) ? $request['videoThumbnail']: "";
            }

            unset($request['videoLink']);
            unset($request['dateCreated']);
            unset($request['videoThumbnail']);
            unset($request['videoDescription']);

            if($labelId = $this->getModel()->createLabel($request)) {
                $result = true;
                $pricing = new Model_SubscriptionPricing();
                if($result && !$pricing->savePricing($labelId, 'label', $splitData['subscriptionPrice'])) {
                    $result = false;
                }

                $image = new Model_Images();
                if($result && !$image->saveImage($labelId, 'label', $splitData['imagePath'], $splitData['imageDescription'])) {
                    $result = false;
                }   
                
                $looper = new BaseApp_Communication_Looper();
                $userId = BaseApp_Auth::getLoggedInUserId();
                $responce = $looper->createPrimaryTag($request['displayName'], $userId);
                if(empty($responce) || $responce['status'] != 'Success') {
                    $result = false;
                }
                $objSectionMapping = new Model_SectionMapping();
                $sectionMappingArr = array();
                if(isset($splitData['section_id_arr'])){
                    $sectionMappingArr = $splitData['section_id_arr'];   
                    if(!empty($sectionMappingArr))
                    $sectionMappingArr = call_user_func_array('array_merge', $sectionMappingArr);
                }
                if(!$objSectionMapping->saveProductSectionData($labelId,'Category',$sectionMappingArr))
                    $result = false;
                 if(!empty($videoData)) {
                    // add category intro video
                    $objVideos = new Model_Videos();
                    $videosArr = array(
                        'linkable_id'=>$labelId,
                        'linkable_type'=>'label',
                        'name'=>'about_label',
                        'videoLink'=>$videoData['videoLink'], 
                        'thumbnailImage' => $videoData['videoThumbnail'],
                    );
                    if(isset($videoData['videoDescription']) && $videoData['videoDescription']){
                        $videosArr['shortDescription'] = $videoData['videoDescription'];
                    }
                    if (isset($videoData['dateCreated']) && $videoData['dateCreated']) {
                        $videosArr['dateCreated'] = $videoData['dateCreated'];
                    }
                    if(isset($videoData['displayName']) && $videoData['displayName']){
                        $videosArr['displayName'] = $videoData['displayName'];
                    }
                    if(isset($videoData['duration']) && $videoData['duration']){
                        $videosArr['duration'] = $videoData['duration'];
                    }
                    $objVideos->clean();
                    $resultInsert = $objVideos->setFromArray($videosArr)->save();
                    if($resultInsert) {
                        if(!$this->_saveVideoSeo($objVideos->video_id, $labelId, $videoData['videoThumbnail']))
                            $result = false;    
                    }else{
                        $result = false;
                    }
                }
            }
            if (!$result) {
                $this->view->message = "An error has occured while saving";
                $this->view->success = true;
            } else {
                $cdnPurgeData  = $this->getModel()->buildCdnPurgeData($labelId,'New Category Created'.$request['name']);
                $objCdn = new Model_CdnPurgeLog();
                if(!empty($cdnPurgeData))
                    $objCdn->InsertCdnPurgeLog($cdnPurgeData);
                $this->view->message = "Data successfully added";
                $this->view->success = false;
                $form->reset();
                $module  = $this->getRequest()->getModuleName();
                $controller = $this->getRequest()->getControllerName();
                // $action = $this->getRequest()->getActionName();
                $action = 'label-indetail';
                if($module && $controller && $action)
                    $this->redirect($module.'/'.$controller.'/'.$action.'/id/'.$labelId);
            }
            //$this->forward('list');
        }
        $this->view->form = $form;
    }
    
    public function getByPartNameAction() {
        $arg = $this->getRequest()->get('labelPart');
        $labelList = array();
        if($arg) {
            foreach($this->getModel()->getByPartName($arg) as $indexId => $data) {
                $labelList[$data['label_id']] = $data['name'];
            }
        }        
        $this->_helper->layout->disableLayout();
        $this->view->labelList =  $labelList;
    }
    
    public function orderAction() {
        if(!$request = $this->getRequest()->getPost()) {
            $this->view->labelList =  $this->getModel()->getByParentLabel();
        }
        else {
            unset($request['Save']);
            $model = new Model_Labels();
            $lableIdsAll = array();            
            foreach($request as $parentLabel => $lableIds) {
                $request[$parentLabel] = explode(",", $lableIds);
                $lableIdsAll = array_merge($lableIdsAll, $request[$parentLabel]);
            }
            $saveData = array();
            foreach($lableIdsAll as $lableId) {
                foreach($request as $parentLabel => $lableIds) {
                    $orderNo = array_search($lableId, $lableIds);
                    if($orderNo !== false) {
                        $orderNo++;
                        $saveData[$lableId][$parentLabel.'OrderNo'] = $orderNo;                        
                    }
                    
                }
            }
            foreach($saveData as $labelId => $data) {
                $model->clean();
                $model->setId($labelId);
                $model->setFromArray($data)->update();
            }
            $module  = $this->getRequest()->getModuleName();
            $controller = $this->getRequest()->getControllerName();
            $action = $this->getRequest()->getActionName();
            if($module && $controller && $action){
                $cdnPurgeData  = $this->getModel()->buildCdnPurgeData($data['label_id'],'Category Modified'.$data['name']);
                $objCdn = new Model_CdnPurgeLog();
                if(!empty($cdnPurgeData))
                    $objCdn->InsertCdnPurgeLog($cdnPurgeData);
                $this->redirect($module.'/'.$controller.'/'.$action.'?success=true');
            }
        }
        
    }
    
    
    public function editAction() {
        // $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        // $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
   
        if ($this->getRequest()->isPost()) {
            $request = $this->getRequest()->getPost();
            $this->_setSubscriptionPrice($request);
            $this->view->labelId = $this->getRequest()->getParam('id');

            $form = $this->_getForm();
            $form->removeOptionalValidators();
            $form->removeUneditableElements();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            
            if($form->isValid($request)) {
                $data = $form->getValues();
                // Remove 3 accreditors limit
                // $accreditorsArr = $data['accreditor_id'];
                // if(!empty($accreditorsArr) && count($accreditorsArr) > 3) {
                //     $this->view->message = "Max 3 accreditors allowed";
                //     $this->view->success = false;
                //     $this->view->form = $form;
                //     return false;
                // }

                // $accreditorsArr = $data['accreditor_id'];
                // if(!empty($accreditorsArr) && count($accreditorsArr) > 3) {
                //     $this->view->message = "Max 3 accreditors allowed";
                //     $this->view->success = false;
                //     $this->view->form = $form;
                //     return false;
                // }

                $companyArr = $data['company'];
                if(!empty($companyArr) && count($companyArr) > 5) {
                    $this->view->message = "Max 5 company allowed";
                    $this->view->success = false;
                    $this->view->form = $form;
                    return false;
                }

                $aluminiArr = $data['alumni'];
                if(!empty($aluminiArr) && count($aluminiArr) > 4) {
                    $this->view->message = "Max 4 alumni allowed";
                    $this->view->success = false;
                    $this->view->form = $form;
                    return false;
                }

                $splitData = $this->_handleDataAfterSubmit($data);
                $videoData = array();

                if(!empty($data['videoLink'])) {
                    $vData = $form->getVideoData();
                    if(!empty($vData) && is_array($vData)){
                    $videoData['videoDescription'] = isset($vData['shortDescription']) ? $vData['shortDescription'] : NULL;
                    $videoData['dateCreated'] = isset($vData['dateCreated']) ? $vData['dateCreated'] : NULL;
                    $videoData['duration'] = isset($vData['duration']) ? $vData['duration'] : NULL;
                    $videoData['displayName'] = isset($vData['displayName']) ? $vData['displayName'] : $data['name'];
                    }
                    $videoData['videoLink'] = $data['videoLink'];
                    $videoData['videoThumbnail'] = !empty($data['videoThumbnail']) ? $data['videoThumbnail']: "";
                }

                unset($data['videoLink']);
                unset($data['dateCreated']);
                unset($data['videoThumbnail']);
                unset($data['videoDescription']);
                $data['label_id'] = $this->getRequest()->getParam('id');
                $result = false;
                $labelModel = new Model_Labels();
                if($labelModel->updateLabel($data)) {
                    $result = true;
                    $imageModel = new Model_Images();
                    if($result && !$imageModel->saveImage($data['label_id'], 'label', $splitData['imagePath'], $splitData['imageDescription'])) {
                        $result = false;
                    }
                    $pricing = new Model_SubscriptionPricing();
                    if($result && !$pricing->savePricing($data['label_id'], 'label', $splitData['subscriptionPrice'])) {
                        $result = false;
                    }

                    $objSectionMapping = new Model_SectionMapping();
                    $sectionMappingArr = array();
                    if(isset($splitData['section_id_arr']) && !empty($splitData['section_id_arr'])){
                        $sectionMappingArr = $splitData['section_id_arr'];    
                        $sectionMappingArr = call_user_func_array('array_merge', $sectionMappingArr);
                    }
                    if(!$objSectionMapping->saveProductSectionData($data['label_id'],'Category',$sectionMappingArr))
                        $result = false;

                    if(!empty($videoData)) {
                        $objVideos = new Model_Videos();
                        $videosArr = array(
                            'linkable_id'=>$data['label_id'],
                            'linkable_type'=>'label',
                            'name'=>'about_label',
                            'videoLink'=>$videoData['videoLink'], 
                            'thumbnailImage'=>$videoData['videoThumbnail']
                        );
                        if(isset($videoData['videoDescription']) && $videoData['videoDescription']){
                            $videosArr['shortDescription'] = $videoData['videoDescription'];
                        }
                        if (isset($videoData['dateCreated']) && $videoData['dateCreated']) {
                            $videosArr['dateCreated'] = $videoData['dateCreated'];
                        }
                        if (isset($videoData['displayName']) && $videoData['displayName']) {
                            $videosArr['displayName'] = $videoData['displayName'];
                        }
                        if (isset($videoData['duration']) && $videoData['duration']) {
                            $videosArr['duration'] = $videoData['duration'];
                        }
                        if($videoExists = $objVideos->getByLinkableId($data['label_id'],'label', false, 'about_label')) {
                            $videosArr['video_id'] = $videoExists['video_id'];
                            $objVideos->clean();
                            $objVideos->setId($videosArr['video_id']);
                            $resultUpdate = $objVideos->setFromArray($videosArr)->update();
                            if(!$this->_saveVideoSeo($videosArr['video_id'], $data['label_id'], $videoData['videoThumbnail']))
                                $result = false;
                
                        }else {
                            $objVideos->clean();
                            $resultInsert = $objVideos->setFromArray($videosArr)->save();
                            if($resultInsert) {
                                if(!$this->_saveVideoSeo($objVideos->video_id, $data['label_id'], $videoData['videoThumbnail']))
                                   $result = false; 
                            }
                        }
                    }else{
                        $objVideos = new Model_Videos();
                        if($videoExists = $objVideos->getByLinkableId($data['label_id'],'label', false, 'about_label')) {
                            $videosArr['video_id'] = $videoExists['video_id'];
                            $objVideos->clean();
                            $objVideos->setId($videosArr['video_id']);
                            $resultUpdate = $objVideos->setFromArray(array('status'=>0))->update();
                            if(!$this->_saveVideoSeo($videosArr['video_id'], $data['label_id'], $videoData['videoThumbnail']))
                                $result = false;
                
                        }
                    }
                }

                if (!$result) {
                    $this->view->message = "An error has occured while saving";
                    $this->view->success = true;
                } else {
                    // for making message page specific
                    $cdnPurgeData  = $this->getModel()->buildCdnPurgeData($data['label_id'],'Category Modified'.$data['name']);
                    $objCdn = new Model_CdnPurgeLog();
                    if(!empty($cdnPurgeData))
                        $objCdn->InsertCdnPurgeLog($cdnPurgeData);
                    $this->view->message = ucwords($this->getRequest()->getControllerName())." Data successfully updated";
                    $this->view->success = false;
                }
                // $this->_redirect('/admin/label/list');
                $module  = $this->getRequest()->getModuleName();
                $controller = $this->getRequest()->getControllerName();
                // $action = $this->getRequest()->getActionName();
                $action = 'label-indetail';
                if($module && $controller && $action)
                    $this->redirect($module.'/'.$controller.'/'.$action.'/id/'.$data['label_id']);
            }
        }
        elseif($labelId = $this->getRequest()->getParam('id')) {                 
            $labelModel = new Model_Labels($labelId);
            if(!$labelModel->toArray()) {
                $this->_redirect('/admin/label/list');
            }
            $imageModel = new Model_Images();
            if($imageData = $imageModel->getByLinkable($labelId, 'label')) {
                $labelModel->imagePath = $imageData['imagePath'];
                $labelModel->imageDescription = $imageData['imageDescription'];
            }
            $labelModel->parentLabel = explode(",", $labelModel->parentLabel);
            $session = new Zend_Session_Namespace('form'); 
            $priceModel = new Model_SubscriptionPricing();
            if($priceData = $priceModel->getByLinkable($labelId, 'label')) {
                $session->keyfeatures = array_keys($priceData);
                array_unshift($session->keyfeatures, '__template__');
                foreach($session->keyfeatures as $indexId) {
                    if(isset($priceData[$indexId])) {
                        $session->data[$indexId] = array(
                            'country_id' => $priceData[$indexId]['country_id'],
                            'currency_id' => $priceData[$indexId]['currency_id'],
                            'access_day_id' => $priceData[$indexId]['access_day_id'],
                            'subscriptionPrice' => $priceData[$indexId]['subscriptionPrice']
                        );
                    }
                    else {
                        $session->data[$indexId] = array(
                            'access_day_id' => '',
                            'subscriptionPrice' => ''
                        );
                    }
                }
            }
            else {
                $session->keyfeatures = array('__template__', 'new');
                $session->data = array();
            }       

            $objSectionMapping = new Model_SectionMapping();
            $sectionData = $objSectionMapping->getByLinkableIdLinkableType($labelId,'Category');
            if(!empty($sectionData)){
                $labelModel['company'] = isset($sectionData['company']) ? array_column($sectionData['company'], 'section_id') : array();
                $labelModel['alumni'] = isset($sectionData['alumni']) ? array_column($sectionData['alumni'], 'section_id') : array();
                $labelModel['course_advisor'] = isset($sectionData['directors']) ? array_column($sectionData['directors'], 'section_id') : array();
            }
            $accreditorMappingObj = new Model_AccreditorMapping();
            $conds = array('linkable_id=?' => $labelId,'linkable_type=?' => 'category');
            $courseAccreditorArr = $accreditorMappingObj->fetchAll($conds);
            if(!empty($courseAccreditorArr)){
                $accIds = array_column($courseAccreditorArr, 'accreditor_id');
                $labelModel['accreditor_id']  =  $accIds;
            }

            $modelVideo = new Model_Videos();
            $videoData = $modelVideo->getByLinkableId($labelId,'label', false, 'about_label');
            if($videoData) {
                $seoMd = new Model_Seo();
                $conds = array(
                        'controller=?' => Model_Videos::SEO_DEFAULT_CONTROLLER,
                        'action=?' => Model_Videos::SEO_DEFAULT_ACTION,
                        'linkable_id=?' => $videoData['video_id'],
                        'linkable_type=?' => 'video'
                );
                $seoData = current($seoMd->fetchAll($conds, array(), false));
                $labelModel['videoLink'] = $videoData['videoLink'];
                $labelModel['dateCreated'] = $videoData['dateCreated'];
                $labelModel['videoUrl'] = $seoData['url'];
                $labelModel['videoThumbnail'] = $seoData['thumb_image'];
                $labelModel['videoDescription'] = $videoData['shortDescription'];
            }
            $this->view->postParams = $labelModel;
            $this->view->labelId = $labelId;            
            $form = $this->_getForm();
            $form->removeUneditableElements();            
            if ($form === false)
            throw new Zend_Exception('_getForm not implemented');        
            $form->setDefaults($labelModel->toArray());            
        }
        else {

            $this->_redirect('/admin/label/list');
        }
        $this->view->form = $form;
    }

    /**
     * labelIndetailAction
     *
     * @return void
     */
    public function labelIndetailAction()
    {
        $labelSectionId = $this->getRequest()->getParam('param');
        $labelSectionId = 1; //faqs option selected by default for now
        $labelId = $this->getRequest()->getParam('id');
        $countryId = $this->getRequest()->getParam('countryId');
        $clusterId = $this->getRequest()->getParam('clusterId');
        $pageNo = $this->getRequest()->getParam('pageNo');
        $allCountryDisable = true;
        $showB2bB2c = false;
        $limitPerPage =  BaseApp_Dao_CourseFaq::DEFAULT_COURSE_FAQ_PAGE_LIMIT;
        if (empty($pageNo)) {
            $pageNo = 1;
        }
        $calc = $limitPerPage * $pageNo;
        $offset = $calc - $limitPerPage;
        // $this->view->selectedCountryId = $countryId;
        $this->view->selectedCountryId = 'all'; //  all countries selected by default for now
        $this->view->selectedClusterId = $clusterId;

        $this->view->curPageNo=$pageNo;
        if (empty($labelId)) {
            $this->view->message = "Label id not given";
            $this->view->success = false;
            return;
        }
        $objLabel = new Model_Labels();
        if (!$labelData = $objLabel->getById($labelId)) {
            $this->view->message = "Invalid Label Id";
            $this->view->success = false;
            return;
        }
        if ($labelSectionId) {
            $this->view->sectionIdCurrent = $labelSectionId;
        }

        $sectionTemplatesData = array(
            'Generic' => array(
                0 => array(
                    'name' => 'FAQS',
                    'section_id' => 1,
                    'label_section_id' => 1,
                )
            )
        );
        
        $objCourseFaq = new Model_CourseFaq();
        $objCountry = new Model_Country();
        $countries = $objCountry->getListDisplay();
        $this->view->countryList = $countries;
        $objCluster = new Model_Clusters();
        $cluster = $objCluster->fetchForSelect();
        $this->view->cluster = $cluster;
        $isEdit = false;
        $isNewEntry = false;
        $this->view->training_id = 0;
        if ($labelSectionId) {
            $contentId = $this->getRequest()->getParam('contentId');
            $showAnswerField = true;
            $contentType = '';
            switch ($labelSectionId) {
                case 1:
                    $contentType = BaseApp_Dao_CourseFaq::COURSE_RESOURCE_FAQ;
                    $showAnswerField = true;
                    break;
                default:
                    break;
            }
            $addMore = $this->getRequest()->getParam('addMore');
            if (empty($labelId)) {
                $this->view->message = "An error has occured while saving";
                $this->view->success = true;
                return;
            }
            if (!empty($contentId)) {
                $isEdit = true;
                $isNewEntry = false;
            }
            if (!empty($addMore)) {
                $isNewEntry = true;
                $isEdit = false;
            }
            $this->view->aboutLabelData = array();
            $errorMessage = "An error occured";
            $this->view->showLabelDataListing = false;

            if ($this->getRequest()->isPost()) {
                $request = $this->getRequest()->getPost();
                $this->_setAboutLabel($request);
                $form = new Form_CourseContentQuestions(0,$showAnswerField,$allCountryDisable,$showB2bB2c);
                $data = $form->getValues();
                if ($form->isValid($request, $errorMessage)) {
                    $data = $form->getValues();
                    if (isset($data['contentCourse'])) {
                        unset($data['contentCourse']['__template__']);
                        $data['contentCourse'] = $data['contentCourse'];
                        $data['contentCourse']['linkable_id'] = $labelId;
                        $data['contentCourse']['linkable_type'] = "label";
                    }
                    $result = false;
                    if (!empty($data['contentCourse']['new']['cluster_id'])) {
                        $countryObj = new Model_Country();
                        $data['contentCourse']['new']['country_id'] =  $countryObj->removeClusterCountries($data['contentCourse']['new']['cluster_id'], $data['contentCourse']['new']['country_id']);
                    }
                    if ($isEdit) {
                        if ($objCourseFaq->addCourseContent($data['contentCourse'], $contentType, $labelId, 0, null, true, "category")) {
                            $result = true;
                        }
                    } elseif ($isNewEntry) {
                        if ($objCourseFaq->addCourseContent($data['contentCourse'], $contentType, $labelId, 0, null, false, "category")) {
                            $result = true;
                        }
                    }

                    if (!$result) {
                        $this->view->message = "An error has occured while saving";
                        $this->view->success = false;
                    } else {
                        $cdnPurgeData = $objLabel->buildCdnPurgeData($labelId, $labelData['name'] . ' Label Faq Data Added / Modified ');
                        $objCdn = new Model_CdnPurgeLog();
                        if (!empty($cdnPurgeData))
                            $objCdn->InsertCdnPurgeLog($cdnPurgeData);
                        $this->view->message = "Saved SuccessFully";
                        $this->view->success = true;
                        $this->_redirect("/admin/label/label-indetail/id/{$labelId}/param/{$labelSectionId}");
                    }
                } else {
                    $this->view->message = $errorMessage;
                    $this->view->success = false;
                }
            } else {
                if ($countryId == '' && $clusterId == '') {
                    $clusterId = 'all';
                } else if ($countryId == 'all') {
                    $clusterId = 0;
                    $countryId = 0;
                }
                $totalResourceCount = count($objCourseFaq->getDataByTypeAndContentId($labelId, "category", $contentType, 0, $clusterId, $countryId, 0, $contentId, $offset, null));
                $labelContent = $objCourseFaq->getDataByTypeAndContentId($labelId, "category", $contentType, 0, $clusterId, $countryId, 0, $contentId, $offset, $limitPerPage);
                // prd($labelContent);
                $totalPages = ceil($totalResourceCount / $limitPerPage);
                $this->view->totalPages = $totalPages;
                $contentLabelData = array(
                    'contentCourse' => $labelContent
                );
                if (!empty($addMore)) {
                    $contentLabelData = array();
                }
                $showCourseFaqForm = empty($contentId) && !empty($contentLabelData) ? false : true;
                $showCourseDataListing = empty($contentId) && !empty($contentLabelData) ? true : false;
                $this->view->detailData = !empty($contentLabelData['contentCourse']) ? $contentLabelData['contentCourse'] : array();
                $this->view->detailListing = $showCourseDataListing;
                $this->view->title = 'Faqs';
                $this->view->linkableId = $labelId;
                $this->view->linkableType = "category";
                $this->view->sectionType = $contentType;
                $this->view->addMore = $addMore;
                $this->view->isEdit = $isEdit;
                $this->_setAboutLabel($contentLabelData, $showCourseFaqForm);
                $default = array();
                if ($showCourseFaqForm) {
                    $this->view->detailListing = false;
                    $addMoreButton = !empty($addMore) ? true : false;
                    $form = new Form_CourseContentQuestions(0, $showAnswerField,$allCountryDisable,$showB2bB2c);
                    $form->setDefaults($default);
                }
            }
        }
        $this->view->sectionTemplates = $sectionTemplatesData;
        if (isset($form)) {
            $this->view->form = $form;
        }
    }

    public function labelMobileAction()
    {
        $objLabel = new Model_Labels();
        $objCourse = new Model_Courses();

        $imageData = array();
        $imageData1 = array();
        if ($labelId = $this->getRequest()->getParam('id')) {
            // Edit
            if (!$objLabel->getById($labelId)) {
                $this->view->message = "Invalid Label Id";
                $this->view->success = false;
                return;
            }
        } else {
            // Add
            $labelId = null;
            $this->view->message = "Label id not given";
            $this->view->success = false;
            return;
        }
        $form = new Form_LabelMobileContent($labelId);


        if ($this->getRequest()->isPost()) {
            $imageInfo = $this->getRequest()->getPost();
            $postData = array_merge_recursive($imageInfo, $_FILES);
            unset($postData['Save']);
            if ($form->isValid($postData)) {
                if (!empty($_FILES['rect_image'])) {
                    if (isset($_FILES['rect_image']['name']) && $_FILES['rect_image']['name'] != '') {
                        $fileName = $_FILES['rect_image']['name'];
                        $absFilePath = $_FILES['rect_image']['tmp_name']; //sys_get_temp_dir().DIRECTORY_SEPARATOR.$fileName;
                        // $absFilePath = sys_get_temp_dir().DIRECTORY_SEPARATOR.$fileName;
                        $s3path = AWS_S3_IMAGES_PATH . '/app';
                        $rectImageUrl = BaseApp_Utility_ImageProcessing::transformAndUploadToS3($absFilePath, $fileName, $s3path);
                        $imageData = array();
                        if (isset($rectImageUrl)) {
                            array_push($imageData, array(
                                'name' => 'rectangular_image',
                                'imagePath' => $rectImageUrl,
                                'linkable_id' => $labelId,
                                'linkable_type' => 'label',
                            ));
                        }
                    }
                }
                if (!empty($_FILES['square_image'])) {
                    if (isset($_FILES['square_image']['name']) && $_FILES['square_image']['name'] != '') {
                        $fileName = $_FILES['square_image']['name'];
                        $absFilePath = $_FILES['square_image']['tmp_name'];
                        // $absFilePath = sys_get_temp_dir().DIRECTORY_SEPARATOR.$fileName;
                        $s3path = AWS_S3_IMAGES_PATH . '/app';
                        $squareImageUrl = BaseApp_Utility_ImageProcessing::transformAndUploadToS3($absFilePath, $fileName, $s3path);
                        $imageData1 = array();
                        if (isset($squareImageUrl)) {
                            array_push($imageData1, array(
                                'name' => 'square_image',
                                'imagePath' => $squareImageUrl,
                                'linkable_id' => $labelId,
                                'linkable_type' => 'label',
                            ));
                        }
                    }
                }
                $data = array_merge($imageData, $imageData1);
                if (!empty($data)) {
                    $objCourse->saveBasicImages($labelId, $data, 'label');
                    $this->view->message = "Uploaded successfully";
                } else {
                    $this->view->message = "Error in uploading";
                    return;
                }
                $imageModel = new Model_Images();
                $imageData = $imageModel->getInclusionImages($labelId, 'label');
                if (!empty($imageData)) {
                    $form = new Form_LabelMobileContent($labelId);
                }
            }
        }
        $this->view->success = true;
        $this->view->form = $form;
    }


    private function _setSubscriptionPrice(&$request) {
        $session = new Zend_Session_Namespace('form');         
        if(isset($request['subscriptionPrice']) && count($request['subscriptionPrice'])) {
            unset($request['subscriptionPrice']['__template__']);
            $request['subscriptionPrice'] = $this->_updateFirstElement($request['subscriptionPrice']);        
            $session->keyfeatures = array_keys($request['subscriptionPrice']);
            array_unshift($session->keyfeatures, '__template__');
            $session->data =  $request['subscriptionPrice'];
        }
        else {
            $session->keyfeatures = array('__template__', 'new');
            $session->data = array();
        }
    }
    
    private function _updateFirstElement($elementArray) {
        $keys = array_keys( $elementArray );
        $keys[ array_search( '0', $keys ) ] = 'new';
        return array_combine( $keys, $elementArray );    
    }
    
    private function _handleDataAfterSubmit(&$data) {
        $returnData = array(
            'imagePath' => '',
            'imageDescription' => '',
            'subscriptionPrice' => array()
        );
        
        if(isset($data['imagePath'])) {
            $returnData['imagePath'] = $data['imagePath'];
            unset($data['imagePath']);
        }
        if(isset($data['imageDescription'])) {
            $returnData['imageDescription'] = $data['imageDescription'];
            unset($data['imageDescription']);
        }
        if(isset($data['subscriptionPrice'])) {
            unset($data['subscriptionPrice']['__template__']);
            $returnData['subscriptionPrice'] = $data['subscriptionPrice'];
            unset($data['subscriptionPrice']);            
        }   
        if(isset($data['parentLabel'])) {
            $data['parentLabel'] = implode(",", $data['parentLabel']);
        }
        $returnData['section_id_arr'] = array();
        if(isset($data['company'])) {
            $returnData['section_id_arr'][] = $data['company'];
        }   

        if(isset($data['course_advisor'])) {
            $returnData['section_id_arr'][] = $data['course_advisor'];
        }   

        if(isset($data['alumni'])) {
            $returnData['section_id_arr'][] = $data['alumni'];
        }
        unset($data['course_advisor']);
        unset($data['company']);
        unset($data['alumni']);
        return $returnData;
    }
    
    public function flyoutAction() {
        if(!$request = $this->getRequest()->getPost()) {
            $this->view->labelList =  $this->getModel()->fetchForSelect(array(), false,array('order'=>'label_id'));
        }
        else {
            $model = new Model_Labels();
            $model->setId($request['label_id']);
            $model->setFromArray(array('popularCourses' => $request['popularList'], 'recentCourses' => $request['recentList'], 'offers'=>$request['offerList']))->update();
            $model->clean();
            
            $module  = $this->getRequest()->getModuleName();
            $controller = $this->getRequest()->getControllerName();
            $action = $this->getRequest()->getActionName();
            if($module && $controller && $action){
                $cdnPurgeData  = $this->getModel()->buildCdnPurgeData($data['label_id'],'Category Modified'.$data['name']);
                $objCdn = new Model_CdnPurgeLog();
                if(!empty($cdnPurgeData))
                    $objCdn->InsertCdnPurgeLog($cdnPurgeData);
                $this->redirect($module.'/'.$controller.'/'.$action.'?success=true');
            }
        }
    }

    private function _saveVideoSeo($videoId, $labelId, $thumbIMage) {
        $return = false;
        $seoMd = new Model_Seo();
        $conds = array(
                'controller=?' => Model_Videos::SEO_DEFAULT_CONTROLLER,
                'action=?' => Model_Videos::SEO_DEFAULT_ACTION,
                'linkable_id=?' => $videoId,
                'linkable_type=?' => 'video'
        );
        if($seoData = current($seoMd->fetchAll($conds, array(), false))) {
            $dataSave = array(
                    'thumb_image' => $thumbIMage
            );
            $seoMd->clean();
            $seoMd->setId($seoData['seo_id']);
            $seoMd->setFromArray($dataSave)->update();
            $return = true;
        }
        else {
            $dataSave = array(
                    'thumb_image' => $thumbIMage,
                    'controller' => Model_Videos::SEO_DEFAULT_CONTROLLER,
                    'action' => Model_Videos::SEO_DEFAULT_ACTION,
                    'params' => json_encode(array(Model_Videos::SEO_DEFAULT_PARAM_KEY=>$videoId,Model_Labels::SEO_DEFAULT_PARAM_KEY=>$labelId)),
                    'linkable_id' => $videoId,
                    'linkable_type' => 'video'
            );
            $return = $seoMd->setFromArray($dataSave)->save();
        }
        return $return;
    }
    public function deleteAction() {
        //parent::deleteAction();
        $id = $this->getRequest()->getParam('id');
        if (ctype_digit($id)) {
            $data = $this->getModel($id);
            $result = $data->delete();
            if ($result) {
                $productId = $id;
                $productType = 'category';
                $action = 'disable';
                $params = array('productId' => $productId, 'productType' => $productType, 'action' => $action);
                $salsesforceApi = new BaseApp_Communication_SalesforceApi();
                $response = $salsesforceApi->SfdcPoductSync($params);
            }
        }
        $module = $this->getRequest()->getModuleName();
        $controller = $this->getRequest()->getControllerName();
        $action = $this->getRequest()->getActionName();
        if ($module && $controller && $action)
            $this->redirect($module . '/' . $controller . '/');
    }
    
    /**
     * _setAboutLabel
     *
     * @param  Array $request
     * @param  Boolean $show
     *
     * @return void
     */
    private function _setAboutLabel(&$request, $show = true)
    {
        $session = new Zend_Session_Namespace('form');
        if ($show) {
            if (isset($request['contentCourse']) && count($request['contentCourse'])) {
                $request['contentCourse'] = $this->_updateFirstElement($request['contentCourse']);
                $session->contentCourse = array_keys($request['contentCourse']);
                array_unshift($session->contentCourse, '__template__');
                $session->contentCourseData = $request['contentCourse'];
            } else {
                $session->contentCourse = array('__template__', 'new');
                $session->contentCourseData = array();
            }
        } else {
            $session->contentCourseData = array();
            $session->contentCourse = array();
        }
    }
    /**
     * faqMoveAction
     *
     * @return void
     */
    public function faqMoveAction()
    {
        $data = $this->getRequest()->getPost();
        $currentPos = $data['current_pos'];
        $finalPosition = $data['to_move_pos'];
        $message = '';
        $status = 'success';
        if (empty($data['course_faq_id']) || empty($data['current_pos']) || empty($data['to_move_pos'])) {
            $message = 'Missing data';
            $status = 'failed';
        } else {
            $objCourseFaq = new Model_CourseFaq();
            if ($currentPos != $finalPosition) {
                if (!$objCourseFaq->changeFaQOrder($data, $currentPos, $finalPosition)) {
                    $message = 'Failed to update';
                    $status = 'failed';
                }
            }
        }


        $this->_helper->layout->disableLayout();
        $this->view->data = array(
            'message' => $message,
            'status' => $status
        );
        $this->_redirect($_SERVER['HTTP_REFERER']);
    }
    /**
     * faqDeleteAction
     *
     * @return void
     */
    public function faqDeleteAction() {
        $data = $this->getRequest()->getPost();
        $faqId = $data['faq_id'];
        $linkableId = $data['linkable_id'];
        $linkableType = $data['linkable_type'];
        $sectionType = $data['section_type'];
        $courseFaqId = array(
            'course_faq_id' => $faqId,
        );
        $faqData = array($courseFaqId);
        $faqData['linkable_id'] = $linkableId;
        $faqData['linkable_type'] = $linkableType;
        $message = '';
        $status = 'success';
        $objCourseFaq = new Model_CourseFaq();
        if (!$objCourseFaq->deleteCourseFaq($faqData, $sectionType)) {
            $message = 'Failed to update';
            $status = 'failed';
        }
        $this->_helper->layout->disableLayout();
        $this->view->data = array(
            'message' => $message,
            'status' => $status
        );
        die(Zend_Json_Encoder::encode($this->view->data));
    }
    /**
     * faqDisableAction
     *
     * @return void
     */
    public function faqDisableAction() {
        $data = $this->getRequest()->getPost();
        $faqId = $data['faq_id'];
        $linkableId = $data['linkable_id'];
        $linkableType = $data['linkable_type'];
        $sectionType = $data['section_type'];
        $crmStatus = $data['crmStatus'];
        $courseFaqId = array(
            'course_faq_id' => $faqId,
        );
        $faqData = array('content_ids' => array($courseFaqId));
        $faqData['linkable_id'] = $linkableId;
        $faqData['linkable_type'] = $linkableType;
        $faqData['cluster_id'] = $data['cluster_id'];
        $faqData['country_id'] = $data['country_id'];
        $faqData['city_id'] = 0;
        $message = '';
        $status = 'success';
        $objCourseFaq = new Model_CourseFaq();
        if (!$objCourseFaq->disableCourseFaq($faqData, $sectionType,$crmStatus)) {
            $message = 'Failed to update';
            $status = 'failed';
        }
        $this->_helper->layout->disableLayout();
        $this->view->data = array(
            'message' => $message,
            'status' => $status
        );
        die(Zend_Json_Encoder::encode($this->view->data));
    }


}
