<?php
/*
 * Contains the CRUD actions of Groups table
 * 
 */

class Admin_GroupController extends BaseApp_Controller_Crud {
    protected $_model = 'Model_Groups';
    
    protected $_descriptions = array(
        'list' => 'List of Existing Groups',
        'index' => 'List of Existing Groups',
        'add' => 'Add New Groups',
        'edit' => 'Make the required changes then click on "Save Groups" to update the Groups',
        'view' => 'View Selected Groups'
    );

    protected function _getForm() {
        $form = new Form_Groups();
        return $form;
    }
    
    public function addAction() {        
        $request = $this->getRequest()->getPost();       
        $this->_setRecommendations($request);
        $this->_setKeyFeatures($request);
        $this->_setGroupFaq($request);
        
        if (!$this->_add)
            $this->forward('list');
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $form = $this->_getForm();        
        if ($form === false)
            throw new Zend_Exception('_getForm not implemented');
        if ($request && $form->isValid($request)) {
            $request = $form->getValues(); 
            $splitData = $this->_handleDataAfterSubmit($request);
            $result = false;
            if($groupId = $this->getModel()->createGroup($request)) {
                $result = true;

                $recommend = new Model_Recommendations();
                if($result && !$recommend->saveRecommendations($groupId, 'group', $splitData['recommendations'])) {
                    $result = false;
                }

                $tags = new Model_Tags();
                if($result && !$tags->saveTags($groupId, 'group', $splitData['searchTags'])) {
                    $result = false;
                }
                
                $features = new Model_KeyFeatures();
                if($result && !$features->saveFeature($groupId, 'group', $splitData['keyFeatures'])) {
                    $result = false;
                }

                $faq = new Model_PracticeFaq();
                if($result && !$faq->saveFaq($groupId, 'group', $splitData['groupFaq'])) {
                    $result = false;
                }
            }                                    
            
            if (!$result) {
                $this->view->message = "An error has occured while saving";
                $this->view->success = true;
            } else {                
                $this->view->message = "Data successfully added";
                $this->view->success = false;
                $form->reset();
                $module  = $this->getRequest()->getModuleName();
                $controller = $this->getRequest()->getControllerName();
                $action = $this->getRequest()->getActionName();
                if($module && $controller && $action)
                    $this->redirect($module.'/'.$controller.'/');
            }
        }
        $this->view->form = $form;
    }
    
    public function editAction() {  
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
                        
        if ($this->getRequest()->isPost()) {
            $request = $this->getRequest()->getPost();      
            $this->_setRecommendations($request);
            $this->_setKeyFeatures($request);
            $this->_setGroupFaq($request);
            
            $form = $this->_getForm();
            $form->removeUneditableElements();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            
            if($form->isValid($request)) {
                $data = $form->getValues();
                $splitData = $this->_handleDataAfterSubmit($data);
                $data['group_id'] = $this->getRequest()->getParam('id');   
                $result = false;
                if($this->getModel()->updateGroup($data)) {
                    $result = true;
                    $recommend = new Model_Recommendations();
                    if($result && !$recommend->saveRecommendations($data['group_id'], 'group', $splitData['recommendations'])) {
                        $result = false;
                    }
                    $tags = new Model_Tags();
                    if($result && !$tags->saveTags($data['group_id'], 'group', $splitData['searchTags'])) {
                        $result = false;
                    }
                    
                    $features = new Model_KeyFeatures();
                    if($result && !$features->saveFeature($data['group_id'], 'group', $splitData['keyFeatures'])) {
                        $result = false;
                    }

                    $faq = new Model_PracticeFaq();
                    if($result && !$faq->saveFaq($data['group_id'], 'group', $splitData['groupFaq'])) {
                        $result = false;
                    }
                }
                if (!$result) {
                    $this->view->message = "An error has occured while saving";
                    $this->view->success = true;
                } else {
                    // for making message page specific
                    $this->view->message = ucwords($this->getRequest()->getControllerName())." Data successfully updated";
                    $this->view->success = false;
                }
                $this->_redirect('/admin/group/list');
            }
        }    
        elseif($groupId = $this->getRequest()->getParam('id')) {            
            $groupModel = new Model_Groups($groupId);
            if(!$groupModel->toArray()) {
                $this->_redirect('/admin/group/list');
            }
             /*
             * recommendation model
             */
            $recommend = new Model_Recommendations();
            $recommendData = array(
                'recommendations' => $recommend->getByLinkable($groupId, 'group')
            );
            $this->_setRecommendations($recommendData);  
            
            /*
             * keyFeature model
             */
            $keyFeatureModel = new Model_KeyFeatures();
            $keyFeatureData = array(
                'keyFeatures' => $keyFeatureModel->getByLinkable($groupId, 'group')
            );
            $this->_setKeyFeatures($keyFeatureData);

            /*
             * faq model
             */           
            $faq = new Model_PracticeFaq();
            $faqData = array(
                'groupFaq' => $faq->getByLinkable($groupId, 'group')
            );
            $this->_setGroupFaq($faqData);
            
            /*
             * tag model
             */
            $tags = new Model_Tags();
            if($tagData = $tags->getByLinkable($groupId, 'group')) {
                $groupModel->searchTags = $tagData['tag'];
            }
            
            $labelModel = new Model_Labels();        
            $groupModel->label_name =  $labelModel->getNameById($groupModel->label_id); 
            
            $groupModel->course_id = explode(",", $groupModel->course_id);
            
            $this->view->postParams = $groupModel;
            $form = $this->_getForm();
            $form->removeUneditableElements();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            $form->setDefaults($groupModel->toArray());            
        }
        else {
            $this->_redirect('/admin/group/list');
        }
        $this->view->form = $form;
    }
   
    private function _handleDataAfterSubmit(&$request) {
        $returnData =array(
            'recommendations' => array(),
            'searchTags' => false,
            'keyFeatures' => array(),
            'bundleFaq' => array()
        );
        unset($request['label_name']);
        unset($request['coursesInclude']);
        unset($request['coursesIncluded']);
        //unset($request['submit']);

        if(isset($request['keyFeatures'])) {
            unset($request['keyFeatures']['__template__']);
            $returnData['keyFeatures'] = $request['keyFeatures'];
            unset($request['keyFeatures']);
        }
        if(isset($request['groupFaq'])) {
            unset($request['groupFaq']['__template__']);
            $returnData['groupFaq'] = $request['groupFaq'];
            unset($request['groupFaq']);
        }
        
        if(isset($request['recommendations'])) {
            $returnData['recommendations'] = $request['recommendations'];
            unset($request['recommendations']);
        }
        if(isset($request['searchTags'])) {
            $returnData['searchTags'] = $request['searchTags'];
            unset($request['searchTags']);
        }  
        
        if(isset($request['course_id']) && is_array($request['course_id'])) {
            $request['course_id'] = implode(",", $request['course_id']);
        } 
        return $returnData;
    }
    
    private function _setRecommendations(&$request) {
        $session = new Zend_Session_Namespace('form'); 
        if(isset($request['recommendations']) && count($request['recommendations'])) {
            $request['recommendations'] = $this->_updateFirstElement($request['recommendations']);        
            $session->recommendations = array_keys($request['recommendations']);
            array_unshift($session->recommendations, '__template__');
            $session->recommendationsData =  $request['recommendations'];
        }
        else {
            $session->recommendations = array('__template__', 'new');
            $session->recommendationsData = array();
        }
    }
    
    private function _setKeyFeatures(&$request) {
        $session = new Zend_Session_Namespace('form'); 
        if(isset($request['keyFeatures']) && count($request['keyFeatures'])) {
            $request['keyFeatures'] = $this->_updateFirstElement($request['keyFeatures']);        
            $session->keyFeatures = array_keys($request['keyFeatures']);
            array_unshift($session->keyFeatures, '__template__');
            $session->keyFeaturesData =  $request['keyFeatures'];
        }
        else {
            $session->keyFeatures = array('__template__', 'new');
            $session->keyFeaturesData = array();
        }
    }
    
    private function _setGroupFaq(&$request) {
        $session = new Zend_Session_Namespace('form'); 
        if(isset($request['groupFaq']) && count($request['groupFaq'])) {
            $request['groupFaq'] = $this->_updateFirstElement($request['groupFaq']);        
            $session->groupFaq = array_keys($request['groupFaq']);
            array_unshift($session->groupFaq, '__template__');
            $session->groupFaqData =  $request['groupFaq'];
        }
        else {
            $session->groupFaq = array('__template__', 'new');
            $session->groupFaqData = array();
        }
    }
    
    private function _updateFirstElement($elementArray) {
        $keys = array_keys( $elementArray );
        $keys[ array_search( '0', $keys ) ] = 'new';
        return array_combine( $keys, $elementArray );    
    }
}
