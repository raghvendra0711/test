<?php

class Admin_FooterLinksController extends BaseApp_Controller_Crud
{

    protected $_model = 'Model_FooterLinks';
    const ROWS_PER_PAGE = 25;
    
    public function init()
    {
        parent::init();
    }

    public function indexAction()
    {
        $request = $this->getRequest()->getPost();
        $countryId = $this->getRequest()->getParam('countryId');
        $clusterId = $this->getRequest()->getParam('clusterId');
        $pageNo = $this->getRequest()->getParam('pageNo');
        $limitPerPage = self::ROWS_PER_PAGE;
        if (empty($pageNo)) {
            $pageNo = 1;
        }
        $calc = $limitPerPage * $pageNo;
        $offset = $calc - $limitPerPage;
        $objFooterlinksModel = new Model_FooterLinks();
        $allFooterLinks = $objFooterlinksModel->getAllFooterLinks($countryId, $clusterId);
        

        $listing = $allFooterLinks;
        $objCountryModel = new Model_Country();
        $countries = $objCountryModel->getListDisplay();
        $objClusterModel = new Model_Clusters();
        $clusters = $objClusterModel->getListDisplay();
        $listingArr = array();
        foreach ($listing as $parentInfo => $valArr) {
            $parentId = current($valArr)['footer_link_id'];
            $listingArr[$parentId]['footer_link_id'] = null;
            $listingArr[$parentId]['clusters'] = array();
            $listingArr[$parentId]['country'] = array();
            $listingArr[$parentId]['links'] = array();
            $listingArr[$parentId]['status'] = FALSE;
            $listingArr[$parentId]['link_category'] = array();
            foreach ($valArr as $index => $value) {
                $listingArr[$parentId]['footer_link_id'] = $value['footer_link_id'];
                if (!empty($value['cluster'])) {
                    $excluded_con_str = '';
                    if (!empty($value['exculded_countries'])) {
                        $excluded_con_arr = explode(',', rtrim(ltrim(trim($value['exculded_countries']), '['), ']'));
                        if (!empty($excluded_con_arr)) {
                            foreach ($excluded_con_arr as $con) {
                                $excluded_con_str .= $countries[$con] . ',';
                            }
                            $excluded_con_str = rtrim($excluded_con_str, ',');
                        }
                    }
                    $listingArr[$parentId]['clusters'][$value['cluster']] = array(
                        'name' => $clusters[$value['cluster']],
                        'exculded_countries' => $excluded_con_str //$value['exculded_countries']
                    );
                }
                if (!empty($value['country'])) {
                    $listingArr[$parentId]['country'][$value['country']] = $countries[$value['country']];
                } elseif ($value['country'] == 0 && $value['cluster'] == 0) {
                    $listingArr[$parentId]['country'][0] = 'All Countries';
                }
                $link_text = array_column($value['links'], 'link_text', 'link_id');
                if (empty($listingArr[$parentId]['links']))
                    $listingArr[$parentId]['links'] = $link_text;
                if (empty($listingArr[$parentId]['link_category'])) {
                    switch ($value['link_category']) {
                        case BaseApp_Dao_FooterLinks::TRENDING_COURSES_LINK:
                            $listingArr[$parentId]['link_category'] = BaseApp_Dao_FooterLinks::TRENDING_COURSES_LINK_TEXT;
                            break;
                        case BaseApp_Dao_FooterLinks::TRENDING_BUNDLES_LINK:
                            $listingArr[$parentId]['link_category'] = BaseApp_Dao_FooterLinks::TRENDING_BUNDLES_LINK_TEXT;
                            break;
                        case BaseApp_Dao_FooterLinks::TRENDING_RESOURCES_LINK:
                            $listingArr[$parentId]['link_category'] = BaseApp_Dao_FooterLinks::TRENDING_RESOURCES_LINK_TEXT;
                            break;
                        default:
                            $listingArr[$parentId]['link_category'] = '';
                            break;
                    }
                }
                if ($listingArr[$parentId]['status'] === FALSE) {
                    $listingArr[$parentId]['status'] = $value['status'];
                }
            }
        }
        $totalProductCount = count($listingArr);
        if($limitPerPage != null) {
            $listingArr = array_slice($listingArr, $offset, $limitPerPage);
        }
        $this->view->selectedCountryId = $countryId;
        $this->view->selectedClusterId = $clusterId;
        
        $totalPages = ceil($totalProductCount / $limitPerPage);
        
        if ($pageNo < $totalPages) {
            $this->view->currentPageRecord = $limitPerPage * $pageNo;
        } else {
            $this->view->currentPageRecord = $totalProductCount;
        }
        $this->view->diffPageRecord = $this->view->currentPageRecord - $limitPerPage;
//        if ($totalProductCount < $limitPerPage) {
//            $this->view->diffPageRecord = 0;
//        }
        if($pageNo == $totalPages){
            $this->view->diffPageRecord = ($pageNo-1) * $limitPerPage;
        }
        
        $this->view->totalPages = $totalPages;
        $this->view->startPos = $offset;
        $this->view->curPageNo = $pageNo;
        $this->view->pageLimit = $limitPerPage;
        $this->view->totalCount = $totalProductCount;
        
        $this->view->countryList = $countries;
        $this->view->cluster = $clusters;
        $this->view->allFooterLinks = $listingArr;
        $this->_helper->viewRenderer('footer-links/index', null, true);
    }

    public function deleteAction()
    {
        $response = array('status' => 'failed', 'message' => 'Delete Failed');
        $footer_link_id = $this->getRequest()->getParam('flink_id');
        $objFooterlinksModel = new Model_FooterLinks();
        if (empty($footer_link_id)) {
            $response = array('status' => 'failed', 'message' => 'empty $footer_link_id');
        } else {
            $response = $objFooterlinksModel->deleteFooterLink($footer_link_id);
            if ($response['status']) {
                $response = array('status' => 'success', 'message' => 'Successfully deleted');
            }
        }
        echo json_encode($response);
        exit;
    }

    public function disableAction()
    {
        $response = array('status' => 'failed', 'message' => 'Disable Failed');
        $footer_link_id = $this->getRequest()->getParam('flink_id');
        $objFooterlinksModel = new Model_FooterLinks();
        if (empty($footer_link_id)) {
            $response = array('status' => 'failed', 'message' => 'empty $footer_link_id');
        } else {
            $response = $objFooterlinksModel->disableFooterLink($footer_link_id);
            if ($response['status']) {
                $response = array('status' => 'success', 'message' => 'Successfully disabled');
            }
        }
        echo json_encode($response);
        exit;
    }

    public function enableAction()
    {
        $response = array('status' => 'failed', 'message' => 'Enable Failed');
        $footer_link_id = $this->getRequest()->getParam('flink_id');
        $objFooterlinksModel = new Model_FooterLinks();
        if (empty($footer_link_id)) {
            $response = array('status' => 'failed', 'message' => 'empty $footer_link_id');
        } else {
            $response = $objFooterlinksModel->enableFooterLink($footer_link_id);
            if ($response['status']) {
                $response = array('status' => 'success', 'message' => 'Successfully enabled');
            }
        }
        echo json_encode($response);
        exit;
    }

    protected function _getForm($new = false)
    {
        $form = new Form_FooterLinks($new);
        return $form;
    }

    public function addAction()
    {
        $request = $this->getRequest()->getPost();
        if (!$request) {
            //show add form            
            $data = array(
                'contentForm' => array('new' => array())
            );
            $this->_setContentForm($data);
            $form = $this->_getForm(true);
            $this->view->form = $form;
        } else {
            //save form data
            $isValid = false;
            $response = $this->_validateFormValues($request);
            if ($response['status'] === TRUE)
                $isValid = TRUE;
            else {
                $message = $response['msg'];
            }
            if ($isValid) {
                $saveData = $request['contentForm']['new'];
                //add data here                    
                $objFooterlinksModel = new Model_FooterLinks();
                $response = $objFooterlinksModel->saveFooterLinks($saveData);
                $message = $response['msg'];
                $this->_redirect('/admin/footer-links');
            } else {
                $form = $this->_getForm(true);
                $form->setDefaults($request);
                $this->view->success = false;
                $this->view->message = $message;
                $this->view->form = $form;
                return false;
            }
        }
    }

    public function testAction()
    {
        $countries = array(2, 6, 213, 74, 106);
        $objFooterlinksModel = new Model_FooterLinks();
        $cLink = $objFooterlinksModel->fetchLinksByCountry($countries, 1);
        prd($cLink);
    }

    private function _validateFormValues($request = array())
    {
        $msg = "data is valid";
        $linksData = (isset($request['contentForm']['new']['footer_links'])
            && !empty($request['contentForm']['new']['footer_links']))
            && ($request['contentForm']['new']['footer_links'] != '[]') ? $request['contentForm']['new']['footer_links'] : array();
        
        $status = true;
        $response = array('status' => $status, 'msg' => $msg);
        
        if (!empty($request) && isset($request['contentForm']['new']) && !empty($request['contentForm']['new'])) {
            $fData = $request['contentForm']['new'];
            // prd($fData);
            if ((!isset($fData['footerCategory']) || empty($fData['footerCategory']))) {
                $msg = "Please enter footer category field.\n";
                $status = false;
                $response = array('status' => $status, 'msg' => $msg);
                return $response;
            } elseif ($fData['all_country'] == 1) {
                $objFooterlinksModel = new Model_FooterLinks();
                $allCountryData = $objFooterlinksModel->fetchAllCountryData($fData['footerCategory']);
                $footlink = array_column($allCountryData,'id');
                if ($allCountryData && !empty($allCountryData) && ( empty($fData['footer_link_id']) || !in_array($fData['footer_link_id'],$footlink))) {
                    $msg = "All country data already exists with this category.\n ";
                    $status = false;
                    $response = array('status' => $status, 'msg' => $msg);
                    return $response;
                }
            } else if ((!isset($fData['cluster_id']) || empty($fData['cluster_id'])) && (!isset($fData['country_id']) || empty($fData['country_id']))) {
                $msg = "Please enter atleast one cluster or country or All countries.";
                $status = false;
                $response = array('status' => $status, 'msg' => $msg);
                return $response;
            } else if ((isset($fData['cluster_id']) && count($fData['cluster_id']) == 1) && (!isset($fData['country_id']) || empty($fData['country_id']))) {
                $objFooterlinksModel = new Model_FooterLinks();
                $allClusterData = $objFooterlinksModel->fetchClusterData($fData['footerCategory'],$fData['cluster_id'][0]);
                $footlink = array_column($allClusterData,'id');
                if ($allClusterData && !empty($allClusterData) && ( empty($fData['footer_link_id']) || !in_array($fData['footer_link_id'],$footlink))) {
                    $msg = "Cluster data already exists with this category.\n ";
                    $status = false;
                    $response = array('status' => $status, 'msg' => $msg);
                    return $response;
                }
            }else if ((isset($fData['country_id']) && count($fData['country_id']) == 1) && (!isset($fData['cluster_id']) || empty($fData['cluster_id']))) {
                $objFooterlinksModel = new Model_FooterLinks();
                $countryData = $objFooterlinksModel->fetchCountryData($fData['footerCategory'],$fData['country_id'][0]);
                $footlink = array_column($countryData,'id');
                if ($countryData && !empty($countryData) && ( empty($fData['footer_link_id']) || !in_array($fData['footer_link_id'],$footlink))) {
                    $msg = "Country data already exists with this category.\n ";
                    $status = false;
                    $response = array('status' => $status, 'msg' => $msg);
                    return $response;
                }
            }else if (isset($fData['cluster_id'],$fData['country_id']) && count($fData['cluster_id']) > 1 && count($fData['country_id']) > 1) {
                // allow combo/multi selection
            }

            if (!empty($linksData)) {
                $response = $this->_validateLinks($linksData);
                //prd($response);
                if ($response['status'] === false) {
                    if ($status === false)
                        $msg .= $response['msg'];
                    else
                        $msg = $response['msg'];
                    $status = false;

                    $response = array('status' => $status, 'msg' => $msg);
                    return $response;
                }
            }else{
                $msg = "Please enter atleast one Link.";
                $status = false;
                $response = array('status' => $status, 'msg' => $msg);
                return $response;
            }
        }
        $response = array('status' => $status, 'msg' => $msg);
        return $response;
    }

    private function _validateLinks($linksData)
    {
        $status = true;
        $msg = "valid links";
        $linksArrData = (!empty($linksData)) ? json_decode($linksData) : array();
        
        if (count($linksArrData) == 0) {
            $msg = "Please add atleast one link.";
            $status = false;
        } else {
            $count = 0;
            foreach ($linksArrData as $key => $value) {
                if ($value->status == 1 || $value->status == 2) {
                    $count += 1;
                }
            }
            if ($count == 0) {
                $msg = "No link to add, Please add atleast one Link";
                $status = false;
            }
        }
        return array('status' => $status, 'msg' => $msg);
    }
    private function _setContentForm($request, $show = true)
    {
        $session = new Zend_Session_Namespace('form');
        if ($show) {
            if (isset($request['contentForm']) && count($request['contentForm'])) {
                $request['contentForm'] = $this->_updateFirstElement($request['contentForm']);
                $session->contentForm = array_keys($request['contentForm']);
                array_unshift($session->contentForm, '__template__');

                if (isset($request['contentForm']) && count($request['contentForm'])) {
                    $session->contentFormData = $request['contentForm'];
                } else {
                    $session->contentFormData = array();
                }
            } else {
                $session->contentForm = array('__template__', 'new');
                $session->contentFormData = array();
            }
        } else {
            $session->contentFormData = array();
            $session->contentForm = array();
        }
    }

    private function _updateFirstElement($elementArray)
    {
        $keys = array_keys($elementArray);
        $keys[array_search('0', $keys)] = 'new';
        return array_combine($keys, $elementArray);
    }

    public function editAction()
    {
        $linkId = $this->getRequest()->getParam('id');
        $request = $this->getRequest()->getPost();
        // pr($request);
        $objFooterlinksModel = new Model_FooterLinks();
        $this->_helper->viewRenderer('footer-links/add', null, true);
        if (!$request) {
            $linkDetails = $objFooterlinksModel->getFooterLinkDetailById($linkId);
            $data = array(
                'contentForm' => array('new' => $linkDetails)
            );
            $this->_setContentForm($data);
            $form = new Form_FooterLinks(false);
            $this->view->form = $form;
        } else {
            $isValid = false;
            $request['contentForm']['new']['footerCategory'] = $request['contentForm']['new']['hidden_footerCategory'];
            $request['contentForm']['new']['all_country'] = $request['contentForm']['new']['hidden_all_country'];
            $request['contentForm']['new']['cluster_id'] = json_decode($request['contentForm']['new']['hidden_cluster_id'],true);
            $request['contentForm']['new']['country_id'] = json_decode($request['contentForm']['new']['hidden_country_id'],true);

            $response = $this->_validateFormValues($request);
            if ($response['status'] === TRUE)
                $isValid = TRUE;
            else {
                $message = $response['msg'];
            }
            if ($isValid) {
                $saveData = $request['contentForm']['new'];
                $footer_link_id = isset($saveData['footer_link_id']) ? $saveData['footer_link_id'] : 0;
                if ($footer_link_id) {
                    //update data here 
                    $objFooterlinksModel = new Model_FooterLinks();
                    $response = $objFooterlinksModel->saveFooterLinks($saveData, $footer_link_id);
                    // $message = $response['msg'];
                    $this->_redirect('/admin/footer-links');
                } else {
                    $message = 'Invalid footer_link_id';
                    $form = $this->_getForm();
                    $form->setDefaults($request);
                    $this->view->success = false;
                    $this->view->message = $message;
                    $this->view->form = $form;
                    return false;
                }
            } else {
                $form = $this->_getForm();
                $form->setDefaults($request);
                $this->view->success = false;
                $this->view->message = $message;
                $this->view->form = $form;
                return false;
            }
        }
    }
}
