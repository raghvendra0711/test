<?php

/*
 * Contains the CRUD actions of EntityListing table
 * 
 */

class Admin_EntityListingController extends BaseApp_Controller_Crud {

    protected $_model = 'Model_EntityListing';
    protected $_descriptions = array(
        'list' => 'List of Existing entities',
        'index' => 'List of Existing entities',
        'add' => 'Add New Entity',
        'edit' => 'Edit Entity',
        'view' => 'View Selected Entity'
    );

    protected function _getForm() {
        $form = new Form_EntityListing();
        return $form;
    }

    public function addAction() {
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $form = new Form_EntityListing();
        $request = $this->getRequest()->getPost();
        if ($this->getRequest()->isPost() && $form->isValid($request)) {
            $data = $form->getValues();
            if(!empty($data['url'])){
                $data['url'] = trim($data['url']);
                $checkSlash = substr($data['url'], 0,1);
                if($checkSlash != '/'){
                    $data['url'] = trim('/'.$data['url']);
                }
            }
            $objSeo = new Model_Seo();
            $seoData = current($objSeo->fetchAll(array('url =?'=>trim($data['url']))));
            if(!empty($seoData)){
                $this->view->message = $data['url']."Does Exists";
                $this->view->success = false;
                $this->view->form = $form;
                return false;
            }
            $objEl = new Model_EntityListing();
            $result = $objEl->createListings($data);
            if (!$result) {
                $this->view->message = "An error has occured while saving";
                $this->view->success = true;
            } else {
                $this->view->message = "Saved SuccessFully";
                $this->view->success = false;
                $form->reset();
                $module  = $this->getRequest()->getModuleName();
                $controller = $this->getRequest()->getControllerName();
                $action = $this->getRequest()->getActionName();
                if($module && $controller && $action)
                    $this->redirect($module.'/'.$controller.'/list');
            }
        }
        $this->view->form = $form;
    }


    public function editAction() {
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $Id = $this->getRequest()->getParam('id');
        if(!$Id)
            throw new BaseApp_Exception('Editable item not selected properly');        
        $elData = $objEl = new Model_EntityListing($Id);
        $elData = $elData->toArray();
        $elData['course_id'] =  explode(',', $elData['course_id']);
        $elData['training_id'] =  explode(',', $elData['training_id']);
        $objimage = new Model_Images();
        $imageId = '';
        $imageData = $objimage->fetchAll(array('linkable_id = ?'=>$elData['entity_listing_id'],'linkable_type =?'=>'entityListing'));
        if(!empty($imageData)){
            $imageId = $imageData[0]['image_id'];
            $elData['imageUrl'] = $imageData[0]['imagePath'];
        }
        $modelSeo = new Model_Seo();
        $seoData = $modelSeo->fetchAll(array('linkable_id = ?'=>$Id,'linkable_type =?'=>'entityListing'));
        if(!empty($seoData)){
            $imageId = $seoData[0]['url'];
            $elData['url'] = $seoData[0]['url'];
        }
        if (!$elData)
            throw new BaseApp_Exception('Editable item not selected properly');
        $form = new Form_EntityListing();
        if ($this->getRequest()->isPost()) { 
            $form->removeUneditableElements();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            if ($form->isValid($this->getRequest()->getPost())) {
                $data = $form->getValues();
                $data['course_id'] =  implode(',', $data['course_id']);
                $data['training_id'] =  implode(',', $data['training_id']);
                $data['image_id'] = $imageId;
                $result = $this->getModel()->UpdateListings($Id, $data);
                if(!$result) {
                    $this->view->message = "An error has occured while saving";
                    $this->view->success = true;
                    $module  = $this->getRequest()->getModuleName();
                    $controller = $this->getRequest()->getControllerName();
                    $action = $this->getRequest()->getActionName();
                    if($module && $controller && $action)
                        $this->redirect($module.'/'.$controller.'/'.$action.'/id/'.$Id);
                }else{
                    $this->view->message = "Saved SuccessFully";
                    $this->view->success = false;
                    $form->reset();
                    $module  = $this->getRequest()->getModuleName();
                    $controller = $this->getRequest()->getControllerName();
                    $action = $this->getRequest()->getActionName();
                    if($module && $controller && $action)
                        $this->redirect($module.'/'.$controller.'/list');
                }
            }else {                                
                $form->setDefaults($elData);
                $form->removeUneditableElements();
            }
        }
        else {
            $form->setDefaults($elData);
            $form->removeUneditableElements();
        }
        $this->view->form = $form;
    }

    public function deleteAction() {
        $this->_helper->viewRenderer->setRender('common/delete')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $entityListingId = $this->getRequest()->getParam('id');
        $dataDelete = $this->getModel($entityListingId);        
        if(!$dataDelete->toArray()) {
            $this->view->message = "Invalid Entity course";
            $this->view->success = false;
            return;
        }
        if(!$this->getModel()->deleteEntityListing($entityListingId)) {
            $this->view->message = 'Oops Something Went Wrong';
            $this->view->success = false;
            return;
        }
        $this->_redirect("/admin/entity-listing/list");
    }
}
