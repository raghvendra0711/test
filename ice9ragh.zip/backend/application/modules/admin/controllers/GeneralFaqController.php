<?php
/*
 *CRUD for banners
 * 
 */

class Admin_GeneralFaqController extends BaseApp_Controller_Crud {
    protected $_model = 'Model_GeneralFaq';
    protected $_descriptions = array(
        'list' => 'List of Existing Labels',
        'index' => 'List of Existing Labels',
        'add' => 'Add New Labels',
        'edit' => 'Make the required changes then click on "Save Labels" to update the Labels',
        'view' => 'View Selected Labels'
    );

    public function indexAction() {
        
    }
    
    protected function _getForm() {
        $form = new Form_GeneralFaq();
        return $form;
    }
    
    public function addAction() {        
        $request = $this->getRequest()->getPost();       
        if (!$this->_add)
            $this->forward('list');
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $form = $this->_getForm();        
        if ($form === false)
            throw new Zend_Exception('_getForm not implemented');
        if ($request && $form->isValid($request)) {
            $request = $form->getValues(); 
            $result = $this->getModel()->createFaq($request);
            
            if (!$result) {
                $this->view->message = "An error has occured while saving";
                $this->view->success = true;
            } else {                
                $this->view->message = "Data successfully added";
                $this->view->success = false;
                $form->reset();
                $module  = $this->getRequest()->getModuleName();
                $controller = $this->getRequest()->getControllerName();
                $action = $this->getRequest()->getActionName();
                if($module && $controller && $action)
                    $this->redirect($module.'/'.$controller.'/list');
            }
        }
        $this->view->form = $form;
    }
    
    public function editAction() {  
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
                        
        if ($this->getRequest()->isPost()) {
            $request = $this->getRequest()->getPost();       
            
            $form = $this->_getForm();
            $form->removeUneditableElements();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            
            if($form->isValid($request)) {
                $data = $form->getValues();
                $data['faq_id'] = $this->getRequest()->getParam('id');
                $result = $this->getModel()->updateFaq($data);
                
                if (!$result) {
                    $this->view->message = "An error has occured while saving";
                    $this->view->success = true;
                } else {
                    // for making message page specific
                    $this->view->message = ucwords($this->getRequest()->getControllerName())." Data successfully updated";
                    $this->view->success = false;
                }
                $this->_redirect('/admin/general-faq/list');
            }
        }    
        elseif($faqId = $this->getRequest()->getParam('id')) {            
            $faqModel = new Model_GeneralFaq($faqId);
            if(!$faqModel->toArray()) {
                $this->_redirect('/admin/general-faq/list');
            }

            $this->view->postParams = $faqModel;
            $form = $this->_getForm();
            $form->removeUneditableElements();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            $form->setDefaults($faqModel->toArray());            
        }
        else {
            $this->_redirect('/admin/general-faq/list');
        }
        $this->view->form = $form;
    }    
}
