<?php

class Admin_CityPageController extends BaseApp_Controller_Crud {

    protected $_model = 'Model_CityPage';
    protected $_descriptions = array(
        'add' => 'Add New CityPage',
    );
    protected $coursesWithCitPage = array();
    public function init() {
        parent::init();
        $this->_getCourseWithCityPage();
        $this->_getBundleWithCityPage();
    }

    /**
     * Get Course With City
     */
    private function _getCourseWithCityPage() {
        $cityPageModel = new Model_CityPage();
        $seoCourseList = $cityPageModel->getCourseList();
        $seocourseCityPageList = $cityPageModel->getAllCourseCity();
        $courseList = $courseCityList = $courseListWithCityPage = array();
        if (!empty($seoCourseList)) {
            $courseList = array_column($seoCourseList, 'name', 'linkable_id');
        }
        if (!empty($seocourseCityPageList)) {
            $courseCityList = array_column($seocourseCityPageList, 'linkable_id');
            $courseCityList = array_unique($courseCityList);
            $courseCityList = array_values($courseCityList);
            $courseCityList = array_flip($courseCityList);
        }
        $courseListWithCityPage = array_intersect_key($courseList, $courseCityList);
        $this->coursesWithCitPage = $courseListWithCityPage;
    }
    
    private function _getBundleWithCityPage() {
        $cityPageModel = new Model_CityPage();
        $seoCourseList = $cityPageModel->getBundleList();
        $seocourseCityPageList = $cityPageModel->getAllBundleCities();
        $courseList = $courseCityList = $bundleListWithCityPage = array();
        if (!empty($seoCourseList)) {
            $courseList = array_column($seoCourseList, 'name', 'linkable_id');
        }
        if (!empty($seocourseCityPageList)) {
            $courseCityList = array_column($seocourseCityPageList, 'linkable_id');
            $courseCityList = array_unique($courseCityList);
            $courseCityList = array_values($courseCityList);
            $courseCityList = array_flip($courseCityList);
        }
        $bundleListWithCityPage = array_intersect_key($courseList, $courseCityList);
        $this->bundlesWithCitPage = $bundleListWithCityPage;
    }

    /**
     * Get Form
     * @return \Form_CityPage
     */
    protected function _getForm() {
        $form = new Form_CityPage();
        return $form;
    }

    public function addAction() {
        $form = $this->_getForm();
        $this->view->form = $form;
        $this->view->coursesWithCitPage = $this->coursesWithCitPage;
        $this->view->bundlesWithCitPage = $this->bundlesWithCitPage;
    }

    public function saveBenefitSalaryAction()
    {
        $contentType = BaseApp_Dao_CourseFaq::COURSE_RESOURCE_BENEFITS;
        $productId = $this->getRequest()->getParam('linkable_id');
        $productType = $this->getRequest()->getParam('linkable_type');
        $countryId = $this->getRequest()->getParam('country_id');
        $cityId = $this->getRequest()->getParam('city_id');
        $clusterId = $this->getRequest()->getParam('cluster_id');
        $answer = $this->getRequest()->getParam('answer');
        $course_faq_id = $this->getRequest()->getParam('course_faq_id');
        $jobdesignation = $this->getRequest()->getParam('jobdesignation');
        $isEdit = !empty($course_faq_id) ? true: false;
        $objCourseFaq = new Model_CourseFaq();
        $objCourseSection = new Model_CourseSections();
        $productType = $productType == 1 ? 'course': 'bundle';
        $courseSectionData = $objCourseSection->getSectionByCourseIdSectionId($productId,BaseApp_Dao_CourseSections::COURSE_SECTION_BENEFITS);
        $batchBenefitsData = array();
        //before saving faq check if data exists for country and show error if it does;                               
        $contentExistsForCity = $this->_contentExistsForCity($productId,$productType, $contentType, $courseSectionData['training_id'], 0,  0,$cityId);
        if ($contentExistsForCity) {
            $bData = array();
            $bData['city_id'] = $cityId;
            $bData['answer'] = $answer;
            $bData['course_faq_id'] = $course_faq_id;
            $bData['jobdesignation'] = $jobdesignation;
            $dataSave['new'] = $bData;
            $dataSave['linkable_id'] = $productId;
            $dataSave['linkable_type'] = $productType;
        }else{
            $bData = array();
            $bData['city_id'] = $cityId;
            $bData['answer'] = $answer;
            $bData['jobdesignation'] = $jobdesignation;
            $dataSave['new'] = $bData;
            $dataSave['linkable_id'] = $productId;
            $dataSave['linkable_type'] = $productType;
        }

        $batchBenefitsData['contentCourse'] = $dataSave;
        $resp = false;
        if ($faqId = $objCourseFaq->addCourseContent($batchBenefitsData['contentCourse'], $contentType, $productId, $courseSectionData['training_id'], null, $isEdit, $productType)) {
            //save job designations
            if (($contentType == BaseApp_Dao_CourseFaq::COURSE_RESOURCE_BENEFITS) && !empty($batchBenefitsData['contentCourse']['new']['jobdesignation'])) {
                $resp = $this->_saveCourseJobDesignations($batchBenefitsData['contentCourse']['new']['jobdesignation'], $faqId,$isEdit);
            }
        }

        if ($resp) {
            $result['status'] = true;
            $result['message'] = 'Success';
        } else {
            $result['status'] = false;
            $result['message'] = 'Failed';
        }
    
        $this->_helper->layout->disableLayout();
        echo json_encode($result);
        exit;
        
    }

    private function _contentExistsForCity($productId,$productType, $contentType, $trainingId, $clusterId, $countryId,$cityId)
    {
        $objCourseFaq = new Model_CourseFaq();
        $contentCountryId = !empty($countryId) ? $countryId : 0;
        $cityContent = $objCourseFaq->getDataByTypeAndContentId($productId, $productType, $contentType, $trainingId, $clusterId, $contentCountryId,$cityId);
        if (!empty($cityContent)) {
            foreach ($cityContent as $content) {
                if ($content['cityIds'] == $cityId) {
                    return true;
                }
            }
        }
        return false;
    }

    private function _saveCourseJobDesignations($data, $faqId, $isEdit)
    {
        try {
            $sessionMapping = new Model_ProductSectionData();
            $existingJobs = $sessionMapping->getDataByType($faqId, BaseApp_Dao_SectionMapping::COURSE_FAQ_LINKABLE_TYPE, BaseApp_Dao_ProductSectionData::JOB_DESIGNATION_SECTION_TYPE, true, 'sm.id ASC');

            //Saving existing and updated jobs to compare and delete the removed jobs.
            $existingJobsArr = array();
            $productMapArr = array();
            $updatedJobsArr = array();
            if (!empty($existingJobs)) {
                foreach ($existingJobs as $existingJob) {
                    array_push($existingJobsArr, $existingJob['id']);
                    $productMapArr[$existingJob['id']] = $existingJob['section_id'];
                }
            }

            if (!empty($data)) {
                foreach ($data as $key => $job) {
                    if (!empty($job)) {
                        if ($key === '__template__') {
                            continue;
                        }

                        $produtSectionId = $job['section_id'];
                        $produtSectionMapId = $job['section_map_id'];
                        $sectionMapObj = new Model_SectionMapping();
                        if (!$isEdit || empty($produtSectionMapId)) {
                            foreach (array(BaseApp_Dao_SectionMapping::COURSE_FAQ_LINKABLE_TYPE /*,BaseApp_Dao_SectionMapping::HIRING_COMPANY_LINKABLE_TYPE*/) as $linkableTypeNew) {
                                $sectionMapObj->clean();
                                $smdata = array();
                                $smdata['linkable_id'] = $faqId;
                                $smdata['linkable_type'] = $linkableTypeNew;
                                $smdata['section_id'] = $produtSectionId;
                                $sectionMapObj->setFromArray($smdata)->save();
                                if ($linkableTypeNew == BaseApp_Dao_SectionMapping::COURSE_FAQ_LINKABLE_TYPE) {
                                    $produtSectionMapId = $sectionMapObj->id;
                                }
                            }
                        } else {

                            $sectionMapObj->clean();
                            $sectionMapObj->setId($produtSectionMapId);
                            $smdata = array();
                            $smdata['section_id'] = $produtSectionId;
                            $sectionMapObj->setFromArray($smdata)->update();
                        }

                        if ($produtSectionId) {
                            //saving job salaries
                            //check if salary exists and delete them 
                            $salaries = new Model_Salaries();
                            $salaryData = array(
                                'min' => $job['min'],
                                'avg' => $job['avg'],
                                'max' => $job['max']
                            );

                            if (!$salaries->saveSalaries($salaryData, $produtSectionId, $produtSectionMapId)) {
                                throw new BaseApp_Exception('Could not save Job salaries  mapping');
                            }
                        } else {
                            throw new BaseApp_Exception('Could not save Job designation');
                        }
                    }
                }
            }
            return true;
        } catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }

    /**
     * Get Course Cities and Countries
     */
    public function getCourseCitiesAction() {
        $courseId = $this->getRequest()->get('courseId');
        $productTypeId = $this->getRequest()->get('productTypeId');
        if(empty($productTypeId)) {
            $productTypeId = BaseApp_Dao_Courses::PRODUCT_TYPE_ID;
        }
        $cityList = $cityCountryList = $sortedCityList = array();
        if ($courseId && is_numeric($courseId)) {
            $cityPageModel = new Model_CityPage();
            $cityList = array();
            if($productTypeId == BaseApp_Dao_Bundles::PRODUCT_TYPE_ID) {
                $cityList = $cityPageModel->getBundleCities($courseId);
            } else {
                $cityList = $cityPageModel->getCourseCities($courseId);
            }
            if (!empty($cityList)) {
                $cityIds = array_keys($cityList);
                $countryData = $cityPageModel->countryDataByCityId($cityIds);
                $cityCountryNameMapping = array_column($countryData, 'name', 'city_id');
                $cityCountryIdMapping = array_column($countryData, 'country_id', 'city_id');
                if (!empty($cityCountryNameMapping)) {
                    foreach ($cityList as $id => $cityName) {
                        if (!empty($cityCountryNameMapping[$id])) {
                            $countryName = $cityCountryNameMapping[$id];
                            $countryCityName = $countryName . ' - ' . $cityName;
                            $cityCountryList[$id] = $countryCityName;
                        }
                    }
                    asort($cityCountryList);
                    foreach ($cityCountryList as $key => $val) {
                        $sortedCityList[] = array('id' => $key, 'name' => $val, 'country_id' => $cityCountryIdMapping[$key]);
                    }
                }
            }
        }
        $this->_helper->layout->disableLayout();
        $this->view->courseCities = $sortedCityList;
    }

    /**
     * Get Country By City Id
     */
    public function getCountryByCityIdAction() {
        $cityId = $this->getRequest()->get('cityId');
        $result = array();
        if ($cityId && is_numeric($cityId)) {
            $cityPageModel = new Model_CityPage();
            $result = $cityPageModel->getCountryByCityId($cityId);
        }
        $this->_helper->layout->disableLayout();
        $this->view->countryId = $result;
    }

    private function _updateFirstElement($elementArray)
    {
        $keys = array_keys($elementArray);
        $keys[array_search('0', $keys)] = 'new';
        return array_combine($keys, $elementArray);
    }

    private function _setContentCourse(&$request, $show = true) {
        $session = new Zend_Session_Namespace('form');
        if ($show) {
            if (isset($request['contentCourse']) && count($request['contentCourse'])) {
                $request['contentCourse'] = $this->_updateFirstElement($request['contentCourse']);
                $session->contentCourse = array_keys($request['contentCourse']);
                array_unshift($session->contentCourse, '__template__');
                if (isset($request['contentCourse']['new']) && isset($request['contentCourse']['new']['jobdesignation'])){
                    unset($request['contentCourse']['new']['jobdesignation']['__template__']);
                }
                $session->contentCourseData = $request['contentCourse'];
            } else {
                $session->contentCourse = array('__template__', 'new');
                $session->contentCourseData = array();
            }
        } else {
            $session->contentCourseData = array();
            $session->contentCourse = array();
        }
    }

    /**
     * Get Course City Data
     */
    public function getCourseCityDataAction()
    {
        $result = $courseFaqs = array();
        $cityId = $this->getRequest()->get('cityId');
        $courseId = $this->getRequest()->get('courseId');
        $trainingTypeId = $this->getRequest()->get('trainingTypeId');
        $productTypeId = $this->getRequest()->get('productTypeId');
        $procutType = Model_CourseCityLookup::getLinkableTypeByProductTypeId($productTypeId);
        $countryId = $this->getRequest()->get('countryId');
        $useBenefitContentId = false;

        if ($cityId && $courseId) {
            $cityPageModel = new Model_CityPage();
            // $courseFaqRes = $cityPageModel->getCourseFaqs($cityId, $courseId, $trainingTypeId,$countryId);
            $objCourseFaq = new Model_CourseFaq();

            /** Benefit Section Start */
            if (empty($trainingTypeId)) {
                $contentBenefitType = BaseApp_Dao_CourseFaq::COURSE_RESOURCE_BENEFITS;
                $objCourseSection = new Model_CourseSections();
                $courseBenefitSectionData = $objCourseSection->getSectionByCourseIdSectionId($courseId, 7);
                $useBenefitContentId = true;
                $allCountryContentId = 0;

                //get city Specific
                $courseContentInfo = $objCourseFaq->getContentIdByTypeAndCourseId($courseId, $contentBenefitType, 0, 0, $cityId);
                if (empty($courseContentInfo)) {
                    //get Country info
                    $courseContentInfo = $objCourseFaq->getContentIdByTypeAndCourseId($courseId, $contentBenefitType, 0, $countryId, 0);
                    $useBenefitContentId = false;
                } elseif (!empty($courseContentInfo) && $countryId == INDIA_COUNTRY_ID) {
                    //get Country designation info to merge - today only India
                    $countryCourseContInfo = $objCourseFaq->getContentIdByTypeAndCourseId($courseId, $contentBenefitType, 0, $countryId, 0);
                    $sameCountryContentId = !empty($countryCourseContInfo['faq_id']) ? $countryCourseContInfo['faq_id'] : 0;
                }

                if (empty($courseContentInfo) && $countryId != INDIA_COUNTRY_ID) {
                    //get all Countries - US
                    $courseContentInfo = $objCourseFaq->getContentIdByTypeAndCourseId($courseId, $contentBenefitType, 0, 0, 0);
                    $useBenefitContentId = false;
                    //will be used by ROW city's for non-existing
                    $allCountryContentId = !empty($courseContentInfo['faq_id']) ? $courseContentInfo['faq_id'] : 0;
                } else if ($countryId != INDIA_COUNTRY_ID) {
                    //get all Countries - US designation into  to merge
                    $allCourseContInfo = $objCourseFaq->getContentIdByTypeAndCourseId($courseId, $contentBenefitType, 0, 0, 0);
                    //will be used by ROW city's for existing to merge
                    $allCountryContentId = !empty($allCourseContInfo['faq_id']) ? $allCourseContInfo['faq_id'] : 0;
                }

                $benefitContentId = !empty($courseContentInfo['faq_id']) ? $courseContentInfo['faq_id'] : 0;
                $benefitParams = array();
                if (!empty($benefitContentId)) {
                    $fetchedFrom = 'city';
                    //get city Specific
                    $courseBenefitContent = $objCourseFaq->getDataByTypeAndContentId($courseId, $procutType, $contentBenefitType, $courseBenefitSectionData['training_id'], 0, 0, $cityId, $benefitContentId);
                    if (empty($courseBenefitContent)) {
                        //get country - today - exists only for india
                        $courseBenefitContent = $objCourseFaq->getDataByTypeAndContentId($courseId, $procutType, $contentBenefitType, $courseBenefitSectionData['training_id'], 0, $countryId, 0, $benefitContentId);
                        $fetchedFrom = 'country';
                    }
                    if (empty($courseBenefitContent) && $countryId != INDIA_COUNTRY_ID) {
                        //get common
                        $courseBenefitContent = $objCourseFaq->getDataByTypeAndContentId($courseId, $procutType, $contentBenefitType, $courseBenefitSectionData['training_id'], 0, 0, 0, $benefitContentId);
                        $fetchedFrom = 'common';
                    }

                    //merge newly added designation
                    $benefitContCountry = $benefitContAll = array();
                    $designationInfo = !empty($courseBenefitContent) ? current($courseBenefitContent) : array();
                    $designationMain = !empty($designationInfo['jobdesignation']) ? $designationInfo['jobdesignation'] : array();
                    if ($useBenefitContentId) {
                        if ($countryId == INDIA_COUNTRY_ID) {
                            //India
                            if ($fetchedFrom == 'city') {
                                $countryContentId = $sameCountryContentId;
                                $benefitContCountry = current($objCourseFaq->getDataByTypeAndContentId($courseId, $procutType, $contentBenefitType, $courseBenefitSectionData['training_id'], 0, $countryId, 0, $countryContentId));
                                $designation = !empty($benefitContCountry['jobdesignation']) ? $benefitContCountry['jobdesignation'] : array();
                                $newlyAdded = array_diff(array_column($designation, 'section_id'), array_column($designationMain, 'section_id'));
                                foreach ($newlyAdded as $indexToAdd => $new) {
                                    $newData = $designation[$indexToAdd];
                                    unset($newData['section_map_id']);
                                    $courseBenefitContent[0]['jobdesignation'][] = $newData;
                                }
                            }
                        } else {
                            //ROW
                            if ($fetchedFrom == 'city') {
                                $benefitContAll = current($objCourseFaq->getDataByTypeAndContentId($courseId, $procutType, $contentBenefitType, $courseBenefitSectionData['training_id'], 0, 0, 0, $allCountryContentId));
                                $designation = !empty($benefitContAll['jobdesignation']) ? $benefitContAll['jobdesignation'] : array();
                                $newlyAdded = array_diff(array_column($designation, 'section_id'), array_column($designationMain, 'section_id'));
                                foreach ($newlyAdded as $indexToAdd => $new) {
                                    $newData = $designation[$indexToAdd];
                                    unset($newData['section_map_id']);
                                    $courseBenefitContent[0]['jobdesignation'][] = $newData;
                                }
                            }
                        }
                    }
                    //merge newly added designation END
                    if (!empty($courseBenefitContent)) {
                        $benefitParams = array(
                            'contentCourse' => $courseBenefitContent
                        );
                        if ($fetchedFrom == 'city' && !empty($courseBenefitContent)) {
                            $this->view->crmStatusBenefit = $courseBenefitContent[0]['crmStatus'];
                        }
                    }
                }
                $this->view->iscIndia = $countryId != INDIA_COUNTRY_ID ? false : true;
            }

            /** Benefit Section End */

            $objCourseFaq->setIsCityPage($cityId);
            $faqResData = $objCourseFaq->getDataByTypeAndContentId($courseId, $procutType, null, $trainingTypeId, 0, 0, $cityId);
            $parentFaqIds = $cityFaqIds = $uniqueFaqIds = $commonFaqIds = $faqResDataNew = array();
            if (!empty($faqResData)) {
                foreach ($faqResData as $key => $row) {
                    if (empty($row['city_id'])) {
                        if (!(int) $row['crmStatus']) {
                            unset($faqResData[$key]);
                            continue;
                        }
                        $parentFaqIds[] = $row['course_faq_id'];
                    } else {
                        $cityFaqIds[] = $row['course_faq_id'];
                    }
                }
                $uniqueFaqIds = array_unique(array_column($faqResData, 'course_faq_id'));
                /* $faqResDataNew = array_values(array_intersect_key($faqResData, $uniqueFaqIds)); */
            }
            $commonFaqIds = array_intersect($parentFaqIds, $cityFaqIds);
            $productType = empty($procutType) ? "course" : $procutType;
            foreach ($faqResData as $key => $row) {
                if (in_array($row['course_faq_id'], $uniqueFaqIds)) {
                    $index = array_search($row['course_faq_id'], $uniqueFaqIds);
                    unset($uniqueFaqIds[$index]);
                    if (!$row['is_b2c'] && $productType != 'bundle')
                        continue;

                    if ($row['is_b2c'] == 0 && $row['is_b2b'] == 1 && $productType == 'bundle')
                        continue;
                    if (empty($row['city_id']) || in_array($row['course_faq_id'], $commonFaqIds)) {
                        $row['is_parent'] = true;
                        $row['is_clone'] = true;
                        $row['action'] = 'Clone';
                    } else {
                        $row['is_parent'] = false;
                        $row['is_clone'] = false;
                        $row['action'] = 'Edit';
                    }
                    $courseFaqs[] = $row;
                }
            }
            $courseFaqRes['courseFaqs'] = $courseFaqs;
            $courseIntroText = $cityPageModel->getCourseIntroText($cityId, $courseId, $trainingTypeId, $productTypeId);
            $result['courseFaqs'] = !empty($courseFaqRes['courseFaqs']) ? $courseFaqRes['courseFaqs'] : array();
            $result['courseIntro'] = !empty($courseIntroText) ? $courseIntroText : array();
            if (empty($trainingTypeId) && !empty($benefitParams)) {
                $this->_setContentCourse($benefitParams);
                $benefitForm = new Form_CourseContentBenefits(true);
                $benefitForm->setDefaults($benefitParams);
            } else {
                $this->view->benefitSectionCity = false;
            }
            // prd($courseIntroText);
            $additionalInfo = array();
            if($trainingTypeId == BaseApp_Dao_TrainingTypes::TYPE_GENERIC && $productTypeId == BaseApp_Dao_ProductTypes::TYPE_ID_COURSE){
                $objCourseFaq = new Model_CourseFaq();
                $allAdditionalData = $objCourseFaq->getDataByTypeAndContentId($courseId, $procutType, null, $trainingTypeId, 0, 0,$cityId);
                //pr($allAdditionalData);
                $overviewInfo = $eligibilityInfo = $prerequisitesInfo = array();
                if(!empty($allAdditionalData)){
                    foreach ($allAdditionalData as $value) {
                        $value['is_parent'] = false;
                        $value['is_clone'] = false;
                        $value['action'] = 'Edit';
                        switch ($value['type']){
                            case BaseApp_Dao_ProductTypes::TYPE_ID_OVERVIEW:
                                $overviewInfo[] = $value;break;
                            case BaseApp_Dao_ProductTypes::TYPE_ID_ELIGIBILITY:
                                $eligibilityInfo[] = $value;break;
                            case BaseApp_Dao_ProductTypes::TYPE_ID_PREREQUISITES:
                                $prerequisitesInfo[] = $value;break;
                            default:
                                break;
                        }
                    }
                    $additionalInfo['courseoverview'] = isset($overviewInfo[0]) ? $overviewInfo[0] : array();
                    $additionalInfo['eligibility'] = isset($eligibilityInfo[0]) ? $eligibilityInfo[0] : array();
                    $additionalInfo['prerequisites'] = isset($prerequisitesInfo[0]) ? $prerequisitesInfo[0] : array();
                }
            }
           //pr($additionalInfo);
            $this->view->additionalInfo = $additionalInfo; 
        }

        $reactCityCourseIds = !empty(REACT_CITY_COURSE_IDS) ? explode(',', REACT_CITY_COURSE_IDS) : array();
        $this->view->isReactCityPage = in_array($courseId, $reactCityCourseIds) ? true : false;
        $this->view->isGeneric = empty($trainingTypeId) ? true : false;
        $this->_helper->layout->disableLayout();
        $this->view->data = $result;
        $this->view->selectedCityId = $cityId;
        $this->view->procutType = $procutType;
        if (isset($benefitForm)) {
            if ($useBenefitContentId) {
                $this->view->benefitContentId = $benefitContentId;
            }
            $this->view->benefitForm = $benefitForm;
        }
        $this->view->selectedCourseId = $courseId;
        $this->view->selectedProductTypeId = $productTypeId;
        $this->view->selectedTrainingTypeId = $trainingTypeId;
    }

    /**
     * Update Course Intro Text
     */
    public function updateCourseIntroTextAction() {
        $result = array('status' => false, 'msg' => null);
        $id = $this->getRequest()->get('id');
        $courseIntrotext = $this->getRequest()->get('introText');
        if ($id && !empty($courseIntrotext)) {
            $cityPageModel = new Model_CityPage();
            $courseFaqRes = $cityPageModel->updateCourseIntroText($id, $courseIntrotext);
            if ($courseFaqRes) {
                $result['status'] = true;
                $result['msg'] = 'Success';
                $result['id'] = $id;
            } else {
                $result['status'] = false;
                $result['msg'] = 'Failed';
                $result['id'] = $id;
            }
        }
        echo json_encode($result);
        exit;
    }
    /**
     * Update Course Overview,  Eligibility and Pre-requisite Text for a selected city
     */
    public function updateAdditonalContentAction() {
        $this->_helper->layout->disableLayout();
        $result = array('status' => false, 'msg' => null);
        $postData = $this->getRequest()->getPost();
        //prd($postData);exit;
        $id = $postData['id'];
        $question = !empty($postData['question']) ? $postData['question'] : '';
        $answer = $postData['answer'];
        $answer = !empty($answer) ? preg_replace( '/[\x{200B}-\x{200D}\x{FEFF}]/u', '', $answer ) : '';
        $isClonFlag = $postData['isCloned'];
        $cityId = $postData['cityId'];
        $courseId = $postData['courseId'];
        $trainingTypeId = $postData['trainingTypeId'];
        $type = $postData['type']; //BaseApp_Dao_ProductTypes::TYPE_ID_ELIGIBILITY        
        $order = $postData['order'];
        $lookupId = $postData['lookupId'];
        $mapId = $postData['mapId'];
        $jumpToSection = $postData['jumpToSection'];
        $productTypeId = $postData['productTypeId'];     
        // prd($postData);
        if ($id && !empty($question) && !empty($type) && !empty($courseId) && !empty($cityId)) {
            $cityPageModel = new Model_CityPage();
            $result = $cityPageModel->updateCityPageAddionalContent($id, $question, $cityId, $type, $courseId, $trainingTypeId, $productTypeId);
            //prd($courseFaqRes);exit;
            if ($result['status']) {
                $this->view->updateStatus = true;
            } else {
                $this->view->result = $result;
                $this->view->updateStatus = false;
            }
        }
        echo json_encode($result);
        exit;
    }
    /**
     * Update City Page Question & Answer
     */
    public function updateCityPageFaqsAction() {
        $this->_helper->layout->disableLayout();
        $result = array('status' => false, 'msg' => null, 'data' => array());
        $courseDesription = array();
        $id = $this->getRequest()->get('id');
        $question = $this->getRequest()->get('question');
        $answer = $this->getRequest()->get('answer');
        $answer = preg_replace( '/[\x{200B}-\x{200D}\x{FEFF}]/u', '', $answer );
        $isClonFlag = $this->getRequest()->get('isCloned');
        $cityId = $this->getRequest()->get('cityId');
        $courseId = $this->getRequest()->get('courseId');
        $trainingTypeId = $this->getRequest()->get('trainingTypeId');
        $type = $this->getRequest()->get('type');
        $order = $this->getRequest()->get('order');
        $lookupId = $this->getRequest()->get('lookupId');
        $mapId = $this->getRequest()->get('mapId');
        $jumpToSection = $this->getRequest()->get('jumpToSection');
        $tabber = $this->getRequest()->get('tabber');
        $productTypeId = $this->getRequest()->get('productTypeId');
        if ($id && !empty($question) && !empty($answer) && !empty($type) && !empty($courseId)) {
            $cityPageModel = new Model_CityPage();
            $courseFaqRes = $cityPageModel->updateCityPageFaqs($id, $answer, $question, $cityId, $type, $courseId, $trainingTypeId, $order, $lookupId, $mapId, $jumpToSection, $isClonFlag,$productTypeId);
            if (!empty($courseFaqRes['status']) && $courseFaqRes['status']) {
                $this->view->updateStatus = true;
                $result['status'] = true;
                $result['msg'] = 'Success';
                $result['id'] = $id;
                $result['data'] = $courseFaqRes['data'];
                $output = '';
                switch (strtolower($tabber)) {
                    case 'course-description':
                        $output = ($isClonFlag) ? $this->view->render('city-page/partial/update-city-page-course-description.phtml') : '';
                        $result['template'] = $output;
                        break;
                    case 'exam-certification':
                        $output = ($isClonFlag) ? $this->view->render('city-page/partial/update-city-page-exam-certification.phtml') : '';
                        $result['template'] = $output;
                        break;
                    case 'faq':
                        $output = ($isClonFlag) ? $this->view->render('city-page/partial/update-city-page-faq.phtml') : '';
                        $result['template'] = $output;
                        break;
                }
            } else {
                $result['status'] = false;
                $result['msg'] = !empty($courseFaqRes['msg']) ? $courseFaqRes['msg'] : 'Failed';
                $result['id'] = $id;
                $this->view->result = $result;
                $this->view->updateStatus = false;
            }
            echo json_encode($result);
            exit;
        }
    }

    /**
     * Add More Question
     */
    public function addMoreQuestionAnswerAction() {
        $this->_helper->layout->disableLayout();
        $result = array('status' => false, 'msg' => null, 'data' => array());
        $question = $this->getRequest()->get('question');
        $answer = $this->getRequest()->get('answer');
        $answer = preg_replace( '/[\x{200B}-\x{200D}\x{FEFF}]/u', '', $answer );
        $isClonFlag = $this->getRequest()->get('isCloned');
        $cityId = $this->getRequest()->get('cityId');
        $courseId = $this->getRequest()->get('courseId');
        $trainingTypeId = $this->getRequest()->get('trainingTypeId');
        $productTypeId = $this->getRequest()->get('productTypeId');
        $type = $this->getRequest()->get('type');
        $order = $this->getRequest()->get('order');
        $jumpToSection = $this->getRequest()->get('jumpToSection');
        $tabber = $this->getRequest()->get('tabber');
        if (!empty($question) && !empty($answer) && !empty($type) && !empty($courseId)) {
            $cityPageModel = new Model_CityPage();
            $extraData['productTypeId'] = empty($productTypeId)?BaseApp_Dao_Courses::PRODUCT_TYPE_ID:$productTypeId;
            $courseFaqRes = $cityPageModel->addMoreQuestionAnswer($answer, $question, $cityId, $type, $courseId, $trainingTypeId, $order, $jumpToSection, $isClonFlag, $extraData);
            if (!empty($courseFaqRes['status']) && $courseFaqRes['status']) {
                $this->view->updateStatus = true;
                $result['status'] = true;
                $result['msg'] = 'Success';
                $result['data'] = $courseFaqRes['data'];
                $cityPageModel = new Model_CityPage();
                $output = '';
                switch (strtolower($tabber)) {
                    case 'course-description':
                        $output = $this->view->render('city-page/partial/update-city-page-course-description.phtml');
                        $result['template'] = $output;
                        break;
                    case 'exam-certification':
                        $output = $this->view->render('city-page/partial/update-city-page-exam-certification.phtml');
                        $result['template'] = $output;
                        break;
                    case 'faq':
                        $output = $this->view->render('city-page/partial/update-city-page-faq.phtml');
                        $result['template'] = $output;
                        break;
                }
            } else {
                $result['status'] = false;
                $result['msg'] = !empty($courseFaqRes['msg']) ? $courseFaqRes['msg'] : 'Failed';
                $this->view->result = $result;
                $this->view->updateStatus = false;
            }
            echo json_encode($result);
            exit;
        }
    }

    /**
     * Get Max Order
     */
    public function getMaxOrderAction() {
        $courseId = $this->getRequest()->get('courseId');
        $trainingTypeId = $this->getRequest()->get('trainingTypeId');
        $type = $this->getRequest()->get('type');
        $cityId = $this->getRequest()->get('cityId');
        $productTypeId = $this->getRequest()->get('productTypeId');
        $maxOrderValue = 0;
        $respone = array('status' => false, 'msg' => '', 'maxOrder' => $maxOrderValue);
        if (!empty($courseId) && !empty($type)) {
            $objCourseCityLookUp = new Model_CourseCityLookup();
            $lookupResult = $objCourseCityLookUp->getAllLookUpByCourseId($courseId,$productTypeId);
            $parentLookUpId = $childLookUpId = 0;
            if (!empty($lookupResult)) {
                foreach ($lookupResult as $row) {
                    if ((int) $row['course_id'] === (int) $courseId && empty($row['city_id']) && empty($parentLookUpId)) {
                        $parentLookUpId = $row['id'];
                    } else if ((int) $row['course_id'] === (int) $courseId && !empty($row['city_id']) && (int) $row['city_id'] === (int) $cityId && empty($childLookUpId)) {
                        $childLookUpId = $row['id'];
                    }
                }
                if (!empty($parentLookUpId)) {
                    $lookupIds[] = $parentLookUpId;
                    if (!empty($childLookUpId)) {
                        $lookupIds[] = $childLookUpId;
                    }
                    $objCourseResourceMapping = new Model_CourseResourceMapping();
                    $result = $objCourseResourceMapping->getChildOrder($courseId, $trainingTypeId, $type, $lookupIds);
                    if (!empty($result)) {
                        $orderList = array_column($result, 'order');
                        $orderList = array_unique($orderList);
                        $maxOrderValue = max($orderList);
                        $respone['status'] = true;
                        $respone['msg'] = 'Ok';
                        $respone['maxOrder'] = !empty($maxOrderValue) ? $maxOrderValue + BaseApp_Dao_CityPage::MORE_QUESTION_INCREMENT_COUNTER : BaseApp_Dao_CityPage::DEFAULT_ADD_ORDER;
                    } else {
                        $respone['status'] = true;
                        $respone['msg'] = 'Ok';
                        $respone['maxOrder'] = BaseApp_Dao_CityPage::DEFAULT_ADD_ORDER;
                    }
                } else {
                    $respone['status'] = true;
                    $respone['msg'] = 'Ok';
                    $respone['maxOrder'] = BaseApp_Dao_CityPage::DEFAULT_ADD_ORDER;
                }
            }
        }
        echo json_encode($respone);
        exit;
    }

    /**
     * Get Next Order Value For Clone Child
     */
    public function getOrderValueForChildAction() {
        $order = $this->getRequest()->get('parentOrder');
        $courseId = $this->getRequest()->get('courseId');
        $trainingTypeId = $this->getRequest()->get('trainingTypeId');
        $type = $this->getRequest()->get('type');
        $cityId = $this->getRequest()->get('cityId');
        $productTypeId = $this->getRequest()->get('productTypeId');
        $newOrderValue = 0;
        $response = array('status' => false, 'msg' => '', 'order' => $newOrderValue);
        if (!empty($order) && !empty($courseId) && !empty($type)) {
            /**
             * Set lower clone limit and upper clone limit
             */
            $objCourseResourceMapping = new Model_CourseResourceMapping();
            $result = $objCourseResourceMapping->getOrderByCourseIdTrainingTypeIdAndType($courseId, $trainingTypeId, $type);
            $lowerCloneLimit = $order;
            $upperCloneLimit = (int) $lowerCloneLimit + BaseApp_Dao_CityPage::COURSE_INCREMENT_COUNTER;
            /**
             * Find the max order value between $lowerCloneLimit and $upperCloneLimit.
             */
            $objCourseCityLookUp = new Model_CourseCityLookup();
            $lookupResult = $objCourseCityLookUp->getAllLookUpByCourseId($courseId,$productTypeId);
            $parentLookUpId = $childLookUpId = 0;
            if (!empty($lookupResult)) {
                foreach ($lookupResult as $row) {
                    if ((int) $row['course_id'] === (int) $courseId && empty($row['city_id']) && empty($parentLookUpId)) {
                        $parentLookUpId = $row['id'];
                    } else if ((int) $row['course_id'] === (int) $courseId && !empty($row['city_id']) && (int) $row['city_id'] === (int) $cityId && empty($childLookUpId)) {
                        $childLookUpId = $row['id'];
                    }
                }
                if (!empty($parentLookUpId)) {
                    $lookupIds[] = $parentLookUpId;
                    if (!empty($childLookUpId)) {
                        $lookupIds[] = $childLookUpId;
                    }
                    $objCourseResourceMapping = new Model_CourseResourceMapping();
                    $result = $objCourseResourceMapping->getChildOrder($courseId, $trainingTypeId, $type, $lookupIds, $lowerCloneLimit, $upperCloneLimit);
                    if (empty($result)) {
                        $newOrderValue = $order + BaseApp_Dao_CityPage::CLONE_QUESTION_INCREMENT_COUNTER;
                        $response = array('status' => true, 'msg' => 'Ok', 'order' => $newOrderValue);
                    } else {
                        $cityPage = new Model_CityPage();
                        $newOrderValue = $cityPage->checkIfOrderValueExist($courseId, $trainingTypeId, $type, $lookupIds, $lowerCloneLimit, $upperCloneLimit);
                        $response = array('status' => true, 'msg' => 'Ok', 'order' => $newOrderValue);
                    }
                }
            }
        }
        echo json_encode($response);
        exit;
    }

    /**
     * Toogle Question Status
     */
    public function updateFaqStatusAction() {
        $productId = $this->getRequest()->get('productId');
        $productTypeId = $this->getRequest()->get('productTypeId');
        $cityId = $this->getRequest()->get('city');
        $status = $this->getRequest()->get('currentStatus');
        $faqId = $this->getRequest()->get('faqId');
        $type = $this->getRequest()->get('type');
        $order = $this->getRequest()->get('order');
        $trainingTypeId = $this->getRequest()->get('trainingTypeId');
        $newStatus = 0;
        $result = array('status' => false, 'msg' => 'Failed', 'mappingIdUpdated' => array());
        if (!empty($faqId) && !empty($cityId) && !empty($productId)) {
            $objCourseResourceMapping = new Model_CourseResourceMapping ();
            $productType = $objCourseResourceMapping->getLinkableTypeByProductTypeId($productTypeId);
            $resourceMappingData = $objCourseResourceMapping->getResourceMappingInfo($faqId, $cityId, $productId,$productType);
            $resourceMappingData = current($resourceMappingData);
            if (!empty($resourceMappingData['id'])) {//if citywise faq data exists
                $mappingId = (int) $resourceMappingData['id'];
                $status = (int) $resourceMappingData['status'];
                if (!empty($mappingId)) {
                    $newStatus = $status ? 0 : 1;
                    $updateCourseMappingData = array('status' => (int) $newStatus);
                    $objCourseResourceMapping->setId($mappingId);
                    if ($objCourseResourceMapping->setFromArray($updateCourseMappingData)->update()) {
                        $result['status'] = true;
                        $result['msg'] = 'Success';
                        $result['newStatus'] = $newStatus;
                        $result['mappingIdUpdated'] = $mappingId;
                    }
                }
            } else {//if citywise faq data do not exist
                $cityPageModel = new Model_CityPage();
                $newStatus = $status ? 0 : 1;
                $result = $cityPageModel->disableCityPageFaq($faqId, $productId, $cityId, $productTypeId, $type, $trainingTypeId, $newStatus, $order);
            }
        }
        echo json_encode($result);
        exit;
    }

    public function checkIfOrderValueExistAction() {
        $response = array('status' => false, 'msg' => '');
        $trainingTypeId = $this->getRequest()->get('trainingTypeId');
        $type = $this->getRequest()->get('type');
        $courseId = $this->getRequest()->get('courseId');
        $cityId = $this->getRequest()->get('cityId');
        $order = $this->getRequest()->get('order');
        $operation = $this->getRequest()->get('operation');
        $courseFaqId = $this->getRequest()->get('faqId');
        $productTypeId = $this->getRequest()->get('productTypeId');
        $objCourseCityLookUp = new Model_CourseCityLookup();
        $lookupResult = $objCourseCityLookUp->getAllLookUpByCourseId($courseId,$productTypeId);
        $pLookUpId = $cLookUpId = 0;
        if (!empty($lookupResult)) {
            foreach ($lookupResult as $row) {
                if ((int) $row['course_id'] === (int) $courseId && empty($row['city_id']) && empty($parentLookUpId)) {
                    $pLookUpId = $row['id'];
                } else if ((int) $row['course_id'] === (int) $courseId && !empty($row['city_id']) && (int) $row['city_id'] === (int) $cityId && empty($childLookUpId)) {
                    $cLookUpId = $row['id'];
                }
            }
            $lookupIds = array();
            if (!empty($pLookUpId)) {
                $lookupIds[] = $pLookUpId;
                if (!empty($cLookUpId)) {
                    $lookupIds[] = $cLookUpId;
                }
                $objCourseResourceMapping = new Model_CourseResourceMapping();
                $result = $objCourseResourceMapping->getChildOrder($courseId, $trainingTypeId, $type, $lookupIds);
                if (!empty($result)) {
                    if (strcmp($operation, 'edit') === 0) {
                        foreach ($result as $key => $row) {
                            if ((int) $row['faq_id'] === (int) $courseFaqId && (int) $order === (int) $row['order']) {
                                $currentStatus = $result[$key]['status'];
                                unset($result[$key]);
                            }
                        }
                    }
                    $orderList = array_column($result, 'order');
                    if (in_array($order, $orderList)) {
                        $response = array('status' => false, 'msg' => "Order Value ( $order ) Already Exist.Please Try With Different Order Value.");
                    } else {
                        $response = array('status' => true, 'msg' => 'Success');
                    }
                }else{
                    $response = array('status' => true, 'msg' => 'Success');
                }
            }
        }
        echo json_encode($response);
        exit;
    }

    public function getAllTrainingTypesAction() {
        $result = array('status' => false, 'message' => '', 'data' => array());
        $trainingTypes = array();
        $courseId = $this->getRequest()->get('product_id');
        if (!empty($courseId)) {
            $courseObj = new BaseApp_Dao_Courses();
            $data = $courseObj->getTrainingTypes($courseId);
            if (!empty($data)) {
                $trainingIds = $data[$courseId];
                if (in_array(BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM, $trainingIds)) {
                    $trainingTypes[BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM] = "Classroom";
                }
                if (in_array(BaseApp_Dao_TrainingTypes::TYPE_ELEARNING, $trainingIds)) {
                    $trainingTypes[BaseApp_Dao_TrainingTypes::TYPE_ELEARNING] = "Online Self Learning";
                }
                if (in_array(BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS, $trainingIds)) {
                    $trainingTypes[BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS] = BaseApp_Dao_TrainingTypes::CART_ONLINE_CLASSROOM_PASS;
                }

                $result['status'] = true;
                $result['message'] = 'success';
                $result['data'] = $trainingTypes;
            }
        }
        echo json_encode($result);
        exit;
    }

    /* public function faqMoveAction() {
        $data = $this->getRequest()->getPost();
        $currentPos = $data['current_pos'];
        $finalPosition = $data['to_move_pos'];
        $message = '';
        $status = 'success';
        if (empty($data['course_faq_id']) || empty($data['current_pos']) || empty($data['to_move_pos'])) {
            $message = 'Missing data';
            $status = 'failed';
        }
        $objCourseFaq = new Model_CourseFaq();
        if ($currentPos != $finalPosition) {
            if (!$objCourseFaq->changeFaQOrder($data, $currentPos, $finalPosition)) {
                $message = 'Failed to update';
                $status = 'failed';
            }
        }

        $this->_helper->layout->disableLayout();
        $this->view->data = array(
            'message' => $message,
            'status' => $status
        );
        $this->_redirect($_SERVER['HTTP_REFERER']);
    } */
    public function faqMoveAction() {

        $this->_helper->layout->disableLayout();
        $data = array();
        $result = array('status' => false, 'msg' => null);
        $finalPosition = $this->getRequest()->get('toMovePos');
        $currentPos = $this->getRequest()->get('currentPos');
        $linkableType = $this->getRequest()->get('linkableType');
        $linkableId = $this->getRequest()->get('linkableId');
        $courseFaqId = $this->getRequest()->get('courseFaqId');
        $clusterId = $this->getRequest()->get('clusterId');
        $countryId = $this->getRequest()->get('countryId');
        $cityId = $this->getRequest()->get('cityId');
        $trainingTypeId = $this->getRequest()->get('trainingTypeId');
        $contentType = $this->getRequest()->get('contentType');
        $objCourseFaq = new Model_CourseFaq();
        $objCourseFaq->setIsCityPage($cityId);
        if (empty($courseFaqId) || empty($currentPos) || empty($finalPosition)) {
            $result = array('status' => false, 'msg' => 'Missing data');
        }else{
            $data['to_move_pos'] = $finalPosition;
            $data['current_pos'] = $currentPos;
            $data['linkable_id'] = $linkableId;
            $data['linkable_type'] = $linkableType;
            $data['course_faq_id'] = $courseFaqId;
            $data['cluster_id'] = $clusterId;
            $data['country_id'] = $countryId;
            $data['city_id'] = $cityId;
            $data['training_id'] = $trainingTypeId;
            $data['content_type'] = $contentType;
            // $objCourseFaq = new Model_CourseFaq();
            if ($currentPos != $finalPosition) {
                if ($objCourseFaq->changeFaQOrder($data, $currentPos, $finalPosition)) {
                    $result['status'] = true;
                    $result['msg'] = 'Success';
                }
            }
        }
        echo json_encode($result);
        exit;
    }

}
