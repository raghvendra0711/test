<?php
/*
 *CRUD for seo
 * 
 */

class Admin_SeoController extends BaseApp_Controller_Crud {
    protected $_model = 'Model_Seo';
    protected $_descriptions = array(
        'list' => 'List of Existing Seo data',
        'index' => 'List of Existing Seo data',
        'add' => 'Add New Seo data',
        'edit' => 'Make the required changes then click on "Save" to update the Seo data',
        'view' => 'View Selected Seo data',
        'search' => 'search Selected Seo data',
        'purge' => 'purging cache for seo urls'
    );

    public function indexAction() {
        
    }
    
    protected function _getForm($paramsArr = array()) {
        $form = new Form_Seo($paramsArr);
        return $form;
    }     
    
    public function editAction() {
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $id = $this->getRequest()->getParam('id');
        $data = $this->getModel($id);
        $data->urlShow = $data->url;
        if ($data) {
            $this->view->postParams = $data;
            if ($this->getRequest()->isPost()) {
                $request = $this->getRequest()->getPost();       
                $this->_setMetatagSession($request);
                $this->_setTwitterCardSession($request);
                $this->_setFBOpenGraphSession($request);
                $form = $this->_getForm();
                $form->removeUneditableElements();
                if ($form === false)
                    throw new Zend_Exception('_getForm not implemented');

                if($form->isValid($request)) {
                    $form->removeOptionalElements();
                    $dataSave = $form->getValues();

                    /** h2Tag validation Start */
                    $h2Tag = !empty($dataSave['h2Tag']) ? $dataSave['h2Tag'] : '';
                    if ($h2Tag) {
                        if ($h2Error = self::validateH2Tag($h2Tag)) {
                            $form->getElement('h2Tag')->setErrors(array($h2Error));
                            $dataSave = $form->getValues();
                            $dataSave['urlShow'] = $data->urlShow;
                            $form->setDefaults($dataSave);
                            $this->view->form = $form;
                            return;
                        }
                    }
                    /** h2Tag validation End */
                    
                    if($dataSave['url_type'] == 'City Page'){
                        if(empty($dataSave['linkable_type_id'])){
                            $form->getElement('linkable_type_id')->setErrors(array('Product Type is Missing'));
                            $dataSave['urlShow'] = $request['url'];
                            $form->setDefaults($dataSave);
                            $this->view->form = $form;
                            return false;
                        }
                        if(empty($dataSave['linkable_id'])){
                            $form->getElement('linkable_id')->setErrors(array('Product is Missing'));
                            $dataSave['urlShow'] = $request['url'];
                            $form->setDefaults($dataSave);
                            $this->view->form = $form;
                            return false;
                        }
                        if(empty($dataSave['seo_city_id'])){
                            $form->getElement('seo_city_id')->setErrors(array('City is Missing'));
                            $dataSave['urlShow'] = $request['url'];
                            $form->setDefaults($dataSave);
                            $this->view->form = $form;
                            return false;
                        }

                        $obPt = new BaseApp_Dao_ProductTypes();
                        $productType = current($obPt->fetchForSelect(array('product_type_id =?'=>$dataSave['linkable_type_id'])));
                        $dataSave['controller'] = $productType;
                        $dataSave['linkable_id'] = $dataSave['linkable_id'];
                        $dataSave['linkable_type'] = $productType.'_city';
                        $objCity = new Model_City($dataSave['seo_city_id']);
                        $params = array($productType.'_id'=>$dataSave['linkable_id'],'city_name'=>$objCity->name,'city_id'=>$dataSave['seo_city_id'],'product_type_id'=>$dataSave['linkable_type_id'],'country_id'=>$dataSave['seo_country_id']);
                        
                        if($productType == BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE){
                            $objCourse = new Model_Courses($dataSave['linkable_id']);
                            $objCountry = new Model_Country($objCity->country_id);
                            $moreCitiesParams = array('product_id'=>$dataSave['linkable_id'],'product_type'=>1,'city_id'=>$dataSave['seo_city_id'],'city'=>$objCity->name,'country_id'=>$objCountry->country_id,'country_name'=>$objCountry->name,'course_name'=>$objCourse->name);
                            $objTrainingRelations = new Model_TrainingRelations();
                            $trainingIds = $objTrainingRelations->getCourseTrainingIds($dataSave['linkable_id'], $productType);
                            if(!empty($trainingIds) && in_array(BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM,$trainingIds)){
                                $params['is_classroom_page'] = 1;
                            }
                        }else if($productType == BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES){
                            $objCourse = new Model_Bundles($dataSave['linkable_id']);
                            $objCountry = new Model_Country($objCity->country_id);
                            $moreCitiesParams = array('product_id'=>$dataSave['linkable_id'],'product_type'=>2,'city_id'=>$dataSave['seo_city_id'],'city'=>$objCity->name,'country_id'=>$objCountry->country_id,'country_name'=>$objCountry->name,'course_name'=>$objCourse->name);
                        }
                        $dataSave['params'] = json_encode($params);
                        
                        unset($dataSave['linkable_type_id']);
                        unset($dataSave['linkable_id']);
                        unset($dataSave['seo_country_id']);
                        unset($dataSave['seo_city_id']);
                    }else{
                        unset($dataSave['linkable_type_id']);
                        unset($dataSave['linkable_id']);
                        unset($dataSave['seo_country_id']);
                        unset($dataSave['seo_city_id']);
                    }

                    unset($dataSave['fbOpenGraph_err']);
                    unset($dataSave['twitterCards_err']);
                    if ($dataSave['url_type'] == BaseApp_Dao_Seo::URL_TYPE_COURSE || $dataSave['url_type'] == BaseApp_Dao_Seo::URL_TYPE_CITY) {
                        $h2Tags = $dataSave['h2tags'];                        
                    }
                    unset($dataSave['h2tags']);
                    $seoUrl = $data['url'];
                    $this->_handleDataAfterSubmit($dataSave);
                    unset($dataSave['seo_id']);
                    unset($dataSave['url']);                        
                    try {
                        $result = $data->setFromArray($dataSave)->update();
                    } catch (Zend_Exception $e) {
                        //die('Something went wrong: ' . $e->getMessage());
                        $this->view->message = "An error has occured while saving". $e->getMessage();
                        $this->view->success = false;
                        $this->view->form = $form;
                        return;
                    }
                    $cdnPurgeData = array('linkable_id'=>$data['linkable_id'],'linkable_type'=>$data['linkable_type'],'action'=>'Seo Data Modified '.$seoUrl,'url'=>$seoUrl,'created_at'=>time(),'updated_at'=>time());
                    $objCdn = new Model_CdnPurgeLog();
                    $objCdn->InsertCdnPurgeLog($cdnPurgeData);
                    //if url_type is course , save h2 tags
                    if ($dataSave['url_type'] == BaseApp_Dao_Seo::URL_TYPE_COURSE || $dataSave['url_type'] == BaseApp_Dao_Seo::URL_TYPE_CITY) {
                        $this->_saveH2tags($h2Tags, $id);                        
                    }                            
                    $module  = $this->getRequest()->getModuleName();
                    $controller = $this->getRequest()->getControllerName();
                    if($module && $controller)
                        $this->redirect($module.'/'.$controller.'/list');                                       
                }
                else {       
                    $dataSave = $form->getValues();
                    $dataSave['urlShow'] = $data->urlShow;
                    $form->setDefaults($dataSave);
                }
            }        
            else {
                $this->getModel()->extractOtherTags($data);   
                $this->_setMetatagSession($data);
                $this->_setTwitterCardSession($data);
                $this->_setFBOpenGraphSession($data);

                $formData = $data->toArray();
                $paramData = json_decode($formData['params'],true);
                if ($data->url_type == BaseApp_Dao_Seo::URL_TYPE_COURSE || $data->url_type == BaseApp_Dao_Seo::URL_TYPE_CITY) {
                    $formData['h2tags'] = $this->_getH2Tags($id);
                }
                $form = $this->_getForm($paramData);
                if ($form === false)
                    throw new Zend_Exception('_getForm not implemented');
                $form->setDefaults($formData);
            }            
            $this->view->form = $form;
        }
    }
    public function purgeAction()
    {
        $form = new Form_SeoUrls();
        if ($form === false) {
            throw new Zend_Exception('_getForm not implemented');
        }
        if ($this->getRequest()->isPost()) {
            $seoUrlArr = array();
            $seoUrls = $this->getRequest()->getPost();
            if ($form->isValid($seoUrls)) {
                unset($seoUrls['Save']);
                $data = $form->getValues();
                if ($seoUrls['seo_urls']) {
                    $seoUrlArr =  explode("\n", $seoUrls['seo_urls']);
                }
                // file_put_contents(APPLICATION_PATH . '/../error.log', __METHOD__ .'purge urls : '.  
                // print_r($data,true), FILE_APPEND);  
                $fileData = $_FILES['seoUrlsCsv'];
                $fileSeoUrls = array();
                $failCodesArr = array();
                if (!empty($fileData['name'])) {
                    $fileSeoUrls = $this->_processFile($fileData);
                    if (false === $fileSeoUrls) {
                        $this->view->message = "500 is the Limit.";
                        $this->view->success = false;
                        $this->view->form = $form;
                        return false;
                    }
                }
                $reindex = !empty($seoUrls['reindex']) ? true : false;
                $purge = !empty($seoUrls['purge']) ? true : false;
                $purgeUrlData = array();
                $purgeData = array_merge($seoUrlArr, $fileSeoUrls);
                $extraData = array('data' => $purgeData, 'isSeo' => 1, 'reindex' => $reindex, 'purge' => $purge);
                $purgeObj = new Helper_PurgeUrl();
                $response = $purgeObj->submitPurgeData('seo', null, null, $extraData);
                $data = array();
                if (!empty($response['data']) && !empty($response['data']['data'])) {
                    $data = $response['data']['data'];
                }
                if(empty($response['data']) ||  empty($response['data']['data'])){
                    $this->view->message = "purge action got failed";
                    return;
                }
                if (!empty($data) && !empty($purge) && !empty($reindex)) {
                    $this->view->message = "url got purged and reindexed";
                    return;
                }
                if (!empty($data) && !empty($reindex) && empty($purge)) {
                    $this->view->message = "url got reindexed";
                    return;
                }
                if (!empty($data) && !empty($purge) && empty($reindex)) {
                    $this->view->message = "url got purged";
                    return;
                }
                $this->_redirect("admin/seo/purge");
            }
        }
        $this->view->success = true;
        $this->view->form = $form;
    }

    private function _processFile($fileData)
    {
        $seoUrlArr = array();
        if ($fileData['tmp_name']) {
            $fileName = $fileData['name'];
            $absFilePath = sys_get_temp_dir() . DIRECTORY_SEPARATOR . $fileName;
            $urlData = file_get_contents($absFilePath);
            if (!empty($urlData)) {
                $seoUrlArr =  explode("\n", $urlData);
                if (count($seoUrlArr) > 500) {
                    return false;
                }
                return $seoUrlArr;
            }
        }
        return $seoUrlArr;
    }
    /**
     * Save H2 tags for course type
     */
    private function _saveH2tags($h2Data, $seoId) {        
        if (!empty($h2Data)){
            foreach ($h2Data as $column => $h2Datum) {
                $productSectionData ['name'] = $h2Datum;
                $productSectionData ['sectionTitle'] = $h2Datum;
                if (!$this->saveOrUpdateCourseField($seoId, $column, $productSectionData)){
                    throw new Zend_Exception('H2 tag saving error');
                }              
            }
        }
    }

    /**
     * get H2 tags from Product section Data linking to Section Mapping
     */
    private function _getH2Tags($seoId){
        $sectionMapping = new Model_SectionMapping();
        $productSectionData = $sectionMapping->getByLinkableIdLinkableType($seoId, BaseApp_Dao_SectionMapping::LINKABLE_TYPE_SEO);
        if (!empty($productSectionData)) {
            $h2Data = [];
            foreach($productSectionData as $key => $productSectionDatum) {
                if (!empty($productSectionDatum)){
                    $h2Data[$key] = $productSectionDatum[0]['name'];
                }
                
            }
            return $h2Data;
        }
        return [];
    }
    
    private function saveOrUpdateCourseField($seoId, $sectionType, $data) {
        $objProductSectionData = new Model_ProductSectionData();
        $existing = $objProductSectionData->getDataByType($seoId, BaseApp_Dao_SectionMapping::LINKABLE_TYPE_SEO, $sectionType, true);
        if (empty($existing) || !is_array($existing) && empty(current($existing)['section_id'])) {
            if (!empty($data['name']) && $data['name'] != '') {
                $param = $data;
                $param['seo_id_arr'] = array($seoId);
                $param['sectionType'] = $sectionType;
                if ($objProductSectionData->saveProductSectionData($param)){
                    return true;
                } else {
                    return false;
                }   
            }
            return true;         
        } else {
            $id = current($existing)['section_id'];
            if (!empty($data['name']) && $data['name'] != '') {
                $param = $data;
                $param['seo_id_arr'] = array($seoId);
                $param['sectionType'] = $sectionType;
                if ($objProductSectionData->updateProductSectionData($id, $param)){
                    return true;
                } else {
                    return false;
                }
            } else {
                return $objProductSectionData->disableProductSectionById($id, $seoId, BaseApp_Dao_SectionMapping::LINKABLE_TYPE_SEO);
            }
        }
    }

    private function validateH2Tag($h2Tag){
        $stripTags = new Zend_Filter_StripTags();
        $sanitizedh2Tag = $stripTags->filter($h2Tag);
        $h2Errors = '';
        $h2Validator = new Zend_Validate_StringLength(array('max' => 82));
        $h2Validator->setMessage(
            'h2Tag is too long, it must be at max %max% ' .
            'characters',
            Zend_Validate_StringLength::TOO_LONG);

        if (!$h2Validator->isValid($sanitizedh2Tag)) {
            $h2Errors = $h2Validator->getMessages();
            return current($h2Errors);
        }
        return $h2Errors;
    }

    public function searchAction() {
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $form = new Form_SeoSearch();
        if ($form === false)
            throw new Zend_Exception('_getForm not implemented');
          
        $request = $this->getRequest()->getPost();
        $this->_setMetatagSession($request);
        $this->_setTwitterCardSession($request);
        $this->_setFBOpenGraphSession($request);
        if($this->getRequest()->isPost()) {
            if(isset($request['search'])) {
                if($form->isValid($request)) {                    
                    $url = trim($this->getRequest()->getParam('url'));
                    $checkSlash = substr($url, 0,1);
                    if($checkSlash != '/'){
                       $url = trim('/'.$url);
                    }
                    $modelObj = new Model_Seo();
                    if($seoData = $modelObj->getDataByUrl($url)) {

                        $seoData['urlShow'] = $url;
                        $this->getModel()->extractOtherTags($seoData);
                        $this->_setMetatagSession($seoData);
                        $this->_setTwitterCardSession($seoData);
                        $this->_setFBOpenGraphSession($seoData);

                        $paramsData = json_decode($seoData['params'],true);
                        $form = $this->_getForm($paramsData);
                        $form->setDefaults($seoData);
                    }
                    else {
                        $form = $this->_getForm();                                      
                        $form->setDefaults(array('urlShow'=>$url));
                    }
                }                
            }
            elseif(isset($request['submit']) && $request['submit'] == 'Save') {
                $this->_setMetatagSession($request);
                $this->_setTwitterCardSession($request);
                $this->_setFBOpenGraphSession($request);
                $form = $this->_getForm();
                if($form->isValid($request)) {
                    $form->removeOptionalElements();
                    $dataSave = $form->getValues();
                    
                    /** h2Tag validation Start */
                    $h2Tag = !empty($dataSave['h2Tag']) ? $dataSave['h2Tag'] : '';
                    if ($h2Tag) {
                        if ($h2Error = self::validateH2Tag($h2Tag)) {
                            $form->getElement('h2Tag')->setErrors(array($h2Error));
                            $dataSave = $form->getValues();
                            $dataSave['urlShow'] = $request['url'];
                            $form->setDefaults($dataSave);
                            $this->view->form = $form;
                            return;
                        }
                    }
                    /** h2Tag validation End */

                    unset($dataSave['fbOpenGraph_err']);
                    unset($dataSave['twitterCards_err']);
                    $this->_handleDataAfterSubmit($dataSave);                                                            
                    $dataSave['url'] = trim($dataSave['url']);
                    $moreCitiesParams = array();
                    if($dataSave['url_type'] != 'City Page'){
                        unset($dataSave['linkable_type_id']);
                        unset($dataSave['linkable_id']);
                        unset($dataSave['seo_country_id']);
                        unset($dataSave['seo_city_id']);
                        
                    }else{

                        if(empty($dataSave['linkable_type_id'])){
                            $form->getElement('linkable_type_id')->setErrors(array('Product Type is Missing'));
                            $dataSave['urlShow'] = $request['url'];
                            $form->setDefaults($dataSave);
                            $this->view->form = $form;
                            return false;
                        }
                        if(empty($dataSave['linkable_id'])){
                            $form->getElement('linkable_id')->setErrors(array('Product is Missing'));
                            $dataSave['urlShow'] = $request['url'];
                            $form->setDefaults($dataSave);
                            $this->view->form = $form;
                            return false;
                        }
                        if(empty($dataSave['seo_city_id'])){
                            $form->getElement('seo_city_id')->setErrors(array('City is Missing'));
                            $dataSave['urlShow'] = $request['url'];
                            $form->setDefaults($dataSave);
                            $this->view->form = $form;
                            return false;
                        }
                        $obPt = new BaseApp_Dao_ProductTypes();
                        $productType = current($obPt->fetchForSelect(array('product_type_id =?'=>$dataSave['linkable_type_id'])));
                        $dataSave['controller'] = $productType;
                        $dataSave['linkable_id'] = $dataSave['linkable_id'];
                        $dataSave['linkable_type'] = $productType.'_city';
                        $objCity = new Model_City($dataSave['seo_city_id']);
                        $params = array($productType.'_id'=>$dataSave['linkable_id'],'city_name'=>$objCity->name,'city_id'=>$dataSave['seo_city_id'],'product_type_id'=>$dataSave['linkable_type_id'],'country_id'=>$dataSave['seo_country_id']);
                        
                        if($productType == BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE){
                            $objCourse = new Model_Courses($dataSave['linkable_id']);
                            $objCountry = new Model_Country($objCity->country_id);
                            $moreCitiesParams = array('product_id'=>$dataSave['linkable_id'],'product_type'=>1,'city_id'=>$dataSave['seo_city_id'],'city'=>$objCity->name,'country_id'=>$objCountry->country_id,'country_name'=>$objCountry->name,'course_name'=>$objCourse->name);
                            $objTrainingRelations = new Model_TrainingRelations();
                            $trainingIds = $objTrainingRelations->getCourseTrainingIds($dataSave['linkable_id'], $productType);
                            if(!empty($trainingIds) && in_array(BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM,$trainingIds)){
                                $params['is_classroom_page'] = 1;
                            }
                        }else if($productType == BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES){
                            $objCourse = new Model_Bundles($dataSave['linkable_id']);
                            $objCountry = new Model_Country($objCity->country_id);
                            $moreCitiesParams = array('product_id'=>$dataSave['linkable_id'],'product_type'=>2,'city_id'=>$dataSave['seo_city_id'],'city'=>$objCity->name,'country_id'=>$objCountry->country_id,'country_name'=>$objCountry->name,'course_name'=>$objCourse->name);
                        }
                        $dataSave['params'] = json_encode($params);
                        unset($dataSave['linkable_type_id']);
                        unset($dataSave['seo_city_id']);
                        unset($dataSave['seo_country_id']);
                    }
                    if ($dataSave['url_type'] == BaseApp_Dao_Seo::URL_TYPE_COURSE || $dataSave['url_type'] == BaseApp_Dao_Seo::URL_TYPE_CITY) {
                        $h2Tags = $dataSave['h2tags'];                        
                    }
                    
                    unset($dataSave['h2tags']);
                    
                    $checkSlash = substr($dataSave['url'], 0,1);
                    if($checkSlash != '/'){
                        $dataSave['url'] = trim('/'.$dataSave['url']);
                    }        
                    $modelSeo = new Model_Seo();
                    $modelSeo->getDb()->beginTransaction();
                    try{
                        if($dataSave['seo_id']) {
                            $modelSeo->setId($dataSave['seo_id']);
                            $result = $modelSeo->setFromArray($dataSave)->update();
                        }
                        else {
                            unset($dataSave['seo_id']);
                            $result = $modelSeo->setFromArray($dataSave)->save();
                        }
                        if($result) {
                            if(!empty($moreCitiesParams)){
                                $objMoreCities = new BaseApp_Dao_MoreCities();
                                $moreCityRecord = current($objMoreCities->fetchAll(array('product_id = ?'=>$moreCitiesParams['product_id'],'product_type = ?'=>$moreCitiesParams['product_type'],"city_id =?"=>$moreCitiesParams['city_id'],'status'=>1)));
                                if(empty($moreCityRecord)){
                                    $result = $objMoreCities->setFromArray($moreCitiesParams)->save();
                                }
                            }
                            if(!empty($dataSave['linkable_id'])){
                                $cdnPurgeData = array('linkable_id'=>$dataSave['linkable_id'],'linkable_type'=>$dataSave['linkable_type'],'action'=>'Seo Data Modified '.$dataSave['url'],'url'=>$dataSave['url'],'created_at'=>time(),'updated_at'=>time());
                                $objCdn = new Model_CdnPurgeLog();
                                $objCdn->InsertCdnPurgeLog($cdnPurgeData);
                            }
                            //if url_type is course , save h2 tags
                            if ($dataSave['url_type'] == BaseApp_Dao_Seo::URL_TYPE_COURSE || $dataSave['url_type'] == BaseApp_Dao_Seo::URL_TYPE_CITY) {
                                $this->_saveH2tags($h2Tags, $modelSeo->seo_id );                        
                            }
                                 
                            $modelSeo->getDb()->commit(); 
                            $module  = $this->getRequest()->getModuleName();
                            $controller = $this->getRequest()->getControllerName();
                            if($module && $controller)
                                $this->redirect($module.'/'.$controller.'/list');
                        }                                               
                    } catch(Exception $e) {
                        //$modelSeo->getDb()->rolback(); 
                        throw new Zend_Exception('Seo data not saved '. $e);
                    }
                }        
                else {                    
                    $request['urlShow'] = $request['url'];
                }
            }            
        }                
        $form->setDefaults($request);
        $this->view->form = $form;
    }
    
    
    public function listAction() {
        $table = $this->getModel()->getName();
        $filterForm = new Form_Filters($table);
        $requestData = array();
        $queryParamsArr = array();
        $page = '';
        if($this->getRequest()->isPost()){
            $filterForm->populate($this->getRequest()->getPost());
            $page = 1;
            $requestData = $filterForm->getValues();
            foreach($requestData as $elementName => $elementValue) {
                if(!empty($elementValue)){
                    $queryData = $filterForm->getElement($elementName)->getAttrib('data-table');
                    $queryData['searchValue'] = $elementValue;
                    $this->queryBuilder($queryData);
                    $queryParamsArr[$queryData['search_id']] = $elementValue;
                } // end of !empty elementValue
            } // end of foreach RequestData
        } // end of if isPost
        if(empty($page)){
            $page = $this->view->navigatorPage;
            $page = (int)$this->getRequest()->getParam('page');
        }
        $orderby = $this->getModel()->getPk() . ' DESC';
        if(empty($this->_queryParams)){
            $getData = $this->getRequest()->getQuery();
            unset($getData['page']);
            if(!empty($getData)){
                foreach ($getData as $key => $value) {
                    $queryParamsArr[$key] = $value;
                    $returnData = $filterForm->getSearchFields($key);
                    if(!empty($returnData)){
                        $returnData = $returnData[0];
                        $filterForm->getElement($returnData['searchColumnName'])->setValue($value);
                        $returnData['searchValue'] = $value;
                        $this->queryBuilder($returnData);
                    }
                }
            }
        }
        if ($page <= 1) {
            $this->view->firstpage = true;
            $page = 1;
        } else {
            $this->view->firstpage = false;
        }
        $offset = ($page - 1) * self::ROWS_PER_PAGE;   
        $limit = array(self::ROWS_PER_PAGE,$offset);
        $this->view->page = $page;
        $model = $this->getModel();
        $data = $model->fetchAll($this->_queryParams, array('order' => array($orderby), 'limit' => $limit));
        $perPageData = count($data);
        $total = $model->fetchCount($this->_queryParams);
        if (count($data) < self::ROWS_PER_PAGE) {
            $this->view->lastpage = true;
        } else {
            $this->view->lastpage = false;
        }
        $numberOfPages = ceil($total / self::ROWS_PER_PAGE);
        if($page < $numberOfPages){
            $this->view->currentPageRecord = self::ROWS_PER_PAGE * $page;    
        }else{
            $this->view->currentPageRecord = $total;    
        }
        $this->view->diffPageRecord = $this->view->currentPageRecord - self::ROWS_PER_PAGE;
        if(count($data) < self::ROWS_PER_PAGE){
            $this->view->diffPageRecord = $total - count($data);
        }
        $this->view->totalCount = $total;
        $this->view->totalPages = $numberOfPages;
        $this->view->lastPage = $numberOfPages;
        $pk = $model->getPk();
        foreach ($data as &$row) {
            $row['Action'] = "<a href='" . $this->view->url(array('action' => 'view', 'id' => $row[$pk])) . "'>View</a> " . "<a href='" . $this->view->url(array('action' => 'edit', 'id' => $row[$pk])) . "'>Edit</a> " . "<a href='" . $this->view->url(array('controller' => 'changelog', 'action' => 'index', 'row' => $row[$pk], 'table' => $table)) . "'>ChangeLog</a> " ;
        }
        //================
        if(isset($data[0])){
            $original = array_keys($data[0]);
        }else{
            $original = array();
        }
        $as = ($this->_displayInDataTable);
        //new datatable   
        //need to define path in ini file after discussion
        $datatableFilePath = '../../library/BaseApp/Datatable/'.ucfirst($table).'.php';       
        if(file_exists($datatableFilePath)) {
            $dataTableClass = 'BaseApp_Datatable_'.ucfirst($table);               
        }
        else{
            $dataTableClass = 'BaseApp_Datatable_Default';                            
        }

        $dataTable = new $dataTableClass;
        $dataTable->setData($data);
        $this->view->queryParams = http_build_query($queryParamsArr);
        $this->view->form = $filterForm;
        $this->view->data = $dataTable;
        //------
        //$this->view->data = $data;
        $this->view->original = $original;
        $this->view->displayInDataTable = $as;
        $this->view->navigatorTotal = ceil($total / BACKEND_ROWS_PER_PAGE);
    }
    
    private function _setMetatagSession(&$request) {
        $session = new Zend_Session_Namespace('form'); 
        if(isset($request['metatags']) && count($request['metatags'])) {
            $request['metatags'] = $this->_updateFirstElement($request['metatags']);        
            $session->metatags = array_keys($request['metatags']);
            array_unshift($session->metatags, '__template__');
            $session->metatagsData =  $request['metatags'];
        }
        else {
            $session->metatags = array('__template__', 'new');
            $session->metatagsData = array();
        }        
    }
    
    private function _setTwitterCardSession(&$request) {
        $session = new Zend_Session_Namespace('form'); 
        if(isset($request['twitterCards']) && count($request['twitterCards'])) {
            $session->twitterCardsData =  $request['twitterCards'];
        }
        else {            
            $session->twitterCardsData = array(
                'siteName' => SEO_TWITTER_SITE_NAME,
                'title' => isset($request['title'])?$request['title']:'',
                'description' => isset($request['description'])?$request['description']:'',
                'image' => $this->getModel()->fetchThumbImage($request)
            );
            if(isset($request['url'])) {
                $session->twitterCardsData['pageUrl'] = sprintf("%s%s", SEO_FRONTEND_URL, $request['url']);
            }            
        }    
    }
    
    private function _setFBOpenGraphSession(&$request) {
        $session = new Zend_Session_Namespace('form'); 
        if(isset($request['fbOpenGraph']) && count($request['fbOpenGraph'])) {
            $session->fbOpenGraphData =  $request['fbOpenGraph'];
        }
        else {
            $session->fbOpenGraphData = array(
                'siteName' => SEO_OPEN_GRAPH_SITE_NAME,
                'title' => isset($request['title'])?$request['title']:'',
                'description' => isset($request['description'])?$request['description']:'',
                'image' => $this->getModel()->fetchThumbImage($request)
            );
            if(isset($request['url'])) {
                $session->fbOpenGraphData['pageUrl'] = sprintf("%s%s", SEO_FRONTEND_URL, $request['url']);
            }            
        }    
    }
        
    private function _updateFirstElement($elementArray) {
        $keys = array_keys( $elementArray );
        $keys[ array_search( '0', $keys ) ] = 'new';
        return array_combine( $keys, $elementArray );    
    } 
    
    public function metatagsAddAction() {
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $form = new Form_SeoMetatag();
        $model = new Model_SeoMetatags();
        if ($form === false)
            throw new Zend_Exception('_getForm not implemented');
          
        $request = $this->getRequest()->getPost();       
        if ($request && $form->isValid($request)) {
            unset($request['save']);
            if($tagId = $model->createTag($request)) {
                $result = true;
            }            
            if (!$result) {
                $this->view->message = "An error has occured while saving";
                $this->view->success = true;
            } else {                
                $this->view->message = "Data successfully added";
                $this->view->success = false;
                $form->reset();
                $module  = $this->getRequest()->getModuleName();
                $controller = $this->getRequest()->getControllerName();
                if($module && $controller)
                    $this->redirect($module.'/'.$controller.'/metatags-list');
            }
        }                
        $this->view->form = $form;
    }
    
    public function metatagsEditAction() {
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');        
        if ($this->getRequest()->isPost()) {
            $request = $this->getRequest()->getPost();                   
            $form = new Form_SeoMetatag();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            if($form->isValid($request)) {
                $data = $form->getValues();   
                $data['tag_id'] = $this->getRequest()->getParam('id');   
                $result = false;
                $model = new Model_SeoMetatags();
                if($model->updateTag($data)) {
                    $result = true;
                }
                if (!$result) {
                    $this->view->message = "An error has occured while saving";
                    $this->view->success = true;
                } else {
                    // for making message page specific
                    $this->view->message = ucwords($this->getRequest()->getControllerName())." Data successfully updated";
                    $this->view->success = false;
                }
                $this->_redirect('/admin/seo/metatags-list');
            }
        }
        elseif($tagId = $this->getRequest()->getParam('id')) {  
            $tagModel = new Model_SeoMetatags($tagId);
            if(!$tagModel->toArray()) {
                $this->_redirect('/admin/seo/metatags-list');
            }
            $form = new Form_SeoMetatag();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            
            $form->setDefaults($tagModel->toArray());            
        }
        else {
            $this->_redirect('/admin/seo/metatags-list');
        }
        $this->view->form = $form;
    }
    
    public function metatagsDeleteAction() {
        $this->_helper->viewRenderer->setRender('common/delete')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $tagId = $this->getRequest()->getParam('id');
        $tagModel = new Model_SeoMetatags($tagId);
        $result = $tagModel->delete();
        $this->_redirect('/admin/seo/metatags-list');
    }
    
    public function metatagsListAction() {        
        $model = new Model_SeoMetatags();
        $table = $model->getName();
        $filterForm = new Form_Filters($table);
        $requestData = array();
        $queryParamsArr = array();
        $page = '';
        if($this->getRequest()->isPost()){
            $filterForm->populate($this->getRequest()->getPost());
            $page = 1;
            $requestData = $filterForm->getValues();
            foreach($requestData as $elementName => $elementValue) {
                if(!empty($elementValue)){
                    $queryData = $filterForm->getElement($elementName)->getAttrib('data-table');
                    $queryData['searchValue'] = $elementValue;
                    $this->queryBuilder($queryData);
                    $queryParamsArr[$queryData['search_id']] = $elementValue;
                } // end of !empty elementValue
            } // end of foreach RequestData
        } // end of if isPost
        if(empty($page)){
            $page = $this->view->navigatorPage;
            $page = (int)$this->getRequest()->getParam('page');
        }
        $orderby = $model->getPk() . ' DESC';
        if(empty($this->_queryParams)){
            $getData = $this->getRequest()->getQuery();
            unset($getData['page']);
            if(!empty($getData)){
                foreach ($getData as $key => $value) {
                    $queryParamsArr[$key] = $value;
                    $returnData = $filterForm->getSearchFields($key);
                    if(!empty($returnData)){
                        $returnData = $returnData[0];
                        $filterForm->getElement($returnData['searchColumnName'])->setValue($value);
                        $returnData['searchValue'] = $value;
                        $this->queryBuilder($returnData);
                    }
                }
            }
        }
        if ($page <= 1) {
            $this->view->firstpage = true;
            $page = 1;
        } else {
            $this->view->firstpage = false;
        }
        $offset = ($page - 1) * self::ROWS_PER_PAGE;   
        $limit = array(self::ROWS_PER_PAGE,$offset);
        $this->view->page = $page;        
        $data = $model->fetchAll($this->_queryParams, array('order' => array($orderby), 'limit' => $limit));
        $perPageData = count($data);
        $total = $model->fetchCount($this->_queryParams);
        if (count($data) < self::ROWS_PER_PAGE) {
            $this->view->lastpage = true;
        } else {
            $this->view->lastpage = false;
        }
        $numberOfPages = ceil($total / self::ROWS_PER_PAGE);
        if($page < $numberOfPages){
            $this->view->currentPageRecord = self::ROWS_PER_PAGE * $page;    
        }else{
            $this->view->currentPageRecord = $total;    
        }
        $this->view->diffPageRecord = $this->view->currentPageRecord - self::ROWS_PER_PAGE;
        if(count($data) < self::ROWS_PER_PAGE){
            $this->view->diffPageRecord = $total - count($data);
        }
        $this->view->totalCount = $total;
        $this->view->totalPages = $numberOfPages;
        $this->view->lastPage = $numberOfPages;
        $pk = $model->getPk();
        foreach ($data as &$row) {
            $row['Action'] = "<a href='" . $this->view->url(array('controller' => 'seo', 'action' => 'metatags-edit', 'id' => $row[$pk])) . "'>Edit</a> " . "<a class='delete-crud-item' href='#' onclick='deleteConfirmShow(\"" . $this->view->url(array('controller' => 'seo', 'action' => 'metatags-delete', 'id' => $row[$pk])) . "\");'>Delete</a> " . "<a href='" . $this->view->url(array('controller' => 'changelog', 'action' => 'index', 'row' => $row[$pk], 'table' => $table)) . "'>ChangeLog</a> " ;
        }
        //================
        if(isset($data[0])){
            $original = array_keys($data[0]);
        }else{
            $original = array();
        }
        $as = ($this->_displayInDataTable);
        //new datatable   
        //need to define path in ini file after discussion
        $datatableFilePath = '../../library/BaseApp/Datatable/'.ucfirst($table).'.php';       
        if(file_exists($datatableFilePath)) {
            $dataTableClass = 'BaseApp_Datatable_'.ucfirst($table);               
        }
        else{
            $dataTableClass = 'BaseApp_Datatable_Default';                            
        }

        $dataTable = new $dataTableClass;
        $dataTable->setData($data);
        $this->view->queryParams = http_build_query($queryParamsArr);
        $this->view->form = $filterForm;
        $this->view->data = $dataTable;
        //------
        //$this->view->data = $data;
        $this->view->original = $original;
        $this->view->displayInDataTable = $as;
        $this->view->navigatorTotal = ceil($total / BACKEND_ROWS_PER_PAGE);
    }      
    
    private function _handleDataAfterSubmit(&$request) {
        $metatags = array();
        $request['other_tags'] = array();
        unset($request['metatags']['__template__']);
        $request['canonical'] = trim($request['canonical']);
        if($request['canonical']) {
            $checkSlash = substr($request['canonical'], 0,1);
            if($checkSlash != '/'){
                $request['canonical'] = trim('/'.$request['canonical']);
            }
        }

        foreach($request['metatags'] as $tagData) {
            if(!$tagData['name'] && !$tagData['content']) {
                continue;
            }
            $metatags[] = array(
                'name' => $tagData['name'],
                'content' => $tagData['content']
            );
        }
        if($metatags) {
            $request['other_tags']['metatags'] = $metatags;
        }
        
        if(isset($request['fbOpenGraph'])) {
            $request['other_tags']['fbOpenGraph'] = $request['fbOpenGraph'];
        }        
        if(isset($request['twitterCards'])) {
            $request['other_tags']['twitterCards'] = $request['twitterCards'];
        }                
        $request['other_tags'] = json_encode($request['other_tags']);
        unset($request['metatags']);
        unset($request['fbOpenGraph']);
        unset($request['twitterCards']);
    }                
}
