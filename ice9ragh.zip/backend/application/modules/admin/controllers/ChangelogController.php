<?php
/*
 * Contains the CRUD actions of Addons table
 * 
 */

class Admin_ChangelogController extends BaseApp_Controller_Crud {
    protected $_descriptions = array(
        'list' => 'List of Existing Addons',
        'index' => 'List of Existing Addons',
        'add' => 'Add New Addons',
        'edit' => 'Make the required changes then click on "Save Addons" to update the Addons',
        'view' => 'View Selected Addons',
        'table-logs' => 'table logs'
    );

    protected function _getForm() {
        $form = new Form_Addons();
        return $form;
    }
    
    public function indexAction() {
        $table = $this->getRequest()->getParam('table');
        $row = $this->getRequest()->getParam('row');
        $conds = array();
        if ($table)
            $conds['tableName = ?'] = $table;
        if ($row)
            $conds['row = ?'] = $row;
        $log = BaseApp_Utility_Changelog::getLatestLog(50, $conds);
        foreach ($log as &$entry) {
            $entry['oldValues'] = unserialize($entry['oldValues']);
            $entry['newValues'] = unserialize($entry['newValues']);
        }
        $this->view->log = $log;
        
        $changeLogSession = new Zend_Session_Namespace('changeLog');
        if(isset($changeLogSession->database))
            $this->view->changelogDatabase = $changeLogSession->database;
        if(isset($changeLogSession->table))
            $this->view->changelogTable = $changeLogSession->table;
        if(isset($changeLogSession->row))
            $this->view->changelogRow = $changeLogSession->row;
    }
    
    
    public function viewlogAction() {
        $this->_helper->layout()->disableLayout();
        $id = $this->getRequest()->getParam('id');
        $log = new Model_ChangeLog($id);
        if(!$this->view->oldValue = unserialize($log->oldValues)) {
            $this->view->oldValue = array();
        }
        $this->view->newValue = unserialize($log->newValues);
    }
    
    public function tableLogsAction(){
        $form = new Form_ChangeLog();
        $request = $this->getRequest();
        $redirectUrl = 'admin/changelog/index';
        if($request->getParam('db_name') && $request->getParam('table_name')){
            $db = $request->getParam('db_name');
            $table = $request->getParam('table_name');
            $redirectUrl.= '/table/'.$table;
            $changeLogSession = new Zend_Session_Namespace('changeLog');
            $changeLogSession->database = $db;
            $changeLogSession->table = $table;
            if($request->getParam('row')){
                $row = $request->getParam('row');
                $redirectUrl.= '/row/'.$row;
                $changeLogSession->row = $row;
            }else{
                $changeLogSession->row = '';
            }
            $this->redirect($redirectUrl);
        }
        $this->view->form = $form;
        $changeLogSession = new Zend_Session_Namespace('changeLog');
        if(isset($changeLogSession->database))
            $this->view->changelogDatabase = $changeLogSession->database;
        if(isset($changeLogSession->table))
            $this->view->changelogTable = $changeLogSession->table;
        if(isset($changeLogSession->row))
            $this->view->changelogRow = $changeLogSession->row;
    }
}
