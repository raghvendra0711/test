<?php
/*
 * Contains the CRUD actions of Ios Courses table
 * 
 */

class Admin_IosController extends BaseApp_Controller_Crud {
    
    const IOS_URL_STR = 'com.simplilearn.Simplilearn.';
    const IOS_CURRENCY_STR = '.USD';

    protected $_model = 'Model_IosCourseData';
    protected $_descriptions = array(
        'list' => 'List of Existing Ios Courses',
        'index' => 'List of Existing Ios Courses',
        'add' => 'Add New Ios Courses',
        'edit' => 'Make the required changes then click on "Save Ios Courses" to update the Ios Courses',
        'view' => 'View Selected Ios Courses'
    );

    protected function _getForm() {
        $form = new Form_Ios();
        return $form;
    }

    public function addAction() {
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $form = new Form_Ios();
        $obj = new Model_IosCourseData();
        $request = $this->getRequest()->getPost();
        if ($this->getRequest()->isPost() && $form->isValid($request)) {
            $paramsData = $form->getValues();
            $data['course_id'] = $paramsData['ios_course_id'];
            $data['access_days'] = $paramsData['ios_access_days'];
            $data['course_price'] = $paramsData['course_price'];
            $data['course_key'] = self::IOS_URL_STR.$data['course_id'].'.'.$data['access_days'].self::IOS_CURRENCY_STR;
            if(false == $checkData = $obj->ValidateUniqueCourseAccess($data['course_key'])){
                $this->view->message = "Data Exists Against selected Course And Access Days Combination ";
                $this->view->success = false;
                $obj = new Model_TrainingRelations();
                $this->view->form = $form;
                return false;
            }
            $result = $obj->addIosData($data);
            if (!$result) {
                $this->view->message = "An error has occured while saving";
                $this->view->success = true;
            } else {
                $this->view->message = "Saved SuccessFully";
                $this->view->success = false;
                $form->reset();
                $module  = $this->getRequest()->getModuleName();
                $controller = $this->getRequest()->getControllerName();
                $action = $this->getRequest()->getActionName();
                if($module && $controller && $action)
                    $this->redirect($module.'/'.$controller.'/list');
            }
        }
        $this->view->form = $form;
    }

    public function editAction() {
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $Id = $this->getRequest()->getParam('id');
        $form = new Form_Ios();
        if(!$Id)
            throw new BaseApp_Exception('Editable item not selected properly');        
        $iosData = current($this->getModel()->fetchAll(array('ios_id =?'=>$Id)));
        if (!$iosData) {
            throw new BaseApp_Exception('Editable item not selected properly');
        }
        $iosFormData = array('ios_course_id'=>$iosData['course_id'],'ios_access_days'=>$iosData['access_days'],'course_price'=>$iosData['course_price']);
        if ($this->getRequest()->isPost()) {
            $form->removeUneditableElements();
            $form->removeOptionalElements();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            if ($form->isValid($this->getRequest()->getPost())) {
                $data = $form->getValues();
                $data['ios_id'] = $Id;
                $result = $this->getModel()->updateIosData($data);
                if (!$result) {
                    $this->view->message = "An error has occured while saving";
                    $this->view->success = true;
                    $module  = $this->getRequest()->getModuleName();
                    $controller = $this->getRequest()->getControllerName();
                    $action = $this->getRequest()->getActionName();
                    if($module && $controller && $action)
                        $this->redirect($module.'/'.$controller.'/'.$action.'/id/'.$Id);
                } else {
                    $this->view->message = "Saved SuccessFully";
                    $this->view->success = false;
                    $form->reset();
                    $module  = $this->getRequest()->getModuleName();
                    $controller = $this->getRequest()->getControllerName();
                    $action = $this->getRequest()->getActionName();
                    if($module && $controller && $action)
                        $this->redirect($module.'/'.$controller.'/list');
                }
            }          
        }else{
            $form->setDefaults($iosFormData);
            $form->removeUneditableElements();
        }
        $this->view->form = $form;
    }
}
