<?php
/*
 *CRUD for banners
 * 
 */

class Admin_BannerController extends BaseApp_Controller_Crud {
    protected $_model = 'Model_Banners';
    protected $_descriptions = array(
        'list' => 'List of Existing Labels',
        'index' => 'List of Existing Labels',
        'add' => 'Add New Labels',
        'edit' => 'Make the required changes then click on "Save Labels" to update the Labels',
        'view' => 'View Selected Labels'
    );

    public function indexAction() {
        
    }
    
    protected function _getForm() {
        $form = new Form_Banners();
        return $form;
    }
    
    public function addAction() {        
        $request = $this->getRequest()->getPost();       
        if (!$this->_add)
            $this->forward('list');
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $form = $this->_getForm();        
        if ($form === false)
            throw new Zend_Exception('_getForm not implemented');
        if ($request && $form->isValid($request)) {
            $request = $form->getValues(); 
            $splitData = $this->_handleAfterSubmit($request);
            $result = false;
            if($bannerId = $this->getModel()->createBanner($request)) {
                $result = true;
                $imageModel = new Model_Images();
                foreach($splitData['imageData'] as $tempId => $imageData) {
                    if($result && !$imageModel->saveImageByName($bannerId, 'banner', $imageData)) {
                        $result = false;
                    }
                }
            }
            
            if (!$result) {
                $this->view->message = "An error has occured while saving";
                $this->view->success = true;
            } else {                
                $this->view->message = "Data successfully added";
                $this->view->success = false;
                $form->reset();
                $module  = $this->getRequest()->getModuleName();
                $controller = $this->getRequest()->getControllerName();
                $action = $this->getRequest()->getActionName();
                if($module && $controller && $action)
                    $this->redirect($module.'/'.$controller.'/list');
            }
        }
        $this->view->form = $form;
    }
    
    public function editAction() {  
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
                        
        if ($this->getRequest()->isPost()) {
            $request = $this->getRequest()->getPost();       
            
            $form = $this->_getForm();
            $form->removeUneditableElements();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            
            if($form->isValid($request)) {
                $data = $form->getValues();
                $splitData = $this->_handleAfterSubmit($data);
                $data['banner_id'] = $this->getRequest()->getParam('id');   
                $result = false;
                if($this->getModel()->updateBanner($data)) {
                    $result = true;
                    $imageModel = new Model_Images();
                    foreach($splitData['imageData'] as $tempId => $imageData) {
                        if($result && !$imageModel->saveImageByName($data['banner_id'], 'banner', $imageData)) {
                            $result = false;
                        }
                    }
                }
                if (!$result) {
                    $this->view->message = "An error has occured while saving";
                    $this->view->success = true;
                } else {
                    // for making message page specific
                    $this->view->message = ucwords($this->getRequest()->getControllerName())." Data successfully updated";
                    $this->view->success = false;
                }
                $this->_redirect('/admin/banner/list');
            }
        }    
        elseif($bannerId = $this->getRequest()->getParam('id')) {            
            $bannerModel = new Model_Banners($bannerId);
            if(!$bannerModel->toArray()) {
                $this->_redirect('/admin/banner/list');
            }
            $imageModel = new Model_Images();
            if($imageData = $imageModel->getByLinkableAndName($bannerId, 'banner', 'home_page_banner')) {
                $bannerModel->banner_path = $imageData['imagePath'];
            }
            if($imageData = $imageModel->getByLinkableAndName($bannerId, 'banner', 'mobile_banner')) {
                $bannerModel->mobile_banner_path = $imageData['imagePath'];
            }
                        
            $bannerModel->cluster_id = explode(",", $bannerModel->cluster_id);
            $bannerModel->country_id = explode(",", $bannerModel->country_id);
            $bannerModel->labels = $bannerModel->label_id;

            $this->view->postParams = $bannerModel;
            $form = $this->_getForm();
            $form->removeUneditableElements();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            $form->setDefaults($bannerModel->toArray());            
        }
        else {
            $this->_redirect('/admin/banner/list');
        }
        $this->view->form = $form;
    }
    
    private function _handleAfterSubmit(&$request) {
        $returnData = array(
            'imageData' => array()
        );
        
        if(isset($request['banner_path']) && $request['banner_path']) {
            $returnData['imageData'][] = array(
                'name' => 'home_page_banner',
                'imagePath'=> $request['banner_path'],
                'imageDescription'=> ''
            );            
        }
        
        if(isset($request['mobile_banner_path']) && $request['mobile_banner_path']) {
            $returnData['imageData'][] = array(
                'name' => 'mobile_banner',
                'imagePath'=> $request['mobile_banner_path'],
                'imageDescription'=> ''
            );
        }

        if($request['homeBanner']) {                
            $request['banner_type'] = 'home';
        }
        else {
            $request['label_id'] = $request['labels'];                
            $request['banner_type'] = 'label';
        }
        $request['cluster_id'] = implode(",", $request['cluster_id']);
        $request['country_id'] = implode(",", $request['country_id']);
        unset($request['homeBanner']);
        unset($request['labels']);
        unset($request['banner_path']);
        unset($request['mobile_banner_path']);
        return $returnData;
    }
    
}
