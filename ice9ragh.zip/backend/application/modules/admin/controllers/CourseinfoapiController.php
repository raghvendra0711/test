<?php
/*
 * Contains the CRUD actions of Label table
 *
 */

class Admin_CourseinfoapiController extends BaseApp_Controller_Crud
{
    protected $_model = 'Model_CourseInfoApi';
    protected $_descriptions = array(
        'list' => 'List of Existing Mapping',
        'index' => 'List of Existing Mapping',
        'add' => 'Add New Mapping',
        'edit' => 'Make the required changes then click on "Save Mapping" to update the Mapping',
        'view' => 'View Selected Mapping',
        'get-by-part-name' => 'For searching course by name name',
        'order' => 'arrange Mapping in a proper order',
        'flyout' => 'flyout lable page'
    );

    protected function _getForm()
    {
        $form = new Form_CourseInfoApi();
        return $form;
    }

    public function addAction()
    {
        $request = $this->getRequest()->getPost();
        if (!$this->_add) {
            $this->forward('list');
        }
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $form = $this->_getForm();
        if ($form === false) {
            throw new Zend_Exception('_getForm not implemented');
        }
        if ($request && $form->isValid($request)) {
            $request = $form->getValues();
            unset($request['tmp_id']);
            if (!empty($request['course_id'])) {
                $request['course_id'] = implode(',',$request['course_id']);
            }
            if (!empty($request['training_id'])) {
                $request['training_id'] = implode(',',$request['training_id']);
            }

            $result = false;

            $this->getModel()->clean();
            $resultInsert = $this->getModel()->setFromArray($request)->save();



            if (!$result) {
                $this->view->message = "An error has occured while saving";
                $this->view->success = true;
            } else {
                $this->view->success = false;
                $this->_redirect('/admin/courseinfoapi/list');
            }
            //$this->forward('list');
        }
        $this->view->form = $form;
    }

    public function getByPartNameAction()
    {
        $arg = $this->getRequest()->get('labelPart');
        $labelList = array();
        if ($arg) {
            foreach ($this->getModel()->getByPartName($arg) as $indexId => $data) {
                $labelList[$data['label_id']] = $data['name'];
            }
        }
        $this->_helper->layout->disableLayout();
        $this->view->labelList =  $labelList;
    }

    public function orderAction()
    {
        if (!$request = $this->getRequest()->getPost()) {
            $this->view->labelList =  $this->getModel()->getByParentLabel();
        } else {
            unset($request['Save']);
            $model = new Model_CourseInfoApi();
            $lableIdsAll = array();
            foreach ($request as $parentLabel => $lableIds) {
                $request[$parentLabel] = explode(",", $lableIds);
                $lableIdsAll = array_merge($lableIdsAll, $request[$parentLabel]);
            }
            $saveData = array();
            foreach ($lableIdsAll as $lableId) {
                foreach ($request as $parentLabel => $lableIds) {
                    $orderNo = array_search($lableId, $lableIds);
                    if ($orderNo !== false) {
                        $orderNo++;
                        $saveData[$lableId][$parentLabel.'OrderNo'] = $orderNo;
                    }
                }
            }
            foreach ($saveData as $labelId => $data) {
                $model->clean();
                $model->setId($labelId);
                $model->setFromArray($data)->update();
            }
            $module  = $this->getRequest()->getModuleName();
            $controller = $this->getRequest()->getControllerName();
            $action = $this->getRequest()->getActionName();
            if ($module && $controller && $action) {
                $cdnPurgeData  = $this->getModel()->buildCdnPurgeData($data['label_id'], 'Category Modified'.$data['name']);
                $objCdn = new Model_CdnPurgeLog();
                if (!empty($cdnPurgeData)) {
                    $objCdn->InsertCdnPurgeLog($cdnPurgeData);
                }
                $this->redirect($module.'/'.$controller.'/'.$action.'?success=true');
            }
        }
    }


    public function editAction()
    {
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');

        if ($this->getRequest()->isPost()) {
            $request = $this->getRequest()->getPost();
            $this->view->Id = $this->getRequest()->getParam('id');

            $form = $this->_getForm();
            $form->removeOptionalValidators();
            $form->removeUneditableElements();
            if ($form === false) {
                throw new Zend_Exception('_getForm not implemented');
            }

            if ($form->isValid($request)) {
                $request = $form->getValues();
                if (!empty($request['course_id'])) {
                    $request['course_id'] = implode(',',$request['course_id']);
                }
                if (!empty($request['training_id'])) {
                    $request['training_id'] = implode(',',$request['training_id']);
                }
                $request['id'] = $this->getRequest()->getParam('id');
                unset($request['tmp_id']);
                $result = false;
                if ($this->getModel()->updateMapping($request)) {
                    $result = true;
                }

                if (!$result) {
                    $this->view->message = "An error has occured while saving";
                    $this->view->success = true;
                } else {
                    $this->view->message = ucwords($this->getRequest()->getControllerName())." Data successfully updated";
                    $this->view->success = false;
                }
                $this->_redirect('/admin/courseinfoapi/list');
            }
        } elseif ($labelId = $this->getRequest()->getParam('id')) {
            $labelModel = new Model_CourseInfoApi($labelId);
            if (!$labelModel->toArray()) {
                $this->_redirect('/admin/courseinfoapi/list');
            }
            $labelModel->tmp_id = $labelId;
            $labelModel->course_id = explode(",", $labelModel->course_id);
            $labelModel->training_id = explode(",", $labelModel->training_id);

            $this->view->postParams = $labelModel;
            $this->view->labelId = $labelId;
            $form = $this->_getForm();
            $form->removeUneditableElements();
            if ($form === false) {
                throw new Zend_Exception('_getForm not implemented');
            }
            $form->setDefaults($labelModel->toArray());
        } else {
            $this->_redirect('/admin/courseinfoapi/list');
        }
        $this->view->form = $form;
    }



    private function _updateFirstElement($elementArray)
    {
        $keys = array_keys($elementArray);
        $keys[ array_search('0', $keys) ] = 'new';
        return array_combine($keys, $elementArray);
    }

    public function listAction() {
        $this->_helper->viewRenderer->setRender('common/list')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $table = $this->getModel()->getName();
        $filterForm = new Form_Filters($table);
        $requestData = array();
        $queryParamsArr = array();
        $page = '';
        echo "URL : ". FRONTEND_URL . '/api/v1/index?method=getCoursesData&identifier={companyidentifier}&pageNum={pagenumber}';
        if($this->getRequest()->isPost()){
            $filterForm->populate($this->getRequest()->getPost());
            $page = 1;
            $requestData = $filterForm->getValues();
            foreach($requestData as $elementName => $elementValue) {
                if(!empty($elementValue)){
                    $queryData = $filterForm->getElement($elementName)->getAttrib('data-table');
                    $queryData['searchValue'] = $elementValue;
                    $this->queryBuilder($queryData);
                    $queryParamsArr[$queryData['search_id']] = $elementValue;
                } // end of !empty elementValue
            } // end of foreach RequestData
        } // end of if isPost
        if(empty($page)){
            $page = $this->view->navigatorPage;
            $page = (int)$this->getRequest()->getParam('page');
        }
        $orderby = $this->getModel()->getPk() . ' DESC';
        if(empty($this->_queryParams)){
            $getData = $this->getRequest()->getQuery();
            unset($getData['page']);
            if(!empty($getData)){
                foreach ($getData as $key => $value) {
                    $queryParamsArr[$key] = $value;
                    $returnData = $filterForm->getSearchFields($key);
                    if(!empty($returnData)){
                        $returnData = $returnData[0];
                        $filterForm->getElement($returnData['searchColumnName'])->setValue($value);
                        $returnData['searchValue'] = $value;
                        $this->queryBuilder($returnData);
                    }
                }
            }
        }
        if ($page <= 1) {
            $this->view->firstpage = true;
            $page = 1;
        } else {
            $this->view->firstpage = false;
        }
        $offset = ($page - 1) * self::ROWS_PER_PAGE;
        $limit = array(self::ROWS_PER_PAGE,$offset);
        $this->view->page = $page;
        $model = $this->getModel();
        $data = $model->fetchAll($this->_queryParams, array('order' => array($orderby), 'limit' => $limit));
        $perPageData = count($data);
        $total = $model->fetchCount($this->_queryParams);
        if (count($data) < self::ROWS_PER_PAGE) {
            $this->view->lastpage = true;
        } else {
            $this->view->lastpage = false;
        }
        $numberOfPages = ceil($total / self::ROWS_PER_PAGE);
        if($page < $numberOfPages){
            $this->view->currentPageRecord = self::ROWS_PER_PAGE * $page;
        }else{
            $this->view->currentPageRecord = $total;
        }
        $this->view->diffPageRecord = $this->view->currentPageRecord - self::ROWS_PER_PAGE;
        if(count($data) < self::ROWS_PER_PAGE){
            $this->view->diffPageRecord = $total - count($data);
        }
        $this->view->totalCount = $total;
        $this->view->totalPages = $numberOfPages;
        $this->view->lastPage = $numberOfPages;
        $pk = $model->getPk();
        foreach ($data as &$row) {
            $row['isModified'] = '';
            if(!empty($row['modified_bundle_id'])){
                $row['isModified'] = self::STR_MODIFIED;
            }

            $row['Action'] = "<a href='" . $this->view->url(array('action' => 'view', 'id' => $row[$pk])) . "'>View</a> " . "<a href='" . $this->view->url(array('controller' => 'changelog', 'action' => 'index', 'row' => $row[$pk], 'table' => $table)) . "'>ChangeLog</a> " .
                    "<a href='" . $this->view->url(array('action' => 'edit', 'id' => $row[$pk])) . "'>Edit</a> " .
                    "<a class='delete-crud-item' href='#' onclick='deleteConfirmShow(\"" . $this->view->url(array('action' => 'delete', 'id' => $row[$pk])) . "\");'>Delete</a> " .
                    "<a href='" . $this->view->url(array('module' => 'admin', 'controller' => 'pricing', 'action' => 'list-other', 'id' => $row[$pk], 'type' => 'bundle'),null,true) . "' target='_blank'>View Price</a> ";
        }
        if(isset($data[0])){
            $original = array_keys($data[0]);
        }else{
            $original = array();
        }
        $as = ($this->_displayInDataTable);
        //new datatable
        //need to define path in ini file after discussion
        $datatableFilePath = '../../library/BaseApp/Datatable/'.ucfirst($table).'.php';
        if(file_exists($datatableFilePath)) {
            $dataTableClass = 'BaseApp_Datatable_'.ucfirst($table);
        }
        else{
            $dataTableClass = 'BaseApp_Datatable_Default';
        }

        $dataTable = new $dataTableClass;
        $dataTable->setData($data);
        $this->view->queryParams = http_build_query($queryParamsArr);
        $this->view->form = $filterForm;
        $this->view->data = $dataTable;
        $this->view->original = $original;
        $this->view->displayInDataTable = $as;
        $this->view->navigatorTotal = ceil($total / BACKEND_ROWS_PER_PAGE);
    }

    public function deleteAction() {
        $this->_helper->viewRenderer->setRender('common/delete')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $Id = $this->getRequest()->getParam('id');

        $dataDelete = $this->getModel($Id);
        if(!$dataDelete->toArray()) {
            $this->view->message = "Invalid Mapping";
            $this->view->success = false;
            return;
        }

        if(!$dataDelete->delete()) {
            $this->view->message = 'failed to delete Mapping:'.$Id;
            $this->view->success = false;
            return;
        }
        $action = 'Mapping Deleted';
        $cdnPurgeData = $this->getModel()->buildCdnPurgeData($Id,$dataDelete['name'].$action);
        $objCdn = new Model_CdnPurgeLog();
        if(!empty($cdnPurgeData))
            $objCdn->InsertCdnPurgeLog($cdnPurgeData);
        $this->_redirect("/admin/courseinfoapi/list");
    }

}
