<?php

/*
 * CRUD for seo
 * 
 */

class Admin_FptUserReportController extends BaseApp_Controller_Crud {
    private $_db = null;
    private $_limit = 50;
    private $fptList = array();
    
    public function init() {
        $this->_db = new Model_Default;
        $this->fptList = array();
        parent::init();
    }


    public function userPersonaAction() {
        $request = $this->getRequest()->getParams();
        if(empty($request['email'])) {
            return;
        }
        
        // Get persona infromation
        $data = $this->callPrsonaApi($request['email']);
        if($data) {
            $onboardingData = $data['get-onboarding-data'];
            $elearningData = $data['get-elearnings-data'];
            $this->view->elearningData = array();
            $this->view->elearningData['rows'] = array();
            $this->view->elearningData['head'] = array();
            
            if(!empty($elearningData)) {
                $this->view->elearningData['rows'] = $elearningData;
                $this->view->elearningData['head'] = array_keys(current($elearningData));
            }
            $this->view->onboardingData = $onboardingData;
        }
    }

    private function callPrsonaApi($email) {
        $params = $this->getRequest()->getPost();
        $formData = array();
        $formData['userMail'] = $email;
        $formData['dataTypes'] = '["get-elearnings-data","get-onboarding-data"]';
        $today = Date("Y-m-d");
        $paramsSerialized = serialize($formData);
        $authKeyFromParams = sha1($paramsSerialized . SALESFORCE_APIS_SALT . $today);
        $formData['authKey'] = $authKeyFromParams;
        $action = BASE_LMS_URL . "/userpersona/v1/get-single-user-persona-info";
        $response = null;
        $err = null;
        
        try {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $action);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($formData));
            $responseRow = curl_exec($ch);
            $response = json_decode($responseRow, true);
            $err = curl_error($ch);
            curl_close($ch);
            
            if(empty($response['status']) || $response['status'] != 1) {
                throw new Exception("API Error - " . $response['msg']);
            }
        } catch(Exception $e) {
            $err = $e->getMessage();
        }
        
        if ($err) {
            return null;
        } else {
            return empty($response['data'])?null:$response['data'];
        }
    }

    public function userInfoAction() {
        $request = $this->getRequest()->getParams();
        if(empty($request['email'])) {
            return;
        }
        $email = $request['email'];
        $objAccounts = new BaseApp_Communication_Accounts();
        $data = $objAccounts->getUserDetailsByEmail($email);
        if(!empty($data['data'])) {
            $profile = $data['data'];
            $this->view->profile = $profile;
        }
    }

    public function reportAction() {
        set_time_limit(60);
        $db = $this->_db;
        $request = $this->getRequest()->getParams();
        if(empty($request['email'])) {
            return;
        }
        $email = trim($request['email']);
        $email = str_replace(" ", "+", $email);
        
    /*  $order = new BaseApp_Dao_Melvin_Order();
        $timestamp = strtotime(date('Y-m-d')." -6 month");
        $orderData = $order->getOrderDetailsByUserEmail($email, $timestamp);
         if(!empty($orderData)) {
            $orderRows = array();
            foreach($orderData as $order) {
                $row = array();
                $row['CrderNumber'] = $order['orderNumber'];
                $row['Date'] = date('Y M d', $order['date']);
                $row['TotalAmount'] = $order['totalAmount'];
                $row['CurrencyCode'] = $order['currencyCode'];
                $row['OrderNumber'] = $order['orderNumber'];
                $row['OrderNumber'] = $order['orderNumber'];
                $row['OrderNumber'] = $order['orderNumber'];
                $row['OrderNumber'] = $order['orderNumber'];
                
                if(!empty($order['items'])) {
                    foreach ($order['items'] as $item) {
                        $itemRow = $row;
                        $itemRow['CourseId'] = $item['courseId'];
                        $itemRow['CourseName'] = $item['course'];
                        $orderRows[] = $itemRow;
                    }
                } else {
                    $orderRows[] = $row;
                }
            }
            $this->view->orderData = $orderRows;
        } */
        
        /* $data = $db->FreePracticeTestsUserData
                ->find(array('user_data.email' => $email))
                ->limit($this->_limit)
                ->sort(array('created' => -1))
                ->toArray(0);
        */
        $fptObj = new Model_FptUserReport();
        $data = $fptObj->getUserData($email);
        $userData = array();
        $keys = [];
        if(!empty($data)){
            $uData = (!empty($data[0])) ? $data[0] : array();
            $uData = (array) $uData;
            $this->view->email = (!empty($uData && !empty($uData['email_id']))) ? $uData['email_id'] : '';
            foreach ($data as $temp) {
                $temp = (array) $temp;
                $row = array();
                $row['phone'] = (!empty($temp['phone'])) ? $temp['phone'] : '';
                $row['course_id'] = (!empty($temp['course_id'])) ? $temp['course_id'] : '';
                $row['course_name'] = (!empty($temp['product_name'])) ? $temp['product_name'] : '';
                $row['test_id'] = (!empty($temp['practice_test_id'])) ? $temp['practice_test_id'] : '';
                $row['test_type'] = (!empty($temp['test_type'])) ? $temp['test_type'] : 'free_practice_test';
                $row['fpt_name'] = !empty($temp['practice_test_name']) ? $temp['practice_test_name'] : '';
                $row['no_of_questions'] = !empty($temp['total_questions']) ? $temp['total_questions'] : '';
                $row['no_of_attempt'] = !empty($temp['questions_attempted']) ? $temp['questions_attempted'] : 0;
                $row['no_of_correct_answers'] = !empty($temp['questions_correct']) ? $temp['questions_correct'] : 0;

                $row['attempt_percentage'] =  (!empty($temp['questions_attempted']) && !empty($temp['total_questions'])) ? (($temp['questions_attempted'] * 100)/$temp['total_questions']) : 0;
                $row['attempt_percentage'] = number_format($row['attempt_percentage'], 2, '.', '') + 0 . '%';
                $row['correct_percentage'] = !empty($temp['correct_percentage']) ? $temp['correct_percentage'] . '%' : 0 . '%';
                $row['fpt_created'] = date("Y-m-d h:i:s A", ($temp['fpt_time']/1000));
                $row['id'] = $temp['fpt_time'];
                //$row['fpt_created_timestamp'] = $temp['created'];
                $userData[] = $row;
            }
        }

        $this->view->userData = $userData;
        $this->view->userColumnHead = array(
            "Phone","Product Id", "Product Name", "Test Id", "Test Type", "Test Name", "Total Questions", "Questions Attempted", "Questions Correct", "Attempt %<br/>attempt/questions", "Correct %<br/>correct/questions", "Created At"
        );
    }
    
    private function getNumberOfAttmept($userSheet) {
        $count = 0;
        if (!empty($userSheet)) {
            foreach ($userSheet as $temp) {
                if ($temp['selected_option'] != -1) {
                    $count++;
                }
            }
        }
        return $count;
    }

    private function getFptNameById($fptId) {
        $db = $this->_db;
        if (empty($this->fptList[$fptId])) {
            $data = $db->FreePracticeTests->find(array('practiceTest_id' => $fptId))->toArray();
            if (empty($data[0])) {
                return '';
            }
            $data = $data[0];
            $name = $data['title'];
            if (!empty($data['seo_data']['name'])) {
                $name = $data['seo_data']['name'];
                $this->fptList[$fptId] = $name;
            }
        } else {
            $name = $this->fptList[$fptId];
        }
        return $name;
    }

}
