<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Admin_EventsController extends BaseApp_Controller_Crud {

    protected $_model = 'Model_CourseEventsData';
    protected $_descriptions = array(
        'list' => 'List of Existing CourseEventsData',
        'index' => 'List of Existing CourseEventsData',
        'add' => 'Add New CourseEventsData',
        'edit' => 'Make the required changes then click on "Save CourseEventsData" to update the CourseEventsData',
        'view' => 'View Selected CourseEventsData'
    );

    protected function _getForm() {
        $form = new Form_CourseEventsData();
        return $form;
    }

    public function addAction() {
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $form = $this->_getForm();
        $request = $this->getRequest()->getPost();
        $action = $this->getRequest()->getActionName();
        $request['action'] = $action;
        $form = $this->_getForm();
        if ($form === false)
            throw new Zend_Exception('_getForm not implemented');
        if ($this->getRequest()->isPost() && $form->isValid($request)) { //prd($request);
            $eventsSiteIds = implode(',', $request['eventSite']);
            //pr();
            $request['eventSite'] = $eventsSiteIds;
            $eventObj = new Model_CourseEventsData();
            $result = $eventObj->SaveEventData($request);
            if (!$result) {
                $this->view->message = "An error has occured while saving";
                $this->view->form = $form;
                return false;
            } else {
                $this->view->message = "Saved SuccessFully";
                $module = $this->getRequest()->getModuleName();
                $controller = $this->getRequest()->getControllerName();
                if ($module && $controller)
                    $this->redirect($module . '/' . $controller . '/list');
            }
        }
        $this->view->form = $form;
    }

    public function editAction() {
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $id = $this->getRequest()->getParam('id');
        $data = $this->getModel($id);
        $form = $this->_getForm();
        $form->removeUneditableElements();
        if ($data) {
            $this->view->postParams = $data;
            if ($this->getRequest()->isPost()) {

                $request = $this->getRequest()->getPost();
                $form = $this->_getForm();
                if ($form === false)
                    throw new Zend_Exception('_getForm not implemented');
                if ($form->isValid($request)) {
                    $dataSave = $form->getValues();
                    try {
                        if (!empty($dataSave)) {
                            unset($dataSave['primary_course_id']);
                            unset($dataSave['eventSite']);
                            $data->setId($id);
                            $result = $data->setFromArray($dataSave)->update();
                        }
                    } catch (Exception $e) {
                        $this->view->message = "there is a issue while updating data";
                    }
                    if (!$result) {
                        $this->view->message = "An error has occured while saving";
                    } else {
                        $module = $this->getRequest()->getModuleName();
                        $controller = $this->getRequest()->getControllerName();
                        if ($module && $controller)
                            $this->redirect($module . '/' . $controller . '/list');
                    }
                }
                else {
                    $dataSave = $form->getValues();
                    $form->setDefaults($dataSave);
                }
            } else {
                $courseEventData = array();
                $courseEventData = $data->toArray();
                $courseEventData['eventSite'] = explode(',', $courseEventData['eventSite']);
                //prd($courseEventData);
                if ($form === false)
                    throw new Zend_Exception('_getForm not implemented');
                $form->setDefaults($courseEventData);
            }
            $this->view->form = $form;
        }
    }

}
