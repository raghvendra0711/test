<?php

/*
 * Contains the CRUD actions of ****** table
 * 
 */
//******************** */
class Admin_UniversityController extends BaseApp_Controller_Crud {

    protected $_model = 'Model_University';
     
    const TYPE_UNIVERSITY_MASTERS_PAGE = 'university_masters_page';

    protected function _getForm() {        
        $form = new Form_University();           
        return $form;
    }

    public function addAction(){
        $data = [];
        $form = $this->_getForm();
        
        if ($form === false)
            throw new Zend_Exception('_getForm not implemented');
                    
            if ($this->getRequest()->isPost() && $form->isValid($this->getRequest()->getPost())) {
                $request = $this->getRequest()->getPost();
                $formValues = $form->getValues();                          
                $saveArr = array();  
                $saveArr = array(
                    'name'  => $formValues['name'],
                    'alt_text'  => $formValues['alt_text'],
                    'link'  => $formValues['link'],
                    'page_type' => $formValues['page_type'][0],                    
                    'status'        => 1,
                );              
                //image upload s3
      
               if (isset($_FILES['logo_colored']['name']) && $_FILES['logo_colored']['name'] != '') {
                $fileName = $_FILES['logo_colored']['name'];
                $absFilePath = sys_get_temp_dir().DIRECTORY_SEPARATOR.$fileName; //sys_get_temp_dir().DIRECTORY_SEPARATOR.$fileName;                            
                //$absFilePath = $_FILES['image_url']['tmp_name'];                           
                $s3path = AWS_S3_IMAGES_PATH . '/university';
                $bannerImgUrl = BaseApp_Utility_ImageProcessing::transformAndUploadToS3($absFilePath, $fileName, $s3path);                            
                $saveArr['university_logo_colored']   = $bannerImgUrl;
            }
 
       
            if (isset($_FILES['logo_bw']['name']) && $_FILES['logo_bw']['name'] != '') {
                $fileName = $_FILES['logo_bw']['name'];
                $absFilePath = sys_get_temp_dir().DIRECTORY_SEPARATOR.$fileName; //sys_get_temp_dir().DIRECTORY_SEPARATOR.$fileName;                            
                //$absFilePath = $_FILES['image_url']['tmp_name'];                           
                $s3path = AWS_S3_IMAGES_PATH . '/university';
                $thumbImgUrl = BaseApp_Utility_ImageProcessing::transformAndUploadToS3($absFilePath, $fileName, $s3path);                            
                $saveArr['university_logo_bw']   = $thumbImgUrl;
            }

                           
                //end image upload
                //upload images                                    
              $status = $this->getModel()->saveContent($saveArr);
              //redirect 
            $module = $this->getRequest()->getModuleName();
            $controller = $this->getRequest()->getControllerName();
            if ($module && $controller)
                $this->redirect($module . '/' . $controller . '/list');

        } 
        $this->view->postParams = $data;      
        $form->setDefaults($data);
        $this->view->form = $form;  

    }

    public function editAction(){
        $request = $this->getRequest()->getParams();        
        $id = !empty($request['id']) ? $request['id'] : "";
        //data already exists
        $pageTypes=array(
            self::TYPE_UNIVERSITY_MASTERS_PAGE=>'University Master Page'                    
        );
        $data = [];
        if($id !="")
            $data = $this->getModel()->getUniversityContent($id);   
               
        
        $module = $this->getRequest()->getModuleName();
        $controller = $this->getRequest()->getControllerName();
        if(empty($data)){            
            if ($module && $controller)
                $this->redirect($module . '/' . $controller . '/list');
        }
  
        $form = $this->_getForm();
        
        if ($form === false)
            throw new Zend_Exception('_getForm not implemented');
                    
            if ($this->getRequest()->isPost() && $form->isValid($this->getRequest()->getPost())) {
                $request = $this->getRequest()->getPost();
                $formValues = $form->getValues();                
                $saveArr = array();  
                $saveArr = array(
                    'name'  => $formValues['name'],
                    'alt_text'  => $formValues['alt_text'],
                    'link'  => $formValues['link'],
                    'page_type' => $formValues['page_type'][0],                    
                    'status'        => 1,
                );              
                //image upload s3
   
                if (isset($_FILES['logo_colored']['name']) && $_FILES['logo_colored']['name'] != '') {
                    $fileName = $_FILES['logo_colored']['name'];
                    $absFilePath = sys_get_temp_dir().DIRECTORY_SEPARATOR.$fileName; //sys_get_temp_dir().DIRECTORY_SEPARATOR.$fileName;                            
                    //$absFilePath = $_FILES['image_url']['tmp_name'];                           
                    $s3path = AWS_S3_IMAGES_PATH . '/university';
                    $bannerImgUrl = BaseApp_Utility_ImageProcessing::transformAndUploadToS3($absFilePath, $fileName, $s3path);                            
                    $saveArr['university_logo_colored']   = $bannerImgUrl;
                }
    
                if (isset($_FILES['logo_bw']['name']) && $_FILES['logo_bw']['name'] != '') {
                    $fileName = $_FILES['logo_bw']['name'];
                    $absFilePath = sys_get_temp_dir().DIRECTORY_SEPARATOR.$fileName; //sys_get_temp_dir().DIRECTORY_SEPARATOR.$fileName;                            
                    //$absFilePath = $_FILES['image_url']['tmp_name'];                           
                    $s3path = AWS_S3_IMAGES_PATH . '/university';
                    $thumbImgUrl = BaseApp_Utility_ImageProcessing::transformAndUploadToS3($absFilePath, $fileName, $s3path);                            
                    $saveArr['university_logo_bw']   = $thumbImgUrl;
                }

                           
                //end image upload
                //upload images 
                   
                $status = $this->getModel()->updateContent($saveArr,$id);
                              
                if ($module && $controller)
                    $this->redirect($module . '/' . $controller . '/list');

        } 
        $this->view->postParams = $data;      
        $form->setDefaults($data);
        $this->view->form = $form; 
    }

    public function addReplicaAction() {
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $id = $this->getRequest()->getParam('id');
        $data = $this->getModel($id);
        if ($data) {
            $form = $this->_getForm();
            $form->removeOptionalValidators();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            if ($this->getRequest()->isPost() && $form->isValid($this->getRequest()->getPost())) {
                $formData = $form->getValues();                 
                unset($formData['logo_colored']);
                unset($formData['logo_bw']);                
                $result = $data->setFromArray($formData)->save();
                if (!$result) {
                    $this->view->message = "An error has occured while saving";
                    $this->view->success = true;
                } else {
                    $this->view->message = "Saved SuccessFully";
                    $this->view->success = false;
                }
            }
            $form->setDefaults($data->toArray());
            $this->view->form = $form;
        }
    }
 

}
