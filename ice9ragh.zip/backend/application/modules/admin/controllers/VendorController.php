<?php
/*
 * Contains the CRUD actions of Vendors table
 * 
 */

class Admin_VendorController extends BaseApp_Controller_Crud {
    protected $_model = 'Model_Vendors';
    protected $_descriptions = array(
        'list' => 'List of Existing Vendors',
        'index' => 'List of Existing Vendors',
        'add' => 'Add New Vendors',
        'edit' => 'Make the required changes then click on "Save Vendors" to update the Vendors',
        'view' => 'View Selected Vendors'
    );

    protected function _getForm() {
        $form = new Form_Vendors();
        return $form;
    }
    
    public function addAction() {
        if (!$this->_add)
            $this->forward('list');
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $form = $this->_getForm();
        if ($form === false)
            throw new Zend_Exception('_getForm not implemented');
        $form->removeVideoElements();
        if ($this->getRequest()->isPost() && $form->isValid($this->getRequest()->getPost())) {
            $request = $this->getRequest()->getPost();
            $form->removeOptionalElements();
            $dataSave = $form->getValues();
            
            $accreditorsArr = $request['accreditor_id'];
            if(!empty($accreditorsArr) && count($accreditorsArr) > 3) {
                $this->view->message = "Max 3 accreditors allowed";
                $this->view->success = false;
                $this->view->form = $form;
                return false;
            }
            
            $companyArr = $request['company'];
            if(!empty($companyArr) && count($companyArr) > 5) {
                $this->view->message = "Max 5 company allowed";
                $this->view->success = false;
                $this->view->form = $form;
                return false;
            }

            $aluminiArr = $request['alumni'];
            if(!empty($aluminiArr) && count($aluminiArr) > 4) {
                $this->view->message = "Max 4 alumni allowed";
                $this->view->success = false;
                $this->view->form = $form;
                return false;
            }
            $splitData = $this->_handleDataAfterSubmit($request);
            $splitData['video_data'] = array();
            $videoData = array();
            if(!empty($request['videoLink'])) {
                $vData = $form->getVideoData();
                if(!empty($vData) && is_array($vData)){
                $videoData['videoDescription'] = isset($vData['shortDescription']) ? $vData['shortDescription'] : NULL;
                $videoData['dateCreated'] = isset($vData['dateCreated']) ? $vData['dateCreated'] : NULL;
                $videoData['duration'] = isset($vData['duration']) ? $vData['duration'] : NULL;
                $videoData['displayName'] = isset($vData['displayName']) ? $vData['displayName'] : $request['name'];
                }
                $videoData['videoLink'] = $request['videoLink'];
                $videoData['videoThumbnail'] = !empty($request['videoThumbnail']) ? $request['videoThumbnail']: "";
           
            }

            unset($dataSave['videoLink']);
            unset($dataSave['dateCreated']);
            unset($dataSave['videoThumbnail']);
            unset($dataSave['videoDescription']);
            unset($dataSave['imagePath']);
            unset($dataSave['imageDescription']);
            
            if(!empty($videoData))
                $splitData['video_data'] = $videoData;
            
            unset($dataSave['course_advisor']);
            unset($dataSave['company']);
            unset($dataSave['alumni']);

            $result = false;
            $result = $this->getModel()->createVendor($dataSave,$splitData);
            if (!$result) {
                $this->view->message = "An error has occured while saving";
                $this->view->success = false;
            } else {
                $this->view->message = "Data successfully added";
                $this->view->success = true;
                $form->reset();
                $module  = $this->getRequest()->getModuleName();
                $controller = $this->getRequest()->getControllerName();
                $action = $this->getRequest()->getActionName();
                if($module && $controller && $action)
                    $this->redirect($module.'/'.$controller.'/list');
            }
        }
        $this->view->form = $form;
    }
    
    public function editAction() {
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $id = $this->getRequest()->getParam('id');
        $this->view->vendorId = $this->getRequest()->getParam('id');
        $data = $this->getModel($id);
        if ($data) {
            $this->view->postParams = $data;
            $form = $this->_getForm();
            $form->removeOptionalValidators();
            $form->removeUneditableElements();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            if ($this->getRequest()->isPost() ){
                if($form->isValid($this->getRequest()->getPost())){
                    $request = $this->getRequest()->getPost();
                    $dataSave = $form->getValues();
                    $form->removeOptionalElements();
                    
                    $accreditorsArr = $dataSave['accreditor_id'];
                    if(!empty($accreditorsArr) && count($accreditorsArr) > 3) {
                        $this->view->message = "Max 3 accreditors allowed";
                        $this->view->success = false;
                        $this->view->form = $form;
                        return false;
                    }
                    
                    $companyArr = $dataSave['company'];
                    if(!empty($companyArr) && count($companyArr) > 5) {
                        $this->view->message = "Max 5 company allowed";
                        $this->view->success = false;
                        $this->view->form = $form;
                        return false;
                    }

                    $aluminiArr = $dataSave['alumni'];
                    if(!empty($aluminiArr) && count($aluminiArr) > 4) {
                        $this->view->message = "Max 4 alumni allowed";
                        $this->view->success = false;
                        $this->view->form = $form;
                        return false;
                    }
                    $splitData = $this->_handleDataAfterSubmit($dataSave);
                    $splitData['video_data'] = array();
                    $videoData = array();
                    if (!empty($dataSave['videoLink'])) {
                        $vData = $form->getVideoData();
                        if (!empty($vData) && is_array($vData)) {
                            $videoData['videoDescription'] = isset($vData['shortDescription']) ? $vData['shortDescription'] : NULL;
                            $videoData['dateCreated'] = isset($vData['dateCreated']) ? $vData['dateCreated'] : NULL;
                            $videoData['duration'] = isset($vData['duration']) ? $vData['duration'] : NULL;
                            $videoData['displayName'] = isset($vData['displayName']) ? $vData['displayName'] : $dataSave['name'];
                        }
                        $videoData['videoLink'] = $dataSave['videoLink'];
                        $videoData['videoThumbnail'] = !empty($dataSave['videoThumbnail']) ? $dataSave['videoThumbnail'] : "";
                    }

                    unset($dataSave['videoLink']);
                    unset($dataSave['dateCreated']);
                    unset($dataSave['videoThumbnail']);
                    unset($dataSave['videoDescription']);
                    unset($dataSave['imagePath']);
                    unset($dataSave['imageDescription']);
                    
                    if(!empty($videoData))
                        $splitData['video_data'] = $videoData;
                    
                    unset($dataSave['course_advisor']);
                    unset($dataSave['company']);
                    unset($dataSave['alumni']);

                    $result = $this->getModel()->updateVendor($id,$dataSave,$splitData);
                    if (!$result) {
                        $this->view->message = "An error has occured while saving";
                        $this->view->success = true;
                    } else {
                        $form->reset();
                        $module  = $this->getRequest()->getModuleName();
                        $controller = $this->getRequest()->getControllerName();
                        $action = $this->getRequest()->getActionName();
                        if($module && $controller && $action)
                            $this->redirect($module.'/'.$controller.'/list');
                    }
                }
            }else{
                $vendorData = $data->toArray();
                $imageModel = new Model_Images();
                if($imageData = $imageModel->getByLinkable($id, 'vendor')) {
                    $vendorData['imagePath'] = $imageData['imagePath'];
                    $vendorData['imageDescription'] = $imageData['imageDescription'];
                }

                $objSectionMapping = new Model_SectionMapping();
                $sectionData = $objSectionMapping->getByLinkableIdLinkableType($id,'vendor');
                if(!empty($sectionData)){
                    $vendorData['company'] = isset($sectionData['company']) ? array_column($sectionData['company'], 'section_id') : array();
                    $vendorData['alumni'] = isset($sectionData['alumni']) ? array_column($sectionData['alumni'], 'section_id') : array();
                    $vendorData['course_advisor'] = isset($sectionData['directors']) ? array_column($sectionData['directors'], 'section_id') : array();
                }

                $accreditorMappingObj = new Model_AccreditorMapping();
                $conds = array('linkable_id=?' => $id,'linkable_type=?' => 'vendor');
                $courseAccreditorArr = $accreditorMappingObj->fetchAll($conds);
                if(!empty($courseAccreditorArr)){
                    $accIds = array_column($courseAccreditorArr, 'accreditor_id');
                    $vendorData['accreditor_id']  =  $accIds;
                }

                $modelVideo = new Model_Videos();
                $videoData = $modelVideo->getByLinkableId($id,'vendor', false, 'about_vendor');
                if($videoData) {
                    $seoMd = new Model_Seo();
                    $conds = array(
                            'controller=?' => Model_Videos::SEO_DEFAULT_CONTROLLER,
                            'action=?' => Model_Videos::SEO_DEFAULT_ACTION,
                            'linkable_id=?' => $videoData['video_id'],
                            'linkable_type=?' => 'video'
                    );
                    $seoData = current($seoMd->fetchAll($conds, array(), false));
                    $vendorData['videoLink'] = $videoData['videoLink'];
                    $vendorData['dateCreated'] = $videoData['dateCreated'];
                    $vendorData['videoUrl'] = $seoData['url'];
                    $vendorData['videoThumbnail'] = $seoData['thumb_image'];
                    $vendorData['videoDescription'] = $videoData['shortDescription'];
                }
                $this->view->postParams = $vendorData;
                $form = $this->_getForm();
                $form->removeUneditableElements();
                if ($form === false)
                    throw new Zend_Exception('_getForm not implemented');
                $form->setDefaults($vendorData);
            }
            $this->view->form = $form;
        }
    }

    public function listAction() {
        $this->_helper->viewRenderer->setRender('common/list')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $table = $this->getModel()->getName();
        $filterForm = new Form_Filters($table);
        $requestData = array();
        $queryParamsArr = array();
        $page = '';
        if($this->getRequest()->isPost()){
            $filterForm->populate($this->getRequest()->getPost());
            $page = 1;
            $requestData = $filterForm->getValues();
            foreach($requestData as $elementName => $elementValue) {
                if(!empty($elementValue)){
                    $queryData = $filterForm->getElement($elementName)->getAttrib('data-table');
                    $queryData['searchValue'] = $elementValue;
                    $this->queryBuilder($queryData);
                    $queryParamsArr[$queryData['search_id']] = $elementValue;    
                }
            }
        }
        if(empty($page)){
            $page = $this->view->navigatorPage;
            $page = (int)$this->getRequest()->getParam('page');
        }
        $orderby = $this->getModel()->getPk() . ' DESC';
        if(empty($this->_queryParams)){
            $getData = $this->getRequest()->getQuery();
            unset($getData['page']);
            if(!empty($getData)){
                foreach ($getData as $key => $value) {
                    $queryParamsArr[$key] = $value;
                    $returnData = $filterForm->getSearchFields($key);
                    if(!empty($returnData)){
                        $returnData = $returnData[0];
                        $filterForm->getElement($returnData['searchColumnName'])->setValue($value);
                        $returnData['searchValue'] = $value;
                        $this->queryBuilder($returnData);
                    }
                }
            }
        }
        if ($page <= 1) {
            $this->view->firstpage = true;
            $page = 1;
        } else {
            $this->view->firstpage = false;
        }
        $offset = ($page - 1) * self::ROWS_PER_PAGE;
        $limit = array(self::ROWS_PER_PAGE,$offset);
        $this->view->page = $page;
        $model = $this->getModel();
        $data = $model->fetchAll($this->_queryParams, array('order' => array($orderby), 'limit' => $limit));
        $perPageData = count($data);
        if (count($data) < self::ROWS_PER_PAGE) {
            $this->view->lastpage = true;
        } else {
            $this->view->lastpage = false;
        }
        $total = $model->fetchCount($this->_queryParams);
        $numberOfPages = ceil($total / self::ROWS_PER_PAGE);
        if($page < $numberOfPages){
            $this->view->currentPageRecord = self::ROWS_PER_PAGE * $page;    
        }else{
            $this->view->currentPageRecord = $total;    
        }
        $this->view->diffPageRecord = $this->view->currentPageRecord - self::ROWS_PER_PAGE;
        if(count($data) < self::ROWS_PER_PAGE){
            $this->view->diffPageRecord = $total - count($data);
        }
        $this->view->totalCount = $total;
        $this->view->totalPages = $numberOfPages;
        $this->view->lastPage = $numberOfPages;
        $pk = $model->getPk();
        $objConv = new Model_CourseConversion();
        foreach ($data as $courseKey => &$row) {
            $row['Action'] = "<a href='" . $this->view->url(array('action' => 'view', 'id' => $row[$pk])) . "'>View</a> " ."<a href='" . $this->view->url(array('controller' => 'changelog', 'action' => 'index', 'row' => $row[$pk], 'table' => $table)) . "'>ChangeLog</a> " ."<a href='#' onclick='deleteConfirmShow(\"" . $this->view->url(array('controller' => 'vendor', 'action' => 'delete', 'id' => $row[$pk])) . "\")'>Delete</a> " ."<a href='" . $this->view->url(array('action' => 'edit', 'id' => $row[$pk])) . "'>Edit</a> " ;
        }
        if(isset($data[0])){
            $original = array_keys($data[0]);
        }else{
            $original = array();
        }
        $as = ($this->_displayInDataTable);
        $datatableFilePath = '../../library/BaseApp/Datatable/'.ucfirst($table).'.php';       
        if(file_exists($datatableFilePath)) {
            $dataTableClass = 'BaseApp_Datatable_'.ucfirst($table);               
        }
        else{
            $dataTableClass = 'BaseApp_Datatable_Default';                            
        }
        $dataTable = new $dataTableClass;
        $dataTable->setData($data);
        $this->view->data = $dataTable;
        $this->view->original = $original;
        $this->view->displayInDataTable = $as;
        $this->view->queryParams = http_build_query($queryParamsArr);
        $this->view->form = $filterForm;
        $this->view->navigatorTotal = ceil($total / BACKEND_ROWS_PER_PAGE);
    }

    private function _handleDataAfterSubmit(&$data) {
        $returnData = array(
            'imagePath' => '',
            'imageDescription' => ''
        );
        
        if(isset($data['imagePath'])) {
            $returnData['imagePath'] = $data['imagePath'];
            $returnData['name'] = 'vendor';
            unset($data['imagePath']);
        }
        if(isset($data['imageDescription'])) {
            $returnData['imageDescription'] = $data['imageDescription'];
            unset($data['imageDescription']);
        }
        
        $returnData['section_id_arr'] = array();
        if(isset($data['company'])) {
            $returnData['section_id_arr'][] = $data['company'];
        }   

        if(isset($data['course_advisor'])) {
            $returnData['section_id_arr'][] = $data['course_advisor'];
        }   

        if(isset($data['alumni'])) {
            $returnData['section_id_arr'][] = $data['alumni'];
        }
        
        return $returnData;
    }
}
