<?php
/*
 * Contains the CRUD actions of Workshop table
 *
 */

class Admin_WorkshopController extends BaseApp_Controller_Crud {
    const STR_WORKSHOP_ACTIVE = 'active';
    const STR_WORKSHOP_INACTIVE = 'inactive';
    const STR_WORKSHOP_COMPLETE = 'complete';

    protected $_model = 'Model_Workshop';
    protected $_descriptions = array(
        'list' => 'List of Existing Workshop',
        'index' => 'List of Existing Workshop',
        'add' => 'Add New Workshop',
        'edit' => 'Make the required changes then click on "Save Workshop" to update the Workshop',
        'view' => 'View Selected Workshop',
        'migrate' => 'price migration',
        'delete' => 'to prevent unable to delete error',
        'sold' => 'mark as sold'
    );

    protected function _getForm() {
        $form = new Form_Workshop();
        return $form;
    }

     public function addAction() {
        $form = new Form_Workshop();
        $objWorkshop = new Model_Workshop();
        $request = $this->getRequest()->getPost();
        if ($this->getRequest()->isPost() && $form->isValid($request)) {
            $userDetails = BaseApp_Auth::getLoggedInUserData();
            $emailId = $userDetails['email'];
            $userId = $userDetails['id'];
            $data = $form->getValues();
            if(!$userId)
                throw new BaseApp_Exception('User is Not Logged In Or please logout and login again');
            $data['user_id'] = $userId;
            $data['emailId'] = $emailId;
            if(isset($data['countries'])) {
                $data['country_id'] = $data['countries'];
            }
            unset($data['countries']);
            if(isset($data['webx_session_id'])) {
                $data['webx_session_id'] = preg_replace("/\s+/", "", $data['webx_session_id']);
            }
            if(isset($data['webx_user_id']) && $data['webx_user_id']) {
                if(!$objWorkshop->getWebxPassword($data['webx_user_id'],$data['webx_version_id'])) {
                    $this->view->message = "webx user not added in configuration";
                    $this->view->success = false;
                    $this->view->form = $form;
                    return false;
                }
            }

            // set webx session password
            if($data['training_id'] == BaseApp_Dao_TrainingTypes::TYPE_LVC) {

                $arrWebexRes = $objWorkshop->getWebxSessionPassword($data);
                if (!$arrWebexRes['status']) {
                    
                    // Generate a log entry if empty password
                    if (empty($arrWebexRes['webx_session_pass'])) {
                        $this->_helper->Logger->Log(__METHOD__ . " Password not set for webx session id : ". $data['webx_session_id'], Zend_Log::CRIT);
                    }
                    $this->view->message = $arrWebexRes['msg'];
                    $this->view->success = false;
                    $this->view->form = $form;
                    return false;
                } else {
                    $data['webx_session_pass'] = $arrWebexRes['webx_session_pass'];
                }
            }



            if(!$this->_isPriceExists($request, $message)) {
                $this->view->message = $message;
                $this->view->success = false;
                $this->view->form = $form;
                return false;
            }
            if($this->_isWorkshopExists($request)) {
                $this->view->message = "Workshop already exists";
                $this->view->success = false;
                $this->view->form = $form;
                return false;
            }
            if($data['training_id'] == BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM) {
                $modelCity = new Model_City();
                $data['timeZone'] = $modelCity->getTimeZone($data['city_id']);
                if(!trim($data['timeZone'])) {
                    $modelCountry = new Model_Country();
                    $data['timeZone'] = $modelCountry->getTimeZone($data['country_id']);
                }
                if(!trim($data['timeZone'])) {
                    throw new BaseApp_Exception("time zone missing for country id {$data['country_id']}");
                }
            }
            if(array_key_exists('workshopStatus', $data)){
                if(!empty($data['workshopStatus'])){
                   if($data['workshopStatus'] == self::STR_WORKSHOP_ACTIVE){
                        $data['isSold'] = 0;
                   }else{
                        $data['isSold'] = 1;
                   }
                }
            }
            $result = $objWorkshop->createWorkShop($data);
            if (!$result) {
                $this->view->message = "An error has occured while saving";
                $this->view->success = true;
            } else {

                //getting purge urls
                $purgeUrlData = array();
                $countryIDs = !empty($data['country_id']) ? $data['country_id'] : array();
                if (!empty($data['course_id'])) {
                    $purgeObj = new Helper_PurgeUrl();
                    $extraData = array('countryIds' => $countryIDs);

                    if (isset($data['training_id']) && $data['training_id'] == BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM) {
                        $cityId = isset($data['city_id']) ? $data['city_id'] : null;
                        $countryId = isset($data['country_id']) ? $data['country_id'] : null;
                        $extraData = [
                            'countryIds' => [$countryId],
                            'cityIds' => [$cityId],
                            'isClassroom' => 1,
                        ];
                    }

                    $purgeUrlData = $purgeObj->submitPurgeData('workshop','course',$data['course_id'], $extraData);
                }
                $objCourse = New Model_Courses($data['course_id']);
                $cdnPurgeData = $this->getModel()->buildCdnPurgeData($data['course_id'],'course','New workshop added for Course '.$objCourse->name);
                $objCdn = new Model_CdnPurgeLog();
                if(!empty($cdnPurgeData))
                    $objCdn->InsertCdnPurgeLog($cdnPurgeData);
                $this->view->message = "Saved SuccessFully";
                $this->view->success = false;
                $form->reset();
                $module  = $this->getRequest()->getModuleName();
                $controller = $this->getRequest()->getControllerName();
                $action = $this->getRequest()->getActionName();
                if($module && $controller && $action)
                    $this->redirect($module.'/'.$controller.'/list');
            }
        }
        $this->view->form = $form;
    }

    private function _isPriceExists($request, &$message) {
        $message = "price does not exists for this location";
        $missingLocations = array();
        $modelPricing = new Model_Pricings();
        if($request['training_id'] == BaseApp_Dao_TrainingTypes::TYPE_LVC) {
            $accessObj = new Model_AccessDays();
            $config = Zend_Registry::get('config');
            $passAccessdays = $config->get('ONLINE_CLASSROOM_PASS_ACCESS_DAYS')->toArray();
            $success = true;
            foreach($request['countries'] as $countryId) {
                $passAccessdayIds = $accessObj->getAccessDayIdByDays($passAccessdays, 'ilt');
                $passAccessdayIds = array_keys($passAccessdayIds);
                if(!$modelPricing->getPricingData($countryId, false, false, $request['course_id'], BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS, $passAccessdayIds[0])) {
                    $success = false;
                    $missingLocations[] = $countryId;
                }
            }
            if($missingLocations) {
               $modelCountry = new Model_Country();
               $missingLocations = $modelCountry->getById($missingLocations);
               $message = "price does not exists for countries : ".implode(", ", $missingLocations);
            }
            return $success;
        }
        else if($request['training_id'] == BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM) {
            if($modelPricing->getPricingData($request['country_id'], $request['city_id'], false, $request['course_id'], $request['training_id'], $request['access_day_id'])) {
                return true;
            }
        }
        return false;
    }

    private function _isWorkshopExists($request) {
        return false;
    }

    public function editAction() {
        $Id = $this->getRequest()->getParam('id');
        if(!$Id)
            throw new BaseApp_Exception('Editable item not selected properly');
        $workShopData = $this->getModel()->getByBatchId($Id);
        if (!$workShopData) {
            $workShopData = $this->getModel()->getByWorkshopId($Id);
            if($workShopData['training_id'] != BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM) {
                throw new BaseApp_Exception('Editable item not selected properly');
            }
        }
        else if($workShopData['training_id'] != BaseApp_Dao_TrainingTypes::TYPE_LVC && $workShopData['workshop_id'] != $workShopData['batch_id']) {
                throw new BaseApp_Exception('Editable item not selected properly');
        }
        if (!$workShopData) {
            throw new BaseApp_Exception('Editable item not selected properly');
        }
        $comm = new BaseApp_Communication_Xenia();
        $workshopIds = explode(',',$workShopData['workshop_id']);
        foreach ($workshopIds as $key => $value) {
            $xeniaData = $comm->checkWorkShopAttende($value);
            if(!empty($xeniaData)){
                if($xeniaData['status'] == "success"){
                        $this->view->message = "Cannot edit this workshop as it is attended by user";
                        $this->view->success = false;
                        return false;
                }
            }
        }
        $reduceDateNAllow = false;
        if(!empty($workShopData['dates'])){
            $dates = explode(',', $workShopData['dates']);
            if(!empty($dates[0]) && $dates[0] < date('Y-m-d')){
                $reduceDateNAllow = true;
            }
        }
        $form = new Form_Workshop($workShopData['country_id'], $workShopData['city_id'], $workShopData['training_id']);
        if ($this->getRequest()->isPost()) {
            $form->removeUneditableElements($workShopData['training_id']);
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            if ($form->isValid($this->getRequest()->getPost())) {
                //$form->removeOptionalElements();
                $data = $form->getValues();
                //prd($data);
                $maxHeadCountOld =  !empty($workShopData['maxHeadCount']) ? $workShopData['maxHeadCount'] : 0;
                $isSold =  !empty($workShopData['isSold']) ? $workShopData['isSold'] : 0;
                $maxHeadCountNew =  !empty($data['maxHeadCount']) ? $data['maxHeadCount'] : 0;
                if(($maxHeadCountNew > $maxHeadCountOld)&& !empty($isSold)){
                    $data['isSold'] = 0;
                }
                $objAccessDays = new Model_AccessDays();
                $dataAD = $objAccessDays->getAccessDaysById('ilt');
                if($reduceDateNAllow && $dataAD[$data['access_day_id']] < $dataAD[$workShopData['access_day_id']]){
                    $this->view->message = "Cannot reduce workshop days as workshop has already started";
                    $this->view->success = false;
                    return false;
                }
                unset($data['country_id']);
                unset($data['city_id']);
                unset($data['venue_id']);
                if(isset($data['countries'])) {
                    $data['country_id'] = $data['countries'];
                    unset($data['countries']);
                }
                $workShopData['countries'] = array();
                if(isset($data['country_id'])) {
                    $workShopData['countries'] = $data['country_id'];
                }
                if(isset($data['webx_session_id'])) {
                    $data['webx_session_id'] = preg_replace("/\s+/", "", $data['webx_session_id']);
                }
                if(isset($data['webx_user_id']) && $data['webx_user_id']) {
                    if(!$this->getModel()->getWebxPassword($data['webx_user_id'],$data['webx_version_id'])) {
                        $this->view->message = "webx user not added in configuration";
                        $this->view->success = false;
                        $this->view->form = $form;
                        return false;
                    }
                }

                // set webx session password
                if($workShopData['training_id'] == BaseApp_Dao_TrainingTypes::TYPE_LVC) {
                    $arrWebexRes = (new Model_Workshop())->getWebxSessionPassword($data);
                    if (!$arrWebexRes['status']) {
                        $this->view->message = $arrWebexRes['msg'];
                        $this->view->success = false;
                        $this->view->form = $form;
                        return false;
                    } else {
                        $data['webx_session_pass'] = $arrWebexRes['webx_session_pass'];
                    }
                }

                if(!$this->_isPriceExists($workShopData, $message)) {
                    $this->view->message = $message;
                    $this->view->success = false;
                    $form->setDefaults($workShopData);
                    $this->view->form = $form;
                    return false;
                }
                foreach($data as $field => $value) {
                    if($value === null || $value === "") {
                        unset($data[$field]);
                    }
                }
                if($workShopData['training_id'] == BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM) {
                    $result = $this->getModel()->updateWorkShopById($Id, $data);
                }
                else {
                    $result = $this->getModel()->updateWorkShopByBatchId($Id, $data);
                }
                if (!$result) {
                    $this->view->message = "An error has occured while saving";
                    $this->view->success = true;
                    $module  = $this->getRequest()->getModuleName();
                    $controller = $this->getRequest()->getControllerName();
                    $action = $this->getRequest()->getActionName();
                    if($module && $controller && $action)
                        $this->redirect($module.'/'.$controller.'/'.$action.'/id/'.$Id);
                } else {

                    //getting purge urls
                    $purgeUrlData = array();
                    $countryIDs = !empty($workShopData['countries']) ? $workShopData['countries'] : array();
                    if (!empty($workShopData['course_id'])) {
                        $purgeObj = new Helper_PurgeUrl();
                        $extraData = array('countryIds' => $countryIDs);

                        if (isset($workShopData['training_id']) && $workShopData['training_id'] == BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM) {
                            $cityId = isset($workShopData['city_id']) ? $workShopData['city_id'] : null;
                            $countryId = isset($workShopData['country_id']) ? $workShopData['country_id'] : null;
                            $extraData = [
                                'countryIds' => [$countryId],
                                'cityIds' => [$cityId],
                                'isClassroom' => 1,
                            ];
                        }

                        $purgeUrlData = $purgeObj->submitPurgeData('workshop','course',$workShopData['course_id'], $extraData);
                    }
                    $objCourse = New Model_Courses($workShopData['course_id']);
                    $cdnPurgeData = $this->getModel()->buildCdnPurgeData($workShopData['course_id'],'course','workshop Got Modified for Course '.$objCourse->name);
                    $objCdn = new Model_CdnPurgeLog();
                    if(!empty($cdnPurgeData))
                        $objCdn->InsertCdnPurgeLog($cdnPurgeData);
                    $this->view->message = "Saved SuccessFully";
                    $this->view->success = false;
                    if(array_key_exists('dates_edit', $data) && !empty($data['dates_edit'])){
                        $userDetails = BaseApp_Auth::getLoggedInUserData();
                        $apiParams = array();
                        $workshopIds = explode(',',$workShopData['workshop_id']);
                        foreach ($workshopIds as $key => $value) {
                            $apiParams[$value] = $data['dates_edit'];
                            try{
                                $res = $comm->updateWorkshopDatesById($apiParams,$userDetails['id']);
                            }catch (Exception $e){
                                // catching any exception so that it will not affect other workshop Id's
                            }
                        }
                    }
                    $form->reset();
                    $module  = $this->getRequest()->getModuleName();
                    $controller = $this->getRequest()->getControllerName();
                    $action = $this->getRequest()->getActionName();
                    if($module && $controller && $action)
                        $this->redirect($module.'/'.$controller.'/list');
                }
            }
            else {
                $form->setDefaults($workShopData);
                $form->removeUneditableElements($workShopData['training_id']);
            }
        }
        else {
            $workShopData['dates_edit'] = $workShopData['dates'];
            $form->setDefaults($workShopData);
            $form->removeUneditableElements($workShopData['training_id']);
        }
        $this->view->form = $form;
    }

    /* delete function Calls an Api to check whether Payment Exists against it */
     public function deleteAction(){
        $form = new Form_Workshop();
        $Id = $this->getRequest()->getParam('id');
        if(!$Id)
            throw new BaseApp_Exception('Editable item not selected properly');
        $workShopData = $this->getModel()->getByWorkshopId($Id);
        if(empty($workShopData))
            throw new BaseApp_Exception('No Workshop exists');
        $comm = new BaseApp_Communication_Xenia();
        $xeniaData = $comm->checkWorkShopPayment($Id);
        if(!empty($xeniaData)){
            if($xeniaData['status'] == "success"){
                $deleteFlag = $xeniaData['data']['deleteFlag'];
                if(false === $deleteFlag){
                    $this->view->message = "Cannot Delete..There exists a Payment Against this workshopId";
                    $this->view->success = false;
                    $this->view->form = $form;
                    return false;
                }
            }
        }
        $data['status'] = 0;
        $result = $this->getModel()->updateWorkShopById($Id, $data);
        if (!$result) {
            $this->view->message = "An error has occured while saving";
            $this->view->success = true;
            $module  = $this->getRequest()->getModuleName();
            $controller = $this->getRequest()->getControllerName();
            $action = $this->getRequest()->getActionName();
            if($module && $controller && $action)
                $this->redirect($module.'/'.$controller.'/'.$action.'/id/'.$Id);
        } else {
            $objCourse = New Model_Courses($workShopData['course_id']);
            $cdnPurgeData = $this->getModel()->buildCdnPurgeData($workShopData['course_id'],'course','workshop Got Deleted for Course '.$objCourse->name);
            $objCdn = new Model_CdnPurgeLog();
            if(!empty($cdnPurgeData))
                $objCdn->InsertCdnPurgeLog($cdnPurgeData);
            $this->view->message = "Saved SuccessFully";
            $this->view->success = false;
            $form->reset();
            $module  = $this->getRequest()->getModuleName();
            $controller = $this->getRequest()->getControllerName();
            $action = $this->getRequest()->getActionName();
            if($module && $controller && $action)
                $this->redirect($module.'/'.$controller.'/list');
        }
    }

    public function listAction() {
        $this->_helper->viewRenderer->setRender('common/list')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $page = $this->view->navigatorPage;
        $table = $this->getModel()->getName();
        $filterForm = new Form_Filters($table);
        $requestData = array();
        $queryParamsArr = array();
        $page = '';
        if($this->getRequest()->isPost()){
            $filterForm->populate($this->getRequest()->getPost());
            $page = 1;
            $requestData = $filterForm->getValues();
            foreach($requestData as $elementName => $elementValue) {
                if(!empty($elementValue)){
                    $queryData = $filterForm->getElement($elementName)->getAttrib('data-table');
                    $queryData['searchValue'] = $elementValue;
                    $this->queryBuilder($queryData);
                    $queryParamsArr[$queryData['search_id']] = $elementValue;
                } // end of !empty elementValue
            } // end of foreach RequestData
        } // end of if isPost
        $orderby = $this->getModel()->getPk() . ' DESC';
        if(empty($page)){
            $page = $this->view->navigatorPage;
            $page = (int)$this->getRequest()->getParam('page');
        }
        if(empty($this->_queryParams)){
            $getData = $this->getRequest()->getQuery();
            unset($getData['page']);
            if(!empty($getData)){
                foreach ($getData as $key => $value) {
                    $queryParamsArr[$key] = $value;
                    $returnData = $filterForm->getSearchFields($key);
                    if(!empty($returnData)){
                        $returnData = $returnData[0];
                        $filterForm->getElement($returnData['searchColumnName'])->setValue($value);
                        $returnData['searchValue'] = $value;
                        $this->queryBuilder($returnData);
                    }
                }
            }
        }
        if ($page <= 1) {
            $this->view->firstpage = true;
            $page = 1;
        } else {
            $this->view->firstpage = false;
        }
        $offset = ($page - 1) * self::ROWS_PER_PAGE;
        $limit = array(self::ROWS_PER_PAGE,$offset);
        $this->view->page = $page;
        $model = $this->getModel();
        $data = $model->fetchAll($this->_queryParams, array('order' => array($orderby), 'limit' => $limit));
        $perPageData = count($data);
        $total = $model->fetchCount($this->_queryParams);
        if (count($data) < self::ROWS_PER_PAGE) {
            $this->view->lastpage = true;
        } else {
            $this->view->lastpage = false;
        }

        $numberOfPages = ceil($total / self::ROWS_PER_PAGE);
        if($page < $numberOfPages){
            $this->view->currentPageRecord = self::ROWS_PER_PAGE * $page;
        }else{
            $this->view->currentPageRecord = $total;
        }
        $this->view->diffPageRecord = $this->view->currentPageRecord - self::ROWS_PER_PAGE;
        if(count($data) < self::ROWS_PER_PAGE){
            $this->view->diffPageRecord = $total - count($data);
        }
        $this->view->totalCount = $total;
        $this->view->totalPages = $numberOfPages;
        $this->view->lastPage = $numberOfPages;

        $total = $model->fetchCount();
        $table = $this->getModel()->getName();
        //@TODO: Remove from controller and create an action helper.

        foreach ($data as &$row) {
            $idToEdit = false;
            if($row['training_id'] == 1) {
                $idToEdit = $row['workshop_id'];
            }
            else {
                $idToEdit = $row['batch_id'];
            }
            $str = "<a href='" . $this->view->url(array('action' => 'view', 'id' => $row['workshop_id'])) . "'>View</a> " .
                   "<a href='" . $this->view->url(array('controller' => 'changelog', 'action' => 'index', 'row' => $row['workshop_id'], 'table' => $table)) . "'>ChangeLog</a> ".
                   "<a href='" . $this->view->url(array('action' => 'edit', 'id' => $idToEdit)) . "'>Edit</a> ";
            if(!$row['isSold']){
                $str =  $str."<a class='delete-crud-item' href='#' onclick='deleteConfirmShow(\"" . $this->view->url(array('action' => 'delete', 'id' => $row['workshop_id'])) . "\");'>Delete</a> ";
                $currentDate = date("Y-m-d");
                
                // EDIT : Modifying the below condition to show is sold option for workshops with type classroom only
                if((!empty($row['endDate']) && $row['endDate'] >= $currentDate) && $row['training_id'] == 1)
                    $str =  $str."<a href='" . $this->view->url(array('action' => 'sold', 'id' =>  $row['batch_id'])) . "'>MarkSold</a> ";
            }
            $row['Action'] = $str;
        }
        //================
        if(isset($data[0])){
            $original = array_keys($data[0]);
        }else{
            $original = array();
        }
        $as = ($this->_displayInDataTable);
        //new datatable
        //need to define path in ini file after discussion
        $datatableFilePath = '../../library/BaseApp/Datatable/'.ucfirst($table).'.php';
        if(file_exists($datatableFilePath)) {
            $dataTableClass = 'BaseApp_Datatable_'.ucfirst($table);
        }
        else{
            $dataTableClass = 'BaseApp_Datatable_Default';
        }
        $dataTable = new $dataTableClass;
        $dataTable->setData($data);
        $this->view->queryParams = http_build_query($queryParamsArr);
        $this->view->form = $filterForm;
        $this->view->data = $dataTable;
        $this->view->original = $original;
        $this->view->displayInDataTable = $as;
        $this->view->navigatorTotal = ceil($total / BACKEND_ROWS_PER_PAGE);
    }

    public function soldAction(){
        $form = new Form_Workshop();
        $Id = $this->getRequest()->getParam('id');
        if(!$Id)
            throw new BaseApp_Exception('Editable item not selected properly');
        $workShopData = $this->getModel()->getByBatchId($Id);
        if(empty($workShopData))
            throw new BaseApp_Exception('No Workshop exists');
        $data['isSold'] = 1;
        $result = $this->getModel()->markWorkshop($Id, $data);
        if (!$result) {
            $this->view->message = "An error has occured while saving";
            $this->view->success = true;
            $module  = $this->getRequest()->getModuleName();
            $controller = $this->getRequest()->getControllerName();
            $action = $this->getRequest()->getActionName();
            if($module && $controller && $action)
            $this->redirect($module.'/'.$controller.'/'.$action.'/id/'.$Id);
        }else{
            $objCourse = New Model_Courses($workShopData['course_id']);
            $cdnPurgeData = $this->getModel()->buildCdnPurgeData($workShopData['course_id'],'course','workshop Got Marked as Sold for Course '.$objCourse->name);
            //getting purge urls
            $purgeUrlData = array();
            $countryIDs = array();
            $countryIDs = !empty($workShopData['countries']) ? $workShopData['countries'] : '';
            if (!empty($workShopData['course_id'])) {
                $purgeObj = new Helper_PurgeUrl();
                $extraData = array('countryIds' => $countryIDs);

                if (isset($workShopData['training_id']) && $workShopData['training_id'] == BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM) {
                    $cityId = isset($workShopData['city_id']) ? $workShopData['city_id'] : null;
                    $countryId = isset($workShopData['country_id']) ? $workShopData['country_id'] : null;
                    $extraData = [
                        'countryIds' => [$countryId],
                        'cityIds' => [$cityId],
                        'isClassroom' => 1,
                    ];
                }

                $purgeUrlData = $purgeObj->submitPurgeData('workshop','course',$workShopData['course_id'], $extraData);
            }
            $objCdn = new Model_CdnPurgeLog();
            if(!empty($cdnPurgeData))
                $objCdn->InsertCdnPurgeLog($cdnPurgeData);
            $this->view->message = "Saved SuccessFully";
            $this->view->success = false;
            $form->reset();
            $module  = $this->getRequest()->getModuleName();
            $controller = $this->getRequest()->getControllerName();
            $action = $this->getRequest()->getActionName();
            if($module && $controller && $action)
                $this->redirect($module.'/'.$controller.'/list');
        }
    }
}
