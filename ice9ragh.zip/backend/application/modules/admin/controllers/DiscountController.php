<?php
/*
 * Contains the CRUD actions of Discounts table
 * 
 */

class Admin_DiscountController extends BaseApp_Controller_Crud {
    protected $_model = 'Model_Discounts';
    protected $_descriptions = array(
        'list' => 'List of Existing Discounts',
        'index' => 'List of Existing Discounts',
        'add' => 'Add New Discounts',
        'edit' => 'Make the required changes then click on "Save Discounts" to update the Discounts',
        'view' => 'View Selected Discounts'
    );

    protected function _getForm() {
        $form = new Form_Discounts();
        return $form;
    }
}
