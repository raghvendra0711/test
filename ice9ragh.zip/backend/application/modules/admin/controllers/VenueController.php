<?php
/*
 * Contains the CRUD actions of Venues table
 * 
 */

class Admin_VenueController extends BaseApp_Controller_Crud {
    protected $_model = 'Model_Venues';
    protected $_descriptions = array(
        'list' => 'List of Existing Venues',
        'index' => 'List of Existing Venues',
        'add' => 'Add New Venues',
        'edit' => 'Make the required changes then click on "Save Venues" to update the Venues',
        'view' => 'View Selected Venues'
    );

    protected function _getForm() {
        $form = new Form_Venues();
        return $form;
    }
    
    public function editAction() {
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $id = $this->getRequest()->getParam('id');
        $data = $this->getModel($id);        
        if ($data) {
            $this->view->postParams = $data;
            $form = $this->_getForm();
            $form->removeOptionalValidators();
            $form->removeUneditableElements();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            if ($this->getRequest()->isPost() && $form->isValid($this->getRequest()->getPost())) {
                $form->removeOptionalElements();
                $result = $data->setFromArray($form->getValues())->update();
                if (!$result) {
                    $this->view->message = "An error has occured while saving";
                    $this->view->success = true;
                } else {
                    // for making message page specific
                    $this->view->message = ucwords($this->getRequest()->getControllerName())." Data successfully updated";
                    $this->view->success = false;
                }
                //$this->forward('list');
            }
            $form->setDefaults($data->toArray());
            if($data->country_id) {
                $objCity = new Model_City();
                $cities = $objCity->fetchforSelect(array('country_id =?'=> intval($data->country_id)));
            }
            $form->getElement('city_id')->setAttrib('options', $cities);
            $this->view->form = $form;
        }
    }
}
