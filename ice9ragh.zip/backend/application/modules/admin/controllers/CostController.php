<?php

/*
 * CRUD for Product_Cost
 * 
 */

class Admin_CostController extends BaseApp_Controller_Crud {

    protected $_cost_type = array(
        'price_type_fixed' => 1,
        'price_type_shared' => 2
    );
    protected $_columns = array('id', 'course_id');
    public $priceData = '';
    protected $_model = 'Model_Cost';
    protected $_descriptions = array(
        'list' => 'List of Existing Cost data',
        'index' => 'List of Existing Cost data',
        'add' => 'Add New Cost data',
        'edit' => 'Make the required changes then click on "Save" to update the Cost data',
        'view' => 'View Selected Cost data',
        'search' => 'search Selected Cost data'
    );
    const  EXAM_TABLE_ID = 1;

    public function init() {
        parent::init();
        $this->__getAllCourses();
    }

    private function __getAllCourses() {
        $courseModelObj = new Model_Courses();
        $courseListWithCityPage = $courseModelObj->fetchForSelect(array('is_dummy = ?' => 0, 'is_free = ?' => 0));
        $this->view->coursesWithCitPage = $courseListWithCityPage;
    }

    public function viewAction() {
        $courseId = $this->getRequest()->getParam('id');
        $trainingObj = new BaseApp_Dao_Courses();
        $training_types = $trainingObj->getTrainingTypes($courseId);
        $objPricing = new Model_Pricings();
        $priceData = $objPricing->fetchAll(array('course_id =?' => $courseId, 'training_id <> ?' => 3), array('order' => array('training_id DESC')));
        $productCostObj = new Model_Cost();
        $costDataOld = $productCostObj->getDataByCourseId($courseId);
        $courseDetainsIdMappingData = $this->_processDataDisplay($priceData);
        $costLabelMapping = new Model_CostLableMapping();
        $costMappingData = $costLabelMapping->getMappingData($training_types);
        $costData = $this->_processCourseData($costMappingData, $priceData, $costDataOld);
        $this->setSessionData($costData, 'costData');
        $courseObj = new Model_Courses();
        $courseName = $courseObj->getNameById($courseId);
        $this->view->costMappingData = !empty($costData) ? $costData : array();
        $this->view->courseId = $courseId;
        $this->view->courseDetainsIdMappingData = $courseDetainsIdMappingData;
    }

    protected function _getForm($paramsArr = array()) {
        $form = new Form_Cost($paramsArr);
        return $form;
    }

    public function courseLabelMappingAction() {

        $courseId = $this->getRequest()->getParam('primary_course_id');
        $trainingObj = new BaseApp_Dao_Courses();
        $training_types = $trainingObj->getTrainingTypes($courseId);
        $objPricing = new Model_Pricings();
        $priceData = $objPricing->fetchAll(array('course_id =?' => $courseId, 'training_id <> ?' => 3), array('order' => array('training_id DESC')));
        $courseDetainsIdMappingData = $this->_processDataDisplay($priceData);
        $costLabelMapping = new Model_CostLableMapping();
        $costMappingData = $costLabelMapping->getMappingData($training_types);
        $costData = $this->_processCourseData($costMappingData, $priceData);
        $this->setSessionData($costData, 'costData');
        $courseObj = new Model_Courses();
        $courseName = $courseObj->getNameById($courseId);
        $this->view->costMappingData = !empty($costData) ? $costData : array();
        $this->view->courseId = $courseId;
        $this->view->courseDetainsIdMappingData = $courseDetainsIdMappingData;
        $this->view->examTableId = self::EXAM_TABLE_ID;
    }

    private function _processCourseData($costMappingData, $priceData, $costData = array()) {
        $examCost = array();
        $affiliateCost = array();
        $trainerCost = array();
        $partner = array();
        $i = 0;
        $processedList = array();
        if (!empty($priceData)) {
            $courseId = current(array_column($priceData,'course_id'));
            $costTableTextMdl = new Model_CostTableText();
            $examDetails = $costTableTextMdl->getExamDetailByCourseId($courseId, self::EXAM_TABLE_ID);
            if (!empty($examDetails)) {
                foreach ($examDetails as $key => $exam) {
                    if (empty($exam['name'])) {
                        unset($examDetails[$key]);
                    }
                }
            }
            foreach ($priceData as $key => $price) {
                unset($price['type']);
                unset($price['allLocation']);
                unset($price['course_inclusion_id']);
                unset($price['discount']);
                unset($price['minPrice']);
                foreach ($costMappingData as &$costMap) {
                    //pr($price); pr($costMap);
                    $examNewPrice = array();
                    $costLabelId = $costMap['id'];
                    if (empty($processedList[$costLabelId])) {
                        $processedList[$costLabelId] = array();
                    }

                    $distinctKey = array();
                    //(!empty($price['training_id']) ? $price['training_id'] : '0');
                    $distinctKey[] = (!empty($costMap['cluster_id'])) ? (!empty($price['cluster_id']) ? $price['cluster_id'] : '0') : '0';
                    $distinctKey[] = (!empty($costMap['country_id'])) ? (!empty($price['country_id']) ? $price['country_id'] : '0') : '0';
                    $distinctKey[] = (!empty($costMap['access_day_id'])) ? (!empty($price['access_day_id']) ? $price['access_day_id'] : '0') : '0';
                    $distinctKey[] = (!empty($costMap['training_id'])) ? (!empty($price['training_id']) ? $price['training_id'] : '0') : '0';

                    $distinctKeyValue = implode('#', $distinctKey);
                    if (empty($processedList[$costLabelId][$distinctKeyValue])) {
                        $processedList[$costLabelId][$distinctKeyValue] = 1;

                        $isAdd = false;
                        if (empty($costMap['training_id'])) {
                            // Independent of training type 
                            $price['training'] = "OSL/LVC";
                            if ($price['training_id'] == 2 || $price['training_id'] == 9) {
                                $isAdd = true;
                            }
                        } else {
                            if ($costMap['class_room'] == 1 && $price['training_id'] == 1) {
                                $price['training'] = "Classroom";
                                $isAdd = true;
                            } else if ($costMap['lvc'] == 1 && $price['training_id'] == 9) {
                                $price['training'] = "Flexi Pass";
                                $isAdd = true;
                            } else if ($costMap['osl'] == 1 && $price['training_id'] == 2) {
                                $price['training'] = "OSL";
                                $isAdd = true;
                            }
                        }

                        $labelId = $costMap['id'];

                        if ($isAdd) {
                            // edit action
                            if (!empty($costData)) {
                                foreach ($costData as $key => $val) {
                                    $costTextId = !empty($val['cost_text_id'])?$val['cost_text_id']:0;
                                    $distinctPriceKeyValue = $distinctKeyValue . "#" . $labelId."#".$costTextId;
                                    $costLabelMapping = new Model_CostLableMapping();
                                    $costMaperArray = $costLabelMapping->fetchAll(array('id =?' => $val['cost_lable_id']));
                                    $costMaper = $costMaperArray['0'];
                                    $distinctEditKey = array();
                                    //(!empty($price['training_id']) ? $price['training_id'] : '0');
                                    $distinctEditKey[] = (!empty($costMaper['cluster_id'])) ? (!empty($val['cluster_id']) ? $val['cluster_id'] : '0') : '0';
                                    $distinctEditKey[] = (!empty($costMaper['country_id'])) ? (!empty($val['country_id']) ? $val['country_id'] : '0') : '0';
                                    $distinctEditKey[] = (!empty($costMaper['access_day_id'])) ? (!empty($val['access_day_id']) ? $val['access_day_id'] : '0') : '0';
                                    $distinctEditKey[] = (!empty($costMaper['training_id'])) ? (!empty($val['training_id']) ? $val['training_id'] : '0') : '0';
                                    $distinctEditKey[] = $val['cost_lable_id'];
                                    $distinctEditKey[] = $costTextId;
                                    $distinctEditKey = implode('#', $distinctEditKey);
                                    $newPrice=array();
                                    if ($distinctPriceKeyValue == $distinctEditKey) {
                                        if ($labelId == self::EXAM_TABLE_ID) {
                                            if (!empty($examDetails)) {//Do not move in upper if
                                                foreach ($examDetails as $exam) {
                                                    if ($val['cost_text_id'] == $exam['id']) {
                                                        $newPrice['cost'] = !empty($val['cost']) ? $val['cost'] : 0;
                                                        $newPrice['cost_type'] = !empty($val['cost_type']) ? $val['cost_type'] : 0;
                                                        $newPrice['currency_symbol_id'] = !empty($val['currency_symbol_id']) ? $val['currency_symbol_id'] : 0;
                                                        $newPrice['id'] = !empty($val['id']) ? $val['id'] : 0;
                                                        $newPrice['validity'] = !empty($val['validity']) ? $val['validity'] : 0;
                                                        $newPrice['bundle_validity'] = !empty($val['bundle_validity']) ? $val['bundle_validity'] : 0;
                                                        $examNewPrice[$val['cost_text_id']] = array_merge($price, $newPrice);
                                                    }
                                                }
                                            }
                                        } else {
                                            $newPrice['cost'] = !empty($val['cost']) ? $val['cost'] : 0;
                                            $newPrice['cost_type'] = !empty($val['cost_type']) ? $val['cost_type'] : 0;
                                            $newPrice['currency_symbol_id'] = !empty($val['currency_symbol_id']) ? $val['currency_symbol_id'] : 0;
                                            $newPrice['id'] = !empty($val['id']) ? $val['id'] : 0;
                                            $newPrice['validity'] = !empty($val['validity']) ? $val['validity'] : 0;
                                            $newPrice['bundle_validity'] = !empty($val['bundle_validity']) ? $val['bundle_validity'] : 0;
                                            $newPrice = array_merge($price, $newPrice);
                                            /*
                                              $price['cost'] = $val['cost'];
                                              $price['cost_type'] = $val['cost_type'];
                                              $price['currency_symbol_id'] = $val['currency_symbol_id'];
                                              $price['id'] = $val['id'];
                                              $price['validity'] = !empty($val['validity']) ? $val['validity'] : 0 ;
                                              $price['bundle_validity'] = !empty($val['bundle_validity']) ?$val['bundle_validity'] : 0 ;
                                             */
                                            break;
                                        }
                                    }
                                }
                                if ($labelId == self::EXAM_TABLE_ID) {
                                    if (!empty($examDetails)) {//Do not move in upper if
                                        foreach ($examDetails as $exam) {
                                            $costMap[$costMap['name']][$exam['id']][] = !empty($examNewPrice[$exam['id']]) ? $examNewPrice[$exam['id']] : $price;
                                        }
                                    }
                                } else {
                                    $costMap[$costMap['name']][0][] = !empty($newPrice) ? $newPrice : $price;
                                }
                                //$costMap[$costMap['name']][] = $price;
                            } else {
                                // add action
                                if ($labelId == self::EXAM_TABLE_ID) {
                                    if (!empty($examDetails)) {//Do not move in upper if
                                        foreach ($examDetails as $exam) {
                                            $costMap[$costMap['name']][$exam['id']][] = !empty($examNewPrice[$exam['id']]) ? $examNewPrice[$exam['id']] : $price;
                                        }
                                    }
                                } else {
                                    $costMap[$costMap['name']][0][] = !empty($newPrice) ? $newPrice : $price;
                                }
                            }
                        }
                        // Add in the resutant bucket    
                    }
                }
            }
        }
        return $costMappingData;
    }

    private function _processDataDisplay($priceData) {
        $dataFetch = array(
            'course_id' => array(),
            'access_day_id' => array(),
            'cluster_id' => array(),
            'country_id' => array(),
            'city_id' => array(),
            'training_id' => array()
        );
        foreach ($priceData as $priceDataSingle) {

            foreach ($dataFetch as $fieldName => $fieldData) {
                if (isset($priceDataSingle[$fieldName]) && $priceDataSingle[$fieldName]) {
                    $dataFetch[$fieldName][] = $priceDataSingle[$fieldName];
                }
            }
        }

        $forCurrency = array(
            'countries' => array(),
            'clusters' => array()
        );
        foreach ($dataFetch as $fieldName => $fieldData) {
            if (!$fieldData) {
                continue;
            }
            $fieldData = array_unique($fieldData);
            switch ($fieldName) {
                case 'course_id':
                    $modelCourses = new Model_Courses();

                    $dataFetch[$fieldName] = $modelCourses->getCourseByIdMultiple($fieldData);
                    break;
                case 'training_id':
                    $modelTraining = new Model_TrainingTypes();
                    $dataFetch[$fieldName] = $modelTraining->getTrainingTypes();
                    break;
                case 'access_day_id':
                    $access = new Model_AccessDays();
                    $dataFetch[$fieldName] = $access->getAccessDaysById(false, true);
                    break;
                case 'cluster_id':
                    $cluster = new Model_Clusters();
                    $dataFetch[$fieldName] = $cluster->getListDisplay($fieldData);
                    $forCurrency['clusters'] = $cluster->getCurrencies($fieldData);
                    break;
                case 'country_id':
                    $country = new Model_Country();
                    $dataFetch[$fieldName] = $country->getById($fieldData);
                    $forCurrency['countries'] = $country->getCurrencies($fieldData);
                    break;
                case 'city_id':
                    $city = new Model_City();
                    $dataFetch[$fieldName] = array();
                    if ($fieldData) {
                        $dataFetch[$fieldName] = $city->getNameById($fieldData);
                    }
                    break;
            }
        }
        return $dataFetch;
    }

    public function searchAction() {
        $form = new Form_CostSearch();
        if ($form === false)
            throw new Zend_Exception('_getForm not implemented');
        $request = $this->getRequest()->getPost();
        if ($this->getRequest()->isPost()) {

            if (!empty($request['primary_course_id'])) {
                $courseId = $request['primary_course_id'];
                $this->setSessionData($courseId, 'course_id');
            }
            if (isset($request['search'])) {
                if ($form->isValid($request)) {
                    $productCostObj = new Model_Cost();
                    $courseId = $this->getRequest()->getParam('primary_course_id');
                    $costDataOld = $productCostObj->getDataByCourseId($courseId);
                    if (!empty($costDataOld)) {
                        return $this->_redirect('/admin/cost/edit');
                    }
                    return $this->_forward('course-label-mapping');
                }
            } elseif (isset($request['submit']) && $request['submit'] == 'Save') {
                if ($form->isValid($request)) {
                    $courseId = $this->getSessionData('course_id');
                    unset($request['submit']);
                    $costData = $request;
                    $costDataSave = array();
                    $keyPrefixArray = array();

                    $i = 0;
                    if (!empty($costData)) {
                        foreach ($costData as $key => $value) {
                            $keyPrefixTemp = substr($key, 0, strpos($key, "_"));
                            $keyLables = str_replace($keyPrefixTemp . "_", "", $key);
                            if ($i == 0) {
                                $keyPrefix = $keyPrefixTemp;
                                array_push($keyPrefixArray, $keyPrefixTemp);
                            }
                            if ($keyPrefix == $keyPrefixTemp) {
                                $costDataSave[$keyPrefixTemp][$keyLables] = $value;
                            } else {
                                $keyPrefix = $keyPrefixTemp;
                                $costDataSave[$keyPrefixTemp][$keyLables] = $value;
                                array_push($keyPrefixArray, $keyPrefixTemp);
                            }
                            $i++;
                        }
                    }
                    if (!empty($keyPrefixArray)) {
                        foreach ($keyPrefixArray as $key => $value) {
                            $costLabelMapping = new Model_CostLableMapping();
                            $productCostObj = new Model_Cost();
                            $costMappingData = $costLabelMapping->getCostLabelId($value);
                            if (!empty($costMappingData))
                                $result = $productCostObj->saveCostData($costDataSave[$value], $courseId, $costMappingData);
                        }
                    }
                    $module = $this->getRequest()->getModuleName();
                    $controller = $this->getRequest()->getControllerName();
                    if ($module && $controller)
                        $this->redirect($module . '/' . $controller . '/list');
                }
            }
        }
        $form->setDefaults($request);
        $this->view->form = $form;
    }

    public function editAction() {
        $courseId = $this->getRequest()->getParam('id');
        if (empty($courseId)) {
            $courseId = $this->getSessionData('course_id');
        }
        $trainingObj = new BaseApp_Dao_Courses();
        $training_types = $trainingObj->getTrainingTypes($courseId);
        $objPricing = new Model_Pricings();
        $priceData = $objPricing->fetchAll(array('course_id =?' => $courseId, 'training_id <> ?' => 3), array('order' => array('training_id DESC')));
        $productCostObj = new Model_Cost();
        $costDataOld = $productCostObj->getDataByCourseId($courseId);
        $courseDetainsIdMappingData = $this->_processDataDisplay($priceData);
        $costLabelMapping = new Model_CostLableMapping();
        $costMappingData = $costLabelMapping->getMappingData($training_types);
        $costData = $this->_processCourseData($costMappingData, $priceData, $costDataOld);
        $this->setSessionData($costData, 'costData');
        $courseObj = new Model_Courses();
        $courseName = $courseObj->getNameById($courseId);
        $this->view->costMappingData = !empty($costData) ? $costData : array();
        $this->view->courseId = $courseId;
        $this->view->courseDetainsIdMappingData = $courseDetainsIdMappingData;
        $this->view->examTableId = self::EXAM_TABLE_ID;

        $request = $this->getRequest()->getPost();
        if ($request) {
            unset($request['submit']);
            $costData = $request;

            $costDataSave = array();
            $keyPrefixArray = array();

            $i = 0;
            if (!empty($costData)) {
                foreach ($costData as $key => $value) {
                    $keyPrefixTemp = substr($key, 0, strpos($key, "_"));
                    $keyLables = str_replace($keyPrefixTemp . "_", "", $key);
                    if ($i == 0) {
                        $keyPrefix = $keyPrefixTemp;
                        array_push($keyPrefixArray, $keyPrefixTemp);
                    }
                    if ($keyPrefix == $keyPrefixTemp) {
                        $costDataSave[$keyPrefixTemp][$keyLables] = $value;
                    } else {
                        $keyPrefix = $keyPrefixTemp;
                        $costDataSave[$keyPrefixTemp][$keyLables] = $value;
                        array_push($keyPrefixArray, $keyPrefixTemp);
                    }
                    $i++;
                }
            }
            if (!empty($keyPrefixArray)) {
                foreach ($keyPrefixArray as $key => $value) {
                    $costLabelMapping = new Model_CostLableMapping();
                    $productCostObj = new Model_Cost();
                    $costMappingData = $costLabelMapping->getCostLabelId($value);
                    $result = $productCostObj->updateCostData($costDataSave[$value], $courseId, $costMappingData);
                }
            }
            $module = $this->getRequest()->getModuleName();
            $controller = $this->getRequest()->getControllerName();
            if ($module && $controller)
                $this->redirect($module . '/' . $controller . '/list');
        }
    }

    public function listAction() {
        $table = $this->getModel()->getName();
        $filterForm = new Form_Filters($table);
        $requestData = array();
        $queryParamsArr = array();
        $page = '';
        if ($this->getRequest()->isPost()) {
            $filterForm->populate($this->getRequest()->getPost());
            $page = 1;
            $requestData = $filterForm->getValues();
            foreach ($requestData as $elementName => $elementValue) {
                if (!empty($elementValue)) {
                    $queryData = $filterForm->getElement($elementName)->getAttrib('data-table');
                    $queryData['searchValue'] = $elementValue;
                    $this->queryBuilder($queryData);
                    $queryParamsArr[$queryData['search_id']] = $elementValue;
                } // end of !empty elementValue
            } // end of foreach RequestData
        } // end of if isPost
        if (empty($page)) {
            $page = $this->view->navigatorPage;
            $page = (int) $this->getRequest()->getParam('page');
        }
        $orderby = $this->getModel()->getPk() . ' DESC';
        if (empty($this->_queryParams)) {
            $getData = $this->getRequest()->getQuery();
            unset($getData['page']);
            if (!empty($getData)) {
                foreach ($getData as $key => $value) {
                    $queryParamsArr[$key] = $value;
                    $returnData = $filterForm->getSearchFields($key);
                    if (!empty($returnData)) {
                        $returnData = $returnData[0];
                        $filterForm->getElement($returnData['searchColumnName'])->setValue($value);
                        $returnData['searchValue'] = $value;
                        $this->queryBuilder($returnData);
                    }
                }
            }
        }
        if ($page <= 1) {
            $this->view->firstpage = true;
            $page = 1;
        } else {
            $this->view->firstpage = false;
        }
        $offset = ($page - 1) * self::ROWS_PER_PAGE;
        $limit = array(self::ROWS_PER_PAGE, $offset);
        $this->view->page = $page;
        $model = $this->getModel();
        $options = array('order' => array($orderby), 'limit' => $limit);
        if (!empty($this->_columns)) {
            $options['columns'] = array('course_id' => 'DISTINCT(course_id)');
        }
        $data = $model->fetchAll($this->_queryParams, $options);
        $courseData = new Model_Cost();
        $data = $courseData->getCourseDetails($data);
        $perPageData = count($data);
        $total = $model->fetchCount($this->_queryParams);
        if (count($data) < self::ROWS_PER_PAGE) {
            $this->view->lastpage = true;
        } else {
            $this->view->lastpage = false;
        }
        $numberOfPages = ceil($total / self::ROWS_PER_PAGE);
        if ($page < $numberOfPages) {
            $this->view->currentPageRecord = self::ROWS_PER_PAGE * $page;
        } else {
            $this->view->currentPageRecord = $total;
        }
        $this->view->diffPageRecord = $this->view->currentPageRecord - self::ROWS_PER_PAGE;
        if (count($data) < self::ROWS_PER_PAGE) {
            $this->view->diffPageRecord = $total - count($data);
        }
        $this->view->totalCount = $total;
        $this->view->totalPages = $numberOfPages;
        $this->view->lastPage = $numberOfPages;
        $pk = $model->getPk();
        foreach ($data as &$row) {
            $row['Action'] = "<a href='" . $this->view->url(array('action' => 'edit', 'id' => $row['course_id'])) . "'>Edit</a> " .
                    "<a class='delete-crud-item' href='#' onclick='deleteConfirmShow(\"" . $this->view->url(array('action' => 'delete', 'id' => $row['course_id'])) . "\");'>Delete</a> " .
                    "<a href='" . $this->view->url(array('controller' => 'changelog', 'action' => 'index', 'row' => $row['course_id'], 'table' => $table)) . "'>ChangeLog</a> ";
        }
        //================
        if (isset($data[0])) {
            $original = array_keys($data[0]);
        } else {
            $original = array();
        }
        $as = ($this->_displayInDataTable);
        //new datatable   
        //need to define path in ini file after discussion
        $datatableFilePath = '../../library/BaseApp/Datatable/' . ucfirst($table) . '.php';
        if (file_exists($datatableFilePath)) {
            $dataTableClass = 'BaseApp_Datatable_' . ucfirst($table);
        } else {
            $dataTableClass = 'BaseApp_Datatable_Default';
        }

        $dataTable = new $dataTableClass;
        $dataTable->setData($data);
        $this->view->queryParams = http_build_query($queryParamsArr);
        $this->view->form = $filterForm;
        $this->view->data = $dataTable;
        //------
        //$this->view->data = $data;
        $this->view->original = $original;
        $this->view->displayInDataTable = $as;
        $this->view->navigatorTotal = ceil($total / BACKEND_ROWS_PER_PAGE);
    }

    public function deleteAction() {
        $courseId = $this->getRequest()->getParam('id');
        $productCostObj = new Model_Cost();
        $costDataOld = $productCostObj->getDataByCourseId($courseId);
        $productCostObj->delete($costDataOld);
        $module = $this->getRequest()->getModuleName();
        $controller = $this->getRequest()->getControllerName();
        if ($module && $controller)
            $this->redirect($module . '/' . $controller . '/list');
    }

    protected function setSessionData($data, $key) {
        $session = new Zend_Session_Namespace('form');
        if (!empty($data) && !empty($key)) {
            $session->$key = $data;
        }
    }

    protected function getSessionData($key) {
        $session = new Zend_Session_Namespace('form');
        if (!empty($key)) {
            return $session->$key;
        }
    }

}
