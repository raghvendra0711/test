<?php
/*
 * Contains the CRUD actions of Addons table
 * 
 */

class Admin_AddonController extends BaseApp_Controller_Crud {
    protected $_model = 'Model_Addons';
    protected $_descriptions = array(
        'list' => 'List of Existing Addons',
        'index' => 'List of Existing Addons',
        'add' => 'Add New Addons',
        'edit' => 'Make the required changes then click on "Save Addons" to update the Addons',
        'view' => 'View Selected Addons'
    );

    protected function _getForm() {
        $form = new Form_Addons();
        return $form;
    }
}
