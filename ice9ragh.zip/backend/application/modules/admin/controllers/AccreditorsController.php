<?php

/*
 * Contains the CRUD actions of Accreditors table
 * 
 */

class Admin_AccreditorsController extends BaseApp_Controller_Crud {

    protected $_model = 'Model_Accreditors';
    protected $_descriptions = array(
        'list' => 'List of Existing Accreditors',
        'index' => 'List of Existing Accreditors',
        'add' => 'Add New Accreditors',
        'edit' => 'Make the required changes then click on "Save Accreditors" to update the Accreditors',
        'view' => 'View Selected Accreditors'
    );

    protected function _getForm() {
        $form = new Form_Accreditors();
        return $form;
    }

    public function addAction() {
        if (!$this->_add)
            $this->forward('list');
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $form = $this->_getForm();
        if ($form === false)
            throw new Zend_Exception('_getForm not implemented');
        if ($this->getRequest()->isPost() && $form->isValid($this->getRequest()->getPost())) {
            $request = $this->getRequest()->getPost();
            $formValues = $form->getValues();
            $pageTypes = $formValues['page_type'];
            unset($formValues['page_type']);
            if (!empty($pageTypes)) {
                foreach ($pageTypes as $pageType) {
                    switch (strtolower($pageType)) {
                        case Form_Accreditors::TYPE_COURSE_PAGE:
                            $formValues['isCoursePage'] = 1;
                            break;
                        case Form_Accreditors::TYPE_NEW_COURSE_PAGE:
                            $formValues['isNewCoursePage'] = 1;
                            break;
                        case Form_Accreditors::TYPE_MASTER_COURSE_PAGE:
                            $formValues['isMasterCoursePage'] = 1;
                            break;
                        case Form_Accreditors::TYPE_CATEGORY_COURSE_PAGE:
                            $formValues['isCategoryCoursePage'] = 1;
                            break;
                        case Form_Accreditors::TYPE_VENDOR_COURSE_PAGE:
                            $formValues['isVendorCoursePage'] = 1;
                            break;
                    }
                }
            }
            $form->removeOptionalElements();
            $result = $this->getModel()->setFromArray($formValues)->save();
            if (!$result) {
                $this->view->message = "An error has occured while saving";
                $this->view->success = true;
            } else {
                $this->view->message = "Data successfully added";
                $this->view->success = false;
                $form->reset();
                $module = $this->getRequest()->getModuleName();
                $controller = $this->getRequest()->getControllerName();
                $action = $this->getRequest()->getActionName();
                if ($module && $controller && $action)
                    $this->redirect($module . '/' . $controller . '/' . $action . '?success=true');
            }
            //$this->forward('list');
        }
        $this->view->form = $form;
    }

    public function editAction() {
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $id = $this->getRequest()->getParam('id');
        $data = $this->getModel($id);
        if ($data) {
            $pageTypes = array();
            if (!empty($data['isNewCoursePage'])) {
                $pageTypes[] = Form_Accreditors::TYPE_NEW_COURSE_PAGE;
            }
            if (!empty($data['isCoursePage'])) {
                $pageTypes[] = Form_Accreditors::TYPE_COURSE_PAGE;
            }
            if (!empty($data['isMasterCoursePage'])) {
                $pageTypes[] = Form_Accreditors::TYPE_MASTER_COURSE_PAGE;
            }
            if (!empty($data['isCategoryCoursePage'])) {
                $pageTypes[] = Form_Accreditors::TYPE_CATEGORY_COURSE_PAGE;
            }
            if (!empty($data['isVendorCoursePage'])) {
                $pageTypes[] = Form_Accreditors::TYPE_VENDOR_COURSE_PAGE;
            }
            $data['page_type'] = $pageTypes;
            //Unset Page Types
            unset($data['isNewCoursePage']);
            unset($data['isCoursePage']);
            unset($data['isMasterCoursePage']);
            unset($data['isCategoryCoursePage']);
            unset($data['isVendorCoursePage']);
            // ###################################
            $this->view->postParams = $data;
            $form = $this->_getForm();
            $form->removeOptionalValidators();
            $form->removeUneditableElements();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            if ($this->getRequest()->isPost() && $form->isValid($this->getRequest()->getPost())) {
                $form->removeOptionalElements();
                $formValues = $form->getValues();
                $pageTypes = $formValues['page_type'];
                unset($formValues['page_type']);
                $formValues['isCoursePage'] = $formValues['isNewCoursePage'] = $formValues['isMasterCoursePage'] = $formValues['isCategoryCoursePage'] = $formValues['isVendorCoursePage'] = 0;
                if (!empty($pageTypes)) {
                    foreach ($pageTypes as $pageType) {
                        switch (strtolower($pageType)) {
                            case Form_Accreditors::TYPE_COURSE_PAGE:
                                $formValues['isCoursePage'] = 1;
                                break;
                            case Form_Accreditors::TYPE_NEW_COURSE_PAGE:
                                $formValues['isNewCoursePage'] = 1;
                                break;
                            case Form_Accreditors::TYPE_MASTER_COURSE_PAGE:
                                $formValues['isMasterCoursePage'] = 1;
                                break;
                            case Form_Accreditors::TYPE_CATEGORY_COURSE_PAGE:
                                $formValues['isCategoryCoursePage'] = 1;
                                break;
                            case Form_Accreditors::TYPE_VENDOR_COURSE_PAGE:
                                $formValues['isVendorCoursePage'] = 1;
                                break;
                        }
                    }
                }
                $result = $data->setFromArray($formValues)->update();
                if (!$result) {
                    $this->view->message = "An error has occured while saving";
                    $this->view->success = true;
                } else {
                    // for making message page specific
                    $this->view->message = ucwords($this->getRequest()->getControllerName()) . " Data successfully updated";
                    $this->view->success = false;
                }
                //$this->forward('list');
            }
            $form->setDefaults($data->toArray());
            $this->view->form = $form;
        }
    }

}
