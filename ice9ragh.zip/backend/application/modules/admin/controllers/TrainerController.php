<?php
/*
 * Contains the CRUD actions of Trainers table
 * 
 */

class Admin_TrainerController extends BaseApp_Controller_Crud {
    protected $_model = 'Model_Trainers';
    protected $_descriptions = array(
        'list' => 'List of Existing Trainers',
        'index' => 'List of Existing Trainers',
        'add' => 'Add New Trainers',
        'edit' => 'Make the required changes then click on "Save Trainers" to update the Trainers',
        'view' => 'View Selected Trainers'
    );

    protected function _getForm() {
        $form = new Form_Trainers();
        return $form;
    }
}
