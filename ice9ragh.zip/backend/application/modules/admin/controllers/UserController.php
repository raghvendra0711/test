<?php

/*
 * Contains the CRUD actions of Accreditors table
 * 
 */

class Admin_UserController extends BaseApp_Controller_Crud {

    protected $_model = 'Model_Acl';
    protected $_descriptions = array(
        'add' => 'Add New User',
        'list' => 'List all Users'
    );

    protected function _getForm() {
        $form = new Form_User();
        return $form;
    }

    public function addAction() {
        if (!$this->_add)
            $this->forward('list');
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $this->view->success = true;
        $form = new Form_User;
        if ($this->getRequest()->isPost() && $form->isValid($this->getRequest()->getPost())) {
            $email = $this->getRequest()->getPost('email');
            $acl = new Model_Acl;            
            if($acl->getByEmail($email)) {
                $this->view->message = "Email already exists";
                $this->view->success = false;               
                $this->view->form = $form;
                return false;
            }
            $userData = json_decode(file_get_contents(BASE_LMS_URL.BASE_LMS_API_URL."get-user-details-by-email/email/".$email),5); 
            if($userData['status'] != 'Success') {
                $this->view->message = "User not registerd in Website";
                $this->view->success = false;               
                $this->view->form = $form;
                return false;
            }            
            $userData = current($userData['user']);
            $dataSave = array(
                'email' => $email, 
                'password' => $userData['users_password'], 
                'name' => sprintf("%s %s", $userData['users_firstName'], $userData['users_lastName']), 
                'looper_user_id' => $userData['users_userId']
            );
            if(!$acl->create($dataSave)) {
                $this->view->message = "Email already exists";
                $this->view->success = false;               
                $this->view->form = $form;
            }
            $module  = $this->getRequest()->getModuleName();
            $controller = $this->getRequest()->getControllerName();
            $action = $this->getRequest()->getActionName();
            if($module && $controller && $action)
                $this->redirect($module.'/'.$controller.'/list');            
        }
        $this->view->form = $form;
    }
    
    public function listAction() {
        $this->_helper->viewRenderer->setRender('common/list')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $table = $this->getModel()->getName();
        $filterForm = new Form_Filters($table);
        $requestData = array();
        $queryParamsArr = array();
        $page = '';
        if($this->getRequest()->isPost()){
            $filterForm->populate($this->getRequest()->getPost());
            $page = 1;
            $requestData = $filterForm->getValues();
            foreach($requestData as $elementName => $elementValue) {
                if(!empty($elementValue)){
                    $queryData = $filterForm->getElement($elementName)->getAttrib('data-table');
                    $queryData['searchValue'] = $elementValue;
                    $this->queryBuilder($queryData);
                    $queryParamsArr[$queryData['search_id']] = $elementValue;    
                }
            }
        }
        if(empty($page)){
            $page = $this->view->navigatorPage;
            $page = (int)$this->getRequest()->getParam('page');
        }
        $orderby = $this->getModel()->getPk() . ' DESC';
        if(empty($this->_queryParams)){
            $getData = $this->getRequest()->getQuery();
            unset($getData['page']);
            if(!empty($getData)){
                foreach ($getData as $key => $value) {
                    $queryParamsArr[$key] = $value;
                    $returnData = $filterForm->getSearchFields($key);
                    if(!empty($returnData)){
                        $returnData = $returnData[0];
                        $filterForm->getElement($returnData['searchColumnName'])->setValue($value);
                        $returnData['searchValue'] = $value;
                        $this->queryBuilder($returnData);
                    }
                }
            }
        }
        if ($page <= 1) {
            $this->view->firstpage = true;
            $page = 1;
        } else {
            $this->view->firstpage = false;
        }
        $offset = ($page - 1) * self::ROWS_PER_PAGE;
        $limit = array(self::ROWS_PER_PAGE,$offset);
        $this->view->page = $page;
        $model = $this->getModel();
        $data = $model->fetchAll($this->_queryParams, array('order' => array($orderby), 'limit' => $limit));
        $perPageData = count($data);
        $total = $model->fetchCount($this->_queryParams);
        if (count($data) < self::ROWS_PER_PAGE) {
            $this->view->lastpage = true;
        } else {
            $this->view->lastpage = false;
        }
        $numberOfPages = ceil($total / self::ROWS_PER_PAGE);
        if($page < $numberOfPages){
            $this->view->currentPageRecord = self::ROWS_PER_PAGE * $page;    
        }else{
            $this->view->currentPageRecord = $total;    
        }
        $this->view->diffPageRecord = $this->view->currentPageRecord - self::ROWS_PER_PAGE;
        if(count($data) < self::ROWS_PER_PAGE){
            $this->view->diffPageRecord = $total - count($data);
        }

        $this->view->totalCount = $total;
        $this->view->totalPages = $numberOfPages;
        $this->view->lastPage = $numberOfPages;
        $pk = $model->getPk();
        //@TODO: Remove from controller and create an action helper.
        foreach ($data as &$row) {
            $row['Action'] = "<a href='" . $this->view->url(array('action' => 'view', 'id' => $row[$pk])) . "'>View</a> " . "<a href='" . $this->view->url(array('controller' => 'changelog', 'action' => 'index', 'row' => $row[$pk], 'table' => $table)) . "'>ChangeLog</a> ";
        }
        //================
        if(isset($data[0])){
            $original = array_keys($data[0]);
        }else{
            $original = array();
        }
        $as = ($this->_displayInDataTable);
        //new datatable   
        //need to define path in ini file after discussion
        $datatableFilePath = '../../library/BaseApp/Datatable/'.ucfirst($table).'.php';       
        if(file_exists($datatableFilePath)) {
            $dataTableClass = 'BaseApp_Datatable_'.ucfirst($table);               
        }
        else{
            $dataTableClass = 'BaseApp_Datatable_Default';                            
        }
        $dataTable = new $dataTableClass;
        $dataTable->setData($data);
        $this->view->queryParams = http_build_query($queryParamsArr);
        $this->view->form = $filterForm;
        $this->view->data = $dataTable;
        $this->view->original = $original;
        $this->view->displayInDataTable = $as;
        $this->view->navigatorTotal = ceil($total / BACKEND_ROWS_PER_PAGE);
    }
    
    public function cartMissingAction() {
        $allowedEmails = array(
            'dinesh@simplilearn.com',
            'santosh.rout@simplilearn.com',
            'prashant.a@simplilearn.com',
            'srinivas.nerella@simplilearn.com'
        );
        $userDetails = BaseApp_Auth::getLoggedInUserData();
        if(!in_array(strtolower($userDetails['email']), $allowedEmails)) {
            die('You dont have permission to view this page.');
        }        
        
        $db = new Model_Default;
        $today = date('Y-m-d');
        $today .= " 00:00:00";
        $startDate = strtotime($today);

        $courseDao = new BaseApp_Dao_Courses();
        $courseData = $courseDao->fetchForSelect();

        $trainingDao = new BaseApp_Dao_TrainingTypes();
        $trainingTypes = $trainingDao->fetchForSelect();

        $bundleDao = new BaseApp_Dao_Bundles();
        $bundleData = $bundleDao->fetchForSelect();

        $countryDao = new BaseApp_Dao_Country();
        $countryData = $countryDao->fetchForSelect();

        $paymentDao = new BaseApp_Dao_PaymentType();
        $paymentTypes = $paymentDao->fetchForSelect();
        
        $this->view->content = "<table border='1' style='overflow:auto;display:inline-block;'><tr><th>orderId</th><th>email</th><th>phone</th><th>personName</th><th>Country</th><th>items</th><th>paymentType</th><th>couponApplied</th><th>ipAddress</th><th>userAgent</th><th>isProcessed</th><th>addDateTime</th><th>lastUpdateDateTime</th></tr>";
        $cartData = $db->cart->find(array('lastUpdateDateTime'=>array('$gt'=>$startDate)), array('_id' => 0))->sort(array('lastUpdateDateTime' => -1))->toArray(0);
        foreach($cartData as &$cartDataSingle) {
            $orderData = $db->orders->find(array('session_id'=> $cartDataSingle['session_id']), array('_id' => 0))->toArray(0);
            if(!$orderData) {
                $cartDataSingle['Country'] = @$countryData[$cartDataSingle['countryId']];
                unset($cartDataSingle['countryId']);

                $cartDataSingle['paymentType'] = @$paymentTypes[$cartDataSingle['paymentType']];                                
                $cartDataSingle['addDateTime'] = date('Y-m-d H:i:s', $cartDataSingle['addDateTime']);
                $cartDataSingle['lastUpdateDateTime'] = date('Y-m-d H:i:s', $cartDataSingle['lastUpdateDateTime']);

                $items = array();
                foreach($cartDataSingle['items'] as $productData => $quantity) {
                    $product = explode("_", $productData);                        
                    $item = array(
                        'Training Type' => @$trainingTypes[@$product[1]],
                        'Access Days' => @$product[2]
                    );
                    if(preg_match("/([a-z])([0-9]+)/i", $product[0], $match)) {
                        if($match[0] == BaseApp_Dao_ProductTypes::PREFIX_BUNDLE) {
                            $item['Product Type'] = 'bundle';
                            $item['Name'] = @$bundleData[$match[2]];
                        }
                        elseif($match[0] == BaseApp_Dao_ProductTypes::PREFIX_PASS) {
                            $item['Product Type'] = 'lvc_pass';
                            $item['Name'] = 'Online Classroom Season Pass';
                        }
                    }
                    else {
                        $item['Product Type'] = 'course';
                        $item['Name'] = @$courseData[$product[0]];
                    }     
                    $items[] = $item;
                }
                $cartDataSingle['items'] = json_encode($items);        
                $this->view->content .= sprintf("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%d</td><td>%s</td><td>%s</td></tr>", @$cartDataSingle['orderId'], $cartDataSingle['email'], $cartDataSingle['phone'], $cartDataSingle['personName'], $cartDataSingle['Country'], $cartDataSingle['items'], $cartDataSingle['paymentType'], $cartDataSingle['couponApplied'], $cartDataSingle['ipAddress'], $cartDataSingle['userAgent'], $cartDataSingle['isProcessed'], $cartDataSingle['addDateTime'], $cartDataSingle['lastUpdateDateTime']);
            }   
        }
        $this->view->content .= "</table>";
    }
}
