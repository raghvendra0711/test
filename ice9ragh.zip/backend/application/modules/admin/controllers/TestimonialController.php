<?php
/*
 * Contains the CRUD actions of Testimonail table
 *
 */

class Admin_TestimonialController extends BaseApp_Controller_Crud {

    const ROWS_PER_PAGE = 50;

    const DEFAULT_AVATAR_PATH = 'ice9/testimonial_images/default_avatar.png';
    const S3_REVIEW_PATH = '/ice9/reviews_images/';
    const S3_ABS_PATH = 'https://www.simplilearn.com/ice9/reviews_images/';

    protected $_model = 'Model_Reviews';

    protected $_descriptions = array(
        'list' => 'List of Existing Testimonail',
        'index' => 'List of Existing Testimonail',
        'add' => 'Add New Testimonail',
        'edit' => 'Make the required changes then click on "Save Testimonail" to update the Testimonail',
        'view' => 'View Selected Testimonail',
        'approve' => 'approve Testimonail',
        'disapprove' => 'disapprove Testimonail'
    );

    protected function _getForm() {
        $form = new Form_Testimonail();
        return $form;
    }

    public function addAction() {
        //prd($_REQUEST);
        if (!$this->_add)
            $this->forward('list');
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $form = $this->_getForm();
        if ($form === false)
            throw new Zend_Exception('_getForm not implemented');
        if ($this->getRequest()->isPost() && $form->isValid($this->getRequest()->getPost())) {
            $request = $this->getRequest()->getPost();
            $data = $form->getValues();
            if(!$data['rating']) {
                $form->getElement('rating')->setErrors(array("Value is required and can't be empty"));
                $this->view->message = "Rating is a required field";
                $this->view->success = false;
                $this->view->form = $form;
                return false;
            }elseif(!$data['country_id']) {
                $form->getElement('country_id')->setErrors(array("Value is required and can't be empty"));
                $this->view->message = "Country is a required field";
                $this->view->success = false;
                $this->view->form = $form;
                return false;
            }
            if(!$data['training_id']) {
                $form->getElement('training_id')->setErrors(array("Value is required and can't be empty"));
                $this->view->message = "Training is a required field";
                $this->view->success = false;
                $this->view->form = $form;
                return false;
            }elseif(!$data['course_id'] && !$data['bundle_id']){
                $form->getElement('course_id')->setErrors(array("Either course or bundle is required and can't be empty"));
                $this->view->message = "Either course or bundle is a required field";
                $this->view->success = false;
                $this->view->form = $form;
                return false;
            }
            unset($data['cluster_id_homepage_tmp']);
            // unset($data['cluster_id_bundle_tmp']);

            /* if ($data['cluster_id_bundle']) {
                $modelCountry = new Model_Country();
                $countries = $modelCountry->fetchForSelect(array("cluster_id IN (?)"=>$data['cluster_id_bundle']), array(), false);
                if ($data['country_id_bundle']) {
                    $data['country_id_bundle'] = array_merge($data['country_id_bundle'], array_keys($countries));
                } else {
                    $data['country_id_bundle'] = array_keys($countries);
                }
            } */

            if ($data['cluster_id_homepage']) {
                $modelCountry = new Model_Country();
                $countries = $modelCountry->fetchForSelect(array("cluster_id IN (?)"=>$data['cluster_id_homepage']), array(), false);
                if ($data['country_id_homepage']) {
                    $data['country_id_homepage'] = array_merge($data['country_id_homepage'], array_keys($countries));
                } else {
                    $data['country_id_homepage'] = array_keys($countries);
                }
            }
            // $data['cluster_id_bundle'] = !empty($data['cluster_id_bundle']) ?implode(",", $data['cluster_id_bundle']) : '';
            // $data['country_id_bundle'] = implode(",", $data['country_id_bundle']);
            $data['cluster_id_homepage'] = !empty($data['cluster_id_homepage']) ? implode(",", $data['cluster_id_homepage']) : '';
            $data['country_id_homepage'] = implode(",", $data['country_id_homepage']);

            if(isset($data['createDate'])) {
                $data['createDate'] = date('Y-m-d H:i:s', strtotime($data['createDate']));
            }
            if(empty($data['city_id'])){
                $objCountry = new Model_Country();
                $defaultCityData = current( $objCountry->fetchAll(array('country_id =?'=>$data['country_id']),array('columns'=>array('defaultCity_id') ) ) );
                if(!empty($defaultCityData['defaultCity_id'])){
                    $data['city_id'] = $defaultCityData['defaultCity_id'];
                    $objCity = new Model_City();
                    $cityData = current($objCity->fetchAll(array('city_id =?'=>$defaultCityData['defaultCity_id'])));
                    if(empty($cityData)){
                        $this->view->message = "Default City Against Selected Country is Not Active..Cannot Add a Review";
                        $this->view->success = false;
                        $this->view->form = $form;
                        return false;
                    }
                }
                else{
                    $this->view->message = "No Default City Found Against Selected Country..Cannot Add a Review";
                    $this->view->success = false;
                    $this->view->form = $form;
                    return false;
                }
            }

            $data['imgUrl'] = empty($data['imgUrl']) ? UPLOAD_CDN_URL.TESTIMONIAL_DEFAULT_IMAGE : $data['imgUrl'] ;
            if( (strpos($data['imgUrl'], self::DEFAULT_AVATAR_PATH) !== false ) || (strpos( $data['imgUrl'], self::S3_REVIEW_PATH ) !== false) ) {
                    // It seems that image is already present in S3
            } else if(strpos($data['imgUrl'], 'media.licdn.com') !== false ){
                // Store the image in /tmp folder
                $imageExt = pathinfo($data['imgUrl'], PATHINFO_EXTENSION);
                if(empty($imageExt)) {
                    $pageHeaders = get_headers($data['imgUrl'], 1);
                    $contentType = (!empty($pageHeaders['Content-Type']))?$pageHeaders['Content-Type']:'';
                    $contendTypeData = explode('/', $contentType);
                    if(!empty($contendTypeData[1])) {
                        $imageExt = $contendTypeData[1];
                    }
                }
                $fileName = $id.'_'.time().'.'.$imageExt;
                $imagePath = self::S3_ABS_PATH.$fileName;
                $fileData = file_get_contents($data['imgUrl']);
                $filePath = '/tmp/'.$fileName;
                file_put_contents($filePath, $fileData);
                $awsPath = 'ice9/reviews_images/'.$fileName;
                $objAws =  new BaseApp_Utility_AwsFileUpload();
                if($objAws->uploadImageIntoAws($filePath,$awsPath)){
                    $data['imgUrl'] = $imagePath;
                }else{
                    $this->view->message = "There was some problem in uploading file";
                    $this->view->success = false;
                    $this->view->form = $form;
                    return false;
                }
            }
            $isApprovedFlag = REVIEW_TO_BE_APPROVED_STATUS;
            $disApprovedReason = NULL;
            if(empty($data['review'])){
                $isApprovedFlag = REVIEW_DISAPPROVED_STATUS;
                $disApprovedReason = 'empty review';
            }elseif($data['rating'] < 3){
                $isApprovedFlag = REVIEW_DISAPPROVED_STATUS;
                $disApprovedReason = 'rating less than 3';
            }elseif ( strlen($data['review']) < 15) {
                $isApprovedFlag = REVIEW_DISAPPROVED_STATUS;
                $disApprovedReason = 'review less than 15 characters';
            }
            $data['isApproved'] = $isApprovedFlag;
            $data['disApprovedReason'] = $disApprovedReason;
            $result = $this->getModel()->setFromArray($data)->save();
            if (!$result) {
                $this->view->message = "An error has occured while saving";
                $this->view->success = true;
            } else {
                $this->view->message = "Data successfully added";
                $this->view->success = false;
                $form->reset();
                $module  = $this->getRequest()->getModuleName();
                $controller = $this->getRequest()->getControllerName();
                $action = $this->getRequest()->getActionName();
                if($module && $controller && $action)
                    $this->redirect($module.'/'.$controller.'/list');
            }
            //$this->forward('list');
        }
        else {
            $dataSave = $form->getValues();
            $cityModel = new Model_City();
            $cityData = $cityModel->fetchforSelect(array('country_id =?'=> intval($dataSave['country_id'])));
            $form->getElement('city_id')->setAttrib('options',$cityData);    
        }
        
        $this->view->form = $form;
    }

    public function editAction() {
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $id = $this->getRequest()->getParam('id');
        $obj = $this->getModel($id);
        if ($obj) {
            $this->view->postParams = $obj;
            $form = $this->_getForm();
            if ($obj->isLms) {
                $form->removeUneditableElements();
            }
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            if ($this->getRequest()->isPost() && $form->isValid($this->getRequest()->getPost())) {
                $dataSave = $form->getValues();
                if ($obj->isLms) {
                    $dataSave['name'] = $obj->name;
                    $dataSave['email'] = $obj->email;
                    $dataSave['review'] = $obj->review;
                    $dataSave['isGeneric'] = $obj->isGeneric;
                    $dataSave['course_id'] = $obj->course_id;
                    $dataSave['training_id'] = $obj->training_id;
                    $dataSave['country_id'] = $obj->country_id;
                    $dataSave['city_id'] = $obj->city_id;
                    $dataSave['createDate'] = $obj->createDate;
                    $dataSave['rating'] = $obj->rating;
                }
                if (!$dataSave['rating']) {
                    $form->getElement('rating')->setErrors(array("Value is required and can't be empty"));
                    $this->view->message = "Rating is a required field";
                    $this->view->success = false;
                    $this->view->form = $form;
                    return false;
                } elseif (!$dataSave['country_id']) {
                    $form->getElement('country_id')->setErrors(array("Value is required and can't be empty"));
                    $this->view->message = "Country is a required field";
                    $this->view->success = false;
                    $this->view->form = $form;
                    return false;
                }
                if (!$dataSave['training_id']) {
                    $form->getElement('training_id')->setErrors(array("Value is required and can't be empty"));
                    $this->view->message = "Training is a required field";
                    $this->view->success = false;
                    $this->view->form = $form;
                    return false;
                } elseif(!$dataSave['course_id'] && !$dataSave['bundle_id']) {
                    $form->getElement('course_id')->setErrors(array("Value is required and can't be empty"));
                    $this->view->message = "Course is a required field";
                    $this->view->success = false;
                    $this->view->form = $form;
                    return false;
                }

                unset($dataSave['cluster_id_homepage_tmp']);
                // unset($dataSave['cluster_id_bundle_tmp']);

                /* if ($dataSave['cluster_id_bundle']) {
                    $modelCountry = new Model_Country();
                    $countries = $modelCountry->fetchForSelect(array("cluster_id IN (?)"=>$dataSave['cluster_id_bundle']), array(), false);
                    if ($dataSave['country_id_bundle']) {
                        $dataSave['country_id_bundle'] = array_merge($dataSave['country_id_bundle'], array_keys($countries));
                    } else {
                        $dataSave['country_id_bundle'] = array_keys($countries);
                    }
                } */

                if ($dataSave['cluster_id_homepage']) {
                    $modelCountry = new Model_Country();
                    $countries = $modelCountry->fetchForSelect(array("cluster_id IN (?)"=>$dataSave['cluster_id_homepage']), array(), false);
                    if ($dataSave['country_id_homepage']) {
                        $dataSave['country_id_homepage'] = array_merge($dataSave['country_id_homepage'], array_keys($countries));
                    } else {
                        $dataSave['country_id_homepage'] = array_keys($countries);
                    }
                }
                // $dataSave['cluster_id_bundle'] = !empty($dataSave['cluster_id_bundle']) ? implode(",", $dataSave['cluster_id_bundle']):'';
                // $dataSave['country_id_bundle'] = implode(",", $dataSave['country_id_bundle']);
                $dataSave['cluster_id_homepage'] = !empty($dataSave['cluster_id_homepage']) ? implode(",", $dataSave['cluster_id_homepage']) : '';
                $dataSave['country_id_homepage'] = !empty($dataSave['country_id_homepage']) ? implode(",", $dataSave['country_id_homepage']) : '';

                if (isset($dataSave['createDate'])) {
                    $dataSave['createDate'] = date('Y-m-d H:i:s', strtotime($dataSave['createDate']));
                }
                if (empty($dataSave['city_id'])) {
                    $objCountry = new Model_Country();
                    $defaultCityData = current( $objCountry->fetchAll(array('country_id =?'=>$dataSave['country_id']),array('columns'=>array('defaultCity_id') ) ) );
                    if (!empty($defaultCityData['defaultCity_id'])) {
                        $dataSave['city_id'] = $defaultCityData['defaultCity_id'];
                        $objCity = new Model_City();
                        $cityData = current($objCity->fetchAll(array('city_id =?'=>$defaultCityData['defaultCity_id'])));
                        if (empty($cityData)) {
                            $this->view->message = "Default City Against Selected Country is Not Active..Cannot Add a Review";
                            $this->view->success = false;
                            $this->view->form = $form;
                            return false;
                        }
                    } else {
                        $this->view->message = "No Default City Found Against Selected Country..Cannot Add a Review";
                        $this->view->success = false;
                        $this->view->form = $form;
                        return false;
                    }
                }
                $dataSave['imgUrl'] = empty($dataSave['imgUrl']) ? UPLOAD_CDN_URL.TESTIMONIAL_DEFAULT_IMAGE : $dataSave['imgUrl'] ;
                if ((strpos($dataSave['imgUrl'], self::DEFAULT_AVATAR_PATH) !== false ) || (strpos( $dataSave['imgUrl'], self::S3_REVIEW_PATH ) !== false) ) {
                    // It seems that image is already present in S3
                } else {
                    if (strpos($dataSave['imgUrl'], 'media.licdn.com') !== false ) {
                        // Store the image in /tmp folder
                        $imageExt = pathinfo($dataSave['imgUrl'], PATHINFO_EXTENSION);
                        if (empty($imageExt)) {
                            $pageHeaders = get_headers($dataSave['imgUrl'], 1);
                            $contentType = (!empty($pageHeaders['Content-Type'])) ? $pageHeaders['Content-Type'] : '';
                            $contendTypeData = explode('/', $contentType);
                            if (!empty($contendTypeData[1])) {
                                $imageExt = $contendTypeData[1];
                            }
                        }
                        $fileName = $id.'_'.time().'.'.$imageExt;
                        $imagePath = self::S3_ABS_PATH.$fileName;
                        $fileData = file_get_contents($dataSave['imgUrl']);
                        $filePath = '/tmp/'.$fileName;
                        file_put_contents($filePath, $fileData);
                        $awsPath = 'ice9/reviews_images/'.$fileName;
                        $objAws =  new BaseApp_Utility_AwsFileUpload();
                        if ($objAws->uploadImageIntoAws($filePath,$awsPath)) {
                            $dataSave['imgUrl'] = $imagePath;
                        } else {
                            $this->view->message = "There was some problem in uploading file";
                            $this->view->success = false;
                            $this->view->form = $form;
                            return false;
                        }
                    }
                }

                $result = $obj->setFromArray($dataSave)->update();
                if (!$result) {
                    $this->view->message = "An error has occured while saving";
                    $this->view->success = true;
                } else {
                    // for making message page specific
                    $this->view->message = ucwords($this->getRequest()->getControllerName())." Data successfully updated";
                    $this->view->success = false;
                    $form->reset();
                    $module  = $this->getRequest()->getModuleName();
                    $controller = $this->getRequest()->getControllerName();
                    $action = $this->getRequest()->getActionName();
                    if($module && $controller && $action)
                        $this->redirect($module.'/'.$controller.'/list');
                }
            }
            $cityModel = new Model_City();
            $cityData = $cityModel->fetchforSelect(array('country_id =?'=> intval($obj->country_id)));
            $form->getElement('city_id')->setAttrib('options',$cityData);
            $data = $obj->toArray();
            // $data['cluster_id_bundle'] = explode(",", $data['cluster_id_bundle']);
            // $data['country_id_bundle'] = explode(",", $data['country_id_bundle']);
            $data['cluster_id_homepage'] = explode(",", $data['cluster_id_homepage']);
            $data['country_id_homepage'] = explode(",", $data['country_id_homepage']);
            $form->setDefaults($data);
            $this->view->form = $form;
        }
    }

    public function listAction() {
        $this->_helper->viewRenderer->setRender('common/list')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $table = $this->getModel()->getName();
        $filterForm = new Form_Filters($table);
        $requestData = array();
        $queryParamsArr = array();
        $page = '';
        if($this->getRequest()->isPost()){
            $filterForm->populate($this->getRequest()->getPost());
            $page = 1;
            $requestData = $filterForm->getValues();
            foreach($requestData as $elementName => $elementValue) {
                if(!empty($elementValue)){
                    $queryData = $filterForm->getElement($elementName)->getAttrib('data-table');
                    $queryData['searchValue'] = $elementValue;
                    $this->queryBuilder($queryData);
                    $queryParamsArr[$queryData['search_id']] = $elementValue;
                }
            }
        }
        if(empty($page)){
            $page = $this->view->navigatorPage;
            $page = (int)$this->getRequest()->getParam('page');
        }
        $orderby = $this->getModel()->getPk() . ' DESC';
        if (empty($this->_queryParams)) {
            $getData = $this->getRequest()->getQuery();
            unset($getData['page']);
            if (!empty($getData)) {
                foreach ($getData as $key => $value) {
                    $queryParamsArr[$key] = $value;
                    $returnData = $filterForm->getSearchFields($key);
                    if(!empty($returnData)){
                        $returnData = $returnData[0];
                        $filterForm->getElement($returnData['searchColumnName'])->setValue($value);
                        $returnData['searchValue'] = $value;
                        $this->queryBuilder($returnData);
                    }
                }
            }
        }
        if ($page <= 1) {
            $this->view->firstpage = true;
            $page = 1;
        } else {
            $this->view->firstpage = false;
        }
        $offset = ($page - 1) * self::ROWS_PER_PAGE;
        $limit = array(self::ROWS_PER_PAGE,$offset);
        $this->view->page = $page;
        $model = $this->getModel();
        $data = $model->fetchAll($this->_queryParams, array('order' => array($orderby), 'limit' => $limit));
        $perPageData = count($data);
        $total = $model->fetchCount($this->_queryParams);
        if (count($data) < self::ROWS_PER_PAGE) {
            $this->view->lastpage = true;
        } else {
            $this->view->lastpage = false;
        }
        $numberOfPages = ceil($total / self::ROWS_PER_PAGE);
        if($page < $numberOfPages){
            $this->view->currentPageRecord = self::ROWS_PER_PAGE * $page;
        }else{
            $this->view->currentPageRecord = $total;
        }
        $this->view->diffPageRecord = $this->view->currentPageRecord - self::ROWS_PER_PAGE;
        if(count($data) < self::ROWS_PER_PAGE){
            $this->view->diffPageRecord = $total - count($data);
        }
        $this->view->totalCount = $total;
        $this->view->totalPages = $numberOfPages;
        $this->view->lastPage = $numberOfPages;
        $pk = $model->getPk();
        $bundleObj = new Model_Bundles();
        //@TODO: Remove from controller and create an action helper.
        foreach ($data as &$row) {
            if(!empty($row['bundle_id'])){
                $bundleName = $bundleObj->getBundleByIds(array($row['bundle_id']));
                $row['Bundle'] = !empty($bundleName[$row['bundle_id']]) ? $bundleName[$row['bundle_id']] : '';
            }
            $row['Action'] = "<a href='" . $this->view->url(array('action' => 'view', 'id' => $row[$pk])) . "'>View</a> " . "<a href='" . $this->view->url(array('controller' => 'changelog', 'action' => 'index', 'row' => $row[$pk], 'table' => $table)) . "'>ChangeLog</a> ";
            if($row['isApproved'] != 2) {
                $row['Action'] .= "<a href='" . $this->view->url(array('action' => 'edit', 'id' => $row[$pk])) . "'>Edit</a> ";
               if($row['isApproved'] == 0) {
                    $row['Action'] .= "<a href='" . $this->view->url(array('action' => 'approve', 'id' => $row[$pk])) . "'>Approve</a> ";
                    $row['Action'] .= "<a href='" . $this->view->url(array('action' => 'disapprove', 'id' => $row[$pk])) . "'>Disapprove</a> ";
               }else{
                    $row['Action'] .= "<a href='" . $this->view->url(array('action' => 'disapprove', 'id' => $row[$pk])) . "'>Disapprove</a> ";
               }
            }
        }
        //================
        if(isset($data[0])){
            $original = array_keys($data[0]);
        }else{
            $original = array();
        }
        $as = ($this->_displayInDataTable);
        //new datatable
        //need to define path in ini file after discussion
        $datatableFilePath = '../../library/BaseApp/Datatable/'.ucfirst($table).'.php';
        if(file_exists($datatableFilePath)) {
            $dataTableClass = 'BaseApp_Datatable_'.ucfirst($table);
        }
        else{
            $dataTableClass = 'BaseApp_Datatable_Default';
        }

        $dataTable = new $dataTableClass;
        $dataTable->setData($data);
        $this->view->queryParams = http_build_query($queryParamsArr);
        $this->view->form = $filterForm;
        $this->view->data = $dataTable;
        //------
        //$this->view->data = $data;
        $this->view->original = $original;
        $this->view->displayInDataTable = $as;
        $this->view->navigatorTotal = ceil($total / BACKEND_ROWS_PER_PAGE);
    }

    public function approveAction() {
        $id = $this->getRequest()->getParam('id');
        $data = $this->getModel($id);
        $data = $data->toArray();
        if(!$data) {
           $this->view->message = "Invalid testimonial id";
           $this->view->success = false;
           return;
        }
        if($data['isApproved'] == 1) {
            $this->view->message = "This testimonial already approved";
            $this->view->success = false;
            return;
        }
        $dataSave = array(
            'isApproved' => 1,
            'ApprovedDate'=>date('Y-m-d H:i:s')
        );
        $modelReview = $this->getModel($id);
        if(!$modelReview->setFromArray($dataSave)->update()) {
            $this->view->message = "Failed to approve";
            $this->view->success = false;
            return;
        }
        $objCourse = New Model_Courses($data['course_id']);
        $cdnPurgeData = $this->getModel()->buildCdnPurgeData($data['course_id'],'course','Testimonail Got Approved For Course '.$objCourse->name);
        $objCdn = new Model_CdnPurgeLog();
        if(!empty($cdnPurgeData))
            $objCdn->InsertCdnPurgeLog($cdnPurgeData);
        $module  = $this->getRequest()->getModuleName();
        $controller = $this->getRequest()->getControllerName();
        $action = $this->getRequest()->getActionName();
        if($module && $controller && $action)
            $this->redirect($module.'/'.$controller.'/list');
    }

    public function disapproveAction() {
        $id = $this->getRequest()->getParam('id');
        $data = $this->getModel($id);
        $data = $data->toArray();
        if(!$data) {
           $this->view->message = "Invalid testimonial id";
           $this->view->success = false;
           return;
        }

        if($data['isApproved'] == 2) {
            $this->view->message = "This testimonial already disapproved";
            $this->view->success = false;
            return;
        }
        $dataSave = array(
            'isApproved' => 2,
            'ApprovedDate'=>NULL
        );

        $modelReview = $this->getModel($id);
        if(!$modelReview->setFromArray($dataSave)->update()) {
            $this->view->message = "Failed to disapprove";
            $this->view->success = false;
            return;
        }
        $objCourse = New Model_Courses($data['course_id']);
        $cdnPurgeData = $this->getModel()->buildCdnPurgeData($data['course_id'],'course','Testimonail Got Approved For Course '.$objCourse->name);
        $objCdn = new Model_CdnPurgeLog();
        if(!empty($cdnPurgeData))
            $objCdn->InsertCdnPurgeLog($cdnPurgeData);
        $module  = $this->getRequest()->getModuleName();
        $controller = $this->getRequest()->getControllerName();
        $action = $this->getRequest()->getActionName();
        if($module && $controller && $action)
            $this->redirect($module.'/'.$controller.'/list');
    }
}
