<?php
/*
 *CRUD for seo
 * 
 */

class Admin_ScholarshipController extends BaseApp_Controller_Crud {
    
    public function indexAction() {
        
    }
    
    public function pendingApprovalAction() {
      $db = new Model_Default();
      $status = !empty($this->getRequest()->getParam('success')) ? $this->getRequest()->getParam('success') : NULL ;
      $this->view->status = $status;
      
      $data = $db->ScholarshipApplications->find(array('TypeScholarship' => 'simplilearn', 'verified' => 1,'approved'=>0))->toArray(FALSE); 
      $this->view->dataStudent = $data;
    }
    
    public function pendingVerifyAction() {
      $db = new Model_Default();
      $data = $db->ScholarshipApplications->find(array('TypeScholarship' => 'simplilearn', 'processed' => 1,  'verified' => 0,))->toArray(FALSE);    
      $this->view->dataStudent = $data;
    }
    
    public function fullDetailsAction() {
      $db = new Model_Default();
      $id = $this->getRequest()->getParam('id');
        if (empty($id)) {
            throw new Zend_Controller_Action_Exception('Missing Ambassador Code', 404);
        }
      
      $data = current($db->ScholarshipApplications->find(array('_id' => new MongoId($id), 'TypeScholarship' => 'simplilearn'))->toArray(FALSE)); 
      $this->view->dataStudent = $data;
    }
    
    public function approveAction() {
        //Check for required request param
        $id = $this->getRequest()->getParam('id');
        $amb_code = substr($id,-8);
        $course_links = null;
        if (empty($id)) {
            throw new Zend_Controller_Action_Exception('Missing Ambassador Code', 404);
        }

        //Check for valid verification link in ScholarshipApplications collection
        $db = new Model_Default();
        $data = current($db->ScholarshipApplications->find(array('_id' => new MongoId($id), 'TypeScholarship' => 'simplilearn', 'verified' => 1))->toArray(FALSE));
        if (empty($data)) {
            throw new Zend_Controller_Action_Exception('Invalid Email verification link', 404);
        }

        if (!empty($data['approved']) && (int) $data['approved'] == 1) {
            $this->redirect("/scholarship/pending-approval?success=fail");
        }
        
        //Getting College Name
        $college_name = current($db->Colleges->find(array('hash' => $data['CurrentCollege']), array('_id'=>FALSE,'institution name' =>true))->toArray(FALSE));
        
        $available_courses_list = explode(',',SCHOLARSHIP_COURSE_LIST);
        foreach($available_courses_list as $key => $cid){
               $courseData_mongo = current($db->CoursePageHeader->find(
                            array('course_id' => (string) $cid), array('_id' => false,"displayName"=>true,"categoryName" => TRUE,"course_url" => true)
                    )->toArray()); 
               
               $url = array_reverse(explode('/', $courseData_mongo['course_url']));
               $course_links[$key]['url'] = SEO_FRONTEND_URL . "/students-free-access/" . $url[0] . "/". $data['CurrentCollege'] . $amb_code;
               $course_links[$key]['name'] = $courseData_mongo['displayName'];
               $course_links[$key]['share_text'] = $college_name['institution name'] . " students can get free access to Simplilearn.com’s " . $courseData_mongo['categoryName'] . " courses by visiting the site via this link. Graduation’s coming. Get prepared and get a great job." ;
        }
        //Mail the user that he is approved
        $mailer = new BaseApp_Mailer();
        $opts = Zend_Registry::get('config')->get('resources')->get('mail')->get('transport')->toArray();
        $mailer->setDefaultTransport(new Zend_Mail_Transport_Smtp($opts['host'], $opts));
        $mailer->setSubject('Simplilearn Student Ambassador Scholarship program | Application approved');
        $mailer->setReplyTo('scholarship@simplilearn.com');
        $mailer->setTemplate(BaseApp_Mailer::SCHOLARSHIP_SA_APPROVAL);
        $mailer->setVariables(array(
            'id' => $amb_code,
            'baseUrl' => FRONTEND_URL,
            'f_name' => $data['FirstName'],
            'link1' => $course_links[0]['url'],
            'link2' => $course_links[1]['url'],
            'link3' => $course_links[2]['url'],
            'cname1' => $course_links[0]['name'],
            'cname2' => $course_links[1]['name'],
            'cname3' => $course_links[2]['name'],
            's_text1' => $course_links[0]['share_text'],
            's_text2' => $course_links[1]['share_text'],
            's_text3' => $course_links[2]['share_text'],
            'twitter_text' => 'College%20students%20get%20free%20access%20to%20@Simplilearn%20course%20.%20Graduation%E2%80%99s%20coming.%20Get%20prepared%20&%20get%20a%20great%20job',
            'program_name' => 'Simplilearn Student Ambassador Scholarship program'
        ));
        $mailer->addTo($data['CollegeEmail']);
        $mailer->send();
        //Mail Ends Here 
        
        $data['approved'] = 1;
        $data['sAmbId'] = $amb_code;
        $db->ScholarshipApplications->update(array('_id' => new MongoId($id)), $data);
        $this->redirect(BACKEND_URL."/admin/scholarship/pending-approval?success=saved");
        //Changes made to cartcontroller will bypass step1 and step 2 and directly show thankyou page.
    }

}
