<?php

/*
 * Contains the CRUD actions of Accreditors table
 *
 */

class Admin_CompanyController extends BaseApp_Controller_Crud {

    const ALL_COURSES = 'all-courses';
    const ALL_MASTERS = 'all-masters';
    const TABBER_DETAIL_PAGE = 1;
    const TABBER_COURSE_PRICING = 2;
    const TABBER_CATEGORY_PRICING = 3;
    const ROWS_PER_LIST = 200;

    protected $_model = 'Model_ProductSectionData';
    public $bundleData2 = array();
    public $courseData2 = array();
    protected $_descriptions = array(
        'list' => 'List of Existing Enterprise Company',
        'index' => 'List of Existing Enterprise Company',
        'add' => 'Add New Enterprise Company',
        'edit' => 'Make the required changes then click on "Save Enterprise Company" to update the Enterprise Company',
        'view' => 'View Selected Enterprise Company'
    );
    
    protected function _getForm($id = '') {
        $form = new Form_Company($id);
        return $form;
    }
    public function priceListAction()
    {
        $companyId = $this->getRequest()->getParam('id');
        $page = '';
        if (empty($page)) {
            $page = $this->view->navigatorPage;
            $page = (int)$this->getRequest()->getParam('page');
        }
        if ($page <= 1) {
            $this->view->firstpage = true;
            $page = 1;
        } else {
            $this->view->firstpage = false;
        }
        $offset = ($page - 1) * self::ROWS_PER_LIST;
        $limit = array(self::ROWS_PER_LIST, $offset);
        $this->view->page = $page;
        $b2bProPriObj = new Model_B2BProductPricing();
        $limiteddata = $b2bProPriObj->getPricingData($companyId, $limit);
        $this->view->productPricingInfo = !empty($limiteddata) ? $limiteddata : array();
        $productData = $b2bProPriObj->getPricingData($companyId);


        $b2bFlatPriObj = new Model_B2BFlatPricing();
        $flatPricingData = $b2bFlatPriObj->getPricingData($companyId, $limit);
        $this->view->flatPricingInfo = !empty($flatPricingData) ? $flatPricingData : array();
        $flatData = $b2bFlatPriObj->getPricingData($companyId);

        $data = array_merge($productData, $flatData);
        $total = count($data);
        $numberOfPages = ceil($total / self::ROWS_PER_LIST);
        if ($numberOfPages == $page) {
            $this->view->lastpage = true;
        } else {
            $this->view->lastpage = false;
        }
    }
    public function coursePricingAction() {
        $this->view->activeTab = self::TABBER_COURSE_PRICING;
        $request = $this->getRequest()->getPost();
        $companyId = $this->getRequest()->getParam('id');
        if (!$companyId) {
            $this->view->message = "Company Id Is Missing";
            $this->view->success = false;
            return;
        }
        $session = new Zend_Session_Namespace('form');
        $leanerRangeInfo = $session->learnerRange;
        $lRModel = new Model_LearnersRange();
        $lRData = $lRModel->getByLinkable($companyId); //prd($learnerRangeData);
        $isHigherRangeAvilable = $this->_validateLearnerRange($lRData);
        if (!$isHigherRangeAvilable) {
            $this->view->message = "Learners Higher Range Missing.Please set the higher range to add.";
            $this->view->success = false;
            return;
        }
        $courseAdvisorData = array();
        $productSectionObj = new Model_ProductSectionData();
        $productSectionInfo = $productSectionObj->getByProduct($companyId, 'company');
        $agency = $productSectionObj->getAgencyData($companyId, 'agency');
        $agencyData = !empty($agency) ? current($agency):array();
        $agencyName = !empty($agencyData['name']) ?$agencyData['name'] :'';
        $companyPricePlan = !empty($productSectionInfo[0]['company_price_plans']) ? $productSectionInfo[0]['company_price_plans'] : 0;
        $courseAdvisorData['company_pricing_plan'] = $companyPricePlan;
        if (empty($companyPricePlan)) {
            $this->view->message = "Company Pricing Plan Doesn't Exist !";
            $this->view->success = false;
            return;
        }
        $form = new Form_CompanyCoursePricing($companyId);
        $compProductObj = new Model_CompanyProductMapper();
        $categoryData = $compProductObj->fetchAll(array('company_id =?' => $companyId, 'linkable_type = ?' => 'category', 'status = ?' => 1), array('order' => 'order'));
        if (!empty($categoryData)) {
            $session = new Zend_Session_Namespace('form');
            $categorieIdArr = array_column($categoryData, 'linkable_id');
            $obj = new Model_Labels();
            $categoryList = $obj->getLabelsToshow();
            $categoryFilter = array_intersect_key($categoryList, array_flip($categorieIdArr));
            $categoryFilter = array('0' => '--Select--') + $categoryFilter;
            /**
             * Product category
             */
            $form->getSubForm('companyPricingCourse')
                    ->getSubForm('new')
                    ->getElement('product_category')
                    ->addMultiOptions($categoryFilter);
            $this->_setProductCategory($courseAdvisorData);
            $this->__setCompanyPricingCourse($request);
            /**
             * Fetch Flat Pricing Data
             */
            $b2bFlatPriObj = new Model_B2BFlatPricing();
            $flatPricingData = $b2bFlatPriObj->getPricingData($companyId);
            $this->view->flatPricingInfo = !empty($flatPricingData) ? $flatPricingData : array();
            if (!empty($this->view->flatPricingInfo)) {
                $courseAdvisorData['is_b2b_flat_pricing'] = 1;
            }
        } else {
            $this->view->message = "No Data Available For Company";
            $this->view->success = false;
            return;
        }

        if (!empty($request['companyPricingCourse'])) {
            $productCategory = $request['companyPricingCourse']['new']['product_category'];
            $productType = $request['companyPricingCourse']['new']['product_type'];
            //$courseAdvisorData['product_category']=array();
            $form->getSubForm('companyPricingCourse')
                    ->getSubForm('new')
                    ->getElement('product_category')
                    ->addMultiOptions($categoryFilter);
            if ($productType == "osl" || $productType == "lvc") {
                $filteredCourses = array('0' => '');
                if (ctype_digit($productCategory)) {
                    $course = new Model_Courses();
                    $courseData = $course->fetchCoursesByLabels(array($productCategory), 1);
                    $b2bExcObj = new Model_B2bProductExclusions();
                    $excCoursesData = $b2bExcObj->fetchAll(array('company_id =?' => $companyId, 'linkable_type = ?' => 'course', 'status = ?' => 1));
                    $agencyCoursesData = array();
                    if (!empty($agencyName)) {
                        $agencyCourses = $course->fetchCoursesByLabelsBasedOnAgency(array($productCategory), $agencyName);
                        if (!empty($agencyCourses)) {
                            $agencyCoursesData = array_column($agencyCourses, 'name', 'linkable_id');
                        }
                    }
                    if (!empty($excCoursesData)) {
                        $filteredCourses = array();
                        $excludedCourses = array_column($excCoursesData, 'linkable_id');
                        $filteredCourses = array_diff_key($courseData, array_flip($excludedCourses));
                        $filteredCourses = array('0' => '--All Course--') + $filteredCourses;
                    } else {
                        $filteredCourses = array('0' => '--All Course--') + $courseData;
                    }
                } else if ($productCategory == "allcategories") {
                    $filteredCourses = array('0' => '--All Categories Courses--');
                }
                if(!empty($agencyCoursesData)){
                    $filteredCourses = $filteredCourses + $agencyCoursesData;
                }
                $form->getSubForm('companyPricingCourse')
                        ->getSubForm('new')
                        ->getElement('product_list')
                        ->addMultiOptions($filteredCourses);
            } else if ($productType == "mp") {
                $filteredMasterProgram = array();
                if (ctype_digit($productCategory)) {
                    $bundle = new Model_Bundles();
                    $bundleData = $bundle->getBundleListByLabelId(array($productCategory),1);
                    $bundleData = array_column($bundleData, 'display_name', 'bundle_id');
                    $agencyBundleData = array();
                    if (!empty($agencyName)) {
                        $agencyBundleData = $bundle->getBundlesAgency(array($productCategory), $agencyName);
                        $agencyBundleData = !empty($agencyBundleData)? array_column($agencyBundleData, 'display_name', 'bundle_id'):array();
                    }
                    $b2bExcObj = new Model_B2bProductExclusions();
                    $excMasterProgramData = $b2bExcObj->fetchAll(array('company_id =?' => $companyId, 'linkable_type = ?' => 'bundle', 'status = ?' => 1));
                    if (!empty($excMasterProgramData)) {
                        $excludedMasterProgram = array_column($excMasterProgramData, 'linkable_id');
                        $filteredMasterProgram = array_diff_key($bundleData, array_flip($excludedMasterProgram));
                        $filteredMasterProgram = array('0' => '--All Master Programs --') + $filteredMasterProgram;
                    } else {
                        $filteredMasterProgram = array('0' => '--All Master Programs --') + $bundleData;
                    }
                } else if ($productCategory == "allcategories") {
                    $filteredMasterProgram = array('0' => '--All Categories Master--');
                }
                if (!empty($agencyBundleData)) {
                    $filteredMasterProgram  =  $filteredMasterProgram + $agencyBundleData;
                }
                $form->getSubForm('companyPricingCourse')
                        ->getSubForm('new')
                        ->getElement('product_list')
                        ->addMultiOptions($filteredMasterProgram);
            }

            /*
             * Cluster
             */
            if (!empty($request['cluster_id'])) {
                $label = $form->getSubForm('companyPricingCourse')
                                ->getSubForm('new')->getElement('cluster_id')->getDecorator('Label');
                $label->setOption('style', 'display: block;');
            }
            /**
             * Country 
             */
            if (!empty($request['country_id'])) {
                $label = $form->getSubForm('companyPricingCourse')
                                ->getSubForm('new')->getElement('country_id')->getDecorator('Label');
                $label->setOption('style', 'display: block;');
            }
            /**
             * Final Product List.
             */
            if (!empty($request['finalSelectedCourses'])) {
                $finalSelectedCourseList = json_decode($request['finalSelectedCourses'], true);
                $form->getSubForm('companyPricingCourse')
                        ->getSubForm('new')
                        ->getElement('final_product_list')
                        ->addMultiOptions($finalSelectedCourseList);
            }
        }


        if (($this->getRequest()->isPost()) && !empty($request) && $form->isValid($request)) {
            if (!empty($request['companyPricingCourse'])) {
                $productInfo = array();
                $productPricingData = $flatPricingData = array();
                $productCoursePricingData = $request['companyPricingCourse'];
                $finalCourseIds = $productType = $productLinkableType = "";
                $productIds = array();
                $countryId = $clusterId = $trainingId = 0;
                $isB2BFlatPricing = $isB2BProductPricing = false;
                $b2bCartPricing = new Model_B2bCartPricing();
                foreach ($productCoursePricingData as $type => $relatedData) {
                    if ($type !== '__template__') {
                        if ((strtolower($relatedData['final_course_ids']) == self::ALL_COURSES) || (strtolower($relatedData['final_course_ids']) == self::ALL_MASTERS)) {
                            $isB2BFlatPricing = true;
                        } else {
                            $isB2BProductPricing = true;
                        }
                        if (empty($finalCourseIds)) {
                            $finalCourseIds = rtrim($relatedData['final_course_ids'], ',');
                            $productIds = explode(',', $finalCourseIds);
                        }
                        if (empty($productType)) {
                            $productType = $relatedData['product_type'];
                        }
                        if (empty($countryId)) {
                            $countryId = $relatedData['country_id'];
                        }
                        if (empty($clusterId)) {
                            $clusterId = $relatedData['cluster_id'];
                        }
                        if (empty($trainingId)) {
                            $trainingId = $relatedData['training_id'];
                        }
                        unset($relatedData['final_course_ids']);
                        if (count($productIds) > 0) {
                            foreach ($productIds as $pid) {
                                $productInfo = array();
                                $linkableType = '';

                                if ($productType == 'osl' || $productType == 'lvc') {
                                    $productLinkableType = $linkableType = 'course';
                                } else if ($productType == 'mp') {
                                    $productLinkableType = $linkableType = 'bundle';
                                }
                                if (empty($relatedData['flat_price'])) {
                                    $relatedData['flat_price'] = 0;
                                }
                                if ($isB2BFlatPricing) {
                                    $discount = $relatedData['flat_price'] > 0 ? ($relatedData['flat_price'] * $relatedData['flat_discount']) / 100 : 0;
                                    $productInfo['linkable_type'] = $linkableType;
                                    $productInfo['training_id'] = $trainingId;
                                    $productInfo['access_day_id'] = $relatedData['access_day_id'];
                                    $productInfo['learners_range_id'] = $relatedData['learners_range_id'];
                                    $productInfo['flat_price'] = $relatedData['flat_price'];
                                    $productInfo['flat_discount'] = $relatedData['flat_discount'];
                                    $productInfo['company_id'] = $companyId;
                                    $productInfo['status'] = 1;
                                    $productInfo['country_id'] = $countryId;
                                    $productInfo['cluster_id'] = $clusterId;
                                    $productInfo['price'] = $relatedData['flat_price'] - $discount;
                                    /**
                                     * Removing Learners Range Min & Max
                                     */
                                    //$productInfo['learners_range_min'] = $relatedData['learners_range_min'];
                                    //$productInfo['learners_range_max'] = $relatedData['learners_range_max'];
                                    $flatPricingData[] = $productInfo;
                                } else {
                                    $discount = $relatedData['flat_price'] > 0 ? ($relatedData['flat_price'] * $relatedData['flat_discount']) / 100 : 0;
                                    $productInfo['linkable_type'] = $linkableType;
                                    $productInfo['linkable_id'] = $pid;
                                    $productInfo['training_id'] = $trainingId;
                                    $productInfo['access_day_id'] = $relatedData['access_day_id'];
                                    $productInfo['learners_range_id'] = $relatedData['learners_range_id'];
                                    $productInfo['flat_price'] = $relatedData['flat_price'];
                                    $productInfo['flat_discount'] = $relatedData['flat_discount'];
                                    $productInfo['company_id'] = $companyId;
                                    $productInfo['status'] = 1;
                                    $productInfo['country_id'] = $countryId;
                                    $productInfo['cluster_id'] = $clusterId;
                                    $productInfo['price'] = $relatedData['flat_price'] - $discount;
                                    /**
                                     * Removing Learners Min & Max
                                     */
                                    //$productInfo['learners_range_min'] = $relatedData['learners_range_min'];
                                    //$productInfo['learners_range_max'] = $relatedData['learners_range_max'];
                                    $productPricingData[] = $productInfo;
                                }
                            }
                        }
                    }
                }
                /**
                 * B2B Product Pricing 
                 */
                if (!empty($productPricingData) && $isB2BProductPricing) {
                    $b2bProPriObj = new Model_B2BProductPricing();
                    foreach ($productPricingData as $ppricingData) {
                        $b2bProPriObj->saveB2BPricingData($companyId, $ppricingData);
                        $updateData = $b2bProPriObj->toArray();
                        $currentId = $b2bProPriObj->getCurrentId();
                        $flag = "product_price";
                        $returnData = $b2bCartPricing->createB2bCartPricing($companyId,$currentId,$updateData,$flag);
                        if(!is_array($returnData)){
                           $b2bProPriObj->updateSyncStatus($currentId);
                        }
                       
                    }
                    $module = $this->getRequest()->getModuleName();
                    $controller = $this->getRequest()->getControllerName();
                    $action = $this->getRequest()->getActionName();
                    
                    $this->redirect($module . '/' . $controller . '/' . $action . '/id/' . $companyId);
                }
                /**
                 * B2B Flat Pricing
                 */
                if (!empty($flatPricingData) && $isB2BFlatPricing) {
                    $b2bFlatPriObj = new Model_B2BFlatPricing();
                    foreach ($flatPricingData as $flatPricingDatas) {
                        $linkableType = !empty($flatPricingDatas['linkable_type']) ? $flatPricingDatas['linkable_type'] : "";
                        $countryId = !empty($flatPricingDatas['country_id']) ? $flatPricingDatas['country_id'] : 0;
                        $clusterId = !empty($flatPricingDatas['cluster_id']) ? $flatPricingDatas['cluster_id'] : 0;
                        $trainingId = !empty($flatPricingDatas['training_id']) ? $flatPricingDatas['training_id'] : "";
                        $b2bFlatPriObj->saveB2BPricingInfo($companyId, $linkableType, $countryId, $clusterId, $trainingId, $flatPricingDatas);
                        $updateData = $b2bFlatPriObj->toArray();
                        $currentId = $b2bFlatPriObj->getCurrentId();
                        $flag = "flat_price";
                        $returnData = $b2bCartPricing->createB2bCartPricing($companyId,$currentId,$updateData,$flag);
                        if(!is_array($returnData)){
                            $b2bFlatPriObj->updateSyncStatus($currentId);
                        }
                    }
                    $module = $this->getRequest()->getModuleName();
                    $controller = $this->getRequest()->getControllerName();
                    $action = $this->getRequest()->getActionName();
                    $this->redirect($module . '/' . $controller . '/' . $action . '/id/' . $companyId);
                }
            }
        }

        $form->setDefaults($courseAdvisorData);
        $this->view->istabsEnabled = true;
        $this->view->success = true;
        $this->view->companyId = $companyId;
        $this->view->form = $form;
    }

    public function coursePricingEditAction() {
        $this->view->activeTab = self::TABBER_COURSE_PRICING;
        $request = $this->getRequest()->getPost();
        $companyId = $this->getRequest()->getParam('id');
        $ppids = $this->getRequest()->getParam('ppids');
        $ptype = $this->getRequest()->getParam('ptype');
        if (!$companyId) {
            $this->view->message = "Company Id Is Missing";
            $this->view->success = false;
            return;
        }
        if (!$ppids) {
            $this->view->message = "Error.Ids not available";
            $this->view->success = false;
            return;
        }
        $learnerRangeModel = new Model_LearnersRange();
        $learnerRangeData = $learnerRangeModel->getByLinkable($companyId); 
        if (!empty($learnerRangeData)) {
            foreach ($learnerRangeData as &$row) {
                $row['learners_range_id'] = $row['id'];
                $row['company_id'] = $companyId;
            }
        }
        $learnersRange['learnerRange'] = $learnerRangeData;
        $this->_setLearnerRange($learnersRange);
        if (($this->getRequest()->isPost()) && !empty($request)) {
            $isB2BProductPricing = empty($request['is_flat']) ? true : false;
            if (!empty($request['companyPricingCourse'])) {
                $productInfo = array();
                $productPricingData = $flatPricingData = array();
                $originalPricingIds = $request['original_ppids'];
                $productCoursePricingData = $request['companyPricingCourse'];
                $finalCourseIds = $productType = "";
                $productIds = array();
                $countryId = $clusterId = $trainingId = 0;
                
                foreach ($productCoursePricingData as $type => $relatedData) {
                    if ($type !== '__template__') {
                        if (empty($finalCourseIds)) {
                            $finalCourseIds = rtrim($relatedData['final_course_ids'], ',');
                            $productIds = explode(',', $finalCourseIds);
                        }
                        if (empty($productType)) {
                            $productType = $relatedData['product_type'];
                        }
                        if (empty($countryId)) {
                            $countryId = $relatedData['country_id'];
                        }
                        if (empty($clusterId)) {
                            $clusterId = $relatedData['cluster_id'];
                        }
                        if (empty($trainingId)) {
                            $trainingId = $relatedData['training_id'];
                        }
                        unset($relatedData['final_course_ids']);
                        if (count($productIds) > 0) {
                            foreach ($productIds as $pid) {
                                $productInfo = array();
                                $linkableType = '';
                                
                                if ($productType == 'osl' || $productType == 'lvc') {
                                    $linkableType = 'course';
                                } else if ($productType == 'mp') {
                                    $linkableType = 'bundle';
                                }
                                if (empty($relatedData['flat_price'])) {
                                    $relatedData['flat_price'] = 0;
                                }
                                
                                if ($isB2BProductPricing) {
                                    $discount = $relatedData['flat_price'] > 0 ? ($relatedData['flat_price'] * $relatedData['flat_discount']) / 100 : 0;
                                    $productInfo['linkable_type'] = $linkableType;
                                    $productInfo['linkable_id'] = $pid;
                                    $productInfo['training_id'] = $trainingId;
                                    $productInfo['access_day_id'] = $relatedData['access_day_id'];
                                    $productInfo['learners_range_id'] = $relatedData['learners_range_id'];
                                    $productInfo['flat_price'] = $relatedData['flat_price'];
                                    $productInfo['flat_discount'] = $relatedData['flat_discount'];
                                    $productInfo['company_id'] = $companyId;
                                    $productInfo['status'] = 1;
                                    $productInfo['country_id'] = $countryId;
                                    $productInfo['cluster_id'] = $clusterId;
                                    $productInfo['price'] = $relatedData['flat_price'] - $discount;
                                    //$productInfo['learners_range_min'] = $relatedData['learners_range_min'];
                                    //$productInfo['learners_range_max'] = $relatedData['learners_range_max'];
                                    $productPricingData[] = $productInfo;
                                } else {
                                    $discount = $relatedData['flat_price'] > 0 ? ($relatedData['flat_price'] * $relatedData['flat_discount']) / 100 : 0;
                                    $productInfo['linkable_type'] = $linkableType;
                                    $productInfo['training_id'] = $trainingId;
                                    $productInfo['access_day_id'] = $relatedData['access_day_id'];
                                    $productInfo['learners_range_id'] = $relatedData['learners_range_id'];
                                    $productInfo['flat_price'] = $relatedData['flat_price'];
                                    $productInfo['flat_discount'] = $relatedData['flat_discount'];
                                    $productInfo['company_id'] = $companyId;
                                    $productInfo['status'] = 1;
                                    $productInfo['country_id'] = $countryId;
                                    $productInfo['cluster_id'] = $clusterId;
                                    $productInfo['price'] = $relatedData['flat_price'] - $discount;
                                    //$productInfo['learners_range_min'] = $relatedData['learners_range_min'];
                                    //$productInfo['learners_range_max'] = $relatedData['learners_range_max'];
                                    $flatPricingData[] = $productInfo;
                                }
                            }
                        }
                    }
                }
                $b2bCartPricing = new Model_B2bCartPricing();
                if (!empty($productPricingData) && $isB2BProductPricing) {
                    $b2bProPriObj = new Model_B2BProductPricing();
                    $newIds  = $b2bProPriObj->updateB2BPricingData($companyId, $productPricingData, $originalPricingIds);
                    $originalPricingIds =  is_array($originalPricingIds) ? $originalPricingIds : explode(',', $originalPricingIds);
                    $originalPricingIds = !empty($originalPricingIds) && !empty($newIds) ? array_merge($originalPricingIds,$newIds) : $originalPricingIds;
                    foreach ($productPricingData as $key => $productPricing) {
                        $currentId = !empty($originalPricingIds[$key]) ? $originalPricingIds[$key] : "";
                        $flag = "product_price";
                        $returnData = $b2bCartPricing->updateB2bCartPricing($companyId, $currentId, $productPricing, $flag);
                        if (!is_array($returnData)) {
                            $b2bProPriObj->updateSyncStatus($currentId);
                        }
                    }
                    $module = $this->getRequest()->getModuleName();
                    $controller = $this->getRequest()->getControllerName();
                    // $action = $this->getRequest()->getActionName();
                    $this->redirect($module . '/' . $controller . '/course-pricing/id/' . $companyId);
                } else {
                    $linkableTypeArr = array_column($flatPricingData, 'linkable_type');
                    $linkableType = array_unique($linkableTypeArr)[0];
                    $countryIdArr = array_column($flatPricingData, 'country_id');
                    $countryId = array_unique($countryIdArr)[0];
                    $clusterIdArr = array_column($flatPricingData, 'cluster_id');
                    $clusterId = array_unique($clusterIdArr)[0];
                    $trainingIdArr = array_column($flatPricingData, 'training_id');
                    $trainingId = array_unique($trainingIdArr)[0];
                    $b2bFlatPriObj = new Model_B2BFlatPricing();
                    $b2bFlatPriObj->saveB2BPricingInfo($companyId, $linkableType, $countryId, $clusterId, $trainingId, $flatPricingData);
                    $originalPricingIds =  is_array($originalPricingIds) ? $originalPricingIds : explode(',', $originalPricingIds);
                    foreach ($flatPricingData as $key => $flatPricing) {
                        $currentId = !empty($originalPricingIds[$key]) ? $originalPricingIds[$key] : "";
                        $flag = "flat_price";
                        $returnData = $b2bCartPricing->updateB2bCartPricing($companyId, $currentId, $flatPricing, $flag);
                        if (!is_array($returnData)) {
                            $b2bFlatPriObj->updateSyncStatus($currentId);
                        }
                    }
                    $module = $this->getRequest()->getModuleName();
                    $controller = $this->getRequest()->getControllerName();
                    // $action = $this->getRequest()->getActionName();
                    $this->redirect($module . '/' . $controller . '/course-pricing/id/' . $companyId);
                }
            }
        }
        $productPricingIds = urldecode($ppids);
        $compProductObj = new Model_CompanyProductMapper();
        $categoryData = $compProductObj->fetchAll(array('company_id =?' => $companyId, 'linkable_type = ?' => 'category', 'status = ?' => 1), array('order' => 'order'));
        $courseAdvisorData = array();
        if (!empty($categoryData)) {
            $session = new Zend_Session_Namespace('form');
            $categorieIdArr = array_column($categoryData, 'linkable_id');
            $obj = new Model_Labels();
            $categoryList = $obj->getLabelsToshow();
            $categoryFilter = array_intersect_key($categoryList, array_flip($categorieIdArr));
            $categoryFilter = array('0' => '--Select--') + $categoryFilter;
            $courseAdvisorData['product_category'] = $categoryFilter;
            $this->_setProductCategory($courseAdvisorData);
            $this->__setCompanyPricingCourse($request);
        } else {
            $this->view->message = "No Data Available For Company";
            $this->view->success = false;
            return;
        }
        $form = new Form_CompanyCoursePricing($companyId, true, $productPricingIds, $ptype);
        $this->view->istabsEnabled = true;
        $this->view->success = true;
        $this->view->companyId = $companyId;
        $this->view->form = $form;
    }

    public function categoryPricingAction() {
        $this->view->activeTab = self::TABBER_CATEGORY_PRICING;
        $request = $this->getRequest()->getPost();
        $this->__setCompanyPricingCat($request);
        $companyId = $this->getRequest()->getParam('id');
        $ppids = $this->getRequest()->getParam('ppids', 0);
        $ptype = $this->getRequest()->getParam('ptype', 0);
        $b2bCartPricing = new Model_B2bCartPricing();
        

        if (!$companyId) {
            $this->view->message = "Company Id Is Missing";
            $this->view->success = false;
            return;
        }
        
        $learnerRangeModel = new Model_LearnersRange();
        $learnerRangeData = $learnerRangeModel->getByLinkable($companyId); 
        if (!empty($learnerRangeData)) {
            foreach ($learnerRangeData as &$row) {
                $row['learners_range_id'] = $row['id'];
                $row['company_id'] = $companyId;
            }
        }
        $courseAdvisorData['learnerRange'] = $learnerRangeData;
        $this->_setLearnerRange($courseAdvisorData);
        if (!empty($companyId) && !empty($ppids) && !empty($ptype)) {
            $ppids = urldecode($ppids);
            $ppidsArr = explode(',', $ppids);
            $b2bProPriObj = new Model_B2BProductPricing();
            $productPricingData = $b2bProPriObj->getCategoryPricingDataById($companyId, $ppidsArr, $ptype);
            $categoryDetails = array();
            if (!empty($productPricingData)) {
                foreach ($productPricingData as $key => $row) {
                    $categoryDetails['companyPricingCat'][$key] = array(
                        'linkable_id_prod' => !empty($row['linkable_id']) ? $row['linkable_id'] : 0,
                        'linkable_type' => 'category',
                        'location_mode' => !empty($row['cluster_id']) ? 1 : 2,
                        'country_id' => $row['country_id'],
                        'cluster_id' => $row['cluster_id'],
                        // 'learners_range_min' => $row['learners_range_min'],
                        // 'learners_range_max' => $row['learners_range_max'],
                        'access_day_id' => $row['access_day_id'],
                        'training_id' => $row['training_id'],
                        'flat_price' => $row['price'],
                        'flat_discount' => $row['discount']
                    );
                }
                if (!empty($categoryDetails)) {
                    $this->__setCompanyPricingCat($categoryDetails);
             }
            }
        }
        $form = new Form_CompanyCategoryPricing($companyId);
        if ($this->getRequest()->isPost() && !empty($request) && $form->isValid($request)) {
            $obj = new Model_ProductSectionData();
            $objSM = new Model_SectionMapping();
            $b2bPriObj = new Model_B2BFlatPricing();
            $b2bExcObj = new Model_B2bProductExclusions();
            $b2bProPriObj = new Model_B2BProductPricing();
            $compProductObj = new Model_CompanyProductMapper();
            
            $data = $form->getValues();
            $data['category_id'] = 0;
            $data['excluded_course_ids'] = array();
            /**
             * Linkable Product Id
             */
            $categoriesId = array_column($request['companyPricingCat'], 'linkable_id_prod');
            //$categoriesId = array_filter($categoriesId);
            $categoriesId = array_unique($categoriesId);
            if (empty($categoriesId)) {
                //  throw new BaseApp_Exception('Category Id Is Empty.');
            }
            $countryId = $clusterId = $pricingLevel = 0;
            /**
             * Pricing Level
             */
            $pricingLevel = array_column($request['companyPricingCat'], 'location_mode');
            $pricingLevel = array_filter($pricingLevel);
            $pricingLevel = array_unique($pricingLevel);
            $pricingLevel = array_values($pricingLevel);
            $pricingLevelVal = !empty($pricingLevel[0]) ? $pricingLevel[0] : 0;
            if ($pricingLevelVal) {
                if ($pricingLevelVal == 1) {
                    $clusterIdVals = array_column($request['companyPricingCat'], 'cluster_id');
                    $clusterIdVals = array_filter($clusterIdVals);
                    $clusterIdVals = array_unique($clusterIdVals);
                    $clusterIdVals = array_values($clusterIdVals);
                    $clusterId = !empty($clusterIdVals[0]) ? $clusterIdVals[0] : 0;
                } elseif ($pricingLevelVal == 2) {
                    $countryIdVals = array_column($request['companyPricingCat'], 'country_id');
                    $countryIdVals = array_filter($countryIdVals);
                    $countryIdVals = array_unique($countryIdVals);
                    $countryIdVals = array_values($countryIdVals);
                    $countryId = !empty($countryIdVals[0]) ? $countryIdVals[0] : 0;
                }
            }

            /**
             * Country Id
             */
            $categoriesId = array_values($categoriesId);
            $data = $request;
            $data['category_id'] = $linkableProdId = !empty($categoriesId[0]) ? $categoriesId[0] : 0;
            $splitData = $this->_handleDataAfterSubmit($data);
            if (!empty($splitData) && !empty($splitData['companyPricingCat'])) {
                $prodPricingCat = array();
                foreach ($splitData['companyPricingCat'] as $key => $pricing) {
                    if (!empty($pricing) && !empty($pricing['flat_discount'])) {
                        $splitData['companyPricingCat'][$key]['price'] = $pricing['flat_price'] - (($pricing['flat_discount'] * $pricing['flat_price']) / 100);
                    } else {
                        $splitData['companyPricingCat'][$key]['price'] = $pricing['flat_price'];
                    }
                    if (!empty($splitData['companyPricingCat'][$key]['location_mode'])) {
                        if ($splitData['companyPricingCat'] [$key]['location_mode'] == 1) {
                            unset($splitData['companyPricingCat'][$key]['country_id']);
                        }
                        if ($splitData['companyPricingCat'] [$key]['location_mode'] == 2) {
                            unset($splitData['companyPricingCat'][$key]['cluster_id']);
                        }
                        unset($splitData['companyPricingCat'][$key]['location_mode']);
                    } else {
                        unset($splitData['companyPricingCat'][$key]);
                    }
                    if (isset($splitData['companyPricingCat'][$key]['linkable_id_prod'])) {
                        $splitData['companyPricingCat'][$key]['linkable_id'] = $splitData['companyPricingCat'][$key]['linkable_id_prod'];
                        unset($splitData['companyPricingCat'][$key]['linkable_id_prod']);
                        if ($splitData['companyPricingCat'] [$key]['linkable_id'] > 0) {
                            $splitData['companyPricingCat'][$key]['linkable_type'] = 'category';
                            $prodPricingCat[$key] = $splitData['companyPricingCat'][$key];
                            $prodPricingCat[$key]['company_id'] = $companyId;
                            unset($splitData['companyPricingCat'][$key]);
                        } else {
                            $splitData['companyPricingCat'][$key]['linkable_type'] = 'category';
                            unset($splitData['companyPricingCat'][$key]['linkable_id']);
                        }
                    }
                }

                $success = false;
                if (!empty($splitData['companyPricingCat'])) {
                    foreach ($splitData['companyPricingCat'] as $key => $value) {
                        unset($splitData['companyPricingCat'][$key]['learners_range_min']);
                        unset($splitData['companyPricingCat'][$key]['learners_range_max']);
                    }
                    $success = true;
                    foreach($splitData['companyPricingCat'] as $pricingData){
                    $priResult = $b2bPriObj->saveB2BPricingData($companyId, 'category', $pricingData, $countryId, $clusterId);
                    $updateData = $b2bPriObj->toArray();
                    $currentId = $b2bPriObj->getCurrentId();
                    $flag = "flat_price";
                        if (empty($ppids)) {
                            $returnData = $b2bCartPricing->createB2bCartPricing($companyId, $currentId, $pricingData, $flag);
                        } else {
                                $returnData = $b2bCartPricing->updateB2bCartPricing($companyId, $currentId, $pricingData, $flag);
                        }
                        if (!is_array($returnData)) {
                            $b2bPriObj->updateSyncStatus($currentId);
                        }
                        
                }
            }
            if (!empty($prodPricingCat)) {
                foreach ($prodPricingCat as $key => $value) {
                    unset($prodPricingCat[$key]['learners_range_min']);
                    unset($prodPricingCat[$key]['learners_range_max']);
                }
                $success = true;
                $params = array('companyId' => $companyId, 'countryId' => $countryId, 'clusterId' => $clusterId, 'linkableId' => $linkableProdId);
                foreach ($prodPricingCat as $prodPricing) {    
                    $priResult = $b2bProPriObj->saveB2BCategoryPricingData($params, 'category', $prodPricing);
                    $updateData = $b2bProPriObj->toArray();
                    $currentId = $b2bProPriObj->getCurrentId();
                    $flag = "product_price";
                    if (empty($ppids)) {
                        $returnData = $b2bCartPricing->createB2bCartPricing($companyId, $currentId, $prodPricing, $flag);
                    }else {
                            $returnData = $b2bCartPricing->updateB2bCartPricing($companyId, $currentId, $prodPricing, $flag);
                    }
                    if (!is_array($returnData)) {
                        $b2bProPriObj->updateSyncStatus($currentId);
                    }
                    
                }
            }
                if ($success) {
                    $form->reset();
                    $request = array();
                    $this->__setCompanyPricingCat($request);
                    $this->view->message = "Saved SuccessFully";
                    $this->view->success = true;
                    $module = $this->getRequest()->getModuleName();
                    $controller = $this->getRequest()->getControllerName();
                    $action = $this->getRequest()->getActionName();
                    if ($module && $controller && $action) {
                        $this->redirect($module . '/' . $controller . '/category-pricing/id/' . $companyId);
                    }
                }
            }
        }

        /**
         * Fetch  Product Pricing Data
         */
        $b2bProPriObj = new Model_B2BProductPricing();
        $productPricingData = $b2bProPriObj->getCategoryPricingData($companyId);

        $this->view->productPricingInfo = !empty($productPricingData) ? $productPricingData : array();

        /**
         * Fetch Flat Pricing Data
         */
        $b2bFlatPriObj = new Model_B2BFlatPricing();
        $flatPricingData = $b2bFlatPriObj->getCategoryPricingData($companyId);
        $this->view->flatPricingInfo = !empty($flatPricingData) ? $flatPricingData : array();
        $this->view->pricingData = array_merge($productPricingData, $flatPricingData);
        $this->view->success = true;
        $this->view->companyId = $companyId;
        $this->view->form = $form;
    }

    public function addAction() {
        $request = $this->getRequest()->getPost();
        $this->_setCompanyAgencies($request);
        $this->_setLearnerRange($request);
        $form = $this->_getForm();
        $this->view->agencyList = SelfServePortal_Utility::getUnmappedAgencies();
        $data = $form->getValues();
        $course = new Model_Courses();
        $b2bCompanies = new Model_B2BCompanies();
        if (!empty($request['category_id'])) {
            $categorieIdArr = explode(',', $request['category_id']);
            /**
             * Course Exclusion
             */ 
            $categorieIdArr = explode(',', $request['category_id']);
            $agencyName = $request['companyAgencies']['new']['agencyName'];
            $courseData = $course->fetchCoursesByLabelsBasedOnAgency($categorieIdArr,'');
            if (!empty($courseData)) {
                $courseData = array_column($courseData, 'name', 'linkable_id');
            }
            $this->courseData2 = $course->fetchCoursesByLabelsBasedOnAgency($categorieIdArr,$agencyName);
            $courseData2 = array();
            if (!empty($this->courseData2)) {
                $courseData2 = array_column($this->courseData2, 'name', 'linkable_id');
            }
            // $courseData = $courseData + $courseData2;
            $form->getElement('exclusion_courses')->addMultiOptions($courseData);
            /**
             * End Of Course Exclusion
             */
            /**
             * Bundle Exclusion
             */

            $bundle = new Model_Bundles();
            $bundleList = $bundle->fetchBundlesByLabelsBasedOnAgency($categorieIdArr,'');
            $bundleData = array();
            if (!empty($bundleList)) {
                $bundleData = array_column($bundleList, 'display_name', 'linkable_id');
            }
            $this->bundleData2 = $bundle->fetchBundlesByLabelsBasedOnAgency($categorieIdArr,$agencyName);
            $bundleData2 = array();
            if (!empty($this->bundleData2)) {
                $bundleData2 = array_column($this->bundleData2, 'display_name', 'linkable_id');        
            }
            // $bundleData = $bundleData + $bundleData2;
            $form->getElement('exclusion_master_program')->addMultiOptions($bundleData);
            /**
             * End Of Bundle Exclusion.
             */
            /**
             * Category Filter.
             */
            $obj = new Model_Labels();
            $categoryList = $obj->getLabelsToshow();
            $categoryFilter = array_intersect_key($categoryList, array_flip($categorieIdArr));
            $categoryFilter = array('0' => '--Select--') + $categoryFilter;
            $form->getElement('category_filter')->addMultiOptions($categoryFilter);
            /**
             * End Of Category Filter.
             */
        }
        if ($request && $form->isValid($request)) {
            $obj = new Model_ProductSectionData();
            $objSM = new Model_SectionMapping();
            $b2bPriObj = new Model_B2BFlatPricing();
            $b2bExcObj = new Model_B2bProductExclusions();
            $b2bProPriObj = new Model_B2BProductPricing();
            $compProductObj = new Model_CompanyProductMapper();
            $learnerRangeObj = new Model_LearnersRange();
            $objAccounts = new BaseApp_Communication_Accounts();
            $objAgency = new BaseApp_Dao_B2bAgencyDetails();
            $data = $form->getValues();
            if (!empty($data['description'])) {
                $data['description'] = strtolower($data['description']);
            }
            $splitData = $this->_handleDataAfterSubmit($data);
            $partnerShipDetails = $splitData['partnershipDetails'];
            $headingInfo = array();
            $advantageInfo = array();
            $getStartSection = array();
            if(!empty($partnerShipDetails)){
                $headingInfo['name']= $partnerShipDetails['heading']? $partnerShipDetails['heading']:'';
                $headingInfo['description']= $partnerShipDetails['heading_content']? $partnerShipDetails['heading_content']:'';
                $advantageInfo['name'] = $partnerShipDetails['advantage_section']? $partnerShipDetails['advantage_section']:'';
                $advantageInfo['description'] = $partnerShipDetails['advantage_content']? $partnerShipDetails['advantage_content']:'';
                $getStartSection['name'] = $partnerShipDetails['getting_started_section']? $partnerShipDetails['getting_started_section']:'';
                $getStartSection['description'] = $partnerShipDetails['get_start_content']? $partnerShipDetails['get_start_content']:'';
            }

            unset($data['agency_dom_err']);
            unset($data['company_id']);

            $data['sectionType'] = 'company';
            $data['sectionTitle'] = null;

            $bannerImage = $data['bannerImageUrl'];
            $bannerText = $data['bannerSectionText'];
            $trainingTypes = array();
            $isMasterIncludedInPortal = false;
            if (!empty($data['isOsl'])) {
                $trainingTypes[BaseApp_Dao_TrainingTypes::TYPE_ELEARNING_NAME] = BaseApp_Dao_TrainingTypes::TYPE_ELEARNING;
            }
            if (!empty($data['isLvc'])) {
                $trainingTypes[BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS_NAME] = BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS;
            }
            if (!empty($data['isBundle'])) {
                $isMasterIncludedInPortal = true;
                $trainingTypes[BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES] = BaseApp_Dao_ProductTypes::TYPE_ID_BUNDLE;
            }
            unset($data['bannerImageUrl']);
            unset($data['bannerSectionText']);
            unset($data['category_filter']);
            unset($data['learnerRange']);
            unset($data['company_existing_price_plan']);
            unset($data['isOsl']);
            unset($data['isLvc']);
            unset($data['isBundle']);
            unset($data['heading']);
            unset($data['heading_content']);
            unset($data['advantage_section']);
            unset($data['advantage_content']);
            unset($data['getting_started_section']);
            unset($data['get_start_content']);

            $result = $obj->saveProductSectionData($data);
            
            $insertData = $obj->toArray();
            $Id = $result;
            $agencies = array();
            if ($result) {

                if (!empty($splitData) && !empty($splitData['category_id'])) {
                    $resultCPM = $compProductObj->saveProductMapping($result, 'category', array_filter($splitData['category_id']));
                }
                


                if(!empty($this->courseData2)) {
                    foreach($this->courseData2 as $b => $val) {
                        unset($this->courseData2[$b]['name']);
                    }
                }

                if(!empty($this->bundleData2)) {
                    foreach($this->bundleData2 as $b => $val) {
                        unset($this->bundleData2[$b]['display_name']);
                    }
                }
                
                $fullcourselist = array_merge($splitData['companyExcludedCourses'],$this->courseData2);
                $fullbundlelist = array_merge($splitData['companyExcludedMasterProgram'],$this->bundleData2);            
                $priResult = $b2bExcObj->saveB2BProductExclusions($Id, 'course', $fullcourselist);       
                $priResult = $b2bExcObj->saveB2BProductExclusions($Id, 'bundle', $fullbundlelist);


                if (!empty($splitData['learnerRange'])) {
                    $priResult = $learnerRangeObj->saveB2BLearnerRange($Id, $splitData['learnerRange']);
                }
                $agencyIdArr = array();
                if (!empty($splitData) && !empty($splitData['companyAgencies'])) {
                    foreach ($splitData['companyAgencies'] as $key => $agency) {
                        $domains = array();
                        $urls = array();
                        $sf_id_agency = $agency['company_sf_acc_id'];
                        unset($agency['company_sf_acc_id']);

                        foreach ($agency as $keyA => $valueA) {
                            if (!empty($valueA)) {
                                if ($keyA == 'agencyName') {
                                    $agencyInfo = array();
                                    $agencyInfo['name'] = $valueA;
                                    $agencyInfo['company_sf_acc_id'] = $sf_id_agency;
                                    $agencyInfo['company'] = $result;
                                    $agencyInfo['sectionType'] = 'agency';
                                    $agencyInfo['sectionTitle'] = null;
                                    $resultAg = $obj->saveProductSectionData($agencyInfo);
                                    if ($resultAg) {
                                        $agencies[] = $resultAg;
                                    }
                                } else if ($keyA == 'lmsurl') {
                                    $urlInfo = array();
                                    $urlInfo['name'] = strtolower($valueA);
                                    $urlInfo['company'] = $result;
                                    $urlInfo['sectionType'] = 'lmsurl';
                                    $urlInfo['sectionTitle'] = 'Agency Url';
                                    $lmsUrl = $valueA. '.' .LMS_DOMAIN;
                                    $response = $objAccounts->getGroupByDomain($lmsUrl);
                                    if (!empty($response) && is_array($response) && !empty($response[0]['gid']) && is_numeric($response[0]['gid']) &&
                                            !empty($response[0]['managerEmail']) && is_string($response[0]['managerEmail'])) {
                                        $urlSave = $objAgency->insertAgencyDetails($response[0]['gid'], $valueA, $response[0]['managerEmail'], $resultAg);
                                        if (!$urlSave) {
                                            SelfServePortal_Utility::log(
                                                    array(
                                                        "TRACE" => array("METHOD" => __METHOD__, "LINE" => __LINE__),
                                                        "MESSAGE" => 'Save agency details in b2b agency details',
                                                        "REQUEST" => array('gid' => $response[0]['gid'], 'lmsUrl' => $valueA, 'managerEmail' => $response[0]['managerEmail'], 'agencyId' => $resultAg),
                                                        "RESPONSE" => $urlSave,
                                            ));
                                        }
                                    }
                                    $resultUrl = $obj->saveProductSectionData($urlInfo);
                                    if ($resultUrl) {
                                        $urls[] = $resultUrl;
                                    }
                                } else {
                                    $domains[] = $valueA;
                                }
                            }
                        }
                        if (!empty($domains) && $resultAg) {
                            $domainsSM = array();
                            foreach ($domains as $key => $domain) {
                                $domainInfo = array();
                                $domainInfo['name'] = $domain;
                                $domainInfo['company'] = $result;
                                $domainInfo['sectionType'] = 'domain';
                                $domainInfo['sectionTitle'] = 'Company Domain';
                                $domainResult = $obj->saveProductSectionData($domainInfo);
                                if ($domainResult) {
                                    $domainsSM[] = $domainResult;
                                }
                            }
                        }
                        $agencyDomainIdArr = array();
                        if (!empty($domainsSM)) {
                            $agencyDomainIdArr = $domainsSM;
                            //$smResult = $objSM->saveProductSectionData($resultAg, 'agency', $domainsSM);
                        }
                        $agencyUrlsIdArr = array();
                        if (!empty($urls)) {
                            $agencyUrlsIdArr = $urls;
                            //$smResult = $objSM->saveProductSectionData($resultAg, 'agency', $urls);
                        }
                        $agencyProdMapSectionIdArr = array();
                        if (!empty($agencyDomainIdArr)) {
                            $agencyProdMapSectionIdArr = $agencyDomainIdArr;
                        }
                        if (!empty($agencyUrlsIdArr)) {
                            $agencyProdMapSectionIdArr = array_merge($agencyProdMapSectionIdArr, $agencyUrlsIdArr);
                        }
                        if (!empty($agencyProdMapSectionIdArr)) {
                            $smResult = $objSM->saveProductSectionData($resultAg, 'agency', $agencyProdMapSectionIdArr);
                        }
                    }

                    if (!empty($agencies)) {
                        $agencyIdArr = $agencies;
                        // $agencyDom = $objSM->saveProductSectionData($result, 'company', $agencies);
                    }
                    $result = $obj->savebannerSectionData($bannerImage, $bannerText, $result);
                    $partnershipresult = $obj->savePartnershipSectionData($headingInfo,$advantageInfo,$getStartSection, $Id);
                    $bannerSectionId = $result->sectionId;
                    $partnershipId = $partnershipresult->sectionId;
                }
                /**
                 * Training Types ProductSectionData
                 */
                $trainingMapIdArr = array();
                if ($Id) {
                    $productSectionIds = array();
                    if (!empty($trainingTypes)) {
                        foreach ($trainingTypes as $key => $val) {
                            if ($key == BaseApp_Dao_TrainingTypes::TYPE_ELEARNING_NAME || $key == BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS_NAME) {
                                $sectionType = BaseApp_Dao_TrainingTypes::B2B_TRAINING_TYPE;
                                $linkableTypeId = '';
                            } else {
                                $sectionType = BaseApp_Dao_TrainingTypes::B2B_PRODUCT_TYPE;
                                $linkableTypeId = $val;
                            }
                            $name = $val;
                            $description = $key;
                            $companyId = $Id;
                            $params = array('linkableTypeId' => $linkableTypeId, 'sectionType' => $sectionType, 'name' => $name, 'description' => $description, 'companyId' => $companyId);
                            $productSectionIds[] = $obj->saveProductSectionDataB2BCompany($params);
                        }
                        if (!empty($productSectionIds)) {
                            $trainingMapIdArr = $productSectionIds;
                        }
                    }
                }

                /**
                 * Agencies Id
                 */
                $productSectionMapIdArr = array();
                if (!empty($agencyIdArr)) {
                    $productSectionMapIdArr = $agencyIdArr;
                }
                /**
                 * Training Map Ids
                 */
                if (!empty($trainingMapIdArr)) {
                    $productSectionMapIdArr = array_merge($productSectionMapIdArr, $trainingMapIdArr);
                }
                if(!empty($bannerSectionId)){
                       $productSectionMapIdArr = array_merge($productSectionMapIdArr, $bannerSectionId);
                   }
                   if(!empty($partnershipId)){
                    $productSectionMapIdArr = array_merge($productSectionMapIdArr, $partnershipId);
                   }
                /**
                 * Save To Section Mapping
                 */
                if (!empty($productSectionMapIdArr)) {
                    $objSM->saveProductSectionData($Id, 'company', $productSectionMapIdArr);
                }
            }

            if(!empty($insertData)){
               $result = $b2bCompanies->createB2bCompanies($insertData);
            }

            if (!empty($result->value)) {
                $this->view->message = "An error has occured while saving";
                $this->view->success = false;
                $this->view->form = $form;
                return false;
            } else {
                $this->view->message = "Saved SuccessFully";
                $this->view->success = true;
                $module = $this->getRequest()->getModuleName();
                $controller = $this->getRequest()->getControllerName();
                $action = $this->getRequest()->getActionName();
                if ($module && $controller && $action) {
                    $this->redirect($module . '/' . $controller . '/course-pricing/id/' . $Id);
                }
            }
        }
        $this->view->success = true;
        $this->view->form = $form;
    }

    private function _setLearnerRange(&$request) {
        $session = new Zend_Session_Namespace('form');
        if (isset($request['learnerRange']) && count($request['learnerRange'])) {
            $request['learnerRange'] = $this->_updateFirstElement($request['learnerRange']);
            $session->learnerRange = array_keys($request['learnerRange']);
            array_unshift($session->learnerRange, '__template__');
            $session->learnerRangeData = $request['learnerRange'];
        } else {
            $session->learnerRange = array('__template__', 'new');
            $session->learnerRangeData = array();
        }
    }

    private function _setCompanyAgencies(&$request) {
        $session = new Zend_Session_Namespace('form');
        if (!empty($request['companyAgencies']) && count($request['companyAgencies'])) {
            $request['companyAgencies'] = $this->_updateFirstElement($request['companyAgencies']);
            $session->companyAgencies = array_keys($request['companyAgencies']);
            array_unshift($session->companyAgencies, '__template__');
            $session->companyAgenciesData = $request['companyAgencies'];
        } else {
            $session->companyAgencies = array('__template__', 'new');
            $session->companyAgenciesData = array();
        }
    }

    private function __setCompanyPricingCat(&$request) {
        $session = new Zend_Session_Namespace('form');
        if (!empty($request['companyPricingCat']) && count($request['companyPricingCat'])) {
            $request['companyPricingCat'] = $this->_updateFirstElement($request['companyPricingCat']);
            $session->companyPricingCat = array_keys($request['companyPricingCat']);
            array_unshift($session->companyPricingCat, '__template__');
            $session->companyPricingCatData = $request['companyPricingCat'];
        } else {
            $session->companyPricingCat = array('__template__', 'new');
            $session->companyPricingCatData = array();
        }
    }

    private function __setCompanyPricingCourse(&$request) {
        $session = new Zend_Session_Namespace('form');
        if (!empty($request['companyPricingCourse']) && count($request['companyPricingCourse'])) {
            $request['companyPricingCourse'] = $this->_updateFirstElement($request['companyPricingCourse']);
            $session->companyPricingCourse = array_keys($request['companyPricingCourse']);
            array_unshift($session->companyPricingCourse, '__template__');
            $session->companyPricingCourseData = $request['companyPricingCourse'];
        } else {
            $session->companyPricingCourse = array('__template__', 'new');
            $session->companyPricingCourseData = array();
        }
    }

    private function _updateFirstElement($elementArray) {
        $keys = array_keys($elementArray);
        $keys[array_search('0', $keys)] = 'new';
        return array_combine($keys, $elementArray);
    }

    public function editAction() {
        
        $this->view->agencyList = SelfServePortal_Utility::getUnmappedAgencies();
        $Id = $this->getRequest()->getParam('id');
        if (!$Id) {
            throw new BaseApp_Exception('Editable item not selected properly');
        }
        $courseAdvisorData = current($this->getModel()->fetchAll(array('id =?' => $Id)));

        $courseAdvisorData['company_id'] = $Id;
        $courseAdvisorData['company_existing_price_plan'] = $courseAdvisorData['company_price_plans'];
        if (empty($courseAdvisorData)) {
            throw new BaseApp_Exception('Editable item not selected properly');
        }
        $obj = new Model_ProductSectionData();
        $objSM = new Model_SectionMapping();
        $b2bPriObj = new Model_B2BFlatPricing();
        $b2bExcObj = new Model_B2bProductExclusions();
        $b2bProPriObj = new Model_B2BProductPricing();
        $compProductObj = new Model_CompanyProductMapper();
        $learnerRangeObj = new Model_LearnersRange();
        $labelObj = new Model_Labels();
        $sectionData = $objSM->getByLinkableIdLinkableType($Id, 'company');
        $objAccounts = new BaseApp_Communication_Accounts();
        $objAgency = new BaseApp_Dao_B2bAgencyDetails();
        $b2bCompanies = new Model_B2BCompanies();
        $deleteAgencyPrice = false;
        /**
         * B2B Training Types
         */
        $b2bTrainingTypes = $obj->fetchAll(array(
            'company =?' => $Id,
            'sectionType IN (?)' => array(BaseApp_Dao_TrainingTypes::B2B_TRAINING_TYPE, BaseApp_Dao_TrainingTypes::B2B_PRODUCT_TYPE)
                ), array('columns' => array('name' => 'description', 'id' => 'name')));
        if (!empty($b2bTrainingTypes)) {
            foreach ($b2bTrainingTypes as $tTypes) {
                if ($tTypes['name'] === BaseApp_Dao_TrainingTypes::TYPE_ELEARNING_NAME) {
                    $courseAdvisorData['isOsl'] = 1;
                }
                if ($tTypes['name'] === BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS_NAME) {
                    $courseAdvisorData['isLvc'] = 1;
                }
                if ($tTypes['name'] === BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES) {
                    $courseAdvisorData['isBundle'] = 1;
                }
            }
        }
        $agenciesInfo = array();
        $agenciesEditInfo = array();
        if (!empty($sectionData) && !empty($sectionData['agency'])) {
            $company_agency_ids = array_column($sectionData['agency'], 'section_id');
            if (!empty($company_agency_ids)) {
                $agenciesData = $obj->fetchAll(array('id IN (?)' => $company_agency_ids, 'status = ?' => 1));
                if (!empty($agenciesData)) {
                    foreach ($agenciesData as $key => $value) {
                        $agenciesInfo[$value['id']]['agencyName'] = $value['name'];
                        $agenciesInfo[$value['id']]['company_sf_acc_id'] = $value['company_sf_acc_id'];
                        $agenciesEditInfo[$value['id']]['agency'] = $value;
                        $sectionDataAgency = $objSM->getByLinkableIdLinkableType($value['id'], 'agency');
                        if (!empty($sectionDataAgency) && !empty($sectionDataAgency['domain'])) {
                            $domain_ids = array_column($sectionDataAgency['domain'], 'section_id');
                            if (!empty($domain_ids)) {
                                $domainsData = $obj->fetchAll(array('id IN (?)' => $domain_ids));
                                if (!empty($domainsData)) {
                                    $i = 1;
                                    $agenciesEditInfo[$value['id']]['domain'] = array();
                                    foreach ($domainsData as $keyD => $valueD) {
                                        $agenciesInfo[$value['id']]['domain' . $i] = $valueD['name'];
                                        $agenciesEditInfo[$value['id']]['domain'][] = $valueD;
                                        $i++;
                                    }
                                }
                            }
                        }
                        if (!empty($sectionDataAgency) && !empty($sectionDataAgency['lmsurl'])) {
                            $ids = array_column($sectionDataAgency['lmsurl'], 'section_id');
                            if (!empty($ids)) {
                                $data = $obj->fetchAll(array('id IN (?)' => $ids));
                                if (!empty($data)) {
                                    $agenciesInfo[$value['id']]['lmsurl'] = $data[0]['name'];
                                    $agenciesEditInfo[$value['id']]['lmsurl'][] = $data[0];
                                }
                            }
                        }
                    }
                }
            }
        }
        $agenciesEditInfo = array_values($agenciesEditInfo);
        $course = new Model_Courses();
        $previousAgencyData = !empty($agenciesInfo) ? current($agenciesInfo):array();
        $previousAgency = !empty($previousAgencyData['agencyName']) ? $previousAgencyData['agencyName'] :'';
        if ($this->getRequest()->isPost()) {
            $request = $this->getRequest()->getPost();
            $request['Isedit'] = 1;
            $this->_setCompanyAgencies($request);
            $this->_setLearnerRange($request);
            $this->__setCompanyPricingCat($request);
            $this->__setCompanyPricingCourse($request);
            $form = $this->_getForm($Id);
            $data = $form->getValues();
            if (!empty($request['category_id'])) {
                /**
                 * Course Exclusion
                 */
                $categorieIdArr = explode(',', $request['category_id']);
                
                
                $courseData = $course->fetchCoursesByLabelsBasedOnAgency($categorieIdArr,'');
                if (!empty($courseData)) {
                    $courseData = array_column($courseData, 'name', 'linkable_id');
                }
                $agencyName = $request['companyAgencies']['new']['agencyName'];
                $this->courseData2 = $course->fetchCoursesByLabelsBasedOnAgency($categorieIdArr,$agencyName);
                $courseDataNew = $this->courseData2;
                $courseDataOld = $course->fetchCoursesByLabelsBasedOnAgency($categorieIdArr,$previousAgency);
                $removeCourseData = array();    
                if ($agencyName != $previousAgency) {
                    $deleteAgencyPrice = true;
                    $this->courseData2 = array_udiff($this->courseData2, $courseDataOld, array($this, 'udiffCompare'));
                    $removeCourseData = array_udiff($courseDataOld,$courseDataNew, array($this, 'udiffCompare'));
                } else{
                    $this->courseData2 = array();
                }
                $removeCourseData = !empty($removeCourseData)? array_column($removeCourseData, 'linkable_id'): array();
                
                $excludeCourseData = !empty($request['exclusion_courses'])?$request['exclusion_courses']:''; 
                $excludeCourseData = !empty($excludeCourseData)? explode(',',$excludeCourseData):array(); 
                
                $courseIds = !empty($request['excluded_course_ids'])?$request['excluded_course_ids']:'';
                $courseIds = !empty($courseIds) ? explode(',', $courseIds):array();

                $effectiveCourseIds = array_diff($courseIds,$removeCourseData);
                $effectiveExcludeCourseIds = array_diff($excludeCourseData,$removeCourseData);
                $request['exclusion_courses'] = implode(',',empty($effectiveExcludeCourseIds)?$effectiveExcludeCourseIds:array());
                $request['excluded_course_ids'] = implode(',',  $effectiveCourseIds);

                $courseData2 = array();
                if (!empty($this->courseData2)) {
                    $courseData2 = array_column($this->courseData2, 'name', 'linkable_id');
                }
                
                $courseData = $courseData + $courseData2;
                $form->getElement('exclusion_courses')->addMultiOptions($courseData);
                
                
                /**
                 * Category Filter
                 */
                $obj = new Model_Labels();
                $categoryList = $obj->getLabelsToshow();
                $categoryFilter = array_intersect_key($categoryList, array_flip($categorieIdArr));
                $categoryFilter = array('0' => '--Select--') + $categoryFilter;
                $form->getElement('category_filter')->addMultiOptions($categoryFilter);
                /**
                 * Master Program Exclusion
                 */

                $bundle = new Model_Bundles();
                $bundleList = $bundle->fetchBundlesByLabelsBasedOnAgency($categorieIdArr, '');
                $bundleData = array();
                if (!empty($bundleList)) {
                    $bundleData = array_column($bundleList, 'display_name', 'linkable_id');
                }
                $bundleData2 =array();
                $this->bundleData2 = $bundle->fetchBundlesByLabelsBasedOnAgency($categorieIdArr,$agencyName);
                $bundleDataOld = $bundle->fetchBundlesByLabelsBasedOnAgency($categorieIdArr,$previousAgency);
                $bundleDataNew = $this->bundleData2;
                $removebundleData  = array();
                if ($agencyName != $previousAgency) {
                    $this->bundleData2 = array_udiff($this->bundleData2, $bundleDataOld, array($this, 'udiffCompare'));
                    $removebundleData = array_udiff($bundleDataOld,$bundleDataNew, array($this, 'udiffCompare'));
                } else{
                    $this->bundleData2 = array();
                }
                $removebundleData = !empty($removebundleData)? array_column($removebundleData, 'linkable_id'): array();
                $excludeBundleData = !empty($request['exclusion_master_program'])?$request['exclusion_master_program']:''; 
                $excludeBundleData = !empty($excludeBundleData)? explode(',',$excludeBundleData):array();                 
                $excludebundleIds = !empty($request['excluded_masterprogram_ids'])?$request['excluded_masterprogram_ids']:'';
                $excludebundleIds = !empty($excludebundleIds) ? explode(',', $excludebundleIds):array();
                $effectiveBundleIds = array_diff($excludebundleIds,$removebundleData);
                $effectiveExcludeBundleIds = array_diff($excludeBundleData,$removebundleData);
                $request['exclusion_master_program'] = implode(',',empty($effectiveExcludeBundleIds)?$effectiveExcludeBundleIds:array());
                $request['excluded_masterprogram_ids'] = implode(',',  $effectiveBundleIds);
                if(!empty($this->bundleData2)) {
                    $bundleData2 = array_column($this->bundleData2, 'display_name', 'linkable_id');
                }
                $bundleData = $bundleData + $bundleData2;
                $form->getElement('exclusion_master_program')->addMultiOptions($bundleData);
                
            }
            if ($form === false) {
                throw new Zend_Exception('_getForm not implemented');
            }
            //prd('request',$request);
            if ($form->isValid($request)) {
                $data = $form->getValues();
                //$form->removeOptionalElements();
                if (!empty($data['description'])) {
                    $data['description'] = strtolower($data['description']);
                }
                unset($data['agency_dom_err']);
                $splitData = $this->_handleDataAfterSubmit($data);
                $partnerShipDetails = $splitData['partnershipDetails'];
                $headingInfo = array();
                $advantageInfo = array();
                $getStartSection = array();
                if (!empty($partnerShipDetails)) {
                    $headingInfo['name'] = $partnerShipDetails['heading'] ? $partnerShipDetails['heading'] : '';
                    $headingInfo['description'] = $partnerShipDetails['heading_content'] ? $partnerShipDetails['heading_content'] : '';
                    $advantageInfo['name'] = $partnerShipDetails['advantage_section'] ? $partnerShipDetails['advantage_section'] : '';
                    $advantageInfo['description'] = $partnerShipDetails['advantage_content'] ? $partnerShipDetails['advantage_content'] : '';
                    $getStartSection['name'] = $partnerShipDetails['getting_started_section'] ? $partnerShipDetails['getting_started_section'] : '';
                    $getStartSection['description'] = $partnerShipDetails['get_start_content'] ? $partnerShipDetails['get_start_content'] : '';
                }
                $bannerImage = $data['bannerImageUrl'];
                $bannerText = $data['bannerSectionText'];
                $trainingTypes = array();
                $isMasterIncludedInPortal = false;
                if (!empty($data['isOsl'])) {
                    $trainingTypes[BaseApp_Dao_TrainingTypes::TYPE_ELEARNING_NAME] = BaseApp_Dao_TrainingTypes::TYPE_ELEARNING;
                }
                if (!empty($data['isLvc'])) {
                    $trainingTypes[BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS_NAME] = BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS;
                }
                if (!empty($data['isBundle'])) {
                    $isMasterIncludedInPortal = true;
                    $trainingTypes[BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES] = BaseApp_Dao_ProductTypes::TYPE_ID_BUNDLE;
                }
                unset($data['bannerImageUrl']);
                unset($data['bannerSectionText']);
                unset($data['company_id']);
                unset($data['category_filter']);
                unset($data['company_existing_price_plan']);
                unset($data['isOsl']);
                unset($data['isLvc']);
                unset($data['isBundle']);
                unset($data['heading']);
                unset($data['heading_content']);
                unset($data['advantage_section']);
                unset($data['advantage_content']);
                unset($data['getting_started_section']);
                unset($data['get_start_content']);

                $obj = new Model_ProductSectionData();
                $result = $obj->updateProductSectionData($Id, $data);
                $updateData = $obj->toArray();
                
                $partnershipResult = $obj->savePartnershipSectionData($headingInfo,$advantageInfo,$getStartSection, $Id);
                $partnershipSectionId = $partnershipResult->sectionId;
                $obj->disableB2BProdTrainingMap($Id);


                $agencies = array();
                if ($result) {
                    if (!empty($deleteAgencyPrice)) {
                        $b2bPricing = new Model_B2BProductPricing();
                        $b2bCartPricing = new  Model_B2bCartPricing();
                        $b2bPricing->deleteProductPricingByIds($removebundleData, 'bundle', $Id);
                        $b2bPricing->deleteProductPricingByIds($removeCourseData, 'course', $Id);
                        $b2bCartPricing->deleteAgencyProductData($removeCourseData, 'COURSE', $Id);
                        $b2bCartPricing->deleteAgencyProductData($removebundleData, 'BUNDLE', $Id);

                    }
                    if(!empty($splitData) && !empty($splitData['category_id'])) {
                        $resultCPM = $compProductObj->saveProductMapping($Id, 'category', array_filter($splitData['category_id']));
                    }

                    if(!empty($this->courseData2)) {
                        foreach($this->courseData2 as $b => $val) {
                            unset($this->courseData2[$b]['name']);
                        }
                    }

                    if(!empty($this->bundleData2)) {
                        foreach($this->bundleData2 as $b => $val) {
                            unset($this->bundleData2[$b]['display_name']);
                        }
                    }          
                    $fullcourselist = array_merge($splitData['companyExcludedCourses'],$this->courseData2);
                    $fullbundlelist = array_merge($splitData['companyExcludedMasterProgram'],$this->bundleData2);
                    
                    $uniqcourselist = !empty($fullcourselist) ? array_unique(array_column($fullcourselist,'linkable_id')):array();
                    $fullcourselist = array_intersect_key($fullcourselist, $uniqcourselist);

                    $uniqmasterlist = !empty($fullbundlelist) ? array_unique(array_column($fullbundlelist,'linkable_id')):array();
                    $fullbundlelist = array_intersect_key($fullbundlelist, $uniqmasterlist);
                    
                    $priResult = $b2bExcObj->saveB2BProductExclusions($Id, 'course', $fullcourselist);       
                    $priResult = $b2bExcObj->saveB2BProductExclusions($Id, 'bundle', $fullbundlelist);
        
                    $agencyIdArr = array();
                    if (!empty($splitData) && !empty($splitData['companyAgencies'])) {
                        foreach ($splitData['companyAgencies'] as $key => $agency) {
                            $sf_id_agency = $agency['company_sf_acc_id'];
                            unset($agency['company_sf_acc_id']);
                            $domains = array();
                            $urls = array();
                            $dataSM = array();
                            $dataAgency = array();
                            $resultAg = false;
                            foreach ($agency as $keyA => $valueA) {
                                if (!empty($valueA)) {
                                    if ($keyA == 'agencyName') {
                                        if (!empty($agenciesEditInfo)) {
                                            $dataAgency = array_shift($agenciesEditInfo);
                                            $agencyInfo = $dataAgency['agency'];
                                            $agencyInfo['name'] = $valueA;
                                            $agencyInfo['company_sf_acc_id'] = $sf_id_agency;
                                            $resultAg = $obj->updateProductSectionData($agencyInfo['id'], $agencyInfo);
                                            $resultAg = $agencyInfo['id'];
                                        } else {
                                            $agencyInfo = array();
                                            $agencyInfo['name'] = $valueA;
                                            $agencyInfo['company_sf_acc_id'] = $sf_id_agency;
                                            $agencyInfo['company'] = $Id;
                                            $agencyInfo['sectionType'] = 'agency';
                                            $agencyInfo['sectionTitle'] = null;
                                            $resultAg = $obj->saveProductSectionData($agencyInfo);
                                        }
                                        if ($resultAg) {
                                            $agencies[] = $resultAg;
                                        }
                                    } else if ($keyA == 'lmsurl') {
                                        $urls[] = $valueA;
                                    } else {
                                        $domains[] = $valueA;
                                    }
                                }
                            }
                            $lmsUrlsStored = array();
                            if (!empty($dataAgency['lmsurl'])) {
                                $lmsUrlsStored = $dataAgency['lmsurl'];
                            }
                            if (!empty($urls) && $resultAg) {

                                foreach ($urls as $key => $url) {
                                    $urlInfo = array();
                                    if (!empty($lmsUrlsStored)) {
                                        $urlInfo = array_shift($lmsUrlsStored);
                                        $urlInfo['name'] = $url;

                                        $lmsUrl = $url. '.' .LMS_DOMAIN;
                                        $response = $objAccounts->getGroupByDomain($lmsUrl);
                                        if (!empty($response) && is_array($response) && !empty($response[0]['gid']) && is_numeric($response[0]['gid']) &&
                                                !empty($response[0]['managerEmail']) && is_string($response[0]['managerEmail'])) {
                                            $urlSave = $objAgency->insertAgencyDetails($response[0]['gid'], $url, $response[0]['managerEmail'], $resultAg);
                                            SelfServePortal_Utility::log(
                                                    array(
                                                        "TRACE" => array("METHOD" => __METHOD__, "LINE" => __LINE__),
                                                        "MESSAGE" => 'Save agency details in b2b agency details',
                                                        "REQUEST" => array('gid' => $response[0]['gid'], 'lmsUrl' => $url, 'managerEmail' => $response[0]['managerEmail'], 'agencyId' => $resultAg),
                                                        "RESPONSE" => $urlSave,
                                            ));
                                        }

                                        $urlResult = $obj->updateProductSectionData($urlInfo['id'], $urlInfo);
                                        $urlResult = $urlInfo['id'];
                                    } else {
                                        $urlInfo['name'] = strtolower($url);
                                        $urlInfo['company'] = $Id;
                                        $urlInfo['sectionType'] = 'lmsurl';
                                        $urlInfo['sectionTitle'] = 'Agency Url';
                                        $lmsUrl = $url. '.' .LMS_DOMAIN;
                                        $response = $objAccounts->getGroupByDomain($lmsUrl);
                                        if (!empty($response) && is_array($response) && !empty($response[0]['gid']) && is_numeric($response[0]['gid']) &&
                                                !empty($response[0]['managerEmail']) && is_string($response[0]['managerEmail'])) {
                                            $urlSave = $objAgency->insertAgencyDetails($response[0]['gid'], $url, $response[0]['managerEmail'], $resultAg);
                                            SelfServePortal_Utility::log(
                                                    array(
                                                        "TRACE" => array("METHOD" => __METHOD__, "LINE" => __LINE__),
                                                        "MESSAGE" => 'Save agency details in b2b agency details',
                                                        "REQUEST" => array('gid' => $response[0]['gid'], 'lmsUrl' => $url, 'managerEmail' => $response[0]['managerEmail'], 'agencyId' => $resultAg),
                                                        "RESPONSE" => $urlSave,
                                            ));
                                        }
                                        $urlResult = $obj->saveProductSectionData($urlInfo);
                                    }
                                    if ($urlResult) {
                                        $dataSM[] = $urlResult;
                                    }
                                }
                            }

                            if (!empty($lmsUrlsStored)) {
                                foreach ($lmsUrlsStored as $key => $urlInfo) {
                                    $urlInfo['status'] = 0;
                                    $urlResult = $obj->updateProductSectionData($urlInfo['id'], $urlInfo);
                                    $smResult = $objSM->disableSecMapBySectionId($resultAg, 'agency', $urlInfo['id']);
                                }
                            }
                            $domainsStored = array();
                            if (!empty($dataAgency['domain'])) {
                                $domainsStored = $dataAgency['domain'];
                            }
                            if (!empty($domains) && $resultAg) {
                                $domainsSM = array();
                                foreach ($domains as $key => $domain) {
                                    $domainResult = false;
                                    $domainInfo = array();
                                    if (!empty($domainsStored)) {
                                        $domainInfo = array_shift($domainsStored);
                                        $domainInfo['name'] = $domain;
                                        $domainResult = $obj->updateProductSectionData($domainInfo['id'], $domainInfo);
                                        $domainResult = $domainInfo['id'];
                                    } else {
                                        $domainInfo['name'] = $domain;
                                        $domainInfo['company'] = $Id;
                                        $domainInfo['sectionType'] = 'domain';
                                        $domainInfo['sectionTitle'] = 'Company Domain';
                                        $domainResult = $obj->saveProductSectionData($domainInfo);
                                    }
                                    if ($domainResult) {
                                        $dataSM[] = $domainResult;
                                    }
                                }
                            }
                            if (!empty($domainsStored)) {
                                foreach ($domainsStored as $key => $domainInfo) {
                                    $domainInfo['status'] = 0;
                                    $domainResult = $obj->updateProductSectionData($domainInfo['id'], $domainInfo);
                                    $smResult = $objSM->disableSecMapBySectionId($resultAg, 'agency', $domainInfo['id']);
                                }
                            }
                            if (!empty($dataSM)) {
                                $smResult = $objSM->saveProductSectionData($resultAg, 'agency', $dataSM);
                            }
                        }
                        if (!empty($agencies)) {
                            $agencyIdArr = $agencies;
                            //$agencyDom = $objSM->saveProductSectionData($Id, 'company', $agencies);
                        }
                    }
                    if (!empty($agenciesEditInfo)) {
                        foreach ($agenciesEditInfo as $key => $dataAgency) {
                            $agencyInfo = $dataAgency['agency'];
                            $agencyInfo['status'] = 0;
                            $smResult = $objSM->disableSecMapBySectionId($Id, 'company', $agencyInfo['id']);
                            $resultAg = $obj->updateProductSectionData($agencyInfo['id'], $agencyInfo);
                            $domainsStored = array();
                            if (!empty($dataAgency['domain'])) {
                                $domainsStored = $dataAgency['domain'];
                                if (!empty($domainsStored)) {
                                    foreach ($domainsStored as $key => $domainInfo) {
                                        $domainInfo['status'] = 0;
                                        $domainResult = $obj->updateProductSectionData($domainInfo['id'], $domainInfo);
                                        $smResult = $objSM->disableSecMapBySectionId($agencyInfo['id'], 'agency', $domainInfo['id']);
                                    }
                                }
                            }
                        }
                    }
                    $result = $obj->savebannerSectionData($bannerImage, $bannerText, $Id);
                    $bannerSectionId = $result->sectionId;
                    if (!empty($splitData['learnerRange'])) {
                        $splitData['learnerRange'] = $this->_checkLearnerRange($splitData['learnerRange']);
                        if (empty($splitData['learnerRange'])) {
                            throw new Zend_Exception('Empty Learner Range.');
                        }
                        $priResult = $learnerRangeObj->saveB2BLearnerRange($Id, $splitData['learnerRange']);
                    }
                    $productSectionIdArr = array();
                    $trainingMapIdArr = array();
                    if (!empty($trainingTypes)) {
                        foreach ($trainingTypes as $key => $val) {
                            if ($key == BaseApp_Dao_TrainingTypes::TYPE_ELEARNING_NAME || $key == BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS_NAME) {
                                $sectionType = BaseApp_Dao_TrainingTypes::B2B_TRAINING_TYPE;
                                $linkableTypeId = '';
                            } else {
                                $sectionType = BaseApp_Dao_TrainingTypes::B2B_PRODUCT_TYPE;
                                $linkableTypeId = $val;
                            }
                            $name = $val;
                            $description = $key;
                            $companyId = $Id;
                            $params = array('linkableTypeId' => $linkableTypeId, 'sectionType' => $sectionType, 'name' => $name, 'description' => $description, 'companyId' => $Id);
                            $productSectionIdArr[] = $obj->saveProductSectionDataB2BCompany($params);
                        }
                        if (!empty($productSectionIdArr)) {
                            $trainingMapIdArr = $productSectionIdArr;
//                           
                        }
                    }
                    /**
                     * Agencies Id
                     */
                    $productSectionMapIdArr = array();
                    if (!empty($agencyIdArr)) {
                        $productSectionMapIdArr = $agencyIdArr;
                    }
                    /**
                     * Training Map Ids
                     */
                    if (!empty($trainingMapIdArr)) {
                        $productSectionMapIdArr = array_merge($productSectionMapIdArr, $trainingMapIdArr);
                    }
                    if(!empty($bannerSectionId)){
                        $productSectionMapIdArr = array_merge($productSectionMapIdArr, $bannerSectionId);
                    }
                    if(!empty($partnershipSectionId)){
                        $productSectionMapIdArr = array_merge($productSectionMapIdArr, $partnershipSectionId);
                    }
                    /**
                     * Save To Sectionn Mapping
                     */
                    if (!empty($productSectionMapIdArr)) {
                        $objSM->saveProductSectionData($Id, 'company', $productSectionMapIdArr);
                    }

                    $updateB2bCompanies = $b2bCompanies->updateB2bCompanies($updateData,$Id);

                }
                if (!$result->value) {
                    $this->view->message = "An error has occured while saving";
                    $this->view->success = false;
                    $this->view->form = $form;
                    return false;
                } else {
                    $form->reset();
                    $module = $this->getRequest()->getModuleName();
                    $controller = $this->getRequest()->getControllerName();
                    $action = $this->getRequest()->getActionName();
                    if ($module && $controller && $action) {
                        // $this->redirect($module . '/' . $controller . '/list');
                        $this->redirect($module . '/' . $controller . '/course-pricing/id/' . $Id);
                    }
                }
            } else {
                $form->setDefaults($courseAdvisorData);
            }
        } else {
            $categoryData = $compProductObj->fetchAll(array('company_id =?' => $Id, 'linkable_type = ?' => 'category', 'status = ?' => 1), array('order' => 'order'));
            if (!empty($categoryData)) {
                $courseAdvisorData['category_id_tmp'] = array_column($categoryData, 'linkable_id');
                $courseAdvisorData['category_id'] = implode(',', $courseAdvisorData['category_id_tmp']);
                $categoryList = $labelObj->getLabelsToshow();
                $categoryFilter = array_intersect_key($categoryList, array_flip($courseAdvisorData['category_id_tmp']));
                $categoryFilter = array('0' => '--Select--') + $categoryFilter;
            }

            $excCoursesData = $b2bExcObj->fetchAll(array('company_id =?' => $Id, 'linkable_type = ?' => 'course', 'status = ?' => 1));
            
            if (!empty($excCoursesData)) {
                $courseAdvisorData['exclusion_courses'] = array_column($excCoursesData, 'linkable_id');
                $courseAdvisorData['excluded_course_ids'] = implode(',', $courseAdvisorData['exclusion_courses']);
            }

            $excMasterProgramData = $b2bExcObj->fetchAll(array('company_id =?' => $Id, 'linkable_type = ?' => 'bundle', 'status = ?' => 1));
            if (!empty($excMasterProgramData)) {
                $courseAdvisorData['exclusion_master_program'] = array_column($excMasterProgramData, 'linkable_id');
                $courseAdvisorData['excluded_masterprogram_ids'] = implode(',', $courseAdvisorData['exclusion_master_program']);
            }

            $pricingData = $b2bPriObj->fetchAll(array('company_id =?' => $Id, 'status = ?' => 1));
            $courseAdvisorData['companyPricingCat'] = array();
            $courseAdvisorData['companyPricingCourse'] = array();
            if (!empty($pricingData)) {
                foreach ($pricingData as $key => $value) {
                    if (!empty($value['cluster_id']) && $value['cluster_id'] != 0) {
                        $value['location_mode'] = 1;
                    }
                    if (!empty($value['country_id']) && $value['country_id'] != 0) {
                        $value['location_mode'] = 2;
                    }
                    if ($value['linkable_type'] == 'category') {
                        $value['linkable_id_prod'] = 0;
                        $courseAdvisorData['companyPricingCat'][] = $value;
                    }
                    if ($value['linkable_type'] == 'course') {
                        $courseAdvisorData['companyPricingCourse'][] = $value;
                    }
                }
            }

            $productPricingData = $b2bProPriObj->fetchAll(array('company_id =?' => $Id, 'status = ?' => 1));
            if (!empty($productPricingData)) {
                foreach ($productPricingData as $key => $value) {
                    if (!empty($value['cluster_id']) && $value['cluster_id'] != 0) {
                        $value['location_mode'] = 1;
                    }
                    if (!empty($value['country_id']) && $value['country_id'] != 0) {
                        $value['location_mode'] = 2;
                    }
                    if ($value['linkable_type'] == 'category') {
                        $value['linkable_id_prod'] = $value['linkable_id'];
                        $courseAdvisorData['companyPricingCat'][] = $value;
                    }
                    // if ($value['linkable_type'] == 'course') {
                    //     $courseAdvisorData['companyPricingCourse'][] = $value;
                    // }
                }
            }
            $agencyData = !empty($agenciesInfo) ? current($agenciesInfo):array();
            $agencyName = !empty($agencyData['agencyName']) ? $agencyData['agencyName']:'';
            $courseAdvisorData['companyAgencies'] = $agenciesInfo;
            $this->_setCompanyAgencies($courseAdvisorData);
            $this->__setCompanyPricingCat($courseAdvisorData);
            $this->__setCompanyPricingCourse($courseAdvisorData);
            $learnerRangeModel = new Model_LearnersRange();
            $learnerRangeData = $learnerRangeModel->getByLinkable($Id); //prd($learnerRangeData);
            if (!empty($learnerRangeData)) {
                foreach ($learnerRangeData as &$row) {
                    $row['learners_range_id'] = $row['id'];
                    $row['company_id'] = $Id;
                }
            }
            $courseAdvisorData['learnerRange'] = $learnerRangeData;
            $this->_setLearnerRange($courseAdvisorData);

            $courseAdvisorData['bannerImageUrl'] = '';
            $courseAdvisorData['bannerSectionText'] = '';
            $bannerSectionData = isset($sectionData['banner_section']) ? $sectionData['banner_section'] : array();
            if (!empty($bannerSectionData)) {
                foreach ($bannerSectionData as $ckey => $cValue) {
                    if ($cValue['sectionTitle'] == 'banner_image')
                        $courseAdvisorData['bannerImageUrl'] = $cValue['name'];
                    elseif ($cValue['sectionTitle'] == 'banner_text')
                        $courseAdvisorData['bannerSectionText'] = $cValue['name'];
                }
            }

            $form = $this->_getForm($Id);
            $form->removeUneditableElements();

            if ($form === false) {
                throw new Zend_Exception('_getForm not implemented');
            }
            if (!empty($courseAdvisorData['category_id_tmp'])) {
                $courseData = array();
                $courseData = $course->fetchCoursesByLabelsBasedOnAgency($courseAdvisorData['category_id_tmp'],'');
                if (!empty($courseData)) {
                    $courseData = array_column($courseData, 'name', 'linkable_id');
                }
                $this->courseData2 = $course->fetchCoursesByLabelsBasedOnAgency($courseAdvisorData['category_id_tmp'],$agencyName);
                $courseData2 = array();
                if (!empty($this->courseData2)) {
                    $courseData2 = array_column($this->courseData2, 'name', 'linkable_id');
                }
                $courseData = $courseData + $courseData2;
                $form->getElement('exclusion_courses')->addMultiOptions($courseData);
                $form->getElement('category_filter')->addMultiOptions($categoryFilter);
                $bundle = new Model_Bundles();
                $bundleList = $bundle->fetchBundlesByLabelsBasedOnAgency($courseAdvisorData['category_id_tmp'], '');
                $bundleData = array();
                if (!empty($bundleList)) {
                    $bundleData = array_column($bundleList, 'display_name', 'linkable_id');
                }
                $bundleData2 = array();
                $this->bundleData2 = $bundle->fetchBundlesByLabelsBasedOnAgency($courseAdvisorData['category_id_tmp'], $agencyName);
                if (!empty($this->bundleData2)) {
                    $bundleData2 = array_column($this->bundleData2, 'display_name', 'linkable_id');
                }
                $bundleData = $bundleData + $bundleData2;
                $form->getElement('exclusion_master_program')->addMultiOptions($bundleData);
            }

            $form->setDefaults($courseAdvisorData);
        }
        $this->view->activeTab = 1;
        $this->view->istabsEnabled = true;
        $this->view->form = $form;
    }
    public function udiffCompare($a, $b)
    {
        return $a['linkable_id'] - $b['linkable_id'];
    }
    private function _handleDataAfterSubmit(&$data) {
        $returnData = array(
            'companyAgencies' => array(),
            'companyPricingCat' => array(),
            'companyPricingCourse' => array(),
            'category_id' => array(),
            'companyExcludedCourses' => array(),
            'companyExcludedMasterProgram' => array(),
            'learnerRange' => array(),
            'partnershipDetails'=> array(),
        );

        if (!empty($data['companyAgencies'])) {
            foreach ($data['companyAgencies'] as $type => $relatedData) {
                if ($type !== '__template__') {
                    $returnData['companyAgencies'][] = $relatedData;
                }
            }
        }
        if (!empty($data['companyPricingCat'])) {
            foreach ($data['companyPricingCat'] as $type => $relatedData) {
                if ($type !== '__template__') {
                    $returnData['companyPricingCat'][] = $relatedData;
                }
            }
        }
        if (!empty($data['companyPricingCourse'])) {
            foreach ($data['companyPricingCourse'] as $type => $relatedData) {
                if ($type !== '__template__') {
                    $returnData['companyPricingCourse'][] = $relatedData;
                }
            }
        }
        if (!empty($data['learnerRange'])) {
            foreach ($data['learnerRange'] as $type => $relatedData) {
                if ($type !== '__template__') {
                    $content = $relatedData['min'] . ' to ' . $relatedData['max'];
                    $learnerRangeData = array('min' => $relatedData['min'], 'max' => $relatedData['max'], 'content' => $content, 'id' => !empty($relatedData['learners_range_id']) ? $relatedData['learners_range_id'] : 0);
                    $returnData['learnerRange'][] = $learnerRangeData;
                }
            }
        }

        if (!empty($data)) {
            $returnData['category_id'] = split(',', $data['category_id']);
        }
        if (!empty($data)) {
        $returnData['partnershipDetails']['heading'] = !empty($data['heading']) ? $data['heading'] :'';
        $returnData['partnershipDetails']['heading_content'] = !empty($data['heading_content']) ? $data['heading_content'] :'';
        $returnData['partnershipDetails']['advantage_section'] = !empty($data['advantage_section']) ? $data['advantage_section'] :'';
        $returnData['partnershipDetails']['advantage_content'] = !empty($data['advantage_content']) ? $data['advantage_content'] :'';
        $returnData['partnershipDetails']['getting_started_section'] = !empty($data['getting_started_section']) ? $data['getting_started_section'] :'';
        $returnData['partnershipDetails']['get_start_content'] = !empty($data['get_start_content']) ? $data['get_start_content'] :'';
        }
        if (!empty($data)) {
            if (!empty($data['excluded_course_ids'])) {
                $dataIds = split(',', $data['excluded_course_ids']);
                foreach ($dataIds as $type => $val) {
                    $returnData['companyExcludedCourses'][] = array('linkable_id' => $val);
                }
            }
            if (!empty($data['excluded_masterprogram_ids'])) {
                $excludedMPIds = split(',', $data['excluded_masterprogram_ids']);
                if (!empty($excludedMPIds)) {
                    foreach ($excludedMPIds as $type => $val) {
                        $returnData['companyExcludedMasterProgram'][] = array('linkable_id' => $val);
                    }
                }
            }
        }
        unset($data['category_id']);
        unset($data['category_id_tmp']);
        unset($data['companyPricingCat']);
        unset($data['companyPricingCourse']);
        unset($data['companyAgencies']);
        unset($data['excluded_course_ids']);
        unset($data['exclusion_courses']);
        unset($data['exclusion_master_program']);
        unset($data['excluded_masterprogram_ids']);
        unset($data['learnerRange']);
        return $returnData;
    }

    /* delete function Calls an Api to check whether Payment Exists against it */

    public function deleteAction() {
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $form = $this->_getForm();
        $Id = $this->getRequest()->getParam('id');
        $b2bCompanies = new Model_B2BCompanies();
        if (!$Id) {
            throw new BaseApp_Exception('Editable item not selected properly');
        }

        $courseAdvisorData = current($this->getModel()->fetchAll(array('id =?' => $Id)));
        if (empty($courseAdvisorData)) {
            throw new BaseApp_Exception('No Data found');
        }

        $data['status'] = 0;
        $result = $this->getModel()->updateProductSectionData($Id, $data);
        $returnValue = $b2bCompanies->deleteB2bCompanies($Id);
        if (!$result) {
            $this->view->message = "An error has occured while saving";
            $this->view->success = true;
            $module = $this->getRequest()->getModuleName();
            $controller = $this->getRequest()->getControllerName();
            $action = $this->getRequest()->getActionName();
            if ($module && $controller && $action) {
                $this->redirect($module . '/' . $controller . '/' . $action . '/id/' . $Id);
            }
        } else {
            $this->view->message = "Saved SuccessFully";
            $this->view->success = false;
            $form->reset();
            $module = $this->getRequest()->getModuleName();
            $controller = $this->getRequest()->getControllerName();
            $action = $this->getRequest()->getActionName();
            if ($module && $controller && $action) {
                $this->redirect($module . '/' . $controller . '/list');
            }
        }
    }

    public function listAction() {
        $this->_helper->viewRenderer->setRender('common/list')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');

        $table = $this->getModel()->getName();
        $filterForm = new Form_Filters($table);
        $requestData = array();
        $queryParamsArr = array();
        $page = '';
        if ($this->getRequest()->isPost()) {
            $filterForm->populate($this->getRequest()->getPost());
            $page = 1;
            $requestData = $filterForm->getValues();
            foreach ($requestData as $elementName => $elementValue) {
                if (!empty($elementValue)) {
                    $queryData = $filterForm->getElement($elementName)->getAttrib('data-table');
                    $queryData['searchValue'] = $elementValue;
                    $this->queryBuilder($queryData);
                    $queryParamsArr[$queryData['search_id']] = $elementValue;
                }
            }
        }
        if (empty($page)) {
            $page = $this->view->navigatorPage;
            $page = (int) $this->getRequest()->getParam('page');
        }
        $orderby = $this->getModel()->getPk() . ' DESC';
        if (empty($this->_queryParams)) {
            $getData = $this->getRequest()->getQuery();
            unset($getData['page']);
            if (!empty($getData)) {
                foreach ($getData as $key => $value) {
                    $queryParamsArr[$key] = $value;
                    $returnData = $filterForm->getSearchFields($key);
                    if (!empty($returnData)) {
                        $returnData = $returnData[0];
                        $filterForm->getElement($returnData['searchColumnName'])->setValue($value);
                        $returnData['searchValue'] = $value;
                        $this->queryBuilder($returnData);
                    }
                }
            }
        }
        if ($page <= 1) {
            $this->view->firstpage = true;
            $page = 1;
        } else {
            $this->view->firstpage = false;
        }
        $offset = ($page - 1) * self::ROWS_PER_PAGE;
        $limit = array(self::ROWS_PER_PAGE, $offset);
        $this->view->page = $page;
        $model = $this->getModel();
        $this->_queryParams['sectionType =?'] = 'company';
        $data = $model->fetchAll($this->_queryParams, array('order' => array($orderby), 'limit' => $limit));
        $perPageData = count($data);
        if (count($data) < self::ROWS_PER_PAGE) {
            $this->view->lastpage = true;
        } else {
            $this->view->lastpage = false;
        }
        $total = $model->fetchCount($this->_queryParams);
        $numberOfPages = ceil($total / self::ROWS_PER_PAGE);
        if ($page < $numberOfPages) {
            $this->view->currentPageRecord = self::ROWS_PER_PAGE * $page;
        } else {
            $this->view->currentPageRecord = $total;
        }
        $this->view->diffPageRecord = $this->view->currentPageRecord - self::ROWS_PER_PAGE;
        if (count($data) < self::ROWS_PER_PAGE) {
            $this->view->diffPageRecord = $total - count($data);
        }
        $this->view->totalCount = $total;
        $this->view->totalPages = $numberOfPages;
        $this->view->lastPage = $numberOfPages;
        $pk = $model->getPk();
        foreach ($data as $key => &$row) {
            $row['Action'] = "<a href='" . $this->view->url(array('action' => 'view', 'id' => $row[$pk])) . "'>View</a> " . "<a href='" . $this->view->url(array('controller' => 'changelog', 'action' => 'index', 'row' => $row[$pk], 'table' => $table)) . "'>ChangeLog</a> " . "<a href='#' onclick='deleteConfirmShow(\"" . $this->view->url(array('controller' => 'company', 'action' => 'delete', 'id' => $row[$pk])) . "\")'>Delete</a> " .
                    "<a href='" . $this->view->url(array('action' => 'edit', 'id' => $row[$pk])) . "'>Edit</a> ";
        }
        if (isset($data[0])) {
            $original = array_keys($data[0]);
        } else {
            $original = array();
        }
        $as = ($this->_displayInDataTable);
        $datatableFilePath = '../../library/BaseApp/Datatable/' . ucfirst('Company') . '.php';
        if (file_exists($datatableFilePath)) {
            $dataTableClass = 'BaseApp_Datatable_' . ucfirst('Company');
        } else {
            $dataTableClass = 'BaseApp_Datatable_Default';
        }

        $dataTable = new $dataTableClass;
        $dataTable->setData($data);
        $this->view->data = $dataTable;
        $this->view->original = $original;
        $this->view->displayInDataTable = $as;
        $this->view->queryParams = http_build_query($queryParamsArr);
        $this->view->form = $filterForm;
        $this->view->navigatorTotal = ceil($total / BACKEND_ROWS_PER_PAGE);
    }

    private function _setProductCategory($request) {
        $session = new Zend_Session_Namespace('form');
        if (isset($request['product_category']) && count($request['product_category'])) {
            $request['product_category'] = $this->_updateFirstElement($request['product_category']);
            $session->productCategory = array_keys($request['product_category']);
            array_unshift($session->productCategory, '__template__');
            $session->productCategory = $request['product_category'];
        } else {
            $session->productCategory = array('__template__', 'new');
            $session->productCategory = array();
        }
    }

    private function _checkLearnerRange($learnerRange) {
        $updatedLearnerRange = array();
        if (!empty($learnerRange)) {
            $updatedLearnerRange = array();
            foreach ($learnerRange as $range) {
                if ((int) $range['max'] === 0) {
                    $updatedLearnerRange[] = $range;
                    break;
                }
                $updatedLearnerRange[] = $range;
            }
        }
        return $updatedLearnerRange;
    }

    private function _validateLearnerRange($learnerRangeData) {
        $isHigherRangeEmpty = false;
        if (!empty($learnerRangeData)) {
            foreach ($learnerRangeData as $data) {
                if ((int) $data['max'] === 0) {
                    $isHigherRangeEmpty = true;
                    break;
                }
            }
        }
        return $isHigherRangeEmpty;
    }

}
