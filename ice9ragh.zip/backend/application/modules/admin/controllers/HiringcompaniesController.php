<?php

/*
 * Contains the CRUD actions of Accreditors table
 * 
 */

class Admin_HiringcompaniesController extends BaseApp_Controller_Crud {

    protected $_model = 'Model_ProductSectionData';
    protected $_descriptions = array(
        'list' => 'List of Existing Hiring Companies',
        'index' => 'List of Existing Hiring Companies',
        'add' => 'Add New Hiring Companies',
        'edit' => 'Make the required changes then click on "Save Hiring Companies" to update the Hiring Companies',
        'view' => 'View Selected Hiring Companies'
    );

    protected function _getForm($data=array()) {
        $form = new Form_HiringCompanies($data);
        return $form;
    }

    public function listAction() {
        $this->_helper->viewRenderer->setRender('common/list')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');

        $table = $this->getModel()->getName();
        $filterForm = new Form_Filters($table);
        $requestData = array();
        $queryParamsArr = array();
        $page = '';
        if ($this->getRequest()->isPost()) {
            $filterForm->populate($this->getRequest()->getPost());
            $page = 1;
            $requestData = $filterForm->getValues();
            foreach ($requestData as $elementName => $elementValue) {
                if (!empty($elementValue)) {
                    $queryData = $filterForm->getElement($elementName)->getAttrib('data-table');
                    $queryData['searchValue'] = $elementValue;
                    $this->queryBuilder($queryData);
                    $queryParamsArr[$queryData['search_id']] = $elementValue;
                }
            }
        }
        if (empty($page)) {
            $page = $this->view->navigatorPage;
            $page = (int) $this->getRequest()->getParam('page');
        }
        $orderby = $this->getModel()->getPk() . ' DESC';
        if (empty($this->_queryParams)) {
            $getData = $this->getRequest()->getQuery();
            unset($getData['page']);
            if (!empty($getData)) {
                foreach ($getData as $key => $value) {
                    $queryParamsArr[$key] = $value;
                    $returnData = $filterForm->getSearchFields($key);
                    if (!empty($returnData)) {
                        $returnData = $returnData[0];
                        $filterForm->getElement($returnData['searchColumnName'])->setValue($value);
                        $returnData['searchValue'] = $value;
                        $this->queryBuilder($returnData);
                    }
                }
            }
        }
        if ($page <= 1) {
            $this->view->firstpage = true;
            $page = 1;
        } else {
            $this->view->firstpage = false;
        }
        $offset = ($page - 1) * self::ROWS_PER_PAGE;
        $limit = array(self::ROWS_PER_PAGE, $offset);
        $this->view->page = $page;
        $model = $this->getModel();
        $this->_queryParams['sectionType =?'] = 'hiring_companies';
        $data = $model->fetchAll($this->_queryParams, array('order' => array($orderby), 'limit' => $limit));

        $perPageData = count($data);
        if (count($data) < self::ROWS_PER_PAGE) {
            $this->view->lastpage = true;
        } else {
            $this->view->lastpage = false;
        }
        $total = $model->fetchCount($this->_queryParams);
        $numberOfPages = ceil($total / self::ROWS_PER_PAGE);
        if ($page < $numberOfPages) {
            $this->view->currentPageRecord = self::ROWS_PER_PAGE * $page;
        } else {
            $this->view->currentPageRecord = $total;
        }
        $this->view->diffPageRecord = $this->view->currentPageRecord - self::ROWS_PER_PAGE;
        if (count($data) < self::ROWS_PER_PAGE) {
            $this->view->diffPageRecord = $total - count($data);
        }
        $this->view->totalCount = $total;
        $this->view->totalPages = $numberOfPages;
        $this->view->lastPage = $numberOfPages;
        $pk = $model->getPk();
        foreach ($data as $key => &$row) {
            $row['Action'] = "<a href='" . $this->view->url(array('action' => 'view', 'id' => $row[$pk])) . "'>View</a> " . "<a href='" . $this->view->url(array('controller' => 'changelog', 'action' => 'index', 'row' => $row[$pk], 'table' => $table)) . "'>ChangeLog</a> " . "<a href='#' onclick='deleteConfirmShow(\"" . $this->view->url(array('controller' => 'hiringcompanies', 'action' => 'delete', 'id' => $row[$pk])) . "\")'>Delete</a> " .
                    "<a href='" . $this->view->url(array('action' => 'edit', 'id' => $row[$pk])) . "'>Edit</a> ";
        }
        if (isset($data[0])) {
            $original = array_keys($data[0]);
        } else {
            $original = array();
        }
        $as = ($this->_displayInDataTable);
        $datatableFilePath = '../../library/BaseApp/Datatable/' . ucfirst('HiringCompany') . '.php';
        if (file_exists($datatableFilePath)) {
            $dataTableClass = 'BaseApp_Datatable_HiringCompany';
        } else {
            $dataTableClass = 'BaseApp_Datatable_Default';
        }

        $dataTable = new $dataTableClass;
        $dataTable->setData($data);
        $this->view->data = $dataTable;
        $this->view->original = $original;
        $this->view->displayInDataTable = $as;
        $this->view->queryParams = http_build_query($queryParamsArr);
        $this->view->form = $filterForm;
        $this->view->navigatorTotal = ceil($total / BACKEND_ROWS_PER_PAGE);
    }

    public function addAction() {
        if (!$this->_add)
            $this->forward('list');
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $form = $this->_getForm();
        if ($form === false)
            throw new Zend_Exception('_getForm not implemented');
        if ($this->getRequest()->isPost()) {
            $request = $this->getRequest()->getPost();
            //merge fields and files for validation        
            $postData = array_merge_recursive($request, $_FILES);
        }
        if ($this->getRequest()->isPost() && $form->isValid($postData)) {
            $request = $this->getRequest()->getPost();
            $formValues = $form->getValues();
            $formValues['sectionType'] = 'hiring_companies';
            
            //process certificate image          
            if(isset($_FILES['logo']['name']) && $_FILES['logo']['name'] != '') {
                $fileName = $_FILES['logo']['name'];
                $absFilePath = sys_get_temp_dir().DIRECTORY_SEPARATOR.$fileName;
                $s3path = AWS_S3_IMAGES_PATH.'/logos';
                $certificateImageUrl = BaseApp_Utility_ImageProcessing::transformAndUploadToS3($absFilePath, $fileName, $s3path); 
                if (isset($certificateImageUrl)){
                    $formValues['imageUrl'] = $certificateImageUrl;
                }    
            }
            if(isset($formValues['long_description'])&&!empty($formValues['long_description'])){
                $formValues['long_description'] = serialize($formValues['long_description']);
            }
            unset($formValues['logo']);
            $form->removeOptionalElements();
            $result = $this->getModel()->setFromArray($formValues)->save();
            if (!$result) {
                $this->view->message = "An error has occured while saving";
                $this->view->success = true;
            } else {
                $this->view->message = "Data successfully added";
                $this->view->success = false;
                $form->reset();
                $module = $this->getRequest()->getModuleName();
                $controller = $this->getRequest()->getControllerName();
                $action = $this->getRequest()->getActionName();
                if ($module && $controller && $action)
                    $this->redirect($module . '/' . $controller . '/list?success=true');
            }
            //$this->forward('list');
        }
        $this->view->form = $form;
    }

    public function editAction() {
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $id = $this->getRequest()->getParam('id');
        $data = $this->getModel($id);
        if ($data) {
            $this->view->postParams = $data;
            $form = $this->_getForm($data);
            $form->removeOptionalValidators();
            $form->removeUneditableElements();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            if ($this->getRequest()->isPost()) {
                $request = $this->getRequest()->getPost();
                //merge fields and files for validation        
                $postData = array_merge_recursive($request, $_FILES);
            }
            if ($this->getRequest()->isPost() && $form->isValid($postData)) {
                $form->removeOptionalElements();
                $formValues = $form->getValues();
                $formValues['sectionType'] = 'hiring_companies';
                //process certificate image          
                if(isset($_FILES['logo']['name']) && $_FILES['logo']['name'] != '') {
                    $fileName = $_FILES['logo']['name'];
                    $absFilePath = sys_get_temp_dir().DIRECTORY_SEPARATOR.$fileName;
                    $s3path = AWS_S3_IMAGES_PATH.'/logos';
                    $certificateImageUrl = BaseApp_Utility_ImageProcessing::transformAndUploadToS3($absFilePath, $fileName, $s3path); 
                    if (isset($certificateImageUrl)){
                        $formValues['imageUrl'] = $certificateImageUrl;
                    }    
                }
                if( isset($formValues['long_description']) && !empty($formValues['long_description'] )){
                    $formValues['long_description'] = serialize($formValues['long_description']);
                }
                unset($formValues['logo']);
                unset($formValues['logo_value']);
                $result = $data->setFromArray($formValues)->update();
                if (!$result) {
                    $this->view->message = "An error has occured while saving";
                    $this->view->success = true;
                } else {
                    // for making message page specific
                    $this->view->message = ucwords($this->getRequest()->getControllerName()) . " Data successfully updated";
                    $this->view->success = false;
                    $module = $this->getRequest()->getModuleName();
                    $controller = $this->getRequest()->getControllerName();
                    $action = $this->getRequest()->getActionName();
                    if ($module && $controller && $action)
                        $this->redirect($module . '/' . $controller . '/list?success=true');
                }
                //$this->forward('list');
            }
            $defaults = $data->toArray();
            if(!empty($defaults['long_description'])){
                $defaults['long_description'] = unserialize($defaults['long_description']);
            }
            $form->setDefaults($defaults);
            $this->view->form = $form;
        }
    }

    public function viewAction($useCommonView = true) {
        if ($useCommonView) {
            $this->_helper->viewRenderer->setRender('common/view')->setNoController(true);
            $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        }
        $id = $this->getRequest()->getParam('id');
        $data = $this->getModel($id)->toArray();
        if ($data) {
            $utilityObj = new BaseApp_Utility_ReplaceString();
            if(is_array($data) && count($data)>0){
                foreach($data as $key=>$val){
                    if(in_array($key,$utilityObj->getHiddenColumns())){
                        $data[$key] = $utilityObj->replaceAlteranateByStart($val);
                    }
                }
            }
            
            $hiddenFileds = array('linkable_id','linkable_type_id','sectionType','sectionTitle','designation',
                'acheivementText','show_at_top','company_sf_acc_id','company','linkedin_url','twitter_url','company_price_plans');
            
            foreach($hiddenFileds as $val){
                if(array_key_exists($val, $data)){
                    unset($data[$val]);
                }
            }
            
            if(array_key_exists('long_description', $data)){
                if(!empty($data['long_description'])){
                    $data['long_description'] = implode(', ',unserialize($data['long_description']));
                }
            }
            
            $renameArray = array('id'=>'Id','imageUrl'=>'Company Logo','name'=>'Name of the company','alt_text'=>'Image Alt tag','description'=>'Image Link','status'=>'Status','long_description'=>'Where this will be shown');
            foreach($renameArray as $key=>$val){
                if(array_key_exists($key, $data)){
                    $data[$val] = $data[$key];
                    unset($data[$key]);
                }
            }
            $this->view->data = $data;
        } else {
            $this->view->noData = true;
        }
    }
    
}
