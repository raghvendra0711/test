<?php
/*
 * Contains the CRUD actions of Schedules table
 * 
 */

class Admin_ScheduleController extends BaseApp_Controller_Crud {
    protected $_model = 'Model_Schedules';
    protected $_descriptions = array(
        'list' => 'List of Existing Schedules',
        'index' => 'List of Existing Schedules',
        'add' => 'Add New Schedules',
        'edit' => 'Make the required changes then click on "Save Schedules" to update the Schedules',
        'view' => 'View Selected Schedules'
    );

    protected function _getForm() {
        $form = new Form_Schedules();
        return $form;
    }
}
