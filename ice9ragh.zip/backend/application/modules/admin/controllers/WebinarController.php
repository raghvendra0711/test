<?php
/*
 * Contains the CRUD actions of Webinars table
 * 
 */

class Admin_WebinarController extends BaseApp_Controller_Crud {
    protected $_model = 'Model_Webinars';
    protected $_descriptions = array(
        'list' => 'List of Existing Webinars',
        'index' => 'List of Existing Webinars',
        'add' => 'Add New Webinars',
        'edit' => 'Make the required changes then click on "Save Webinars" to update the Webinars',
        'view' => 'View Selected Webinars'
    );

    protected function _getForm() {
        $form = new Form_Webinars();
        return $form;
    }
    
    public function addAction() {        
        $request = $this->getRequest()->getPost();               
        $this->_setCountryPrice($request);//pending
        $this->_setWebinarFaq($request);
        $this->_setRecommendations($request);
        
        if (!$this->_add)
            $this->forward('list');
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $form = $this->_getForm();        
        if ($form === false)
            throw new Zend_Exception('_getForm not implemented');
        if ($request && $form->isValid($request)) {
            $request = $form->getValues(); 
            if(!$this->_isValid($request, $message)) {
                $this->view->message = $message;
                $this->view->success = false;
                $this->view->form = $form;
                return;
            }
            $splitData = $this->_handleDataAfterSubmit($request);
            $request['searchTags'] = $splitData['searchTags'];
            $result = false;
            if($webinarId = $this->getModel()->createWebinar($request)) {
                $result = true;

                $pricing = new Model_SubscriptionPricing();
                if($result && !$pricing->savePricing($webinarId, 'webinar', $splitData['countryPrice'])) {
                    $result = false;
                }
                    
                $faq = new Model_PracticeFaq();
                if($result && !$faq->saveFaq($webinarId, 'webinar', $splitData['webinarFaq'])) {
                    $result = false;
                }

                $recommend = new Model_Recommendations();
                if($result && !$recommend->saveRecommendations($webinarId, 'webinar', $splitData['recommendations'])) {
                    $result = false;
                }

                $tags = new Model_Tags();
                if($result && !$tags->saveTags($webinarId, 'webinar', $splitData['searchTags'])) {
                    $result = false;
                }
            }
            if (!$result) {
                $this->view->message = "An error has occured while saving";
                $this->view->success = true;
            } else {
                $cdnPurgeData = $this->getModel()->buildCdnPurgeData($webinarId,$request['name'].' Webinar Added');
                $objCdn = new Model_CdnPurgeLog();
                if(!empty($cdnPurgeData))
                    $objCdn->InsertCdnPurgeLog($cdnPurgeData);
                $this->view->message = "Data successfully added";
                $this->view->success = false;
                $form->reset();
                $module  = $this->getRequest()->getModuleName();
                $controller = $this->getRequest()->getControllerName();
                $action = $this->getRequest()->getActionName();
                if($module && $controller && $action)
                    $this->redirect($module.'/'.$controller.'/');
            }
        }
        $this->view->form = $form;
    }
    
    public function editAction() {  
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
                        
        if ($this->getRequest()->isPost()) {
            $request = $this->getRequest()->getPost();               
            $this->_setCountryPrice($request);//pending
            $this->_setWebinarFaq($request);
            $this->_setRecommendations($request);
            
            $form = $this->_getForm();
            $form->removeUneditableElements();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            if($form->isValid($request)) {
                $data = $form->getValues();
                if(!$this->_isValid($data, $message)) {
                    $this->view->message = $message;
                    $this->view->success = false;
                    $this->view->form = $form;
                    return;
                }
                $splitData = $this->_handleDataAfterSubmit($data);
                $data['webinar_id'] = $this->getRequest()->getParam('id');   
                unset($data['webinar_ident']);
                unset($data['isDemo']);
                if($this->getModel()->updateWebinar($data)) {
                    $result = true;

                    $pricing = new Model_SubscriptionPricing();
                    if($result && !$pricing->savePricing($data['webinar_id'], 'webinar', $splitData['countryPrice'])) {
                        $result = false;
                    }
                    
                    $faq = new Model_PracticeFaq();
                    if($result && !$faq->saveFaq($data['webinar_id'], 'webinar', $splitData['webinarFaq'])) {
                        $result = false;
                    }

                    $recommend = new Model_Recommendations();
                    if($result && !$recommend->saveRecommendations($data['webinar_id'], 'webinar', $splitData['recommendations'])) {
                        $result = false;
                    }

                    $tags = new Model_Tags();
                    if($result && !$tags->saveTags($data['webinar_id'], 'webinar', $splitData['searchTags'])) {
                        $result = false;
                    }
                }
                $result = false;
                if (!$result) {
                    $this->view->message = "An error has occured while saving";
                    $this->view->success = true;
                } else {
                    // for making message page specific
                    $cdnPurgeData = $this->getModel()->buildCdnPurgeData($webinarId,$request['name'].' Webinar Modified');
                    $objCdn = new Model_CdnPurgeLog();
                    if(!empty($cdnPurgeData))
                        $objCdn->InsertCdnPurgeLog($cdnPurgeData);
                    $this->view->message = ucwords($this->getRequest()->getControllerName())." Data successfully updated";
                    $this->view->success = false;
                }
                $this->_redirect('/admin/webinar/list');
            }
        }    
        elseif($webinarId = $this->getRequest()->getParam('id')) {            
            $webinarModel = new Model_Webinars($webinarId);
            if(!$webinarModel->toArray()) {
                $this->_redirect('/admin/webinar/list');
            }
            $session = new Zend_Session_Namespace('form'); 
            /*
             * pricing model
             */
            $priceModel = new Model_SubscriptionPricing();
            $priceData = array(
                'countryPrice' => $priceModel->getByLinkable($webinarId, 'webinar')
            );
            $this->_setCountryPrice($priceData);            
            
            /*
             * faq model
             */           
            $faq = new Model_PracticeFaq();
            $faqData = array(
                'webinarFaq' => $faq->getByLinkable($webinarId, 'webinar')
            );
            $this->_setWebinarFaq($faqData);

            /*
             * recommendation model
             */
            $recommend = new Model_Recommendations();
            $recommendData = array(
                'recommendations' => $recommend->getByLinkable($webinarId, 'webinar')
            );
            $this->_setRecommendations($recommendData);    

            /*
             * faq model
             */
            $tags = new Model_Tags();
            if($tagData = $tags->getByLinkable($webinarId, 'webinar')) {
                $webinarModel->searchTags = $tagData['tag'];
            }
            
            /*
            $courseModel = new Model_Courses();        
            $webinarModel->course_name =  $courseModel->getNameById($webinarModel->course_id);                  
             * 
             */
            
            $webinarModel->label_id = explode(",", $webinarModel->label_id);
            $webinarModel->course_id = explode(",", $webinarModel->course_id);
            
            $this->view->postParams = $webinarModel;
            $form = $this->_getForm();
            $form->removeUneditableElements();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');            
            $form->setDefaults($webinarModel->toArray());            
        }
        else {
            $this->_redirect('/admin/webinar/list');
        }
        $this->view->form = $form;
    }
    
    private function _handleDataAfterSubmit(&$data) {
        $returnData = array(
            'countryPrice' => array(),
            'webinarFaq' => array(),
            'recommendations' => array(),
            'searchTags' => false
        );
        
        unset($data['course_name']);
        if(isset($data['countryPrice'])) {
            unset($data['countryPrice']['__template__']);
            $returnData['countryPrice'] = $data['countryPrice'];
            unset($data['countryPrice']);
        }
        if(isset($data['webinarFaq'])) {
            unset($data['webinarFaq']['__template__']);
            $returnData['webinarFaq'] = $data['webinarFaq'];
            unset($data['webinarFaq']);
        }
        if(isset($data['recommendations'])) {
            unset($data['recommendations']['__template__']);
            $returnData['recommendations'] = $data['recommendations'];
            unset($data['recommendations']);
        }
        if(isset($data['searchTags'])) {
            $returnData['searchTags'] = $data['searchTags'];
            unset($data['searchTags']);
        }     
        if(isset($data['course_id'])) {
            $data['course_id'] = implode(",", $data['course_id']);
        }
        if(isset($data['label_id'])) {
            $data['label_id'] = implode(",", $data['label_id']);
        }          
        return $returnData;
    }
    
    private function _setCountryPrice(&$request) {
        $session = new Zend_Session_Namespace('form'); 
        if(isset($request['countryPrice']) && count($request['countryPrice'])) {
            $request['countryPrice'] = $this->_updateFirstElement($request['countryPrice']);        
            $session->countryPrice = array_keys($request['countryPrice']);
            array_unshift($session->countryPrice, '__template__');
            $session->countryPriceData =  $request['countryPrice'];
        }
        else {
            $session->countryPrice = array('__template__', 'new');
            $session->countryPriceData = array();
        }        
    }
    
    private function _setWebinarFaq(&$request) {
        $session = new Zend_Session_Namespace('form'); 
        if(isset($request['webinarFaq']) && count($request['webinarFaq'])) {
            $request['webinarFaq'] = $this->_updateFirstElement($request['webinarFaq']);        
            $session->webinarFaq = array_keys($request['webinarFaq']);
            array_unshift($session->webinarFaq, '__template__');
            $session->webinarFaqData =  $request['webinarFaq'];
        }
        else {
            $session->webinarFaq = array('__template__', 'new');
            $session->webinarFaqData = array();
        }
    }
    
    private function _setRecommendations(&$request) {
        $session = new Zend_Session_Namespace('form'); 
        if(isset($request['recommendations']) && count($request['recommendations'])) {
            $request['recommendations'] = $this->_updateFirstElement($request['recommendations']);        
            $session->recommendations = array_keys($request['recommendations']);
            array_unshift($session->recommendations, '__template__');
            $session->recommendationsData =  $request['recommendations'];
        }
        else {
            $session->recommendations = array('__template__', 'new');
            $session->recommendationsData = array();
        }
    }
    
    private function _updateFirstElement($elementArray) {
        $keys = array_keys( $elementArray );
        $keys[ array_search( '0', $keys ) ] = 'new';
        return array_combine( $keys, $elementArray );    
    }
    
    public function getByRelatedAction() {
        $arg = $this->getRequest()->get('webinarPart');
        $webinarList = array();
        if($arg) {
            $model = new Model_Webinars();
            foreach($model->fetchAll( array('name LIKE ?'=>'%'.$arg.'%'), array(), false) as $indexId => $data) {
                $webinarList[$data['webinar_id']] = $data['name'];
            }
        }        
        $this->_helper->layout->disableLayout();
        $this->view->webinarList =  $webinarList;
    }
    
    private function _isValid($data, &$message='') {
        if(isset($data['course_id']) && count($data['course_id']) > Model_Ebooks::MAX_COURSES_ALLOWED_LINK) {
            $message = sprintf("Maximum %d courses allowed", Model_Ebooks::MAX_COURSES_ALLOWED_LINK);
            return false;
        }
        
        if(isset($data['label_id']) && count($data['label_id']) > Model_Ebooks::MAX_CATEGORIES_ALLOWED_LINK) {
            $message = sprintf("Maximum %d Categories allowed", Model_Ebooks::MAX_CATEGORIES_ALLOWED_LINK);
            return false;
        }
        return true;
    }
}
