<?php
/*
 * Contains the CRUD actions of TrainingTypes table
 * 
 */

class Admin_TrainingTypesController extends BaseApp_Controller_Crud {
    protected $_model = 'Model_TrainingTypes';
    protected $_descriptions = array(
        'list' => 'List of Existing TrainingTypes',
        'index' => 'List of Existing TrainingTypes',
        'add' => 'Add New TrainingTypes',
        'edit' => 'Make the required changes then click on "Save TrainingTypes" to update the TrainingTypes',
        'view' => 'View Selected TrainingTypes'
    );

    protected function _getForm() {
        $form = new Form_TrainingTypes();
        return $form;
    }
}
