<?php
/*
 * Contains the CRUD actions of Pass Promos table
 * 
 */

class Admin_PromoController extends BaseApp_Controller_Crud {
    protected $_model = 'Model_PromoParams';
    protected $_descriptions = array(
        'list' => 'List of Existing PromoParams',
        'index' => 'List of Existing PromoParams',
        'add' => 'Add New PromoParams',
        'edit' => 'Make the required changes then click on "Save PromoParams" to update the PromoParams',
        'view' => 'View Selected PromoParams'
    );

    protected function _getForm() {
        $form = new Form_PromoParams();
        return $form;
    }

    public function addAction() {
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $objPromo = new Model_PromoParams();
        $form = new Form_PromoParams();
        $request = $this->getRequest()->getPost();
        if ($this->getRequest()->isPost() && $form->isValid($request)) {
            $data = $form->getValues();
            $promoData = current($this->getModel()->fetchAll(array('promoValue =?'=>$data['promoValue']), array(), false));
            if(!empty($promoData)){
                $this->view->message = "Promo Param Value Does Exists";
                $this->view->success = false;
                $this->view->form = $form;
                return false;
            }
            $result = $this->getModel()->addPromoParams($data);
            if (!$result) {
                $this->view->message = "An error has occured while saving";
                $this->view->success = false;
            } else {
                $this->view->message = "Saved SuccessFully";
                $this->view->success = false;
                $form->reset();
                $module  = $this->getRequest()->getModuleName();
                $controller = $this->getRequest()->getControllerName();
                $action = $this->getRequest()->getActionName();
                if($module && $controller && $action)
                    $this->redirect($module.'/'.$controller.'/list');
            }
        }
        $this->view->form = $form;
    }

    public function editAction() {
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $Id = $this->getRequest()->getParam('id');
        if(!$Id)
            throw new BaseApp_Exception('Editable item not selected properly');        
        $promoData = current($this->getModel()->fetchAll(array('promo_id =?'=>$Id), array(), false));
        if (!$promoData) {
            throw new BaseApp_Exception('Editable item not selected properly');
        }
        $form = new Form_PromoParams();
        if ($this->getRequest()->isPost()) {
            $form->removeOptionalElements();
            $form->removeUneditableElements();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            if ($form->isValid($this->getRequest()->getPost())) {
                $data = $form->getValues();
                if(array_key_exists('promoValue', $data))
                    unset($data['promoValue']);
                $result = $this->getModel()->UpdatePromoParams($data,$Id);
                if (!$result) {
                    $this->view->message = "An error has occured while saving";
                    $this->view->success = true;
                    $module  = $this->getRequest()->getModuleName();
                    $controller = $this->getRequest()->getControllerName();
                    $action = $this->getRequest()->getActionName();
                    if($module && $controller && $action)
                        $this->redirect($module.'/'.$controller.'/'.$action.'/id/'.$Id);
                } else {
                    $this->view->message = "Saved SuccessFully";
                    $this->view->success = false;
                    $form->reset();
                    $module  = $this->getRequest()->getModuleName();
                    $controller = $this->getRequest()->getControllerName();
                    $action = $this->getRequest()->getActionName();
                    if($module && $controller && $action)
                        $this->redirect($module.'/'.$controller.'/list');
                }
            }          
        } 
        else {
            $form->removeOptionalElements();
            $form->removeUneditableElements();
            $form->setDefaults($promoData);
        }
        $this->view->form = $form;
    }
}
