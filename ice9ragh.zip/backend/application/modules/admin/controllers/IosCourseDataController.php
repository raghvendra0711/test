<?php

class Admin_IosCourseDataController extends BaseApp_Controller_Crud {
    
    CONST IOS_PACKAGE_NAME = 'com.simplilearn.Simplilearn';
    CONST CURRENCY_FOR_KEY = 'USD';

    protected $_model = 'Model_IosCourseData';

     
    public function listAction() {
  	$table = $this->getModel()->getName();
        $model = $this->getModel();
        $data = $model->getAllCoursesKey();
        $total = $model->fetchCount($this->_queryParams);

        $this->_paginationData($data, $total);
        
        $pk = $model->getPk();
        foreach ($data as &$row) {
            $row['Action'] = "<a href='" . $this->view->url(array('action' => 'view', 'id' => $row[$pk])) . "'>View</a> " .
                             "<a href='" . $this->view->url(array('controller' => 'changelog', 'action' => 'index', 'row' => $row[$pk], 'table' => $table)) . "'>ChangeLog</a> " .
                             "<a href='#' onclick='deleteConfirmShow(\"" . $this->view->url(array('controller' => 'course', 'action' => 'delete', 'id' => $row[$pk])) . "\")'>Delete</a> " .
                             "<a href='" . $this->view->url(array('action' => 'basic', 'courseId' => $row[$pk])) . "'>Edit</a> " ;
        }

        $original = array();
        if(isset($data[0])) {
            $original = array_keys($data[0]);
        }
       
        $datatableFilePath = '../../library/BaseApp/Datatable/'.ucfirst($table).'.php';       
        if(file_exists($datatableFilePath)) {
            $dataTableClass = 'BaseApp_Datatable_'.ucfirst($table);               
        } else {
            $dataTableClass = 'BaseApp_Datatable_Default';                            
        }

        $dataTable = new $dataTableClass;
        $dataTable->setData($data);
        $this->view->data = $dataTable;
        $this->view->original = $original;
        $this->view->displayInDataTable = $this->_displayInDataTable;
        $this->view->navigatorTotal = ceil($total / BACKEND_ROWS_PER_PAGE);
    }


    protected function _paginationData($data, $total) {
          $page = (int)$this->getRequest()->getParam('page');
  
          if (empty($page) || $page <= 1) {
              $this->view->firstpage = true;
              $page = 1;
          } else {
              $this->view->firstpage = false;
          }
  
          $offset = ($page - 1) * self::ROWS_PER_PAGE;
          $limit = array(self::ROWS_PER_PAGE,$offset);
          $this->view->page = $page;
          $perPageData = count($data);
          if ($perPageData < self::ROWS_PER_PAGE) {
              $this->view->lastpage = true;
          } else {
              $this->view->lastpage = false;
          }

          $numberOfPages = ceil($total / self::ROWS_PER_PAGE);
       
          if($page < $numberOfPages) {
              $this->view->currentPageRecord = self::ROWS_PER_PAGE * $page;
          } else {
              $this->view->currentPageRecord = $total;
          }
          $this->view->diffPageRecord = $this->view->currentPageRecord - self::ROWS_PER_PAGE;
          if(count($data) < self::ROWS_PER_PAGE) { 
              $this->view->diffPageRecord = $total - count($data);
          }

          $this->view->totalCount = $total;
          $this->view->totalPages = $numberOfPages;
          $this->view->lastPage = $numberOfPages;
    }    


    public function addCourseKey($courseId, $accessDays) {
	if(empty($courseId) || empty($accessDays)) {
		return false;
	}

	$accessDaysArr = explode(',', $accessDays);

        $courseKeyDelimiter = '.';
        
        foreach($accessDaysArr as $accessDays) {
            $courseKeyArr['course_id'] = $courseId;
            $coursekeyArr['access_days'] = $accessDays;
            $courseKeyArr['course_key'] = self::IOS_PACKAGE_NAME . $courseKeyDelimiter . $courseId . $courseKeyDelimiter . $accessDays . $courseKeyDelimiter . self::CURRENCY_FOR_KEY;
        }
    }


    public function fetchCourseKey() {
        $model = $this->getModel();
        return $model->_fetchCourseKey();              
    }


    public function testAction() {
       $this->fetchCourseKey();
       exit;
    }
    
   
} 
