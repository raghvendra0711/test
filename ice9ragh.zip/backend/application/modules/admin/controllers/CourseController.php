<?php

/*
 * Contains the CRUD actions of course table
 *
 */

class Admin_CourseController extends BaseApp_Controller_Crud {

    protected $_model = 'Model_Courses';
    protected $_descriptions = array(
        'list' => 'List of Existing Courses',
        'index' => 'List of Existing Courses',
        'add' => 'Add New Courses',
        'edit' => 'Make the required changes then click on "Save Courses" to update the Courses',
        'view' => 'View Selected Courses',
        'course-content' => 'Add Course Content Inclusions',
        'course-detail' => 'Add Course Content Details Inclusions Templates',
        'course-indetail' => 'Add Course Content In Details Templates',
        'course-moredetail' => 'Add Course Content More Details Templates',
        'get-by-part-name' => 'For searching course by name name',
        'update-course-content' => 'edit Course Content in Detail',
        'update-course-detail' => 'edit Course in Detail',
        'basic' => 'first page for course'
    );

    protected function _getForm($courseId = false, $new = true) {
        $form = new Form_Courses($courseId, $new);
        return $form;
    }

    public function basicAction() {
        $objCourse = new Model_Courses();
        $b2bCartPricing = new Model_B2bCartPricing();
        if ($courseId = $this->getRequest()->getParam('courseId')) {
            if (!$objCourse->getCourseById($courseId)) {
                $this->view->message = "Invalid Course Id";
                $this->view->success = false;
                return;
            }
            $this->view->courseId = $courseId;
            $newSectionTitleVal = '';
            if (!$this->getRequest()->isPost()) {
                $session = new Zend_Session_Namespace('form');
                $session->trainingTypesData = array();
                
                $objCourseFaq = new Model_CourseFaq();
                $overviewInfo = $objCourseFaq->getDataByTypeAndContentId($courseId, "course", BaseApp_Dao_ProductTypes::TYPE_ID_OVERVIEW, BaseApp_Dao_TrainingTypes::TYPE_GENERIC);
                $session->overview = isset($overviewInfo[0])?$overviewInfo[0]:array();
                $trainingRelation = new Model_TrainingRelations();
                $trainingRelationData = $trainingRelation->getByLinkable($courseId, 'course');
                if (isset($trainingRelationData['oslAccessDays'])) {
                    $trainingRelationData['oslAccessDays'] = explode(",", $trainingRelationData['oslAccessDays']);
                }
                if (isset($trainingRelationData['classRoomAccessDays'])) {
                    $trainingRelationData['classRoomAccessDays'] = explode(",", $trainingRelationData['classRoomAccessDays']);
                }
                if (isset($trainingRelationData['iloAccessDays'])) {
                    $trainingRelationData['iloAccessDays'] = explode(",", $trainingRelationData['iloAccessDays']);
                }
                foreach ($trainingRelationData as $fieldName => $fieldValue) {
                    $session->trainingTypesData[$fieldName] = $fieldValue;
                }
                $objConv = new Model_CourseConversion();
                $session = new Zend_Session_Namespace('form');
                $session->conversionIndiaData = array(
                    'industry' => array(
                        'data' => '',
                        'source' => '',
                        'link' => ''
                    ),
                    'job' => array(
                        'data' => '',
                        'source' => '',
                        'link' => ''
                    ),
                    'salary' => array(
                        'data' => '',
                        'source' => '',
                        'link' => ''
                    )
                );
                $conversionData = $objConv->getDataForCourseConversion($courseId);
                if (!empty($conversionData)) {
                    unset($conversionData['course_id']);
                    $conversionData = $conversionData['form_data'];
                    $session->conversionIndiaData = $conversionData;
                }
                /*
                 * productSectionData model
                 */
                $productSecMdl = new Model_ProductSectionData();

                $directorsData = array(
                    'courseDirectors' => $productSecMdl->getByProduct($courseId, BaseApp_Dao_ProductTypes::TYPE_ID_COURSE, 'directors')
                );
                if (isset($directorsData['courseDirectors'][0])) {
                    $newSectionTitleVal = $directorsData['courseDirectors'][0]['sectionTitle'];
                }
                $this->_setCourseDirectors($directorsData);                
            }
            $form = new Form_Courses($courseId);
        } else {
            if (!$this->getRequest()->isPost()) {
                $session = new Zend_Session_Namespace('form');
                $session->trainingTypesData = array();
                $form = $this->_getForm();
            }
        }

        if ($this->getRequest()->isPost()) {
            $request = $this->getRequest()->getPost();
            $this->_setCourseDirectors($request);
            if (!empty($courseId))
                $form = $this->_getForm($courseId, false);
            else
                $form = $this->_getForm(false, true);

            //merge fields and files for validation        
            $postData = array_merge_recursive($request, $_FILES);
        }
        $sectionTitle = 'Course Advisor';
                
        // fetch enterprise list
        $groupsObj = new Model_Groups();
        $this->view->enterpriseList = json_encode($groupsObj->getEnterpriseList());
        
        // fetch existing enterprise data
        $this->view->prePolulateEnterpriseList = '[]';
        $oldAgencies = array();
        $newAgencies = array();
        if($courseId) {
            $groupsObj = new Model_Groups();
            $prePopulateParams = array('entity_type' => ENTITY_TYPE_FOR_ENTERPRISE_COURSE_MAPPING, 'entity_id' => $courseId, 'status' => 1);
            $res = $groupsObj->getPrePolulateEnterpriseList($prePopulateParams);
            
            if(empty($res)) {
                $this->view->prePolulateEnterpriseList = '[]';
            } else {
                $oldAgencies = array_map(function($temp){return $temp['id'];} , $res);
                $this->view->prePolulateEnterpriseList = json_encode($res);
            }
        } 
        
        //Basic Form Validation Here
        if ($this->getRequest()->isPost() && $form->isValid($postData)) {
            $data = $form->getValues();
            $form->removeUneditableElements();
            $isProductSyncRequired = false;
            $sfParams = array();
            $courseCategoryName = '';
            $salsesforceApi = new BaseApp_Communication_SalesforceApi();
            if (isset($data['currentCourseName'])) {
                if (!empty($data['currentCourseName'])) {
                    if (strcmp(strtolower($data['currentCourseName']), strtolower($data['name'])) !== 0) {
                        if (!empty($courseId) && !empty($data['name'])) {
                            $isProductSyncRequired = true;
                            $nonFoucusCourse = !empty($data['hideFromSearch']) ? $data['hideFromSearch'] : 0;
                            $productId = $courseId;
                            $productName = $data['name'];
                            $productType = 'course';
                            $action = 'edit';
                            $product_available_for = !empty($data['course_available_for']) ? $data['course_available_for'] : '';
                            $params = array(
                                'productId' => $productId, 
                                'productName' => $productName, 
                                'productType' => $productType, 
                                'nonFocusCourse' => $nonFoucusCourse, 
                                'product_available_for'=>$product_available_for,
                                'action' => $action
                            );
                            $sfParams[] = $params;
                        }
                    }
                }
                unset($data['currentCourseName']);
            }
            $oldPrimaryElearningId = !empty($data['old_primary_eLearning_id']) ? $data['old_primary_eLearning_id'] : "";
            if (!empty($data) && !empty($courseId)) {
                $elearningId = !empty($data['primary_eLearning_id']) ? $data['primary_eLearning_id'] : "";
                if ($elearningId != $oldPrimaryElearningId) {
                    $elearningUpdate = $b2bCartPricing->updatePrimaryElearningId($courseId, $elearningId);
                }
            }
            unset($data['old_primary_eLearning_id']);
            if (isset($data['categoryLabelName'])) {
                if (!empty($data['categoryLabelName'])) {
                    $courseCategoryName = trim($data['categoryLabelName']);
                    $courseCategoryNameArray = explode(' - ', $courseCategoryName);
                    $productCategoryName = isset($courseCategoryNameArray[1]) ? $courseCategoryNameArray[1] : '';
                }
                unset($data['categoryLabelName']);
            }
            if (isset($data['oldCategoryLabelID'])) {
                if ($data['oldCategoryLabelID'] !== $data['primary_label_id']) {
                    $isProductSyncRequired = true;
                    $productId = $courseId;
                    $productType = 'course';
                    $productCategoryId = (int) $data['primary_label_id'];
                    $courseCategoryNameArray = explode(' - ', $courseCategoryName);
                    $productCategoryName = isset($courseCategoryNameArray[1]) ? $courseCategoryNameArray[1] : '';
                    $action = 'mapping';
                    $params = array(
                        'productId' => $productId, 
                        'productCategoryId' => $productCategoryId, 
                        'productCategoryName' => $productCategoryName, 
                        'productType' => $productType, 
                        'action' => $action
                    );
                    $sfParams[] = $params;
                }
                unset($data['oldCategoryLabelID']);
            }
            if (isset($data['hideFromSearch'],$data['course_available_for'])) {
                if ((isset($data['oldhideFromSearch']) && $data['oldhideFromSearch'] !== $data['hideFromSearch']) 
                    || (isset($data['oldCourseAvailableFor']) && $data['oldCourseAvailableFor'] !== $data['course_available_for']) 
                ) {
                    $isProductSyncRequired = true;
                    $nonFoucusCourse = !empty($data['hideFromSearch']) ? $data['hideFromSearch'] : 0;
                    $productId = $courseId;
                    $productName = $data['name'];
                    $productType = 'course';
                    $product_available_for = !empty($data['course_available_for']) ? $data['course_available_for'] : '';
                    $action = 'edit';
                    $params = array(
                        'productId' => $productId, 
                        'productName' => $productName, 
                        'productType' => $productType, 
                        'nonFocusCourse' => $nonFoucusCourse, 
                        'product_available_for' => $product_available_for,
                        'action' => $action
                    );
                    $sfParams[] = $params;
                }
                unset($data['oldhideFromSearch']);
            }
            if (isset($data['freeCourses']) && $data['freeCourses']) {
                $data['freeCourses'] = implode(",", $data['freeCourses']);
            }
            $trainingData = $data['trainingTypes'];
            if (!$this->_validTrainingData($trainingData, $message)) {
                $this->view->message = $message;
                $this->view->success = false;
                $this->view->form = $form;
                return;
            }
            if ($courseId && $this->_isWorkShopExists($courseId, $trainingData, $message)) {
                $this->view->message = $message;
                $this->view->success = false;
                $this->view->form = $form;
                return;
            }
            
            if(isset($data['enterprise_list'])) {
                $enterpriseCourseMappingArr = explode(",",$data['enterprise_list']);
                // PRD($data['enterprise_list']);
                // PRD(count($enterpriseCourseMappingArr));
                if($data['course_available_for'] == 'private_b2b' && $data['enterprise_list'] == '') {
                    $this->view->message = "Please select at least one Enterprise for Private B2B";
                    $this->view->success = false;
                    $form->getElement('enterprise_list')->setErrors(array("Please select at least one Enterprise for Private B2B"));
                    $this->view->form = $form;
                    return false;
                }
                $newAgencies = $enterpriseCourseMappingArr;
                unset($data['enterprise_list']);
            }

            $objConversion = new Model_CourseConversion();
            $conversionForIndia = !empty($data['conversionForIndia']) ? $data['conversionForIndia'] : array();
            foreach ($conversionForIndia as $key => $value) {
                if (empty($value['data']) || empty($value['source'])) {
                    if (!empty($data['for_india'])) {
                        $this->view->message = "Please fill all the mandatory fields for each section For India";
                        $this->view->success = false;
                        $form->getElement('for_india')->setErrors(array("Please fill all the mandatory fields for each section"));
                        $this->view->form = $form;
                        return false;
                    }
                } else {
                    if (empty($data['for_india'])) {
                        $this->view->message = "There are errors on the page. Please Check";
                        $this->view->success = false;
                        $form->getElement('for_india')->setErrors(array("Please fill all the mandatory fields for each section"));
                        $this->view->form = $form;
                        return false;
                    }
                }
            }

            // check for max 2 accreditors
            $accreditorsArr = array();
            if(!empty($data['accreditor_id_sorted_list'])) {
                $accreditorsArr = explode(",", $data['accreditor_id_sorted_list']);
            }
            if (!empty($accreditorsArr) && count($accreditorsArr) > 2) {
                $this->view->message = "Max 2 accreditors allowed";
                $this->view->success = false;
                $this->view->form = $form;
                return false;
            }
            $newAccreditorsList = array();
            if(!empty($data['accreditor_id_sorted_list_new'])) {
                $newAccreditorsList = explode(",", $data['accreditor_id_sorted_list_new']);
            }
            $data['accreditor_id'] = $accreditorsArr;
            $data['accreditor_id_new'] = $newAccreditorsList;
            unset($data['accreditor_id_sorted_list']);
            unset($data['accreditor_id_sorted_list_new']);
            $toolList = array();
            if(!empty($data['courseToolsFeatureSortedList'])) {
                $toolList = explode(",", $data['courseToolsFeatureSortedList']);
            }
            unset($data['courseToolsFeature']);
            unset($data['courseToolsFeatureSortedList']);

            $conversionForUs = !empty($data['conversionForUs']) ? $data['conversionForUs'] : array();
            foreach ($conversionForUs as $key => $value) {
                if (empty($value['data']) || empty($value['source'])) {
                    if (!empty($data['for_us'])) {
                        $this->view->message = "Please fill all the mandatory fields for each section For Us";
                        $form->getElement('for_us')->setErrors(array("Please check to show data"));
                        $this->view->success = false;
                        $this->view->form = $form;
                        return false;
                    }
                } else {
                    if (empty($data['for_us'])) {
                        $this->view->message = "There are errors on the page. Please Check";
                        $this->view->success = false;
                        $form->getElement('for_us')->setErrors(array("Please check to show data"));
                        $this->view->form = $form;
                        return false;
                    }
                }
            }
            $conversionData = array('for_india' => !empty($data['for_india']) ? $data['for_india'] : "", 'for_us' => !empty($data['for_us']) ? $data['for_us'] :"", 'conversionForIndia' => !empty($data['conversionForIndia']) ? $data['conversionForIndia'] : "", 'conversionForUs' => !empty($data['conversionForUs']) ? $data['conversionForUs'] : "");
            unset($data['for_india']);
            unset($data['for_us']);
            unset($data['conversionForIndia']);
            unset($data['conversionForUs']);

            if ($trainingData['osl' . BaseApp_Dao_TrainingTypes::TYPE_ELEARNING] && isset($trainingData['oslAccessDays'])) {
                $trainingData['oslAccessDays'] = implode(",", $trainingData['oslAccessDays']);
            }
            if ($trainingData['ilt' . BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM] && isset($trainingData['classRoomAccessDays'])) {
                $trainingData['classRoomAccessDays'] = implode(",", $trainingData['classRoomAccessDays']);
            }
            if ($trainingData['ilt' . BaseApp_Dao_TrainingTypes::TYPE_LVC] && isset($trainingData['iloAccessDays'])) {
                $trainingData['iloAccessDays'] = implode(",", $trainingData['iloAccessDays']);
            }
            if (!$trainingData['osl' . BaseApp_Dao_TrainingTypes::TYPE_ELEARNING]) {
                unset($trainingData['osl' . BaseApp_Dao_TrainingTypes::TYPE_ELEARNING]);
                unset($trainingData['oslAccessDays']);
            }
            if (!$trainingData['ilt' . BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM]) {
                unset($trainingData['ilt' . BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM]);
                unset($trainingData['classRoomAccessDays']);
            }
            if (!$trainingData['ilt' . BaseApp_Dao_TrainingTypes::TYPE_LVC]) {
                unset($trainingData['ilt' . BaseApp_Dao_TrainingTypes::TYPE_LVC]);
                unset($trainingData['iloAccessDays']);
            }
            unset($data['trainingTypes']);

            //Add Online class room pass training type by default.
            $config = Zend_Registry::get('config');
            $trainingData['ilt' . BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS] = 1;
            $trainingData['onlineClassRoomAccessDays'] = $config->get('ONLINE_CLASSROOM_PASS_ACCESS_DAYS')->toArray();
            $daysObj = new Model_AccessDays();
            $trainingData['onlineClassRoomAccessDays'] = $daysObj->getAccessDayIdByDays($trainingData['onlineClassRoomAccessDays'], 'ilt');
            $trainingData['onlineClassRoomAccessDays'] = array_keys($trainingData['onlineClassRoomAccessDays']);
            $trainingData['onlineClassRoomAccessDays'] = implode(",", $trainingData['onlineClassRoomAccessDays']);            

            $searchTags = $data['tags'];
            unset($data['tags']);
            $data['label_id'] = implode(",", $data['label_id']);
            $imageData = array(
                1 => array(
                    'name' => 'image_home_page',
                    'imagePath' => $data['image_home_page'],
                    'linkable_id' => $courseId,
                    'linkable_type' => 'course'
                ),
            );
            //process certificate image  
            if (!empty($_FILES['certificate_image'])) {
                if(isset($_FILES['certificate_image']['name']) && $_FILES['certificate_image']['name'] != '') {
                    $fileName = $_FILES['certificate_image']['name'];
                    $absFilePath = sys_get_temp_dir().DIRECTORY_SEPARATOR.$fileName;
                    $s3path = AWS_S3_IMAGES_PATH.'/certificates';
                    $certificateImageUrl = BaseApp_Utility_ImageProcessing::transformAndUploadToS3($absFilePath, $fileName, $s3path); 
                    if (isset($certificateImageUrl)){
                        array_push($imageData, array(
                            'name' => 'image_certificate',
                            'imagePath' => $certificateImageUrl,
                            'linkable_id' => $courseId,
                            'linkable_type' => 'course',
                            'imageDescription' => $data['certificate_alt_text']
                        ));
                    }    
                }else{
                    if(!empty($data['certificate_image_id'])){
                        array_push($imageData, array(
                            'name' => 'image_certificate',
                            'imagePath' => $data['certificate_image_old'],
                            'linkable_id' => $courseId,
                            'linkable_type' => 'course',
                            'imageDescription' => $data['certificate_alt_text'],
                            'image_id' => $data['certificate_image_id']
                        ));
                    }

                }     
            }
            $directorsSetData = $this->_handleDataAfterSubmit($request);
            $accreditorTitle = $data['accreditor_title'];
            $oldCourseAvailableFor = $data['oldCourseAvailableFor'];

            // unset($data['image_course_detail_page']);
            $faqId = $data['course_faq_id'];
            $overview = $data['overview'];
            unset($data['image_home_page']);
            // unset($data['image_list_page']);
            // unset($data['image_mobile']);
            unset($data['certificate_image_id']);
            unset($data['certificate_image_old']);
            unset($data['certificate_alt_text']);
            unset($data['certificate_image']);
            unset($data['certificate_value']);
            unset($data['courseDirectors']);
            unset($data['course_advisor']);
            unset($data['course_advisor_temp']);
            unset($data['course_advisor_top']);
            unset($data['courseToolsFeature']);
            unset($data['course_tool_err']);
            unset($data['accreditor_title']);
            unset($data['overview']);
            unset($data['course_faq_id']);
            unset($data['videoDescription']);
            unset($data['dateCreated']);
            unset($data['oldCourseAvailableFor']);
            $result = false;

            if(empty($data['money_back_guarantee']) || !isset($data['money_back_guarantee'])){
                $data['money_back_guarantee_text'] = '';
            } else{
                $data['money_back_guarantee_text'] = strip_tags($data['money_back_guarantee_text'],'<a><i><b><span><strong><br>');
            }

            if(isset($trainingData['ilt1']) && $trainingData['ilt1'] == 1){
                $data['is_classroom_page'] = true;
            }else{
                $data['is_classroom_page'] = false;
            }

            if (!empty($data['videoLink'])) {
                $vData = $form->getVideoData();
                if(!empty($vData) && is_array($vData)){
                $data['videoDescription'] = isset($vData['shortDescription']) ? $vData['shortDescription'] : NULL;
                $data['dateCreated'] = isset($vData['dateCreated']) ? $vData['dateCreated'] : NULL;
                $data['duration'] = isset($vData['duration']) ? $vData['duration'] : NULL;
                $data['displayName'] = isset($vData['displayName']) ? $vData['displayName'] : $data['name'];
                }
                $data['videoThumbnail'] = !empty($data['videoThumbnail']) ? $data['videoThumbnail'] : "";
            }

            $availableForData = array('old' => array(), 'new' => array());
            if ($courseId) {

                $availableForData['old']['availableFor'] = $oldCourseAvailableFor;
                $availableForData['old']['agencies'] = $oldAgencies;
                $availableForData['new']['availableFor'] = $data['course_available_for'];
                $availableForData['new']['agencies'] = empty($newAgencies)?array():$newAgencies;

                $action = 'Course Modified ' . $data['name'];
                $data['course_id'] = $courseId;
  
                $result = $objCourse->updateCourse($courseId, $data, $imageData);
                if (($isProductSyncRequired) && is_array($sfParams) && !empty($sfParams) && ctype_digit(strval($result)) && $courseId == $result) {
                    foreach ($sfParams as $param):
                        $response = $salsesforceApi->SfdcPoductSync($param);
                    endforeach;
                }
            } else if ($courseId = $objCourse->createCourse($data, $imageData)) {
                
                $availableForData['old']['availableFor'] = '';
                $availableForData['old']['agencies'] = array();
                $availableForData['new']['availableFor'] = $data['course_available_for'];
                $availableForData['new']['agencies'] = empty($newAgencies)?array():$newAgencies;

                $sfParams = array();
                $action = 'New Course Added ' . $data['name'];
                $result = true;
                if (ctype_digit(strval($courseId)) && !empty($data['name'])) {
                    $nonFoucusCourse = !empty($data['hideFromSearch']) ? $data['hideFromSearch'] : 0;
                    $product_available_for = !empty($data['course_available_for']) ? $data['course_available_for'] : '';
                    $sfParams['productId'] = (int) $courseId;
                    $sfParams['productName'] = $data['name'];
                    $sfParams['productType'] = 'course';
                    $sfParams['productCategoryId'] = !empty($data['primary_label_id']) ? (int) $data['primary_label_id'] : 0;
                    $sfParams['productCategoryName'] = !empty($productCategoryName) ? $productCategoryName : '';
                    $sfParams['product_available_for']  = $product_available_for;
                    $sfParams['nonFocusCourse'] = $nonFoucusCourse;
                    $sfParams['action'] = 'add';
                    $response = $salsesforceApi->SfdcPoductSync($sfParams);
                }
            }

            try {
                // b2b update based on course available for
                $b2bHelper = new Helper_B2bHelper();
                $b2bHelper->processAvaliableForChange(BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE, $courseId, $availableForData);
            } catch (Exception $e) {
                file_put_contents(APPLICATION_PATH . '/../error.log', "\n[" .date('Y-m-d H:i:s'). '] ERROR: course processAvaliableForChange failed ' . $e->getMessage(), FILE_APPEND);
                if (APPLICATION_ENV != 'production') throw $e;
            }
                
            //Save Training data;
            $this->_extractandSaveCourseSections($courseId, $trainingData);
   
            $objCourseFaq = new Model_CourseFaq();
            $courseOverview = array();
            $courseOverviewData = array();
            $courseOverview['question'] = $overview;
            $courseOverview['all_country'] = 1;
            $courseOverview['linkable_id'] = $courseId;
            $courseOverview['linkable_type'] = "course";
            $courseOverview['course_faq_id'] = $faqId;
            $courseOverviewData[] = $courseOverview;
            if (!empty($courseOverview)) {
                $objCourseFaq->addCourseContent($courseOverviewData, BaseApp_Dao_ProductTypes::TYPE_ID_OVERVIEW, $courseId, BaseApp_Dao_TrainingTypes::TYPE_GENERIC, null, true, "course");
            }

            $tags = new Model_Tags();
            if ($result && !$tags->saveTags($courseId, 'course', $searchTags)) {
                $result = false;
            }

            $trainingRelation = new Model_TrainingRelations();
            if ($result && !$trainingRelation->createRelation($courseId, 'course', $trainingData)) {

                $result = false;
            }                                               

            $objSectionMapping = new Model_SectionMapping();
            $sectionMappingArr = array();
            
            $this->_modifyTools($objSectionMapping, $courseId, $toolList);

            if (isset($directorsSetData['course_advisor']) && !empty($directorsSetData['course_advisor'])) {
                $sectionMappingArr = $directorsSetData['course_advisor'];
                $objSectionMapping->saveProductSectionData($courseId, BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE, $sectionMappingArr, false, Model_SectionMapping::HAS_ORDER_TRUE, BaseApp_Dao_ProductSectionData::SECTION_TYPE_COURSE_DIRECTORS);                
            }else{
                $objSectionMapping->removeProductMappingBySection($courseId, BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE, BaseApp_Dao_ProductSectionData::SECTION_TYPE_COURSE_DIRECTORS);
            }

            // Save accreditor title
            $param = array('sectionTitle' => $accreditorTitle);
            $this->_saveOrUpdateCoruseField($courseId, BaseApp_Dao_ProductSectionData::SECTION_TYPE_ACCREDITOR_TITLE, $param);
            unset($accreditorTitle);
            $conversionData = $this->_buildInsertData($conversionData, $courseId);
            $checUnique = current($objConversion->fetchAll(array('linkable_id =?' => $courseId, 'linkable_type =?' => 'course')));
            if (!empty($checUnique)) {
                $conversionResult = $objConversion->editCourseConversion($conversionData, $courseId);
                if (!$conversionResult)
                    $result = false;
            }else {
                if (!empty($conversionData)) {
                    $conversionResult = $objConversion->addCourseConversion($conversionData);
                    if (!$conversionResult)
                        $result = false;
                }
            } 

            if (
                isset($postData['primary_eLearning_id'])
                    && isset($postData['old_eLearning_id'])
                        && $postData['primary_eLearning_id'] != $postData['old_eLearning_id']
            ) {
                $courseElearningHistoryModel = new Model_CourseElearningHistory();
                $courseElearningHistoryModel->setFromArray([
                    'course_id' => $courseId,
                    'elearning_id' => $postData['primary_eLearning_id'],
                    'old_elearning_id' => $postData['old_eLearning_id'],
                    'created_at' => time(),
                    'status' => 1,
                ])->save();
                $courseElearningHistoryModel->clean();
            }
            
            // update enterprise course mapping data in cloud6 api
            if(isset($enterpriseCourseMappingArr)) {
                $enterpriseCourseData = array(
                    'entity_type' => 1, // course
                    'entity_id' =>  $courseId,
                    'group_ids' => $enterpriseCourseMappingArr,
                );            
                $groupsObj = new Model_Groups();
                $resp = $groupsObj->setEnterpriseList($enterpriseCourseData);
            }
            
            if (!$result) {
                $this->view->message = "An error has occured while saving";
                $this->view->success = false;
            } else {
                $cdnPurgeData = $this->getModel()->buildCdnPurgeData($courseId, $data['name'] . $action);
                $objCdn = new Model_CdnPurgeLog();
                if (!empty($cdnPurgeData))
                    $objCdn->InsertCdnPurgeLog($cdnPurgeData);
                $this->view->message = "Saved SuccessFully";
                $this->view->success = false;
                $this->_redirect("/admin/course/course-indetail/courseId/$courseId");
            }
        }
        
        $this->view->success = true;
        $this->view->form = $form;
    }
    
    private function _modifyTools($objSectionMapping, $courseId, $toolList) {
        if (!empty($toolList)) {
            $sectionMappingArr = $toolList;
            $objSectionMapping->saveProductSectionData($courseId, BaseApp_Dao_ProductSectionData::LINKABLE_TYPE_COURSE, $sectionMappingArr, null, true, BaseApp_Dao_ProductSectionData::SECTION_TYPE_COURSE_TOOLS);
        } else {
            $objSectionMapping->removeProductMappingBySection($courseId, BaseApp_Dao_ProductSectionData::LINKABLE_TYPE_COURSE, BaseApp_Dao_ProductSectionData::SECTION_TYPE_COURSE_TOOLS);
        }
    }

    /**
     * Get training types from $trainingData 
     * Get apllicable sections from section templates and training types
     * save sections for each training type in course sections
     */
    private function _extractandSaveCourseSections($courseId, $trainingData) {
        $objCourse = new Model_Courses();        
        //Get the traing type array
        $courseTrainingTypes = $this->_getCourseTrainerTypes($trainingData);   
        //get the sections from templates        
        $courseSectionData = $this->_getTrainingSections($courseTrainingTypes);
        $objCourse->saveCourseSections($courseSectionData, $courseId);        
    }

    /**
     * Extract (string operation) the training type from course training data and 
     * compare if the type exists.
     * @return $courseTrainingTypes array all legitimate training types from course form data
     */
    private function _getCourseTrainerTypes($trainingData) {
        $trainingModel = new Model_TrainingTypes();
        $trainingTypes = $trainingModel->getInclusionTrainingTypes();
        $genericTrainingType = '0';                
        $courseTrainingTypes = array();
        //add generic at first
        array_push($courseTrainingTypes, $genericTrainingType);
        foreach($trainingData as $typeName => $value){
            if (!empty($value)) {
                //extracting the type from data, the key has a numeric at the end of it
                If(is_numeric($trainingType = substr($typeName, -1))){
                    if(array_key_exists($trainingType, $trainingTypes)) {
                        array_push($courseTrainingTypes, $trainingType);
                    }
                }   
            }
        }        
        return $courseTrainingTypes;
    }

    /**
     * For each traing type get the correcsponding sections from section template table
     * @return $returnData Array of section data applicable to the course
     */
    private function _getTrainingSections($courseTrainingTypes){
        $sectionTemplate = new Model_SectionTemplates();
        $returnData = array();
        foreach($courseTrainingTypes as $trainingType){
            if (!empty($trainingType) || $trainingType == '0') {
                $sectionData = $sectionTemplate->getTemplatesForTrainingType($trainingType);   
                $returnData[$trainingType] = $sectionData;
            }
        }
        return $returnData;
    }
        
    private function _saveOrUpdateCoruseField($coruseId, $sectionType, $data) {
        $objProductSectionData = new Model_ProductSectionData();
        $existing = $objProductSectionData->getDataByType($coruseId, BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE, $sectionType, true);
        if (empty($existing) || !is_array($existing) && empty(current($existing)['section_id'])) {
            $param = $data;
            $param['course_id_arr'] = array($coruseId);
            $param['sectionType'] = $sectionType;
            $objProductSectionData->saveProductSectionData($param);
        } else {
            $id = current($existing)['section_id'];
            $param = $data;
            $param['course_id_arr'] = array($coruseId);
            $objProductSectionData->updateProductSectionData($id, $param);
        }
    }

    private function _handleDataAfterSubmit(&$request) {
        $returnData = array();
        $returnData['course_advisor'] = array();
        if (!empty($request['course_advisor'])) {
            $returnData['course_advisor'] = explode(",", $request['course_advisor']);
        }
        unset($request['course_advisor']);
        unset($request['course_advisor_top']);
        return $returnData;
    }

    private function _setCourseDirectors(&$request) {
        $session = new Zend_Session_Namespace('form');
        if (isset($request['courseDirectors']) && count($request['courseDirectors'])) {
            $request['courseDirectors'] = $this->_updateFirstElement($request['courseDirectors']);
            $session->courseDirectors = array_keys($request['courseDirectors']);
            array_unshift($session->courseDirectors, '__template__');
            $session->courseDirectorsData = $request['courseDirectors'];
        } else {
            $session->courseDirectors = array('__template__', 'new');
            $session->courseDirectorsData = array();
        }
    }

    private function _validTrainingData($trainingData, &$message) {
        if (!$trainingData['osl2'] && !$trainingData['ilt1'] && !$trainingData['ilt3']) {
            $message = "Please select atleast one training type";
            return false;
        }
        if ($trainingData['osl2'] && !$trainingData['oslAccessDays']) {
            $message = "Please select acces days for Online Self Learning";
            return false;
        }
        if ($trainingData['ilt1'] && !$trainingData['classRoomAccessDays']) {
            $message = "Please select acces days for Classroom";
            return false;
        }
        if ($trainingData['ilt3'] && !$trainingData['iloAccessDays']) {
            $message = "Please select acces days for LVC";
            return false;
        }
        return true;
    }

    private function _isWorkShopExists($courseId, $trainingData, &$message) {
        $message = "Can not uncheck access days as there are some workshops exists";
        $trainingModel = new Model_TrainingTypes();
        $trainingTypes = $trainingModel->loadAll();

        $accessDayModel = new Model_AccessDays();
        $accessDaysAll = $accessDayModel->getAccessDaysById();

        $modelWorkshop = new Model_Workshop();
        $exists = false;
        foreach ($modelWorkshop->getByCourse($courseId) as $workshopData) {
            $typeKey = sprintf("%s%d", $trainingTypes[$workshopData['training_id']]['type'], $workshopData['training_id']);
            if (!$trainingData[$typeKey]) {
                $message = "Workshop exists for {$trainingTypes[$workshopData['training_id']]['name']}";
                $exists = true;
            }
            switch ($workshopData['training_id']) {
                case 1:
                    if (!$trainingData['classRoomAccessDays'] || !in_array($workshopData['access_day_id'], $trainingData['classRoomAccessDays'])) {
                        $message = "Workshop exists for {$trainingTypes[$workshopData['training_id']]['name']} and {$accessDaysAll[$workshopData['access_day_id']]} accessdays";
                        $exists = true;
                    }
                    break;
                case 2:
                    if (!$trainingData['oslAccessDays'] || !in_array($workshopData['access_day_id'], $trainingData['oslAccessDays'])) {
                        $message = "Workshop exists for {$trainingTypes[$workshopData['training_id']]['name']} and {$accessDaysAll[$workshopData['access_day_id']]} accessdays";
                        $exists = true;
                    }
                    break;
                case 3:
                    if (!$trainingData['iloAccessDays'] || !in_array($workshopData['access_day_id'], $trainingData['iloAccessDays'])) {
                        $message = "Workshop exists for {$trainingTypes[$workshopData['training_id']]['name']} and  {$accessDaysAll[$workshopData['access_day_id']]} accessdays";
                        $exists = true;
                    }
                    break;
            }
        }
        return $exists;
    }


    public function courseDetailAction() {
        $objCourseSections = new Model_CourseSections();
        $courseId = $this->getRequest()->getParam('courseId');
        if (empty($courseId)) {
            $this->view->message = "An error has occured while saving";
            $this->view->success = true;
            return;
        }
        $sectionTemplatesData = $objCourseSections->getCourseSection($courseId);
        $this->view->sectionTemplates = $sectionTemplatesData;        
    }

// end of function courseDetailAction

    public function courseIndetailAction() {
        $courseSectionId = $this->getRequest()->getParam('param');
        $courseId = $this->getRequest()->getParam('courseId');
        $countryId = $this->getRequest()->getParam('countryId');
        $clusterId = $this->getRequest()->getParam('clusterId');
        $pageNo = $this->getRequest()->getParam('pageNo');
        $limitPerPage =  BaseApp_Dao_CourseFaq::DEFAULT_COURSE_FAQ_PAGE_LIMIT;
        if (empty($pageNo)) {
            $pageNo = 1;
        }
        $calc = $limitPerPage * $pageNo;
        $offset = $calc - $limitPerPage;
        $this->view->selectedCountryId = $countryId;
        $this->view->selectedClusterId = $clusterId;

        $this->view->curPageNo=$pageNo;
        if (empty($courseId)) {
            $this->view->message = "Course id not given";
            $this->view->success = false;
            return;
        }
        $objCourse = new Model_Courses();
        if (!$courseData = $objCourse->getCourseById($courseId)) {
            $this->view->message = "Invalid Course Id";
            $this->view->success = false;
            return;
        }
        if ($courseData['is_dummy']) {
            $this->view->message = "Its a dummy course";
            $this->view->success = false;
            return;
        }

        if ($courseData['is_free']) {
            $this->view->message = "Its a free course";
            $this->view->success = false;
            return;
        }

        $objCourseSections = new Model_CourseSections();
        $courseSectionData = array();
        if ($courseSectionId) {
            $courseSectionData = $objCourseSections->getById($courseSectionId);
            $this->view->sectionIdCurrent = $courseSectionId;
        }
        $trainingRelation = new Model_TrainingRelations();
        $trainingInclude = $trainingRelation->getCourseTrainingIds($courseId, 'course');
        $sectionTemplatesData = $objCourseSections->getCourseSectionToShow($courseId, $trainingInclude);
        $objCourseFaq = new Model_CourseFaq();
        $objCourselinkBlock = new Model_CourseLinkBlock();
        $objCountry = new Model_Country();
        $countries = $objCountry->getListDisplay();
        $this->view->countryList = $countries;
        $objCluster = new Model_Clusters();
        $cluster = $objCluster->fetchForSelect();
        $this->view->cluster = $cluster;
        $isEdit = false;
        $isNewEntry = false;
        $examPassContent = $objCourseFaq->getDataByTypeAndContentId($courseId, "course", BaseApp_Dao_CourseFaq::COURSE_RESOURCE_EXAM_PASS_NEW_ID, 0, 'all', $countryId, 0, 0, $offset, $limitPerPage);
        $this->view->examPassContent = !empty($examPassContent) ? $examPassContent : array();
        $this->view->training_id = !empty($courseSectionData['training_id']) ? $courseSectionData['training_id']:0;
        if ($courseSectionData) {
            $courseId = $this->getRequest()->getParam('courseId');
            $contentId = $this->getRequest()->getParam('contentId');
            $contentType = '';
            $showAnswerField = true;   
            $sectionTemplate = new Model_SectionTemplates();
            $relatedCourseSectionId = $sectionTemplate->getSectionId(BaseApp_Dao_CourseFaq::COURSE_RESOURCE_RELATED_COURSE);
            $this->view->relatedCourseSectionId = $relatedCourseSectionId;
            $benefitSectionType = $sectionTemplate->getSectionId(BaseApp_Dao_CourseFaq::COURSE_RESOURCE_BENEFITS_NAME);
            $examPassSectionType = $sectionTemplate->getSectionId(BaseApp_Dao_CourseFaq::COURSE_RESOURCE_EXAM_PASS);
            switch ($courseSectionData['section_id']) {
                case 1:
                    $contentType = BaseApp_Dao_CourseFaq::COURSE_RESOURCE_KEY_FEATURE;
                    $showAnswerField = false;
                    break;
                case 2:
                    $contentType = BaseApp_Dao_CourseFaq::COURSE_RESOURCE_ABOUT_COURSE;
                    break;
                case 3:
                    $contentType = BaseApp_Dao_CourseFaq::COURSE_RESOURCE_EXAM_AND_CERTIFICATION;
                    break;
                case 4:
                    $contentType = BaseApp_Dao_CourseFaq::COURSE_RESOURCE_FAQ;
                    break;                    
                case $benefitSectionType:
                    $contentType = BaseApp_Dao_CourseFaq::COURSE_RESOURCE_BENEFITS;
                    break;
                case $relatedCourseSectionId:
                    $contentType = $relatedCourseSectionId;
                    break;
                case $examPassSectionType:
                    $contentType = BaseApp_Dao_CourseFaq::COURSE_RESOURCE_EXAM_PASS_NEW_ID;
                    break;
                default:
                    break;
            }

                    $addMore = $this->getRequest()->getParam('addMore');
                    if (empty($courseId)) {
                        $this->view->message = "An error has occured while saving";
                        $this->view->success = true;
                        return;
                    }
                    if (!empty($contentId)) {
                        $isEdit = true;
                        $isNewEntry = false;
                    }
                    if (!empty($addMore)) {
                        $isNewEntry = true;
                        $isEdit = false;
                    }
                    $this->view->aboutCourseData = array();
                    $errorMessage = "An error occured";
                    $this->view->showCourseDataListing = false;
                    if ($this->getRequest()->isPost()){
                        $request = $this->getRequest()->getPost();
                        $this->_setContentCourse($request);
                        switch ($contentType) {
                            case $relatedCourseSectionId:
                                $form = new Form_CourseLinkBlock($courseId, $countryId, $clusterId);
                                break;
                            case BaseApp_Dao_CourseFaq::COURSE_RESOURCE_BENEFITS:
                                $form = new Form_CourseContentBenefits();
                                break;
                            case BaseApp_Dao_CourseFaq::COURSE_RESOURCE_EXAM_PASS_NEW_ID:
                                $form = new Form_ExamPassGuarantee('');
                                break;
                            default:
                                $form = new Form_CourseContentQuestions($courseSectionData['training_id'], $showAnswerField);
                                break;
                        }
                        $data = $form->getValues();              
                        if ($form->isValid($request, $errorMessage,$showAnswerField)) {
                            $data = $form->getValues();
                            if (isset($data['contentCourse'])) {
                                unset($data['contentCourse']['__template__']);
                                $data['contentCourse'] = $data['contentCourse'];
                                $data['contentCourse']['linkable_id'] = $courseId;
                                $data['contentCourse']['linkable_type'] = "course";
                            }
                            $result = false;
                            $errorMessage = "An error has occured while saving";
                            if( !empty($data['contentCourse']['new']['cluster_id']) && !empty($data['contentCourse']['new']['country_id']) ) {
                                $countryObj = new Model_Country();
                                $data['contentCourse']['new']['country_id'] =  $countryObj->removeClusterCountries($data['contentCourse']['new']['cluster_id'], $data['contentCourse']['new']['country_id']);
                            }
                            
                            /*
                            if ($contentType == $benefitSectionId){
                                //before saving faq check if data exists for country and show error if it does;
                                $benefitCountryId = !empty($data['contentCourse']['new']['country_id']) ? $data['contentCourse']['new']['country_id']: 0;
                                $countryBenefits = $objCourseFaq->getDataByTypeAndContentId($courseId, "course", $contentType, $courseSectionData['training_id'], $clusterId, $countryId, 0, $contentId, $offset, 1);
                                if(!empty($countryBenefits)){
                                    $result = false;
                                    $errorMessage = "Benefits already exists for this country . Cannot create another.";
                                } else {
                                    if ($faqId = $objCourseFaq->addCourseContent($data['contentCourse'], $contentType, $courseId, $courseSectionData['training_id'],null,$isEdit,"course")) {
                                        //save job designations
                                        if (isset($data['contentCourse']['new']['jobdesignation'])) {
                                            $result = $this->_saveCourseJobDesignations($data['contentCourse']['new']['jobdesignation'], $faqId);
                                        }
                                    }
                                }
                            } else {
                                if ($objCourseFaq->addCourseContent($data['contentCourse'], $contentType, $courseId, $courseSectionData['training_id'],null,$isEdit,"course")) {
                                    $result = true;
                                }
                            }
                            */             
                            //All the types which should have only one enty per country
                            $onlyOnePerCountryTypes = array(BaseApp_Dao_CourseFaq::COURSE_RESOURCE_BENEFITS);

                            if (in_array($contentType, $onlyOnePerCountryTypes)){
                                //before saving faq check if data exists for country and show error if it does;                               
                                if($this->_contentExistsForCountry($courseId, $contentType, $courseSectionData['training_id'], $clusterId,  $data['contentCourse']['new']['country_id']) && empty($contentId)){
                                    $result = false;
                                    $errorMessage = "Content already exists for this country . Cannot create another one.";
                                } else {
                                    $courseFaqId = $data['contentCourse']['new']['course_faq_id'];
                                    $countryId = $data['contentCourse']['new']['country_id'];
                                    if ($faqId = $objCourseFaq->addCourseContent($data['contentCourse'], $contentType, $courseId, $courseSectionData['training_id'],null,$isEdit,"course")) {
                                        //save job designations
                                        if (($contentType == BaseApp_Dao_CourseFaq::COURSE_RESOURCE_BENEFITS) && !empty($data['contentCourse']['new']['jobdesignation'])) {
                                            $result = $this->_saveCourseJobDesignations($data['contentCourse']['new']['jobdesignation'], $faqId);
                                        }
                                        
                                        // Benefit Data Newly added
                                        if ( empty($courseFaqId) && $contentType == BaseApp_Dao_CourseFaq::COURSE_RESOURCE_BENEFITS){
                                            $objCourseFaq->deleteCourseCitiesFaq($courseId,$contentType,$countryId);
                                        }
                                    }
                                }
                            } else {
                                switch($contentType){
                                    case $relatedCourseSectionId:
                                        if( empty($countryId) && empty($clusterId) ){
                                            if ($objCourselinkBlock->editCourseContentFromParams($data['contentCourse'], $contentType, $courseId,false,"course")) {
                                                $result = true;
                                            }
                                        }else{
                                            if ($objCourselinkBlock->editCourseContentFromParams($data['contentCourse'], $contentType, $courseId,false,"course",$countryId,$clusterId)) {
                                                $result = true;
                                            }    
                                        }
                                    break;
                                    default:
                                     //prd($isEdit,$isNewEntry);
                                        if ($isEdit) {
                                            if ($objCourseFaq->addCourseContent($data['contentCourse'], $contentType, $courseId, $courseSectionData['training_id'],null,true,"course")) {
                                                $result = true;
                                            }
                                        } elseif ($isNewEntry) {
                                            if ($objCourseFaq->addCourseContent($data['contentCourse'], $contentType, $courseId, $courseSectionData['training_id'],null,false,"course")) {
                                                $result = true;
                                            }
                                        }
                                    break;
                                }
                            }

                            if (!$result) {
                                $this->view->message = $errorMessage;
                                $this->view->success = false;
                            } else {
                                $cdnPurgeData = $objCourse->buildCdnPurgeData($courseId, $courseData['name'] . ' About Course Section Data Added / Modified ');
                                $objCdn = new Model_CdnPurgeLog();
                                if (!empty($cdnPurgeData))
                                    $objCdn->InsertCdnPurgeLog($cdnPurgeData);
                                $this->view->message = "Saved SuccessFully";
                                $this->view->success = true;
                                $strAppend = '';
                                if ($contentType !== BaseApp_Dao_CourseFaq::COURSE_RESOURCE_EXAM_PASS_NEW_ID) {
                                    $this->_redirect("/admin/course/course-indetail/courseId/{$courseId}/param/{$courseSectionId}");
                                } else {
                                    $examPassContent = $objCourseFaq->getDataByTypeAndContentId($courseId, "course", BaseApp_Dao_CourseFaq::COURSE_RESOURCE_EXAM_PASS_NEW_ID, 0, 'all', $countryId, 0, 0, $offset, $limitPerPage);
                                    if (!empty($examPassContent)) {
                                        $examPassContent = current($examPassContent);
                                        $idExam = !empty($examPassContent['course_faq_id']) ? $examPassContent['course_faq_id'] : '';
                                        if (!empty($idExam)) {
                                            $this->_redirect("/admin/course/course-indetail/courseId/{$courseId}/param/{$courseSectionId}?contentId={$idExam}");
                                        }
                                    }
                                }
                            }
                        }
                        else {
                            $this->view->message = $errorMessage;
                            $this->view->success = false;
                        }
                    } else {
                        if($contentType == BaseApp_Dao_CourseFaq::COURSE_RESOURCE_EXAM_PASS_NEW_ID){
                        $examPassContent = $objCourseFaq->getDataByTypeAndContentId($courseId, "course", BaseApp_Dao_CourseFaq::COURSE_RESOURCE_EXAM_PASS_NEW_ID, 0, 'all', $countryId, 0, 0, $offset, $limitPerPage);
                            if(!empty($examPassContent)){
                                $examPassContent = current($examPassContent);
                                $idExam = !empty($examPassContent['course_faq_id'])?$examPassContent['course_faq_id']:'';
                                if (!empty($idExam) && empty($this->getRequest()->getParam('contentId'))) {
                                    $this->_redirect("/admin/course/course-indetail/courseId/{$courseId}/param/{$courseSectionId}?contentId={$idExam}");
                                }
                            }elseif(empty($examPassContent) && empty($this->getRequest()->getParam('addMore'))){
                                $this->_redirect("/admin/course/course-indetail/courseId/{$courseId}/param/{$courseSectionId}?addMore=1");
                            }
                        }
                        if($contentType!=$relatedCourseSectionId){
                            if ($countryId == '' && $clusterId == '') {
                                $clusterId = 'all';
                            } else if($countryId == 'all') {
                                $clusterId = 0;
                                $countryId = 0;
                            }
                        }

                        switch($contentType){
                            case $relatedCourseSectionId:
                                $totalResourceCount = count($objCourselinkBlock->getDataByTypeAndContentId($courseId, "course", $contentType, $courseSectionData['training_id'], $clusterId, $countryId, 0, $contentId, $offset, null));
                                $courseContent = $objCourselinkBlock->getDataByTypeAndContentId($courseId, "course", $contentType, $courseSectionData['training_id'], $clusterId, $countryId, 0, $contentId, $offset, $limitPerPage);                            
                            break;
                            default:
                                                      
                            $totalResourceCount = count($objCourseFaq->getDataByTypeAndContentId($courseId, "course", $contentType, $courseSectionData['training_id'], $clusterId, $countryId, 0, $contentId, $offset, null));
                            $courseContent = $objCourseFaq->getDataByTypeAndContentId($courseId, "course", $contentType, $courseSectionData['training_id'], $clusterId, $countryId, 0, $contentId, $offset, $limitPerPage);
                            break;
                        }
                        $totalPages = ceil($totalResourceCount / $limitPerPage);
                        $this->view->totalPages = $totalPages;
                        $this->view->startPos = $offset;
                        $this->view->totalResourceCount = $totalResourceCount;
                        $contentCourseData = array(
                            'contentCourse' => $courseContent
                        );
                        if (!empty($addMore)) {
                            $contentCourseData = array();
                        }
                        $showCourseFaqForm = empty($contentId) && !empty($contentCourseData) ? false : true;
                        $showCourseDataListing = empty($contentId) && !empty($contentCourseData) ? true : false;
                        $this->view->detailData = !empty($contentCourseData['contentCourse']) ? $contentCourseData['contentCourse'] : array();
                        $this->view->detailListing = $showCourseDataListing;
                        $this->view->title = 'About Course';
                        $this->view->linkableId = $courseId;
                        $this->view->linkableType = "course";
                        $this->view->sectionType = $contentType;
                        $this->view->addMore = $addMore;
                        $this->view->isEdit = $isEdit;
                        $this->_setContentCourse($contentCourseData, $showCourseFaqForm);
                        $default = array();
                        if ($showCourseFaqForm) {
                            $this->view->detailListing = false;
                            $addMoreButton = !empty($addMore) ? true : false;
                            switch($contentType){
                                case $relatedCourseSectionId:
                                    $form       = new Form_CourseLinkBlock($courseId,$countryId,$clusterId);
                                    if( !empty($countryId) || !empty($clusterId) ){
                                        $default    = $objCourselinkBlock->getCourseContent($courseId,$countryId,$clusterId);
                                    }
                                break;
                                case BaseApp_Dao_CourseFaq::COURSE_RESOURCE_BENEFITS:
                                    $form = new Form_CourseContentBenefits();
                                break;
                        case BaseApp_Dao_CourseFaq::COURSE_RESOURCE_EXAM_PASS_NEW_ID:
                            $form = new Form_ExamPassGuarantee($showCourseFaqForm, $showAnswerField);
                            break;
                                default:
                                    $form = new Form_CourseContentQuestions($showCourseFaqForm, $showAnswerField);
                                break;
                            }
                            $form->setDefaults($default);
                        }
                    }
        }
        
        $this->view->sectionTemplates = $sectionTemplatesData;
        if (isset($form)) {
            $this->view->form = $form;
        }
    }

     /**
     * Checks if there is content already existing for the country specified
     * @return boolean
     */
    private function _contentExistsForCountry($courseId, $contentType, $trainingId, $clusterId, $countryId) {         
        $objCourseFaq = new Model_CourseFaq();
        $contentCountryId = !empty($countryId) ? $countryId: 0;
        $countryContent = $objCourseFaq->getDataByTypeAndContentId($courseId, "course", $contentType, $trainingId, $clusterId, $contentCountryId);
        if (!empty($countryContent)) {
            foreach($countryContent as $content) {
                if ($content['countryIds'] == $countryId) {
                   return true;
                }
            }
        }
        return false;
   }

 
    public function courseMoredetailAction() {  
        $courseId = $this->getRequest()->getParam('courseId');
       if (empty($courseId)) {
            $this->view->message = "Course id not given";
            $this->view->success = false;
            return;
        }
        if ($this->getRequest()->isPost()) {
            $postData = $this->getRequest()->getPost();
            $this->_setCourseProjects($postData);
            $this->_setCourseSkills($postData);
            $form = new Form_CourseMoreDetail();
            $objCourseFaq = new Model_CourseFaq();
            $skillsData = array();
            $eligibilityData = array();
            $eligibility = array();
            $prerequisitesData = array();
            $prerequisites = array();
            $batchBenefitsData = array();
            $batchBenefits = array();
            $eligibilityData['question'] = isset($postData['eligibility']) ? $postData['eligibility'] : '';
            $eligibilityData['all_country']= 1;
            $eligibilityData['linkable_id'] = $courseId;
            $eligibilityData['linkable_type'] = "course";
            $eligibilityData['course_faq_id'] = $postData['eligibility_id']? $postData['eligibility_id']:null;
            $eligibility[]= $eligibilityData;
            $faqId = $eligibilityData['course_faq_id'];
            if (!empty($faqId)) {
                $objCourseFaq->addCourseContent($eligibility, BaseApp_Dao_ProductTypes::TYPE_ID_ELIGIBILITY, $courseId, BaseApp_Dao_TrainingTypes::TYPE_GENERIC, null, true, "course");
                if(empty($eligibilityData['question'])){
                   $objCourseFaq->deleteCourseFaq($eligibility, BaseApp_Dao_ProductTypes::TYPE_ID_ELIGIBILITY);
                }
            } else{
                if ($eligibilityData['question']) {
                    $objCourseFaq->addCourseContent($eligibility, BaseApp_Dao_ProductTypes::TYPE_ID_ELIGIBILITY, $courseId, BaseApp_Dao_TrainingTypes::TYPE_GENERIC, null, false, "course");
                }
            }
            $prerequisitesData['question'] = isset($postData['Prerequisites']) ? $postData['Prerequisites'] : '';
            $prerequisitesData['all_country']= 1;
            $prerequisitesData['linkable_id'] = $courseId;
            $prerequisitesData['linkable_type'] = "course";
            $prerequisitesData['course_faq_id'] = $postData['prerequisites_id'];
            $prerequisites[]= $prerequisitesData;
            $preFaqId = $prerequisitesData['course_faq_id'];
            if (!empty($preFaqId)) {
                $objCourseFaq->addCourseContent($prerequisites,BaseApp_Dao_ProductTypes::TYPE_ID_PREREQUISITES,$courseId,BaseApp_Dao_TrainingTypes::TYPE_GENERIC,null,true,"course");      
                if(empty($prerequisitesData['question'])){
                   $objCourseFaq->deleteCourseFaq($prerequisites, BaseApp_Dao_ProductTypes::TYPE_ID_PREREQUISITES);
                }
            } else{
                if ($prerequisitesData['question']) {
                    $objCourseFaq->addCourseContent($prerequisites, BaseApp_Dao_ProductTypes::TYPE_ID_PREREQUISITES, $courseId, BaseApp_Dao_TrainingTypes::TYPE_GENERIC, null, false, "course");
                }
            }
            $batchBenefitsData['question'] = isset($postData['batchbenefits']) ? $postData['batchbenefits'] : '';
            $batchBenefitsData['all_country']= 1;
            $batchBenefitsData['linkable_id'] = $courseId;
            $batchBenefitsData['linkable_type'] = "course";
            $batchBenefitsData['course_faq_id'] = $postData['batchbenefits_id'];
            $batchBenefits[]= $batchBenefitsData;
            $batchBenFaqId = $batchBenefitsData['course_faq_id'];
            if ($batchBenFaqId) {
                $objCourseFaq->addCourseContent($batchBenefits,BaseApp_Dao_ProductTypes::TYPE_ID_BATCHBENIFITS,$courseId,BaseApp_Dao_TrainingTypes::TYPE_GENERIC,null,true,"course");      
                if(empty($batchBenefitsData['question'])){
                   $objCourseFaq->deleteCourseFaq($batchBenefits, BaseApp_Dao_ProductTypes::TYPE_ID_BATCHBENIFITS);
                }
            } else{
                if ($batchBenefitsData['question']) {
                    $objCourseFaq->addCourseContent($batchBenefits, BaseApp_Dao_ProductTypes::TYPE_ID_BATCHBENIFITS, $courseId, BaseApp_Dao_TrainingTypes::TYPE_GENERIC, null, false, "course");
                }
            }
            
            $skillsData['skills'] = isset($postData['skills']) ? $postData['skills'] : array();
            
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            if ($form->isValid($postData)) {
                /*
                saving Ind project section
                 */
                $projectData = array();
                if (!empty($postData['projects'])) {
                    $projectData['projects'] = $postData['projects'];
                }
                $projectSectionTitle = !empty($postData['projectsDescription']) ? $postData['projectsDescription'] : '';
                $projectTitleSectionId = !empty($postData['projectTitleSectionId']) ? $postData['projectTitleSectionId'] : '';
                $parameter = array();
                if (!empty($projectData['projects'])) {
                    $parameter = array('courseId' => $courseId, 'projects' => $projectData['projects']);
                }
                if (!empty($skillsData['skills'])) {
                    $skillsCovered = array('courseId' => $courseId, 'skills' => $skillsData['skills']);
                }
                /**
                 * saving project section title and project section data along with job data
                 */
                $this->handleProjectSection($projectSectionTitle,$projectTitleSectionId,$parameter);

                $this->handleCourseSkills($skillsCovered);                
                //setting data to session 
                
                $this->_redirect("/admin/pricing/add/courseId/$courseId");
                //            }
            }
        } elseif ($courseId) {
                    $order = 'ps.id ASC';
                    $session = new Zend_Session_Namespace('form');
                $objProductSectionData = new Model_ProductSectionData();
                $objCourseFaq = new Model_CourseFaq();
                $session->eligibility = array();
                $eligibilityInfo = $objCourseFaq->getDataByTypeAndContentId($courseId, "course", BaseApp_Dao_ProductTypes::TYPE_ID_ELIGIBILITY, BaseApp_Dao_TrainingTypes::TYPE_GENERIC);               
                if($eligibilityInfo){
                $session->eligibility = $eligibilityInfo[0];
                }
                
                $prerequisitesInfo = $objCourseFaq->getDataByTypeAndContentId($courseId, "course", BaseApp_Dao_ProductTypes::TYPE_ID_PREREQUISITES, BaseApp_Dao_TrainingTypes::TYPE_GENERIC);
                $session->prerequisites = array();
                if($prerequisitesInfo){
                $session->prerequisites = $prerequisitesInfo[0];
                }                
                $batchBenefitsInfo = $objCourseFaq->getDataByTypeAndContentId($courseId, "course", BaseApp_Dao_ProductTypes::TYPE_ID_BATCHBENIFITS, BaseApp_Dao_TrainingTypes::TYPE_GENERIC);
                $session->batchBenefits = array();
                if($batchBenefitsInfo){
                $session->batchBenefits = $batchBenefitsInfo[0];
                }
                $skillsCoveredData = array(
                    'skills' => $objProductSectionData->getDataByType($courseId,BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE,BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_SKILLS_COVERED,TRUE,$order)
                    );
                $this->_setCourseSkills($skillsCoveredData);
                $result = true;
                $pTitleData = $this->_getCourseProjectsTitle($objProductSectionData,$courseId,BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE,BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE_PROJECTS_TITLE);
                $courseProjectsData = $this->_getCourseProjects($objProductSectionData,$courseId,BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE,BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE_PROJECTS,$order);
                $projects = $courseProjectsData;
                $this->_setCourseProjects($projects);
                $form = new Form_CourseMoreDetail();
                $addtionalContentData = array();
                $addtionalContentData['projectsDescription'] = !empty($pTitleData['sectionTitle'])?$pTitleData['sectionTitle']:'';
                $addtionalContentData['projectTitleSectionId'] = !empty($pTitleData['section_id'])?$pTitleData['section_id']:'';
                if ($form === false)
                    throw new Zend_Exception('_getForm not implemented');
                $form->setDefaults($addtionalContentData);
            }
            else
                $this->_redirect("/admin/pricing/add/courseId/$courseId");
       $this->view->form = $form;
    }
    public function courseEnterpriseAction() {
        $objCourse = new Model_Courses();
        if ($courseId = $this->getRequest()->getParam('courseId')) {
            // Edit
            if (!$objCourse->getCourseById($courseId)) {
                $this->view->message = "Invalid Course Id";
                $this->view->success = false;
                return;
            }
        } else {
            // Add
            $courseId = null;
            $this->view->message = "Course id not given";
            $this->view->success = false;
            return;
        }
        $form = new Form_CoursesEnterprise($courseId);
        if ($this->getRequest()->isPost()) {
            // submit action
            $courseData = $this->getRequest()->getPost();
            unset($courseData['Save']);
            if ($form->isValid($courseData)) {
                $courseId = $objCourse->saveSettings($courseId, $courseData);
                $this->_redirect("/admin/course/list");
            }
        }
        $this->view->success = true;
        $this->view->form = $form;
    }
    public function courseMobileAction()
    {
        $objCourse = new Model_Courses();

        $imageData = array();
        $imageData1 = array();
        if ($courseId = $this->getRequest()->getParam('courseId')) {
            // Edit
            if (!$objCourse->getCourseById($courseId)) {
                $this->view->message = "Invalid Course Id";
                $this->view->success = false;
                return;
            }
        } else {
            // Add
            $courseId = null;
            $this->view->message = "Course id not given";
            $this->view->success = false;
            return;
        }
        $form = new Form_CoursesMobileContent($courseId);


        if ($this->getRequest()->isPost()) {
            $imageInfo = $this->getRequest()->getPost();
            $postData = array_merge_recursive($imageInfo, $_FILES);
            unset($postData['Save']);
            if ($form->isValid($postData)) {
                if (!empty($_FILES['rect_image'])) {
                    if (isset($_FILES['rect_image']['name']) && $_FILES['rect_image']['name'] != '') {
                        $fileName = $_FILES['rect_image']['name'];
                        $absFilePath = $_FILES['rect_image']['tmp_name']; //sys_get_temp_dir().DIRECTORY_SEPARATOR.$fileName;
                        // $absFilePath = sys_get_temp_dir().DIRECTORY_SEPARATOR.$fileName;
                        $s3path = AWS_S3_IMAGES_PATH . '/app';
                        $certificateImageUrl = BaseApp_Utility_ImageProcessing::transformAndUploadToS3($absFilePath, $fileName, $s3path);
                        $imageData = array();
                        if (isset($certificateImageUrl)) {
                            array_push($imageData, array(
                                'name' => 'rectangular_image',
                                'imagePath' => $certificateImageUrl,
                                'linkable_id' => $courseId,
                                'linkable_type' => 'course',
                            ));
                        }
                    }
                }
                if (!empty($_FILES['square_image'])) {
                    if (isset($_FILES['square_image']['name']) && $_FILES['square_image']['name'] != '') {
                        $fileName = $_FILES['square_image']['name'];
                        $absFilePath = $_FILES['square_image']['tmp_name'];
                        // $absFilePath = sys_get_temp_dir().DIRECTORY_SEPARATOR.$fileName;
                        $s3path = AWS_S3_IMAGES_PATH . '/app';
                        $certificateImageUrl = BaseApp_Utility_ImageProcessing::transformAndUploadToS3($absFilePath, $fileName, $s3path);
                        $imageData1 = array();
                        if (isset($certificateImageUrl)) {
                            array_push($imageData1, array(
                                'name' => 'square_image',
                                'imagePath' => $certificateImageUrl,
                                'linkable_id' => $courseId,
                                'linkable_type' => 'course',
                            ));
                        }
                    }
                }
                $data = array_merge($imageData, $imageData1);
                if (!empty($data)) {
                    $objCourse->saveBasicImages($courseId, $data);
                    $this->view->message = "Uploaded successfully";
                } else {
                    $this->view->message = "Error in uploading";
                    return;
                }
                $imageModel = new Model_Images();
                $imageData = $imageModel->getInclusionImages($courseId);
                if (!empty($imageData)) {
                    $form = new Form_CoursesMobileContent($courseId);
                }
            }
        }
        $this->view->success = true;
        $this->view->form = $form;
    }

    private function handleProjectSection($title = '', $projectTitleSectionId, $parameter = array())
    {
        $productId = $parameter['courseId'];
        $objProductSectionData = new Model_ProductSectionData();
        $projectTitle = htmlspecialchars(trim($title));
        $projectTitle = htmlentities($projectTitle, ENT_COMPAT, 'utf-8');
        $projectTitle = preg_replace("/[^ \w]+/", "", $projectTitle);
        $param['course_id_arr'] = array($productId);
        $param['sectionType'] = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE_PROJECTS_TITLE;
        $param['sectionTitle'] = $projectTitle;
        $param['name'] = $projectTitle;
        if (!empty($projectTitleSectionId)) {
            if (empty($title)) {
                $linkableId = $projectTitleSectionId;
                $linkableType = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE_PROJECTS_TITLE;
                $objProductSectionData->updateToolProductSectionData($linkableId, $linkableType);
                $objSectionMapping = new Model_SectionMapping();
                $updateStatus = $objSectionMapping->disableSecMapBySectionId($productId, BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE, $linkableId);
            } else {
                $objProductSectionData->updatedPSDataProjects($projectTitleSectionId, $param);
            }
        } else {
            if (!empty($title)) {
                $objProductSectionData->saveProductSectionData($param);
            }
        }
        if (!empty($parameter)) {
            $this->handleCourseProjects($parameter);
        }
    }
    private function handleCourseProjects($data = array())
    {  
        $objSectionMapping = new Model_SectionMapping();
        if (!empty($data)) {
            $productId = $data['courseId'];
            $objProductSectionData = new Model_ProductSectionData();
            $newProductSectionData = array();
            foreach ($data['projects'] as $key => $project) {
                if ($key === '__template__') {
                    continue;
                }
                $companyContent = htmlspecialchars(trim($project['content']));
                $projectTitle = htmlspecialchars(trim($project['name']));
                $projectTitle = htmlentities($projectTitle, ENT_COMPAT, 'utf-8');
                $projectTitle = preg_replace("/[^ \w]+/", "", $projectTitle);
                $companyId = !empty($project['companyIds']) ? $project['companyIds'] : '';
                $sectionId = !empty($project['sectionId']) ? $project['sectionId'] : '';
                $sectionType = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE_PROJECTS;
                $param['course_id_arr'] = array($productId);
                $param['sectionType'] = $sectionType;
                $param['sectionTitle'] = $projectTitle;
                $param['name'] = $projectTitle;
                $param['description'] = $companyContent;
                $companyIds = array();
                if(!empty($companyId)){
                    $companyIds = array($companyId);
                }
                $isStatus = false;
                if (!empty($sectionId)) {
                    $newProductSectionData[$sectionId] = $sectionId;
                    if (empty($param['name']) && empty($param['description'])) {
                        $isStatus = true;
                        $linkableId = $sectionId;
                        $linkableType = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE_PROJECTS;
                        $updateResponse = $objProductSectionData->updateToolProductSectionData($linkableId, $linkableType);
                        $updateStatus = $objSectionMapping->disableSecMapBySectionId($productId, BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE, $linkableId);
                        $updateStatus = $objSectionMapping->disableSecMapBySectionId($companyId, 'hiring_company', $linkableId);

                    } else {
                        $objProductSectionData->updatedPSDataProjects($sectionId, $param);
                    }
                } else {
                    if (!(empty($param['name']) && empty($param['description']))) {
                        $sectionId = $objProductSectionData->saveProductSectionData($param);
                    }
                }
                if (!empty($sectionId) && empty($isStatus)) {
                    $newProductSectionData[$sectionId] = $sectionId;
                    $objSectionMapping->saveProductSectionDataBySectionId($companyIds, 'hiring_company', $sectionId);
                }
            }
            $existingProjectsData = $objProductSectionData->getDataByType($productId, BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE, BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE_PROJECTS);
            $existingProjects = array_keys($existingProjectsData);
            $newCourseCategoryProjects = array_keys($newProductSectionData);
            $courseProjectsCategoryDiff = array_diff($existingProjects, $newCourseCategoryProjects);
            if (is_array($courseProjectsCategoryDiff) && !empty($courseProjectsCategoryDiff)) {
                foreach ($courseProjectsCategoryDiff as $projectId) {
                    if (!in_array($projectId, $newCourseCategoryProjects)) {
                        $linkableId = $projectId;
                        $linkableType = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE_PROJECTS;
                        $updateResponse = $objProductSectionData->updateToolProductSectionData($linkableId, $linkableType);
                        $updateStatus = $objSectionMapping->disableSecMapBySectionId($productId, BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE, $linkableId);
                        $updateStatus = $objSectionMapping->disableSecMapBySectionId('', 'hiring_company', $linkableId);
                    }
                }
            }
        }
    }
    private function handleCourseSkills($data = array())
    {  
        if (!empty($data)) {
            $productId = $data['courseId'];
            $objProductSectionData = new Model_ProductSectionData();
            $objSectionMapping = new Model_SectionMapping();
            $newProductSectionData = array();
            foreach ($data['skills'] as $key => $project) {
                if ($key === '__template__') {
                    continue;
                };
                $skillsData = htmlspecialchars(trim($project['name']));
                $skillsData = preg_replace("/[^ \w]+/", "", $skillsData);
                $sectionId = !empty($project['sectionId']) ? $project['sectionId'] : '';
                $sectionType = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_SKILLS_COVERED;
                $sectionTitle = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_SKILLS_COVERED_TITLE;
                $param['course_id_arr'] = array($productId);
                $param['sectionType'] = $sectionType;
                $param['sectionTitle'] = $sectionTitle;
                $param['name'] = $skillsData;
                $courseIds = array($productId);
                if (!empty($sectionId)) {
                    $newProductSectionData[$sectionId] = $sectionId;
                    if (empty($param['name'])) {
                        $linkableId = $sectionId;
                        $linkableType = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_SKILLS_COVERED;
                        $updateResponse = $objProductSectionData->updateToolProductSectionData($linkableId, $linkableType);
                        $updateStatus = $objSectionMapping->disableSecMapBySectionId($productId, BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE, $sectionId);
                    } else {
                        
                        $objProductSectionData->updatedPSDataProjects($sectionId, $param);
                    }
                } else {
                    if(!empty($param['name'])){
                        $sectionId = $objProductSectionData->saveProductSectionData($param);
                    }
                }
                if (!empty($sectionId)) {
                    $newProductSectionData[$sectionId] = $sectionId;
                }
            }
            $existingSkillsData = $objProductSectionData->getDataByType($productId, BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE, BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_SKILLS_COVERED);
            $existingSkills = array_keys($existingSkillsData);
            $newCourseCategorySkills = array_keys($newProductSectionData);
            $courseSkillsCategoryDiff = array_diff($existingSkills, $newCourseCategorySkills);
            if (is_array($courseSkillsCategoryDiff) && !empty($courseSkillsCategoryDiff)) {
                foreach ($courseSkillsCategoryDiff as $sectionId) {                   
                    if (!in_array($sectionId, $newCourseCategorySkills)) {
                        $linkableId = $sectionId;
                        $linkableType = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_SKILLS_COVERED;
                        $updateResponse = $objProductSectionData->updateToolProductSectionData($linkableId, $linkableType);
                        $updateStatus = $objSectionMapping->disableSecMapBySectionId($productId,BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE,$sectionId);
                        
                    }
                }
            }
        }
    }
    private function _getCourseProjectsTitle(Model_ProductSectionData $modelObj, $linkableId, $linkableType, $sectionType)
    {
        $courseProjectTitleData = $modelObj->getDataByType($linkableId, $linkableType, $sectionType);
        $courseProjectTitleData = !empty($courseProjectTitleData)?current($courseProjectTitleData):array();
        return $courseProjectTitleData;
    }
    private function _getCourseProjects(Model_ProductSectionData $modelObj, $linkableId, $linkableType, $sectionType,$order='')
    {
        $sectionObj = new Model_SectionMapping();
        $formattedData = array();
        $courseProjectCategoryData = $modelObj->getDataByType($linkableId, $linkableType, $sectionType,TRUE,$order);
        if (is_array($courseProjectCategoryData) && !empty($courseProjectCategoryData)) {
            if (!empty($courseProjectCategoryData)) {
                foreach ($courseProjectCategoryData as $key => $value) {
                    $linkableId = $key;
                    $linkableType = 'hiring_company';
                    $toolsData = $sectionObj->getByProductSection($linkableType,$linkableId);
                    $bundleCategoryAndToolMap[$key]['name'] = $value['name'];
                    $bundleCategoryAndToolMap[$key]['content'] = $value['ps_description'];
                    $bundleCategoryAndToolMap[$key]['sectionId'] = $value['section_id'];
                    if(!empty($toolsData)){
                        $bundleCategoryAndToolMap[$key]['companyIds'] = current($toolsData);
                    }
                }
                if (!empty($bundleCategoryAndToolMap)) {
                    $formattedData['projects'] = $bundleCategoryAndToolMap;
                }
            }
        }
        return $formattedData;
    }
    private function _setCourseSkills(&$request) {
        $session = new Zend_Session_Namespace('form'); 
        if(isset($request['skills']) && count($request['skills'])) {
            
            $request['skills'] = $this->_updateFirstElement($request['skills']);        
            $session->skills = array_keys($request['skills']);
            array_unshift($session->skills, '__template__');
            $session->skillsData=  $request['skills'];
        }
        else {
            $session->skills = array('__template__', 'new');
            $session->skillsData = array();
        }
    }
    private function _setCourseProjects($request)
    {
        $session = new Zend_Session_Namespace('form');
        if (isset($request['projects']) && count($request['projects'])) {

            $request['projects'] = $this->_updateFirstElement($request['projects']);
            $session->projects = array_keys($request['projects']);
            array_unshift($session->projects, '__template__');
            $session->projectsData =  $request['projects'];
        } else {
            $session->projects = array('__template__', 'new');
            $session->projectsData = array();
        }
    }
    private function _setContentCourse(&$request, $show = true) {
        $session = new Zend_Session_Namespace('form');
        if ($show) {
            if (isset($request['contentCourse']) && count($request['contentCourse'])) {
                $request['contentCourse'] = $this->_updateFirstElement($request['contentCourse']);
                $session->contentCourse = array_keys($request['contentCourse']);
                array_unshift($session->contentCourse, '__template__');
                if (isset($request['contentCourse']['new']) && isset($request['contentCourse']['new']['jobdesignation'])){
                    unset($request['contentCourse']['new']['jobdesignation']['__template__']);
                }
                $session->contentCourseData = $request['contentCourse'];
            } else {
                $session->contentCourse = array('__template__', 'new');
                $session->contentCourseData = array();
            }
        } else {
            $session->contentCourseData = array();
            $session->contentCourse = array();
        }
    }

    private function _updateFirstElement($elementArray) {
        $keys = array_keys($elementArray);
        $keys[array_search('0', $keys)] = 'new';
        return array_combine($keys, $elementArray);
    }

    private function _setFaq(&$request) {
        $session = new Zend_Session_Namespace('form');
        if (isset($request['genericCourseFaq']) && count($request['genericCourseFaq'])) {
            $request['genericCourseFaq'] = $this->_updateFirstElement($request['genericCourseFaq']);
            $session->genericCourseFaq = array_keys($request['genericCourseFaq']);
            array_unshift($session->genericCourseFaq, '__template__');
            $session->genericCourseFaqData = $request['genericCourseFaq'];
        } else {
            $session->genericCourseFaq = array('__template__', 'new');
            $session->genericCourseFaqData = array();
        }
    }
    /**
     * save industry trends title, heading and text 
     */
    public function _saveIndustryTrends($data,$faqId){
        try{
            $sessionMapping = new Model_ProductSectionData();
            $existingJobs = $sessionMapping->getDataByType($faqId, BaseApp_Dao_SectionMapping::COURSE_FAQ_LINKABLE_TYPE , BaseApp_Dao_ProductSectionData::INDUSTRY_TREND_ADDITIONAL_DATA, true, 'sm.id ASC');
            //Saving existing and updated jobs to compare and delete the removed jobs.
            $existingJobsArr = array();
            $productMapArr = array();
            $updatedJobsArr = array();
            $newJobsArr = array();
            if (!empty($existingJobs)) {
                foreach($existingJobs as $existingJob){
                    $existingJobsArr[$existingJob['id']] = $existingJob['section_id'];
                    $productMapArr[$existingJob['id']] = $existingJob['section_id'];
                } 
            }

            if(!empty($data)){
                $productSectionFaq = array(); 
                $productSection = new Model_ProductSectionData();
                $productSectionFaq['name'] = $data['designation'];
                $productSectionFaq['sectionType'] = "job_designation";
                $productSectionFaq['course_faq_id_arr']= array();
                $productSectionFaq['hiring_company_arr'] = explode(',',$job['company_ids']);
                array_push($productSectionFaq['course_faq_id_arr'], $faqId);
            }
        }catch(Exception $ex){
            if (APPLICATION_ENV == 'development')
                throw $ex;
            return false;
        }
    }

    /**
     * Saves course job designation if it is benefit type 
     * saves job in Product section Table
     * Maps faq and hiring company in session mapping
     * saves salary in salary table
     */
    private function _saveCourseJobDesignations($data, $faqId){
        try{
            $sessionMapping = new Model_ProductSectionData();
            $existingJobs = $sessionMapping->getDataByType($faqId, BaseApp_Dao_SectionMapping::COURSE_FAQ_LINKABLE_TYPE , BaseApp_Dao_ProductSectionData::JOB_DESIGNATION_SECTION_TYPE, true, 'sm.id ASC');
            //Saving existing and updated jobs to compare and delete the removed jobs.
            $existingJobsArr = array();
            $productMapArr = array();
            $updatedJobsArr = array();
            $newJobsArr = array();
            if (!empty($existingJobs)) {
                foreach($existingJobs as $existingJob){
                    $existingJobsArr[$existingJob['id']] = $existingJob['section_id'];
                    $productMapArr[$existingJob['id']] = $existingJob['section_id'];
                } 
            }

            if(!empty($data)){
                foreach($data as $key => $job){
                    if(!empty($job)){
                        if ($key=== '__template__'){
                            continue;
                        }
                        $productSectionFaq = array(); 
                        $productSection = new Model_ProductSectionData();
                        $productSectionFaq['name'] = $job['designation'];
                        $productSectionFaq['sectionType'] = "job_designation";
                        $productSectionFaq['course_faq_id_arr']= array();
                        $productSectionFaq['hiring_company_arr'] = explode(',',$job['company_ids']);
                        array_push($productSectionFaq['course_faq_id_arr'], $faqId);                        
                        if (empty($job['section_id'])){
                            $produtSectionId = $productSection->saveProductSectionData($productSectionFaq);
                            $produtSectionMapId = $productSection->segmentMapId;
                            $newJobsArr[$produtSectionMapId] = $produtSectionId;
                            $productMapArr[$produtSectionMapId] = $produtSectionId;
                            //no insert to city
                        } else {
                            $produtSectionId = $job['section_id'];
                            $produtSectionMapId = $job['section_map_id'];
                            if (!$productSection->updateProductSectionData($produtSectionId, $productSectionFaq,BaseApp_Dao_CourseFaq::COURSE_RESOURCE_BENEFITS,$produtSectionMapId)){
                                throw new BaseApp_Exception('Job designation culd not be updated');
                            }          
                            
                            $produtSectionMapId = $productSection->segmentMapId;
                            //saving the jobs that are left after update. To compare and delete the removed ones.
                            $updatedJobsArr[$produtSectionMapId] = $produtSectionId;
                            $productMapArr[$produtSectionMapId] = $produtSectionId;
                        }              
                        
                        if ($produtSectionId){
                            //saving job salaries
                            //check if salary exists and delete them 
                            $salaries = new Model_Salaries();
                            $salaryData = array(
                                'min' => $job['min'],
                                'avg' => $job['avg'],
                                'max' => $job['max']                      
                            );                        
                            if (!$salaries->saveSalaries($salaryData, $produtSectionId,$produtSectionMapId)){
                                throw new BaseApp_Exception('Could not save Job salaries  mapping');
                            }

                        } else {
                            throw new BaseApp_Exception('Could not save Job designation');
                        }
                    }                
                }
            }
            $this->_deleteTheRemovedJobs($existingJobsArr, $newJobsArr, $updatedJobsArr,$productMapArr);
            return true;
        }  catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }        
    }

    private function _deleteTheRemovedJobs($existingJobsArr, $newJobsArr, $updatedJobsArr,$productMapArr){
        $renewJobsIds = array_diff(array_keys($existingJobsArr),array_keys($updatedJobsArr));
        $removedJobsIds = array_diff(array_values($existingJobsArr),array_values($updatedJobsArr));
        try{
            if (!empty($renewJobsIds)) {
                foreach($renewJobsIds as $renewJobId){
                    $sectionMapObj = new Model_SectionMapping();
                    $sectionMapObj->clean();
                    $sectionMapObj->setId($renewJobId);
                    $sectionMapObj->setFromArray(array('status' => 0))->update();
                    
                    //disable section Mapping by id
                    $salaryObj = new Model_Salaries();
                    $salaryObj->deleteSalaryBySectionMapId($renewJobId);
                }
            }

            if(!empty($removedJobsIds)){
                foreach($removedJobsIds as $removedJobsId){
                    foreach(array(BaseApp_Dao_SectionMapping::COURSE_FAQ_LINKABLE_TYPE ,BaseApp_Dao_SectionMapping::HIRING_COMPANY_LINKABLE_TYPE ) as $linkableTypeNew){
                        $sectionMapObj = new Model_SectionMapping();
                        $checkExisting = $sectionMapObj->fetchAll(array('linkable_type =?'=>$linkableTypeNew,'section_id =?'=> $removedJobsId));
                        if(!empty($checkExisting)){
                            foreach ($checkExisting as $key => $value) {
                                $sectionMapObj->clean();
                                $sectionMapObj->setId($value['id']);
                                $sectionMapObj->setFromArray(array('status'=>0))->update();
                            }
                        }
                    }
                }
            }
        }  catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        } 
    }

    public function getByPartNameAction() {
        $arg = $this->getRequest()->get('coursePart');
        $courseList = array();
        if ($arg) {
            foreach ($this->getModel()->getByPartName($arg) as $indexId => $data) {
                $courseList[$data['course_id']] = $data['name'];
            }
        }
        $this->_helper->layout->disableLayout();
        $this->view->courseList = $courseList;
    }

    public function updateCourseDetailAction() {
        $objCourseSections = new Model_CourseSections();
        $courseId = $this->getRequest()->getParam('courseId');
        if (empty($courseId)) {
            $this->view->message = "An error has occured while saving";
            $this->view->success = true;
            return;
        }
        $sectionTemplatesData = $objCourseSections->getCourseSection($courseId);
        $this->view->sectionTemplates = $sectionTemplatesData;
    }
    
    public function listAction() {
        $table = $this->getModel()->getName();
        $filterForm = new Form_Filters($table);
        $requestData = array();
        $queryParamsArr = array();
        $page = '';
        if ($this->getRequest()->isPost()) {
            $filterForm->populate($this->getRequest()->getPost());
            $page = 1;
            $requestData = $filterForm->getValues();
            foreach ($requestData as $elementName => $elementValue) {
                if (!empty($elementValue)) {
                    $queryData = $filterForm->getElement($elementName)->getAttrib('data-table');
                    $queryData['searchValue'] = $elementValue;
                    $this->queryBuilder($queryData);
                    $queryParamsArr[$queryData['search_id']] = $elementValue;
                }
            }
        }
        if (empty($page)) {
            $page = $this->view->navigatorPage;
            $page = (int) $this->getRequest()->getParam('page');
        }
        $orderby = $this->getModel()->getPk() . ' DESC';
        if (empty($this->_queryParams)) {
            $getData = $this->getRequest()->getQuery();
            unset($getData['page']);
            if (!empty($getData)) {
                foreach ($getData as $key => $value) {
                    $queryParamsArr[$key] = $value;
                    $returnData = $filterForm->getSearchFields($key);
                    if (!empty($returnData)) {
                        $returnData = $returnData[0];
                        $filterForm->getElement($returnData['searchColumnName'])->setValue($value);
                        $returnData['searchValue'] = $value;
                        $this->queryBuilder($returnData);
                    }
                }
            }
        }
        if ($page <= 1) {
            $this->view->firstpage = true;
            $page = 1;
        } else {
            $this->view->firstpage = false;
        }
        $offset = ($page - 1) * self::ROWS_PER_PAGE;
        $limit = array(self::ROWS_PER_PAGE, $offset);
        $this->view->page = $page;
        $model = $this->getModel();
        $data = $model->fetchAll($this->_queryParams, array('order' => array($orderby), 'limit' => $limit));
        $perPageData = count($data);
        if (count($data) < self::ROWS_PER_PAGE) {
            $this->view->lastpage = true;
        } else {
            $this->view->lastpage = false;
        }
        $total = $model->fetchCount($this->_queryParams);
        $numberOfPages = ceil($total / self::ROWS_PER_PAGE);
        if ($page < $numberOfPages) {
            $this->view->currentPageRecord = self::ROWS_PER_PAGE * $page;
        } else {
            $this->view->currentPageRecord = $total;
        }
        $this->view->diffPageRecord = $this->view->currentPageRecord - self::ROWS_PER_PAGE;
        if (count($data) < self::ROWS_PER_PAGE) {
            $this->view->diffPageRecord = $total - count($data);
        }
        $this->view->totalCount = $total;
        $this->view->totalPages = $numberOfPages;
        $this->view->lastPage = $numberOfPages;
        $pk = $model->getPk();
        $objConv = new Model_CourseConversion();
        foreach ($data as $courseKey => &$row) {
            $row['Action'] = "<a href='" . $this->view->url(array('action' => 'view', 'id' => $row[$pk])) . "'>View</a> " . "<a href='" . $this->view->url(array('controller' => 'changelog', 'action' => 'index', 'row' => $row[$pk], 'table' => $table)) . "'>ChangeLog</a> " . "<a href='#' onclick='deleteConfirmShow(\"" . $this->view->url(array('controller' => 'course', 'action' => 'delete', 'id' => $row[$pk])) . "\")'>Delete</a> " .
                    "<a href='" . $this->view->url(array('action' => 'basic', 'courseId' => $row[$pk])) . "'>Edit</a> ";
            $data[$courseKey]['purge'] = "<a class='purge' data-action='" . $this->view->url(array('action' => 'purgeurl', 'id' => $row[$pk] )) . "' data-id='10' href='" . $this->view->url(array('action' => 'purgeurl', 'id' => $row[$pk] )) . "'>purge</a> ";
            $conversionData = $objConv->getCountryForConversionCourse($row[$pk]);
            // if (!empty($conversionData))
            //     $data[$courseKey]['conversionCountry'] = $conversionData;
        }
        if (isset($data[0])) {
            $original = array_keys($data[0]);
        } else {
            $original = array();
        }
        $as = ($this->_displayInDataTable);
        $datatableFilePath = '../../library/BaseApp/Datatable/' . ucfirst($table) . '.php';
        if (file_exists($datatableFilePath)) {
            $dataTableClass = 'BaseApp_Datatable_' . ucfirst($table);
        } else {
            $dataTableClass = 'BaseApp_Datatable_Default';
        }
        $dataTable = new $dataTableClass;
        $dataTable->setData($data);
        $this->view->data = $dataTable;
        $this->view->original = $original;
        $this->view->displayInDataTable = $as;
        $this->view->queryParams = http_build_query($queryParamsArr);
        $this->view->form = $filterForm;
        $this->view->navigatorTotal = ceil($total / BACKEND_ROWS_PER_PAGE);
    }

    public function faqMoveAction() {
        $data = $this->getRequest()->getPost();
        $currentPos = $data['current_pos'];
        $finalPosition = $data['to_move_pos'];
        $message = '';
        $status = 'success';
        if (empty($data['course_faq_id']) || empty($data['current_pos']) || empty($data['to_move_pos'])) {
            $message = 'Missing data';
            $status = 'failed';
        } else {
            $objCourseFaq = new Model_CourseFaq();
            if ($currentPos != $finalPosition) {
                if (!$objCourseFaq->changeFaQOrder($data, $currentPos, $finalPosition)) {
                    $message = 'Failed to update';
                    $status = 'failed';
                }
            }
        }


        $this->_helper->layout->disableLayout();
        $this->view->data = array(
            'message' => $message,
            'status' => $status
        );
        $this->_redirect($_SERVER['HTTP_REFERER']);
    }
    public function purgeurlAction()
    {
        $Id = $this->getRequest()->getParam('id');
        try {
            $message = '';
            $status = '';
            $response = array();
            $purgeObj = new Helper_PurgeUrl();
            $extraData = array();
            $response = $purgeObj->submitPurgeData('course', 'course', $Id, $extraData);
            $data = array();
            if (!empty($response['data']) && !empty($response['data']['data'])) {
                $data = $response['data']['data'];
            }
            if (!empty($data)) {
                $message = "success";
                $status = "success";
            } else {
                http_response_code(404);
                $message = 'Some error occurred while fetching data.';
                $status = "error";
            }
        } catch (Exception $e) {
            http_response_code(401);
            $message = "Error occured." . $e->getMessage();
            $status = "error";
        }
        $this->view->data = array(
            'message' => $message,
            'status' => $status,
            'data' => $data
        );
        die(Zend_Json_Encoder::encode($this->view->data));
    }
    public function deleteAction() {
        $objCourse = new Model_Courses();
        $b2bCartPricing = new Model_B2bCartPricing();
        $this->_helper->viewRenderer->setRender('common/delete')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $courseId = $this->getRequest()->getParam('id');

        $dataDelete = $this->getModel($courseId);
        if (!$dataDelete->toArray()) {
            $this->view->message = "Invalid course";
            $this->view->success = false;
            return;
        }

        try {
            // b2b update based on course available for
            $groupsObj = new Model_Groups();
            $prePopulateParams = array('entity_type' => ENTITY_TYPE_FOR_ENTERPRISE_COURSE_MAPPING, 'entity_id' => $courseId, 'status' => 1);
            $res = $groupsObj->getPrePolulateEnterpriseList($prePopulateParams);
            $agencies = array_map(function($temp){return $temp['id'];} , $res);
            $availableForData = array('old' => array(), 'new' => array());
            $availableForData['new']['availableFor'] = 'no_where';
            $availableForData['new']['agencies'] = array();
            $availableForData['old']['availableFor'] = !empty($dataDelete['course_available_for']) ? $dataDelete['course_available_for']: '';
            $availableForData['old']['agencies'] = $agencies;
            $b2bHelper = new Helper_B2bHelper();
            $b2bHelper->processAvaliableForChange(BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE, $courseId, $availableForData);
        } catch (Exception $e) {
            file_put_contents(APPLICATION_PATH . '/../error.log', "\n[" .date('Y-m-d H:i:s'). '] ERROR: bundle processAvaliableForChange failed ' . $e->getMessage(), FILE_APPEND);
            if (APPLICATION_ENV != 'production') throw $e;
        }

        // check if workshop exists
        $modelWorkshop = new Model_Workshop();
        if ($modelWorkshop->getActiveWorkshopByCourse($courseId)) {
            $this->view->message = "Workshops exists for this course";
            $this->view->success = false;
            return;
        }

        // check if articles exists
        /**
          $modelArticles = new Model_Articles();
          if ($articleList = $modelArticles->getAssociatedArticlesByCourse($courseId)) {
          $this->view->message = "There are some articles associated with this course.";
          $this->view->success = false;
          return;
          }* */
        // check if ebooks exists
        $modelEbooks = new Model_Ebooks();
        if ($ebookList = $modelEbooks->getAssociatedArticlesByCourse($courseId)) {
            $this->view->message = "There are some ebooks associated with this course.";
            $this->view->success = false;
            return;
        }

        // check if videos exists
        $modelVideos = new Model_Videos();
        if ($videoList = $modelVideos->getAssociatedArticlesByCourse($courseId)) {
            $this->view->message = "There are some videos associated with this course.";
            $this->view->success = false;
            return;
        }

        // check if webinars exists
        $modelWebinars = new Model_Webinars();
        if ($webinarList = $modelWebinars->getAssociatedArticlesByCourse($courseId)) {
            $this->view->message = "There are some webinars associated with this course.";
            $this->view->success = false;
            return;
        }

        $objConv = new Model_CourseConversion();
        $conversionData = $objConv->getDataForCourseConversion($courseId);
        if (!empty($conversionData)) {
            $objConv->deleteCourseConversion($courseId);
        }

        //delete course
        $deleteStatus = $this->getModel()->deleteCourse($courseId, $message);
        if ($deleteStatus) {
            $productId = $courseId;
            $productType = 'course';
            $action = 'disable';
            $params = array(
                'productId' => $productId, 
                'productType' => $productType, 
                'action' => $action
            );
            $salsesforceApi = new BaseApp_Communication_SalesforceApi();
            $response = $salsesforceApi->SfdcPoductSync($params);
        }
        if (!$deleteStatus) {
            $this->view->message = $message;
            $this->view->success = false;
            return;
        }
        $b2bCartPricing->deleteB2bCartProductData('course',$courseId);
        $objCourse = new Model_Courses();
        $cdnPurgeData = $objCourse->buildCdnPurgeData($courseId, $dataDelete['name'] . ' Course Got Deleted ');
        $objCdn = new Model_CdnPurgeLog();
        if (!empty($cdnPurgeData))
            $objCdn->InsertCdnPurgeLog($cdnPurgeData);
        $this->_redirect("/admin/course/list");
    }

    private function _saveVideoSeo($videoId, $labelId, $thumbIMage) {
        $return = false;

        $labelMd = new Model_Labels();
        $labelName = $labelMd->getDisplayNameById($labelId);
        $labelName = strtolower($labelName);
        $labelName = preg_replace("/[^a-z0-9]/", "-", $labelName);

        $url = sprintf("/resources/%s-videos/about-course-rrt%d", $labelName, $videoId);

        $seoMd = new Model_Seo();
        $conds = array(
            'controller=?' => Model_Videos::SEO_DEFAULT_CONTROLLER,
            'action=?' => Model_Videos::SEO_DEFAULT_ACTION,
            'linkable_id=?' => $videoId,
            'linkable_type=?' => 'video'
        );
        if ($seoData = current($seoMd->fetchAll($conds, array(), false))) {
            $dataSave = array(
                'url' => $url,
                'thumb_image' => $thumbIMage
            );
            $seoMd->clean();
            $seoMd->setId($seoData['seo_id']);
            $seoMd->setFromArray($dataSave)->update();
            $return = true;
        } else {
            $dataSave = array(
                'url' => $url,
                'thumb_image' => $thumbIMage,
                'controller' => Model_Videos::SEO_DEFAULT_CONTROLLER,
                'action' => Model_Videos::SEO_DEFAULT_ACTION,
                'params' => json_encode(array(Model_Videos::SEO_DEFAULT_PARAM_KEY => $videoId)),
                'linkable_id' => $videoId,
                'linkable_type' => 'video'
            );
            $return = $seoMd->setFromArray($dataSave)->save();
        }
        return $return;
    }

    private function _prepareCoursePreviewToSave($coursePreviewData) {
        $return = array();
        foreach ($coursePreviewData as $elementKey => $data) {
            $chapterName = $data['chapterName'];
            unset($data['chapterName']);
            foreach ($data as $dataReal) {
                $return[] = array(
                    'name' => $dataReal['name'],
                    'url' => $dataReal['url'],
                    'duration' => $dataReal['duration'],
                    'chapter_name' => $chapterName
                );
            }
        }
        unset($coursePreviewData);
        return $return;
    }


    private function _buildInsertData($data, $courseId) {
        $returnArr = array();
        $countryInd = '';
        $countryUs = '';
        if (!empty($data['for_india']))
            $countryInd = INDIA_COUNTRY_ID;
        if (!empty($data['for_us']))
            $countryUs = US_COUNTRY_ID;

        if (!empty($countryInd)) {
            $conversionForIndia = $data['conversionForIndia'];
            foreach ($conversionForIndia as $row => $dataSet) {
                foreach ($dataSet as $name => $value) {
                    $returnArr[$countryInd][] = array('linkable_id' => $courseId, 'linkable_type' => 'course', 'conversrionCatgegory' => $row, 'conversionName' => $name, 'conversionValue' => $value);
                }
            }
        } // end of India Checks

        if (!empty($countryUs)) {
            $conversionForUs = $data['conversionForUs'];
            foreach ($conversionForUs as $row => $dataSet) {
                foreach ($dataSet as $name => $value) {
                    $returnArr[$countryUs][] = array('linkable_id' => $courseId, 'linkable_type' => 'course', 'conversrionCatgegory' => $row, 'conversionName' => $name, 'conversionValue' => $value);
                }
            }
        } // end of Us / Row Checks
        return $returnArr;
    }
    
    public function courselinkblockDeleteAction() {
        $data = $this->getRequest()->getPost();
        $faqId = $data['faq_id'];
        $linkableId = $data['linkable_id'];
        $linkableType = $data['linkable_type'];
        $sectionType = $data['section_type'];
        $courseFaqId = array(
            'course_faq_id' => $faqId,
        );
        $faqData = array($courseFaqId);
        $faqData['linkable_id'] = $linkableId;
        $faqData['linkable_type'] = $linkableType;
        /* $faqData['cluster_id'] = $data['cluster_id'];
        $faqData['country_id'] = $data['country_id'];
        $faqData['city_id'] = 0; */
        $message = '';
        $status = 'success'; 
        $objCourseFaq = new Model_CourseFaq();
        if (!$objCourseFaq->deleteCourseFaq($faqData, $sectionType)) {
            $message = 'Failed to update';
            $status = 'failed';
        }
        $this->_helper->layout->disableLayout();
        $this->view->data = array(
            'message' => $message,
            'status' => $status
        );
        die(Zend_Json_Encoder::encode($this->view->data));
    }

    /**
     * This is an Api call to delete Fa
     */
    public function faqDeleteAction() {
        $data = $this->getRequest()->getPost();
        $faqId = $data['faq_id'];
        $linkableId = $data['linkable_id'];
        $linkableType = $data['linkable_type'];
        $sectionType = $data['section_type'];
        $courseFaqId = array(
            'course_faq_id' => $faqId,
        );
        $faqData = array($courseFaqId);
        $faqData['linkable_id'] = $linkableId;
        $faqData['linkable_type'] = $linkableType;
        if(in_array($sectionType,array(BaseApp_Dao_CourseFaq::COURSE_RESOURCE_BENEFITS))){
            $faqData['country_id'] = !empty($data['country_id']) ? $data['country_id'] : 0;
            $faqData['city_id'] = !empty($data['city_id']) ? $data['city_id'] : 0;
        }
        $sectionTemplate = new Model_SectionTemplates();
        $relatedCourseSectionId = $sectionTemplate->getSectionId(BaseApp_Dao_CourseFaq::COURSE_RESOURCE_RELATED_COURSE);
        /* $faqData['cluster_id'] = $data['cluster_id'];
        $faqData['country_id'] = $data['country_id'];
        $faqData['city_id'] = 0; */
        $message = '';
        $status = 'success'; 
        switch ($sectionType) {
            case $relatedCourseSectionId:
                $objCourselinkBlock = new Model_CourseLinkBlock($faqId);
                if (!$objCourselinkBlock->deleteAndReorder()) {
                    $message = 'Failed to update';
                    $status = 'failed';
                }
                break;
            default:
                $objCourseFaq = new Model_CourseFaq();
                if (!$objCourseFaq->deleteCourseFaq($faqData, $sectionType)) {
                    $message = 'Failed to update';
                    $status = 'failed';
                }
                break;
        }
        
        $this->_helper->layout->disableLayout();
        $this->view->data = array(
            'message' => $message,
            'status' => $status
        );
        die(Zend_Json_Encoder::encode($this->view->data));
    }

    public function faqDisableAction() {
        $data = $this->getRequest()->getPost();
        $faqId = $data['faq_id'];
        $linkableId = $data['linkable_id'];
        $linkableType = $data['linkable_type'];
        $sectionType = $data['section_type'];
        $crmStatus = $data['crmStatus'];
        $courseFaqId = array(
            'course_faq_id' => $faqId,
        );
        $faqData = array('content_ids' => array($courseFaqId));
        $faqData['linkable_id'] = $linkableId;
        $faqData['linkable_type'] = $linkableType;
        $faqData['cluster_id'] = !empty($data['cluster_id']) ? $data['cluster_id']: 0;
        $faqData['country_id'] = !empty($data['country_id']) ? $data['country_id']: 0;
        $faqData['city_id'] = !empty($data['city_id']) ? $data['city_id']: 0;
        $message = '';
        $status = 'success';
        //if it is benefit type
        //disable job designation psd 
        $objCourseFaq = new Model_CourseFaq();
        if (!$objCourseFaq->disableCourseFaq($faqData, $sectionType,$crmStatus)) {
            $message = 'Failed to update';
            $status = 'failed';
        }
        $this->_helper->layout->disableLayout();
        $this->view->data = array(
            'message' => $message,
            'status' => $status
        );
        die(Zend_Json_Encoder::encode($this->view->data));
    }
    
    private function createTrimCountryList($faqIds = array(),$countryId = null ,$clusterId = null) {
        $mappedCountryResult = array();
        if (!empty($faqIds)) {
            $courseResourceMappingModel = new BaseApp_Dao_CourseResourceMapping();
            $mappedResult = $courseResourceMappingModel->getResourceCountryMappingInfo($faqIds);
            $clusterCountries = array();
            $sortedCountries = '';
            if (!empty($mappedResult)) {
                foreach($mappedResult as $mapData) {

                    $faqId = $mapData['faq_id'];
                    $clusterIds = !empty($mapData['clusterIds']) ? explode(',', $mapData['clusterIds']) : array();
                    $mapCountryNames = !empty($mapData['countryName']) ? explode(',', $mapData['countryName']) : array();
                    $mapCountryNames = array_slice($mapCountryNames, 0, 3);
                    $clusterCountries = array();
                    $countryModel = new Model_Country();
                    if (!empty($clusterIds)) {

                        $countryData = $countryModel->getCountriesByCluster($clusterIds);
                        $countryDataIds = array_keys($countryData);
                        $clusterCountries = !empty($mapData['countryIds']) ? explode(',', $mapData['countryIds']) : array();
                        $nonClusterCountry = array_diff($clusterCountries, $countryDataIds);
                        $nonClusterCountryNames = array();
                        if (!empty($nonClusterCountry)) {
                            foreach ($nonClusterCountry as $ctyId) {
                                $index = array_search($ctyId, $clusterCountries);
                                if ($index !== false) {
                                    unset($clusterCountries[$index]);
                                }
                            }
                            $nonClusterCountryNames = $countryModel->getById($nonClusterCountry);
                            $clusterCountries = array_merge($nonClusterCountryNames, $mapCountryNames);
                        }
                        if (!empty($clusterCountries))
                            $sortedCountries = implode(',', $clusterCountries);
                    }
                    else{
                        $countryName = $countryModel->getById($countryId);
                        $countryList = !empty($mapData['countryName']) ? explode(',',$mapData['countryName']) : array();
                        if($countryName && !empty($countryList)){
                            $countryName = current($countryName);
                            $index = array_search($countryName,$countryList);
                            if($index !== false){
                                unset($countryList[$index]);
                            }
                            $countryList = array_values($countryList);
                            $trimCountryList = array_slice($countryList,0,4);
                            $sortedCountries = implode(',',$trimCountryList);
                        }
                    }
                    $mappedCountryResult[$faqId] = array('name' => $mapData['countryName'], 'ids' => $mapData['countryIds'], 'clusterIds' => $mapData['clusterIds'], 'clusterName' => $mapData['clusterName'], 'sortedCountries' => $sortedCountries);
                }
            }
        }
        return $mappedCountryResult;
    }
    
}
