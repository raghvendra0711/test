<?php

/*
 * Contains the CRUD actions of Accreditors table
 * 
 */

class Admin_ModuleController extends BaseApp_Controller_Crud {

    protected $_model = 'Model_Module';
    protected $_descriptions = array(
        'list' => 'List of Existing Roles',
        'index' => 'List of Existing Role',
        'add' => 'Add New Role',
        'edit' => 'Edit Role',
        'view' => 'View Selected Role'
    );

    protected function _getForm() {
        $form = new Form_Module();
        return $form;
    }

}
