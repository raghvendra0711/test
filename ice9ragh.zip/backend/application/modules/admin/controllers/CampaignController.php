<?php
/*
 * Contains the CRUD actions of Exams table
 * 
 */

class Admin_CampaignController extends BaseApp_Controller_Crud {
    protected $_model = 'Model_Campaign';
    protected $_add = false;
    
    protected $_descriptions = array(
        'list' => 'List of Existing Campaigns',
        'index' => 'List of Existing Campaigns',
        'edit' => 'Make the required changes then click on "Save" to update the Campaigns',
        'view' => 'View Selected Campaigns',
        'add-course' => 'Add a campaign for course',
        'add-subscription' => 'Add a campaign for subscription',
        'edit-course' => 'Edit a campaign for course',
        'edit-subscription' => 'Edit a campaign for subscription'
    );

    private $_fieldsIgnore = array(
        'campaign_source',
        'Save'
    );
     
    public function addCourseAction() {        
        $request = $this->getRequest()->getPost();            
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $form = new Form_CampaignCourse();        
        if ($form === false)
            throw new Zend_Exception('_getForm not implemented');
        if ($request && $form->isValid($request)) {
            $request = $form->getValues(); 
            $splitData = $this->_handleDataAfterSubmit($request);
            $result = false;
            $request['campaignType'] = 'course';
            if($campaignId = $this->getModel()->createCampaign($request, 'course')) {
                $result = true;                   
                /*
                $trainingRelation = new Model_TrainingRelations();
                if($result && !$trainingRelation->createRelation($campaignId, 'campaign', $splitData['trainingData'])) {
                    $result = false;   
                }
                
                 * 
                 */
                $modelBanner = new Model_Banners();
                foreach($splitData['bannerData'] as $bannerData) {
                    $bannerData['linkable_id'] = $campaignId;
                    $bannerData['linkable_type'] = 'campaign';
                    if($result && !$modelBanner->saveBanner($bannerData)) {
                        $result = false;   
                    }
                }
            }
            if (!$result) {
                $this->view->message = "An error has occured while saving";
                $this->view->success = true;
            } else {                
                $this->view->message = "Data successfully added";
                $this->view->success = false;
                $form->reset();
                $module  = $this->getRequest()->getModuleName();
                $controller = $this->getRequest()->getControllerName();
                $action = $this->getRequest()->getActionName();
                if($module && $controller && $action)
                    $this->redirect($module.'/'.$controller.'/');
            }
        }
        $this->view->form = $form;
    }
    
    private function _handleEditCourse($campaignId=false) {  
        if ($this->getRequest()->isPost()) {
            $request = $this->getRequest()->getPost();       

            $form = new Form_CampaignCourse();    
            $form->removeUneditableElements();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            
            if($form->isValid($request)) {
                $data = $form->getValues();
                $splitData = $this->_handleDataAfterSubmit($data);
                $data['campaign_id'] = $this->getRequest()->getParam('id');   
                $result = false;
                if($this->getModel()->updateCampaign($data)) {
                    $result = true;                   
                    $trainingRelation = new Model_TrainingRelations();
                    if($result && !$trainingRelation->createRelation($data['campaign_id'], 'campaign', $splitData['trainingData'])) {
                        $result = false;   
                    }
                    
                    $modelBanner = new Model_Banners();
                    foreach($splitData['bannerData'] as $bannerData) {
                        $bannerData['linkable_id'] = $data['campaign_id'];
                        $bannerData['linkable_type'] = 'campaign';
                        if($result && !$modelBanner->saveBanner($bannerData)) {
                            $result = false;   
                        }
                    }
                }
                if (!$result) {
                    $this->view->message = "An error has occured while saving";
                    $this->view->success = true;
                } else {
                    // for making message page specific
                    $this->view->message = ucwords($this->getRequest()->getControllerName())." Data successfully updated";
                    $this->view->success = false;
                }
                $this->_redirect('/admin/campaign/list');
            }
        }    
        elseif($campaignId) {            
            $campaignModel = new Model_Campaign($campaignId);
            if(!$campaignModel->toArray()) {
                $this->_redirect('/admin/campaign/list');
            }
            /*
            $session = new Zend_Session_Namespace('form');
            $session->trainingTypesData = array();
            $trainingRelation = new Model_TrainingRelations();
            $trainingRelationData = $trainingRelation->getByLinkable($campaignId, 'campaign');
            foreach($trainingRelationData as $fieldName => $fieldValue) {
                $session->trainingTypesData[$fieldName] = $fieldValue;
            } 
             * 
             */      
            
            $modelBanner = new Model_Banners();
            foreach($modelBanner->getByLinkable($campaignId, 'campaign') as $bannerData) {
                switch($bannerData['banner_type']) {
                    case 'top':
                        $campaignModel->topBannerPath = $bannerData['banner_path'];
                        break;
                    case 'small':    
                        $campaignModel->smallBannerPath = $bannerData['banner_path'];
                        break;
                }
            }
            
            $campaignModel->validFrom = date('m/d/Y', $campaignModel->validFrom);
            $campaignModel->validto = date('m/d/Y', $campaignModel->validto);
            
            $campaignModel->course_id = explode(",", $campaignModel->course_id);
            $campaignModel->bundle_id = explode(",", $campaignModel->bundle_id);
            $campaignModel->cluster_id = explode(",", $campaignModel->cluster_id);
            $campaignModel->country_id = explode(",", $campaignModel->country_id);
            $campaignModel->label_id = explode(",", $campaignModel->label_id);
            $campaignModel->training_id = explode(",", $campaignModel->training_id);
        
            $this->view->postParams = $campaignModel;            
            $form = new Form_CampaignCourse();    
            $form->removeUneditableElements();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            $form->setDefaults($campaignModel->toArray());            
        }
        else {
            $this->_redirect('/admin/campaign/list');
        }
        $this->view->form = $form;
    }    
    
    public function editAction() {  
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        if($campaignId = $this->getRequest()->getParam('id')) {            
            $campaignModel = new Model_Campaign($campaignId);
            if($campaignModel->campaignType == 'course'){
                $this->_handleEditCourse($campaignId);
            }
            else {
                $this->_handleEditSubscription($campaignId);
            }
        }
        else {
            $this->_redirect('/admin/campaign/list');
        }
    }
    
    public function addSubscriptionAction() {        
        $request = $this->getRequest()->getPost();
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $form = new Form_CampaignSubscription();        
        if ($form === false)
            throw new Zend_Exception('_getForm not implemented');
        if ($request && $form->isValid($request)) {
            $request = $form->getValues(); 
            $splitData = $this->_handleDataAfterSubmit($request);
            $result = false;
            $request['campaignType'] = 'subscription';
            if($campaignId = $this->getModel()->createCampaign($request)) {
                $result = true;      
                $modelBanner = new Model_Banners();
                foreach($splitData['bannerData'] as $bannerData) {
                    $bannerData['linkable_id'] = $campaignId;
                    $bannerData['linkable_type'] = 'campaign';
                    if($result && !$modelBanner->saveBanner($bannerData)) {
                        $result = false;   
                    }
                }
            }
            if (!$result) {
                $this->view->message = "An error has occured while saving";
                $this->view->success = true;
            } else {                
                $this->view->message = "Data successfully added";
                $this->view->success = false;
                $form->reset();
                $module  = $this->getRequest()->getModuleName();
                $controller = $this->getRequest()->getControllerName();
                $action = $this->getRequest()->getActionName();
                if($module && $controller && $action)
                    $this->redirect($module.'/'.$controller.'/');
            }
        }
        $this->view->form = $form;
    }   
    
    private function _handleEditSubscription($campaignId=false) {  
                        
        if ($this->getRequest()->isPost()) {
            $request = $this->getRequest()->getPost();       

            $form = new Form_CampaignSubscription(); 
            $form->removeUneditableElements();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            
            if($form->isValid($request)) {
                $data = $form->getValues();
                $splitData = $this->_handleDataAfterSubmit($data);
                $data['campaign_id'] = $this->getRequest()->getParam('id');   
                $result = false;
                if($this->getModel()->updateCampaign($data)) {
                    $result = true;                   
                    $modelBanner = new Model_Banners();
                    foreach($splitData['bannerData'] as $bannerData) {
                        $bannerData['linkable_id'] = $data['campaign_id'];
                        $bannerData['linkable_type'] = 'campaign';
                        if($result && !$modelBanner->saveBanner($bannerData)) {
                            $result = false;   
                        }
                    }
                }
                if (!$result) {
                    $this->view->message = "An error has occured while saving";
                    $this->view->success = true;
                } else {
                    // for making message page specific
                    $this->view->message = ucwords($this->getRequest()->getControllerName())." Data successfully updated";
                    $this->view->success = false;
                }
                $this->_redirect('/admin/campaign/list');
            }
        }    
        elseif($campaignId = $this->getRequest()->getParam('id')) {            
            $campaignModel = new Model_Campaign($campaignId);
            if(!$campaignModel->toArray()) {
                $this->_redirect('/admin/campaign/list');
            }
            
            $modelBanner = new Model_Banners();
            foreach($modelBanner->getByLinkable($campaignId, 'campaign') as $bannerData) {
                switch($bannerData['banner_type']) {
                    case 'top':
                        $campaignModel->topBannerPath = $bannerData['banner_path'];
                        break;
                    case 'small':    
                        $campaignModel->smallBannerPath = $bannerData['banner_path'];
                        break;
                }
            }
            $campaignModel->validFrom = date('m/d/Y', $campaignModel->validFrom);
            $campaignModel->validto = date('m/d/Y', $campaignModel->validto);
            
            $campaignModel->cluster_id = explode(",", $campaignModel->cluster_id);
            $campaignModel->country_id = explode(",", $campaignModel->country_id);
            $campaignModel->label_id = explode(",", $campaignModel->label_id);
            
            $this->view->postParams = $campaignModel;            
            $form = new Form_CampaignSubscription();    
            $form->removeUneditableElements();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            $form->setDefaults($campaignModel->toArray());            
        }
        else {
            $this->_redirect('/admin/campaign/list');
        }
        $this->view->form = $form;
    }
    
    private function _handleDataAfterSubmit(&$request) {
       $returnData = array(
            'trainingData' => array(),
            'bannerData' => array()
       );
       foreach($this->_fieldsIgnore as $fieldName) {
            unset($request[$fieldName]);
        }
        if(isset($request['topBannerPath'])) {
            $returnData['bannerData'][] = array(
                'banner_type' => 'top',
                'banner_path' => $request['topBannerPath']
            );
            unset($request['topBannerPath']);
        }
        if(isset($request['smallBannerPath'])) {
            $returnData['bannerData'][] = array(
                'banner_type' => 'small',
                'banner_path' => $request['smallBannerPath']
            );
            unset($request['smallBannerPath']);
        }
        if(isset($request['trainingTypes'])) {
            $returnData['trainingData'] = $request['trainingTypes'];
            unset($request['trainingTypes']);
        }
        if(isset($request['validFrom'])) {
            $request['validFrom'] = strtotime($request['validFrom']);
        }
        if(isset($request['validto'])) {
            $request['validto'] = strtotime($request['validto']);
        } 
        
        if(isset($request['cluster_id']) && $request['cluster_id']) {
            $modelCountry = new Model_Country();
            $countries = $modelCountry->fetchForSelect(array("cluster_id IN (?)"=>$request['cluster_id']), array(), false);
            if(isset($request['country_id']) && $request['country_id']) {
                $request['country_id'] = array_merge($request['country_id'], array_keys($countries));
            }
            else {
                $request['country_id'] = array_keys($countries);
            }  
        }
        if(isset($request['course_id']) && is_array($request['course_id'])) {
            $request['course_id'] = implode(",", $request['course_id']);
        } 
        
        if(isset($request['label_id'])) {
            $request['label_id'] = implode(",", $request['label_id']);
        }                 
        
        if(isset($request['bundle_id'])) {
            $request['bundle_id'] = implode(",", $request['bundle_id']);
        }
        
        if(isset($request['cluster_id']) && is_array($request['cluster_id'])) {
            $request['cluster_id'] = implode(",", $request['cluster_id']);
        } 
        
        if(isset($request['country_id']) && is_array($request['country_id'])) {
            $request['country_id'] = implode(",", $request['country_id']);
        } 
        
        if(isset($request['training_id']) && is_array($request['training_id'])) {
            $request['training_id'] = implode(",", $request['training_id']);
        } 
        return $returnData;
    }
    
    public function listAction() {
        $table = $this->getModel()->getName();
        $filterForm = new Form_Filters($table);
        $requestData = array();
        $queryParamsArr = array();
        $page = '';
        if($this->getRequest()->isPost()){
            $filterForm->populate($this->getRequest()->getPost());
            $page = 1;
            $requestData = $filterForm->getValues();
            foreach($requestData as $elementName => $elementValue) {
                if(!empty($elementValue)){
                    $queryData = $filterForm->getElement($elementName)->getAttrib('data-table');
                    $queryData['searchValue'] = $elementValue;
                    $this->queryBuilder($queryData);
                    $queryParamsArr[$queryData['search_id']] = $elementValue;    
                }
            }
        }
        if(empty($page)){
            $page = $this->view->navigatorPage;
            $page = (int)$this->getRequest()->getParam('page');
        }
        $orderby = $this->getModel()->getPk() . ' DESC';
        if(empty($this->_queryParams)){
            $getData = $this->getRequest()->getQuery();
            unset($getData['page']);
            if(!empty($getData)){
                foreach ($getData as $key => $value) {
                    $queryParamsArr[$key] = $value;
                    $returnData = $filterForm->getSearchFields($key);
                    if(!empty($returnData)){
                        $returnData = $returnData[0];
                        $filterForm->getElement($returnData['searchColumnName'])->setValue($value);
                        $returnData['searchValue'] = $value;
                        $this->queryBuilder($returnData);
                    }
                }
            }
        }
        if ($page <= 1) {
            $this->view->firstpage = true;
            $page = 1;
        } else {
            $this->view->firstpage = false;
        }
        $offset = ($page - 1) * self::ROWS_PER_PAGE;    
        $this->view->page = $page;
        $limit = array(self::ROWS_PER_PAGE,$offset);
        $model = $this->getModel();
        $data = $model->fetchAll($this->_queryParams, array('order' => array($orderby), 'limit' => $limit));
        $perPageData = count($data);
        $total = $model->fetchCount($this->_queryParams);
        if (count($data) < self::ROWS_PER_PAGE) {
            $this->view->lastpage = true;
        } else {
            $this->view->lastpage = false;
        }
        $numberOfPages = ceil($total / self::ROWS_PER_PAGE);
        if($page < $numberOfPages){
            $this->view->currentPageRecord = self::ROWS_PER_PAGE * $page;    
        }else{
            $this->view->currentPageRecord = $total;    
        }
        $this->view->diffPageRecord = $this->view->currentPageRecord - self::ROWS_PER_PAGE;
        if(count($data) < self::ROWS_PER_PAGE){
            $this->view->diffPageRecord = $total - count($data);
        }
        $this->view->totalCount = $total;
        $this->view->totalPages = $numberOfPages;
        $this->view->lastPage = $numberOfPages;
        $pk = $model->getPk();
        //@TODO: Remove from controller and create an action helper.
        foreach ($data as &$row) {
            $row['Action'] = "<a href='" . $this->view->url(array('action' => 'view', 'id' => $row[$pk])) . "'>View</a> " .
                    $row['actions'] = "<a href='" . $this->view->url(array('controller' => 'changelog', 'action' => 'index', 'row' => $row[$pk], 'table' => $table)) . "'>ChangeLog</a> " .
                    "<a href='" . $this->view->url(array('action' => 'edit', 'id' => $row[$pk])) . "'>Edit</a> " .
                    "<a class='delete-crud-item' href='#' onclick='deleteConfirmShow(\"" . $this->view->url(array('action' => 'delete', 'id' => $row[$pk])) . "\");'>Delete</a> " .
                    "<a href='" . $this->view->url(array('action' => 'add-replica', 'id' => $row[$pk])) . "'>Replicate</a> ";
        }
        //================
        if(isset($data[0])){
            $original = array_keys($data[0]);
        }else{
            $original = array();
        }
        $as = ($this->_displayInDataTable);
        //new datatable   
        //need to define path in ini file after discussion
        $datatableFilePath = '../../library/BaseApp/Datatable/'.ucfirst($table).'.php';       
        if(file_exists($datatableFilePath)) {
            $dataTableClass = 'BaseApp_Datatable_'.ucfirst($table);               
        }
        else{
            $dataTableClass = 'BaseApp_Datatable_Default';                            
        }

        $dataTable = new $dataTableClass;
        $dataTable->setData($data);
        $this->view->queryParams = http_build_query($queryParamsArr);
        $this->view->form = $filterForm;
        $this->view->data = $dataTable;
        //------
        //$this->view->data = $data;
        $this->view->original = $original;
        $this->view->displayInDataTable = $as;
        $this->view->navigatorTotal = ceil($total / BACKEND_ROWS_PER_PAGE);
    }
}
