<?php
/*
 * Contains the CRUD actions of Articles table
 * 
 */

class Admin_ArticleController extends BaseApp_Controller_Crud {
    protected $_model = 'Model_Articles';
    protected $_descriptions = array(
        'list' => 'List of Existing Articles',
        'index' => 'List of Existing Articles',
        'add' => 'Add New Articles',
        'edit' => 'Make the required changes then click on "Save Articles" to update the Articles',
        'get-by-part-name' => 'For searching article by name',
        'view' => 'View Selected Articles'
    );

    public function addAction(){
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $request = $this->getRequest()->getPost();
        $this->_setRelatedArticle($request);
        $this->_setRelatedEbook($request);
        $this->_setRelatedWebinar($request);
        $form = new Form_Articles();
        $objArticle = new Model_Articles();
        if ($this->getRequest()->isPost() && $form->isValid($request)) {            
            $data = $form->getValues();           
            if(!$this->_isValid($data, $message)) {
                $this->view->message = $message;
                $this->view->success = false;
                $this->view->form = $form;
                return;
            }
            $splitData = $this->_handleDataAfterSubmit($data); 
            $data['relatedArticles'] = $splitData['relatedArticles'];
            $data['relatedEbooks'] = $splitData['relatedEbooks'];
            $data['relatedWebinars'] = $splitData['relatedWebinars'];            
            //unset($data['isInfographicUrlExists']);
            $result = false;
            if($articleId = $objArticle->addArticle($data)) {
                $result = true;
                
                $tags = new Model_Tags();
                if($result && !$tags->saveTags($articleId, 'article', $splitData['searchTags'])) {
                    $result = false;
                }                
            }
            if (!$result) {
                $controller = $this->getRequest()->getControllerName();
                $this->view->message = "An error has occured while saving";
                $this->view->success = false;
            } else {
                $cdnPurgeData = $this->getModel()->buildCdnPurgeData($articleId,$request['name'].' New Article Added');
                $objCdn = new Model_CdnPurgeLog();
                if(!empty($cdnPurgeData))
                    $objCdn->InsertCdnPurgeLog($cdnPurgeData);
                $this->view->message = "Saved SuccessFully";
                $this->view->success = true;
                $form->reset();
                $module  = $this->getRequest()->getModuleName();
                $controller = $this->getRequest()->getControllerName();
                $action = $this->getRequest()->getActionName();
                if($module && $controller && $action)
                    $this->redirect($module.'/'.$controller.'/');
            }
        }
        $this->view->form = $form;
    } // end of function courseContentAction
    
    
    public function editAction() {  
        $this->_helper->viewRenderer->setRender('common/add')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
                        
        if ($this->getRequest()->isPost()) {
            $request = $this->getRequest()->getPost();       
            $this->_setRelatedArticle($request);
            $this->_setRelatedEbook($request);
            $this->_setRelatedWebinar($request);
            $form = new Form_Articles();
            $form->removeUneditableElements();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            
            if($form->isValid($request)) {
                $data = $form->getValues();                
                if(!$this->_isValid($data, $message)) {
                    $this->view->message = $message;
                    $this->view->success = false;
                    $this->view->form = $form;
                    return;
                }
                $splitData = $this->_handleDataAfterSubmit($data);
                $data['article_id'] = $this->getRequest()->getParam('id');   
                $data['relatedArticles'] = $splitData['relatedArticles'];
                $data['relatedEbooks'] = $splitData['relatedEbooks'];
                $data['relatedWebinars'] = $splitData['relatedWebinars'];            
                //unset($data['isInfographicUrlExists']);
                if($this->getModel()->updateArticle($data)) {
                    $result = true;

                    $tags = new Model_Tags();
                    if($result && !$tags->saveTags($data['article_id'], 'article', $splitData['searchTags'])) {
                        $result = false;
                    }                    
                }
                if (!$result) {
                    $this->view->message = "An error has occured while saving";
                    $this->view->success = true;
                } else {
                    // for making message page specific
                    $cdnPurgeData = $this->getModel()->buildCdnPurgeData($data['article_id'],$data['name'].' Article Modified');
                    $objCdn = new Model_CdnPurgeLog();
                    if(!empty($cdnPurgeData))
                        $objCdn->InsertCdnPurgeLog($cdnPurgeData);
                    $this->view->message = ucwords($this->getRequest()->getControllerName())." Data successfully updated";
                    $this->view->success = false;
                }
                $this->_redirect('/admin/article/list');
            }
        }    
        elseif($articleId = $this->getRequest()->getParam('id')) {            
            $articleModel = new Model_Articles($articleId);
            if(!$articleModel->toArray()) {
                $this->_redirect('/admin/article/list');
            }            
                        
            $tags = new Model_Tags();
            if($tagData = $tags->getByLinkable($articleId, 'article')) {
                $articleModel->searchTags = $tagData['tag'];
            }
                        
            $articleModel->vertical = explode(",", $articleModel->vertical);
            $articleModel->label_id = explode(",", $articleModel->label_id);
            $articleModel->course_id = explode(",", $articleModel->course_id);
            
            if(trim($articleModel->relatedArticles)) {
                $articleModel->relatedArticles = explode(",", trim($articleModel->relatedArticles));
            }            
            else {
                $articleModel->relatedArticles = array();
            }
            if($relatedArticleData = $this->getModel()->getRelatedArticlesToShow($articleModel->relatedArticles)) {
                $articleModel->relatedArticles = $relatedArticleData;
                $relatedArticles = array(
                    'relatedArticles' => $relatedArticleData
                );
                $this->_setRelatedArticle($relatedArticles);  
            }                 
            else {
                $relatedArticles = array();
                $this->_setRelatedArticle($relatedArticles);  
            }
            
            $ebookModel = new Model_Ebooks();
            if(trim($articleModel->relatedEbooks)) {
                $articleModel->relatedEbooks = explode(",", trim($articleModel->relatedEbooks));
            }  
            else {
                $articleModel->relatedEbooks = array();
            }
            if($relatedEbookData = $ebookModel->getRelatedEbooksToShow($articleModel->relatedEbooks)) {
                $articleModel->relatedEbooks = $relatedEbookData;
                $relatedEbooks = array(
                    'relatedEbooks' => $relatedEbookData
                );
                $this->_setRelatedEbook($relatedEbooks);  
            }     
            else {
                $relatedEbooks = array();
                $this->_setRelatedEbook($relatedEbooks);  
            }
            
            $webinarModel = new Model_Webinars();
            if(trim($articleModel->relatedWebinars)) {
                $articleModel->relatedWebinars = explode(",", trim($articleModel->relatedWebinars));
            }       
            else {
                $articleModel->relatedWebinars = array();
            }
            if($relatedWebinarData = $webinarModel->getRelatedWebinarsToShow($articleModel->relatedWebinars)) {
                $articleModel->relatedWebinars = $relatedWebinarData;
                $relatedWebinars = array(
                    'relatedWebinars' => $relatedWebinarData
                );
                $this->_setRelatedWebinar($relatedWebinars);  
            }
            else {
                $relatedWebinars = array();
                $this->_setRelatedWebinar($relatedWebinars);  
            }
            /*
            if($articleModel->infographicUrl) {
                $articleModel->isInfographicUrlExists = 1;
            }
             * 
             */
            $this->view->postParams = $articleModel;
            $form = new Form_Articles();
            $form->removeUneditableElements();
            if ($form === false)
                throw new Zend_Exception('_getForm not implemented');
            
            $form->setDefaults($articleModel->toArray());            
        }
        else {
            $this->_redirect('/admin/article/list');
        }
        $this->view->form = $form;
    }
    
    private function _setRelatedArticle(&$request) {
        $session = new Zend_Session_Namespace('form'); 
        if(isset($request['relatedArticles']) && count($request['relatedArticles'])) {
            $request['relatedArticles'] = $this->_updateFirstElement($request['relatedArticles']);        
            $session->relatedArticles = array_keys($request['relatedArticles']);
            array_unshift($session->relatedArticles, '__template__');
            $session->relatedArticlesData =  $request['relatedArticles'];
        }
        else {
            $session->relatedArticles = array('__template__', 'new');
            $session->relatedArticlesData = array();
        }
    }
    
    private function _setRelatedEbook(&$request) {
        $session = new Zend_Session_Namespace('form'); 
        if(isset($request['relatedEbooks']) && count($request['relatedEbooks'])) {
            $request['relatedEbooks'] = $this->_updateFirstElement($request['relatedEbooks']);        
            $session->relatedEbooks = array_keys($request['relatedEbooks']);
            array_unshift($session->relatedEbooks, '__template__');
            $session->relatedEbooksData =  $request['relatedEbooks'];
        }
        else {
            $session->relatedEbooks = array('__template__', 'new');
            $session->relatedEbooksData = array();
        }
    }
    
    private function _setRelatedWebinar(&$request) {
        $session = new Zend_Session_Namespace('form'); 
        if(isset($request['relatedWebinars']) && count($request['relatedWebinars'])) {
            $request['relatedWebinars'] = $this->_updateFirstElement($request['relatedWebinars']);        
            $session->relatedWebinars = array_keys($request['relatedWebinars']);
            array_unshift($session->relatedWebinars, '__template__');
            $session->relatedWebinarsData =  $request['relatedWebinars'];
        }
        else {
            $session->relatedWebinars = array('__template__', 'new');
            $session->relatedWebinarsData = array();
        }
    }
    
    private function _updateFirstElement($elementArray) {
        $keys = array_keys( $elementArray );        
        $newFound = false;
        $firstKey = false;
        foreach($keys as $key) {
            if($key == '__template__') {
                continue;
            }
            if($firstKey === false) {
                $firstKey = $key;
            }            
            if($key === 'new') {
                $newFound = true;
                break;
            }
        }
        if(!$newFound) {
            $keys[ array_search( $firstKey, $keys ) ] = 'new';
            return array_combine( $keys, $elementArray );    
        }   
        return $elementArray;
    }
    
    private function _handleDataAfterSubmit(&$data) {
        $returnData = array(
            'searchTags' => false,
            'relatedArticles' => array(),
            'relatedEbooks' => array(),
            'relatedWebinars' => array()
        );
        
        if(isset($data['searchTags'])) {
            $returnData['searchTags'] = $data['searchTags'];
            unset($data['searchTags']);
        }     

        $data['course_id'] = implode(",",$data['course_id']);
        $data['vertical'] = implode(",",$data['vertical']);
        $data['label_id'] = implode(",",$data['label_id']);

        foreach($data['relatedArticles'] as $type => $relatedData) {
            if($type !== '__template__') {
                $returnData['relatedArticles'][] = $relatedData['articleId'];                
            }            
        }
        $returnData['relatedArticles'] = implode(",", $returnData['relatedArticles']);
        unset($data['relatedArticles']);
        
        foreach($data['relatedEbooks'] as $type => $relatedData) {
            if($type !== '__template__') {
                $returnData['relatedEbooks'][] = $relatedData['ebookId'];
            }            
        }
        $returnData['relatedEbooks'] = implode(",", $returnData['relatedEbooks']);
        unset($data['relatedEbooks']);
        
        foreach($data['relatedWebinars'] as $type => $relatedData) {
            if($type !== '__template__') {
                $returnData['relatedWebinars'][] = $relatedData['webinarId'];
            }            
        }
        $returnData['relatedWebinars'] = implode(",", $returnData['relatedWebinars']);
        unset($data['relatedWebinars']);
        
        /*
        if(!$data['isInfographicUrlExists']) {
            $data['infographicUrl'] = '';
        }
         * 
         */
        return $returnData;
    }
    
    public function getByPartNameAction() {
        $arg = $this->getRequest()->get('articlePart');
        $articleList = array();
        if($arg) {
            foreach($this->getModel()->getByPartName($arg) as $indexId => $data) {
                $articleList[$data['article_id']] = $data['name'];
            }
        }        
        $this->_helper->layout->disableLayout();
        $this->view->articleList =  $articleList;
    }
    
    public function listAction() {
        $this->_helper->viewRenderer->setRender('common/list')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        $table = $this->getModel()->getName();
        $filterForm = new Form_Filters($table);
        $requestData = array();
        $queryParamsArr = array();
        $page = '';
        if($this->getRequest()->isPost()){
            $filterForm->populate($this->getRequest()->getPost());
            $page = 1;
            $requestData = $filterForm->getValues();
            foreach($requestData as $elementName => $elementValue) {
                if(!empty($elementValue)){
                    $queryData = $filterForm->getElement($elementName)->getAttrib('data-table');
                    $queryData['searchValue'] = $elementValue;
                    $this->queryBuilder($queryData);
                    $queryParamsArr[$queryData['search_id']] = $elementValue;    
                }
            }
        }
        if(empty($page)){
            $page = $this->view->navigatorPage;
            $page = (int)$this->getRequest()->getParam('page');
        }
        $orderby = $this->getModel()->getPk() . ' DESC';
        if(empty($this->_queryParams)){
            $getData = $this->getRequest()->getQuery();
            unset($getData['page']);
            if(!empty($getData)){
                foreach ($getData as $key => $value) {
                    $queryParamsArr[$key] = $value;
                    $returnData = $filterForm->getSearchFields($key);
                    if(!empty($returnData)){
                        $returnData = $returnData[0];
                        $filterForm->getElement($returnData['searchColumnName'])->setValue($value);
                        $returnData['searchValue'] = $value;
                        $this->queryBuilder($returnData);
                    }
                }
            }
        }
        if ($page <= 1) {
            $this->view->firstpage = true;
            $page = 1;
        } else {
            $this->view->firstpage = false;
        }
        $offset = ($page - 1) * self::ROWS_PER_PAGE;
        $limit = array(self::ROWS_PER_PAGE,$offset);
        $this->view->page = $page;
        $model = $this->getModel();
        $data = $model->fetchAll($this->_queryParams, array('order' => array($orderby), 'limit' => $limit));
        $perPageData = count($data);
        $total = $model->fetchCount($this->_queryParams);
        if (count($data) < self::ROWS_PER_PAGE) {
            $this->view->lastpage = true;
        } else {
            $this->view->lastpage = false;
        }
        $numberOfPages = ceil($total / self::ROWS_PER_PAGE);
        if($page < $numberOfPages){
            $this->view->currentPageRecord = self::ROWS_PER_PAGE * $page;    
        }else{
            $this->view->currentPageRecord = $total;    
        }
        $this->view->diffPageRecord = $this->view->currentPageRecord - self::ROWS_PER_PAGE;
        if(count($data) < self::ROWS_PER_PAGE){
            $this->view->diffPageRecord = $total - count($data);
        }

        $this->view->totalCount = $total;
        $this->view->totalPages = $numberOfPages;
        $this->view->lastPage = $numberOfPages;
        $pk = $model->getPk();
        //@TODO: Remove from controller and create an action helper.
        foreach ($data as &$row) {
            $row['Action'] = "<a href='" . $this->view->url(array('action' => 'view', 'id' => $row[$pk])) . "'>View</a> " . "<a href='" . $this->view->url(array('controller' => 'changelog', 'action' => 'index', 'row' => $row[$pk], 'table' => $table)) . "'>ChangeLog</a> " .
                    "<a href='" . $this->view->url(array('action' => 'edit', 'id' => $row[$pk])) . "'>Edit</a> " .
                    "<a class='delete-crud-item' href='#' onclick='deleteConfirmShow(\"" . $this->view->url(array('action' => 'delete', 'id' => $row[$pk])) . "\");'>Delete</a> " .
                    "<a href='" . $this->view->url(array('action' => 'view-comments', 'id' => $row[$pk])) . "'>View Comments</a> ";
        }
        //================
        if(isset($data[0])){
            $original = array_keys($data[0]);
        }else{
            $original = array();
        }
        $as = ($this->_displayInDataTable);
        //new datatable   
        //need to define path in ini file after discussion
        $datatableFilePath = '../../library/BaseApp/Datatable/'.ucfirst($table).'.php';       
        if(file_exists($datatableFilePath)) {
            $dataTableClass = 'BaseApp_Datatable_'.ucfirst($table);               
        }
        else{
            $dataTableClass = 'BaseApp_Datatable_Default';                            
        }
        $dataTable = new $dataTableClass;
        $dataTable->setData($data);
        $this->view->queryParams = http_build_query($queryParamsArr);
        $this->view->form = $filterForm;
        $this->view->data = $dataTable;
        $this->view->original = $original;
        $this->view->displayInDataTable = $as;
        $this->view->navigatorTotal = ceil($total / BACKEND_ROWS_PER_PAGE);
    }
    
    public function viewCommentsAction() {
        
        $page = $this->view->navigatorPage;

        $model = new Model_ArticleComments();
        $orderby = $model->getPk() . ' DESC';
        $page = (int)$this->getRequest()->getParam('page');
        if ($page <= 1) {
            $this->view->firstpage = true;
            $page = 1;
        } else {
            $this->view->firstpage = false;
        }
        $offset = ($page - 1) * self::ROWS_PER_PAGE;   
        $limit = array(self::ROWS_PER_PAGE,$offset);
        $this->view->page = $page;
        
        $conds = array();
        if($this->getRequest()->getParam('id')) {
            $conds = array(
                'article_id=?' => $this->getRequest()->getParam('id')
            );
        }
        $data = $model->fetchAll($conds, array('order' => array($orderby), 'limit' => $limit));
        if (count($data) < self::ROWS_PER_PAGE) {
            $this->view->lastpage = true;
        } else {
            $this->view->lastpage = false;
        }
        $total = $model->fetchCount();
        $pk = $model->getPk();
        $table = $model->getName();
        
        foreach ($data as &$row) {
            if($row['is_approved']) {
                $row['Action'] = " Approve " .
                   "<a href='" . $this->view->url(array('action' => 'comment-disapprove', 'id' => $row[$pk])) . "'>Disapprove</a> ";
            }
            else {
                $row['Action'] = "<a href='" . $this->view->url(array('action' => 'comment-approve', 'id' => $row[$pk])) . "'>Approve</a> " .
                   " Disapprove ";
            }
            
        }
        
        if(isset($data[0])){
            $original = array_keys($data[0]);
        }else{
            $original = array();
        }
        $as = ($this->_displayInDataTable);
        //new datatable   
        //need to define path in ini file after discussion
        $datatableFilePath = '../../library/BaseApp/Datatable/'.ucfirst($table).'.php';       
        if(file_exists($datatableFilePath)) {
            $dataTableClass = 'BaseApp_Datatable_'.ucfirst($table);               
        }
        else{
            $dataTableClass = 'BaseApp_Datatable_Default';                            
        }

        $dataTable = new $dataTableClass;
        $dataTable->setData($data);

        $this->view->data = $dataTable;
        //------
        //$this->view->data = $data;
        $this->view->original = $original;
        $this->view->displayInDataTable = $as;
        $this->view->navigatorTotal = ceil($total / BACKEND_ROWS_PER_PAGE);
    }
    
    public function commentApproveAction() {
        $this->_helper->viewRenderer->setRender('common/list')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        if(!$commentId = $this->getRequest()->getParam('id')) {
            $this->_redirect('/admin/article/list');
        }
        
        $dataUpdate = array(
            'is_approved' => 1,
            'last_update_time' => time()
        );
        $commentModel = new Model_ArticleComments();
        $commentModel->setId($commentId);
        $articleId = $commentModel->article_id;
        $commentModel->setFromArray($dataUpdate)->update();
        $cdnPurgeData = $this->getModel()->buildCdnPurgeData($commentModel->article_id,$commentModel->name.' Article Modified',false);
        $objCdn = new Model_CdnPurgeLog();
        if(!empty($cdnPurgeData))
            $objCdn->InsertCdnPurgeLog($cdnPurgeData);
        $this->_redirect('/admin/article/view-comments/id/'.$articleId);
    }
    
    public function commentDisapproveAction() {
        $this->_helper->viewRenderer->setRender('common/list')->setNoController(true);
        $this->view->setScriptPath(APPLICATION_PATH . '/views/scripts');
        if(!$commentId = $this->getRequest()->getParam('id')) {
            $this->_redirect('/admin/article/list');
        }
        $dataUpdate = array(
            'is_approved' => 0,
            'last_update_time' => time()
        );
        $commentModel = new Model_ArticleComments();
        $commentModel->setId($commentId);
        $articleId = $commentModel->article_id;
        $commentModel->setFromArray($dataUpdate)->update();
        $commentModel->setFromArray($dataUpdate)->update();
        $cdnPurgeData = $this->getModel()->buildCdnPurgeData($commentModel->article_id,$commentModel->name.' Article Modified',false);
        $objCdn = new Model_CdnPurgeLog();
        if(!empty($cdnPurgeData))
            $objCdn->InsertCdnPurgeLog($cdnPurgeData);
        $this->_redirect('/admin/article/view-comments/id/'.$articleId);
    }
    
    private function _isValid($data, &$message='') {
        if(isset($data['course_id']) && count($data['course_id']) > Model_Articles::MAX_COURSES_ALLOWED_LINK) {
            $message = sprintf("Maximum %d courses allowed", Model_Articles::MAX_COURSES_ALLOWED_LINK);
            return false;
        }
        
        if(isset($data['label_id']) && count($data['label_id']) > Model_Articles::MAX_CATEGORIES_ALLOWED_LINK) {
            $message = sprintf("Maximum %d Categories allowed", Model_Articles::MAX_CATEGORIES_ALLOWED_LINK);
            return false;
        }
        return true;
    }
    
    public function publishDateAction() {
        $labelDao = new BaseApp_Dao_Labels();
        $articleDao = new BaseApp_Dao_Articles();
        $articleData = array();
        foreach($labelDao->fetchAll(array(), array('columns' => array('label_id', 'displayName'), 'order' => array('label_id'))) as $labelData) {
            $conds = array(
                'FIND_IN_SET(?, label_id)>0' => $labelData['label_id'],        
            );
            $opts = array(
                'columns' => array('article_id', 'articleName' => 'name', 'dateCreated'),
                'order' => array('dateCreated')
            );            
            foreach($articleDao->fetchAll($conds, $opts) as $articleSingle) {        
                $articleData[$labelData['displayName']][$articleSingle['article_id']] = array(
                    'articleName' => $articleSingle['articleName'],
                    'dateCreated' => $articleSingle['dateCreated']
                );
            }
        }
        $this->view->articleData = $articleData;         
    }
}