 <?php
/**
 * @desc: Backend controller class for driplead CRUD
 */
class Product_DripLeadController extends BaseApp_Controller_Crud{
    protected $_model = 'Model_Melvin_MarketingPage';
    protected $_descriptions = array(
        'list' => 'List of drip lead pages',    
        'index' => 'List of drip lead pages',
        'add' => 'Add New Drip Lead Page',
        'edit' => 'Make the required changes then click on "Save" to update',
        'view' => 'View Selected page',
        'delete' => 'to prevent unable to delete error.',
        'add-replica' => 'test'
    ); 
    
    protected function _getForm() {
        $form=new Form_Melvin_MarketingPage();
        return $form;
    }
        
    public function editAction(){
        $form = $this->_getForm();
        $request = $this->getRequest();
        $marketingPages_id = $request->getParam('id');
        if($marketingPages_id && is_numeric($marketingPages_id)){
            $marketingPageMdl = new Model_Melvin_MarketingPage($marketingPages_id);
            $formData = $marketingPageMdl->toArray();
            $bullets = unserialize($formData['bulletPoints']);
            foreach($bullets as $key=>$val){
                $formData['bullet'.intval($key+1)] = $val;
            }
            $form->setDefaults($formData);
            $form->removeOptionalValidators();
            if($request->isPost() && $form->isValid($request->getPost())){
                $data = $form->getValues();
                $data['marketingPages_id'] = $marketingPages_id;
                $files = $this->_uploadFiles($_FILES);
                $data['image'] = $files['image'];
                $data['downloadableFile'] = $files['doc'];    
                $status = $this->getModel()->prepareDripPage($data);
                if($status){
                    $this->view->message = 'Drip page updated successfully';
                    $form->reset();
                }else{
                    $this->view->errorMessage = 'Unable to update drip page';
                }
            }
        }
        $this->view->form = $form;
    }
    
    public function addReplicaAction(){
        $form = $this->_getForm();
        $request = $this->getRequest();
        $marketingPages_id = $request->getParam('id');
        $marketingPageMdl = new Model_Melvin_MarketingPage($marketingPages_id);
        $formData = $marketingPageMdl->toArray();
        $bullets = unserialize($formData['bulletPoints']);
        foreach($bullets as $key=>$val){
            $formData['bullet'.intval($key+1)] = $val;
        }
        $form->setDefaults($formData);
        if($request->isPost() && $form->isValid($request->getPost())){
            $data = $form->getValues();
            $files = $this->_uploadFiles($_FILES);
            $data['image'] = $files['image'];
            $data['downloadableFile'] = $files['doc']; 
            $status = $this->getModel()->prepareDripPage($data);
            if($status){
                $this->view->message = 'Drip page replicated successfully';
                $form->reset();
            }else{
                $this->view->errorMessage = 'Unable to create drip page';
            }
        }
        $this->view->form = $form;
    }
    
    protected function _uploadFiles($files){
        $return = array('image'=>'','doc'=>'');
        if($files['image']['tmp_name']){
            $realImage=$files['image']['name'];
            $fileName=pathinfo($realImage);
            $newFilename = 'drip_'. $fileName['filename'].'_'. uniqid().'.'.$fileName['extension'];
            $uploadPath=REL_UPLOAD_URL.'/'. Model_Melvin_MarketingPage::DRIP_PAGE_IMAGE_PATH.'/'.$newFilename;
            if(move_uploaded_file($files['image']['tmp_name'], $uploadPath)){
                $return['image'] = Model_Melvin_MarketingPage::DRIP_PAGE_IMAGE_PATH.'/'.$newFilename;
            }
        }
        
        if($files['downloadableFile']['tmp_name']){
            $realDoc=$files['downloadableFile']['name'];
            $docFile=pathinfo($realDoc);
            $newDoc = 'drip_doc_'. $docFile['filename'].'_'. uniqid().'.'.$docFile['extension'];
            $uploadDoc=REL_UPLOAD_URL.'/'. Model_Melvin_MarketingPage::DRIP_PAGE_DOC_PATH.'/'.$newDoc;
            if(move_uploaded_file($files['downloadableFile']['tmp_name'], $uploadDoc)){
                $return['doc'] = Model_Melvin_MarketingPage::DRIP_PAGE_DOC_PATH.'/'.$newDoc;
            }
        }
        
        return $return;
    }
    
    public function listAction() {
        parent::listAction();
        foreach($this->view->data as &$row){
            $row['actions'] = "<a href='" . $this->view->url(array('action' => 'view', 'id' => $row[$pk])) . "'>View</a> " .
                    "<a href='" . $this->view->url(array('action' => 'edit', 'id' => $row[$pk])) . "'>Edit</a> " .
                    "<a class='delete-crud-item' href='" . $this->view->url(array('action' => 'delete', 'id' => $row[$pk])) . "'>Delete</a> " .
                    "<a href='" . $this->view->url(array('action' => 'add-replica', 'id' => $row[$pk])) . "'>Replicate</a> ";
        }
    }
    
}