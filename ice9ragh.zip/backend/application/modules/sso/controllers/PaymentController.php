<?php

class Sso_PaymentController extends BaseApp_Controller_Crud {

    protected $_model = 'Model_Payments';
    protected $_descriptions = array(
        'list' => 'List of Existing Coupons',
        'index' => 'List of Existing Coupons',
        'add-subscription' => 'Add New Coupons for Subscription',
        'add-course' => 'Add New Coupons for Course',
        'edit' => 'Make the required changes then click on "Save Coupons" to update the Coupons',
        'view' => 'View Selected Coupons',
        'update-expiry' => 'update validto Field'
    );
    public static $_removedCourses = array ('335','11','7','659','1','18','184','26','19','20','21','22','25','29','28','30','27','220','34','105');
    public static $_removedBundles = array ('55','53','54','23');
    protected $_allowed_payment_roles = array(Model_Payments::SIMPLEX_PAYMENT, Model_Payments::SIMPLEX_PAYMENT_APPROVE);

    public function init() {
        parent::init();
        if (SIMPLEX_MAINTENANCE) {
            $this->_redirect('error/down');
            exit;
        }

        if (!isset($_COOKIE[SSO_VERIFIED_USER_COOKIE]) || !isset($_COOKIE[SSO_COOKIE_NAME])) {
            $loggedInUserData = BaseApp_Auth::getLoggedInUserData();
            $url = $_SERVER['REQUEST_URI'];
            file_put_contents(APPLICATION_PATH . '/../500_error.log', 'session time out url [' . $url . '] and data - ' . print_r($loggedInUserData, true), FILE_APPEND);
            print sprintf('You do not have permission to access %s. Kindly login via salesforce <br>', $url);
            exit;
        }
    }

    public function indexAction() {
        // assign country
        $Country = new Model_Country();
        $countries = $Country->fetchAll(['isCityActivated =?' => 1], ['order' => 'name', 'columns' => ['country_id', 'name', 'currency_code', 'currency_id', 'cluster_id', 'callingCode']]);
        $this->view->countries = $countries;
        $this->view->payment_sub_type = (new Model_Payments)->getPaymentSubTypes();

        // Fetch courses
        /*$Courses = new Model_Courses();
        $condition = array('course_available_for in (?)'=>['universal','b2c_only']);
        $courseResult = $Courses->fetchAll($condition, array(), false);
        $freeCourses = $paidCourses = array();
        foreach ($courseResult as $key => $val) {
            if ($val['can_be_free'] == 1) {
                $freeCourses[$val['course_id']] = strip_tags($val['displayName']);
            } else {
                $paidCourses[$val['course_id']] = strip_tags($val['displayName']);
            }
        }*/

        // Fetch bundles
        /*$Bundle = new Model_Bundles();
        $bundlesResult = $Bundle->fetchAll(array('bundle_available_for in (?)'=>['universal','b2c_only'], 'payment_type_id =?' => BaseApp_Dao_PaymentType::ONETIME_PAYMENT_TYPE_ID,'linkable_type = ?' => 'bundle'), array(), false);
        $bundles = array();
        foreach ($bundlesResult as $key => $val) {
            $bundles[$val['bundle_id']] = strip_tags($val['display_name']);
        }*/
        // Fetch Maters
        /*$momResult = $Bundle->fetchAll(array('bundle_available_for in (?)'=>['universal','b2c_only'], 'payment_type_id =?' => BaseApp_Dao_PaymentType::ONETIME_PAYMENT_TYPE_ID,'linkable_type = ?' => 'master_of_masters'), array(), false);
        $masters = array();
        foreach($momResult as $key => $value){
             $masters[$value['bundle_id']] = strip_tags($value['display_name']);
        }*/
        
        $userData = BaseApp_Auth::getLoggedInUserData();
        $this->view->userId = $userData['id'];
        $this->view->userEmail = $userData['email'];
        $certificationBundles = array();
        $Payment = new Model_Payments();
        $certificationCoursesIds = array();
        $certificationBundlesIds = array();
        $certificationCoursesIds =  $Payment->getCertificationCourses();
        $getClassRoomCourses = $Payment->getClassRoomCourses();
        $filteredClasses = array_unique(array_merge($certificationCoursesIds,$getClassRoomCourses), SORT_REGULAR);
        $certificationBundlesIds = $Payment->getCertificationBundle();
        $filteredProducts = array(BaseApp_Dao_ProductTypes::TYPE_ID_COURSE => $filteredClasses,  BaseApp_Dao_ProductTypes::TYPE_ID_BUNDLE => $certificationBundlesIds );
        $this->view->removedCourses  = json_encode($filteredProducts);
//        $this->view->allCourseData = json_encode([BaseApp_Dao_ProductTypes::TYPE_ID_COURSE => ['free' => $freeCourses, 'paid' => $paidCourses],
//            BaseApp_Dao_ProductTypes::TYPE_ID_BUNDLE => ['paid' => $bundles], BaseApp_Dao_ProductTypes::TYPE_ID_MOM => ['paid' => $masters]]);
        $discountRange = explode('-', FREE_COURSE_DISCOUNT_RANGE);
        $this->view->discountRange = json_encode(array('min' => $discountRange[0], 'max' => $discountRange[1]));
        $discountRangeDefault = explode('-', DEFAULT_COURSE_DISCOUNT_RANGE);
        $this->view->discountRangeDefault = json_encode(array('min' => $discountRangeDefault[0], 'max' => $discountRangeDefault[1]));
        $this->view->countryIdIndia = INDIA_COUNTRY_ID;
    }

    public function customPaymentAction() {
        //Production maintenance desclaimer, to be removed
//        $loggedInUserData = BaseApp_Auth::getLoggedInUserData();
//        $this->underMaintenance($loggedInUserData, 'msg');

        $requestParams = $this->getRequest()->getParams();
        if (empty($requestParams)) {
            echo json_encode(array('status' => false, 'msg' => 'Invalid request params.', 'responseText' => ''));
            exit;
        }

        if (!is_array($requestParams['items']) || count($requestParams['items']) == 0) {
            echo json_encode(array('status' => false, 'msg' => 'Invalid payment items.'));
            exit;
        }

        $customPayment = new BaseApp_Payments_Custom($requestParams);
        $response = $customPayment->generatePayment();
        echo json_encode($response);
        exit;
    }

    public function backendPaymentAction() {
        //Production maintenance desclaimer, to be removed
//        $loggedInUserData = BaseApp_Auth::getLoggedInUserData();
//        $this->underMaintenance($loggedInUserData, 'msg');

        // @todo Need to implement
        $requestParams = $this->getRequest()->getParams();
        if(isset($requestParams['is_zest_money'])) {
            unset($requestParams['is_zest_money']);
        }
        if(isset($requestParams['is_bajaj_finserv'])) {
            unset($requestParams['is_bajaj_finserv']);
        }
        if(isset($requestParams['is_eduvanz'])) {
            unset($requestParams['is_eduvanz']);
        }
        if(isset($requestParams['is_affirm'])) {
            unset($requestParams['is_affirm']);
        }
        if(isset($requestParams['is_liquiloan'])) {
            unset($requestParams['is_liquiloan']);
        }

        if (empty($requestParams)) {
            echo json_encode(array('status' => false, 'msg' => 'Invalid request params.', 'responseText' => ''));
            exit;
        }

        if (empty($requestParams['total_price'])) {
            echo json_encode(array('status' => false, 'msg' => 'total price should not be zero.', 'responseText' => ''));
            exit;
        }

        if (!is_array($requestParams['items']) || count($requestParams['items']) == 0) {
            echo json_encode(array('status' => false, 'msg' => 'Invalid payment items.'));
            exit;
        }

        $backendPayment = new BaseApp_Payments_Backend($requestParams);
        $response = $backendPayment->generatePayment();
        echo json_encode($response);
        exit;
    }

    public function listAction() {
        parent::listAction();
        $this->_helper->viewRenderer->setRender('list');
        $this->view->setScriptPath(APPLICATION_PATH . '/modules/' . $this->getRequest()->getModuleName() . '/views/scripts/');
        $this->_helper->viewRenderer->setNoController(false);
    }

    public function getPaymentPopupAction() {
        //Production maintenance desclaimer, to be removed
//        $loggedInUserData = BaseApp_Auth::getLoggedInUserData();
//        $this->underMaintenance($loggedInUserData, 'message');

        $requestParams = $this->getRequest()->getParams();
        $loggedInUserData = BaseApp_Auth::getLoggedInUserData();
        if (!in_array(Model_Payments::SIMPLEX_PAYMENT, $loggedInUserData['roles'])) {
            echo json_encode(array('status' => false, 'message' => "You do not have permission to upload files."));
            exit;
        }
        echo json_encode(array('status' => true, 'message' => "success"));
        exit;
    }

    public function validateDiscountAction() {
        //Production maintenance desclaimer, to be removed
//        $loggedInUserData = BaseApp_Auth::getLoggedInUserData();
//        $this->underMaintenance($loggedInUserData, 'msg');

        $response = array('status' => FALSE, 'msg' => '--');
        $this->_helper->layout()->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);
        $params = $this->getRequest()->getParams();
        $prod_params = $params['param'];
        if (!empty($prod_params)) {
            $response = Model_Payments::validateDiscount($prod_params['productType'], $prod_params['productId'], $prod_params['discountRate'], $prod_params['sellingMode']);
        }

        echo json_encode($response);
    }

    public function uploadAttachmentAction() {
        //Production maintenance desclaimer, to be removed
//        $loggedInUserData = BaseApp_Auth::getLoggedInUserData();
//        $this->underMaintenance($loggedInUserData, 'message');

        $requestParams = $this->getRequest()->getParams();
        $params = json_decode($requestParams['params'], TRUE);

        if (empty($params)) {
            echo json_encode(array('status' => false, 'message' => 'Invalid request params.', 'responseText' => ''));
            exit;
        }

        if (empty($params['paymentMethod'])) {
            echo json_encode(array('status' => false, 'message' => "payment method is empty."));
            exit;
        }

        if (empty($params['paymentId'])) {
            echo json_encode(array('status' => false, 'message' => "payment id is empty."));
            exit;
        }

        if (empty($_FILES)) {
            echo json_encode(array('status' => false, 'message' => "Please upload a valid file."));
            exit;
        }

        $loggedInUserData = BaseApp_Auth::getLoggedInUserData();
        $roleToUpload = array_intersect($loggedInUserData['roles'], BaseApp_Dao_Payments::$_upload_payment_attachment);
        if (empty($roleToUpload)) {
            echo json_encode(array('status' => false, 'message' => "You do not have permission to upload files."));
            exit;
        }

        $paymentModel = new Model_Payments();
        $fileValidationResponse = $paymentModel->validateUploadedFile($_FILES);
        if ($fileValidationResponse['status'] === false && empty($fileValidationResponse['data'])) {
            echo json_encode(array('status' => false, 'message' => $fileValidationResponse['message']));
            exit;
        }
        /**
         * Update the Payment and Order table
         */
        $uploadResult = $paymentModel->uploadFileInS3($params, $_FILES);
        //Adding log
        Model_Payments::log(array('msg' => $uploadResult, 'params' => array($params, $_FILES)));
        if ($uploadResult['status'] === true && !empty($uploadResult['data'] && !empty($uploadResult['data']['s3Url']) && !empty($uploadResult['data']['orderNo']))) {
          $contractNumber = $uploadResult['data']['contract_number'];
          unset($uploadResult['data']['contract_number']);
            $columnToUpdate = array('attachment' => $uploadResult['data']['s3Url'], 'payment_method' => $params['paymentMethod'], 'remark' => $params['remark']);
            if(!empty($contractNumber)) {
              $is_approved = 1;
              $updateWhere = array('contract_number =?' => $contractNumber);
              $contractUpdateData = array('is_approved' => $is_approved);
              $xenia = new BaseApp_Communication_Xenia();
              $updateStatus = $xenia->updateContract($contractUpdateData, $updateWhere);
              if(empty($updateStatus['status'])) {
                echo json_encode(array('status' => false, 'message' => "approval failed"));
                Model_Payments::log(array('key' => 'CUSTOM_PAYMENT_ERROR', 'msg' => $updateStatus['message'], 'data' => json_encode($contractUpdateData), 'trace' => $updateStatus['trace']));
                exit;
              }
            }
            $updateTableResult = $paymentModel->updateS3Url($params, $uploadResult['data']);
            if ($updateTableResult['status'] === true) {
                echo json_encode(array('status' => true, 'message' => "File uploaded successfully and data updated successfully"));
                exit;
            } else {
                echo json_encode(array('status' => false, 'message' => $updateTableResult['message']));
                exit;
            }
        } else {
            echo json_encode(array('status' => false, 'message' => $uploadResult['message']));
            exit;
        }
    }

    public function approvePaymentAction() {
        //Production maintenance desclaimer, to be removed
//        $loggedInUserData = BaseApp_Auth::getLoggedInUserData();
//        $this->underMaintenance($loggedInUserData, 'message');

        $requestParams = $this->getRequest()->getParams();
        if (empty($requestParams['paymentId'])) {
            echo json_encode(array('status' => false, 'message' => "payment id is empty."));
            exit;
        }

        $loggedInUserData = BaseApp_Auth::getLoggedInUserData();
        $roleToApprove = array_intersect($loggedInUserData['roles'], BaseApp_Dao_Payments::$_approve_payment);
        if (empty($roleToApprove)) {
            echo json_encode(array('status' => false, 'message' => "You do not have permission to upload files."));
            exit;
        }

        /**
         * fetch learners based on payment id
         */
        $paymentModel = new Model_Payments();
        $condition = array("payment_id IN (?) " => $requestParams['paymentId'], "is_approved = ?" => 1);
        $column = array('order_number', 'is_approved','payment_sub_type_id','contract_number');
        $paymentDetails = $paymentModel->getPaymentDetails($column, $condition);

        if ($paymentDetails[0]['is_approved'] === 2) {
            echo json_encode(array('status' => false, 'message' => "Payment is already approved."));
            exit;
        }

        if (empty($paymentDetails[0]['order_number'])) {
            echo json_encode(array('status' => false, 'message' => "Order number is missing."));
            exit;
        }

        $details = $paymentModel->assignCourse($paymentDetails[0]['order_number']);

        if (!empty($details['status']) && $details['status'] === true) {
            $assignData = !empty($details['data']) ? $details['data'] : "";
            $isPartial = !empty($paymentDetails[0]['contract_number']) ? true : false;
            if($isPartial) {
              $updateWhere = array('contract_number =?' => $paymentDetails[0]['contract_number']);
              $contractUpdateData = array('is_approved' => BaseApp_Datatable_Payments::PAYMENT_APPROVED);
              $xenia = new BaseApp_Communication_Xenia();
              $updateStatus = $xenia->updateContract($contractUpdateData, $updateWhere);
              if(empty($updateStatus['status'])) {
                echo json_encode(array('status' => false, 'message' => "approval failed"));
                Model_Payments::log(array('key' => 'CUSTOM_PAYMENT_ERROR', 'msg' => $updateStatus['message'], 'data' => json_encode($contractUpdateData), 'trace' => $updateStatus['trace']));
                exit;
              }
            }
            unset($paymentDetails[0]['contract_number']);
            $paymentsResult = $paymentModel->updateTablesForBackendPymentApproval($paymentDetails, $assignData);
            if (!empty($paymentsResult) && $paymentsResult['status'] === true) {
                echo json_encode(array('status' => true, 'message' => $paymentsResult['message']));
                exit;
            } else {
                echo json_encode(array('status' => false, 'message' => "Courses assigned successfully. Error occured while updating the data. {$paymentsResult['message']}"));
                exit;
            }
        } else {
            echo json_encode(array('status' => false, 'message' => "Some error occured while assigning course - {$details['message']}."));
            exit;
        }
    }

    public function getWorkshopsAction() {
        $this->_helper->layout()->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);
        $return = array('status' => false, 'msg' => '-', 'data' => array());
        $query = $this->getRequest()->getParams();
        $params = $query['params'];
        $trainingTypeId = $params['training_id'];
        $countryId = $params['country_id'];
        $cityId = $params['city_id'];
        $courseId = $params['course_id'];
        $fromDate = date('Y-m-d');
        $isBackendPayment = $params['is_backend_payment'];
        $active = 1;
        $notSold = 1;
        $corporate = 0;
        //Workshop Cutoff date for backend payment = current date - 2 months
        //Workshop Cutoff date for custom payment = current date
        if ($isBackendPayment == 'true') {
            $fromDate = strtotime($fromDate . ' -2 months');
            $fromDate = date('Y-m-d', $fromDate);
        }
        $paymentMdl = new Model_Payments();
        $data = $paymentMdl->getWorkshopForSelect($trainingTypeId, $countryId, $cityId, $courseId, $fromDate, $active, $notSold, $corporate);
        if (!empty($data)) {
            $return['status'] = true;
            $return['msg'] = 'Data found';
            $return['data'] = $data;
        }
        echo json_encode($return);
    }

    public function underMaintenance($loggedInUserData, $msg) {
        $allowedUsers = array('sfqa@simplilearn.net');
//        $allowedUsers = array('nagraj@simplilearn.net', 'sakshi.jain@simplilearn.net', 'shanu.singh@simplilearn.net', 'priyanka.km@simplilearn.net',
//            'manjunatha.devadiga1@simplilearn.net', 'kalyanakannan@simplilearn.net', 'soumyadeep.daptury@simplilearn.net');
        if (!empty($loggedInUserData['email']) && !in_array($loggedInUserData['email'], $allowedUsers)) {
            echo json_encode(array('status' => false, $msg => 'Page is currently under maintenance. Please try after sometime'));
            exit;
        }
    }
}
