<?php

class Sso_OrderApproveController extends BaseApp_Controller_Action {

    public function orderApproveAction() {

        $this->_helper->layout()->disableLayout();

        $return = array('status' => false, 'message' => 'Invalid Data.');
        $approval_status = $is_approved = '';
        $contractUpdateData = $revertContractData = [];
        $requestParams = $this->getRequest()->getParams();
        if (empty($requestParams) || empty($requestParams['token'])) {
            $return['message'] = 'Empty Data';
            $this->view->data = $return;
            return;
        }
        $jwtMdl = new BaseApp_Utility_JWT();
        $tokenData = (array) $jwtMdl->decode($requestParams['token'], SSO_CLIENT_SECRET, array(0 => 'HS512'));
        $mdlPayment = new Model_Payments();
        $paymentId = ($tokenData['paymentId']);

        if(!is_numeric($paymentId)){
            $return['message'] = 'Incorrect Payment Id';
            $this->view->data=$return;
            return;       
        }

        //Fectch Payment Details using payment Id
        $paymentData = $mdlPayment->fetchAll(array('payment_id =?' => $paymentId));
        $paymentData = current($paymentData);

        if(empty($paymentData)){
            $return['message'] = 'Payment Data Not Found';
            Model_Payments::log(array('key' => 'CUSTOM_PAYMENT_ERROR', 'msg' => $return['message'],
                'data' => json_encode(array('paymentId' => $paymentId)),
                'trace' => array('METHOD' => __METHOD__, 'LINE' => __LINE__)));
            $this->view->data = $return;
            return;  
        }

        //Set status and is approved based on approval status
        if($tokenData['approval'] === 'approve'){
            $approval_status = 1;
            $is_approved = 0;
        }elseif ($tokenData['approval'] === 'reject') {
            $approval_status = 2;
            $is_approved = 4;
        }

        if(!empty($paymentData['contract_number'])){
            // Make api call to fetch contract by contract number
            $xenia = new BaseApp_Communication_Xenia();
            $response = $xenia->fetchContract(array('contract_number =?' => $paymentData['contract_number']));

            if($response['status'] && !empty($response['data'])){
                $contract = current($response['data']);
                //Check for contract approval status
                if($contract['approval_status'] == 1 ){
                    $return['message'] = 'Contract already approved';
                    $this->view->data = $return;
                    return;
                }
                elseif ($contract['approval_status'] == 2) {
                    $return['message'] = 'Contract already reject';
                    $this->view->data = $return;
                    return;
                }

                //Validate Contract and Payment Approval token
                if($contract['approval_token'] !== $paymentData['approval_token']){
                    $return['message'] = "Contract's Approval token and Payment's Approval token mismatched";
                    $this->view->data = $return;
                    return;
                }

                //Validate Contract and Payment User email
                if($contract['created_user'] !== $paymentData['user_email']){
                    $return['message'] = "Contract's user email and Payment's user email mismatched";
                    $this->view->data = $return;
                    return;
                }
            } else {
                Model_Payments::log(array('key' => 'CUSTOM_PAYMENT_ERROR', 'msg' => $response['message'],
                    'params' => json_encode($response['data']),
                    'trace' => $response['trace']));
                $return['message'] = 'Contract Not Found';
                $this->view->data = $return;
                return;
            }
        }

        if ($paymentData['approval_token'] === $tokenData['token'] && $paymentData['user_email'] === $tokenData['userEmail']) {
            if ($approval_status != '') {
                //Update payment Data
                if ($paymentData['approval_status'] == 1) {
                    $return['message'] = 'Order already approved';
                    $this->view->data = $return;
                    return;
                } elseif ($paymentData['approval_status'] == 2) {
                    $return['message'] = 'Order already rejected';
                    $this->view->data = $return;
                    return;
                }

                // Update contract Data
                if(!empty($paymentData['contract_number'])){
                    //Data to be updated in contract table
                    $updateWhere = array('id =?' => $contract['id']);
                    $contractUpdateData = array('approval_status' => $approval_status, 'is_approved' => $is_approved, 'approval_date' => time());
                    $revertContractData = array('approval_status' => $contract['approval_status'], 'is_approved' => $contract['is_approved'], 'approval_date' => null);

                    $contractUpdateResponse = $xenia->updateContract($contractUpdateData, $updateWhere);                        
                    if (!$contractUpdateResponse['status']) {
                        Model_Payments::log(array('key' => 'CUSTOM_PAYMENT_ERROR', 'msg' => $contractUpdateResponse['message'], 'data' => json_encode($contractUpdateData), 'trace' => $contractUpdateResponse['trace']));
                        $return['message'] = 'Unable to update contract';
                        $this->view->data = $return;
                        return;
                    }
                }

                $data = array('payment_id' => $paymentId, 'status' => $approval_status);
                $response = $mdlPayment->updateDiscountApprovalStatus($data);

                if ($response['status'] == false) {
                    //if Payment fails and contract is updated than revert the same
                    if(!empty($paymentData['contract_number'])){
                        $contractUpdateResponse = $xenia->updateContract($revertContractData, $updateWhere);
                        if (!$contractUpdateResponse['status']) {
                            Model_Payments::log(array('key' => 'CUSTOM_PAYMENT_ERROR', 'msg' => $contractUpdateResponse['message'], 'data' => json_encode($revertContractData), 'trace' => $contractUpdateResponse['trace']));
                        }
                    }
                    $return['message'] = $response['msg'];
                    $this->view->data = $return;
                    return;
                }
                if ($response['status'] == true) {
                    if ($tokenData['approval'] === 'approve') {
                        $status = $mdlPayment->sendCustomPaymentMail($paymentData['billing_email'], $paymentData['payment_id']);
                        $status1 = $mdlPayment->sendApprovePaymentMail($paymentData['user_email'], $paymentData['payment_id'], 'approve');
                        if ($status && $status1) {
                            $this->view->data = (array('status' => true, 'message' => $response['msg']));
                            return;
                        } else {
                            $return['message'] = 'Order updated successfully, but E-Mail not send.';
                            $this->view->data = $return;
                            return;
                        }
                    } elseif ($tokenData['approval'] === 'reject') {
                        $mdlPayment->sendApprovePaymentMail($paymentData['user_email'], $paymentData['payment_id'], 'reject');
                        $this->view->data = (array('status' => true, 'message' => $response['msg']));
                        return;
                    }
                    $this->view->data = (array('status' => true, 'message' => $response['msg']));
                    return;
                }
            }
            $return['message'] = 'Incorrect approval status data';
            $this->view->data = $return;
            return;
        }
        $return['message'] = 'Incorrect approval token or user e-mail';
        $this->view->data = $return;
        return;
    }
}
