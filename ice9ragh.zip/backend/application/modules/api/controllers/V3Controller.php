<?php

/*
 * Controller contains the API methods
 *
 */

class Api_V3Controller extends BaseApp_Controller_Api {
    const PRICING_BY_CLUSTER = 1;
    const PRICING_BY_COUNTRY = 2;
    const PRICING_BY_CITY = 3;

    const WEBEX_SUCCESS = 'SUCCESS';
    const DEFAULT_ACCREDITOR_NAME = 'simpli';

    const API_SUCCESS = 200;
    const API_ERROR_ALREADY_CANCELLED = 600;
    const API_ERROR_INVALID_ORDER = 601; // Couldn't find the order
    const API_ERROR_ORDER_NOT_ACTIVE = 602; // Order status not ACTIVE
    const API_ERROR_INTERNAL_ERROR = 605; // Uknkown exception
    private $_IS_SOLD_STATUS = ['0','1'];

    protected function getAccessDays($trainingId) {
        $objAccessDays = new Model_AccessDays();
        $this->view->data = $objAccessDays->getAccessDays($trainingId);
    }

    protected function getSeedPricing($locationMode,$currencyId=false) {
        switch($locationMode){
           case self::PRICING_BY_CLUSTER:
               $obj = new Model_Clusters($currencyId);
               $this->view->data = $obj->fetchAll(array('currency_id=?'=>$currencyId), array('columns' => array('id' =>'cluster_id', 'name')));
               break;
           case self::PRICING_BY_COUNTRY:
           case self::PRICING_BY_CITY:
               $obj = new Model_Country($currencyId);
               $this->view->data = $obj->fetchAll(array('currency_id=?'=>$currencyId), array('columns'=>array('id' =>'country_id', 'name'), 'order' => array('orderNo DESC')));
               break;
           default :
               $this->view->data = array(
                   'error' => true,
                   'errorMessage' => 'Invalid location mode'
               );
        }
    }

    protected function getCityList($countryId){
        $objCity = new Model_City();
        $this->view->data = $objCity->fetchforSelect(array('country_id =?'=> intval($countryId)));
    }

    protected function getVenuesForCityCountry($countryId,$cityId){
        $venues =new Model_Venues();
        $this->view->data =$venues->fetchForSelect(array('country_id =?'=> intval($countryId),'city_id =?'=>intval($cityId)));
    }

    protected function getExamVenuesForCity($cityId){
        $examVenues = new Model_ExamVenues();
        $this->view->data = $examVenues->fetchForSelect(array('city_id =?'=>intval($cityId)));
    }

    protected function getPricingforCourse($countryId, $cityId, $courseId, $trainingId, $accessdays){
        $objAccessDays = new Model_AccessDays();
        $accessDays = $objAccessDays->fetchForSelect(array('noOfDays =?'=>$accessdays));
        $accessId = key($accessDays);

        $objPricing =new Model_Pricings();
        if($paramsData = $objPricing->getPricingData($countryId, $cityId, $courseId, $trainingId, $accessId)) {
            $this->view->data = $paramsData;
        }
    }

    protected function getTrainerForCityCountry($countryId,$cityId){
        $venues =new Model_Trainers();
        $this->view->data =$venues->fetchForSelect(array('country_id =?'=> intval($countryId),'city_id =?'=>intval($cityId)));
    }

    protected function checkPricingsExists($courseId,$trainindId){
        $priceObj = new BaseApp_Dao_Pricings();
        $pricingData = $priceObj->fetchAll(array('course_id=?' => $courseId,'training_id=?'=>$trainindId,'status=?'=>1));
        $trainindTypes = array(1=>'classroom',2=>'osl',3=>'lvc');
        if(empty($pricingData)){
            $this->view->data = array(
                'error' => false
            );
        }else{
            $this->view->data = array(
                'error' => true,
                'message' => 'Please delete the '.count($pricingData).' active pricings for '.$trainindTypes[$trainindId].' training type.'
            );  
        }
    }

    protected function showPricingPreview($pricingId,$basePrice,$maxDiscount,$courseInclusionId = false){
        $this->view->data = array(
            'error' => false
        );
        $pricingModel = new Model_Pricings();
        if(!$pricingModel->updatePricing($pricingId, $basePrice, $maxDiscount, $courseInclusionId)) {
            $this->view->data = array(
                'error' => true
            );
        } else {
            try {
                $priceObj = new BaseApp_Dao_Pricings();
                $pricingData = current($priceObj->fetchAll(array('pricing_id=?' => $pricingId)));

                $countryIds = array();
                if(!empty($pricingData['country_id'])){
                    $countryIds = array($pricingData['country_id']);
                } else {
                    $clusterId = !empty($pricingData['cluster_id'])?$pricingData['cluster_id']:null;
                    if (!empty($clusterId)) {
                        $modelCountry = new Model_Country();
                        $countryIds = $modelCountry->getCountryIdsFromCluster(array($clusterId));
                    }
                }
                if (!empty($pricingData['course_id'])) {
                    $courseId = $pricingData['course_id'];
                    $purgeObj = new Helper_PurgeUrl();
                    $extraData = array('countryIds' => $countryIds);
                    $purgeUrlData = $purgeObj->submitPurgeData('pricing_course','course',$courseId, $extraData);
                }
            } catch (Exception $e) { }
        }
    }
    protected function deletePricingPreview($pricingId){
        $this->view->data = array(
            'error' => false
        );
        $priceObj = new BaseApp_Dao_Pricings();
        $pricingData = current($priceObj->fetchAll(array('pricing_id=?' => $pricingId)));
        $countryIds = array();
        if (!empty($pricingData['country_id'])) {
            $countryIds = array($pricingData['country_id']);
        } else {
            $clusterId = !empty($pricingData['cluster_id']) ? $pricingData['cluster_id'] : null;
            if (!empty($clusterId)) {
                $modelCountry = new Model_Country();
                $countryIds = $modelCountry->getCountryIdsFromCluster(array($clusterId));
            }
        }
        $objPricing = new Model_Pricings();
        

        if(!$objPricing->deletePricing($pricingId, $message)) {
            $this->view->data = array(
                'error' => true,
                'errorMessage' => $message
            );
        } else {
            try {
                if (!empty($pricingData['course_id'])) {
                    $courseId = $pricingData['course_id'];
                    $purgeObj = new Helper_PurgeUrl();
                    $extraData = array('countryIds' => $countryIds);
                    $purgeUrlData = $purgeObj->submitPurgeData('pricing_course', 'course', $courseId, $extraData);
                }
            } catch (Exception $e) { }
        }
    }

    protected function getCoursesForLabels($labelId){
        $objCourses = new Model_Courses();
        $this->view->data = $objCourses->getbyLables($labelId);
    }
    
    protected function fetchCoursesForLabels($labelId=""){
        $objCourses = new Model_Courses();
        $newdata    = array();
        $data       = $objCourses->fetchbyLables($labelId);
        foreach($data as $key=>$val){
           $newdata[] = array("key"=>$key,"val"=>$val);
        }
        $this->view->data = json_encode($newdata);
    }
    
    protected function getBundlesForLabels($labelId){
        $objBundles = new Model_Bundles();
        $this->view->data = $objBundles->getbyLables($labelId);
    }  

    protected function getCoursesForTag($courseGrp){
        $objCourses = new Model_Courses();
        $this->view->data = $objCourses->getAllCourses($courseGrp);
    }
    protected function getBundlesForTag($bundleGrp){
        $objBundles = new Model_Bundles();
        $this->view->data = $objBundles->getAllBundles($bundleGrp);
    }    
    
    protected function getCountriesByTag($countryGrp){
        $countriesObj = new Model_Country();
        $this->view->data = $countriesObj->getCountriesByTag($countryGrp);
    } 
    protected function getCoursesByPricing(){
        $request = $this->getRequest()->getParams();
        $objCourses = new Model_Courses();
        if(empty($request['training_id'])) {
            $request['training_id'] = array(BaseApp_Dao_TrainingTypes::TYPE_ELEARNING, BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS);
        }
        $this->view->data = $objCourses->getCoursesByPricing($request);
    }

    protected function getBundlesByPricings(){
        $request = $this->getRequest()->getParams();
        $objCourses = new Model_Bundles();
        if(empty($request['training_id'])) {
            $request['training_id'] = array(BaseApp_Dao_TrainingTypes::TYPE_ELEARNING);
        }
        $this->view->data = $objCourses->getBundlesByPricings($request);
    }

    protected function AddMorePricing(){

        $request = $this->getRequest()->getPost();
        $courseID = !empty($request['course_id']) ? $request['course_id']:0 ;
        unset($request['method']);
        //validation
        if($errorData = $this->_isPricingInvalid($request)) {
            $this->view->data = $errorData;
            return true;
        }
        $priceData = $request['priceData'];
        unset($request['priceData']);
        if(isset($request['cityId'])) {
            $request['city_id'] = $request['cityId'];
            unset($request['cityId']);
        }
        unset($request['training_id']);
        unset($request['locationMode']);
        $objPricing = new Model_Pricings();
        $objCountry = new Model_Country();
        $pricingLocData = array('country'=>array(),'cluster'=>array());
        foreach($priceData as $keyTemp => $priceDataSingle) {
            foreach($request as $fieldName => $fieldValue) {
                $priceDataSingle[$fieldName] = $fieldValue;
            }
            $countryId = @$priceDataSingle['country_id'];
            if(@$priceDataSingle['city_id']) {
                $countryId = @$priceDataSingle['countryCityMode'];
            }
            $priceExistsingAll = array();
            if(@$priceDataSingle['city_id']) {
                foreach($priceDataSingle['city_id'] as $cityId) {
                    if($priceExistsing = $objPricing->getPricingByCity($countryId, $cityId,$priceDataSingle['course_id'], $priceDataSingle['training_id'], $priceDataSingle['access_day_id'])) {
                        $priceExistsingAll[] = $priceExistsing;
                    }
                }
            }
            else if($countryId){
                $pricingLocData['country'][]=$countryId; 
                if($priceExistsing = $objPricing->getPricingByCountry($countryId, $priceDataSingle['course_id'], $priceDataSingle['training_id'], $priceDataSingle['access_day_id'])) {
                    $priceExistsingAll[] = $priceExistsing;
                } else {
                    $countryData = $objCountry->getCountryDetailsById($countryId);
                    if (!empty($countryData) && !empty($countryData['cluster_id'])) {
                        $priceExCluster = current($objPricing->getPricingByCluster($countryData['cluster_id'], $priceDataSingle['course_id'], $priceDataSingle['training_id'], $priceDataSingle['access_day_id']));
                        if(!empty($priceExCluster) && $priceExCluster['free_trial'] == 1) {
                            $priceDataSingle['free_trial'] = 1;
                        }
                    }
                }
            }
            else if(@$priceDataSingle['cluster_id']){
                $pricingLocData['cluster'][]=$priceDataSingle['cluster_id'];
                if($priceExistsing = $objPricing->getPricingByCluster($priceDataSingle['cluster_id'], $priceDataSingle['course_id'], $priceDataSingle['training_id'], $priceDataSingle['access_day_id'])) {
                    $priceExistsingAll[] = $priceExistsing;
                }
            }
            else {
                $this->view->data = array(
                    'errorExistsing' => true,
                    'errorMessage' => 'no parameter found to check pricing'
                );
                return true;
            }
           
            if($priceExistsing) {
                $this->view->data = array(
                    'errorExistsing' => true,
                    'errorMessage' => 'price already exists'
                );
                return true;
            }
            $result = true;
            if(isset($priceDataSingle['city_id'])) {
                $cities = $priceDataSingle['city_id'];
                unset($priceDataSingle['city_id']);
                foreach($cities as $cityId) {
                    $priceDataSingle['city_id'] = $cityId;
                    if(!$objPricing->addPricing($priceDataSingle)) {
                        $result = false;
                    }
                }
            }
            elseif(!$objPricing->addPricing($priceDataSingle)){
                 $result = false;
            }
            $this->view->data = array(
                'errorExistsing' => false
            );
            if(!$result) {
                $this->view->data = array(
                    'errorExistsing' => true,
                    'errorMessage' => 'Failed to save price'
                );
            }
        }
        if (!empty($courseID)) {
            try {
                if (!empty($courseID)) {
                    $countryIdArray = array();
                    if (!empty($pricingLocData['country'])) {
                        $countryIdArray = $pricingLocData['country'];
                    } elseif (!empty($pricingLocData['cluster'])) {
                        $modelCountry = new Model_Country();
                        $countryIdArray = $modelCountry->getCountryIdsFromCluster($pricingLocData['cluster']);
                    }
                    $purgeObj = new Helper_PurgeUrl();
                    $extraData = array('countryIds' => $countryIdArray);
                    $purgeUrlData = $purgeObj->submitPurgeData('pricing_course', 'course', $courseID, $extraData);
                }
            } catch (Exception $e) { }
        }
    }

    private function _isPricingInvalid(&$request) {
        $isValid = true;
        $errorMessages = array();
        $pricingData = array();
        $counter = 0;
        foreach ($request as $fieldName => $fieldValue) {
            switch($fieldName) {
                case 'course_id':
                case 'training_id':
                case 'access_day_id':
                case 'locationMode':
                case 'cluster_id':
                case 'country_id':
                case 'countryCityMode':
                case 'cityId':
                case 'price':
                case 'discount':
                    if(!$fieldValue) {
                        $errorMessages[] = array(
                            'fieldName' => $fieldName,
                            'message' => 'Please fill the value'
                        );
                        $isValid = false;
                    }
            }
            if(preg_match("/daysPricing(\d+)/", $fieldName, $match)) {
                foreach($fieldValue as $priceFieldName => $priceData) {
                    foreach($priceData as $fieldSingle => $valueSingle) {
                        if(preg_match("/([^\d]+)\_(\d+)\_{$match[1]}/", $fieldSingle, $match1)) {
                            $pricingData[$counter]['access_day_id'] = $match1[2];
                            $pricingData[$counter]['training_id'] = $match[1];
                            $breakTheLoop = false;
                            switch($match1[1]) {
                                case 'price':
                                    /*
                                    if(!$valueSingle) {
                                        $errorMessages[] = array(
                                            'fieldName' => $fieldName.'-'.$priceFieldName.'-'.$fieldSingle,
                                            'message' => 'please fill the values'
                                        );
                                        $isValid = false;
                                    }
                                     *
                                     */
                                    if(!$valueSingle){
                                        $breakTheLoop = true;
                                        break;
                                    }
                                    $pricingData[$counter]['price'] = $valueSingle;
                                    break;
                                case 'discount':
                                    $pricingData[$counter]['discount'] = $valueSingle;
                                    break;
                            }
                            if($breakTheLoop) {
                                unset($pricingData[$counter]);
                                break;
                            }
                        }
                        else {
                            $errorMessages[] = array(
                                'fieldName' => $fieldName,
                                'message' => 'some problem with pricing'
                            );
                            $isValid = false;
                        }
                    }
                    $counter++;
                }
                unset($request[$fieldName]);
            }
        }
        if(!$pricingData) {
            return array(
                'errorExistsing' => true,
                'errorMessage' => 'Please enter atleast one price'
            );
            $isValid = false;
        }
        $request['priceData'] = $pricingData;
        if($isValid) {
            return false;
        }
        return array(
            'error' => true,
            'errorMessages' => $errorMessages
        );
    }

    protected function getUploadForm(){
        $form = new Form_UploadForm();
        $form->getElement('sourceform')->setValue($this->getRequest()->getParam('sourceForm'));
        $form->getElement('form_name')->setValue($this->getRequest()->getParam('form_name'));
        $this->view->uploadForm = $form;
        $this->view->data = $this->view->render('common/upload-form.phtml');
    }

    protected function uploadFileAction(){
        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);
        $form = new Form_UploadForm();
        // read config file for form parameters
        $baseObj = new BaseApp_Utility_ReadFileConfig();
        $fileSetting = $baseObj->getFormInputSettings('Form_'.$this->getRequest()->getParam('form_name'));
        if($_FILES){
            $fileDimension = '';
            $size = getimagesize($_FILES['uploadfile']['tmp_name']);
            $finalFileDim = $fileSetting['width'].'X'.$fileSetting['height'];
            if($size[0] && $size[1]){
               $fileDimension = $size[0].'X'.$size[1];
               if($fileSetting['height'] == 0)
                   $fileDimension = $size[0].'X0';
            }
            $fileSizeInKb = ($_FILES['uploadfile']['size']/1024);
            $fileExt = explode(".", strtolower($_FILES['uploadfile']['name']));
            if(($fileSizeInKb <= $fileSetting['filesize']) && $finalFileDim == $fileDimension){
                $extenistonArray = explode(',',$fileSetting['type']);
                if(in_array($fileExt[count($fileExt)-1], $extenistonArray)){
                    $newFileName = $fileDimension.'-'.uniqid().$_FILES['uploadfile']['name'];
                    $newPath = REL_UPLOAD_URL.'/'.Form_UploadForm::RESOURCE_PHOTO_PATH.'/'.$fileSetting['folderName'].'/'.$newFileName;
                    if(move_uploaded_file($_FILES['uploadfile']['tmp_name'], $newPath)){
                        $model = new Model_UploadImages();
                        $data['image_name'] = Form_UploadForm::RESOURCE_PHOTO_PATH.'/'.$fileSetting['folderName'].'/'.$newFileName;
                        $data['addedDate'] = date('Y-m-d');
                        $model->setFromArray($data)->save();
                        $this->redirect($this->getRequest()->getParam('sourceform'));
                    }
                }
                else{
                    $this->redirect($this->getRequest()->getParam('sourceform').'#ext-error');
                }
            }
            $this->redirect($this->getRequest()->getParam('sourceform').'#size-error');
        }
    } // end of function uploadFileAction

    public function getCoursesBylabel($labelId) {
        $labelModel = new Model_Labels();
        $labelData = $labelModel->getById($labelId);
        $courseModel = new Model_Courses();
        $coursesAll = $courseModel->fetchForSelect(array('FIND_IN_SET(?, label_id)>0'=>$labelId,'hideFromSearch=?'=>0));
        $bundleModel = new Model_Bundles();
        $bundlesAll = $bundleModel->fetchForSelect(array('FIND_IN_SET(?, label_id)>0'=>$labelId,'hideFromSearch=?'=>0));
        $this->view->coursesAll = $coursesAll;
        $this->view->popularCourses = array();
        if($labelData['popularCourses']) {
            $courseIdsPopular = explode(",", trim($labelData['popularCourses']));
            foreach($courseIdsPopular as $courseId) {
                if(preg_match("/b(\d+)/", $courseId, $match)) {
                    if(isset($bundlesAll[$match[1]])) {
                        $this->view->popularCourses[$courseId] = $bundlesAll[$match[1]];
                        unset($bundlesAll[$match[1]]);
                    }
                }
                elseif(isset($coursesAll[$courseId])) {
                    $this->view->popularCourses[$courseId] = $coursesAll[$courseId];
                    unset($coursesAll[$courseId]);
                }
            }
            if($coursesAll || $bundlesAll) {
                $this->view->popularCourses['-'] = '-';
            }
            foreach($coursesAll as $courseId => $name) {
                $this->view->popularCourses[$courseId] = $name;
            }
            foreach($bundlesAll as $bundleId => $bundleName) {
                $this->view->popularCourses["b{$bundleId}"] = $bundleName;
            }
        }
        else {
            $this->view->popularCourses = $coursesAll;
            foreach($bundlesAll as $bundleId => $bundleName) {
                $this->view->popularCourses["b{$bundleId}"] = $bundleName;
            }
        }

        $this->view->popularCoursesHidden = $labelData['popularCourses'];

        $this->view->recentCourses = array();
        if($labelData['recentCourses']) {
            $courseIdsRecent = explode(",", $labelData['recentCourses']);
            if($courseIdsRecent) {
                $this->view->recentCourses = $courseModel->fetchForSelect(array('course_id IN (?)'=>$courseIdsRecent));
            }
            $this->view->recentCoursesHidden = $labelData['recentCourses'];

        }

        $this->view->labelOffers = array();
        $offerModel = new Model_Campaign();
        if($labelData['offers']) {
            $offers =  explode(",", $labelData['offers']);
            $offerData = $offerModel->fetchAll(array('campaign_id IN (?)'=>$offers), array('columns' => array('campaign_id', 'displayName')), false);
            foreach($offerData as $offerSingle) {
                $this->view->labelOffers[$offerSingle['campaign_id']] = $offerSingle['displayName'];
            }
            unset($offerData);
            $this->view->labelOffersHidden = $labelData['offers'];
        }
        $this->view->labelOffersAll = $offerModel->fetchAll(array('FIND_IN_SET(?, label_id)>0'=>$labelId), array('columns' => array('campaign_id', 'displayName')), false);

        $this->view->data = $this->view->render('common/label-flyout.phtml');
    }

    public function getDataByElement($element) {
        $modelRecommend = new Model_Recommendations();
        $this->view->data = $modelRecommend->getByElement($element);
    }

    public function getSeoElementsByType($elementType) {
        $modelSeo = new Model_Seo();
        $this->view->data = $modelSeo->getElementsByType($elementType);
    }

    /* Api functions */

    protected function getCoursesDisplayWise(){
        $objCourses = new Model_Courses();
        $return = $objCourses->getDispalyWiseSortedCourse();
        $this->view->data = $return;
    }

    protected function getCoursePageUrlByCourseId(){
        $courseId = $this->getRequest()->getParam('courseId');
        if(is_numeric($courseId) && $courseId){
            $seoMd = new Model_Seo();
            $conds = array(
                'controller=?' => Model_Courses::SEO_DEFAULT_CONTROLLER,
                'action=?' => Model_Courses::SEO_DEFAULT_ACTION,
                'linkable_id=?' => $courseId,
                'linkable_type=?' => 'course'
            );
            $seoData = current($seoMd->fetchAll($conds, array(), false));
            if($seoData && $seoData['url']){
                $return = array('status'=>'Success','url'=>FRONTEND_URL.'/'.$seoData['url'],'msg'=>'');
            }else{
                $return = array('status'=>'False','url'=>'','msg'=>'URL not defind for the requested course!');
            }
        }else{
            $return = array('status'=>'False','url'=>'Invalid course passed to retrieve the URL');
        }
        $this->view->data = $return;
    }

    public function getTrainingType() {
        $trainingTypeModel = new Model_TrainingTypes();
        $trainingType = $trainingTypeModel->fetchForSelect();
        $this->view->data =  $trainingType;
    }

    public function getAccreditorsById(){
         $accreditorIds = $this->getRequest()->getParam('accreditorIds');
         $accreditorMdl = new Model_Accreditors();
         $return = $accreditorMdl->fetchAll(array('accreditor_id IN(?)'=>$accreditorIds));
         $this->view->data = $return;
    }

    protected function getAccreditorsByCourseId(){
        $courseId = $this->getRequest()->getParam('courseId');
        $data=array();
        if($courseId && is_numeric($courseId)){
            $courseObj = new Model_Courses($courseId);
            $courseData = $courseObj->toArray();
            if(count($courseData)>0){
                    $accredator = new Model_Accreditors($courseData['accreditor_id']);
                    if(count($accredator->toArray())>0){
                        $data[$courseData['accreditor_id']] = array('name'=>$accredator->name,
                                                              'imagePath'=>$accredator->imagePath,
                                                              'details'=>$accredator->details,
                                                              'link'=>$accredator->link
                                                             );
                        $this->view->data = array('status'=>'Success','msg'=>'','data'=>$data);
                    }else{
                        $this->view->data = array('status'=>'Failed','msg'=>'No accredator found','data'=>$data);
                    }
            }else
                $this->view->data = array('status'=>'Failed','msg'=>'No accredator found','data'=>$data);
        }else
            $this->view->data = array('status'=>'Failed','msg'=>'Parameters not passed properly','data'=>$data);
    }

     public function getTrialCoursesInfo(){
         $courseIdArray = $this->getRequest()->getParam('courseIds');
         $fetchDisableFlag = false;
         $disableFlag = $this->getRequest()->getParam('disable');
         if(isset($disableFlag) && !empty($disableFlag))
            $fetchDisableFlag = true;
         $courseModel = new Model_Courses();
         if($fetchDisableFlag)
            $courseModel->setFetchDisabled(true);
         $courses = $courseModel->fetchAll(array('course_id in(?)'=>$courseIdArray));
         foreach($courses as $courseIndex => $courseData) {
             $courses[$courseIndex]['eLearning_id'] = $courseData['primary_eLearning_id'];
             $courseData['FreeELearningId'] = $courseModel->getFreeElearningsFromFreeCourses($courseData['freeCourses']);
             if($courseData['FreeELearningId']) {
                $courses[$courseIndex]['FreeELearningId'] = implode(",", $courseData['FreeELearningId']);
             }
         }

         $this->view->data = $courses;
     }

     public function getLabelInfo(){
         $idArray = $this->getRequest()->getParam('labelIds');
         $productId = $this->getRequest()->getParam('productId');
         $disableFlag = $this->getRequest()->getParam('disable');
         $labelModel = new Model_Labels();
         $labels = array();
         if (!empty($productId) && $productId == BaseApp_Dao_ProductTypes::TYPE_ID_CATEGORY && !empty($idArray)) {
            $labels = $labelModel->getLabelByIds($idArray);
         }
         $this->view->data = $labels;
     }


     public function getCityInfo(){
         $city = $this->getRequest()->getParam('city');
         $cityArray = array();
         $country_id = $this->getRequest()->getParam('country_id');
         $cityModel = new Model_City();
         $countryModel = new Model_Country();
         if($city && $country_id){
            $cityData = $cityModel->fetchAll(array('name=?'=>$city,'country_id=?'=>$country_id));
            $countryData = $countryModel->fetchAll(array('country_id=?'=>$country_id));
            if($cityData && $countryData){
                $cityArray['city_id'] = $cityData[0]['city_id'];
                $cityArray['country_id'] = $cityData[0]['country_id'];
                $cityArray['city_name'] = $cityData[0]['name'];
                $cityArray['country_name'] = $countryData[0]['name'];
            }else{
                 $db = Zend_Db_Table::getDefaultAdapter();
                 $sql=$db->select()
                           ->from('city',array('city.city_id','city.name as city_name','country.name as country_name'))
                           ->join('country','city.city_id=country.defaultCity_id')
                           ->where('country.country_id=?',$country_id);
                $record= $db->fetchAll($sql);
                $cityArray['city_id'] = $record[0]['city_id'];
                $cityArray['country_id'] = $record[0]['country_id'];
                $cityArray['city_name'] = $record[0]['city_name'];
                $cityArray['country_name'] = $record[0]['country_name'];
            }
        }
        else{
                $baseAppLocator = BaseApp_Ice9Locator::getInstance();
                $cityArray['city_id'] = $baseAppLocator->getData('city_id');
                $cityArray['country_id'] = $baseAppLocator->getData('country_id');
                $cityArray['city_name'] = $baseAppLocator->getData('name');
                $cityArray['country_name'] = $baseAppLocator->getData('name');
        }
        $this->view->data = $cityArray;
     }

     public function getAllAccreditors() {
        $accreditorsModel = new Model_Accreditors();
        $accreditors = $accreditorsModel->fetchForSelect();
        $this->view->data =  $accreditors;
    }

    public function getAllCategories() {
        $options = '' ;
        if($this->getRequest()->getParam('orderField')){
            $options= array('order'=>$this->getRequest()->getParam('orderField')." ASC");
        }
        $labelModel = new Model_Labels();
        $labels = $labelModel->fetchForSelect(null,false,$options);
        $this->view->data =  $labels;
    }

    protected function fetchCourseByTrainingTypeId(){
      $trainingTypeId = $this->getRequest()->getParam('trainingType_id');
      $courseId = $this->getRequest()->getParam('course_id');
      $approved=($this->getRequest()->getParam('approved'))?true:false;
      $data = array();
      if(is_numeric($trainingTypeId) && $trainingTypeId){
          $courseModel = new Model_Courses();
          $data = $courseModel->getCourseByTrainingTypeId($trainingTypeId,$courseId,$approved);
      }
      $this->view->data = $data;
    }

    public function getCourseById(){
        $courseId = $this->getRequest()->getParam('course_id');
        $fetchDisableFlag = false;
        $disableFlag = $this->getRequest()->getParam('disable');
        if(isset($disableFlag) && !empty($disableFlag))
            $fetchDisableFlag = true;
        $return = array();
        if(is_numeric($courseId) && $courseId>0){
            $objCourse = new Model_Courses();
            if($fetchDisableFlag)
                $objCourse->setFetchDisabled(true);
            $courseData = current($objCourse->fetchAll(array('course_id=?'=>$courseId)));
            if(!empty($courseData)){
                $courseData['eLearning_id'] = $courseData['primary_eLearning_id'];
                $courseData['FreeELearningId'] = $objCourse->getFreeElearningsFromFreeCourses($courseData['freeCourses']);
                if($courseData['FreeELearningId']) {
                    $courseData['FreeELearningId'] = implode(",", $courseData['FreeELearningId']);
                }
                else {
                    $courseData['FreeELearningId'] = '';
                }
                $return =  $courseData;
            }
        }
        $this->view->data = $return;
    }

    public function getCourseInfoById(){
        $courseId = $this->getRequest()->getParam('course_id');
        $fetchDisableFlag = false;
        $disableFlag = $this->getRequest()->getParam('disable');
        if(isset($disableFlag) && !empty($disableFlag))
            $fetchDisableFlag = true;
        $return = array();
        if(is_numeric($courseId) && $courseId>0){
            $objCourse = new Model_Courses();
            if($fetchDisableFlag)
                $objCourse->setFetchDisabled(true);
            $courseData = current($objCourse->fetchAll(array('course_id=?'=>$courseId)));
            $courseInfo = array();
            if(!empty($courseData)){
                $courseData['eLearning_id'] = $courseData['primary_eLearning_id'];
                $courseInfo[$courseData['primary_eLearning_id']] = array(
                    'cid' => $courseId,
                    'eid' => $courseData['primary_eLearning_id'],
                    'isFree' => 0
                );
                if(isset($courseData['freeCourses']) && !empty($courseData['freeCourses'])){
                    $freeCourses = explode(",", trim($courseData['freeCourses']));
                    if(!empty($freeCourses)) {
                        foreach ($freeCourses as $keyFC => $valueFC) {
                            $freeElearnings = $objCourse->getFreeElearningsFromFreeCourses($valueFC);
                            if(!empty($freeElearnings)) {
                                $freeElearnings = implode(",", $freeElearnings);
                                $courseInfo[$freeElearnings] = array(
                                    'cid' => $valueFC,
                                    'eid' => $freeElearnings,
                                    'isFree' => 1,
                                    'primary_cid' => $courseId
                                );
                            }
                        }
                    }
               }
                $return['course_info'] =  $courseInfo;
            }
        }
        $this->view->data = $return;
    }

    protected function getCourseRating($courseId='') {
        if($courseId=='All'){
            $courseModel= new Model_Courses();
            $courseData = $courseModel->fetchAll(array(), array(), false);
            foreach($courseData as $value){
                    $courseArray['course_id_'.$value['course_id'] ] = $value['rating'];
            }
            $data=array('status'=>'success','rating'=>$courseArray);
        }else{
            $courseData= new Model_Courses($courseId);
            $data=array('status'=>'success','rating'=>$courseData->rating);
        }
        $this->view->data = $data;
    }

    protected function getCoursesPackageInfo(){
         $courseIdArray = $this->getRequest()->getParam('courseIds');
         $country_id = $this->getRequest()->getParam('country_id');
         $courseModel = new Model_Courses();
         $courses = $courseModel->getCourseWithPackage($courseIdArray,$country_id);
         $this->view->data = $courses;
     }

     protected function getCoursesForSelect($labelId='') {
        $courseModel = new Model_Courses();
        if($labelId){
            $courses = $courseModel->fetchForSelect(array('primary_label_id=?'=>$labelId));
        }else
            $courses = $courseModel->fetchForSelect();
        $data=array('status'=>'success','courses'=>$courses);
        $this->view->data = $data;
    }

    protected function getCourseForCertificate(){
         $courseMdl = new Model_Courses();
         $courses = $courseMdl->fetchAll();
         $return = array();
         foreach($courses as $course){
                 $return[$course['course_id']] = $course['displayName'];
         }
         $data=array('status'=>'success','courses'=>$return);
         $this->view->data = $data;
    }

    protected function fetchOrderDetails(){
      $orderIds = $this->getRequest()->getParam('orderIds');
      $orderModel = new BaseApp_Dao_Melvin_Order();
      $data = $orderModel->getOrderDetailsByOrderIds($orderIds);
      $this->view->data = $data;
    }

    protected function freeTrialInfo(){
      $data = $this->getRequest()->getParams();
      $orderModel = new BaseApp_Dao_Melvin_Order();
      $data = $orderModel->getFTOrderDetailsByOrderNumber($data);
      $this->view->data = $data;
    }

    protected function fetchOrderDetailsByUserId(){
      $userId = $this->getRequest()->getParam('userId');
      if(!$userId){
              $data = array();
      }else{
          $orderModel = new BaseApp_Dao_Melvin_Order();
          $data = $orderModel->getOrderDetailsByOrderIds(array(),$userId);
      }
      $this->view->data = $data;
    }

    protected function getOrderIdByUserCourseId() {
        $userId = trim($this->getRequest()->getParam('userId'));
        $eLearningId = trim($this->getRequest()->getParam('courseId'));
        if(!$userId || !$eLearningId) {
            $this->view->data = array();
            return true;
        }
        $conds = array(
            'primary_eLearning_id = ?' => $eLearningId
        );
        $courseMd = new Model_Courses();
        $courseIds = array();
        foreach($courseMd->fetchAll($conds, array('columns' => array('course_id')), false) as $course) {
            $courseIds[] = $course['course_id'];
        }
        if(!$courseIds) {
            $this->view->data = array();
            return true;
        }
        $orderModel = new BaseApp_Dao_Melvin_Order();
        if(!$this->view->data = $orderModel->getOrderIdsByUserCourse($userId, $courseIds)) {
            $this->view->data = array();
        }
    }

    protected function getOrdersByUserId(){
        $email = $this->getRequest()->getParam('email');
        if($email && $email!=''){
            $orderObj = new BaseApp_Dao_Melvin_Order();
            $orders = $orderObj->getOrdersByUserId($email);
            if($orders){
                $orderNos = array_column($orders,'orderNumber');
                $this->view->data = array('status'=>'Success','msg'=>$orderNos);
            }else
                $this->view->data = array('status'=>'Failed','msg'=>'No orders found');
        }else
            $this->view->data = array('status'=>'Failed','msg'=>'Parameters not passed properly');
    }

    protected function getInvoiceOrderDetailsByOrderId(){
        $orderId = $this->getRequest()->getParam('orderId');
        $order = new BaseApp_Dao_Melvin_Order();
        $data = $order->getOrderDetailsForInvoice($orderId);
        $this->view->data= $data;
    }

    protected function generateTokenDeletedOrder(){
      $return = array();
      $orders=$this->getRequest()->getParam('orders');
      if(is_array($orders) && count($orders)>0){
        $orderModel = new BaseApp_Dao_Melvin_Order();
        $status = $orderModel->prepareCreditOrderforDeletedTokens($orders);
        if(isset($status['failed'])){
            $msg = 'Failed to create the orders for deleted tokens';
        }else if(isset($status['failed'])){
            $msg = 'Successfully created orders for deleted tokens and amount credited to respectice ATP account';
        }else{
            $msg='';
        }
        $return = array('status'=>'Success','data'=>$status,'msg'=>$msg);
      }else{
        $return = array('status'=>'Failed','data'=>array(),'msg'=>'Invalid parameter passed! Array expected');
      }
      $this->view->data = $return;
   }


    protected function getAllExpiringAgreements(){
        $req = $this->getRequest();
        if($req->getParam('days')){
            $affAgreement = new BaseApp_Dao_Melvin_AffiliateAgreement();
            $agreements = $affAgreement->getAllExpiringAgreements($req->getParam('days'));
            if($agreements && count($agreements)>0){
                $return = array('status'=>'Success','data'=>$agreements);
            }else{
                $return = array('status'=>'Success','data'=>array());
            }
        }else
            $return = array('status'=>'Failed','data'=>'params not passed properly');

        $this->view->data = $return;
    }


    protected function getFinsaleUserAttendStatus(){
        $orderNo = $this->getRequest()->getParam('orderNo');
        $email = $this->getRequest()->getParam('email');
        $paymentReconcile = new BaseApp_Dao_Melvin_PaymentReconcile();
        $data = $paymentReconcile->getStatusByOrderEmail($orderNo,$email);
        $isAttended = false;
        if(count($data)>0 && $data['status']==BaseApp_Dao_Melvin_FinanceTransactionStatus:: $_finSaleStatus['ATTENDED']){
            $isAttended = true;
        }
        $this->view->data = array('orderNumber'=>$orderNo,'email'=>$email,'isAttended'=>$isAttended);
    }

    /* Atp Api's */
    public function getAtpPackagesForSelect(){
        $affiliateId = $this->getRequest()->getParam('affiliateId');
        try{
            if($affiliateId){
                $affiliatePriceObj = new BaseApp_Dao_Melvin_AffiliatePrice();
                $packages = $affiliatePriceObj->getPackageListFromAffiliateId($affiliateId);
                $this->view->data= array('status'=>'Success', 'msg'=>$packages);
            }else
                $this->view->data = array('status'=>'Failed', 'msg'=>'invalid affilaite id passed');
        }catch(Exception $e){
            $this->view->data = array('status'=>'Failed', 'msg'=>'some error occoured  ');
        }
    }

    public function getAtpAccessDaysForSelect(){
        $req = $this->getRequest();
        if($this->getRequest()->getParam('affiliateId') && $this->getRequest()->getParam('courseId')){
            $affiliateId = $this->getRequest()->getParam('affiliateId');
            $packageId = $this->getRequest()->getParam('courseId');
            $affiliatePriceObj = new BaseApp_Dao_Melvin_AffiliatePrice();
            $accessDays = $affiliatePriceObj->getAccessDaysFromPackageId($affiliateId,$packageId);
            $this->view->data= array('status'=>'Success', 'msg'=>$accessDays);
    }else
        $this->view->data = array('status'=>'Failed', 'msg'=>'parameters not passed properly');

    }

    protected function getAffiliateClosingBalance(){
        $affiliate_id = $this->getRequest()->getParam('affiliateId');
        if($affiliate_id && is_numeric($affiliate_id)){
            $model = new BaseApp_Dao_Melvin_OrderAdjustment();
            $amount = $model->getOrderAdjustedAmount($affiliate_id);
            if($amount['status'] == 'Success'){
                $this->view->data = array('status'=>'Success', 'data'=>$amount['balanceAmount'],'currency'=>$amount['currency'],'registrationAmount'=>$amount['registrationAmount']);
            }else{
                $this->view->data = array('status'=>'Failed','data'=>$amount['status'],'currency'=>$amount['currency']);
            }
        }else{
            $this->view->data = array('status'=>'Failed','data'=>'Invalid affiliateId passed');
        }
    }

    protected function validateAndGetAtpPriceDetails(){
        $res = $this->getRequest();
        if($res){
            $atpPrice = new BaseApp_Dao_Melvin_AffiliatePrice();
            $result = $atpPrice->getAffiliatePriceDetails($res);
            $this->view->data = $result;
        }else{
            $this->view->data = array('status'=>'Failed', 'msg'=>'no data passed');
        }
    }

    protected function createAdjustmentOrder(){
       $data = $this->getRequest()->getParam('orderData');
       try{
            if($data){
                $orderAdjustment = new BaseApp_Dao_Melvin_OrderAdjustment();
                $response = $orderAdjustment->AddNewAdjustment($data);
            }else{
                $response = array('status'=>'Failed','msg'=>'Empty payment data can not be adjusted');
            }
       }catch (Exception $e){
           $response = array('status'=>'Failed','msg'=>'Some error occurs'.$e->getMessage());
       }
       $this->view->data = $response;
    }

    protected function getCourseCertificateCode(){
        $courseIds = $this->getRequest()->getParam('courseIds');
        $courseModel = new Model_Courses();
        $return = array();
        $data = $courseModel->fetchAll(array('course_id IN(?)'=>$courseIds), array(), false);
        foreach($data as $course){
            $return[$course['course_id']] = $course['certificateCode'];
        }
        $this->view->data = $return;
    }

    public function getCategoriesHavingChapterVideos(){
        $categoryModel = new BaseApp_Dao_Labels();
        $this->view->data =  $categoryModel->getCategoriesHavingChapterVideo();
    }

    protected function getChapterVideo($course_id='All') {
         $course=new Model_Courses();
         if(isset($course_id) && is_numeric($course_id) && $course_id!=null){
            $courses=$course->fetchAll(array('course_id=?'=>$course_id), array(), false);
         }else{
            $courses=$course->fetchAll(array(), array(), false);
         }
         $video=new Model_Videos();
         $modelImage = new Model_Images();
         $totalVideos = 0;
         $finalresultArray['data'] = array();
         foreach($courses as $CourseData){
             $resultArray=array();
             $Allvideo=$video->fetchAll(array('course_id=?'=>$CourseData['course_id'],'name <> ?'=> 'about_course'),array(),false);
             $courseImageUrl = '';
             $courseImage = $modelImage->fetchAll(array('linkable_id=?'=>$CourseData['course_id'],'linkable_type=?'=>'course','name =?'=> 'image_home_page'));
             if(!empty($courseImage)){
                // taking the 1st certificatge description
                $courseImageUrl = $courseImage[0]['imagePath'];
             }
             if(count($Allvideo)>0)
             {
                $resultArray['course_id']=$CourseData['course_id'];
                $resultArray['label_id']=$CourseData['primary_label_id'];
                $resultArray['name']=$CourseData['name'];
                $resultArray['displayName']=$CourseData['displayName'];
                $resultArray['courseImageUrl']=$courseImageUrl;
                $resultArray['aboutCertification']=$CourseData['aboutCertification'];
                $resultArray['bestSuited']=NULL;//$CourseData['bestSuited'];
                $resultArray['introContentList']=NULL; //$CourseData['introContentList'];
                $resultArray['looperProgramId']=NULL;//$CourseData['looperProgramId'];
                $resultArray['averageRating']=NULL;//$CourseData['averageRating'];
                $resultArray['manualRating']=NULL;//$CourseData['manualRating'];
                $resultArray['actualRatingOn']=$CourseData['rating'];
                $resultArray['courseImageClass']=NULL;

                $videoIdsAll = array();
                $videoUrls = array();
                foreach($Allvideo as $value){
                    $videoIdsAll[] = $value['video_id'];
                }
                $seoMd = new Model_Seo();
                $conds = array(
                    'controller=?' => Model_Videos::SEO_DEFAULT_CONTROLLER,
                    'action=?' => Model_Videos::SEO_DEFAULT_ACTION,
                    'linkable_id IN (?)' => $videoIdsAll,
                    'linkable_type=?' => 'video'
                );
                $seoData = $seoMd->fetchAll($conds, array(), false);
                foreach($seoData as $seoDataSingle) {
                    $videoUrls[$seoDataSingle['linkable_id']]['url'] = $seoDataSingle['url'];
                    $videoUrls[$seoDataSingle['linkable_id']]['thumb_image'] = $seoDataSingle['thumb_image'];
                }
                unset($seoData);
                unset($videoIdsAll);

                foreach($Allvideo as &$value){
                    $videoArray['chapterVideo_id']=$value['video_id'];
                    $videoArray['course_id']=$value['course_id'];
                    $videoArray['duration']=$value['duration'];
                    $videoArray['chapterNo']=NULL;//$value['chapterNo'];
                    $videoArray['videoUrl']=$value['videoLink'];
                    $videoArray['url']=FRONTEND_URL.'/'.@$videoUrls[$value['video_id']]['url'];
                    $videoArray['thumbnailImage']= @$videoUrls[$value['video_id']]['thumb_image'];
                    $videoArray['title']=$value['displayName'];//$value['title'];
                    $videoArray['description']=$value['shortDescription'];
                    $videoArray['transcript']=NULL;//$value['transcript'];
                    $videoArray['isIntro']='0';
                    $resultArray['videos'][]=$videoArray;
                   }
               $totalVideos += count($resultArray['videos']);
             }

             $finalresultArray['data'][] = $resultArray;
         }
         $finalresultArray['status']='success';
         $finalresultArray['totalVideos']=$totalVideos;
         $this->view->data = $finalresultArray;
    }

    public function getTrainingTypeForCountryCityCourse(){
        $courseId = $this->getRequest()->getParam('course_id');
        $countryId = $this->getRequest()->getParam('country_id');
        $cityId = $this->getRequest()->getParam('city_id');
        if( empty($courseId) || empty($countryId) || empty($cityId) ){
            $this->view->data = array('status'=>'false','trainign_type_id'=>'','trainign_type_name'=>'','msg'=>'parameters not valid');
        }else{
            $objCourses = new Model_Courses();
            $courseData = $objCourses->getTrainingTypeForCountryCityCourse($courseId,$countryId,$cityId);
            if($courseData){
                $this->view->data = array('status'=>'true','trainign_type_id'=>1,'trainign_type_name'=>'Classroom','msg'=>'success');
            }else{
                $this->view->data = array('status'=>'true','trainign_type_id'=>2,'trainign_type_name'=>'Online Self Learning','msg'=>'success');
            }
        }
    }

    public function getTrainingTypeForCountryCityCourseV2(){
        $courseId = $this->getRequest()->getParam('course_id');
        $countryId = $this->getRequest()->getParam('country_id');
        $cityId = $this->getRequest()->getParam('city_id');
        if(!empty($courseId)){
            $objCourses = new Model_Courses();
            $resArr = array();
            if(true === $objCourses->checkOnlineCourse($courseId)){
                $resArr[BaseApp_Dao_TrainingTypes::TYPE_ELEARNING] = "Online Self Learning";
            }
            if(!empty($countryId) && !empty($cityId)){
                if(true === $objCourses->getTrainingTypeForCountryCityCourse($courseId,$countryId,$cityId)){
                    $resArr[BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM] = "Classroom";
                }
            }
            if(!empty($resArr)){
                $this->view->data = array('status'=>'true','msg'=>'success','data'=>$resArr);
            }else{
                $this->view->data = array('status'=>'false','msg'=>'no data found','data'=>array());
            }
        }else{
            $this->view->data = array('status'=>'false','msg'=>'parameters not valid','data'=>array());
        }
    }

    public function isImageValid($imageUrl, $fromSimpliCdn=true) {
        $aws = new Model_Aws();
        return $aws->validateFile($imageUrl, $fromSimpliCdn);
    }

    protected function getCourseForLabel($labelId){
        if (is_numeric($labelId)) {
            $course = new Model_Courses();
            $this->view->data = $course->fetchForSelect(array('primary_label_id = ?' => $labelId));
        }else{
            $this->view->data = array();
        }
    }

    protected function getAllCourses(){
        $course = new Model_Courses();
        $this->view->data = $course->fetchForSelect();
    }

    protected function getCourseDetails($courseId){
        $objCourse = new Model_Courses();
        $this->view->data = $objCourse->fetchCourseDetails($courseId);
    }

    protected function getLabelDetails($labelId){
        $objLabel = new Model_Labels();
        $this->view->data=$objLabel->fetchAll(array('label_id = ?' => $labelId), array(), false);
    }

    public function saveUserTestimonial(){
        if($this->getRequest()->getParam('elearningId')) {
            $courseObj = new BaseApp_Dao_Courses();
            $course_id = $courseObj->getCourseIdByElearningId($this->getRequest()->getParam('elearningId'));
        }
        else{
            $course_id = $this->getRequest()->getParam('course_id');
        }
        $feedback=  $this->getRequest()->getParam('feedback');
        $cityName = $this->getRequest()->getParam('city_id');
        $ipAdd = $this->getRequest()->getParam('ip');
        $trainingId = $this->getRequest()->getParam('training_id');
        $profileUrl = $this->getRequest()->getParam('profile_url');
        if(!empty($profileUrl)){
            if( (strpos($profileUrl,'https') === false) || (strpos($profileUrl,'http') === false)){
                $profileUrl = 'http://'.$profileUrl;
            }
        }

        $email = $this->getRequest()->getParam('email');
        $firstName = $this->getRequest()->getParam('firstName');
        $lastName = $this->getRequest()->getParam('lastName');
        $rating = $this->getRequest()->getParam('rating');
        $testimonialData = array('firstName'=>$firstName,
                                 'lastName'=>$lastName,
                                 'courseId'=>$course_id,
                                 'feedback'=>$feedback,
                                 'profileUrl'=>$profileUrl,
                                 'ip'=>$ipAdd,
                                 'email'=>$email,
                                 'rating'=>$rating,
                                 'training_id'=>$trainingId
                                 );
        $testimonial=new Model_Reviews();
        $res = $testimonial->saveUserTestimonial($testimonialData);
        $this->view->data = $res;
    }

    /* CRM API's */

    protected function datesSelectByCourse($country_id,$city_id=null,$course_id,$date_formate = null){
        $dates= new Model_Workshop();
        if(is_numeric($country_id) && is_numeric($course_id)){
            $data = $dates->getDetailByCourse($country_id,$city_id,$course_id,$date_formate = null);
            $this->view->data = $data;
        }else {
            $this->view->data = 'Please provide valid data';
        }
    }

    public function getDataForWorkshopJSObjectNew(){
        ini_set('memory_limit', '256M');
        $dateModel = new Model_Workshop();
        $data = $dateModel->getDataForWorkshopJSObjectNew();
        $this->view->data = $data;
    }

    public function getNamedWorkshopIdByAllWorkshopId($workshopId){
        $workshopId = $this->getRequest()->getParam("workshopId");
        if (strpos($workshopId, ",")){
            $workshopId = explode(",", $workshopId);
        }
        $dateModel = new Model_Workshop();
        $namedWorkshop = $dateModel->getNamedWorkshopId($workshopId);
        $this->view->data = $namedWorkshop;
    }

    public function getCurrencyByCountry($countryId) {
        $modelCountry = new Model_Country();
        $currencyData = $modelCountry->getCurrencies(array($countryId), true);
        $this->view->data = $currencyData[$countryId];
    }

    //crm apis start
     /**
    * @return array
    */
   protected function getCourseData() {
        $courseModel = new Model_Courses();
        $data = $courseModel->fetchForSelect();
        if($data)
            $this->view->data = $data;
        else
            $this->view->data = array();
   }
   /**
    * @return array
    */
   protected function fetchAllCategoryCourses($columnsArray = array(),$order = 'name',$courseId = array()) {
        $courseModel = new Model_Courses();
        $options = array();

        if($courseId)
            $conds = array('course_id in(?)'=>$courseId);
        else
            $conds = array();

        if($columnsArray)
            $data = $courseModel->fetchAll($conds,array('columns'=>$columnsArray,'order'=>$order),false);
        else
            $data = $courseModel->fetchAll($conds,array('order'=>$order),false);
        if($data){
            if(isset($data['primary_eLearning_id'])) {
                $data['eLearning_id'] = $data['primary_eLearning_id'];
            }
            if(isset($data['freeCourses'])) {
                $data['FreeELearningId'] = $courseModel->getFreeElearningsFromFreeCourses($data['freeCourses']);
                if($data['FreeELearningId']) {
                    $data['FreeELearningId'] = implode(",", $data['FreeELearningId']);
                }
            }
            $this->view->data = $data;
        }
        else{
            $this->view->data = array();
        }
   }
   /**
    * @param $courseId int
    * @return string
    */
    protected function getOnlyCourseNameById($courseId) {
        $courseModel = new Model_Courses($courseId);
        if(isset($courseModel->name) && $courseModel->name)
             $this->view->data = $courseModel->name;
        else
            $this->view->data  = '';
    }
    /**
    *
    * @return array of all courses key/value pair includeing disabled courses
    */
    protected function getAllCoursesList($opt = '') {
        $courseModel = new Model_Courses();
        if(!$opt)
            $courseModel->setFetchDisabled(true);
        $courseResult = $courseModel->fetchAll(array(),array(),false);
        $courses = array();
        foreach($courseResult as $key => $val)
        {
                $courses[$val['course_id']] = strip_tags($val['displayName']);
        }
        $this->view->data = $courses;
    }
    public function updateTheUserGA() {
        $request = $this->getRequest();
        $data['email'] = $request->getParam('email');
        $config = Zend_Registry::get('config');
        $mbsyConfigs = $config->get('mbsyconfig')->toArray();
        $countryCode = $request->getParam('country_code');
        if (!empty($countryCode) && ($countryCode != 'IN' && $countryCode != 'US')) {
            $countryCode = 'ROW';
        }
        $data['is_deactivated'] = 0;
        $data['set_groups'] = !empty($mbsyConfigs['group_id'][$countryCode]) ? $mbsyConfigs['group_id'][$countryCode] : '';
        $data = array_map('trim', $data);

        if (empty($data['email'])) {
            return false;
        }
        $params = '';
        foreach ($data AS $key => $value) {
            if (!empty($value)) {
                $params .= "{$key}={$value}&";
            }
        }
        if (APPLICATION_ENV != 'production') {
            $params = $params . "sandbox=1";
        }
        $params = rtrim($params, '&');
        $apiObj = new BaseApp_Ambassador_Api();
        $result = $apiObj->updatedAmbassadorUser($params);
        $response = array('status' => 404 ,'response' => '');
        $this->view->data = !empty($result['response']) ? $result['response'] : $response;
        return;
    }
    // public function getAmbassadorsUser() {
    //     $request = $this->getRequest();
    //     $data = array();
    //     $data['email'] = $request->getParam('email');
    //     $config = Zend_Registry::get('config');
    //     $mbsyConfigs = $config->get('mbsyconfig')->toArray();
    //     $countryCode = $request->getParam('country_code');
    //     if(!empty($countryCode) && ($countryCode !='IN' && $countryCode != 'US')) {
    //         $countryCode = 'ROW';
    //     }
    //     $data['campaign_uid'] = !empty($mbsyConfigs['camp_id'][$countryCode]) ? $mbsyConfigs['camp_id'][$countryCode] : '';
    //     $data['auto_create'] = 1;
    //     $data['add_to_group_id'] = !empty($mbsyConfigs['group_id'][$countryCode]) ? $mbsyConfigs['group_id'][$countryCode] : '';
    //     $data['first_name'] = $request->getParam('referrer_name');
    //     $nameData = explode(" ", $data['first_name']);
    //     $nameData = is_array($nameData)?$nameData:array();
    //     $data['first_name'] = isset($nameData[0])?$nameData[0]:'';
    //     unset($nameData[0]);
    //     $data['last_name'] = implode(" ", $nameData);
    //     $data = array_map('trim', $data);
    //     $shortCodeCandidate = empty($data['first_name'])?$data['email']:$data['first_name'];
    //     $shortCodeValue = strtolower(substr(preg_replace("/[^a-zA-Z0-9]+/", "", explode('@',$shortCodeCandidate)[0]), 0, 6));
    //     $data['custom1'] = str_pad($shortCodeValue, BaseApp_Ambassador_Api::SHORT_CODE_MIN_LENGTH, rand(100000, 999999));
    //     $data = array_map('trim', $data);
        
    //     if (empty($data['email'])) {
    //         return false;
    //     }
        
    //     $params = '';
    //     foreach ($data AS $key => $value) {
    //         if (!empty($value)) {
    //             $params .= "{$key}={$value}&";
    //         }
    //     }
    //     if (APPLICATION_ENV != 'production') {
    //         $params = $params . "sandbox=1";
    //     }
        
    //     $params = rtrim($params, '&');
    //     $apiObj = new BaseApp_Ambassador_Api();
    //     $result = $apiObj->addAmbassadorUser($params);
    //     $config = Zend_Registry::get('config');
    //     $mbsyConfigs = $mbsyConfigsForReferer = $campaignIdsReferer = $campaignIds = array();
    //     if(!empty($config) && !empty($config->get('trainermbsyconfig'))){
    //     $mbsyConfigs = $config->get('trainermbsyconfig')->toArray();
    //      $campaignIds = !empty($mbsyConfigs['camp_id']) ? $mbsyConfigs['camp_id'] : array();
    //     }
    //     if(!empty($config) && !empty($config->get('mbsyconfig'))){
    //     $mbsyConfigsForReferer = $config->get('mbsyconfig')->toArray();
    //     $campaignIdsReferer = !empty($mbsyConfigsForReferer['camp_id']) ? $mbsyConfigsForReferer['camp_id'] : array();
    //     }
    //     if (!empty($result['ambassador']['campaign_links'])) {
    //         $_r = $result['ambassador']['campaign_links'];
    //         if (!empty($_r)) {
    //             $_current_r = current($_r);
    //             if (array_key_exists('campaign_uid', $_current_r) && !(in_array($_current_r['campaign_uid'], $campaignIds))) {
    //                 foreach ($_r as $key => $value) {
    //                     if (!empty($value['campaign_uid'])) {
    //                         $campaign_uid = $value['campaign_uid'];
    //                         if (!(in_array($campaign_uid, $campaignIdsReferer))) {
    //                             unset($_r[$key]);
    //                         }
    //                     }
    //                 }
    //                 $_r = array_values($_r);
    //             }
    //             if (!empty($_r)) {
    //                 $_r = current($_r);
    //             }
    //         }
    //         if (!empty($_r['url'])) {
    //             $mbsy = $_r['url'];
    //             // Add trainee, if it's a trainer refer and earn module
    //             $config = Zend_Registry::get('config');
    //             $mbsyConfigs = $config->get('trainermbsyconfig')->toArray();
    //             $campaignIds = $mbsyConfigs['camp_id'];
    //             $campaignId = $data['campaign_uid'];
    //             if (!empty($campaignId) && in_array($campaignId, $campaignIds)) {
    //                 $this->addTrainee($result);
    //             }
    //             $mbsyChunks = explode('/', $mbsy);
    //         if (count($mbsyChunks) > 0) {
    //             $mbsy = end($mbsyChunks);
    //         }
    //         $this->view->data = array('status' => 200 ,'response' => $mbsy);
    //             return;
    //         }
    //     }
    //     $this->view->data = array('status' => 400 ,'response' => $result);
    //     return;
    // }

    protected function getAllCoursesListWithB2BStatus($opt = '') {
        $courseModel = new Model_Courses();
        if (!$opt)
            $courseModel->setFetchDisabled(true);
        $courseResult = $courseModel->fetchAll(array(), array(), false);
        $courses = array();
        foreach ($courseResult as $key => $val) {
            $courses[$val['course_id']] = array('name' => strip_tags($val['displayName']), 'is_b2b' => $val['is_b2b']);
        }
        $this->view->data = $courses;
    }

    /**
    * @param courseId
    * @returns array of course data with category_name also
    */
    protected function courseModelLoad($courseId) {
        $courseData = array();
        $courseModel = new Model_Courses();
        $courseModel->setFetchDisabled(true);
        $courseData = $courseModel->fetchAll(array('course_id =?' => $courseId));
        if($courseData[0]){
            $categoryModel = new Model_Labels($courseData[0]['primary_label_id']);
            $courseData[0]['category_name'] = $categoryModel->displayName;
            $courseData = $courseData[0];
            $courseData['eLearning_id'] = $courseData['primary_eLearning_id'];
            $courseData['FreeELearningId'] = $courseModel->getFreeElearningsFromFreeCourses($courseData['freeCourses']);
            if($courseData['FreeELearningId']) {
                $courseData['FreeELearningId'] = implode(",", $courseData['FreeELearningId']);
            }
        }
        $this->view->data = $courseData;
    }

    /**
    * @param course id array
    * @return array of one course key/value pair
    */
    protected function getOneCourse($courseId=array()) {
        $courseModel = new Model_Courses();
        $courseArray = $courseModel->fetchForSelect(array('course_id IN (?)' => $courseId));
        if($courseArray)
            $this->view->data = $courseArray;
        else
            $this->view->data = array();
    }

    /**
    * @param categoryIds array
    * @return key/value array of categories
    */
    protected function categoryFetchForSelect($categoryIds = array()){
         $categoryModel = new Model_Labels();
         if($categoryIds)
             $conds = array('label_id in (?)' => $categoryIds);
         else
             $conds = array();
         $categories = $categoryModel->fetchForSelect($conds);
         if($categories)
            $this->view->data = $categories;
         else
             $this->view->data = array();
    }
    /**
    * @param $courseId array
    *  @return array with 'course_name'=>'name','course_id','category_name'=>'name','category_id' (courses.name = course_name and category.name = category_name)
    */
    protected function fetchCategoryCoursesDetail($courseId){
        $courses = new Model_Courses();
        $db = $courses->getDb();
                $sQuery = $db->select()
                     ->from('courses', array('course_name'=>'name','course_id'))
                     ->join(array('labels'),'labels.label_id =courses.primary_label_id',array('category_name'=>'name','category_id'=>'label_id'))
                     ->where('course_id IN (?)',$courseId);

        $arrCourseData = $db->fetchAll($sQuery);
        if($arrCourseData)
            $this->view->data = $arrCourseData;
        else
            $this->view->data = array();

    }
    /**
    * @param $courseId array
    * @return array with 'name','category_id',course_id( category.name = name)
    */
    protected function fetchCategoryDetail($courseId){
        $courses = new Model_Courses();
        $db = $courses->getDb();
        $sQuery = $db->select()
                     ->from('labels', array('name','category_id'=>'label_id'))
                     ->join(array('courses'),'courses.primary_label_id =labels.label_id',array('course_id'))
                     ->where('course_id IN (?)',$courseId)
                     ->where('courses.status = 1')
                     ->where('labels.status = 1');
        $arrData = $db->fetchAll($sQuery);
        if($arrData)
            $this->view->data = $arrData;
        else
            $this->view->data = array();
    }
    /**
    * @param $columns array
    * @param $categoryId array
    * @return array
    */
    protected function fetchCategories($categoryId,$columns = array()){
        $categoryModel = new Model_Labels();
        $categoryModel->_allowDelete = true;
        $categoryModel->_useCache = false;
        $categoryData = $categoryModel->fetchAll(array('label_id in (?)' => $categoryId),array('columns'=>$columns), false);
        if($categoryData)
            $this->view->data = $categoryData;
        else
            $this->view->data = array();

    }
    public function updateWorkshopTypeById()
    {
            $workshopId = $this->getRequest()->getParam("workshopId");
            $workshopStatus = $this->getRequest()->getParam("workshopStatus");
            $dateModel = new Model_Workshop($workshopId);
            $dataArray = $dateModel->toArray();
            unset($dataArray['isEligible']);
            $dataArray['isNamed'] = $workshopStatus;
            $dateModel->setFromArray($dataArray);
            $status=$dateModel->update();
            $this->view->data = array("status" => $status);
    }

    public function updateWorkshopTypeByBatchId()
    {
         $columnName = $this->getRequest()->getParam("columnName");
         $id = $this->getRequest()->getParam("id");
         $workshopStatus = $this->getRequest()->getParam("workshopStatus");

         if($id > 0 && !empty($columnName))
         {
             $dateModel = new Model_Workshop();
             $where = $columnName.'='.$id;
             $arrUpdate = array('isNamed'=>$workshopStatus);
             $db = $dateModel->getDb();
             $status = $db->update('workshop',$arrUpdate,$where);
             $this->view->data = array("status" => $status);
         }else{
             $this->view->data = array("status" => 0);
         }

    }
    public function getWorkshopDates($date_id) {
        $dates = new Model_Date($date_id);
        $workshopDates=$dates->dates;
        $this->view->data =$workshopDates;
    }
     public function getCityForRegionAndCountry($countryId,$regionName){
             $cityModel = new Model_City();
             if($countryId != '' && $countryId != '-1'){
                 $cityModel->setFetchDisabled(true);
                 $cities = $cityModel->fetchAll(array(
                                                    'country_id=?'=>$countryId,
                                                    'region_name=?'=>$regionName
                                                ),
                                                array(
                                                    'columns' => array('city_id', 'city', 'displayName'),
                                                    'order' => 'city asc'
                                                )
                            );
                 foreach ($cities as &$city) {
                     unset($city['displayName']);
                 }
             }else{
                 $cities = array();
             }

             $this->view->data = $cities;
         }
         // crm apis end

     public function getcityByIpForMobile($ip){
        $locationData = BaseApp_Ice9Locator::getInstance()->getClientCityByIp($ip);
        $this->view->data = $locationData;
     }

     /**
     * get database tables
     */
    public function getDBTables($dbName) {
        if(!$dbName){
            $this->view->data = array();
            return true;
        }
        $mdlUtility = new Model_Utility();
        $res = $mdlUtility->getDbTables($dbName);
        $this->view->data = Zend_Json_Encoder::encode($res);
    }

    public function getCountriesByCluster($clusterIDs){
        $modelCountry = new Model_Country();
        $this->view->data = $modelCountry->fetchForSelect(array("cluster_id IN (?)"=>$clusterIDs), array(), false);
    }

    public function checkWorkShopStatus(){
        $workshopId = $this->getRequest()->getParam("workshopId");
        if(empty($workshopId)){
            $resultArray = array('status'=>'error','data'=>array(),'message'=>'please provide workshopId');
        }else{
            $objWorkShop = new Model_Workshop();
            $workShopData = $objWorkShop->checkWorkShopStatus($workshopId);
            $dataArr['isPass'] = $workShopData;
            $resultArray = array('status'=>'success','data'=>$dataArr,'message'=>'success');
        }
        $this->view->data = $resultArray;
    }

    protected function getCourseIdsForLabel($labelId){
        if (is_array($labelId)) {
            $course = new Model_Courses();
            $courseData = $course->fetchForSelect(array('primary_label_id in (?)' => $labelId));
            $courseIds = array_keys($courseData);
            $this->view->data = $courseIds;
        }else{
            $this->view->data = array();
        }
    }

    public function checkCourseStatus(){
        $courseId = $this->getRequest()->getParam("courseId");
        if(empty($courseId)){
            $resultArray = array('status'=>false,'message'=>'course Id mandatory');
        }else{
            $course = new Model_Courses();
            $courseData = $course->fetchAll(array('course_id = ?' => $courseId));
            if(!empty($courseData)){
                $resultArray = array('status'=>true,'message'=>'course is active');
            }else{
                $resultArray = array('status'=>false,'message'=>'course is Inactive');
            }
        }
        $this->view->data = $resultArray;
    }

    public function getCurrencyCodes(){
        $currencyObj = new Model_Currency();
        $currencyData = $currencyObj->getCurrencyCodes();
        if(!empty($currencyData)){
                $resultArray = array('status'=>true,'message'=>'records found','data'=>$currencyData);
        }else{
            $resultArray = array('status'=>true,'message'=>'no records found','data'=>array());
        }
        $this->view->data = $resultArray;
    }

    protected function getCityRegionList($countryId){
        $objCity = new Model_City();
        $this->view->data = $objCity->getCityRegionList(intval($countryId));
    }

    public function getCoursesForTrainingType() {
        $trainingArr = $this->getRequest()->getParam('trainingId');
        $resultArray = array();
        if(is_array($trainingArr) && count($trainingArr)>0){
            $objCourses = new Model_Courses();
            $resultData = $objCourses->getCoursesForTrainingType($trainingArr);
            $resultArray = array('status'=>true,'message'=>'success','data'=>$resultData);
        }else{
            $resultArray = array('status'=>false,'message'=>'invalid Parameters','data'=>array());
        }
        $this->view->data = $resultArray;
    }

    public function fetchAffiliateRegistrationOrder() {
        $userId = $this->getRequest()->getParam('userId');
        $resultArray = array();
        if($userId && is_numeric($userId)){
            $orderModel = new BaseApp_Dao_Melvin_Order();
            $resultData = $orderModel->fetchAffiliateRegistrationOrder($userId);
            $resultArray = array('status'=>true,'message'=>'success','data'=>$resultData);
        }else{
            $resultArray = array('status'=>false,'message'=>'invalid Parameters','data'=>array());
        }
        $this->view->data = $resultArray;
    }

    protected function getBundleAccessDays($bundleId,$countryId) {
        $modelObj = new Model_SubscriptionPricing();
        $conds = array('linkable_type=?'=> 'bundle', 'linkable_id=?'=>$bundleId, 'country_id=?'=>$countryId);
        $pricingDataAll = $modelObj->fetchAll($conds, array(), false);
        $accessObj = new Model_AccessDays();
        $accessDaysAll = $accessObj->getAccessDaysById('osl');
        if($pricingDataAll) {
            $accessDaysList = array();
            foreach($pricingDataAll as $pricingData) {
                $accessDaysList[] = $accessDaysAll[$pricingData['access_day_id']];
            }
            $this->view->data = array(
                'status' => 'success',
                'accessDays' => $accessDaysList
            );
            return;
        }

        $modelCountry = new Model_Country();
        $countryData =  current($modelCountry->fetchAll(array('country_id=?'=>$countryId), array(), false));
        if(empty($countryData) || empty($countryData['cluster_id'])) {
            $this->view->data = array(
                'status' => 'error',
                'message' => 'country does not exists or cluster missing'
            );
            return;
        }
        $conds = array('linkable_type=?'=> 'bundle', 'linkable_id=?'=>$bundleId, 'cluster_id=?'=>$countryData['cluster_id']);
        $pricingDataAll = $modelObj->fetchAll($conds);
        if($pricingDataAll) {
            $accessDaysList = array();
            foreach($pricingDataAll as $pricingData) {
                $accessDaysList[] = $accessDaysAll[$pricingData['access_day_id']];
            }
            $this->view->data = array(
                'status' => 'success',
                'accessDays' => $accessDaysList
            );
            return;
        }
        $this->view->data = array(
            'status' => 'error',
            'message' => 'no price exists',
            'accessDays' => array()
        );
        return;
    }

    protected function fetchCertificateDetails(){
        $trainingTypeId = $this->getRequest()->getParam('trainingType_id');
        $courseId = $this->getRequest()->getParam('course_id');
        $certificateType = 'pdu'; // by default PDU will be set
        $certificateRequest =$this->getRequest()->getParam('certificate_type');
        if(!empty($certificateRequest))
             $certificateType = trim($certificateRequest);
        $resultData = array('pduOffer'=>'',
                            'courseCode'=>'',
                            'certificateName'=>'',
                            'completionCode'=>'',
                            'oneLiner'=>'',
                            'accreditor_details'=>array()
                           );
        if($trainingTypeId && $courseId && $certificateType){
            $objCertificate = new Model_Certificates();
            $certificateData = $objCertificate->fetchAll(array(  'linkable_id =?'=>$courseId,
                                                                 'linkable_type =?'=>'course',
                                                                 'training_id =?'=>$trainingTypeId,
                                                                 'certificateType = ?' =>$certificateType,
                                                                 'name is not null' =>''
                                                              )
                                                            );
            if(!empty($certificateData)){
                $resultData['pduOffer'] = $certificateData[0]['pdu'];
                $resultData['courseCode'] = $certificateData[0]['activityNumber'];
                $resultData['certificateName'] = $certificateData[0]['displayName'];
                $resultData['oneLiner'] = $certificateData[0]['oneLiner'];
                if($certificateType == 'completion')
                    $resultData['completionCode'] = $certificateData[0]['activityNumber'];
                if(!empty($certificateData[0]['accreditor_id'])){
                    $objAccreditor = new Model_Accreditors();
                    $accDetails = $objAccreditor->fetchAll(array('accreditor_id in (?)'=>explode(',',$certificateData[0]['accreditor_id'])));
                    if(!empty($accDetails)){
                        $resultData['accreditor_details'] = $accDetails;
                    }
                }
                $resultArray = array('status'=>true,'message'=>'success','data'=>$resultData);
            }elseif($certificateRequest == 'completion'){
                    $objCourse = new Model_Courses();
                    $courseData = current($objCourse->fetchAll(array('course_id =?'=>$courseId)));
                    $objAccreditor = new Model_Accreditors();
                    $accDetails = $objAccreditor->fetchAll( array('is_default =?'=>1));
                    if(!empty($courseData))
                        $resultData['certificateName'] = $courseData['displayName'];
                    if(!empty($accDetails))
                        $resultData['accreditor_details'] = $accDetails;
                    $resultArray = array('status'=>true,'message'=>'success','data'=>$resultData);
            }else{
                $resultArray = array('status'=>false,'message'=>'no data','data'=>array());
            }
        }else{
            $resultArray = array('status'=>false,'message'=>'invalid Parameters','data'=>array());
        }
        $this->view->data = $resultArray;
    }

    public function createAcl() {
        $email = trim($this->getRequest()->getParam('email'));
        $password = $this->getRequest()->getParam('password');
        $name = $this->getRequest()->getParam('name');
        $looperUserId = $this->getRequest()->getParam('looperUserId');
        if(!$looperUserId || !$email) {
            $this->view->data = array(
                'status'=>false,
                'message'=>'insufficient data to create'
            );
            return false;
        }
        $dataSave = array(
            'email' => $email,
            'password' => $password,
            'name' => $name,
            'looper_user_id' => $looperUserId
        );
        $model = new Model_Acl();
        if($model->getByEmail($email)) {
            $this->view->data = array(
                'status'=>false,
                'message'=>'acl already exists for this email'
            );
            return false;
        }
        if($aclId = $model->create($dataSave)) {
            $this->view->data = array(
                'status'=>true,
                'message'=>'successfully created',
                'acl_id' => $aclId
            );
            return true;
        }
        $this->view->data = array(
            'status'=>false,
            'message'=>'failde to create'
        );
        return false;
    }

    public function updateAcl() {
        $email = trim($this->getRequest()->getParam('email'));
        $password = $this->getRequest()->getParam('password');
        $name = $this->getRequest()->getParam('name');
        if(!$password && !$name) {
            $this->view->data = array(
                'status'=>false,
                'message'=>'nothing to update'
            );
            return false;
        }

        $model = new Model_Acl();
        if(!$aclData = $model->getByEmail($email)) {
            $this->view->data = array(
                'status'=>false,
                'message'=>'acl does not exists for this email'
            );
            return false;
        }

        $dataSave = array();
        if($password) {
            $dataSave['password'] = $password;
        }
        if($name) {
            $dataSave['name'] = $name;
        }
        $model->clean();
        $model->setId($aclData['acl_id']);
        if($model->setFromArray($dataSave)->update()) {
            $this->view->data = array(
                'status'=>true,
                'message'=>'successfully updated'
            );
            return true;
        }
        $this->view->data = array(
            'status'=>false,
            'message'=>'failde to update'
        );
        return false;
    }

    public function deleteAcl() {
        $email = trim($this->getRequest()->getParam('email'));
        if(!$email) {
            $this->view->data = array(
                'status'=>false,
                'message'=>'invalid data'
            );
            return false;
        }

        $model = new Model_Acl();
        if(!$aclData = $model->getByEmail($email)) {
            $this->view->data = array(
                'status'=>false,
                'message'=>'acl does not exists for this email'
            );
            return false;
        }

        $model->clean();
        $model->setId($aclData['acl_id']);
        if($model->delete()) {
            $this->view->data = array(
                'status'=>true,
                'message'=>'successfully deleted'
            );
            return true;
        }
        $this->view->data = array(
            'status'=>false,
            'message'=>'failde to delete'
        );
        return false;
    }

    protected function getBundlesDisplayWise(){
        $objBundle = new Model_Bundles();
        $bundleData = $objBundle->getBundleList();
        $this->view->data = $bundleData;
    }
    protected function getBundlesCourseList(){
        $objBundle = new Model_Bundles();
        $bundleData = $objBundle->getBundleCourseList();
        $this->view->data = $bundleData;
    }
    /**
     * @author PJ
     * @param integer $wsId Description
     * @param array $userInfo User info - name, email Array('name'=>'UserName', 'email'=>'email@email.e');
     * @param string $type Registration type like REGISTER/ACCEPT/REJECT
     *
     */
    protected function webexRegister($wsId,$userId, $type = 'ACCEPT') {

        //Get workshop details by $wsId

        //Pass webExId and webExPwd of corresponding WS

        if(!$wsId && !$userId){
            $resultArray = array('status'=>false,'message'=>'invalid Parameters','data'=>array());
        }else{
            $looper = new BaseApp_Communication_Accounts;
            $userData = $looper->getUserDetailsById($userId);
            if($userData['status'] != 'success'){
                $resultArray = array('status'=>false,'message'=>'No User Data Found','data'=>array());
            }else{
                $userData = $userData['data'];
                $objWorkShop = new Model_Workshop();
                $workshopData = current($objWorkShop->fetchAll(array('workshop_id = ?' =>$wsId)));
                if(!empty($workshopData)){
                    try{
                        $sessionKey = $workshopData['webx_session_id'];
                        $webExId = $workshopData['webx_user_id'];
                        $webExVId = $workshopData['webx_version_id'];
                        $webExPwd = $objWorkShop->getWebxPassword($webExId,$webExVId);
                        if(!$webExPwd){
                            $resultArray = array('status'=>false,'message'=>'No pass Word Found in INI file','data'=>array());
                        }else{
                            if(!empty($sessionKey)){

                            //$webexApi = new BaseApp_Webex_Api($webExId, $webExPwd);

                            $objManager = new BaseApp_Webex_Manager($webExId,$webExPwd,$webExVId);
                            $objManager->setWorkshopId($wsId);
                            $webexApi = $objManager->getInstance();

                            $attendees = array(array('info'=>array("name" => $userData['displayName'], "email" => $userData['users_mail']),
                                                     'options'=>array('emailInvitations'=>false, 'sessionKey'=>$sessionKey,'joinStatus'=>$type)
                                                     )
                                              );
                            $result = $webexApi->attendee_RegisterMeetingAttendee($attendees);
                            if( is_array($result) && array_key_exists('result', $result) && ($result['result'] == self::WEBEX_SUCCESS) ){
                                $resultArray = array('status'=>true,'message'=>'success','data'=>$result);
                            }else{
                                $resultArray = array('status'=>false,'message'=>'fail','data'=>$result);
                            }

                            }else{
                                $resultArray = array('status'=>false,'message'=>'No session Id found against workshop','data'=>array());
                            }
                        }
                    }catch(Exception $e){
                        $resultArray = array('status'=>false,'message'=>'Something went wrong at Webex End','data'=>array($e->getMessage()));
                    }
                }else{
                    $resultArray = array('status'=>false,'message'=>'No workshop Found','data'=>array());
                }
            }
        }
        $this->view->data = $resultArray;
    }

    /**
     * @author PJ
     * @param integer $oldWsId
     * @param integer $newWsId
     * @param array $$userData User info - name, email Array('name'=>'UserName', 'email'=>'email@email.e');
     *
     */
    protected function webexRescheduleUser($oldWsId,$newWsId, $userId) {
        //Cancel Registration for given WS and User
        //Get workshop details by $oldWsId
        //
        //Pass webExId and webExPwd of corresponding WS
        if(!$oldWsId && !$userId && !$newWsId){
            $resultArray = array('status'=>false,'message'=>'invalid Parameters','data'=>array());
        }else{
            $looper = new BaseApp_Communication_Accounts();
            $userData = $looper->getUserDetailsById($userId);
            if($userData['status'] != 'success'){
                $resultArray = array('status'=>false,'message'=>'No User Data Found','data'=>array());
            }else{
                $userData = $userData['data'];
                $resultData = array();
                $objWorkShop = new Model_Workshop();
                $oldWorkshopData = current($objWorkShop->fetchAll(array('workshop_id = ?' =>$oldWsId)));
                $newWorkshopData = current($objWorkShop->fetchAll(array('workshop_id = ?' =>$newWsId)));
                if(!empty($oldWorkshopData) && !empty($newWorkshopData)){
                    try{

                        $oldSessionKey = $oldWorkshopData['webx_session_id'];
                        $oldWebExId = $oldWorkshopData['webx_user_id'];
                        $oldWebExVId = $oldWorkshopData['webx_version_id'];
                        $oldWebExPwd = $objWorkShop->getWebxPassword($oldWebExId);

                        $newSessionKey = $newWorkshopData['webx_session_id'];
                        $newWebExId = $newWorkshopData['webx_user_id'];
                        $newWebExVId = $newWorkshopData['webx_version_id'];
                        $newWExPwd = $objWorkShop->getWebxPassword($newWebExId);

                        if((!$newWExPwd) || (!$oldWebExPwd)){
                            if(empty($oldWebExPwd))
                                    $message = 'Old workshop';
                                else
                                    $message = 'New workshop';
                                $resultArray = array('status'=>false,'message'=>'No Password found against'.$message,'data'=>array());
                        }else{
                            if(!empty($oldSessionKey) && !empty($newSessionKey)){

                            //$webexApi = new BaseApp_Webex_Api($oldWebExId, $oldWebExPwd);
                            $objManager = new BaseApp_Webex_Manager($oldWebExId, $oldWebExPwd,$oldWebExVId);
                            $objManager->setWorkshopId($oldWsId);
                            $webexApi = $objManager->getInstance();

                            $attendees = array(array('info'=>array("name" => $userData['displayName'], "email" => $userData['users_mail']),
                                                     'options'=>array('emailInvitations'=>true, 'sessionKey'=>$oldSessionKey,'joinStatus'=>'REJECT')
                                                    )
                                              );
                            $result = $webexApi->attendee_RegisterMeetingAttendee($attendees);
                            if( is_array($result) && array_key_exists('result', $result) && ($result['result'] == self::WEBEX_SUCCESS) ){
                                $attendees = array(array('info'=>array("name" => $userData['displayName'], "email" => $userData['users_mail']),
                                                         'options'=>array('emailInvitations'=>true, 'sessionKey'=>$newSessionKey,'joinStatus'=>'ACCEPT')
                                                        )
                                                  );
                                //$webexApi = new BaseApp_Webex_Api($newWebExId, $newWExPwd);

                                $objManager = new BaseApp_Webex_Manager($newWebExId, $newWExPwd,$newWebExVId);
                                $objManager->setWorkshopId($newWsId);
                                $webexApi = $objManager->getInstance();

                                $newResult = $webexApi->attendee_RegisterMeetingAttendee($attendees);
                                if( is_array($newResult) && array_key_exists('result', $newResult) && ($newResult['result'] == self::WEBEX_SUCCESS) ){
                                    $resultArray = array('status'=>true,'message'=>'success','data'=>$newResult);
                                }else{
                                    $resultArray = array('status'=>false,'message'=>'fail','data'=>$newResult);
                                }
                            }else{
                                $resultArray = array('status'=>false,'message'=>'Some error occured while cancelling old workshop','data'=>$result);
                            }
                            }else{
                                if(empty($oldSessionKey))
                                    $message = 'Old workshop';
                                else
                                    $message = 'New workshop';
                                $resultArray = array('status'=>false,'message'=>'No session Id found against'.$message,'data'=>array());
                            }
                        }
                    }catch(Exception $e){
                        $resultArray = array('status'=>false,'message'=>'Something went wrong at Webex End','data'=>array($e->getMessage()));
                    }
                }else{
                    if(empty($oldWorkshopData))
                        $message = 'Old workshop';
                    else
                        $message = 'New workshop';
                    $resultArray = array('status'=>false,'message'=>'No workshop Found For '.$message,'data'=>array());
                }
            }
        }
        $this->view->data = $resultArray;
    }


    protected function fetchLvcPassDetails(){
        $request = $this->getRequest();
        $countryId = $this->getRequest()->getParam('country_id');
        $startDate = $this->getRequest()->getParam('start_date');
        $endDate = $this->getRequest()->getParam('end_date');
        $userEmail = $this->getRequest()->getParam('user_email');
        $priceId = $request->getParam('price_id');
        $courseId = '';
        $resultData = array();
        if($countryId && $startDate && $endDate){
            if(!empty($priceId)){
                $objPricing = new Model_Pricings();
                $objPricing->setFetchDisabled(true);
                $priceDetails = current($objPricing->fetchAll(array('pricing_id = ?'=>$priceId), array('columns'=>array('course_id'),'limit' => 1)));
                if(!empty($priceDetails)){
                    $objCourses = new Model_Courses($priceDetails['course_id']);
                    if(!$objCourses->is_dummy)
                        $courseId = $priceDetails['course_id'];
                }
            }
            $objWorkShop = new Model_Workshop();
            $workshopData = $objWorkShop->getLvcWorkshop($countryId,$startDate,$endDate,$userEmail,$courseId);
            if(!empty($workshopData)){
                $objCountryRegion = new BaseApp_Dao_CountryRegion();
                $support_number = CONTACT_US_ROW;
                $supportNumber = $objCountryRegion->getCountryNumber($countryId);
                if(!empty($supportNumber)){
                    $support_number = $supportNumber;
                }
                $workshopData['support_number'] = $support_number;
                $resultArray = array('status'=>true,'message'=>'success','data'=>$workshopData);
            }else{
                $resultArray = array('status'=>true,'message'=>'success','data'=>array());
            }
        }else{
            $resultArray = array('status'=>false,'message'=>'invalid Parameters','data'=>array());
        }
        $this->view->data = $resultArray;
    }

    public function getAccessDaysForCourse($courseId) {
        $obj = new Model_TrainingRelations();
        $this->view->data = $obj->getOslAccessDaysForCourse($courseId,'course');
    }

    public function getCurrencyDetails(){
         $countryId = $this->getRequest()->getParam('countryId');
         $countryCode = $this->getRequest()->getParam('countryCode');
         if(!empty($countryCode) && empty($countryId)) {
            $objCountry = new Model_Country();
            $countryDetails = current($objCountry->fetchAll(array('code = ?'=>$countryCode)));
            if(!empty($countryDetails) && !empty($countryDetails['country_id']))
                $countryId = $countryDetails['country_id'];

         }
         if($countryId){
            $objCurrency = new Model_Currency();
            $currencyData = $objCurrency->getCurrencyDetails($countryId);
            if(!empty($currencyData))
                $resultArray = array('status'=>true,'message'=>'success','data'=>$currencyData);
            else
                $resultArray = array('status'=>false,'message'=>'No data Found','data'=>array());
         }else{
            $resultArray = array('status'=>false,'message'=>'country Id is mandatory','data'=>array());
         }
         $this->view->data = $resultArray;
    }

    public function getCurrencyDetailsByCountry(){
         $countryId = $this->getRequest()->getParam('countryId');
         $stateName = $this->getRequest()->getParam('state');
         if($countryId){
            $objCurrency = new Model_Currency();
            $dataReturn = array();
            $currencyData = $objCurrency->getCurrencyDetails($countryId);
            if(!empty($currencyData)){
                $dataReturn = array(
                    'code'=>$currencyData['code'],
                    'currency_id'=>$currencyData['currency_id'],
                    'tax'=>array()
                );
                $dataReturn['totalTax'] = $currencyData['serviceTax'];
                $dataReturn['invoiceAddress'] = $currencyData['invoiceAddress'];
                $dataReturn['invoiceString'] = $currencyData['invoiceString'];
                $dataReturn['registrationNumber'] = !empty($currencyData['registrationNumber']) ?$currencyData['registrationNumber'] : '';
                $dataReturn['currency_symbol']=!empty($currencyData['symbol_original']) ? $currencyData['symbol_original'] :'';
                if (!$currencyData['serviceTaxString']) {
                    $currencyData['serviceTaxString'] = 'Service Tax';
                }
                if ($countryId == INDIA_COUNTRY_ID) {
                    $taxBreakupNew = array();
                    $state = '';
                    $cityObj = new BaseApp_Dao_City();
                    $cityData = $cityObj->getDefaultCityData($countryId);
                    if (!empty($cityData) && $cityData['region_name']) {
                        $state = $cityData['region_name'];
                    }
                    if (!empty($state) && $state == $stateName) {
                        $dataReturn['tax'][STATE_GST_STRING] = array(
                            'percentage' => $dataReturn['totalTax']/2,
                            );
                        $dataReturn['tax'][CENTRE_GST_STRING] = array(
                            'percentage' => $dataReturn['totalTax']/2,
                            );
                    } else {
                        $dataReturn['tax'][INTEGRATED_GST_STRING] = array(
                            'percentage' => $dataReturn['totalTax'],
                            );
                    }
                } else {
                    $dataReturn['tax'][$currencyData['serviceTaxString']] = array(
                        'percentage' => $currencyData['serviceTax']
                    );
                }


                $resultArray = array('status'=>'success','data'=>$dataReturn);
            }
            else {
                $resultArray = array('status'=>'fail','message'=>'No data Found','data'=>array());
            }
         }else{
            $resultArray = array('status'=>'fail','message'=>'country Id is mandatory','data'=>array());
         }
         $this->view->data = $resultArray;
    }

    public function getAllCurrencyData(){
        $currencyObj = new Model_Currency();
        $currencyData = $currencyObj->fetchAll();
        if(!empty($currencyData)){
                $resultArray = array('status'=>true,'message'=>'success','data'=>$currencyData);
        }else{
            $resultArray = array('status'=>false,'message'=>'no records found','data'=>array());
        }
        $this->view->data = $resultArray;
    }

    public function getCountryList(){
        $objCountry = new Model_Country();
        $countryData = $objCountry->fetchAll(array(),array('columns'=>array('country_id','name','code','timeZone'),'order' =>array('name ASC')));
        $this->view->data = $countryData;
    }


    public function getPassDetails(){
        $request = $this->getRequest();
        $priceId = $request->getParam('price_id');
        if(!empty($priceId)){
            $objPricing = new Model_Pricings();
            $objPricing->setFetchDisabled(true);
            $priceDetails = current($objPricing->fetchAll(array('pricing_id = ?'=>$priceId), array('columns'=>array('course_id'),'limit' => 1)));
            if(!empty($priceDetails)){
                $courseId = $priceDetails['course_id'];
                $objCourse = new Model_Courses();
                $courseData = current($objCourse->fetchAll(array('course_id =?'=>$courseId)));
                if(!empty($courseData)) {
                    if($courseData['is_dummy']){
                        $passObj = new Model_Pass();
                        $passData = current($passObj->fetchAll(array('course_id =?'=>$courseId)));
                        if(!empty($passData)){
                            $passData['eLearning_id'] = $courseData['primary_eLearning_id'];
                            $resultArray = array('status'=>true,'message'=>'success','data'=>$passData);
                        }
                    }else{
                        $priceDetails['name'] = $courseData['name'];
                        $priceDetails['displayName'] = $courseData['displayName'];
                        $priceDetails['shortDescription'] = $courseData['shortDescription'];
                        $priceDetails['pass_type'] = BaseApp_Dao_TrainingTypes::CART_ONLINE_CLASSROOM_PASS;
                        $priceDetails['no_of_days'] = PASS_ACCESS_DAYS;
                        $priceDetails['osl_access_days'] = ONLINE_CLASSROOM_PASS_OSL_ACCESS_DAYS;
                        $priceDetails['status'] = $courseData['status'];
                        $priceDetails['eLearning_id'] = $courseData['primary_eLearning_id'];
                        $resultArray = array('status'=>true,'message'=>'success','data'=>$priceDetails);
                    }
                }else{
                    $resultArray = array('status'=>false,'message'=>'no Course Found','data'=>array());
                }
            }else{
                $resultArray = array('status'=>false,'message'=>'No Course Found For Price Id','data'=>array());
            }
        }else{
            $resultArray = array('status'=>false,'message'=>'no records found','data'=>array());
        }
        $this->view->data = $resultArray;
    }

     protected function getOrderDetailsByOrderNumber(){
      $orderId = $this->getRequest()->getParam('orderId');
      $orderModel = new BaseApp_Dao_Melvin_Order();
      $data = $orderModel->getOrderDetailsByOrderNumber($orderId);
      $this->view->data = $data;
    }

    protected function getBundleData(){
        $bundleId = $this->getRequest()->getParam('bundle_id');
        $fetchDisableFlag = false;
        $disableFlag = $this->getRequest()->getParam('disable');
        if(isset($disableFlag) && !empty($disableFlag))
            $fetchDisableFlag = true;

        $objBundle = new Model_Bundles();
        if($fetchDisableFlag)
            $objBundle->setFetchDisabled(true);
        $bundleData = $objBundle->getBundleList($bundleId);
        if(!empty($bundleData))
            $resultArray = array('status'=>true,'message'=>'success','data'=>$bundleData);
        else
            $resultArray = array('status'=>false,'message'=>'no results found','data'=>array());

        $this->view->data = $resultArray;
    }


    protected function getSubscriptionPrice(){
        $countryId = $this->getRequest()->getParam('country_id');
        $conversionFactor = 1;
        $currencyId = '';
        $currencySymbol = '';
        $currencyData = array();
        $objCountry = new Model_Country();
        $objCurrency = new Model_Currency();
        $countryData = current($objCountry->fetchAll(array('country_id = ?'=>$countryId),array('columns'=>array('currency_id'))));
        if(empty($countryData)){
            $currencyData = current($objCurrency->fetchAll(array('defaults = ?'=>1),array('columns'=>array('currency_id','symbol'))));
        }else{
            $currencyData = current($objCurrency->fetchAll(array('currency_id = ?'=>$countryData['currency_id']),array('columns'=>array('currency_id','symbol'))));
        }
        $currencyId = $currencyData['currency_id'];
        $lmsCurrencySymbol = $currencyData['symbol'];
        $crmCurrencySymbol = $currencyData['symbol'];
        $bundleId = $this->getRequest()->getParam('bundle_id');
        if($countryId && $bundleId){
            $objBundle = new Model_Bundles();
            $pricingData = $objBundle->getSubscriptionPrice($countryId,$bundleId);
            if(!empty($pricingData)){
                $pricingData['currency_id'] = $currencyId;
                $pricingData['crm_currency_symbol'] = $crmCurrencySymbol;
                $pricingData['lms_currency_symbol'] = $lmsCurrencySymbol;
                $pricingData['conversion_factor'] = $conversionFactor;
                $resultArray = array('status'=>true,'message'=>'success','data'=>$pricingData);
            }
            else
                $resultArray = array('status'=>false,'message'=>'no results found','data'=>array());
        }else{
            $resultArray = array('status'=>false,'message'=>'invalid Parameters','data'=>array());
        }
        $this->view->data = $resultArray;
    }

    public function getTrainingTypeForCountryCityCourseV3(){
        $courseId = $this->getRequest()->getParam('course_id');
        $countryId = $this->getRequest()->getParam('country_id');
        $cityId = $this->getRequest()->getParam('city_id');
        if(!empty($courseId)){
            $objCourses = new Model_Courses();
            $resArr = array();
            if(true === $objCourses->checkOnlineCourse($courseId)){
                $resArr[BaseApp_Dao_TrainingTypes::TYPE_ELEARNING] = "Online Self Learning";
            }
            if(!empty($countryId)){
                $resultData = $objCourses->getTrainingTypeForCountryCityCourseV3($courseId,$countryId,$cityId);
                if(!empty($resultData)){
                    if(in_array(BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM, $resultData))
                        $resArr[BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM] = "Classroom";
                    if(in_array(BaseApp_Dao_TrainingTypes::TYPE_LVC, $resultData))
                        $resArr[BaseApp_Dao_TrainingTypes::TYPE_LVC] = "LVC";
                }
            }
            if(!empty($resArr)){
                $this->view->data = array('status'=>'true','msg'=>'success','data'=>$resArr);
            }else{
                $this->view->data = array('status'=>'false','msg'=>'no data found','data'=>array());
            }
        }else{
            $this->view->data = array('status'=>'false','msg'=>'parameters not valid','data'=>array());
        }
    }

    /* Api Written By Ganesh,Added by Kirit in the file
        Fetches List of All Bundles .
        By default it fetches only active bundles .
        If $opt is set then All bundles will be fetched
    */

    protected function getAllBundlesList($opt = '',$isBundle ='') {
        $bundleModel = new Model_Bundles();
        if(!$opt)
            $bundleModel->setFetchDisabled(true);
        if($isBundle)
            $bundlesResult = $bundleModel->fetchAll(array('payment_type_id =?'=>BaseApp_Dao_PaymentType::ONETIME_PAYMENT_TYPE_ID),array(),false);
        else
            $bundlesResult = $bundleModel->fetchAll(array(),array(),false);

        $bundles = array();
        foreach($bundlesResult as $key => $val){
            $bundles[$val['bundle_id']] = strip_tags($val['display_name']);
        }
        $this->view->data = $bundles;
    }


   /* Api Written By Ganesh,Added by Kirit in the file
        Fetches List of All Bundles bases on Query Params.
    */

   protected function fetchAllCategorybundles($columnsArray = array(),$order = 'name',$bundleId = array()) {
        $courseModel = new Model_Bundles();
        $options = array();
        if($bundleId)
            $conds = array('bundle_id in (?)'=>$bundleId);
        else
            $conds = array();
        if($columnsArray)
            $data = $courseModel->fetchAll($conds,array('columns'=>$columnsArray,'order'=>$order),false);
        else
            $data = $courseModel->fetchAll($conds,array('order'=>$order),false);
        if($data){
            if(isset($data['primary_eLearning_id'])) {
                $data['eLearning_id'] = $data['primary_eLearning_id'];
            }
            if(isset($data['freeCourses'])) {
                $data['FreeELearningId'] = $courseModel->getFreeElearningsFromFreeCourses($data['freeCourses']);
                if($data['FreeELearningId']) {
                    $data['FreeELearningId'] = implode(",", $data['FreeELearningId']);
                }
            }
            $this->view->data = $data;
        }
        else{
            $this->view->data = array();
        }
   }

   /* Api Written By by Kirit .
        Version 4 Api to fetch training Types available for the request params
        Difference between V3 and V4 is V4 checks against a product Type
    */


    public function getTrainingTypeForCountryCityCourseV4(){
        $productTypeId = $this->getRequest()->getParam('product_type_id');
        $productId = $this->getRequest()->getParam('product_id');
        $countryId = $this->getRequest()->getParam('country_id');
        $cityId = $this->getRequest()->getParam('city_id');
        if($productTypeId){
            $productObj = new BaseApp_Dao_ProductTypes();
            $productData = current($productObj->fetchAll(array('product_type_id =?'=>$productTypeId)));
            if(!empty($productData)){
                if(!empty($productId)){
                    $productName = $productData['product_type_name'];
                    if($productName == BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE){
                        $objCourses = new Model_Courses();
                        $resArr = array();
                        if(true === $objCourses->checkOnlineCourse($productId))
                            $resArr[BaseApp_Dao_TrainingTypes::TYPE_ELEARNING] = "Online Self Learning";
                        if(!empty($countryId)){
                            $resultData = $objCourses->getTrainingTypeForCountryCityCourseV3($productId,$countryId,$cityId);
                            if(!empty($resultData)){
                                if(in_array(BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM, $resultData))
                                    $resArr[BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM] = "Classroom";
                                if(in_array(BaseApp_Dao_TrainingTypes::TYPE_LVC, $resultData))
                                    $resArr[BaseApp_Dao_TrainingTypes::TYPE_LVC] = "LVC";
                            }
                        }
                        if(!empty($resArr))
                            $resultArray = array('status'=>true,'message'=>'success','data'=>$resArr);
                        else
                            $resultArray = array('status'=>false,'message'=>'No Data Found','data'=>array());
                    }elseif($productName == BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES){
                        $objBundle= new Model_Bundles();
                        $resArr = array();
                        if(true === $objBundle->checkBundlePricings($productId))
                            $resArr[BaseApp_Dao_TrainingTypes::TYPE_ELEARNING] = "Online Self Learning";
                        if(!empty($resArr))
                            $resultArray = array('status'=>true,'message'=>'success','data'=>$resArr);
                        else
                            $resultArray = array('status'=>false,'message'=>'No Data Found','data'=>array());
                    }elseif($productName == BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_MOM){
                        $objBundle= new Model_Bundles();
                        $resArr = array();
                        if(true === $objBundle->checkMomPricings($productId))
                            $resArr[BaseApp_Dao_TrainingTypes::TYPE_ELEARNING] = "Online Self Learning";
                        if(!empty($resArr))
                            $resultArray = array('status'=>true,'message'=>'success','data'=>$resArr);
                        else
                            $resultArray = array('status'=>false,'message'=>'No Data Found','data'=>array());
                    }else{
                        $resultArray = array('status'=>false,'message'=>'Only Course and Bundles are supported','data'=>array());
                    }
                }else{
                    $resultArray = array('status'=>false,'message'=>'porduct_id is Mandatory','data'=>array());
                }
            }else{
                $resultArray = array('status'=>false,'message'=>'No Data Found against Product Id '.$productTypeId,'data'=>array());
            }
        }else{
            $resultArray = array('status'=>false,'message'=>'product_type_id is Mandatory','data'=>array());
        }
        $this->view->data = $resultArray;
    }

    public function getCurrencyDataById(){
        $currencyId = $this->getRequest()->getParam('currency_id');
        if(!empty($currencyId)){
            $currencyObj = new Model_Currency();
            $currencyData = $currencyObj->fetchAll(array('currency_id =?'=>$currencyId));
            if(!empty($currencyData)){
                    $resultArray = array('status'=>true,'message'=>'success','data'=>$currencyData);
            }else{
                $resultArray = array('status'=>false,'message'=>'no records found','data'=>array());
            }
        }else{
            $resultArray = array('status'=>false,'message'=>'parameters not valid','data'=>array());
        }
        $this->view->data = $resultArray;
    }

    public function getCertificatesForCourses(){
        $courseIds = $this->getRequest()->getParam('course_id');
        if(!empty($courseIds) && is_array($courseIds)){
            $objCertificate = new Model_Certificates();
            $certificateData = $objCertificate->getCertificateListings($courseIds);
            if(!empty($certificateData))
                $resultArray = array('status'=>true,'message'=>'success','data'=>$certificateData);
            else
                $resultArray = array('status'=>false,'message'=>'no data found','data'=>array());
        }else{
          $resultArray = array('status'=>false,'message'=>'Invalid parameters','data'=>array());
        }
        $this->view->data = $resultArray;

    }


    /*
     * Get region specific contact number of a country
     *
     * @param INT countryId
     *
     * @return contact number
     */
    public function getCountryContactNumber($countryId) {
        $countryRegionModel = new Model_CountryRegion();
        $contactNumber = $countryRegionModel->getCountryNumber($countryId);
        if(!empty($contactNumber)) {
            $status = true;
            $message = 'success';
            $dataArr = array($contactNumber);
        } else {
            $status = false;
            $message = 'no contact number found for this country';
            $dataArr = array();
        }
        $resultArr = array('status' => $status, 'message' => $message, 'data' => $dataArr);
        $this->view->data = $resultArr;
    }

    protected function getLectureSeoForm(){
        $lectureId = $this->getRequest()->getParam('lectureId');
        $isFirstChapter = $this->getRequest()->getParam('isFirstChapter');
        $lectureModel = new Model_Lecture();
        $this->view->lectureData = $lectureModel->getLectureSeo($lectureId, $isFirstChapter);
        $this->view->data = $this->view->render('common/lecture-seo-update.phtml');
    }

    protected function saveLectureSeo() {
        $request = $this->getRequest()->getPost();
        $seoModel = new Model_Lecture();
        $this->view->data = array(
            'status' => 'failed'
        );
        if(!$request['title']) {
            $this->view->data['message'] = 'Title can not be empty';
            return false;
        }
        if(!$request['description']) {
            $this->view->data['message'] = 'Description can not be empty';
            return false;
        }
        if(!$request['h1Tag']) {
            $this->view->data['message'] = 'h1Tag can not be empty';
            return false;
        }
        if(!$request['url']) {
            $this->view->data['message'] = 'url can not be empty';
            return false;
        }
        if(preg_match("/([^a-z0-9\-\/]+)/", $request['url'], $match)) {
            $this->view->data['message'] = 'url is invalid';
            return false;
        }
        if($seoModel->saveLectureSeo($request)) {
            $this->view->data = array(
                'status' => 'success'
            );
        }
        else {
            $this->view->data['message'] = 'url already exists';
        }

    }

    public function updateLearners(){
        $request = $this->getRequest()->getPost();
        $productId = '';
        $productTypeId = '';
        if(array_key_exists('product_id', $request))
            $productId = $request['product_id'];
        if(array_key_exists('product_type_id', $request))
            $productTypeId = $request['product_type_id'];

        if( !empty($productId) && !empty($productTypeId) ){
            $courseDao = new BaseApp_Dao_Courses();
            if($productTypeId == BaseApp_Dao_ProductTypes::TYPE_ID_COURSE){
                try{
                    $courseDao->getDb()->update($courseDao->getName(), array('learners' => new Zend_Db_Expr('COALESCE(learners,0) + 1') ), array('course_id = ?' => $productId));
                    $resultArray = array('status'=>true,'message'=>'success','data'=>array());
                }catch(Exception $e){
                    $resultArray = array('status'=>false,'message'=>'fail','data'=>array());
                }
            }elseif($productTypeId == BaseApp_Dao_ProductTypes::TYPE_ID_BUNDLE){
                try{
                    $bundleDao = new BaseApp_Dao_Bundles($productId);
                    $bundleData = $bundleDao->toArray();
                    if(!empty($bundleData)){
                        $bundleDao->getDb()->update($bundleDao->getName(), array('learners' => new Zend_Db_Expr('COALESCE(learners,0) + 1') ), array('bundle_id = ?' => $productId));
                        $courseIdArr = explode(',',$bundleData['course_id']);
                        $courseDao->getDb()->update($courseDao->getName(), array('learners' => new Zend_Db_Expr('COALESCE(learners,0) + 1') ), array('course_id in (?)' => $courseIdArr));
                        $resultArray = array('status'=>true,'message'=>'success','data'=>array());
                    }else{
                        $resultArray = array('status'=>false,'message'=>'fail','data'=>array());
                    }
                }catch(Exception $e){
                    $resultArray = array('status'=>false,'message'=>'fail','data'=>array());
                }
            }elseif($productTypeId == BaseApp_Dao_ProductTypes::TYPE_ID_PASS){
                $workshopDao = new BaseApp_Dao_Workshop();
                $workshopDao->updatePassLearners();
                $resultArray = array('status'=>true,'message'=>'success','data'=>array());
            }else{
                $resultArray = array('status'=>false,'message'=>'Invalid Product Type','data'=>array());
            }
        }else{
            $resultArray = array('status'=>false,'message'=>'parameters not valid','data'=>array());
        }
        $this->view->data = $resultArray;
    }

    public function getCoursesByTrainingTypes(){
        $request = $this->getRequest();
        $trainingId = $request->getParam('training_id');
        $isB2b = $request->getParam('is_b2b');
        $getElearningId = $request->getParam('get_elearning_id');
        $includeDisablesCourses = $request->getParam('include_disabled_courses');
        if(empty($trainingId)){
            $resultArray = array('status'=>false,'message'=>'parameters not valid','data'=>array());
        }else{
            $objCourses = new Model_Courses();
            $resultSet =  $objCourses->fetchAllCoursesByTrainingId($trainingId,$isB2b,$getElearningId, $includeDisablesCourses);
            if(!empty($resultSet))
                $resultArray = array('status'=>true,'message'=>'success','data'=>$resultSet);
            else
                $resultArray = array('status'=>false,'message'=>'no result found','data'=>array());
        }
        $this->view->data = $resultArray;
    }

    public function fetchAccessDays(){
        $request = $this->getRequest();
        $courseId = $request->getParam('course_id');
        $trainingId = $request->getParam('training_id');
        $countryId = $request->getParam('country_id');
        $productTypeId = $request->getParam('product_type_id');
        $getMpAccessDays = $request->getParam('mp_access_days');
         if(empty($courseId) || empty($trainingId) || empty($productTypeId)){
            $resultArray = array('status'=>false,'message'=>'parameters not valid','data'=>array());
        }else{
            if($productTypeId == BaseApp_Dao_ProductTypes::TYPE_ID_COURSE){
                if( $trainingId == BaseApp_Dao_TrainingTypes::TYPE_ELEARNING){
                    $objCourses = new Model_Courses();
                    $accessdaysDetails = $objCourses->getCoursesTrainingTypeData($courseId);
                    if(empty($accessdaysDetails))
                        $resultArray = array('status'=>false,'message'=>'no data found','data'=>array());
                    else
                        $resultArray = array('status'=>true,'message'=>'success','data'=>$accessdaysDetails);
                }elseif($trainingId == BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS) {
                    if(empty($countryId)){
                        $resultArray = array('status'=>false,'message'=>'country Id is Mandatory','data'=>array());
                    }else{
                        $objPricing = new Model_Pricings();
                        $accessdaysDetails = $objPricing->fetchAccessDays($courseId,$trainingId,$countryId);
                        if(empty($accessdaysDetails)){
                            $resultArray = array('status'=>false,'message'=>'no data found','data'=>array());
                        }else{
                            $resultArray = array('status'=>true,'message'=>'success','data'=>$accessdaysDetails);
                        }
                    }
                }else{
                    $resultArray = array('status'=>false,'message'=>'Invalid training Type','data'=>array());
                }
            }elseif($productTypeId == BaseApp_Dao_ProductTypes::TYPE_ID_BUNDLE){
                if($trainingId == BaseApp_Dao_TrainingTypes::TYPE_ELEARNING || $trainingId == BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS){
                    $accessDaysList = array();
                    $modelObj = new Model_SubscriptionPricing();
                    $conds = array('linkable_type=?'=> 'bundle', 'linkable_id=?'=>$courseId, 'country_id=?'=>$countryId);
                    $pricingDataAll = $modelObj->fetchAll($conds, array(), false);
                    $accessObj = new Model_AccessDays();
                    $trainingType = ($trainingId == BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS) ? BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS_NAME : BaseApp_Dao_TrainingTypes::TYPE_ELEARNING_NAME;
                    $accessDaysAll = $accessObj->getAccessDaysByTrainingType($trainingType);
                    //Important
                    //by default we get only 365 for mp/bundle with TYPE_ONLINE_CLASSROOM_PASS
                    // so to get all access days for master program in custom payment we are hardcoding training type to osl
                    // as the pricing is set to osl for now
                    if (!empty($getMpAccessDays)) {
                        $accessDaysAll = $accessObj->getAccessDays(BaseApp_Dao_TrainingTypes::TYPE_ELEARNING);
                    }

                    if($trainingId == BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS && (empty($getMpAccessDays) || $getMpAccessDays != 1)) {
                        // LVC directly form config
                        $resultArray = array('status'=>true,'message'=>'success','data'=>$accessDaysAll);
                    } else {
                        if($pricingDataAll) {
                            $accessDaysList = array();
                            foreach($pricingDataAll as $pricingData) {
                                if (!empty($pricingData['access_day_id']))
                                    $accessDaysList[$accessDaysAll[$pricingData['access_day_id']]] = $accessDaysAll[$pricingData['access_day_id']];
                            }
                        }
                        if(empty($accessDaysList)){
                            $modelCountry = new Model_Country();
                            $countryData =  current($modelCountry->fetchAll(array('country_id=?'=>$countryId), array(), false));
                            if(empty($countryData) || empty($countryData['cluster_id']))
                                $resultArray = array('status'=>false,'message'=>'invalid country Id','data'=>array());
                            else
                                $conds = array('linkable_type=?'=> 'bundle', 'linkable_id=?'=>$courseId, 'cluster_id=?'=>$countryData['cluster_id']);
                                $pricingDataAll = $modelObj->fetchAll($conds);
                                if($pricingDataAll) {
                                    $accessDaysList = array();
                                    foreach($pricingDataAll as $pricingData) {
                                        if(!empty($accessDaysAll[$pricingData['access_day_id']]))
                                            $accessDaysList[$accessDaysAll[$pricingData['access_day_id']]] = $accessDaysAll[$pricingData['access_day_id']];
                                    }
                                }
                        }
                        if(!empty($accessDaysList))
                            $resultArray = array('status'=>true,'message'=>'success','data'=>$accessDaysList);
                        else
                            $resultArray = array('status'=>false,'message'=>'success','data'=>array());
                    }
                }else{
                    $resultArray = array('status'=>false,'message'=>'In valid data passed','data'=>array());
                }
            }elseif($productTypeId == BaseApp_Dao_ProductTypes::TYPE_ID_MOM){
                if($trainingId == BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS){
                    $accessDaysList = array();
                    $modelObj = new Model_SubscriptionPricing();
                    $conds = array('linkable_type=?'=> 'master_of_masters', 'linkable_id=?'=>$courseId, 'country_id=?'=>$countryId);
                    $pricingDataAll = $modelObj->fetchAll($conds, array(), false);
                    $accessObj = new Model_AccessDays();
                    $trainingType = BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS_NAME;
                    $accessDaysAll = $accessObj->getAccessDaysByTrainingType($trainingType);
                    //Important
                    //by default we get only 365 for mp/bundle with TYPE_ONLINE_CLASSROOM_PASS
                    // so to get all access days for master program in custom payment we are hardcoding training type to osl
                    // as the pricing is set to osl for now
                    if (!empty($getMpAccessDays)) {
                        $accessDaysAll = $accessObj->getAccessDays(BaseApp_Dao_TrainingTypes::TYPE_ELEARNING);
                    }

                    if($trainingId == BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS && (empty($getMpAccessDays) || $getMpAccessDays != 1)) {
                        // LVC directly form config
                        $resultArray = array('status'=>true,'message'=>'success','data'=>$accessDaysAll);
                    } else {
                        if($pricingDataAll) {
                            $accessDaysList = array();
                            foreach($pricingDataAll as $pricingData) {
                                if (!empty($pricingData['access_day_id']))
                                    $accessDaysList[$accessDaysAll[$pricingData['access_day_id']]] = $accessDaysAll[$pricingData['access_day_id']];
                            }
                        }
                        if(empty($accessDaysList)){
                            $modelCountry = new Model_Country();
                            $countryData =  current($modelCountry->fetchAll(array('country_id=?'=>$countryId), array(), false));
                            if(empty($countryData) || empty($countryData['cluster_id']))
                                $resultArray = array('status'=>false,'message'=>'invalid country Id','data'=>array());
                            else
                                $conds = array('linkable_type=?'=> 'master_of_masters', 'linkable_id=?'=>$courseId, 'cluster_id=?'=>$countryData['cluster_id']);
                                $pricingDataAll = $modelObj->fetchAll($conds);
                                if($pricingDataAll) {
                                    $accessDaysList = array();
                                    foreach($pricingDataAll as $pricingData) {
                                        if(!empty($accessDaysAll[$pricingData['access_day_id']]))
                                            $accessDaysList[$accessDaysAll[$pricingData['access_day_id']]] = $accessDaysAll[$pricingData['access_day_id']];
                                    }
                                }
                        }
                        if(!empty($accessDaysList))
                            $resultArray = array('status'=>true,'message'=>'success','data'=>$accessDaysList);
                        else
                            $resultArray = array('status'=>false,'message'=>'success','data'=>array());
                    }
                }else{
                    $resultArray = array('status'=>false,'message'=>'In valid data passed','data'=>array());
                }
            }elseif($productTypeId == BaseApp_Dao_ProductTypes::TYPE_ID_PASS){
                if( $trainingId == BaseApp_Dao_TrainingTypes::TYPE_LVC){
                    $objPricing = new Model_Pricings();
                    $accessdaysDetails = $objPricing->fetchAccessDays(LVC_PASS_DUMMY_COURSE_ID,$trainingId,US_COUNTRY_ID);
                    if(empty($accessdaysDetails)){
                        $resultArray = array('status'=>false,'message'=>'no data found','data'=>array());
                    }else{
                        $resultArray = array('status'=>true,'message'=>'success','data'=>$accessdaysDetails);
                    }
                }
            }
        }
        $this->view->data = $resultArray;
    }

    public function getTrainingTypeForCountryCityCourseV5(){
        $productTypeId = $this->getRequest()->getParam('product_type_id');
        $productId = $this->getRequest()->getParam('product_id');
        $countryId = $this->getRequest()->getParam('country_id');
        $cityId = $this->getRequest()->getParam('city_id');
        $isB2b = $this->getRequest()->getParam('is_b2b');
        if($productTypeId){
            $productObj = new BaseApp_Dao_ProductTypes();
            $productData = current($productObj->fetchAll(array('product_type_id =?'=>$productTypeId)));
            if(!empty($productData)){
                if(!empty($productId)){
                    $productName = $productData['product_type_name'];
                    if($productName == BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE){
                        $objCourses = new Model_Courses();
                        $resArr = array();
                        if(true === $objCourses->checkOnlineCourse($productId))
                            $resArr[BaseApp_Dao_TrainingTypes::TYPE_ELEARNING] = "Online Self Learning";
                        if(!empty($countryId)){
                            $resultData = $objCourses->getTrainingTypeForCountryCityCourseV3($productId,$countryId,$cityId,$isB2b);
                            if(!empty($resultData)){
                                if(in_array(BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM, $resultData))
                                    $resArr[BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM] = "Classroom";
                                if(in_array(BaseApp_Dao_TrainingTypes::TYPE_LVC, $resultData)){
                                    if(empty($isB2b))
                                        $resArr[BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS] = BaseApp_Dao_TrainingTypes::CART_ONLINE_CLASSROOM_PASS;
                                    else
                                        $resArr[BaseApp_Dao_TrainingTypes::TYPE_LVC] = BaseApp_Dao_TrainingTypes::CART_ILT;
                                }
                            }
                        }
                        if(!empty($resArr)){
                            $resultArray = array('status'=>true,'message'=>'success','data'=>$resArr);
                            $courseInfo=$objCourses->getCourseById($productId);
                            if(!empty($courseInfo)){
                                $labelIds=$courseInfo['label_id'];
                                $primaryLabelId = $courseInfo['primary_label_id'];
                                $resultArray['categoryInfo']['primaryLabelId']=$primaryLabelId;
                                $resultArray['categoryInfo']['labelIds']=$labelIds;
                            }
                        }
                        else
                            $resultArray = array('status'=>false,'message'=>'No Data Found','data'=>array());
                    }elseif($productName == BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES){
                        $objBundle= new Model_Bundles();
                        $resArr = array();
                        if(true === $objBundle->checkBundlePricings($productId))
                            $resArr[BaseApp_Dao_TrainingTypes::TYPE_ELEARNING] = "Online Self Learning";
                        if(!empty($countryId)){
                            $resultData = $objBundle->getTrainingTypeForCountryCityBundleV3($productId,$countryId,$cityId,$isB2b);
                            if(!empty($resultData)){
                                if(in_array(BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM, $resultData))
                                    $resArr[BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM] = "Classroom";
                                    if(in_array(BaseApp_Dao_TrainingTypes::TYPE_LVC, $resultData)){
                                        $resArr[BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS] = BaseApp_Dao_TrainingTypes::CART_ONLINE_CLASSROOM_PASS;
                                    }
                            }
                        }
                        if(!empty($resArr))
                            $resultArray = array('status'=>true,'message'=>'success','data'=>$resArr);
                        else
                            $resultArray = array('status'=>false,'message'=>'No Data Found','data'=>array());

                        $isMasterProgram = intval($objBundle->isMasterProgram($productId));
                        $resultArray['isMasterProgram'] = $isMasterProgram;
                    } else if($productName == BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_MOM){
                        $objBundle= new Model_Bundles();
                        $resArr = array();
                        if(true === $objBundle->checkMomPricings($productId))
                            $resArr[BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS] = BaseApp_Dao_TrainingTypes::CART_ONLINE_CLASSROOM_PASS;;
                        if(!empty($resArr))
                            $resultArray = array('status'=>true,'message'=>'success','data'=>$resArr);
                        else
                            $resultArray = array('status'=>false,'message'=>'No Data Found','data'=>array());
                    }
                    else{
                        $resultArray = array('status'=>false,'message'=>'Only Course and Bundles are supported','data'=>array());
                    }
                }else{
                    $resultArray = array('status'=>false,'message'=>'porduct_id is Mandatory','data'=>array());
                }
            }else{
                $resultArray = array('status'=>false,'message'=>'No Data Found against Product Id '.$productTypeId,'data'=>array());
            }
        }else{
            $resultArray = array('status'=>false,'message'=>'product_type_id is Mandatory','data'=>array());
        }
        $this->view->data = $resultArray;
    }

    public function getOneCoursePassBatches(){
        $request = $this->getRequest();
        $startDate = $this->getRequest()->getParam('start_date');
        $countryId = $this->getRequest()->getParam('country_id');
        $priceId = $request->getParam('price_id');
        $courseId = '';
        $startDate = date('Y-m-d H:i:s', $startDate);
        $endDate = date('Y-m-d H:i:s', strtotime($startDate.' + 90 day'));
        $userEmail ='';
        $resultData = array();
        if($priceId && $startDate && $countryId){
            $objPricing = new Model_Pricings();
            $objPricing->setFetchDisabled(true);
            $priceDetails = current($objPricing->fetchAll(array('pricing_id = ?'=>$priceId), array('columns'=>array('course_id'),'limit' => 1)));
            if(!empty($priceDetails)){
                $courseId = $priceDetails['course_id'];
            }
            if(empty($courseId)){
                $resultArray = array('status'=>false,'message'=>'no course Found against pricing Id','data'=>array());
            }else{
                $objWorkShop = new Model_Workshop();
                $workshopData = $objWorkShop->getLvcWorkshop($countryId,$startDate,$endDate,$userEmail,$courseId,'',true);
                if(!empty($workshopData)){
                    $objCountryRegion = new BaseApp_Dao_CountryRegion();
                    $support_number = CONTACT_US_ROW;
                    $supportNumber = $objCountryRegion->getCountryNumber($countryId);
                    if(!empty($supportNumber)){
                        $support_number = $supportNumber;
                    }
                    $workshopData['support_number'] = $support_number;
                    $resultArray = array('status'=>true,'message'=>'success','data'=>$workshopData);
                }else{
                    $resultArray = array('status'=>false,'message'=>'no Data Found','data'=>array());
                }
            }
        }else{
            $resultArray = array('status'=>false,'message'=>'invalid Parameters','data'=>array());
        }
        $this->view->data = $resultArray;
    }

    public function fetchPricingId(){
        $request = $this->getRequest();
        $trainingTypeId = $this->getRequest()->getParam('trainingType_id');
        $courseId = $this->getRequest()->getParam('course_id');
        $countryId = $this->getRequest()->getParam('country_id');
        $resultData = array();
        if($trainingTypeId && $courseId && $countryId){
            $objAccessDays = new Model_AccessDays();
            $accessdaysDetails = current($objAccessDays->fetchAll(array('noOfDays = ?'=>PASS_ACCESS_DAYS,'type =?'=>'ilt')));
            $accessdayId = isset($accessdaysDetails['day_id']) ? $accessdaysDetails['day_id'] : '';
            if(empty($accessdayId)){
                $resultArray = array('status'=>false,'message'=>'no access days found','data'=>array());
            }else{
                $objPricing = new Model_Pricings();
                $priceDetails = current($objPricing->fetchPricingId($courseId,$trainingTypeId,$accessdayId,$countryId));
                if(empty($priceDetails)){
                    $resultArray = array('status'=>false,'message'=>'no Data Found','data'=>array());
                }else{
                    $resultArray = array('status'=>true,'message'=>'success','data'=>$priceDetails);
                }
            }
        }else{
            $resultArray = array('status'=>false,'message'=>'invalid Parameters','data'=>array());
        }
        $this->view->data = $resultArray;
    }

    public function fetchTrainigTypeByPrice(){
        $request = $this->getRequest();
        $priceId = $this->getRequest()->getParam('price_id');
        $fetchDisableFlag = $this->getRequest()->getParam('disable');
        $resultData = array();
        if($priceId){
            $objPricing = new Model_Pricings();
            if(isset($fetchDisableFlag) && !empty($fetchDisableFlag))
                $objPricing->setFetchDisabled(true);

            $priceDetails = current($objPricing->fetchAll(array('pricing_id = ?'=>$priceId), array('columns'=>array('training_id'))));
            if(empty($priceDetails)){
                $resultArray = array('status'=>false,'message'=>'no Data Found','data'=>array());
            }else{
                $resultArray = array('status'=>true,'message'=>'success','data'=>$priceDetails);
            }
        }else{
            $resultArray = array('status'=>false,'message'=>'invalid Parameters','data'=>array());
        }
        $this->view->data = $resultArray;
    }

    public function getCountryDetailsByCode() {
        $request = $this->getRequest();
        $countryCode = $this->getRequest()->getParam('code');
        $fetchDisableFlag = $this->getRequest()->getParam('disable');
        $resultData = array();
        if($countryCode){
            $objCountry = new Model_Country();
            if(isset($fetchDisableFlag) && !empty($fetchDisableFlag))
                $objCountry->setFetchDisabled(true);
            $countryDetails = current($objCountry->fetchAll(array('code = ?'=>$countryCode)));
            if(empty($countryDetails)){
                $resultArray = array('status'=>false,'message'=>'no Data Found','data'=>array());
            }else{
                $resultArray = array('status'=>true,'message'=>'success','data'=>$countryDetails);
            }
        }else{
            $resultArray = array('status'=>false,'message'=>'invalid Parameters','data'=>array());
        }
        $this->view->data = $resultArray;
    }

    public function getCountryDetailsByIp() {
        $ip = $this->getRequest()->getParam('ip');
        $cdnUtil = new BaseApp_Utility_Cdn();
        $ip = $cdnUtil->getIpAddress();
        $city  = new BaseApp_Dao_City();
        $cityData = $city->getCityByIp($ip);
        $countryCode = $cityData['countryCode'];
        $fetchDisableFlag = $this->getRequest()->getParam('disable');
        if ($countryCode) {
            $objCountry = new Model_Country();
            if (isset($fetchDisableFlag) && !empty($fetchDisableFlag)) {
                $objCountry->setFetchDisabled(true);
            }
            $countryDetails = current($objCountry->fetchAll(array('code = ?' => $countryCode)));
            if (empty($countryDetails)) {
                $resultArray = array('status' => false, 'message' => 'no Data Found', 'data' => array());
            } else {
                $resultArray = array('status' => true, 'message' => 'success', 'data' => $countryDetails);
            }
        } else {
            $resultArray = array('status' => false, 'message' => 'invalid Parameters', 'data' => array());
        }
        $this->view->data = $resultArray;
    }

    public function getPricingIdForLvcPassV1(){
        $request = $this->getRequest();
        $trainingTypeId = $this->getRequest()->getParam('trainingType_id');
        $courseId = $this->getRequest()->getParam('course_id');
        $countryId = $this->getRequest()->getParam('country_id');
        $accessDays = $this->getRequest()->getParam('accessDays');
        $resultData = array();
        if($trainingTypeId && $courseId && $countryId && $accessDays){
            $objTt = new Model_TrainingTypes($trainingTypeId);
            $trainingType = $objTt->type;
            if(empty($trainingType)){
                $resultArray = array('status'=>false,'message'=>'Invalid Training Id Passed','data'=>array());
            }else{
                $objAccessDays = new Model_AccessDays();
                $accessdaysDetails = current($objAccessDays->fetchAll(array('type = ?'=>$trainingType,'noOfDays =?'=>$accessDays)));
                if(empty($accessdaysDetails)){
                    $resultArray = array('status'=>false,'message'=>'Invalid Access Days Passed','data'=>array());
                }else{
                    $accessdayId = $accessdaysDetails['day_id'];
                    if($courseId == LVC_PASS_DUMMY_COURSE_ID)
                        $countryId = DEFAULT_COUNTRY_ID;
                    $objPricing = new Model_Pricings();
                    $priceDetails = current($objPricing->fetchPricingId($courseId,$trainingTypeId,$accessdayId,$countryId));
                    if(empty($priceDetails)){
                        $resultArray = array('status'=>false,'message'=>'no Data Found','data'=>array());
                    }else{
                        $eLearningIds = array();
                        $objCourses = new Model_Courses($courseId);
                        $workshopDao = new BaseApp_Dao_Workshop();
                        if($courseId == LVC_PASS_DUMMY_COURSE_ID){
                            $lvcCourseIds = $workshopDao->getLVCPassCourses();
                            $eLearningIds = $objCourses->getPassCourseDetailsV1($lvcCourseIds);
                        }else{
                            $eLearningIds = $objCourses->getPassCourseDetailsV1($courseId);
                        }
                        $priceDetails['passAccessDays'] = PASS_ACCESS_DAYS;
                        $priceDetails['elearningAccessDays'] = ONLINE_CLASSROOM_PASS_OSL_ACCESS_DAYS;
                        $priceDetails['passDetails']['courseIds'] = $eLearningIds;
                        $resultArray = array('status'=>true,'message'=>'success','data'=>$priceDetails);
                    }
                }
            }
        }else{
            $resultArray = array('status'=>false,'message'=>'invalid Parameters','data'=>array());
        }
        $this->view->data = $resultArray;
    }

    public function getPricingIdForLvcPass(){
        $request = $this->getRequest();
        $trainingTypeId = $this->getRequest()->getParam('trainingType_id');
        $courseId = $this->getRequest()->getParam('course_id');
        $countryId = $this->getRequest()->getParam('country_id');
        $accessDays = $this->getRequest()->getParam('accessDays');
        $resultData = array();
        if($trainingTypeId && $courseId && $countryId && $accessDays){
            $objTt = new Model_TrainingTypes($trainingTypeId);
            $trainingType = $objTt->type;
            if(empty($trainingType)){
                $resultArray = array('status'=>false,'message'=>'Invalid Training Id Passed','data'=>array());
            }else{
                $objAccessDays = new Model_AccessDays();
                $accessdaysDetails = current($objAccessDays->fetchAll(array('type = ?'=>$trainingType,'noOfDays =?'=>$accessDays)));
                if(empty($accessdaysDetails)){
                    $resultArray = array('status'=>false,'message'=>'Invalid Access Days Passed','data'=>array());
                }else{
                    $accessdayId = $accessdaysDetails['day_id'];
                    if($courseId == LVC_PASS_DUMMY_COURSE_ID)
                        $countryId = DEFAULT_COUNTRY_ID;
                    $objPricing = new Model_Pricings();
                    $priceDetails = current($objPricing->fetchPricingId($courseId,$trainingTypeId,$accessdayId,$countryId));
                    if(empty($priceDetails)){
                        $resultArray = array('status'=>false,'message'=>'no Data Found','data'=>array());
                    }else{
                        $eLearningIds = array();
                        $objCourses = new Model_Courses($courseId);
                        $workshopDao = new BaseApp_Dao_Workshop();
                        if($courseId == LVC_PASS_DUMMY_COURSE_ID){
                            $lvcCourseIds = $workshopDao->getLVCPassCourses();
                            $eLearningIds = $objCourses->getPassCourseDetails($lvcCourseIds);
                        }else{
                            $eLearningIds = $objCourses->getPassCourseDetails($courseId);
                        }
                        $priceDetails['passAccessDays'] = PASS_ACCESS_DAYS;
                        $priceDetails['elearningAccessDays'] = ONLINE_CLASSROOM_PASS_OSL_ACCESS_DAYS;
                        $priceDetails['passDetails']['courseIds'] = $eLearningIds;
                        $resultArray = array('status'=>true,'message'=>'success','data'=>$priceDetails);
                    }
                }
            }
        }else{
            $resultArray = array('status'=>false,'message'=>'invalid Parameters','data'=>array());
        }
        $this->view->data = $resultArray;
    }


    protected function getPassScheduleDetail(){
        $success = true;
        $request = $this->getRequest()->getPost();
        $passInfo = $request['passInfo'];
        $userEmail = isset($request['user_email']) ? $request['user_email'] : '';
        $isActive = isset($request['is_active']) ? $request['is_active'] : '';
        $isSold = isset($request['is_sold']) ? $request['is_sold'] : '';
        $isFreeTrial = (array_key_exists('is_free_trial', $request) && filter_var($request['is_free_trial'], FILTER_VALIDATE_BOOLEAN) === TRUE) ? true : false;
        $passData = array();
        try{
            $passData = @unserialize($passInfo);
            if(empty($passData)){
                 $passData = utf8_decode($passData);
                 $passData = unserialize($passData);
             }
        }catch(Exception $e){
            $message = 'some error occured';
            $success = false;
        }

        if(empty($passData) || !is_array($passData)) {
            $message = 'passInfo params missing';
            $success = false;
        }

        if(!$success) {
            $this->view->data = array('status'=>false,'message'=>'invalid Parameters','data'=>array());
            return false;
        }
        $courseId = '';
        $resultArray = array();
        $workshopObj = new BaseApp_Dao_Workshop();
        foreach ($passData as $key => $value) {
            $priceId = $value['priceId'];
            $courseId = $value['courseId'];
            $startDate = date('Y-m-d', strtotime($value['startDate']));
            /**
             * IF FREE TRIAL IS SET THEN CALCULATE THE END DATE BY ADDING "ONLINE_CLASSROOM_PASS_ACCESS_DAYS" TO START DATE.
             */
            if ($isFreeTrial == true) {
                $config = Zend_Registry::get('config');
                $onlineClassRoomPassDays = $config->get('ONLINE_CLASSROOM_PASS_ACCESS_DAYS')->toArray();
                if (is_array($onlineClassRoomPassDays) && !empty($onlineClassRoomPassDays[0])) {
                    $noOfDaysToAdd = "+$onlineClassRoomPassDays[0] days";
                    $endDate = date('Y-m-d', strtotime($noOfDaysToAdd . $startDate));
                } else {
                    $endDate = date('Y-m-d', strtotime($value['endDate']));
                }
            } else {
                $endDate = date('Y-m-d', strtotime($value['endDate']));
            }
            $countryId = $value['countryId'];
            if(!empty($courseId)){
                //get lvc workshops including running workshops, hence $includeRunningWs = true
                $workshopScedule = $workshopObj->getLvcWorkshop($countryId, $startDate, $endDate,$userEmail,$courseId,$priceId,false,$isActive,$isSold, true);
                if(!empty($workshopScedule))
                    $resultArray = array_merge($workshopScedule,$resultArray);
            }else{
                $this->view->data = array('status'=>false,'message'=>'course id is Mandatory','data'=>array());
            }
        }
        if(empty($resultArray)) {
            $this->view->data = array('status'=>false,'message'=>'no data found','data'=>array());
            return false;
        }
        $this->array_sort_by_column($resultArray, 'startDate');
        $this->view->data = array('status'=>true,'message'=>'success','data'=>$resultArray);
    }

    public function fetchPassScheduleCsv() {
        $success = true;
        $request = $this->getRequest()->getPost();
        $passInfo = $request['passInfo'];
        $passData = array();
        try{
            $passData = @unserialize($passInfo);
            if(empty($passData)){
                 $passData = utf8_decode($passData);
                 $passData = unserialize($passData);
             }
        }catch(Exception $e){
            $message = 'some error occured';
            $success = false;
        }

        if(empty($passData) || !is_array($passData)) {
            $message = 'passInfo params missing';
            $success = false;
        }

        if(!$success) {
            $this->view->data = array(
                'success' => false,
                'message' => $message
            );
            return false;
        }
        $resultArray = array();
        $workshopObj = new BaseApp_Dao_Workshop();
        foreach ($passData as $key => $value) {
            $priceId = $value['priceId'];
            $objPricing = new Model_Pricings($priceId);
            $courseId = $objPricing->course_id;
            $startDate = date('Y-m-d', strtotime($value['startDate']));
            $endDate = date('Y-m-d', strtotime($value['endDate']));
            $countryId = $value['countryId'];
            if(!empty($courseId)){
                if($courseId == LVC_PASS_DUMMY_COURSE_ID)
                    $courseId = '';
                $workshopScedule = $workshopObj->getLvcWorkshopForSchedule($countryId, $startDate, $endDate,$courseId);
                if(!empty($workshopScedule))
                    $resultArray = array_merge($workshopScedule,$resultArray);
            }
        }
        if(empty($resultArray)) {
            $this->view->data = array(
                'success' => false,
                'message' => 'No workshops found in given dates'
            );
            return false;
        }
        $filename = sprintf("%s%ssimplilearn-batch_details.csv", sys_get_temp_dir(), DIRECTORY_SEPARATOR);
        $fp = fopen($filename, 'w');
        ob_start();
        header('Content-Description: File Transfer');
        header('Content-Type: application/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename=simplilearn-batch_details.csv');

        $headerFlag = false;
        $this->array_sort_by_column($resultArray, 'start_date');
        foreach ($resultArray as $workshopSceduleData) {
            unset($workshopSceduleData['start_date']);
            if(!$headerFlag){
                fputcsv($fp, array_keys($workshopSceduleData));
                $headerFlag = true;
            }
            fputcsv($fp, array_values($workshopSceduleData));
        }
        readfile($filename);
        ob_flush();
        fclose($fp);
        unlink($filename);
        exit;
    }

    private function array_sort_by_column(&$array, $column, $direction = SORT_ASC) {
        $reference_array = array();
        foreach($array as $key => $row) {
            $reference_array[$key] = $row[$column];
        }
        array_multisort($reference_array, $direction, $array);
    }

    public function getReviewsByUserEmail(){
        $request = $this->getRequest();
        $emailId = $request->getParam('email');
        if(!empty($emailId)){
            $objReviews = new Model_Reviews();
            $reviewsData = $objReviews->fetchAll(array('email =?'=>$emailId,'isApproved =?'=>1));
            if(!empty($reviewsData))
                $resultArray = array('status'=>true,'message'=>'success','data'=>$reviewsData);
            else
                $resultArray = array('status'=>false,'message'=>'No Data Found','data'=>array());
        }else{
          $resultArray = array('status'=>false,'message'=>'Invalid parameters','data'=>array());
        }
        $this->view->data = $resultArray;
    }

    public function fetchCertificateForAllCourse(){
        $request = $this->getRequest();
        $objCourses = new Model_Courses();
        $certificateData = $objCourses->fetchCertificateForAllCourse();
        if(!empty($certificateData))
            $resultArray = array('status'=>true,'message'=>'success','data'=>$certificateData);
        else
            $resultArray = array('status'=>false,'message'=>'No Data Found','data'=>array());
        $this->view->data = $resultArray;
    }

    public function getSeasonPassDetails(){
        $request = $this->getRequest();
        $passId = $request->getParam('pass_id');
        if(!empty($passId)){
            $passObj = new Model_Pass();
            $passData = current($passObj->fetchAll(array('pass_id =?'=>$passId)));
            if(!empty($passData)){
                $resultArray = array('status'=>true,'message'=>'success','data'=>$passData);
            }else{
                $resultArray = array('status'=>false,'message'=>'no Pass Found','data'=>array());
            }
        }else{
            $resultArray = array('status'=>false,'message'=>'pass Id mandatory field','data'=>array());
        }
        $this->view->data = $resultArray;
    }

    public function getCourseIdbyElearning(){
        $request = $this->getRequest();
        $eLearningId = $request->getParam('primary_eLearning_id');
        if(!empty($eLearningId)){
            $objCourse = new Model_Courses();
            $courseData = current($objCourse->fetchAll( array('primary_eLearning_id =?'=>$eLearningId),
                                                array('columns'=>array('course_id'))
                                               ));
            if(!empty($courseData)){
                $resultArray = array('status'=>200,'message'=>'success','data'=>$courseData);
            }else{
                $resultArray = array('status'=>404,'message'=>'no Courses Found','data'=>array());
            }
        }else{
            $resultArray = array('status'=>400,'message'=>' primary_eLearning_id mandatory field','data'=>array());
        }
        $this->view->data = $resultArray;
    }
    public function getCityDetailsByIp(){
        $request = $this->getRequest();
        $resultArray = array();
        $ipAddr = $request->getParam('ip');
        if(!empty($ipAddr)){
            $city = new BaseApp_Dao_City();
            $ipdata = explode('.', $ipAddr);
            $user_ip_num = ($ipdata[0] * 256 * 256 * 256) + ($ipdata[1] * 256 * 256) + ($ipdata[2] * 256) + ($ipdata[3]);
            $cityDetails = $city->getCityByIp($user_ip_num);
            if(!empty($cityDetails)){
                $resultArray = array('status'=>200,'message'=>'success','data'=>$cityDetails);
            }else{
                $resultArray = array('status'=>404,'message'=>'no City Found','data'=>array());
            }
        }else{
            $resultArray = array('status'=>400,'message'=>' Ip Address mandatory field','data'=>array());
        }
         $this->view->data = $resultArray;
    }


    public function getWebexSessionDetail(){
        $request = $this->getRequest();
        $uId = $request->getParam('u_id');
        $objWorkshop = new Model_Workshop();
        $arrSession = $objWorkshop->getSessionDetails($uId);
        if(count($arrSession)>0){
            $resultArray = array('status'=>200,'message'=>'success','data'=>$arrSession);
        }else{
             $resultArray = array('status'=>404,'message'=>'no webex session details found!','data'=>array());
        }
        $this->view->data = $resultArray;
    }

    public function getSessionDetailsBySessionId(){
        $request = $this->getRequest();
        $sId = $request->getParam('s_id');
        $objWorkshop = new Model_Workshop();
        $arrSession = $objWorkshop->getSessionDetailsBySessionId($sId);
        if(count($arrSession)>0){
            $arrSession[0]['noOfClass'] = empty($arrSession['0']['dates']) ? 0 : count(explode(',',$arrSession['0']['dates']));
            $resultArray = array('status'=>200,'message'=>'success','data'=>$arrSession);
        }else{
            $resultArray = array('status'=>200,'message'=>'no webex session details found!','data'=>array());
        }
        $this->view->data = $resultArray;
    }

    public function getWorkshopDetail(){
        $workshopIdArr = $this->getRequest()->getParam("workshopIds");
        if(is_array($workshopIdArr) && !empty($workshopIdArr)){
            $dateModel = new Model_Workshop();
            $arrWorkshop = $dateModel->fetchAll(array('workshop_id IN (?)'=>$workshopIdArr),array('columns'=>array('workshop_id','batch_id','course_id','country_id','city_id','webx_session_id','webx_session_pass','webx_user_id','webx_version_id','status','maxHeadCount','isSold','fromTime','toTime','timeZone', 'savedTimezone')),false);
            if(count($arrWorkshop) > 0){
                foreach($arrWorkshop AS $key => &$data){
                    $data['webx_user_pass'] = $dateModel->getWebxPassword($data['webx_user_id'],$data['webx_version_id']);
                }
                $resultArray = array('status'=>200,'message'=>'success','data'=>$arrWorkshop);
            }else{
                $resultArray = array('status'=>404,'message'=>'no workshop details found!','data'=>array());
            }
        }else{
            $resultArray = array('status'=>400,'message'=>'workshopId is mandatory field and should be array','data'=>array());
        }
        $this->view->data = $resultArray;

    }

    public function insertInSeo() {
        $request = $this->getRequest()->getPost();
        $request = $request['body'];
        if (empty($request)) {
            http_response_code(404);
            throw new Exception ('Posted data not found');
        }

        $requestArray  = is_array($request) ? $request : json_decode($request , true);
        $responseArray = array();
        $result = false;
        try {
            $requestArray['seo_url'] = trim(urldecode($requestArray['seo_url']));
            $checkSlash = substr($requestArray['seo_url'], 0,1);
            if($checkSlash != '/') {
                $requestArray['seo_url'] = trim('/'.$requestArray['seo_url']);
            }
            $modelSeo = new Model_Seo();
            $modelSeo->setFetchDisabled(true);
            $seoData  = $modelSeo->getDataByUrl($requestArray['seo_url']);
            $dataSave = array();
            $dataSave['url'] = $requestArray['seo_url'];
            $dataSave['module']      = 'default';
            $dataSave['controller']  = 'career-edge';
            $dataSave['action']      = 'details';
            $dataSave['params']      = (!empty($requestArray['id']) && !empty($requestArray['seo_url'])) ? json_encode(array('content_id' => $requestArray['id'], 'url' => $requestArray['seo_url'])) : "";
            $dataSave['h1Tag']       = isset($requestArray['h1_tag'])?$requestArray['h1_tag']:'';
            $dataSave['product_type']= isset($requestArray['primary_product_type'])? $requestArray['primary_product_type']:'';
            $dataSave['product_id']  = isset($requestArray['primary_product_id'])? $requestArray['primary_product_id']:'';
            $dataSave['linkable_type']= isset($requestArray['type'])? $requestArray['type']:'';
            $dataSave['alt_text']    = isset($requestArray['alt_text'])?$requestArray['alt_text']:'';
            $dataSave['canonical']   = isset($requestArray['canonical'])?$requestArray['canonical']:'';
            $dataSave['keyword']     = isset($requestArray['meta_keywords'])?$requestArray['meta_keywords']:'';
            $dataSave['thumb_image'] = isset($requestArray['thumbnail_image_url'])?$requestArray['thumbnail_image_url']:'';
            $isIndexed = isset($requestArray['indexed'])?$requestArray['indexed']:'';
            $dataSave['noindex']     = ($isIndexed==false? 0 : 1);
            if(isset($requestArray['status'])){
                $dataSave['status'] = (int)$requestArray['status'];
            }
            if(!empty($seoData) && $seoData['seo_id']) {
                $dataSave['seo_id'] = $seoData['seo_id'];
                $dataSave['status'] = !empty($requestArray['status']) ? (int)$requestArray['status'] : 0;
                $modelSeo->setId($dataSave['seo_id']);
                $modelSeo->setFromArray($dataSave)->update();
                $result = 1;
            } else {
                unset($dataSave['seo_id']);
                $result = $modelSeo->setFromArray($dataSave)->save();
            }
            //********************** Logic to enter in Routes also ***********//
            $db  = new Model_Default;
            $record = $db->Routes->find(array('url' => $requestArray['seo_url']))->toArray();
            if (empty($record)) {
                $insertArray = array (
                    'url' => $requestArray['seo_url'],
                    'params' => array (
                        'id' => 'content_id',
                        //'content_id' => $requestArray['id'],
                        'url' => $requestArray['seo_url'],
                        'module' => 'default',
                        'controller' => 'career-edge',
                        'action' => 'details',
                        'content_id' => !empty($requestArray['id']) ? $requestArray['id'] :0
                    ),
                    'meta' => array(
                        'h1Tag' => isset($requestArray['h1_tag'])?$requestArray['h1_tag']:'',
                        'product_id' => isset($requestArray['primary_product_id'])? $requestArray['primary_product_id']:'',
                        'product_type' => isset($requestArray['primary_product_type'])? $requestArray['primary_product_type']:'',
                        'linkable_type' => isset($requestArray['type'])? $requestArray['type']:''
                    )
                );
                $rv = $db->Routes->insert($insertArray);
                if ($rv != true && is_array($rv) && $rv['err'] != null) {
                      throw new BaseApp_Exception('Error occurred while inserting data. Mongo error : ' . $rv['err']);
                } else {
                    $result = true;
                }
            }else{
                $updateArray = array (
                    'meta' => array(
                        'h1Tag' => isset($requestArray['h1_tag'])?$requestArray['h1_tag']:'',
                        'product_id' => isset($requestArray['primary_product_id'])? $requestArray['primary_product_id']:'',
                        'product_type' => isset($requestArray['primary_product_type'])? $requestArray['primary_product_type']:'',
                    )
                );
                $rv = $db->Routes->update(array('url' => $requestArray['seo_url']),array('$set'=>$updateArray));
                if ($rv != true && is_array($rv) && $rv['err'] != null) {
                    throw new BaseApp_Exception('Error occurred while inserting data. Mongo error : ' . $rv['err']);
                } else {
                  $result = true;
                }
            }
            //*****************Logic to enter in Routes also ends************//
            if ($result) {
                http_response_code(201);
                $responseArray = array ('status'=>201, 'message'=>'success');
            } else {
                http_response_code(500);
                $responseArray = array ('status'=>500, 'message'=>'faliure');
            }
        } catch (Exception $e) {
            http_response_code(404);
            $responseArray = array ('status'=>404, 'message'=>$e->getMessage());
        }
        $this->view->data = $responseArray;
    }

    /**
     * Following function used to get batch details
     * @author ganesh
     * @return array
     */
    public function getBatchList(){
        $request = $this->getRequest()->getPost();
        $arrCourse = ( isset($request['course']) && is_array($request['course']) ) ? $request['course'] : '';
        $year = isset($request['year']) ? $request['year'] : '';
        $month = isset($request['month']) ? $request['month'] : '';

        if(empty($arrCourse) || empty($year) || empty($month)){
            $this->view->data = array('status'=>400,'message'=>'Mandatory fields are missing.','data'=>array());
            return;
        }

        $objWorkshop = new BaseApp_Dao_Workshop();
        $arrBatchList = $objWorkshop->getBatchList($arrCourse,$year,$month);
        if(count($arrBatchList) > 0){
            $resultArray = array('status'=>200,'message'=>'success','data'=>$arrBatchList);
        }else{
            $resultArray = array('status'=>404,'message'=>'no workshop details found!','data'=>array());
        }
        $this->view->data = $resultArray;
    }

    public function checkCouponDisplay(){
        $request = $this->getRequest()->getPost();
        $countryIdArr = $request['country_id'];
        $courseIdArr = $request['course_id'];
        $labelIdArr = $request['label_id'];
        $clusterIdArr = $request['cluster_id'];
        $couponCode = $request['coupon_code'];
        $objCoupon = new Model_Coupons();
        $this->view->data = $resultArray = $objCoupon->checkCouponDisplay($courseIdArr,$countryIdArr,$labelIdArr,$clusterIdArr,$couponCode);
    }

    public function getReferrerDetails(){
        $referrerCode = $this->getRequest()->getParam("mbsy_code");
        if(!is_array($referrerCodeArr) && !empty($referrerCodeArr)){
            $this->view->data = array('status'=>400,'message'=>'Mandatory fields are missing.','data'=>array());
            return;
        }
        $returnArr = array();
        $objApi = new BaseApp_Ambassador_Api();
        foreach ($referrerCodeArr as $key => $value) {
            $resultSet = $objApi->getDetailsByCode($value);
            if(!empty($resultSet))
                $returnArr[$value] = $resultSet;
        }
        if(count($returnArr) > 0){
            $resultArray = array('status'=>200,'message'=>'success','data'=>$returnArr);
        }else{
            $resultArray = array('status'=>404,'message'=>'no details found!','data'=>array());
        }
        $this->view->data = $resultArray;
    }

    public function addReferrerComission(){
        $request = $this->getRequest()->getPost();
        $referrerCodeArr = $request["referrer_codes"];
        $referrerCodeArr = Zend_Json_Decoder::decode($referrerCodeArr);
        if(!is_array($referrerCodeArr) && !empty($referrerCodeArr)){
            $this->view->data = array('status'=>400,'message'=>'Mandatory fields are missing.','data'=>array());
            return;
        }
        $returnArr = array();
        $objApi = new BaseApp_Ambassador_Api();
        foreach ($referrerCodeArr as $key => $value) {
	    $customerEmail = $transactionID = $revenue = $TransactionDate = $courseName = $referee_ISM_email = $customer_name ='';

            if (!empty($value['customer_email'])) {
                $customerEmail = $value['customer_email'];
            }

            if (!empty($value['transaction_id'])) {
                $transactionID = $value['transaction_id'];
            }
            
            if(!empty($value['revenue'])){
                $revenue = $value['revenue'];
            }
            
            if(!empty($value['TransactionDate'])){
                $TransactionDate = $value['TransactionDate'];
            }
            
            if(!empty($value['customer_name'])){
                $customer_name = $value['customer_name'];
            }
            
            if(!empty($value['course_name'])) {
                $courseName = $value['course_name'];
            }
            
            if(array_key_exists('referee_ISM_email', $value) && !empty($value['referee_ISM_email'])){
                $referee_ISM_email = $value['referee_ISM_email'];
            }

            $resultSet = $objApi->addComission($value['referrer_code'], $value['amount'], $customerEmail, $transactionID,$revenue,$TransactionDate,$courseName,$referee_ISM_email,$customer_name);
            if(!empty($resultSet))
                $returnArr[$value['referrer_code']] = $resultSet;
        }
        if(count($returnArr) > 0){
            $resultArray = array('status'=>200,'message'=>'success','data'=>$returnArr);
        }else{
            $resultArray = array('status'=>404,'message'=>'no details found!','data'=>array());
        }
        $this->view->data = $resultArray;
    }

    /**
     * API method to fetch course pairs in format array(courseId=>courseName)
     * @author Mrinal Barua <mrinal@simplilearn.com.com>
     * @return array array('status'=>boolean,'message'=>'Message','data'=>array('course'=>array(),'bundle'=>array(),'flexipass'=>array()));
     */
    public function getProductPairs(){
        $resultArray = array('status'=>false,'message'=>'No data found','data'=>array('course'=>array(),'bundle'=>array(),'flexipass'=>array()));
        $courseModel = new Model_Courses();
        $data = $courseModel->fetchForSelect(array('is_dummy=?'=> 0),true,array('order'=>array('course_id ASC')));
        if(!empty($data)){
            $resultArray['status'] = true;
            $resultArray['data']['course'] = $data;
            $resultArray['message'] = '';
        }
        $this->view->data = $resultArray;
    }

    public function getAllLvcCourses(){
        $resultArray = array('status'=>false,'message'=>'No data found','data'=>array());
        $courseModel = new Model_Courses();
        $data = $courseModel->getAllLvcCourses();
        if(!empty($data)){
            $resultArray['status'] = 'success';
            $resultArray['message'] = 'records found';
            $resultArray['data'] = $data;
        }
        $this->view->data = $resultArray;
    }

    public function getTrainerReferrerInfo() {
        $request = $this->getRequest()->getPost();
        $referrerCode = $request['short_code'];

        if(empty($referrerCode)){
            $this->view->data = array('status'=>400,'message'=>'short_code field is missing.','data'=>array());

            return;
        }

        $db  = new Model_Default;
        $record = $db->ReferAndEarnTrainee->find(array('mbsy' => $referrerCode))->toArray();

        $result = array();
	    if (count($record) < 1) {
            // Call Get Ambassador API
            $objApi = new BaseApp_Ambassador_Api();
            $record = $objApi->getDetailsByCode($referrerCode);
            if (!empty($record['campaign_uid'])) {
                // Check if this is a trainer reference
                $config = Zend_Registry::get('config');
                $mbsyConfigs = $config->get('trainermbsyconfig')->toArray();
                $mbsyConfigsForReferer = $config->get('mbsyconfig')->toArray();
                $campaignIds = $mbsyConfigs['camp_id'];
                $campaignIdsReferer = $mbsyConfigsForReferer['camp_id'];
                if (in_array($record['campaign_uid'], $campaignIds)) {
                    $result[] = ["email"           => $record['email'],
                                 "mbsy"            => $referrerCode,
                                 "campaign_id"     => $record['campaign_uid'],
                                 "campaign_name"   => $record['campaign_name'],
                                 "campaign_desc"   => $record['campaign_description']];
                } else if (in_array($record['campaign_uid'], $campaignIdsReferer)) {
                    $result[] = ["email"           => $record['email'],
                                 "mbsy"            => $referrerCode,
                                 "campaign_id"     => $record['campaign_uid'],
                                 "campaign_name"   => $record['campaign_name'],
                                 "campaign_desc"   => $record['campaign_description'],
                                 "campaign_type"   => 'Refer and Earn'
                            ];
                }
            }
        } else {
            $result[] = $record[0];
        }

	    if (count($result) < 1) {
            $returnArr = array();
        } else {
            $returnArr = $result[0];

            if (isset($returnArr['_id'])) {
                unset($returnArr['_id']);
            }
        }
        $resultArray = array('status'=>200,'message'=>'success','data'=>$returnArr);

        $this->view->data = $resultArray;
    }
    public function getAmbasidorDataByCode() {
        $request = $this->getRequest()->getPost();
        $referrerCode = $request['short_code'];
        $this->view->data = array();
        if(empty($referrerCode)){
            $this->view->data = array('status'=>400,'message'=>'short_code field is missing.','email'=>'');

            return;
        }
        $objApi = new BaseApp_Ambassador_Api();
        $record = $objApi->getDetailsByCode($referrerCode);
        if(!empty($record) && !empty($record['email'])) {
            $this->view->data = array('status'=>200,'message'=>'success','email'=>$record['email']);
        }
    }

    public function insertAuthorRoutes() {
        $request = $this->getRequest()->getPost();
        $request = $request['body'];
        if (empty($request)) {
            http_response_code(404);
            throw new Exception ('Posted data not found');
        }
        $requestArray  = json_decode($request , true);
        $responseArray = array();
        $result = false;
        try {
            $modelSeo = new Model_Seo();
            $modelSeo->setFetchDisabled(true);
            $author = trim(urldecode($requestArray['seo_url']));
            # for author page SEO routes
            if (isset($author) && $author!='') {
                $authorSeoUrl  = urldecode('/authors/'.$author);
                $seoDataAuthor = $modelSeo->getDataByUrl($authorSeoUrl);
                $dataSaveAuthor = array();
                if (empty($seoDataAuthor)) {
                    $dataSaveAuthor['url']         = $authorSeoUrl;
                    $dataSaveAuthor['params']      = json_encode(array('url' => $authorSeoUrl));
                    $dataSaveAuthor['module']      = 'default';
                    $dataSaveAuthor['controller']  = 'career-edge';
                    $dataSaveAuthor['action']      = 'author-details';
                    $result = $modelSeo->setFromArray($dataSaveAuthor)->save();
                }
            }
            #also insert in Mongo collection
            if (isset($author) && $author!='') {
                $db  = new Model_Default;
                $authorSeoUrl = '/authors'.urlencode('/'.$author);
                $authorRecord = $db->Routes->find(array('url' => $authorSeoUrl))->toArray();
                if (empty($authorRecord)) {
                    $insertArray = array (
                        'url' => $authorSeoUrl,
                        'params' => array (
                            'url' => $authorSeoUrl,
                            'module' => 'default',
                            'controller' => 'career-edge',
                            'action' => 'author-details'
                        )
                    );
                    $rv = $db->Routes->insert($insertArray);
                    if ($rv != true && is_array($rv) && $rv['err'] != null) {
                          throw new BaseApp_Exception('Error occurred while inserting data. Mongo error : ' . $rv['err']);
                    } else {
                        $result = true;
                    }
                }
            }
            if ($result) {
                http_response_code(201);
                $responseArray = array ('status'=>201, 'message'=>'success');
            } else {
                http_response_code(500);
                $responseArray = array ('status'=>500, 'message'=>'already present');
            }
        } catch (Exception $ex) {
            http_response_code(404);
            $responseArray = array ('status'=>404, 'message'=>$e->getMessage());
        }

    }

    public function getBundleListForCouponId(){
        $request = $this->getRequest();
        $couponId = $request->getParam('coupon_id');
        $couponObj =new Model_Coupons();
        $couponData = current($couponObj->fetchAll(array('coupon_id =?'=>$couponId,'validto >= ?' => time()),array('columns'=>'bundle_id'),false));
        if(!empty($couponData)){
            if(!empty($couponData['bundle_id'])){
                $bundleIds = explode(',',$couponData['bundle_id']);
                $objBundle = new Model_Bundles();
                $bundleData = $objBundle->fetchForSelect(array('bundle_id in (?)'=>$bundleIds));
                $resultArray = array('status'=>200,'message'=>'success','data'=>$bundleData);
            }else{
                $resultArray = array('status'=>404,'message'=>'no details found!','data'=>array());
            }

        }else{
             $resultArray = array('status'=>404,'message'=>'no details found!','data'=>array());
        }
        $this->view->data = $resultArray;
    }

    public function getCityDetailsById(){
        $request = $this->getRequest();
        $cityId = $request->getParam('city_id');
        $objCity = new Model_City();
        $cityData = current($objCity->fetchAll(array('city_id =?'=>$cityId)));
        if(!empty($cityData)){
            $resultArray = array('status'=>200,'message'=>'success','data'=>$cityData);
        }else{
            $resultArray = array('status'=>404,'message'=>'no details found!','data'=>array());
        }
        $this->view->data = $resultArray;
    }

    public function fetchProductDetails(){
        $request = $this->getRequest();
        $productTypeId = $request->getParam('product_id');
        if(!empty($productTypeId)){
            if($productTypeId == BaseApp_Dao_ProductTypes::TYPE_ID_COURSE)
                $productObj = new Model_Courses();
            elseif($productTypeId == BaseApp_Dao_ProductTypes::TYPE_ID_BUNDLE)
                $productObj = new Model_Bundles();

            $productDetails = $productObj->fetchProductDetails();
            $resultArray = array('status'=>200,'message'=>'success','data'=>$productDetails);
        }else{
            $resultArray = array('status'=>400,'message'=>'Product Type Id missing!','data'=>array());
        }
        $this->view->data = $resultArray;
    }

    public function getCategoryCourses(){
        $resultArray = array();
        $request = $this->getRequest();
        $labels = $request->getParam('categories');
        if(!empty($labels)){
            $labels = explode(',',$labels);
            // Course Data
            $course = new Model_Courses();
            $courseData = $course->fetchCoursesByLabels($labels,1);
            // Master Program
            $bundle = new Model_Bundles();
            $bundleData = $bundle->getBundleListByLabelId($labels,1);
            $resultArray = array('status'=>200,'message'=>'Labels data!','data'=>$courseData,'bundledata'=>$bundleData);
        }else{
            $resultArray = array('status'=>400,'message'=>'Labels missing!','data'=>array());
        }
        $this->view->data = $resultArray;
    }

    public function getCoursesBasedOnAgency() {
        $resultArray = array();
        $request = $this->getRequest();
        $labels = $request->getParam('categories');
        $agencyName = $request->getParam('agencyName');
        if(!empty($labels)) {
            $labels = explode(',',$labels);
            // Course Data
            $course = new Model_Courses();
            $courseData = $course->fetchCoursesByLabelsBasedOnAgencyAjax($labels,$agencyName);
            // Master Program
            $bundle = new Model_Bundles();
            $bundleData = $bundle->fetchBundlesByLabelsBasedOnAgencyAjax($labels,$agencyName);
            $resultArray = array('status'=>200,'message'=>'Labels data!','data'=>$courseData,'bundledata'=>$bundleData);
    
        } 
        else {
            $resultArray = array('status'=>400,'message'=>'Labels missing!','data'=>array());
        }
        $this->view->data = $resultArray;
    }


    public function getCategoryCoursesForB2CPricing() { 
        $resultArray = array(); 
        $request = $this->getRequest(); 
        $labels = $request->getParam('categories'); 
        $isClusterOrCountry = $request->getParam('isClusterOrCountry'); 
        $countryOrClusterId = $request->getParam('clusterOrCountryId'); 
        $trainingType = $request->getParam('trainingType'); 
        $companyId = $request->getParam('company'); 
        $productSectionObj = new Model_ProductSectionData(); 
        $productSectionInfo = $productSectionObj->getByProduct($companyId, 'company');
        $agency = $productSectionObj->getAgencyData($companyId, 'agency');
        $agencyData = !empty($agency) ? current($agency):array();
        $companyName = !empty($agencyData['name']) ?$agencyData['name'] :'';
        $companyPricingPlan = $productSectionInfo[0]['company_price_plans'];
        if(!empty($labels)) {
            $labels = explode(',',$labels);
            if($trainingType == BaseApp_Dao_TrainingTypes::TYPE_ELEARNING_NAME || $trainingType == BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS_NAME) { 
                $course = new Model_Courses();
                $agencyCoursesData = array();
                if (!empty($companyName)) {
                    $agencyCourses = $course->fetchCoursesByLabelsBasedOnAgency($labels, $companyName);
                    if (!empty($agencyCourses)) {
                        $courseIds = array_column($agencyCourses, 'linkable_id');
                        $pricObj = new Model_Pricings();
                        $validCourseIds = $pricObj->getPricingByCourseIds($isClusterOrCountry, $countryOrClusterId, $courseIds, $trainingType);
                        $validCourseIds = !empty($validCourseIds) ? $validCourseIds : array();
                        $inValidCourseIds = array_diff($courseIds, $validCourseIds);
                        $agencyCoursesData = array_column($agencyCourses, 'name', 'linkable_id');
                        foreach ($inValidCourseIds as $key => $value) {
                            if (!empty($value)) {
                                if (!empty($agencyCoursesData[$value])) {
                                    unset($agencyCoursesData[$value]);
                                }
                            }
                        }
                    }
                }
                if ($companyPricingPlan == BaseApp_Dao_CompanyProductMapper::TYPE_COMPANY_DISCOUNT_PRICE_PLAN) {
                    $courseDataNew = $course->fetchCoursesByLabelsHavingB2cPrice($labels, $isClusterOrCountry, $countryOrClusterId, $trainingType, 1);
                     $resultArray = array('status' => 200, 'message' => 'Labels data!', 'data' => $courseDataNew);
                     
                    }
                else {
                    $courseData = $course->fetchCoursesByLabels($labels, 1); 
                    $resultArray = array('status'=>200, 'message'=>'Labels data!', 'data'=>$courseData); 
                }
                if (!empty($agencyCoursesData)) {
                
                    $resultArray['data'] = $resultArray['data'] + $agencyCoursesData;
                    
                }
            }
            elseif($trainingType == 'mp') { 
                $bundle = new Model_Bundles();
                $agencyBundle = array();
                if (!empty($companyName)) {
                    $agencyBundle = $bundle->getBundlesAgency($labels, $companyName);
                    
                    if (!empty($agencyBundle)) {
                        $bundleIds = array_column($agencyBundle, 'bundle_id');
                        
                        $pricObj = new Model_SubscriptionPricing();
                        $validBundleIds = $pricObj->getPricingByBundleIds($isClusterOrCountry, $countryOrClusterId, $bundleIds);
                        $validBundleIds = !empty($validBundleIds) ? $validBundleIds : array();
                        
                        $inValidBundleIds = array_diff($bundleIds, $validBundleIds);
                        
                        
                        $agencyBundleData = array_column($agencyBundle, 'display_name', 'bundle_id');
                        
                        
                        foreach ($inValidBundleIds as $key => $value) {
                            if (!empty($value)) {
                                if (!empty($agencyBundleData[$value])) {
                                    unset($agencyBundleData[$value]);
                                }
                            }
                        }
                    }
                }
                if($companyPricingPlan == BaseApp_Dao_CompanyProductMapper::TYPE_COMPANY_DISCOUNT_PRICE_PLAN) {
                    $bundleData = $bundle->getBundleListByLabelsHavingB2cPrice($labels, $isClusterOrCountry, $countryOrClusterId, 1); 
                    $resultArray = array('status'=>200, 'message'=>'Labels data!', 'data'=>$bundleData);
                    
                }
                else {
                    $bundleData = $bundle->getBundleListByLabelId($labels, 1);
                    $resultArray = array('status'=>200, 'message'=>'Labels data!', 'data'=>$bundleData); 
                }
                if(!empty($agencyBundleData)){
                    
                     
                    $resultArray['data'] = $resultArray['data'] + $agencyBundleData;
                    
                     
                }         
            }
        }
        else {
            $resultArray = array('status'=>400, 'message'=>'Labels missing!', 'data'=>array()); 
        }
        $this->view->data = $resultArray;
    }

    public function getMasterProgramCourseDetails(){
        $request = $this->getRequest();
        $courseIdArr = $request->getParam('course_id_arr');
        $purchaseDate = $request->getParam('purchase_date');
        $countryCode = $request->getParam('country_code');
        $quantity = $request->getParam('quantity');
        $passAccessDays = $request->getParam('pass_access_days');
        $mpAccessDays = $request->getParam('mp_access_days');
        $bundleId = $request->getParam('bundle_id');
        $trainingType_id = $request->getParam('trainingType_id');
        if (empty($mpAccessDays)) {
            $mpAccessDays = $passAccessDays;
        }
        $objCountry = new Model_Country();
        $countryDetails = current($objCountry->fetchAll(array('code = ?'=>$countryCode),array('columns'=>array('country_id'))));
        $countryId = $countryDetails['country_id'];
        if(empty($courseIdArr) || empty($purchaseDate) || empty($countryCode) || empty($countryId) || empty($quantity) || empty($bundleId)){
            $resultArray = array('status'=>400,'message'=>'Mandate Params missing !','data'=>array());

        }else{
            $objCourse = new Model_Courses();
            $courseDetails = $objCourse->getMasterProgramCourseDetails($courseIdArr,$purchaseDate,$passAccessDays,$countryCode,$countryId,$quantity,$trainingType_id,$mpAccessDays);
            $objBundle = new Model_Bundles();
            $learningPath = $objBundle->getMasterProgramLearningPath($bundleId);
            $resultArray = array('status'=>200,'message'=>'success','data'=>array('course_details'=>$courseDetails,'learning_path'=>$learningPath));
        }
        $this->view->data = $resultArray;
    }

    /**
     * Update lead in SFDC using the information shared
     * from LMS
     *
     * @param JSON string e.g. {"company":"","designation":"","industry":"","objective_for_taking_course":"","sponsored_by":"","dob":""}
     * @throws Exception
     */
    public function updateLeadInfo() {
        $request = $this->getRequest()->getRawBody();
        $mandatoryFieldsArr = array('email');
        $responseArray = array ('status'=>200, 'message'=>'success');
        /**
         * @todo log the request params. Right now it is not required
         * since here all the params are stored in mongo. If mongo save
         * operation will fail then anyways api will respond as false
         * and the data will be sent over again
         *
         **/
        try {
            if ( empty($request) ) {
                throw new Exception ('post data missing');
            }

            $inputParamsArr = json_decode($request , true);
            // check for mandatory fields
            if( !empty($errMsg = $this->_checkMandatoryFields($mandatoryFieldsArr, $inputParamsArr) ) ) {
                throw new Exception ($errMsg);
            }

            // save in mongo
            $inputParamsArr['is_processed'] = 0;
            $db  = new Model_Default;
            $rv = $db->LmsToSfdc->insert($inputParamsArr);
            if ($rv != true && is_array($rv) && $rv['err'] != null) {
                  throw new BaseApp_Exception('Error occurred while inserting data. Mongo error : ' . $rv['err']);
            }
        } catch (Exception $e) {
            http_response_code(500);
            $responseArray = array ('status'=>500, 'message'=>$e->getMessage());
        }
        $this->view->data = $responseArray;
    }

    /**
     * Get multiple course prices with multiple product types
     * @return JSON
     */
    protected function getMultipleProductPrices() {
        $params = Zend_Json_Decoder::decode(file_get_contents("php://input"));
        $params['country_code'] = urldecode($this->getRequest()->getParam('country_code'));
        $params['course_details'] = urldecode($this->getRequest()->getParam('course_details'));

        if (empty($params['country_code'])) {
            $this->view->data = array(
                'status' => 'fail',
                'message' => 'Please provide valid country code',
                'data' => array()
            );
            return;
        }

        $courseDetails = (!empty($params['course_details'])) ? @unserialize($params['course_details']) : array();
        if (!(!empty($courseDetails) && is_array($courseDetails) &&
                (!empty($courseDetails['osl']['course_ids']) || !empty($courseDetails['bundle']['bundle_ids']) || !empty($courseDetails['lvc']['course_ids'])))) {
            $this->view->data = array(
                'status' => 'fail',
                'message' => 'Please provide valid course details',
                'data' => array()
            );
            return;
        }

        if (!empty($courseDetails['osl']['course_ids']) && (empty($courseDetails['osl']['access_days']) || !is_numeric($courseDetails['osl']['access_days']))) {
            $this->view->data = array(
                'status' => 'fail',
                'message' => 'Please provide valid access days for OSL courses',
                'data' => array()
            );
            return;
        }

        try {
            $countryModel = new BaseApp_Dao_Country();
            $countryData = $countryModel->getCountryDetailsByCode($params['country_code']);
            if (empty($countryData['country_id'])) {
                $this->view->data = array(
                    'status' => 'fail',
                    'message' => 'Country data not found for the code : ' . $params['country_code'],
                    'data' => array()
                );
                return;
            }
            $countryId = $countryData['country_id'];

            $coursePriceData = array();

            $mongoDb = new Model_Default();

            // Online Self Learning Course Prices
            if (!empty($courseDetails['osl']['course_ids']) && is_array($courseDetails['osl']['course_ids']) && !empty($courseDetails['osl']['access_days'])) {
                $oslCourses = array_map('intval', $courseDetails['osl']['course_ids']);
                $condition = array('course_id' => array('$in' => $oslCourses), 'country_id' => (string) $countryId, 'access_days' => (string) $courseDetails['osl']['access_days']);
                $columns = array('_id' => false, 'course_id' => true, 'price' => true, 'access_days' => true);
                $oslData = $mongoDb->OnlineCourses->find($condition, $columns)->toArray();
                if (!empty($oslData)) {
                    foreach ($oslData as $oslPrice) {
                        $coursePriceData['osl'][$oslPrice['course_id']] = $oslPrice['price'];
                    }
                }
            }

            // Bundle Course Prices
            if (!empty($courseDetails['bundle']['bundle_ids']) && is_array($courseDetails['bundle']['bundle_ids'])) {
                $bundleIds = $courseDetails['bundle']['bundle_ids'];
                array_walk($bundleIds, array($this, '_getBundleIdsWithPrefix'));
                //$condition = array('bundle_id' => array('$in' => $bundleIds), 'country_id' => (string) $countryId);
                $condition = array('bundle_id' => array('$in' => $bundleIds), 'type'=>'country-master-page','country_id'=>(int)$countryId);
                $fields = array('_id' => false, 'bundle_id' => true, 'data.price' => true);
                $bundleData = $mongoDb->BundlePageHeader->find($condition, $fields)->toArray();
                if (!empty($bundleData)) {
                    foreach ($bundleData as $bundlePrice) {
                        $bundleId = $bundlePrice['bundle_id'];
                        $coursePriceData['bundle'][$bundleId] = $bundlePrice['data']['price'];
                    }
                }
            }

            // LVC Course Prices
            if (!empty($courseDetails['lvc']['course_ids']) && is_array($courseDetails['lvc']['course_ids'])) {
                $lvcCourses = array_map('intval', $courseDetails['lvc']['course_ids']);
                $condition = array('course_id' => array('$in' => $lvcCourses), 'country_id' => (integer) $countryId);
                $fields = array('_id' => false, 'course_id' => true, 'pricings.minPrice' => true);
                $lvcData = $mongoDb->OneCoursePass->find($condition, $fields)->toArray();
                if (!empty($lvcData)) {
                    foreach ($lvcData as $lvcPrice) {
                        $coursePriceData['lvc'][$lvcPrice['course_id']] = $lvcPrice['pricings']['minPrice'];
                    }
                }
            }

            if (!empty($coursePriceData)) {
                $this->view->data = array(
                    'status' => 'success',
                    'message' => 'ok',
                    'data' => $coursePriceData
                );
            } else {
                $this->view->data = array(
                    'status' => 'fail',
                    'message' => 'Course price data not found',
                    'data' => array(),
                );
            }
        } catch (Exception $ex) {
            $this->view->data = array(
                'status' => 'fail',
                'message' => 'Exception --> ' . $ex->getMessage(),
                'data' => array(),
            );
        }
    }

    /**
     * Add prefix to bundle course ids to fetch data from mongoDb
     * @param string $item
     */
    private function _getBundleIdsWithPrefix(&$item) {
        $item = (strpos($item, 'b') === false) ? 'b' . $item : $item;
    }

    /**
     * Upgrade free trial to order
     * Auto debit payment
     */
    public function enrollFreeTrial() {
        $resultArray = array('status' => null, 'message' => null, 'data' => null);
        $request = $this->getRequest();
        $email = $request->getParam('email');
        $orderNumber = $request->getParam('orderNumber');

        try {
            $mongoDb = new Model_Default();
            $condition = array('orderNumber' => $orderNumber, 'email' => $email);
            $order = $mongoDb->{BaseApp_Dao_FreeTrial::ORDERS_COLLECTION_NAME}->find($condition)->toArray(0);
            if(empty($order[0])) {
                throw new Exception("Invalid data");
            }
            $order = $order[0];
            if($order['free_trial'] != BaseApp_Dao_Melvin_Order::STATUS_FREE_TRIAL_ON) {
                if($order['free_trial'] == BaseApp_Dao_Melvin_Order::STATUS_FREE_TRIAL_USER_RENEWAL ||
                        $order['free_trial'] == BaseApp_Dao_Melvin_Order::STATUS_FREE_TRIAL_AUTO_RENEWAL ||
                        $order['free_trial'] == BaseApp_Dao_Melvin_Order::STATUS_FREE_TRIAL_PURCHASE
                ) {
                    throw new Exception("Already purchased");
                }
                if($order['free_trial'] == BaseApp_Dao_Melvin_Order::STATUS_FREE_TRIAL_CANCELLED) {
                    throw new Exception("Cancelled order can not purchase");
                }
                throw  new Exception("Free trial is not active");
            }
            $freeTrialModel = new BaseApp_Dao_FreeTrial();
            $status = $freeTrialModel->autoDebit($order, true);
            $purchaseTime = time();
            if(!$status) {
                throw new Exception("Payment failed");
            }
            $resultArray['status'] = 'success';
            $resultArray['message'] = 'Successfully updated';
            $resultArray['data'] = array(
              'purchaseTime' => $purchaseTime
            );
        } catch (Exception $e) {
            $resultArray['status'] = 'failed';
            $resultArray['message'] = $e->getMessage();
        }

        $this->view->data = $resultArray;
    }

    /**
     * Change free trial status
     * This will update in mongo
     * FreeTrialStatusSync will update it in xenia & salesforce
     */
    public function changeFreeTrial() {
        $resultArray = array('status' => null, 'message' => null, 'data' => null);
        $request = $this->getRequest();
        $email = $request->getParam('email');
        $orderNumber = $request->getParam('orderNumber');
        $status = $request->getParam('status');
        $comment = $request->getParam('comment');
        $mongoDb = new Model_Default();
        $email = str_replace(' ','+',$email);
        try {
            if(empty($email) || empty($orderNumber) || empty($orderNumber)) {
                throw new Exception("Mandatory field is missing");
            }
            $condition = array(
                'email' => $email,
                'orderNumber' => $orderNumber,
            );
            $orderData = $mongoDb->{BaseApp_Dao_FreeTrial::ORDERS_COLLECTION_NAME}->find($condition)->toArray(0);
            if(empty($orderData[0])) {
                throw new Exception("Invalid order", self::API_ERROR_INVALID_ORDER);
            }
            $orderData = $orderData[0];
            if($orderData['free_trial'] != BaseApp_Dao_Melvin_Order::STATUS_FREE_TRIAL_ON) {
               if($orderData['free_trial'] == BaseApp_Dao_Melvin_Order::STATUS_FREE_TRIAL_CANCELLED) {
                   throw new Exception("Order is already cancelled.", self::API_ERROR_ALREADY_CANCELLED);
               }
               throw new Exception("Order is not in ACTIVE status. [ Status: " . $orderData['free_trial'] . " ]", self::API_ERROR_ORDER_NOT_ACTIVE);
            }
            $freeTrialModel = new BaseApp_Dao_FreeTrial();
            $status = $freeTrialModel->updateFreeTrialStatus($email, $orderNumber, $status, $comment);
            if(!$status) {
                throw new Exception("Status update failed.", self::API_ERROR_INTERNAL_ERROR);
            }
            $resultArray['status'] = 'success';
            $resultArray['message'] = 'Successfully updated';
            $resultArray['code'] = self::API_SUCCESS;
        } catch (Exception $e) {
            $code = $e->getCode();
            if(empty($code)) {
                $code = self::API_ERROR_INTERNAL_ERROR;
            }
            $resultArray['status'] = 'failed';
            $resultArray['message'] = $e->getMessage();
            $resultArray['code'] = $code;
        }

        $this->view->data = $resultArray;
    }
    /**
     * Get Data For Custom Payment SSVC.
     * Method prepare and returns array containing country name ,city name ,label id ,label name etc.
     * @param int $countryId    Country Id
     * @param int $courseId     Course Id
     * @param int $cityId       City Id
     * @return array('status' => null, 'message' => null, 'data' => null);
     * @throws Exception
     */
    public function getDataForCustomPaymentSSVC() {
        $resultArray = array('status' => null, 'message' => null, 'data' => null);
        $request = $this->getRequest();
        $countryId = $request->getParam('countryId',0);
        $courseId = $request->getParam('courseId', 0);
        $cityId = $request->getParam('cityId', 0);
       try {
            if(empty($countryId) || empty($courseId) ){
                throw new Exception("Empty parameter.Either CountryId Or CourseId is empty.");
            }
            if(!is_numeric($countryId) || !is_numeric($courseId) || !is_numeric($cityId)){
                throw new Exception("Invalid parameter.{Country Id or Course Id or City Id } must be numeric.");
            }
            $data=array('countryDetails'=>array(),'cityDetails'=>array(),'courseInfo'=>array());
            if(is_numeric($countryId) && $countryId > 0){
                $objCountry = new Model_Country();
                $countryDetails = current($objCountry->fetchAll(array('country_id = ?' => $countryId)));
                if (!empty($countryDetails)) {
                   $data['countryDetails'][$countryDetails['country_id']]=$countryDetails['name'];
                }
                $condition=array('country_id =?'=> intval($countryId));
                if(is_numeric($cityId) && $cityId > 0){
                    $condition['city_id = ?']=intval($cityId);
                }
                $objCity = new Model_City();
                $cityDetails= $objCity->fetchforSelect($condition);
                if(!empty($cityDetails)){
                   $data['cityDetails']=$cityDetails;
                }
            }
            if (is_numeric($courseId) && $courseId > 0) {
                $objCourse = new Model_Courses();
                $courseData = current($objCourse->fetchAll(array('course_id=?' => $courseId)));
                if (!empty($courseData)) {
                 $data['courseInfo'][$courseData['course_id']]=array(
                                        'course_id'=>$courseData['course_id'],
                                        'label_id'=>$courseData['label_id'],
                                        'name'=>$courseData['name'],
                                        'displayName'=>$courseData['displayName'],
                                        'primaryLabel'=>$courseData['primary_label'],
                                        'labels'=>$courseData['labels']);
                }
            }
            $resultArray['status']=true;
            $resultArray['message']='Ok';
            $resultArray['data']=$data;
        } catch (Exception $e) {
             $resultArray = array('status' => false, 'message' =>'Error In Fetching Infomation : '.$e->getMessage(), 'data' => null);
        }
        $this->view->data = $resultArray;
    }
    public function getCoursePrice()
    {
        $pricingData = [];

        $request = $this->getRequest();

        $countryId = $request->getParam('countryId',0);
        $courseId = $request->getParam('courseId', 0);
        $trainingId = $request->getParam('trainingId', 0);
        $accessDays = $request->getParam('accessDays', 0);
        $productTypeId = $request->getParam('productTypeId', 0);
        $workshopId = $request->getParam('ws_id', 0);

        $db = new Model_Default;

        if ($productTypeId == 2) {
            // If product type is bundle
            $bundleHeader = current($db->OnlineBundles->find(array('bundle_id' => "b{$courseId}", 'country_id' => (string) $countryId, 'access_days' => (string) $accessDays), array('_id' => false))->toArray());
            $pricingData['price'] = $bundleHeader['price'];
            $pricingData['curr'] = $bundleHeader['currency'];
        }else if($productTypeId == 5){ 
            $masterHeader = current($db->ProductDetailedPageBlockPricing->find(array('master_product_id' => "m{$courseId}", 'country_id' => (string) $countryId), array('_id' => false))->toArray());
            $pricingData['price'] = $masterHeader['data']['price'];
            $pricingData['curr'] = $masterHeader['data']['currency'];
        }else if ($productTypeId == 1) {
            // If product type is course
            if ($trainingId == 2) {
                // If training type is OSL
                $dataQuery = current($db->OnlineCourses->find(array('course_id' => (int) $courseId, 'country_id' => (string) $countryId, 'access_days' => (string) $accessDays), array('_id' => false))->toArray());
                if ($dataQuery) {
                    $pricingData['price'] = $dataQuery['price'];
                    $pricingData['curr'] = $dataQuery['currency'];
                }
            } else if ($trainingId == 9) {
                // If training type is LVC
                $params = array('course_id' => (int) $courseId, 'country_id' => (int) $countryId, 'no_of_days_batches' => (int) $accessDays);
                $dataQuery = current($db->OneCoursePass->find($params, array('_id' => false))->toArray());
                if ($dataQuery) {
                    $pricingData['price'] = $dataQuery['pricings']['minPrice'];
                    $pricingData['curr'] = $dataQuery['pricings']['symbol'];
                }
            } else if($trainingId == 1) {
                // If training type is classroom
                $params = array('workshop_id' => (string) $workshopId);
                $dataQuery = current($db->ClassroomCourses->find($params, array('_id' => false))->toArray());
                if ($dataQuery) {
                    $pricingData['price'] = $dataQuery['price'];
                    $pricingData['curr'] = $dataQuery['currency'];
                }
            }else{
                echo json_encode(array('status' => false,'message' => 'training type is not correct','data' => [])); die;
            }
        } else {
            echo json_encode(array('status' => false,'message' => 'product type not correct','data' => [])); die;
        }

        echo json_encode(array('status' => true,'message' => 'Success','data' => $pricingData)); die;
    }

    protected function getRegionCityByCountry($countryId){
        $objCity = new Model_City();
        $this->view->data = $objCity->fetchAll(array('country_id =?'=> intval($countryId)), array('columns'=>array('city_id','name','region_name')));
    }

    protected function getTotalAmountForPartialPayment($currencyKey,$userEmail) {
        //fetch custom payment config from contract config table
        $xenia = new BaseApp_Communication_Xenia();
        $this->view->data = json_encode($xenia->getTotalAmountForPartialPayment($currencyKey,$userEmail));
    }

    public function getExamSlotDetails()
    {
        $response = array('status' => false, 'message' => 'No data found', 'data' => null);

        $request = $this->getRequest();

        $examId = $request->getParam('examId');
        if (!empty($examId)) {
            $SlotObject = new BaseApp_Dao_ExamSlots;
            $slots = $SlotObject->getSlotDataByExamid($examId);
            if (!empty($slots)) {
                $response = array('status' => true, 'message' => 'OK', 'data' => $slots);
            }
        }
        $this->view->data = $response;
        
    }

    /**
     * Validates role for payment approval and uploading attachments.
     * Moved from PaymentController
     */
    public function validateRole() {
        $requestParams = $this->getRequest()->getParams();
        $params = json_decode($requestParams['params'], TRUE);
        if (empty($params['paymentId']) || empty($params['role'])) {
            echo json_encode(array('status' => false, 'message' => "Invalid params passed."));
            exit;
        }

        //validate the role
        $loggedInUserData = BaseApp_Auth::getLoggedInUserData();
        if ($params['role'] == "SIMPLEX_PAYMENT") {
            $roleToUpload = array_intersect($loggedInUserData['roles'], BaseApp_Dao_Payments::$_upload_payment_attachment);
            if (empty($roleToUpload)) {
                echo json_encode(array('status' => false, 'message' => "You do not have permission to upload files."));
                exit;
            }
        }

        if ($params['role'] == "SIMPLEX_PAYMENT_APPROVE") {
            $roleToApprove = array_intersect($loggedInUserData['roles'], BaseApp_Dao_Payments::$_approve_payment);
            if (empty($roleToApprove)) {
                echo json_encode(array('status' => false, 'message' => "You do not have permission to approve payment."));
                exit;
            }
        }

        echo json_encode(array('status' => true, 'message' => "success"));
        exit;
    }

    /**
     * Disable Learner Range
     * @param int $learners_range_id learner range id
     * @param int $company_id Company Id
     */
    public function disableLearnerRange() {
        $resultArray = array();
        $request = $this->getRequest();
        $learners_range_id = $request->getParam('learners_range_id');
        $company_id = $request->getParam('company_id');
        if (!empty($learners_range_id) && !empty($company_id)) {
            $b2bPPricingObj = new Model_B2BProductPricing();
            $statusProductPricing = $b2bPPricingObj->disablePricingAndRange($company_id, $learners_range_id);
            
            $b2bFlatPriObj = new Model_B2BFlatPricing();
            $statusFlatPricing = $b2bFlatPriObj->disablePricingAndRange($company_id, $learners_range_id);
            
            $b2bCartPricing = new Model_B2bCartPricing();
            $statusCartPricing = $b2bCartPricing->deleteLearnersRangePricing($company_id, $learners_range_id);

            $message='';
            if(!$statusProductPricing && !$statusFlatPricing){
                $message = 'Error in Removing Learners Range !';
            }else{
                if($statusProductPricing || $statusFlatPricing){
                    $message ='Learner Range Removed Successfully !';
                }
            }
            $resultArray = array('status' => 200, 'message' => $message, 'data' => array());
            $session = new Zend_Session_Namespace('form');
            $learnerRangeIndex=0;
            foreach($session->learnerRangeData as $key=>$rangeData){
                if($learners_range_id==$rangeData['id']){
                    $learnerDataRangeIndex=$key;
                    unset($session->learnerRangeData[$key]);
                    $learnerRangeIndex=array_search($learnerDataRangeIndex,$session->learnerRange);
                    unset($session->learnerRange[$learnerRangeIndex]);
                }
            }
        } else {
            $resultArray = array('status' => 400, 'message' => 'Pricing Ids missing!', 'data' => array());
        }
        $this->view->data = $resultArray;
    }
    /**
     * Change Pricing Plan For Company
     * @param int $planId Plan id
     * @param int $companyId Company Id
     */
    public function companyPricePlanChange() {
        $resultArray = array();
        $request = $this->getRequest();
        $planId = $request->getParam('planId');
        $companyId = $request->getParam('companyId');
        if (!empty($companyId) && !empty($planId)) {
            /**
             * Check If Any Pricing Is Already Set For The Company With The Pricing Plan Id
             * If Pricing Plan Already Exist Then Update The Pricing Status To Zero(0).
             * Else If No Pricing Set/Exist Return .
             */
            $b2bPPricingObj = new Model_B2BProductPricing();
            $b2bFlatPriObj = new Model_B2BFlatPricing();
            $b2bCartPricingObj = new Model_B2bCartPricing();
            $condition = array('company_id' => $companyId);
            $pricingInfo = $b2bPPricingObj->fetchAll($condition, array('columns' => array('id')));
            $flatInfo = $b2bFlatPriObj->fetchAll($condition, array('columns' => array('id')));
            if (!empty($pricingInfo) || !empty($flatInfo)) {
                $pricingIds = array_column($pricingInfo, 'id');
                $status = $b2bPPricingObj->disableCompanyPricing($companyId);
                $removeFromFlat = !empty($flatInfo) ? $b2bFlatPriObj->disableCompanyPricing($companyId) : "";
                $remove = $b2bCartPricingObj->deleteAllB2bCartPricing($companyId);
                $message = '';
                if ($status) {
                    $message = 'All Course Pricing Deleted Successfully !';
                } else {
                    $message = 'Error in deleting the course price!';
                }
                $resultArray = array('status' => 200, 'message' => $message, 'data' => array());
            } else {
                $resultArray = array('status' => 200, 'message' => 'Pricing is not yet set.So you can change your plan !', 'data' => array());
            }
        } else {
            $resultArray = array('status' => 400, 'message' => 'Empty Parameters.', 'data' => array());
        }
        $this->view->data = $resultArray;
    }

    public function deletePricingByIds() {
        $resultArray = array();
        $request = $this->getRequest();
        $ppids = $request->getParam('ppids');
        $companyId = $request->getParam('companyId');
        $pricingType = $request->getParam('ptype');
        if (!empty($companyId) && !empty($ppids) && !empty($pricingType)) {
            /**
             * Product Pricing Delete
             */
            if ($pricingType == 'product') {
                $b2bProPriObj = new Model_B2BProductPricing();
                if ($b2bProPriObj->deleteB2BPricingData($companyId, $ppids)) {
                    $message = "Deleted Successfully";
                    $resultArray = array('status' => 200, 'message' => $message, 'data' => array());
                } else {
                    $message = "Error In Deletion !";
                    $resultArray = array('status' => 200, 'message' => $message, 'data' => array());
                }
            }
            /**
             * Flat Pricing Delete
             */
            if ($pricingType == 'flat') {
                $b2bFlatPriObj = new Model_B2BFlatPricing();
                if ($b2bFlatPriObj->deleteB2BPricingData($companyId, $ppids)) {
                    $message = "Deleted Successfully";
                    $resultArray = array('status' => 200, 'message' => $message, 'data' => array());
                } else {
                    $message = "Error In Deletion !";
                    $resultArray = array('status' => 200, 'message' => $message, 'data' => array());
                }
            }
            /**
             * Delete from B2bCartPricings Collection
             */
            if(!empty($pricingType)){
                $b2bCartPricings = new Model_B2bCartPricing();
                $b2bCartPricings->deleteB2bCartPricingData($companyId,$ppids);
            }
        }
        $this->view->data = $resultArray;
    }
    public function deleteDataByTrainingAndType() {
        $resultArray = array();
        $request = $this->getRequest();
        $linkableType = $request->getParam('linkableType');
        $companyId = $request->getParam('companyId');
        $trainingId = $request->getParam('trainingId');
        if (!empty($companyId) && !empty($linkableType) && !empty($trainingId)) {
            /**
             * Product Pricing Delete
             */
            $b2bProPriObj = new Model_B2BProductPricing();
            if ($b2bProPriObj->deleteDataByTrainingAndType($companyId, $linkableType, $trainingId)) {
                $message = "Deleted Successfully";
                $resultArray = array('status' => 200, 'message' => $message, 'data' => array());
            } else {
                $message = "Error In Deletion !";
                $resultArray = array('status' => 200, 'message' => $message, 'data' => array());
            }
            /**
             * Flat Pricing Delete
             */
            $b2bFlatPriObj = new Model_B2BFlatPricing();
             if ($b2bFlatPriObj->deleteDataByTrainingAndType($companyId, $linkableType, $trainingId)) {
                 $message = "Deleted Successfully";
                 $resultArray = array('status' => 200, 'message' => $message, 'data' => array());
             } else {
                 $message = "Error In Deletion !";
                 $resultArray = array('status' => 200, 'message' => $message, 'data' => array());
             }
        }
        $this->view->data = $resultArray;
    }
    
    public function fetchAllReseller(){ 
        $affiliateModel = new BaseApp_Communication_Accounts();
        $affiliate = $affiliateModel->getAffiliateForSelect(1);
        $affiliates =array();
        if(!empty($affiliate['data'])){
            $affiliates = $affiliate['data'];
        }
        $this->view->data = $affiliates;
    }

    public function fetchAffiliateByAffiliateId() {
        $xenia = new BaseApp_Communication_Xenia();
        $affiliateId = $this->getRequest()->getParam('affiliate_id');
        $return = $xenia->fetchAffiliateByAffiliateId($affiliateId);
        $this->view->data = $return;
    }

    public function getFinsaleIdsAndData() {
        $xenia = new BaseApp_Communication_Xenia();
        $params = $this->getRequest()->getParams();
        $return = $xenia->getDataByEmail($params);
        $this->view->data = $return;
    }

    public function getDataForPartialSubsequent(){
        $xenia = new BaseApp_Communication_Xenia();
        $email = $this->getRequest()->getParam('email');
        $isBackendPayment = $this->getRequest()->getParam('is_backend_payment');
        $response = $xenia->getDataForPartialSubsequent($email, $isBackendPayment);
        $this->view->data = $response;
    }

    private function addTrainee(array $data) {
        try {
            $email = isset($data['ambassador']['email']) ? $data['ambassador']['email'] : null;
            $mbsy = isset($data['ambassador']['campaign_links'][0]['url']) ? $data['ambassador']['campaign_links'][0]['url'] : null;
            $campaignId = isset($data['ambassador']['campaign_links'][0]['campaign_uid']) ? $data['ambassador']['campaign_links'][0]['campaign_uid'] : null;
            $campaignName = isset($data['ambassador']['campaign_links'][0]['campaign_name']) ? $data['ambassador']['campaign_links'][0]['campaign_name'] : null;
            $campaignDesc = isset($data['ambassador']['campaign_links'][0]['campaign_description']) ? $data['ambassador']['campaign_links'][0]['campaign_description'] : null;
            $sandbox = isset($data['ambassador']['sandbox']) ? $data['ambassador']['sandbox'] : null;

            $mbsyChunks = explode('/', $mbsy);
            if (count($mbsyChunks) > 0) {
                $mbsy = end($mbsyChunks);
            }

            if (empty($email) || empty($mbsy) || empty($campaignId)) {
                return;
            }
            $callbackObj = new BaseApp_Dao_ReferAndEarnTrainee();
            $result = $callbackObj->save($email, $mbsy, $campaignId, $campaignName, $campaignDesc, $sandbox);
        } catch (Exception $e) {

        }

        return;
    }

    public function getDefaultCityDetailsByCountryId() {
        $cityData = array();
        $countryId = $this->getRequest()->getParam('country_id');
        if(!empty($countryId)&& is_numeric($countryId)){
        $objCity = new Model_City();
        $cityData = $objCity->getDefaultCityData($countryId);
       }
        $this->view->data = $cityData;
    }

    /**
     * Method to get mapped enterprise company data by gid
     * @return array
     */
    public function getCompanyByGid() {
        $gid = $this->getRequest()->getParam('gid');
        $agencyObj = new BaseApp_Dao_B2bAgencyDetails();
        $result = $agencyObj->getCompanyByGid($gid);
        $this->view->data = $result;
    }

    /**
     * Method to get course catalogue details by courseIds
     * @return array
     */
    public function getCourseCatalogueDetails() {
        $cIds = $this->getRequest()->getParam('course_ids');
        $lmsUrlRequest = $this->getRequest()->getParam('lms_url_request');
        $catalogType = $this->getRequest()->getParam('catalog_type');
        $countryCode = $this->getRequest()->getParam('country_code');
        $courseIds = (!empty($cIds)) ? @unserialize($cIds) : array();
        $catalogUtil = new CourseCatalogue_Utility();
        $catalogueDetails = $catalogUtil->getCatalogueDetails($courseIds, $lmsUrlRequest, $catalogType, $countryCode);
        $this->view->data = $catalogueDetails;
    }

    /**
     * Method to get SSP course catalog
     */
    public function getSspCourseCatalogue(){
        $gid = $this->getRequest()->getParam('gid');
        $countryCode = $this->getRequest()->getParam('country_code');
        $lmsUrlRequest = $this->getRequest()->getParam('lms_url_request');
        $sspUtilityObj = new SelfServePortal_Utility();
        $result = $sspUtilityObj->getCourseCatalogue($gid, $countryCode, $lmsUrlRequest);
        $this->view->data = $result;
    }

    /**
     * Method to get course and bundle and category URL by courseId and bundleId and categoryId respectively.
     * Will return B2C or B2B URL based on gid request
     */
    public function getUrlByCourseId(){
        $response = array(
            'status' => 'failed',
            'msg' => 'Invalid input data.',
            'url' => '',
        );
        $courseId = $this->getRequest()->getParam('course_id'); // courseId / bundleId  / categoryId
        $courseType = $this->getRequest()->getParam('course_type');     // course / bundle / label
        $gid = $this->getRequest()->getParam('gid');    // For B2B
        if (!(!empty($courseId) && is_numeric($courseId) && !empty($courseType) && is_string($courseType))) {
            $this->view->data = $response;
            return;
        }

        $mongoDb = new Model_Default();
        $condition = array('meta.linkable_id' => strval($courseId), 'meta.linkable_type' => strval($courseType));
        $keys = array('_id' => false, 'meta.url' => true);
        $result = $mongoDb->Routes->find($condition, $keys)->toArray();

        $hostUrl = WEBSITE_MAIN_URL;
        // Generate Enterprise host URL
        if (!empty($gid) && is_numeric($gid)) {
            $agencyObj = new BaseApp_Dao_B2bAgencyDetails();
            $companyResult = $agencyObj->getCompanyByGid($gid);
            if (!(!empty($companyResult['status']) && strcasecmp($companyResult['status'], 'success') === 0 && !empty($companyResult['data']['company_identifier']) )) {
                $this->view->data = $response;
                return;
            }
            $hostUrl = ENTERPRISE_MAIN_URL . B2B_IDENTIFIER . DIRECTORY_SEPARATOR . $companyResult['data']['company_identifier'];
        }

        if (!empty($result[0]['meta']['url'])) {
            $websiteCourseUrl = $hostUrl . $result[0]['meta']['url'];
            $response['status'] = 'success';
            $response['msg'] = 'Ok';
            $response['url'] = $websiteCourseUrl;
        } else {
            $response['msg'] = 'Data not found.';
        }
        $this->view->data = $response;
    }

    /**
     * To get the course name by IDs
     */
    protected function getCourseNames() {
        $courseModel = new Model_Courses();
        $courseIds = !empty($this->getRequest()->getParam('course_ids')) ? unserialize($this->getRequest()->getParam('course_ids')) : array();
        $this->view->data = $courseModel->fetchCourseNames($courseIds);
    }

    public function getCourseCostForMigratingData() {
        $response = array('status' => false, 'cost' => array());
        $items = $this->getRequest()->getParam('items');
        $order = $this->getRequest()->getParam('order');
        $paymentsObj = new BaseApp_Dao_Payments();
        $orderCosts = $paymentsObj->prepareOrderCostByOrderItems($items, $order);
        if ($orderCosts['status'] == true) {
            $response['status'] = true;
            $response['cost'] = $orderCosts['data'];
        }
        $this->view->data = $response;
        return;
    }
    public function getClusterAndCountriesMapping(){
        $response = array('status'=>'failed','message'=>'empty','data');
        $modelCountry = new Model_Country();
        $result = $modelCountry->fetchAll(array("status IN (?)"=>1),array('columns'=>array('id' =>'country_id', 'cluster_id'), 'order' => array('cluster_id')));
        $clusterCountryMap =array();
        if(!empty($result)){
           foreach($result as $row){
               if($row['cluster_id'] > 0){
                   $clusterCountryMap[$row['cluster_id']][] = $row['id'];
               }
           }
           $response['status']='success';
           $response['message']='ok';
           $response['data']=$clusterCountryMap;
        }
        $this->view->data = $response;
        return ;
    }

    public function getTrainingsOnPricing($courseId){
        $objTrainingRelations = new Model_TrainingRelations();
        $trainingIds = $objTrainingRelations->getCourseTrainingIds($courseId, 'course');
        $this->view->data = $trainingIds;
    }
    /**
     * function to fetch max_reg_count for lvc registration.
     * params course_id
     */
    public function getAllowedLvcRegistrationCount(){
       
        try{
                $courseId = $this->getRequest()->getParam('course_id');         
                $resArr = array('status'=>'fail','msg'=>'Invalid course id','data'=>null);       
                if(empty($courseId)){
                    $this->view->data = $resArr;    
                    return; 
                }
                                    
                $lvcRegistrationAllowed = (new Model_Workshop())->getLvcWorkshopMaxRegAllowed($courseId);
                if(empty($lvcRegistrationAllowed)){                    
                    $this->view->data = array('status'=>'fail','msg'=>'No data found for this course id','data'=> null);    
                    return; 
                }
                        
                $this->view->data = array('status'=> 'success','msg'=>'successfull data fetch','data'=>$lvcRegistrationAllowed); 
                return;
        }catch(Exception $e){            
            $this->view->data = array('status' => 'fail', 'msg' =>'Error In Fetching Infomation : '.$e->getMessage(), 'data' => null);  
            return; 
        }
    }
    
    /**
     * @method : setIsSoldFlagForWorkshops() 
     * @params : $webx_session_id [string], $flag [bool => 0/1]
     * @return : boolean
     * @author : pavansb (pavan.sb@simplilearn.net)
    */
    public function setIsSoldFlagForWorkshops() {
        $webx_session_id = $this->getRequest()->getParam('webx_session_id');
        $flag = $this->getRequest()->getParam('flag');
        
        // Validate the data
        $validated = (array)$this->validateWorkshopData($webx_session_id, $flag);

        if(!$validated['status']) {
            $this->view->data = $validated;
            return;
        }

        // Set the flag
        $returnObj = (new Model_Workshop())->updateIsSoldFlagForWorkshops($webx_session_id, $flag);
        
        if(!$returnObj['status']) {
            $this->view->data = $validated;
            return;
        }
        
        $this->view->data = $returnObj;
    }

    /**
     * Validation rules, check for :
     * 1: non-empty webx_session_id & flag
     * 2: valid row in the DB with flag
     */
    private function validateWorkshopData($webx_session_id, $flag) {
        // rule #1
        if($webx_session_id == NULL || $webx_session_id == '') {
            return array('status'=>false, 'message'=>'Required parameters are missing!');
        }

        if($flag == NULL || $flag == '' ) {
            return array('status'=>false, 'message'=>'Required parameters are missing!');
        }
        
        if(!in_array($flag,$this->_IS_SOLD_STATUS, true)) {
            return(array('status' => false, 'message' => 'Invalid flag value, update failed!'));
        }

        // rule #2
        $validated = (new Model_Workshop())->checkForVaildWorkshopData($webx_session_id, $flag);
        if(!$validated['status']) {
            return array('status'=>false, 'message'=>$validated['message']);
        }

        return array('status'=>true, 'message'=>'All validations passed!');
    }

    public function getCoursesList() {
        $request = $this->getRequest();
        $paymentSubType = $request->getParam('paymentSubType');
        $response = array('status' => 'failed', 'message' => 'empty', 'data'=> '');

        // Fetch courses
        $Courses = new Model_Courses();
        $condition = array('course_available_for in (?)'=>['universal','b2c_only']);
        if ($paymentSubType == BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_PARTIAL) {
            $condition = array('is_part_payment = ?' => 1,'course_available_for in (?)'=>['universal','b2c_only']);
        }
        $courseResult = $Courses->fetchAll($condition, array(), false);
        $freeCourses = $paidCourses = array();


        /* 
            If the course is free, list in both free as well as paid 
            But if the course is paid, list only in paid section
        */
            
        if (!empty($courseResult)) {
            foreach ($courseResult as $key => $val) {
                if ($val['can_be_free'] == 1) {
                    $freeCourses[$val['course_id']] = strip_tags($val['displayName']);
                } 
                $paidCourses[$val['course_id']] = strip_tags($val['displayName']);
            }
        }

        // Fetch bundles
        $Bundle = new Model_Bundles();
        $bundleCondition = array('bundle_available_for in (?)'=>['universal','b2c_only'],'payment_type_id =?' => BaseApp_Dao_PaymentType::ONETIME_PAYMENT_TYPE_ID, 'linkable_type = ?' => 'bundle');
        if ($paymentSubType == BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_PARTIAL) {
            $bundleCondition = array('bundle_available_for in (?)'=>['universal','b2c_only'],'payment_type_id =?' => BaseApp_Dao_PaymentType::ONETIME_PAYMENT_TYPE_ID, 'linkable_type = ?' => 'bundle', 'is_part_payment = ?' => 1);
        }
        $bundlesResult = $Bundle->fetchAll($bundleCondition, array(), false);
        $freeBundles = $paidBundles = array();
        foreach ($bundlesResult as $key => $val) {
            if($val['can_be_free'] == 1){
                $freeBundles[$val['bundle_id']] = strip_tags($val['display_name']);
            }
            //SLUB-32091: bundle marked as free should also be visible under paid
            $paidBundles[$val['bundle_id']] = strip_tags($val['display_name']);        
        }

        // Fetch Masters
        $momCondition = array('bundle_available_for in (?)'=>['universal','b2c_only'],'payment_type_id =?' => BaseApp_Dao_PaymentType::ONETIME_PAYMENT_TYPE_ID, 'linkable_type = ?' => 'master_of_masters');
        if ($paymentSubType == BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_PARTIAL) {
            $momCondition = array('bundle_available_for in (?)'=>['universal','b2c_only'], 'payment_type_id =?' => BaseApp_Dao_PaymentType::ONETIME_PAYMENT_TYPE_ID, 'linkable_type = ?' => 'master_of_masters', 'is_part_payment = ?' => 1);
        }
        $momResult = $Bundle->fetchAll($momCondition, array(), false);
        $masters = array();
        foreach ($momResult as $key => $value) {
            $masters[$value['bundle_id']] = strip_tags($value['display_name']);
        }

        $allCourses = json_encode([BaseApp_Dao_ProductTypes::TYPE_ID_COURSE => ['free' => $freeCourses, 'paid' => $paidCourses],
            BaseApp_Dao_ProductTypes::TYPE_ID_BUNDLE => ['free' => $freeBundles,'paid' => $paidBundles], BaseApp_Dao_ProductTypes::TYPE_ID_MOM => ['paid' => $masters]]);

        if (!empty($allCourses)) {
            $response['status'] = 'success';
            $response['message'] = 'ok';
            $response['data'] = $allCourses;
        }

        $this->view->data = $response;
        return;
    }


    public function getSearchTagsByproductId () {
        $productId = $this->getRequest()->getParam('productId');
        $productType = $this->getRequest()->getParam('productType');
        $tags = new Model_Tags(); 
        $courseTagDetail = $tags->getByLinkable($productId, $productType);
        if(isset($courseTagDetail['tag'])){
            $response['status']='success';
            $response['message']='ok';
            $response['tag'] = $courseTagDetail['tag'];
        } else {
            $response['status']='error';
            $response['message']='No tag found.';
            $response['tag'] = '';
        }

        $this->view->data = $response;
    }

    public function updateFreePracticeUserCount() {
        $freePracticeTestId = $this->getRequest()->getParam('freePracticeTestId');
        $practicetestModel = new Model_FreePracticeTest($freePracticeTestId);
        if (!$practicetestModel->toArray()) {
            $response['status']='error';
            $response['message']='Invalid Free Preactice Test ID.';
        } else {
            $data = $practicetestModel->toArray();
            $updateData['user_test_taken_count'] = $data['user_test_taken_count']+1;
            $updateData['free_practice_test_id'] = $freePracticeTestId;
            
            $practicetestModel->updatePracticeTest($updateData);
            $response['status']='success';
            $response['message']='Value updated successfully.';
        }
        $this->view->data = $response;
    }
    protected function getProductCategoryById()
    {
        $productId = $this->getRequest()->getParam('product_id');
        $productType = $this->getRequest()->getParam('product_type');

        if ($productType == "course") {
            $courseModel = new Model_Courses();
            $product = $courseModel->fetchPrimaryLabelIdByCourseId($productId);
        } elseif ($productType == "bundle") {
            $courseModel = new Model_Bundles();
            $product = $courseModel->fetchPrimaryLabelIdByBundleId($productId);
        }

        $this->view->data = $product;
    }
    public function fetchProductDetailsByLable()
    {
        $type   = $this->getRequest()->getParam('type');
        $label  = $this->getRequest()->getParam('label');
        $products = array();
        $label = !empty($label) ? $label : '';        
        $labelArr = !empty($label) ? array($label) : array();
        if (!empty($type)) {
            $modelObj = new Model_Courses($label);
            if ($type == "master_program") {
                $modelObj = new Model_Bundles();
                $products = $modelObj->fetchMasterPrograms($label);
            } else if ($type == "course") {
                $products = $modelObj->getCoursesbyLables($labelArr);
                $productsFreeCourses = $modelObj->fetchFreeCourseByLabels($labelArr);
                $products =  $products + $productsFreeCourses;
            }else if($type == "webinar" || $type == "ebook" || $type == "article"){
                $resourseCat = $this->getRequest()->getParam('resourse');
                $products = $modelObj->getSeoContents($resourseCat,$type,$label);
            } 
            else {
                $products = $modelObj->fetchFreeCourseByLabels($labelArr);
            }
        }
        $newdata = array();
        if (!empty($products)) {
            foreach ($products as $key => $val) {
                $newdata[$key] =  $key . ' - ' . $val;
            }
        }
        echo json_encode($newdata);
        die();
    }
    public function getReferrerInfo()
    {
        $request = $this->getRequest()->getParams();
        $referData = array();
        $res = array('status' => 'failure', 'message' => 'invalid data', 'url' => '');
        if (empty($request) || empty($request['name']) || empty($request['email'])) {
            $this->view->data = $res;
            return;
        }
        $referrerObj = new BaseApp_Dao_ReferrerUsers();
        $campainData = $referrerObj->getCampainDetails($request);
        if (empty($request['camp_id'])) {
            $request['camp_id'] = !empty($campainData['camp_id']) ? $campainData['camp_id'] : '';
        }
        $email = $request['email'];
        $name = $request['name'];
        $name = !empty($request['name']) ? $request['name'] : '';
        $name = empty($name) ? '' : $name;
        $nameData = explode(' ', $name);
        $nameData = is_array($nameData) ? $nameData : array();
        $referData['first_name'] = isset($nameData[0]) ? $nameData[0] : '';
        unset($nameData[0]);
        $referData['last_name'] = implode(" ", $nameData);
        $referData['name'] = $name;
        $referData['email'] = $email;
        $referData['camp_id'] = $request['camp_id'];
        $referData['eventStatus'] = !empty($request['eventStatus']) ? $request['eventStatus'] : false;
        $referData['country_code'] = !empty($campainData['country_code'])?$campainData['country_code']:'';
        $referSaveObj = new BaseApp_Dao_ReferrerUsers();
        $response  = $referSaveObj->saveData($referData);
        if (!empty($response)) {
            $res = array('status' => 'success', 'url' => '');
        } else {
            $res['message'] = 'error in saving data';
        }
        $this->view->data = $res;
        return;
    }
    public function saveReferrerRefereeInfo()
    {
        $res = array('status' => 'failure', 'message' => 'invalid data');
        if (!empty($_SERVER['CONTENT_TYPE']) && strtolower($_SERVER['CONTENT_TYPE']) == 'application/json') {
            $body = $this->getRequest()->getRawBody();
            $inputData = Zend_Json::decode($body);
        } else {
            $inputData = $this->getRequest()->getParams();
        }
        try {
            // unset unwanted values
            unset($inputData['module']);
            unset($inputData['controller']);
            unset($inputData['action']);
            unset($inputData['method']);

            $referRefereeSaveObj = new BaseApp_Dao_ReferrerRefereeMapping();
            if (empty($inputData['data'])) {
                throw new Exception("bulk data empty");
            }
            unset($inputData['type']);
            $inputData = $inputData['data'];
            $response = $referRefereeSaveObj->saveBulkData($inputData);
            if (!empty($response)) {
                $res = array('status' => 'success', "message" => "success");
            } else {
                $res['message'] = 'error in saving data';
            }
        } catch (Exception $e) {
            $res['status'] = 'failure';
            $res['message'] = $e->getMessage();
        }
        $this->view->data = $res;
        return;
    }

    public function getYouTubeVideoDetails(){
        $request = $this->getRequest();
        $videoLink = !empty($request->getParam('videoLink')) ? $request->getParam('videoLink') : '';
        $part = !empty($request->getParam('part')) ? $request->getParam('part') : 'snippet,contentDetails,statistics';
        $responseMsg = array();
        if(empty($videoLink)){
            $responseMsg = array('status' => 'failed', 'data' => array(), 'message' => 'Invalid Video Url');
            $this->view->data = $responseMsg;
            return;
        }
        $youtubeApi = new BaseApp_Utility_YoutubeApi();
        $vData = $youtubeApi->getVideoDetails($videoLink,$part);
        $videoData = array();
        if(is_array($vData) && !empty($vData)) {
            $videoData['videoDescription'] = isset($vData['shortDescription']) ? $vData['shortDescription'] : NULL;
            $videoData['dateCreated'] = isset($vData['dateCreated']) ? $vData['dateCreated'] : NULL;
            $videoData['duration'] = $videoData['durationInSeconds'] = NULL;
            if(isset($vData['duration'])){
                $durationArr = explode(':',$vData['duration']);
                $hours = $minutes = $seconds = 0;
                if(!empty($durationArr)) {
                    switch (count($durationArr)) {
                        case 1:
                            $hours = 0;
                            $minutes = 0;
                            $seconds = $durationArr[0];
                            $videoData['duration'] = "00:00:".$vData['duration'];
                            break;
                        case 2:
                            $hours = 0;
                            $minutes = $durationArr[0];
                            $seconds = $durationArr[1];
                            $videoData['duration'] = "00:".$vData['duration'];
                            break;
                        case 3:
                            $hours = $durationArr[0];
                            $minutes = $durationArr[1];
                            $seconds = $durationArr[2];
                            $videoData['duration'] = $vData['duration'];
                            break;
                        
                        default:
                            $hours = 0;
                            $minutes = 0;
                            $seconds = 0;
                            $videoData['duration'] = "00:00:00";
                            break;
                    }
                }
                $videoData['durationInSeconds'] = ($hours * 60 * 60) + ($minutes * 60) + $seconds;
            }
            $videoData['displayName'] = isset($vData['displayName']) ? $vData['displayName'] : '';
            $videoData['thumbnailImage'] = isset($vData['thumbnailImage']) ? $vData['thumbnailImage'] : '';
            $videoData['viewCount'] = !empty($vData['statistics']) && !empty($vData['statistics']['viewCount']) ? $vData['statistics']['viewCount'] : 0;

            $responseMsg = array('status' => 'success', 'data' => $videoData, 'message' => 'success');
        } else {
            if ($vData == BaseApp_Utility_YoutubeApi::INVALID_VIDEO) {
                $responseMsg = array('status' => 'failed', 'data' => $videoData, 'message' => 'Please enter valid youtube video link');
            } else if ($vData == BaseApp_Utility_YoutubeApi::LIMIT_ERROR) {
                $responseMsg = array('status' => 'failed', 'data' => $videoData, 'message' => 'Daily limit for authenticated use exceeded');
            } else {
                $responseMsg = array('status' => 'failed', 'data' => $videoData, 'message' => 'Check the video url');
            }
        }
        $this->view->data = $responseMsg;
        return;
    }

    public function checkSeoUrl(){
        $request = $this->getRequest();
        $seo_url = !empty($request->getParam('seo_url')) ? $request->getParam('seo_url') : '';
        if (empty($seo_url)) {
            http_response_code(404);
            throw new Exception ('Invalid seo url');
        }
        $responseArray = array();
        try {
            $requestArray['seo_url'] = trim(urldecode($seo_url));
            $checkSlash = substr($seo_url, 0,1);
            if($checkSlash != '/') {
                $seo_url = trim('/'.$seo_url);
            }
            $modelSeo = new Model_Seo();
            $modelSeo->setFetchDisabled(true);
            $seoData  = $modelSeo->getDataByUrl($seo_url);
            if(!empty($seoData) && $seoData['seo_id']) {
                http_response_code(200);
                $responseArray = array ('status'=>"failed", 'message'=>'Seo Url Already Exists');
            } else {
                http_response_code(200);
                $responseArray = array ('status'=>"success", 'message'=>"Seo Url doesn't Exists");
            }
        } catch (Exception $e) {
            http_response_code(404);
            $responseArray = array ('status'=>404, 'message'=>$e->getMessage());
        }
        $this->view->data = $responseArray;
    }

    /**
     * @author Amit kumar maurya
     * This function will revcieve course ids comma seprated and return the course details 
     */

    public function getCourseDetailsByCourseIds() {
        $courseIds = $this->getRequest()->getParam('courseIds');
        $responseMsg = array();
        if ($courseIds ) {
            $ids = explode(",", $courseIds );
            $courseModel = new Model_Courses();
            $courses = $courseModel->getCourseDetailsByIds($ids);
            $responseMsg = array('status' => 'success', 'data' =>$courses);
        } else {
            $responseMsg = array('status' => 'failed', 'message' => 'Please provide course ids.');
        }

        $this->view->data = $responseMsg;
    }
    public function getMasterTypeOfBundle() {
        $params = $this->getRequest()->getParams();
        unset($params['module'], $params['controller'], $params['action'], $params['method']);
        $bundleId = !empty($params['linkable_id']) ? $params['linkable_id']:0;
        $resultArray = array('status' => false, 'message' => 'no data found', 'data' => array());
        try {
            if(empty($bundleId)) {
                $this->view->data = $resultArray;
            }
            $objBundle = new Model_Bundles();
            $bundleTypeData = $objBundle->getMasterTypeOfBundle($bundleId);
            if (!empty($bundleTypeData))
                $resultArray = array('status' => true, 'message' => 'success', 'data' => $bundleTypeData);
        } catch (Exception $e) {
            $resultArray['msg'] = $e->getMessage();
        }
        $this->view->data = $resultArray;
    }

    /**
     * Fetches the course and the cost offerings
     * Params - Producttypeid, product id, country, payment_sub_type_id
     */
    public function getCourseOfferings() {
        $params = $this->getRequest()->getParams();
        unset($params['module'], $params['controller'], $params['action'], $params['method']);
        $result = array('status' => false, 'message' => 'no data found', 'data' => array());
        try {
            if(empty($params))  {
                $this->view->data = $result;
            }
            $costMdl = new BaseApp_Dao_Cost();
            $courseOfferings = $costMdl->getCourseOfferings($params);
            if (!empty($courseOfferings)) {
                $result['status'] = $courseOfferings['status'];
                $result['message'] = $courseOfferings['message'];
                $result['data'] = $courseOfferings['data'];
            }
        } catch (Exception $e) {
            $result['msg'] = $e->getMessage();
        }
        $this->view->data = $result;
    }

    public function getWorkshopDetailById(){
        $workshopIdArr = $this->getRequest()->getParam("workshopIds");
        if(is_array($workshopIdArr) && !empty($workshopIdArr)){
            $dateModel = new Model_Workshop();
            $arrWorkshop = $dateModel->fetchAll(array('workshop_id IN (?)'=>$workshopIdArr));
            if(count($arrWorkshop) > 0){
                $resultArray = array('status'=>200,'message'=>'success','data'=>$arrWorkshop);
            }else{
                $resultArray = array('status'=>404,'message'=>'no workshop details found!','data'=>array());
            }
        }else{
            $resultArray = array('status'=>400,'message'=>'workshopId is mandatory field and should be array','data'=>array());
        }
        $this->view->data = $resultArray;

    }

}
