<?php

class Content_KeyWordRankingController extends BaseApp_Controller_Crud {

    public function init() {
        $this->_helper->layout->setLayout('_content_layout');
    }

    public function indexAction() {
        $form = $this->_getForm();
        $request = $this->getRequest()->getPost();
        $authenticatedata = new Model_YoutubeAdmin();
        $validate = $authenticatedata->getAll();
        if ($this->getRequest()->getPost() && $form->isValid($request)) {
            if ($validate[0]['username'] == $request['username'] && $validate[0]['password'] == $request['password']) {
                $this->_redirect("/content/key-word-ranking/add");
            } else {
                echo "<script type='text/javascript'>alert('Invalid Credentials')</script>";
            }
        }
        $this->view->form = $form;
    }

    public function addAction() {
        $detailsform = new Form_KeyWordRanking();
        $request = $this->getRequest()->getPost();


        if ($this->getRequest()->getPost() && $detailsform->isValid($request)) {
            $datasave = $request;
            unset($request['add']);

            $datatosave = new Model_YoutubeKeyword();

            try {
                $datatosave->setFromArray($request)->save();
                echo "<script type='text/javascript'>alert('Data submitted successfully!')</script>";
            } catch (Exception $ex) {
                
            }
        }

        $this->view->form = $detailsform;


        if (isset($request["download"])) {
            $data = new Model_YoutubeKeyword();
            //$myfile = fopen("Download.txt", "w") or die("Unable to open file!");
            $txt = $data->getAll();

            $fileName = "Keyword_Data_".date('m-d-Y').".xls";

            if ($txt) {

                function filterData(&$str) {
                    $str = preg_replace("/\t/", "\\t", $str);
                    $str = preg_replace("/\r?\n/", "\\n", $str);
                    if (strstr($str, '"'))
                        $str = '"' . str_replace('"', '""', $str) . '"';
                }

                // headers for download
                header("Content-Disposition: attachment; filename=\"$fileName\"");
                header("Content-Type: application/vnd.ms-excel");

                $flag = false;
                foreach ($txt as $row) {

                    if (!$flag) {
                        // display column names as first row
                        echo implode("\t", array_keys($row)) . "\n";
                        $flag = true;
                    }
                    // filter data
                    array_walk($row, 'filterData');
                    echo implode("\t", array_values($row)) . "\n";
                }
                exit;
            }
        }

        if (isset($request['addCourse'])) {

            $this->_redirect("/content/key-word-ranking/edit");
        }
    }

    public function editAction() {

        $courseform = new Form_KeyWordRankingCourse();
        $request = $this->getRequest()->getPost();
        if ($this->getRequest()->getPost()) {
            if (isset($request['savecourse']) && $courseform->isValid($request)) {
                unset($request['savecourse']);
                $courseToAdd = new Model_YoutubeCourseName();
                $courseToAdd->setFromArray($request)->save();
                $this->_redirect("/content/key-word-ranking/add");
            }
            if (isset($request['cancelcourse'])) {
                $this->_redirect("/content/key-word-ranking/add");
            }
        }
        $this->view->form = $courseform;
    }

    protected function _getForm() {
        $form = new Form_KeyWordRankingLogin();
        return $form;
    }

}
