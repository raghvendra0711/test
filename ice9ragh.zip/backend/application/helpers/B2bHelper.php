<?php

class Helper_B2bHelper {

    private $_eligibleList = ["universal", "b2b_only"];
    private $_partialEligibleList = ["private_b2b"];

    const NOT_ELIGBLE = 0;
    const ELIGBLE = 1;
    const PARTIAL_ELIGBLE = 2;
    
    private function isEligbleB2bByAvailableFor($courseAavailableFor) {
        if(in_array($courseAavailableFor, $this->_eligibleList)) {
            return self::ELIGBLE;
        }
        if(in_array($courseAavailableFor, $this->_partialEligibleList)) {
            return self::PARTIAL_ELIGBLE;
        }
        return self::NOT_ELIGBLE;
    }

    public function processAvaliableForChange($productType, $productId, $availableForData) {
        if(
            empty($availableForData['old']) || empty($availableForData['new']) ||
            !isset($availableForData['old']['availableFor']) || !isset($availableForData['old']['agencies']) ||
            empty($availableForData['new']['availableFor']) || !isset($availableForData['new']['agencies'])
        ) {
            $errorMessage = "invalid data passed in processAvaliableForChange. " . json_encode(func_get_args());
            if (APPLICATION_ENV != 'production') {
                throw new Exception($errorMessage);
            }
            else {
                file_put_contents(APPLICATION_PATH . '/../error.log', "\n[" .date('Y-m-d H:i:s'). '] ERROR: processAvaliableForChange failed ' . $errorMessage, FILE_APPEND);
            }
            return;
        }
        $oldData = $availableForData['old'];
        $newData = $availableForData['new'];
        $oldEligbleStatus = $this->isEligbleB2bByAvailableFor(empty($oldData['availableFor'])?"":$oldData['availableFor']);
        $newEligbleStatus = $this->isEligbleB2bByAvailableFor($newData['availableFor']);
        $b2bProductExclusionsModel = new Model_B2bProductExclusions();
        $b2bPriceModel = new Model_B2BProductPricing();
        
        // rules
        if($oldEligbleStatus != self::PARTIAL_ELIGBLE && $oldEligbleStatus == $newEligbleStatus) {
            // no change
            return;
        }
        
        if($oldEligbleStatus == self::NOT_ELIGBLE && $newEligbleStatus == self::ELIGBLE)  {
            // add
            $b2bProductExclusionsModel->saveB2bExclusionsInCompanies($productType, $productId);
        }
        
        if ($oldEligbleStatus == self::NOT_ELIGBLE && $newEligbleStatus == self::PARTIAL_ELIGBLE && !empty($newData['agencies'])) {
            // add to agency company
            $b2bProductExclusionsModel->saveB2bExclusionsInCompanies($productType, $productId, $newData['agencies']);
        }
        
        if($oldEligbleStatus == self::ELIGBLE && $newEligbleStatus == self::NOT_ELIGBLE) {
            // remove
            $b2bPriceModel->deletePricingByProduct($productType, $productId);
            $b2bProductExclusionsModel->removeProductFromExclutions($productType, $productId);
        }

        if($oldEligbleStatus == self::ELIGBLE && $newEligbleStatus == self::PARTIAL_ELIGBLE) {
            // $newData['agencies'] - existing agencies no change, remove other agency data
            $b2bPriceModel->deleteProductPricingByAgencies($productType, $productId, $newData['agencies'], Model_B2BProductPricing::OPTIONS_EXCLUDE);
            $b2bProductExclusionsModel->removeProductFromExclutions($productType, $productId, $newData['agencies'], Model_B2bProductExclusions::OPTIONS_EXCLUDE);
        }

        if($oldEligbleStatus == self::PARTIAL_ELIGBLE && $newEligbleStatus == self::ELIGBLE) {
            // $oldData['agencies'] - existing agencies no change, add other for other agency
            $b2bProductExclusionsModel->removeProductFromExclutions($productType, $productId);
            $b2bProductExclusionsModel->saveB2bExclusionsInCompanies($productType, $productId);
        }
        
        if($oldEligbleStatus == self::PARTIAL_ELIGBLE && $newEligbleStatus == self::NOT_ELIGBLE) {
            // $oldData['agencies'] - existing agencies remove
            $b2bPriceModel->deleteProductPricingByAgencies($productType, $productId, $oldData['agencies'], Model_B2BProductPricing::OPTIONS_INCLUDE);
            $b2bProductExclusionsModel->removeProductFromExclutions($productType, $productId, $oldData['agencies'], Model_B2bProductExclusions::OPTIONS_INCLUDE);
        }

        if($oldEligbleStatus == self::PARTIAL_ELIGBLE && $newEligbleStatus == self::PARTIAL_ELIGBLE) {
            $commonAgencies = array_intersect($oldData['agencies'], $newData['agencies']); // no change
            $oldInvalidAgencies = array_diff($oldData['agencies'], $commonAgencies); // remove
            $newValidAgencies = array_diff($newData['agencies'], $commonAgencies); // add

            if(!empty($newValidAgencies)) {
                // add
                $b2bProductExclusionsModel->saveB2bExclusionsInCompanies($productType, $productId, $newValidAgencies, Model_B2bProductExclusions::OPTIONS_INCLUDE);
            }

            if (!empty($oldInvalidAgencies)) {
                // remove
                $b2bPriceModel->deleteProductPricingByAgencies($productType, $productId, $oldInvalidAgencies, Model_B2BProductPricing::OPTIONS_INCLUDE);
                $b2bProductExclusionsModel->removeProductFromExclutions($productType, $productId, $oldInvalidAgencies, Model_B2bProductExclusions::OPTIONS_INCLUDE);
            }
        }
    }

}