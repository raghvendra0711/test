<?php
class Helper_PurgeUrl
{

    public function submitPurgeData($type, $productType, $id, $extraData = array())
    {
        $response = array(
            'status' => 'failed',
            'msg' => 'Data not found',
            'data' => NULL
        );
        try {
            $map = [
                "workshop" => ["course", "course_city", "bundle", "bundle_city", "api"],
                "pricing_course" => ["course", "course_city"],
                "pricing_bundle" => ["bundle", "bundle_city"],
                "course" => ["course", "course_city", "bundle", "bundle_city", "api"],
                "bundle" => ["bundle", "bundle_city", "api"],
                "seo" => ["seo"]
            ];
            if ($type != 'seo') {
                if (empty($id)) {
                    return $response;
                }
            }
            $unique_transaction_id = $type . '_' . $id;
            $idsArray = array($id);
            $purgeUrlData = array();
            $countryIDs = !empty($extraData['countryIds']) ? $extraData['countryIds'] : array();
            $cityIds = !empty($extraData['cityIds']) ? $extraData['cityIds'] : [];
            $isClassroom = isset($extraData['isClassroom']) ? (int)$extraData['isClassroom'] : 0;
            if (!empty($type) && !empty($map[$type])) {
                $actionTypes = $map[$type];
                $courseObj = new Model_Courses();
                $bundleObj = new Model_Bundles();
                if (!empty($actionTypes)) {
                    foreach ($actionTypes as $index => $label) {
                        $urlsData = array();
                        switch ($label) {
                            case 'course':
                                $urlsData = $courseObj->getCoursePageUrlsByIds($idsArray, $label);
                                if (!empty($urlsData)) {
                                    $purgeUrlData = array_merge($purgeUrlData, $urlsData);
                                }
                                break;
                            case 'course_city':
                                $urlsData = $courseObj->getCoursePageUrlsByIds($idsArray, $label, $countryIDs, $cityIds);
                                if (!empty($urlsData)) {
                                    $purgeUrlData = array_merge($purgeUrlData, $urlsData);
                                }
                                break;
                            case 'bundle':
                                $bundleIds = array();
                                if ($productType == 'course') {
                                    $bundlesData = $bundleObj->getBundleListByCourseIds($idsArray);
                                    if (!empty($bundlesData)) {
                                        $bundleIds = array_column($bundlesData, 'linkable_id');
                                    }
                                } else {
                                    $bundleIds = $idsArray;
                                }
                                $urlsData = $bundleObj->getBundlePageUrlsByIds($bundleIds, $label);
                                if (!empty($urlsData)) {
                                    $purgeUrlData = array_merge($purgeUrlData, $urlsData);
                                }
                                break;
                            case 'bundle_city':
                                $bundleIds = array();
                                if ($productType == 'course') {
                                    $bundlesData = $bundleObj->getBundleListByCourseIds($idsArray);
                                    if (!empty($bundlesData)) {
                                        $bundleIds = array_column($bundlesData, 'linkable_id');
                                    }
                                } else {
                                    $bundleIds = $idsArray;
                                }
                                $urlsData = $bundleObj->getBundlePageUrlsByIds($bundleIds, $label, $countryIDs, $cityIds);
                                if (!empty($urlsData)) {
                                    $purgeUrlData = array_merge($purgeUrlData, $urlsData);
                                }
                                break;
                            case 'api':
                                $urlsData = $bundleObj->getApiByProductType($productType, $id, $countryIDs,$type, $cityIds, $isClassroom);
                                if (!empty($urlsData)) {
                                    $purgeUrlData = array_merge($purgeUrlData, $urlsData);
                                }
                                break;
                            case 'seo':
                                $purgeData = !empty($extraData['data']) ? $extraData['data'] : array();
                                $reindex = !empty($extraData['reindex']) ? true : false;
                                $purge = !empty($extraData['purge']) ? true : false;
                                $modelObj = new Model_Seo();
                                $seoPurgeData = $modelObj->validateUrlWithNoindex($purgeData);
                                foreach ($seoPurgeData as $key => &$seo) {
                                    if (!empty($seo)) {
                                        $seo['linkable_type'] = 'seo';
                                        $indexSubmission = $reindex ? true : false;
                                        if ($seo['noindex']) {
                                            $indexSubmission = false;
                                        }
                                        $seo['indexing_submission'] = $indexSubmission;
                                        $seo['purge_submission'] = $purge ? true : false;
                                        $seo['linkable_id'] = $seo['seo_id'];
                                        $seo['unique_transaction_id'] = 'seo_' . $seo['seo_id'];
                                        unset($seo['noindex']);
                                    }
                                }
                                if (!empty($seoPurgeData)) {
                                    $purgeUrlData = array_merge($purgeUrlData, $seoPurgeData);
                                }
                                break;
                            default:

                                break;
                        }
                    }
                }
            }
            if ($type != 'seo') {
                foreach ($purgeUrlData as $key => &$data) {
                    $data['indexing_submission'] = false;
                    if (array_key_exists('noindex', $data)) {
                        $data['indexing_submission'] = ($data['noindex']) ? false : true;
                    }
                    $data['purge_submission'] = true;
                    unset($data['noindex']);
                }
                $purgeUrlData = array_map(function ($arr) use ($unique_transaction_id) {
                    return $arr + ['unique_transaction_id' => $unique_transaction_id];
                }, $purgeUrlData);
            }
            if (!empty($purgeUrlData) && is_array($purgeUrlData)) {
                $purgeApi = new BaseApp_Communication_PurgeApi();
                $response['data'] = $purgeApi->submitPurdeUrlData($purgeUrlData);
                $response['status'] = 'success';
                $response['msg'] = 'Ok';
            }

            // $this->log('submitPurgeUrlData data processed', $purgeUrlData);
        } catch (Exception $e) {
            $this->log('submitPurgeUrlData failed', $e);
            $response['msg'] = 'Some error occurred while fetching data.';
        }
        return $response;
    }

    private function log($message, $data = null)
    {
        $logMessage = "\n[" . date('Y-m-d H:i:s') . "] $message";
        if (!empty($data)) {
            $logMessage .= ' [ ' . json_encode($data) . ' ]';
        }
        file_put_contents(APPLICATION_PATH . '/../error.log', $logMessage, FILE_APPEND);
    }
}
