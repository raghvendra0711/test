<?php

class IndexController extends BaseApp_Controller_Backend {

    public function indexAction() {

    }
    public function index2Action() {
 
    }

}
