<?php

class UserController extends BaseApp_Controller_Action {

    public function logoutAction() {
        /*
        $sess = new Zend_Session_Namespace('auth');
        $sess->unsetAll();
        */
        $this->_logout();
        $this->redirect('/');
    }

    public function loginAction() {                
        $redirect = $this->getRequest()->getParam('redirect');
        if(BaseApp_Auth::getLoggedInUserId()) {
            if($redirect) {
                $this->_redirect($redirect);
            }            
            $this->_redirect('/');            
        }        
        $this->_logout();
        $form = new Form_Login;
        if ($this->getRequest()->isPost() && $form->isValid($this->getRequest()->getPost())) {
            if(!$this->_login($form->getValues(), $message, $redirect)) {
                $this->view->message = $message;
            }
        }
        $this->view->form = $form;
    }

    protected function _logout() {
        $communicator = new BaseApp_Communication_Accounts();
        $communicator->logout();
    }

    protected function _login($data, &$message, $redirect=false) {   
        $communicator = new BaseApp_Communication_Accounts();
        $responce = $communicator->login($data['email'], $data['password']);                
        if($responce[BaseApp_Communication_Accounts::STR_RESPONSE_KEY_STATUS] == BaseApp_Communication_Accounts::STR_ERROR) {
            $message = $responce[BaseApp_Communication_Accounts::STR_RESPONSE_KEY_MESSAGE];
            return false;
        }
        if(!isset($responce['data']['roles']) || !$responce['data']['roles'] || !is_array($responce['data']['roles'])) {
            $this->_redirect('/');
        }                                
        
        $permission = new Model_Permission();
        $module = new Model_Module();
        
        $permissions = $permission->fetchAll(array('role_id in (?)' => array_keys($responce['data']['roles'])));
        if(!$permissions) {
            $this->_redirect('/');
            /*
            $message = "No Roles are assignd for this user";
            return false;            
             * 
             */
        }
        $moduleIds = array_column($permissions, 'module_id');
        if ($moduleIds) {
            $modules = $module->fetchAll(array('module_id in (?)' => $moduleIds));
            $urls = array_column($modules, 'url');                        
            $userData = array(
                I9SIMPLEX_USER_MODULE_SESSION_NAME => array(
                    $responce['data']['id'] => $urls
                ) 
            );
            BaseApp_Auth::setAuthModuleSession($userData);
        }
        if($redirect) {
            $this->_redirect($redirect);
        }
        $this->_redirect('/');
    }

    
}
