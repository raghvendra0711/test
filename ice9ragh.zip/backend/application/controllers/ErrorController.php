<?php

class ErrorController extends BaseApp_Controller_Error {
    public function forbiddenAction() {
		$module = $this->getRequest ()->getParam ( 'fmodule' );
		$controller = $this->getRequest ()->getParam ( 'fcontroller' );
		$action = $this->getRequest ()->getParam ( 'faction' );
		$role = $this->getRequest ()->getParam ( 'frole' );
                $this->view->message = "You don't have access to this action (".$module . "/" . $controller . "/" . $action."). Please contact your manager.";
		//throw new BaseApp_Exception ( 'Forbidden : ' . $module . ', ' . $controller . ', ' . $action . ' for ' . $role . ' role.', 403 );
	}
   public function downAction(){
       $this->view->message = SIMPLEX_MAINTENANCE_MESSAGE;
   }
}

