<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Model_Module extends BaseApp_Dao_Module {

    protected $_useCache = false;

}

// End of Class