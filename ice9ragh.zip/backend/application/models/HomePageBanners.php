<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_HomePageBanners extends BaseApp_Dao_HomePageBanners{

    const HOME_PAGE_OFFER_BANNER = 'home_page_offer_banner';

    public function addBanner($data){
        $db = $this->getDb();
        $db->beginTransaction();
        try{
            $bundleIds = array();
            $bannerData = array(
                                'banner_name' =>$data['banner_name'],
                                'linkable_id' =>$data['coupon_id'],
                                'linkable_type' =>self::HOME_PAGE_OFFER_BANNER,
                                'banner_start_date' =>strtotime($data['validFrom']),
                                'banner_end_date' =>strtotime($data['validto']),
								                'auto_apply_coupon' =>$data['auto_apply_coupon'],
                                );
            if(!empty($data['offer_bundle_id'])){
                if(isset($data['bundle_hidden_sort_add']) && !empty($data['bundle_hidden_sort_add'])){
                    $bundleIds = $data['bundle_hidden_sort_add'];
                }    
            }
            unset($data['banner_name']);
            unset($data['coupon_id']);
            unset($data['validFrom']);
            unset($data['validto']);
            unset($data['offer_bundle_list']);
            unset($data['offer_bundle_id']);
            unset($data['bundle_hidden_sort_add']);
            unset($data['auto_apply_coupon']);
            $this->setFromArray($bannerData)->save();
            $bannerId = $this->banner_id;
            $imageObj = new Model_Images();
            foreach ($data as $key => $value) {
                $imageData = array('name'=>$key ,'imagePath'=>$value,'imageDescription'=>$key);
                $imageObj->saveBannerOfferImages($bannerId,self::HOME_PAGE_OFFER_BANNER, $imageData);
                $imageObj->clean();
            }
            $objLookup = new Model_lookUp();
            if(!empty($bundleIds)){
                $bundleOrder = explode(',',$bundleIds);
                foreach ($bundleOrder as $key => $value) {
                    $lookUpDataSave = array('type'=>self::HOME_PAGE_OFFER_BANNER,'name'=>$bannerId,'description'=>$value);
                    $objLookup->setFromArray($lookUpDataSave)->save();
                    $objLookup->clean();
                }    
            }
            $db->commit();
            return true;
        }catch (Exception $e){
            $db->rollBack();
            return false;
        }
    }

    public function EditBanner($bannerId,$data){
        $db = $this->getDb();
        $db->beginTransaction();
        try{
            $bundleIds = array();
            $bannerData = array(
                                'banner_name' =>$data['banner_name'],
                                'linkable_id' =>$data['coupon_id'],
                                'linkable_type' =>self::HOME_PAGE_OFFER_BANNER,
                                'banner_start_date' =>strtotime($data['validFrom']),
                                'banner_end_date' =>strtotime($data['validto']),
															  'auto_apply_coupon' =>$data['auto_apply_coupon'],
                                );
            if(!empty($data['offer_bundle_id_selected'])){
                if(isset($data['bundle_hidden_sort']) && !empty($data['bundle_hidden_sort'])){
                    $bundleIds = $data['bundle_hidden_sort'];
                }    
            }
            $isBundleFlag = $data['offer_bundle_id_selected'];
            unset($data['banner_name']);
            unset($data['coupon_id']);
            unset($data['validFrom']);
            unset($data['validto']);
            unset($data['offer_bundle_list_selected']);
            unset($data['offer_bundle_id_selected']);
            unset($data['bundle_hidden_sort']);
            unset($data['auto_apply_coupon']);
            $this->setId($bannerId);
            $this->setFromArray($bannerData)->update();
            $imageObj = new Model_Images();
            foreach ($data as $key => $value) {
                $imageData = array('name'=>$key ,'imagePath'=>$value,'imageDescription'=>$key);
                $imageObj->saveBannerOfferImages($bannerId,self::HOME_PAGE_OFFER_BANNER, $imageData);
                $imageObj->clean();
            }
            $objLookup = new Model_lookUp();
            $bundleBannerData = $objLookup->fetchAll(array('type =?'=>self::HOME_PAGE_OFFER_BANNER,'name =?'=>$bannerId));
            if(!empty($bundleBannerData)){
                foreach ($bundleBannerData as $key => $value) {
                    $objLookup->setId($value['lookup_id']);
                    $objLookup->setFromArray(array('status'=>0))->update();
                    $objLookup->clean();
                }
            }
            if(!empty($isBundleFlag)){
                if(!empty($bundleIds)){
                    $bundleOrder = explode(',',$bundleIds);
                    foreach ($bundleOrder as $key => $value) {
                        $lookUpDataSave = array('type'=>self::HOME_PAGE_OFFER_BANNER,'name'=>$bannerId,'description'=>$value);
                        $objLookup->setFromArray($lookUpDataSave)->save();
                        $objLookup->clean();
                    }
                }
            }
            
            $db->commit();
            return true;
        }catch (Exception $e){
            $db->rollBack();
            return false;
        }
    }

    public function deleteBanner($bannerId){
        $db = $this->getDb();
        $db->beginTransaction();
        try{
            $this->setId($bannerId);
            $this->setFromArray(array('status'=>0))->update();
            $imageObj = new Model_Images();
            $imageData = $imageObj->fetchAll(array('linkable_type =?'=>'home_page_offer_banner','linkable_id = ?'=>$bannerId));
            foreach ($imageData as $key => $value) {
                $imageObj->setId($value['image_id']);
                $imageObj->setFromArray(array('status'=>0))->update();
                $imageObj->clean();
            }
            $objLookup = new Model_lookUp();
            $bundleBannerData = $objLookup->fetchAll(array('type =?'=>self::HOME_PAGE_OFFER_BANNER,'name =?'=>$bannerId));
            if(!empty($bundleBannerData)){
                foreach ($bundleBannerData as $key => $value) {
                    $objLookup->setId($value['lookup_id']);
                    $objLookup->setFromArray(array('status'=>0))->update();
                    $objLookup->clean();
                }
            }
            $db->commit();
            return true;
        }catch (Exception $e){
            $db->rollBack();
            return false;
        }
    }


    // public function getAllBanners(){
    //     $promotions = array();
    //     $records = $this->fetchAll(array('country_id > 0'=>''),array('group' => array(array("country_id"))));
    //      foreach($records as $prom){
    //         if(array_key_exists($prom['image_order'], $promotions)){
    //            $promotions[$prom['image_order']]['country_id'][]=$prom['country_id'];
    //         }else{
    //             $promotions[$prom['image_order']]=$prom;
    //             $promotions[$prom['image_order']]['country_id']=array($promotions[$prom['image_order']]['country_id']);
    //         }
    //     }
    //     return $promotions;
    // }
    
    // public function deleteExistingbanners($indexOrder='',$imagename='',$image_id='') {
    //     if($imagename){
    //         $rowCount = $this->getDb()->delete($this->_name, array('image_order =? '=>$indexOrder,'image_name =?'=>$imagename));
    //     }
    //     elseif($image_id){
    //         $rowCount = $this->getDb()->delete($this->_name, 'banner_id = ' . $image_id);
    //     }
    //     else{
    //         $rowCount = $this->getDb()->delete($this->_name, 'image_order = ' . $indexOrder);
    //     }
    //     return $rowCount;
    // }
    
    // public function getAlreadyAddedHomePagebanners($indexorder=''){
    //     $countriesModel=new Model_Country();
    //     $countriesList = $countriesModel->getListDisplay();
    //     $currentCountries = array();
    //     $currentBanners = array();
    //     if($indexorder){
    //         $currentCountries = $this->fetchAll(array('image_order = ?'=>$indexorder));
    //         $addedcountries = array_unique(array_column($this->fetchAll(array('image_order <> ?'=>$indexorder)),'country_id'));
    //         $currentBanners = $this->fetchAll(array('image_order = ?'=>$indexorder),array('group' => array(array("image_name", "image_order"))));
    //     }else{
    //         $addedcountries = array_unique(array_column($this->fetchAll(array('image_order <> ?'=> '')),'country_id'));
    //         $currentBanners = $this->fetchAll(array('country_id = ?'=>-1),array('group' => array(array("image_name"))));
    //     }
    //     foreach($addedcountries as $val){
    //         if($countriesList[$val]){
    //             unset($countriesList[$val]);
    //         }                
    //     }      
    //     return array('excluded'=>$countriesList,'current'=>$currentCountries,'currentBanners'=>$currentBanners);
    // }


} // End of Class