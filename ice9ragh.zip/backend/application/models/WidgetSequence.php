<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_WidgetSequence extends BaseApp_Dao_WidgetSequence{

    const TYPE_BANNER = 'banner';
    const TYPE_GRID = 'grid';
    const TYPE_FRS = 'free_resources';
    const TYPE_HORIZONTAL_LIST ='horizontal_cards';
    const TYPE_VERTICAL_LIST ='vertical_list';

    const CONTENT_TYPE_DEEPLINK='deeplink';
    const CONTENT_TYPE_GRID='category';
    const CONTENT_TYPE_FRS='free_resources';

    public static $wigetKeyMapper = array(
        'horizontal_cards' => 'Horizontal Listing',
        'vertical_list' => 'Vertical Listing',
        'banner' => 'Banner',
        'grid' => 'Grid',
        'free_resources' => 'FRS',
    );
    public static $widgetMapper = array(
        self::TYPE_BANNER => array('widget_type' => self::TYPE_BANNER),
        self::TYPE_GRID => array('widget_type' => self::TYPE_GRID),
        self::TYPE_HORIZONTAL_LIST => array('widget_type' => self::TYPE_HORIZONTAL_LIST),
        self::TYPE_VERTICAL_LIST => array('widget_type' => self::TYPE_VERTICAL_LIST),
        self::TYPE_FRS => array('widget_type' => self::TYPE_FRS)
    );

    public function getSectionContentByTitle($title = "")
    {
        if (!empty($title)) {
            $db             = $this->getDb();
            $queryStatement = $db
                ->select()
                ->from(array('mhs' => $this->_name), '*')
                ->where('mhs.status=?', 1);
            $queryStatement = $queryStatement->where('mhs.title=?', $title);
            $queryStatement = $queryStatement->order('position ASC');
            $data = $db->fetchAll($queryStatement);
            if (!empty($data[0])) {
                return $data[0];
            }
        }
        return array();
    }

    public function getSectionContent($id = "")
    {
        if (!empty($id)) {
            $db             = $this->getDb();
            $queryStatement = $db
                ->select()
                ->from(array('mhs' => $this->_name), '*')
                ->where('mhs.status=?', 1);
            $queryStatement = $queryStatement->where('mhs.sequence_id=?', $id);

            $queryStatement = $queryStatement->order('position ASC');
            $data = $db->fetchAll($queryStatement);
            if (!empty($data[0])) {
                return $data[0];
            }
        }
        return array();
    }
    public function getWidgetContentByType($type=""){
        $db             = $this->getDb();
        $queryStatement = $db
            ->select()
            ->from(array('mhs' => $this->_name), '*')
            ->where('mhs.status=?',1);
        if(!empty($type)){
            $queryStatement = $queryStatement->where('mhs.widget_type=?',$type);
        } 
        $queryStatement = $queryStatement->order('position ASC'); 
        $data = $db->fetchAll($queryStatement);
        if(!empty($data[0])){
            return $data[0];
        }
        return array();
    }

    public function fetchAllWidgets(){
        try{
            $db             = $this->getDb();
            $queryStatement = $db
                ->select()
                ->from(array('mhs' => $this->_name), '*')
                ->where('mhs.status=?',1);
            $queryStatement = $queryStatement->order('position ASC');
            $data = $db->fetchAll($queryStatement);
            $res = [];
            $sortedContentIds = [];
            if(!empty($data)){
                foreach($data as $value){
                    array_push($sortedContentIds,$value['sequence_id']);
                    $res['data']['content'][$value['sequence_id']] =   $value['title']."  [".$value['widget_type'] ." ] ";
                }
            }
            $res['data']['content_ids_sorted_list'] = implode(',',$sortedContentIds);
            return $res;       
        }catch(exception $e){
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }

    public function updateWidgetOrder($data) {
        $db = $this->getDb();
        $db->beginTransaction();
        $objMobileHomeSequence = new self();   
        try{
            foreach($data as $seqId => $position){
                $updateVal = [];
                $updateVal['last_updated_timestamp'] = time();
                $updateVal['position']  = $position;            
                $objMobileHomeSequence->setId($seqId);
                $objMobileHomeSequence->setFromArray($updateVal)->update();                                              
            }
            $db->commit();
            return true;  
        }catch (Exception $e){
            $db->rollBack();            
            if (APPLICATION_ENV == 'development')
                throw $e;
           return false;
        }
    }
    public function delete($sId) {
        $db = $this->getDb();
        $db->beginTransaction();
        $objMobileHomeSequence = new self();
        $updateVal = [];
        try{        
            $updateVal['status'] = '0';
            $objMobileHomeSequence->setId($sId);
            $objMobileHomeSequence->setFromArray($updateVal)->update();
            $db->commit();
            return true;
        }catch(exception $e){
            $db->rollBack();            
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }            
    }

    public function saveWidget($data)
    {
        $db = $this->getDb();
        $objWidget = new self();
        $db->beginTransaction();
        try {
            $maxPostion = $this->getLastPostionOfWidget();
            $data['position'] = $maxPostion+1;
            $objWidget->setFromArray($data)->save();
            $db->commit();
            return $objWidget->sequence_id;
        } catch (Exception $e) {
            $db->rollBack();
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }
    public function getLastPostionOfWidget()
    {
        $db             = $this->getDb();
        $queryStatement = $db
            ->select()
            ->from(array('mhs' => $this->_name), '*')
            ->where('mhs.status=?', 1);
        $queryStatement = $queryStatement->order('position ASC');
        $data = $db->fetchAll($queryStatement);
        $maxPosition = 0;
        $data = array_column($data,'position');
        if(!empty($data)){
            $maxPosition = max($data);
        }
        return $maxPosition;
    }
} // End of Class