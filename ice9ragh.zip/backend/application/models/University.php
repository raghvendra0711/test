<?php
	
class Model_University extends BaseApp_Dao_University {

    public function getUniversityContent($id = "")
    {
        if (!empty($id)) {
            $db             = $this->getDb();
            $queryStatement = $db
                ->select()
                ->from(array('mhs' => $this->_name), '*')
                ->where('mhs.status=?', 1);
            $queryStatement = $queryStatement->where('mhs.university_id=?', $id);            
            $data = $db->fetchAll($queryStatement);
            if (!empty($data[0])) {
                return $data[0];
            }
        }
        return array();
    }

    public function saveContent($data)
    {
        
        $db = $this->getDb();
        $db->beginTransaction();
        $obj = new self();    
            
        try {                                    
                $obj->clean();
                $obj->setFromArray($data)->save();                                             
            //end 
            $db->commit();
            return true;
        } catch (Exception $e) {            
            $db->rollBack();
            return false;
        }        
    }

    

    public function updateContent($data,$id) {
        $db = $this->getDb();
        $db->beginTransaction();
        $obj = new self();  
        try{            
            $obj->setId($id);
            $obj->setFromArray($data)->update();            
            $db->commit();
            return true;  
        }catch (Exception $e){
            $db->rollBack();            
            if (APPLICATION_ENV == 'development')
                throw $e;
           return false;
        }
    }
} // End of Class
