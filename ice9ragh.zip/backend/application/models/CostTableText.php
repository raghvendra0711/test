<?php

class Model_CostTableText extends BaseApp_Dao_CostTableText {

   public function getTableDataByCourseId($courseId,$tableId) {
        return current($this->fetchAll(array('course_id=?' => $courseId,'cost_label_id=?'=> $tableId)));
    }

    public function getExamDetailByCourseId($courseId = 0, $costLableId = 0) {
        $sql = $this->getDb()->select()
                ->from(array('ct' => 'cost_table_text'), array('id','course_id', 'exam_id'))
                ->join(array('ed' => 'exam_details'), 'ed.id=ct.exam_id', array('name'))
                ->where('ct.course_id=?', $courseId)
                ->where('ct.cost_label_id=?', $costLableId)
                ->where('ct.status =?', 1)
                ->where('ed.status =?', 1)
        ;
        $resultData = $this->getDb()->fetchAll($sql);
        return $resultData;
    }

   /**
    * Check if $courseId has any exam mapped.
    * @param type $courseId
    * @return string
    */
    /**
    public function getForInclusion($courseId = 0, $trainingId = 0) {
        $returnData = array();
        $sql = $this->getDb()->select()
                ->from(array('ct' => 'cost_table_text'), array('course_id', 'exam_id'))
                ->join(array('ed' => 'exam_details'), 'ed.id=ct.exam_id', array('name'))
                ->join(array('ci' => 'courseInclusion'), 'ct.course_id = ci.course_id', array())
                ->join(array('cc' => 'course_cost'), 'ct.course_id = cc.course_id', array())
                ->where('ct.course_id=?', $courseId)
                ->where('ct.cost_label_id=?', 1)
                ->where('cc.cost_lable_id=?', 1)
                ->where('ct.status =?', 1)
                ->where('cc.status =?', 1)
                ->where('ed.status =?', 1)
                ->where('ed.status =?', 1)
                ->where("ci.linkable_type = 'exam'")
        //->where('ci.status =?', 1)
        ;
        if($trainingId != 0 ) {
            $sql->where('ci.training_id=?', $trainingId);
            $sql->where('ci.status=?', 1);
        }
        $resultData = $this->getDb()->fetchAll($sql);
        $returnData = array();
        if (!empty($resultData)) {
            foreach ($resultData as $res) {
                if (!empty($res['exam_id'])) {
                    $returnData['exams']['exam' . $res['exam_id']] = 'exam (Name-' . $res['name'] . ')';
                }
            }
        }
        return $returnData;
    }
    **/

}
