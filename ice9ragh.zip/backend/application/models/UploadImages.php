<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_UploadImages extends BaseApp_Dao_UploadImages{
	
    protected $_useCache = false;
    
} // End of Class