<?php
class Model_CourseElearningHistory extends BaseApp_Dao_CourseElearningHistory
{
}
