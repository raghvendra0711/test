<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_Labels extends BaseApp_Dao_Labels{
	
    protected $parentLablesArray = array('business'=>'Business','technology'=>'Technology','design'=>'Design');

    public function getParentLabels (){
            return $this->parentLablesArray;
    }
        
    public function createLabel($data) {
        $db = $this->getDb();
	    $objLabel = new self();
        $pageUrl = '';
        $db->beginTransaction();
        try{
            $accreditorArr = $data['accreditor_id'];
            unset($data['accreditor_id']);
            if(isset($data['url'])) {
                $pageUrl = trim($data['url']);
                $checkSlash = substr($pageUrl, 0,1);
                if($checkSlash != '/'){
                    $pageUrl = trim('/'.$pageUrl);
                }
                $objLabel->setPageUrl($pageUrl);
                unset($data['url']);
            }
            $objLabel->setFromArray($data)->save();
            $dataSave = array(
                'controller' => self::SEO_DEFAULT_CONTROLLER,
                'action' => self::SEO_DEFAULT_ACTION,
                'params' => json_encode(array(self::SEO_DEFAULT_PARAM_KEY=>$objLabel->label_id)),
                'linkable_id' => $objLabel->label_id,
                'linkable_type' => 'label'
            );
            $modelSeo = new Model_Seo();
            $seoData = $modelSeo->getDataByUrl($pageUrl);
            $modelSeo->setId($seoData['seo_id']);
            $modelSeo->setFromArray($dataSave)->update();

            // save accreditor info
            if (!empty($accreditorArr)) {
                $accreditorMappingObj = new Model_AccreditorMapping();
                foreach ($accreditorArr as $accreditorId) {
                    $accreditorRow = array();
                    $accreditorRow['accreditor_id']= $accreditorId;
                    $accreditorRow['linkable_type'] = 'category';
                    $accreditorRow['linkable_id'] = $objLabel->label_id;
                    $accreditorMappingObj->setFromArray($accreditorRow)->save();
                }
            }
            // --
            $db->commit();
            return $objLabel->label_id;
        }
        catch (Exception $e){
            $db->rollBack();
            return false;
        }
    }   
    
    public function updateLabel($data) {
        $db = $this->getDb();
	    $objLabel = new self();
        $db->beginTransaction();
        try{
            $accreditorArr = $data['accreditor_id'];
            unset($data['accreditor_id']);

            $objLabel->setId($data['label_id']);
            $objLabel->setFromArray($data)->update();

            $accreditorMappingObj = new Model_AccreditorMapping();
            $conds = array(
                'linkable_id=?' => $data['label_id'],
                'linkable_type=?' => 'category',
            );

            $courseAccreditorArr = $accreditorMappingObj->fetchAll($conds);
            // delete
            if(!empty($courseAccreditorArr)) {
                foreach($courseAccreditorArr as $courseAccreditorRow){
                    $accreditorMappingObj->clean();
                    $accreditorMappingObj->setId($courseAccreditorRow['id']);
                    $accreditorMappingObj->delete();
                }
            }
            // add
            if(!empty($accreditorArr)) {
                foreach ($accreditorArr as $accreditorId) {
                    $accreditorRow = array();
                    $accreditorRow['accreditor_id']= $accreditorId;
                    $accreditorRow['linkable_type'] = 'category';
                    $accreditorRow['linkable_id'] = $data['label_id'];
                    $accreditorMappingObj->setFromArray($accreditorRow)->save();
                }
            }
            $db->commit();
            return true;
        }
        catch (Exception $e){
            $db->rollBack();
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }
    
    public function getLabelsToshow(){
        $objCourse = new self();
        $labels = array();
        $type = $objCourse->fetchAll();
        foreach($type as $indexId => $data) {
            $labels[$data['label_id']] = $data['name'];
        }
        return $labels;
    }

    public function getByPartName($partName) {
        return $this->fetchAll( array('name LIKE ?'=>'%'.$partName.'%'), array(), false);
    }
    
    public function getByParentLabel($parentLabel=array(), $fullData=false) {
        $condition = array();
        if($parentLabel) {
            $condition["FIND_IN_SET('?', parentLabel)>0"] = new Zend_Db_Expr(implode("', parentLabel)>0 OR FIND_IN_SET('",$parentLabel));
        }
        
        $returnData = array();
        $options = array();
        $data = $this->fetchAll($condition, $options, false);
        if($fullData) {
            return $data;
        }
        
        foreach($data as $indexId => $dataReal) {
            if(!trim($dataReal['parentLabel'])) {
                continue;
            }
            $parentLabels = explode(",", $dataReal['parentLabel']);            
            foreach($parentLabels as $parentLabelSingle) {
                if($parentLabel && !in_array($parentLabelSingle, $parentLabel)) {
                    continue;
                }
                $order = count($dataReal);
                if($dataReal[$parentLabelSingle.'OrderNo']) {
                    $order = $dataReal[$parentLabelSingle.'OrderNo'];
                }
                $returnData[$parentLabelSingle][] = array(
                    'label_id' => $dataReal['label_id'],
                    'name' => $dataReal['name'],
                    'order' => $order
                );
            }            
        }        
        foreach($returnData as $parentLabelSingle => $dataReal) {
            usort($dataReal, array($this,'_sortLabelByOrder'));
            $returnData[$parentLabelSingle] = $dataReal;
        }
        unset($data);
        return $returnData;
    }
    
    private function _sortLabelByOrder($a, $b){
        if ($a == $b)
            return 0;
        return ($a['order'] < $b['order']) ? -1 : 1;
    }
    
    public function getById($labelId) {
        return current($this->fetchAll( array('label_id = ?'=> $labelId), array(), false));
    }
    
    public function getNameById($labelId){
        $objCourse = new self();
        $data = current($objCourse->fetchAll( array('label_id = ?'=>$labelId), array('columns'=>array('name'), false)));
        return $data['name'];
    }
    
    public function getDisplayNameById($labelId){
        $objCourse = new self();
        $data = current($objCourse->fetchAll( array('label_id = ?'=>$labelId), array('columns'=>array('displayName'), false)));
        return $data['displayName'];
    }
    
    public function getFlyoutLabelData() {
        
    }

    public function getCategoriesHavingChapterVideo(){
        $this->_joinTables = array('courses'=>array('cond'=>'courses.category_id = categories.category_id','cols'=>array()),
                                    'chapterVideo'=>array('cond'=>'chapterVideo.course_id = courses.course_id','cols'=>array()));
        $this->_joinType = 'Right';
        $res = $this->fetchAll(array(), array('group'=>'courses.category_id','order'=>'displayOrder asc','columns'=>array('category_id','name','displayOrder')), false);
        $categories = array();
        foreach ($res as $key => $value) {
            $categories[$value['category_id']] = $value['name'];
        }
        return $categories;
    }
    
    public function _afterFetchAll($data){
        return $data;
    }
    
    public function getLabelByIds($labelIds) {
        $return = array();
        if(!$labelIds) {
            return $return;
        }
        foreach ($this->fetchAll(array('label_id IN (?)'=>$labelIds), array(), false) as $labelData) {
            $return[$labelData['label_id']] = $labelData['displayName'];
        }
        return $return;
    }

    public function buildCdnPurgeData($labelId,$action){
        $returnArr = array();
        //array_push($returnArr,array('linkable_id'=>$labelId,'linkable_type'=>'label','action'=>$action,'url'=>PURGE_WEBSITE,'created_at'=>time(),'updated_at'=>time()) );
        return $returnArr;
    } // end of function
    public function getPrimaryLableData()
    {
        $return = array();
        $data = $this->fetchAll();
        if (!empty($data)) {
            uasort($data, function ($a, $b) {
                return strcmp($a['name'], $b['name']);
            });
            foreach ($data as $key => $value) {
                $return[$value['label_id']] = $value['label_id'] . ' - ' . $value['name'];
            }
        }
        return $return;
    }

    /**
     * Fetch Category Label for FRS
     * Sreerag@simplilearn.net
     */
    
    public function getFRSLabelData()
    {
        $return = array();
        $data = $this->fetchAll();        
        if (!empty($data)) {
            uasort($data, function ($a, $b) {
                return strcmp($a['name'], $b['name']);
            });
            foreach ($data as $key => $value) {
                $return[$value['label_id']] = $value['label_id'] . ' - ' . $value['name'];
            }
        }
        return $return;
    }

    
    
} // End of Class