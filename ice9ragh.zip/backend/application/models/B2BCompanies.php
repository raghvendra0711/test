<?php

class Model_B2BCompanies extends BaseApp_Model
{
    const SIMPLILEARN_ID = 1194;

    public function createB2bCompanies($insertData)
    {
        $dbM = new Model_Default;
        $productSection = new Model_ProductSectionData();
        $data = $this->fetchRelatedData($insertData);
        $preparedData = $this->prepareData($insertData, $data, "insert");
        $currentId =  !empty($preparedData['id']) ? $preparedData['id'] : "";
        $result = "";
        try {
            if (!empty($preparedData) && !empty($preparedData['agency'])) {
                $result =  $dbM->B2bCompanies->insert($preparedData);
            }
            if ((empty($preparedData['agency'])) || is_array($result)) {
                $productSection->updateSyncStatus($currentId);
            }        
        } catch (Exception $e) {
            $result = $e->getMessage();
            if(!empty($result)){
                $this->log($result);
            }
        }
        return $result;
    }

    public function fetchRelatedData($insertData)
    {
        $companyId = !empty($insertData['id']) ? $insertData['id'] : "";
        $sync  = new BaseApp_Synchronizer_B2bCompanies();
        $db = $sync->getDao()->getDb();
        $return = array();
        $linkableType = array('company', 'agency');
        $sectionType = array("agency","domain","lmsurl");
        $sql = $db->select()
            ->from(array('ps' => 'productSectionData'), array('*'))
            ->join(array('sm' => 'sectionMapping'), 'sm.section_id=ps.id')
            ->where('sm.linkable_id=?', $companyId)
            ->where('sm.linkable_type IN (?)', $linkableType)
            ->where('ps.status = ?', 1)
            ->where('sm.status = ?', 1);
        $companydata = $db->fetchAll($sql);
        $companySpecific = array();

        $companySpecificQuery = $db->select()
            ->from(array('ps' => 'productSectionData'), array('*'))
            ->where('ps.id=?', $companyId)
            ->where('ps.sectionType =?', "company")
            ->where('ps.status = ?', 1);
        $companySpecific = $db->fetchAll($companySpecificQuery);
        $companySpecific = !empty($companySpecific) && !empty($companySpecific[0]) ? $companySpecific[0] : "";


        $sqlQuery = $db->select()
            ->from(array('ps' => 'productSectionData'), array('*'))
            ->where('ps.company=?', $companyId)
            ->where('ps.sectionType in (?)', $sectionType)
            ->where('ps.status = ?', 1);
        $lmsData = $db->fetchAll($sqlQuery);
        $agencyId = "";
        $domain = array();
        $agencySfdcId = "";
        $lmsUrl = "";
        if (!empty($lmsData)) {
            foreach ($lmsData as $key => $value) {
                if ($value['sectionType'] == 'agency') {
                    $agencyId = !empty($value['id']) ? $value['id'] : "";
                    $agencySfdcId = !empty($value['company_sf_acc_id']) ? $value['company_sf_acc_id'] : "";
                }
                if($value['sectionType'] == 'domain'){
                    $domain[] = !empty($value) ? $value : "";
                }
                if($value['sectionType'] == 'lmsurl'){
                    $lmsUrl = !empty($value['name']) ? $value['name'] : "";
                }
            }
        }
        
        $sqlCategory = $db->select()
            ->from(array('companyProductMapping'), array('linkable_id', 'company_id'))
            ->where('company_id =?', $companyId)
            ->where('linkable_type = ?', 'category')
            ->where('status = ?', 1);
        $categoryDataAll = $db->fetchAll($sqlCategory);
        $linkableIds = array();
        if (!empty($categoryDataAll)) {
            foreach ($categoryDataAll as $k => $v) {
                $linkableIds[] = $v['linkable_id'];
            }
        }
        $labelDataAll = array();
        if (!empty($linkableIds)) {
            $labelsSql = $db
                ->select()
                ->from(array('labels'), array('label_name' => 'name', 'label_id'))
                ->joinLeft('seo', 'seo.linkable_id = labels.label_id and seo.linkable_type="label"', array('url'))
                ->joinLeft('images', 'images.linkable_id = labels.label_id and images.linkable_type="label" and images.name="label_icon"', array('imagePath'))
                ->where('labels.label_id IN (?)', $linkableIds)
                ->where('labels.status = ?', 1);
            $labelDataAll = $db->fetchAll($labelsSql);
        }
        $excSql = $db
            ->select()
            ->from(array('pr' => 'b2b_product_exclusions'), array('*'))
            ->where('pr.status = ?', 1)
            ->where('pr.company_id = ?', $companyId);
        $excDataArr = $db->fetchAll($excSql);
        $excCoursesData = array();
        $excMPData = array();
        if (!empty($excDataArr)) {
            foreach ($excDataArr as $keyC => $valueC) {
                if ($valueC['linkable_type'] == BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE) {
                    $excCoursesData[] = !empty($valueC['linkable_id']) ? $valueC['linkable_id'] : "";
                }
                if ($valueC['linkable_type'] == BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES) {
                    $excMPData[] = !empty($valueC['linkable_id']) ? $valueC['linkable_id'] : "";
                }
            }
        }

        if (!empty($agencyId)) {
            $b2bAgencySql = $db->select()
                ->from(array('b2bAgencyDetails'), array('*'))
                ->where('status = ?', 1)
                ->where('agency_id in (?)', $agencyId);
            $agencyDataLms = $db->fetchAll($b2bAgencySql);
            $agencyDataLms = !empty($agencyDataLms)  && !empty($agencyDataLms[0]) ? $agencyDataLms[0] : "";
            if(empty($agencyDataLms) && $companyId == Model_B2BCompanies::SIMPLILEARN_ID){
                $agencyDataLms['agency_id'] = !empty($agencyId) ? $agencyId : "";
                $agencyDataLms['lms_url'] = !empty($lmsUrl) ? $lmsUrl : "";
            }
            if(!empty($agencySfdcId)){
                $agencyDataLms['agencySfdcId'] = !empty($agencySfdcId) ? $agencySfdcId : "";
            }
        }
        $return['companyData'] = !empty($companydata) ? $companydata : "";
        $return['categoryData'] = !empty($labelDataAll) ? $labelDataAll : "";
        $return['excludedMp'] = !empty($excMPData) ? $excMPData : "";
        $return['excludedCourses'] = !empty($excCoursesData) ? $excCoursesData : "";
        $return['agencyData'] = !empty($agencyDataLms) ? $agencyDataLms : "";
        $return['companySpecific'] = !empty($companySpecific) ? $companySpecific : "";
        $return['domain'] = !empty($domain) ? $domain : "";
        return $return;
    }
    public function prepareData($insertData, $fetchData , $type)
    {
        $data = array();
        $companyData = !empty($fetchData) && !empty($fetchData['companyData']) ? $fetchData['companyData'] : "";
        $categoryData = !empty($fetchData) && !empty($fetchData['categoryData']) ? $fetchData['categoryData'] : "";
        $domainData = !empty($fetchData) && !empty($fetchData['domain']) ? $fetchData['domain'] : "";
        $companySpecific = !empty($fetchData) && !empty($fetchData['companySpecific']) ? $fetchData['companySpecific'] : "";
        $data['id'] = !empty($insertData['id']) ? $insertData['id'] : !empty($companySpecific['id']) ? $companySpecific['id'] : "";
        $data['name'] = !empty($insertData['name']) ? $insertData['name'] : !empty($companySpecific['name']) ? $companySpecific['name'] : "";
        $data['identifier'] = !empty($insertData['description']) ? $insertData['description'] : !empty($companySpecific['description']) ? $companySpecific['description'] : "";
        $data['imageUrl'] = !empty($insertData['imageUrl']) ? $insertData['imageUrl'] : !empty($companySpecific['imageUrl']) ? $companySpecific['imageUrl'] : "";

        $data['pricePlan'] = !empty($insertData['company_price_plans']) && $insertData['company_price_plans'] == 1 ? "flat_discount" : !empty($companySpecific['company_price_plans']) && $companySpecific['company_price_plans'] == 1 ? "flat_discount" :  "flat_price";
        $details = array();
        $agency = array();
        $companyPricing = array();
        $companyProducts = array();
        $domain = array();
        $bannerImage = "";
        $bannerText = "";
        if (!empty($companyData)) {
            foreach ($companyData as $key => $value) {
                if ($value['sectionType'] == 'partnership_section') {
                    $details[$value['sectionTitle']]['name'] = !empty($value['name']) ? $value['name'] : "";
                    $details[$value['sectionTitle']]['description'] = !empty($value['description']) ? $value['description'] : "";
                }
                if ($value['sectionType'] == 'b2bTrainingType') {
                    $companyPricing[] = $value['name'];
                }
                if ($value['sectionType'] == 'banner_section' && $value['sectionTitle'] == 'banner_image' && !empty($value['name'])) {
                    $bannerImage = $value['name'];
                }
                if ($value['sectionType'] == 'banner_section' && $value['sectionTitle'] == 'banner_text' && !empty($value['name'])) {
                    $bannerText = $value['name'];
                }
                if ($value['sectionType'] == 'b2bProductType') {
                    $companyProducts[] = $value['name'];
                }
                if ($value['sectionType'] == 'agency') {
                    $agency['id'] = $value['section_id'];
                    $agency['name'] = $value['name'];
                    $agency['companySfAccId'] = !empty($fetchData) && !empty($fetchData['agencyData']) && !empty($fetchData['agencyData']['agencySfdcId']) ? $fetchData['agencyData']['agencySfdcId'] : "";
                    $agency['sectionType'] = !empty($value['sectionType']) ? $value['sectionType'] : "";
                    $agency['gid'] = !empty($fetchData) && !empty($fetchData['agencyData']) && !empty($fetchData['agencyData']['gid']) ? $fetchData['agencyData']['gid'] : "";
                    $agency['manager_email'] = !empty($fetchData) && !empty($fetchData['agencyData']) && !empty($fetchData['agencyData']['manager_email']) ? $fetchData['agencyData']['manager_email'] : "";
                    $agency['lms_url'] = !empty($fetchData) && !empty($fetchData['agencyData']) && !empty($fetchData['agencyData']['lms_url']) ? $fetchData['agencyData']['lms_url'] : "";
                }
            }
        }
        if(!empty($companyPricing)){
            $companyProducts[] = BaseApp_Dao_ProductTypes::TYPE_ID_COURSE;
        }
        if(!empty($domainData)){
            foreach($domainData as $key=>$value){
                $domainId = !empty($value['id']) ? $value['id'] : "";
                $domainName = !empty($value['name']) ? $value['name'] : "";
                array_push($domain, ['id' => $domainId, 'name' => $domainName]);
            }
        }
        if (!empty($agency) && !empty($domain)) {
            $agency['domain'] = !empty($domain) ? $domain : "";
        }
        $category = array();
        if (!empty($categoryData)) {
            foreach ($categoryData as $key => $value) {
                $category[$value['label_id']] = $value;
            }
        }
        $data['companyPricing'] = !empty($companyPricing) ? $companyPricing : "";
        $data['companyProducts'] = !empty($companyProducts) ? $companyProducts : "";
        $data['details'] = !empty($details) ? $details : "";
        $data['parentCompanySfAccId'] = !empty($insertData['company_sf_acc_id']) ? $insertData['company_sf_acc_id'] : !empty($companySpecific['company_sf_acc_id']) ? $companySpecific['company_sf_acc_id'] : "";
        $data['banner_image'] = !empty($bannerImage) ? $bannerImage : "";
        $data['banner_text'] = !empty($bannerText) ? $bannerText : "";
        $data['allowed_categories'] = !empty($category) ? $category : "";
        $data['excluded_mp'] = !empty($fetchData) && !empty($fetchData['excludedMp']) ? $fetchData['excludedMp'] : array();
        $data['excluded_courses'] = !empty($fetchData) && !empty($fetchData['excludedCourses']) ? $fetchData['excludedCourses'] : array();
        if (!empty($agency['lms_url'])) {
            $data['agency'][$agency['id']] =  $agency;
        }
        $excludedIndex = array('excluded_courses','excluded_mp');
        if ($type == "insert") {
            $result = !empty($data) ? $this->emptyCheck($data,$excludedIndex) : "";
            return $result;
        } else {
            return $data;
        }
    }
    private function emptyCheck($data = [],$exclude = [])
    {
        foreach ($data as $key => $value) {
            if (!in_array($key, $exclude)) {
                if (empty($data[$key])) {
                    unset($data[$key]);
                }
            }
        }
        return $data;
    }
    public function insertProductExclusionData($linkableType, $linkableId, $companyIds)
    {
        try {
            $dbM = new Model_Default;
            $field = "";
            if ($linkableType == "bundle") {
                $field = 'excluded_mp';
            } else if ($linkableType == "course") {
                $field = 'excluded_courses';
            }
            $multi = array(
                "multiple" => true
            );
                $result = $dbM->B2bCompanies->update(array('id' => array('$in' => $companyIds)), array('$push' => array($field => $linkableId)),$multi);
        } catch (Exception $e) {
            $result = $e->getMessage();
            if (!empty($result)) {
                $this->log($result);
            }
        }
    }

    public function updateExclusionList($linkableType, $linkableId)
    {
        try {
            $dbM = new Model_Default;
            $field = "";
            if ($linkableType == "bundle") {
                $condition = array(
                    'excluded_mp' => strval($linkableId),
                    'companyProducts' => strval(BaseApp_Dao_ProductTypes::TYPE_ID_BUNDLE)
                );
                $field = 'excluded_mp';
            } else if ($linkableType == "course") {
                $condition = array(
                    'excluded_courses' => strval($linkableId),
                    'companyProducts' => BaseApp_Dao_ProductTypes::TYPE_ID_COURSE
                );
                $field = 'excluded_courses';
            }
            $fields = array(
                '_id' => 0,
                'id' => 1
            );
            $data = $dbM->B2bCompanies->find($condition, $fields)->toArray();
            $data = !empty($data[0]) ? $data : array();

            $id = array();
            foreach ($data as $key => $value) {
                $id[] = !empty($value['id']) ? $value['id'] : "";
            }
            $multi = array(
                "multiple" => true
            );

            $result = $dbM->B2bCompanies->update(array('id'=> array('$in' =>$id)), array('$pull' => array($field => $linkableId)), $multi);
        } catch (Exception $e) {
            $result = $e->getMessage();
            if(!empty($result)){
                $this->log($result);
            }
        }
        return $result;
    }
    public function updateExclusionByAgency($linkableType, $linkableId, $companyId,$inclusionFlag)
    {
        try {
            $dbM = new Model_Default;
            $field = "";
            $id = array();
            foreach ($companyId as $key => $value) {
                $id[] = !empty($value['id']) ? $value['id'] : "";
            }
            if ($linkableType == "bundle") {
                $field = 'excluded_mp';
            } else if ($linkableType == "course") {
                $field = 'excluded_courses';
            }
            $multi = array(
                "multiple" => true
            );

            $result = $dbM->B2bCompanies->update(array('id'=> array($inclusionFlag =>$id)), array('$pull' => array($field => $linkableId)), $multi);
        } catch (Exception $e) {
            $result = $e->getMessage();
            if(!empty($result)){
                $this->log($result);
            }
        }
        return $result;
    }
    public function updateB2bCompanies($updateData, $Id)
    {
        $dbM = new Model_Default;
        $productSection = new Model_ProductSectionData();
        $updateData['id'] = !empty($Id) ? $Id : "";
        $data = $this->fetchRelatedData($updateData);
        $preparedData = $this->prepareData($updateData, $data ,"update");  
        $result = "";
        $condition = array(
            'id' => $Id
        );
        $dbData = $dbM->B2bCompanies->find($condition)->toArray();
        try {
            if (!empty($preparedData) && !empty($preparedData['agency'])) {
                if (!empty($dbData)) {
                    $result =  $dbM->B2bCompanies->update($condition, array('$set' => $preparedData));
                } else {
                    $result =  $dbM->B2bCompanies->insert($preparedData);
                }
            }
            if ((empty($preparedData['agency'])) || is_array($result)) {
                $productSection->updateSyncStatus($Id);
            } 
        } catch (Exception $e) {
            $result = $e->getMessage();
            if(!empty($result)){
                $this->log($result);
            }
        }
        return $result;
    }
    public function deleteB2bCompanies($id)
    {
        $dbM = new Model_Default;
        $result = $dbM->B2bCompanies->remove(array('id' => ($id)));
        if ($result != true && is_array($result) && $result['err'] != null) {
            throw new BaseApp_Exception('Error occurred while Deleting data. Mongo error : ' . $result['err']);
        }
    }
    private function log($message, $data = null)
    {
        $logMessage = "\n[" . date('Y-m-d H:i:s') . "]" ."B2BCompanies"."$message";
        if (!empty($data)) {
            $logMessage .= ' [ ' . json_encode($data) . ' ]';
        }
        file_put_contents(APPLICATION_PATH . '/../../backend/error.log', $logMessage, FILE_APPEND);
    }
}
