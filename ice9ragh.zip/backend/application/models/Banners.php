<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_Banners extends BaseApp_Dao_Banners{
	
    public function createBanner($bannerData) {
        $db = $this->getDb();
        $objBanner = new self();
        $db->beginTransaction();
	try{
            $objBanner->setFromArray($bannerData)->save();            
            $db->commit();
            return $objBanner->banner_id;
        }
        catch (Exception $e){
            $db->rollBack();
            return false;
        }
    }
    
    public function updateBanner($bannerData) {
        $db = $this->getDb();
	$objBanner = new self();
        $db->beginTransaction();
        try{
            $objBanner->setId($bannerData['banner_id']);
            $objBanner->setFromArray($bannerData)->update();  
            $db->commit();
            return true;
        }
        catch (Exception $e){
            $db->rollBack();
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }
    
    public function saveBanner($bannerData) {
        $objBanner = new self();
        $conds = array(
            'linkable_id=?'=>$bannerData['linkable_id'], 
            'linkable_type=?'=>$bannerData['linkable_type'],
            'banner_type=?' =>$bannerData['banner_type']     
        );
        $bannerExistsing = current($objBanner->fetchAll($conds));
        if($bannerExistsing) {
            $bannerData['banner_id'] = $bannerExistsing['banner_id'];
            return $this->updateBanner($bannerData);
        }
        else {
            return $this->createBanner($bannerData);
        }
    }
    
    public function getByLinkable($linkableId, $linkableType) {
        $conds = array(
            'linkable_id=?'=>$linkableId, 
            'linkable_type=?'=>$linkableType
        );
        return $this->fetchAll($conds);
    }
    
} // End of Class