<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_CourseConversion extends BaseApp_Dao_CourseConversion{


	public function addCourseConversion($data){
		$db = $this->getDb();
        $db->beginTransaction();
        try{
        	$conversionCountryArr = array();
    		$this->setFetchDisabled(true);
        	$conversionData = current($this->fetchAll(array(), array('columns'=>array('conversion_group_id','conversion_batch_id'), 'order' => array('conversion_group_id DESC'),'limit' => 1)));
        	$batchId = 1;
        	$groupId = 1;
        	if(!empty($conversionData['conversion_group_id'])){
        		$batchId = $conversionData['conversion_batch_id'] + 1;
        		$groupId = $conversionData['conversion_group_id'] + 1;
        	}
        	$counter = 0;
            foreach ($data as $key => $value) {
            	array_push($conversionCountryArr,array('conversion_group_id'=> ($groupId + $counter),'country_id'=>$key));
            	foreach ($value as $row => $dataSet) {
            		$dataSet['conversion_group_id'] = $groupId + $counter;
            		$dataSet['conversion_batch_id'] = $batchId;
            		$this->setFromArray($dataSet)->save();
            		$this->clean();
            	}
            	$counter ++;
            }
            $objConversionCountry = new Model_CourseConversionCourtry();
            if(!empty($conversionCountryArr)){
            	foreach ($conversionCountryArr as $countryKey => $countryValue) {
            		$objConversionCountry->setFromArray($countryValue)->save();
            		$objConversionCountry->clean();
            	}
            }
            $db->commit();
            return true;
        }catch (Exception $e){
            pr($e->getMessage());
            $db->rollBack();
            return false;
        }
	}


	public function editCourseConversion($data,$courseId){
		$db = $this->getDb();
        $db->beginTransaction();
        try{
        	$groupIdArr = array();
        	$currentData = $this->fetchAll(array('linkable_id =?'=>$courseId));
        	foreach ($currentData as $key => $value) {
        		array_push($groupIdArr,$value['conversion_group_id']);
        	   	$this->clean();
                $this->setId($value['course_conversion_id']);
                $this->delete();
        	}
        	$objConversionCountry = new Model_CourseConversionCourtry();
        	$currentCountryData = $objConversionCountry->fetchAll(array('conversion_group_id in (?)'=>$groupIdArr));
        	foreach ($currentCountryData as $key => $value) {
        	   	$objConversionCountry->clean();
                $objConversionCountry->setId($value['course_country_id']);
                $objConversionCountry->delete();
        	}

        	$conversionCountryArr = array();
        	$this->setFetchDisabled(true);
        	$conversionData = current($this->fetchAll(array(), array('columns'=>array('conversion_group_id','conversion_batch_id'), 'order' => array('conversion_group_id DESC'),'limit' => 1)));
        	$batchId = 1;
        	$groupId = 1;
        	if(!empty($conversionData['conversion_group_id'])){
        		$batchId = $conversionData['conversion_batch_id'] + 1;
        		$groupId = $conversionData['conversion_group_id'] + 1;
        	}
        	$counter = 0;
            if(!empty($data)){
                foreach ($data as $key => $value) {
                    array_push($conversionCountryArr,array('conversion_group_id'=> ($groupId + $counter),'country_id'=>$key));
                    foreach ($value as $row => $dataSet) {
                        $this->clean();
                        $dataSet['conversion_group_id'] = $groupId + $counter;
                        $dataSet['conversion_batch_id'] = $batchId;
                        $this->setFromArray($dataSet)->save();
                    }
                    $counter ++;
                }
            }
            
            
            if(!empty($conversionCountryArr)){
            	foreach ($conversionCountryArr as $countryKey => $countryValue) {
            		$objConversionCountry->clean();
            		$objConversionCountry->setFromArray($countryValue)->save();
            	}
            }
            $db->commit();
            return true;
        }catch (Exception $e){
            pr($e->getMessage());
            $db->rollBack();
            return false;
        }
	}

	public function deleteCourseConversion($courseId){
		$db = $this->getDb();
        $db->beginTransaction();
        try{
        	$groupIdArr = array();
        	$currentData = $this->fetchAll(array('linkable_id =?'=>$courseId));
        	foreach ($currentData as $key => $value) {
        		array_push($groupIdArr,$value['conversion_group_id']);
        	   	$this->clean();
                $this->setId($value['course_conversion_id']);
                $this->delete();
        	}
        	$objConversionCountry = new Model_CourseConversionCourtry();
        	$currentCountryData = $objConversionCountry->fetchAll(array('conversion_group_id in (?)'=>$groupIdArr));
        	foreach ($currentCountryData as $key => $value) {
        	   	$objConversionCountry->clean();
                $objConversionCountry->setId($value['course_country_id']);
                $objConversionCountry->delete();
        	}
            $db->commit();
            return true;
        }catch (Exception $e){
            pr($e->getMessage());
            $db->rollBack();
            return false;
        }
	}

	public function getDataForCourseConversion($courseId){
		$returnArr = array();
		$conversionArr = array();
		$convesrionSql = $this->getDb()->select()
                        ->from(array('cv' => 'courseConversion'),array('conversrionCatgegory','conversionName','conversionValue','linkable_id'))
                        ->joinLeft(array('cvc' => 'courseConversionCourtry'),'cvc.conversion_group_id = cv.conversion_group_id', array('cvc.country_id as conversionCountry'))
                        ->where('cv.status = ?', 1)
                        ->where('cvc.status = ?', 1)
                        ->where('cv.linkable_type = ?', 'course')
                        ->where('cv.linkable_id = ?', $courseId);
        $conversionSqlResult = $this->getDb()->fetchAll($convesrionSql);

        if(!empty($conversionSqlResult)){
        	foreach($conversionSqlResult as $conversionData) {
            	$conversionArr[$conversionData['conversionCountry']][$conversionData['conversrionCatgegory']][$conversionData['conversionName']] = $conversionData['conversionValue'];
        	}
        	$returnArr['course_id'] = $conversionSqlResult[0]['linkable_id'];
        	$returnArr['form_data'] = $conversionArr;
        }
        return $returnArr;
	}

    public function getCountryForConversionCourse($courseId){
        
        $conversionArr = array();
        $convesrionSql = $this->getDb()->select()
                        ->from(array('cv' => 'courseConversion'),array())
                        ->join(array('cvc' => 'courseConversionCourtry'),'cvc.conversion_group_id = cv.conversion_group_id', array('cvc.country_id as conversionCountry'))
                        ->join(array('co' => 'country'),'cvc.country_id = co.country_id', array('co.name as countryName'))
                        ->where('cv.status = ?', 1)
                        ->where('cvc.status = ?', 1)
                        ->where('cv.linkable_type = ?', 'course')
                        ->where('co.status = ?', 1)
                        ->where('cv.linkable_id = ?', $courseId)
                        ->group(array('co.name'));
        $conversionSqlResult = $this->getDb()->fetchAll($convesrionSql);
        if(!empty($conversionSqlResult)){
            foreach($conversionSqlResult as $conversionData) {
                $isRow = '';
                if($conversionData['conversionCountry'] == US_COUNTRY_ID){
                    $isRow = '/Row';
                }
                array_push($conversionArr,$conversionData['countryName'].$isRow);
            }
        }
        return implode(',', $conversionArr);
    }

} // End of Class