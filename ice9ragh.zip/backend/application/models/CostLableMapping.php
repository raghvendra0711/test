<?php

class Model_CostLableMapping extends BaseApp_Dao_CostLableMapping {

    public function getMappingData($trainingTypes) {
        $costLableMapping = $conds = array();
        if (!empty($trainingTypes)) {
            $sql = $this->getDb()->select()
                    ->from('cost_label_mapping as cmap')
                    ->where('cmap.osl = ?', (int) BaseApp_Dao_CostLableMapping::ACTIVE);
            foreach ($trainingTypes as $trainingId) {
                if (in_array(BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM, $trainingId)) {
                    $sql->orWhere('cmap.class_room = ?', (int) BaseApp_Dao_CostLableMapping::ACTIVE);
                }
                if (in_array(BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS, $trainingId)) {
                    $sql->orWhere('cmap.lvc = ?', (int) BaseApp_Dao_CostLableMapping::ACTIVE);
                }
            }
            $sql->orWhere('cmap.osl = ?', (int) BaseApp_Dao_CostLableMapping::IN_ACTIVE);
            $sql->Where('cmap.lvc = ?', (int) BaseApp_Dao_CostLableMapping::IN_ACTIVE);
            $sql->Where('cmap.lvc = ?', (int) BaseApp_Dao_CostLableMapping::IN_ACTIVE);
            $data = $this->getDb()->fetchAll($sql);
            return $data;
        }
        return $costLableMapping;
    }
    
    public function getCostLabelId($costLabel) {
        $data = array();
        if (!empty($costLabel)) {
            $sql = $this->getDb()->select()
                    ->from('cost_label_mapping as cmap')
                    ->where('cmap.name = ?', $costLabel);
            $data = $this->getDb()->fetchCol($sql);
        }
        return $data;
    }
}
