<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
   
class Model_City extends BaseApp_Dao_City{	
    
    public function getNameById($cityIds=array()) {
        $conds = array();
        $return = array();
        if($cityIds) {
            $conds['city_id IN (?)'] = $cityIds;
        }
        $this->setFetchDisabled(true);
        foreach($this->fetchAll($conds) as $cityData) {
            $return[$cityData['city_id']] = $cityData['name'];
        }
        $this->setFetchDisabled(false);
        return $return;
    }


	public function getCityDetailsByCityIdForInvoice($cityId){
        $data=array();
        if($cityId){
            $select = $this->getDb()->select()
                    ->from(array('c'=>'city'))
                    ->where('city_id =?',$cityId);
            $data =  $this->getDb()->fetchAll($select);
            if($data)
                return $data;
            else
                return array();
        }
        return $data;
    }
    
    public function getCityId($cityName){
        return $this->fetchAll(array('name =?'=>$cityName),array(),false);
    }

    // public function citiesConsolidate(){
    //     $select = $this->getDb()->select()
    //                 ->from(array('c'=>'city'))
    //                 ->where('city_id =?',$cityId);
    //         $data =  $this->getDb()->fetchAll($select);
    //     CONCAT(if(displayName='', city, displayName),', ',region_name)
    // }
    
    public function getTimeZone($cityId) {
        $conds = array(
            'city_id=?' => $cityId
        );
        $options = array(
            'columns' => 'location_time_zone'
        );
        $data = current($this->fetchAll($conds, $options, false));
        if($data) {
            return $data['location_time_zone'];
        }
        return false;
    }

    public function getCityRegionList($countryId) {
        $returnData = array();
        foreach($this->fetchAll(array('country_id =? '=>$countryId), array('columns'=> array('city_id','name','region_name'), 'order' => array('city_id DESC'))) as $tempId => $dataReal) {
            $cityName = $dataReal['name'];
                if(!empty($dataReal['region_name']))
                    $cityName = $cityName.','.$dataReal['region_name'];
            $returnData[$dataReal['city_id']] = $cityName;
        }
        return $returnData;
    }

    public function getCityIdbyIp($ip){
        $ipdata = explode('.', $ip);
        $ipAddress = ($ipdata[0] * 256 * 256 * 256) + ($ipdata[1] * 256 * 256) + ($ipdata[2] * 256) + ($ipdata[3]);
        $cityData = array();
        $sql = $this->getDb()->select()
                ->from(array('rc' => self::RAW_CITIES))
                ->where('rc.ipto>=?', $ipAddress)
                ->limit(1);
        $data = $this->getDb()->fetchRow($sql);
        if(!empty($data)){
            $cityData = current($this->fetchAll(array('name =?'=>$data['region'],'region_name =?'=>$data['city'])));
        }
        return $cityData;
    }

    public function getStateCode($regionCode) {
        $returnData = array();
        foreach($this->fetchAll(array('country_id =? '=>$countryId), array('columns'=> array('city_id','name','region_name'), 'order' => array('city_id DESC'))) as $tempId => $dataReal) {
            $cityName = $dataReal['name'];
                if(!empty($dataReal['region_name']))
                    $cityName = $cityName.','.$dataReal['region_name'];
            $returnData[$dataReal['city_id']] = $cityName;
        }
        return $returnData;
    }

    public function getCityDetails($cityId) {
        $response = array('status' => false, 'msg' => '', 'data' => array());
        if (empty($cityId)) {
            $response['msg'] = "Empty city id passed";
            return $response;
        }
        $cityData = $this->fetchAll(array('city_id =?' => $cityId));
        if (count($cityData) > 0) {
            $data = $cityData[0];
        }
        $response['status'] = true;
        $response['msg'] = "Success";
        $response['data'] = $data;
        return $response;
    }

} // End of Class
