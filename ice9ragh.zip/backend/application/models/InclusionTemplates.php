<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_InclusionTemplates extends BaseApp_Dao_InclusionTemplates{	

    public function getTemplates() {
        $data = $this->fetchAll();
        $returnData = array();
        foreach($data as $insexTemp => $dataReal) {
            $returnData[$dataReal['inclusion_id']] = array(
                'name' => $dataReal['name'],
                'templateData' => $dataReal['templateData'],
                'templateIconPath' => $dataReal['templateIconPath']
            );
        }
        return $returnData;
    }
} // End of Class