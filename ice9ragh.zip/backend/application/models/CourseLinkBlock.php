<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Model_CourseLinkBlock extends BaseApp_Dao_CourselinkBlock {
    private $_isCityPage = false;

    public function getCourseContent($productId,$countryId=0,$clusterId=0,$linkableType='',$linkableId=''){
        $db             = $this->getDb();
        $queryStatement = $db
            ->select()
            ->from(array('cf' => $this->_name), '*')
            ->where('cf.status=?',1)
            ->where('cf.prod_id=?',$productId)
            ->where('cf.prod_type=?','course');
        if(!empty($countryId)){
            $queryStatement = $queryStatement->where('cf.country_id=?',$countryId);
        }
        if(!empty($clusterId)){
            $queryStatement = $queryStatement->where('cf.cluster_id=?',$clusterId);
        }
        if( ($linkableType='course' || $linkableType='bundle') && !empty($linkableId)){
            if( is_array($linkableId) && count($linkableId)>0 ){
                $queryStatement = $queryStatement->where('cf.linkable_type=?',$linkableType)->where('cf.linkable_id IN(?)',$linkableId);
            }else{
                $queryStatement = $queryStatement->where('cf.linkable_type=?',$linkableType)->where('cf.linkable_id=?',$linkableId);
            }
        }
        $data = $db->fetchAll($queryStatement);
        $res['country_id']  = array_unique(array_column($data, 'country_id'));
        $res['cluster_id']  = array_unique(array_column($data, 'cluster_id'));
        
        array_walk($data,function(&$key,$elem){
            if($key['linkable_type']=='course'){
                $key['course_id'] = $key['linkable_id'];
            }else{
                $key['bundle_id'] = $key['linkable_id'];
            }  
        });
        $res['course_id']   = array_unique(array_column($data, 'course_id'));
        $res['bundle_id']   = array_unique(array_column($data, 'bundle_id'));
        /*$res['all_country'] = 0;
        if( count($res['country_id'])<2 && count($res['cluster_id'])<2 ){
            $res['all_country'] = 1;
        }*/
        if(count($res['course_id'])>0){
            $res['course_id_sorted_list'] = implode(',', $res['course_id']);
        }
        if(count($res['bundle_id'])>0){
            $res['bundle_id_sorted_list'] = implode(',', $res['bundle_id']);
        }
        return $res;
    }
    
    public function deleteCourseContent($productId,$countryId=0,$clusterId=0){
        $condition = array('prod_id=?'=>$productId, 'prod_type=?'=>'course');
        if(!empty($countryId)){
            $condition['country_id=?'] = $countryId;
        }
        if(!empty($clusterId)){
            $condition['cluster_id=?'] = $clusterId;
        } 
        
        $objCourselinkBlock = new self();
        foreach($objCourselinkBlock->fetchAll($condition, array('columns' => 'course_link_block_id'), false) as $relData) {
            $objCourselinkBlock->clean();
            $objCourselinkBlock->setId($relData['course_link_block_id']);
            if(!$objCourselinkBlock->delete()) {
                $db->rollBack();
                $message = "failed to delete related course data:{$relData['course_link_block_id']}";
                return false;
            }
        }
    }
    
    public function deleteAndReorder(){
        $db = $this->getDb();
        $db->beginTransaction();
        
        $condition = array('course_link_block_id=?'=>$this->_id, 'prod_type=?'=>'course');
        $objCourselinkBlock = new self();
        try{
            $info = $objCourselinkBlock->fetchAll($condition);

            if(!empty($info[0])){
                $conds['prod_id=?']        = $info[0]['prod_id'];
                $conds['prod_type=?']      = $info[0]['prod_type'];
                $conds['linkable_type=?']  = $info[0]['linkable_type'];
                if(isset($info[0]['country_id'])){
                    $conds['country_id=?']          = $info[0]['country_id'];
                }else{
                    $conds['country_id is null']    = '';
                }
                
                if(isset($info[0]['cluster_id'])){
                    $conds['cluster_id=?']          = $info[0]['cluster_id'];
                }else{
                    $conds['cluster_id is null']    = '';
                }
                
                //$conds['cluster_id=?']     = isset($info[0]['cluster_id'])?$info[0]['cluster_id']:0;
                $conds['status=?']         = 1;
            }
        
            foreach($objCourselinkBlock->fetchAll($condition, array('columns' => 'course_link_block_id'), false) as $relData) {
                $objCourselinkBlock->clean();
                $objCourselinkBlock->setId($relData['course_link_block_id']);
                if(!$objCourselinkBlock->delete()) {
                    $db->rollBack();
                    $message = "failed to delete related course data:{$relData['course_link_block_id']}";
                    return false;
                }
            }
        
            $order = 1;
            $data  = $objCourselinkBlock->fetchAll($conds,array('order'=>array('order ASC')));
            foreach($data as $relData) {
                $relData['order'] = $order;
                $objCourselinkBlock->clean();
                $objCourselinkBlock->setId($relData['course_link_block_id']);
                $objCourselinkBlock->setFromArray($relData)->update();
                $order++;
            }
            $db->commit();
            return true;
            
        } catch (Exception $ex) {
            $db->rollBack();
            if (APPLICATION_ENV == 'development')
                throw $ex;
            return false;
        }

    }
    
    public function getDataByTypeAndContentId($productId, $productType, $type, $trainingId, $clusterId = 0, $countryId = 0, $cityId = 0, $contentId = '', $offset = 0, $limitPerPage = null, $content = array())
    {
        $productType    = empty($productType) ? "course" : $productType;
        $clusterId      = ($clusterId == '') ? 0 : $clusterId;
        $countryId      = ($countryId == '') ? 0 : $countryId;
        $cityId         = ($cityId == '') ? 0 : $cityId;
        $allFlag        = false;

        $db = $this->getDb();
        $queryStatement = $db
            ->select()
            ->from(array('cf' => $this->_name), '*')
            ->joinLeft('courses as co', 'co.course_id = cf.linkable_id AND cf.linkable_type="course"', array(new Zend_Db_Expr('GROUP_CONCAT(DISTINCT(co.name)) as courseName')))
            ->joinLeft('bundles as b', 'b.bundle_id = cf.linkable_id AND cf.linkable_type="bundle"', array(new Zend_Db_Expr('GROUP_CONCAT(DISTINCT(b.name)) as bundleName')))
            ->joinLeft('cluster as cl', 'cf.cluster_id = cl.cluster_id', array(new Zend_Db_Expr('GROUP_CONCAT(DISTINCT(cl.name)) as clusterName'), new Zend_Db_Expr('GROUP_CONCAT(DISTINCT(cl.cluster_id)) as clusterIds')))
            ->joinLeft('country as c', 'cf.country_id = c.country_id', array(new Zend_Db_Expr('GROUP_CONCAT(DISTINCT (if((cf.country_id=0 and cf.cluster_id=0),"All Country", c.name))) AS countryName'), new Zend_Db_Expr('GROUP_CONCAT(DISTINCT (if((cf.country_id=0 and cf.cluster_id=0),0,c.country_id))) AS countryIds')))
            ->where('cf.status=?',1)
            ->order(array('cf.order asc'))
            ->group(array('cf.linkable_type','cf.linkable_id'));;
        if (!empty($productType)) {
            $queryStatement->where('cf.prod_type=?', $productType);
        }
        
        if (!empty($productId)) {
            $queryStatement->where('cf.prod_id=?', $productId);
        }else{
            $queryStatement->where('cf.prod_id=?', 0);
        }

        if (!empty($clusterId) && $clusterId!=='all') {
            $queryStatement->where('cf.cluster_id=?', $clusterId);
        }

        if (!empty($countryId) && $clusterId!=='all' ) {
            $queryStatement->where('cf.country_id=?', $countryId);
        }
        
        $data = $db->fetchAll($queryStatement);
        $contentNew = array();
        if($data != null) {
            $contentNew = array_slice($data, $offset, $limitPerPage);
        }
        return $contentNew;
    }

    public function editCourseContentFromParams($linkData, $type, $courseId, $isEdit='', $linkableType="course", $countryId=0, $clusterId=0) {
        $db                 = $this->getDb();
        $objCourselinkBlock = new self();
        
        if( !empty($countryId) || !empty($clusterId) ){
            $this->deleteCourseContent($courseId, $countryId, $clusterId);
        }
        
        $lastCreatedFaqId = array();
        $db->beginTransaction();
        $allCountriesEnable = array();
        $clusterCountriesEnable = array();
        $linkBlockIds = array();
        try {
            $linkLinkableType = !empty($linkableType) ? $linkableType : 'course';
            if (isset($linkData['linkable_type'])) {
                unset($linkData['linkable_type']);
            }
            if (isset($linkData['linkable_id'])) {
                unset($linkData['linkable_id']);
            }
            if (isset($linkData['cluster_text'])) {
                unset($linkData['cluster_text']);
            }
            if (isset($linkData['country_text'])) {
                unset($linkData['country_text']);
            }
            if (isset($linkData['cluster_id_err'])) {
                unset($linkData['cluster_id_err']);
            }
            if (isset($linkData['country_id_err'])) {
                unset($linkData['country_id_err']);
            }

            $prepareDataToSave = array();
            if (!empty($linkData)) {
                $fkey = 0;
                foreach ($linkData as $fData) {
                    $countryIds     = array();
                    $clusterIds     = array();
                    $relCourseIds   = array();
                    $relBundleIds   = array();
                    //$allCountry     = false;
                    if(!empty($countryId)){
                        $fData['country_id'] = $countryId;
                    }
                    if(!empty($clusterId)){
                        $fData['cluster_id'] = $clusterId;
                    }
                    
                    // prepare mapping data for save
                    if (!empty($fData['country_id'])) {
                        if (is_array($fData['country_id'])) {
                            $countryIds = $fData['country_id'];
                        } else {
                            $countryIds = explode(',', $fData['country_id']);
                        }
                    }

                    if (!empty($fData['cluster_id'])) {
                        if (is_array($fData['cluster_id'])) {
                            $clusterIds = $fData['cluster_id'];
                        } else {
                            $clusterIds = explode(',', $fData['cluster_id']);
                        }
                    }
                    
                    if (!empty($fData['course_id_sorted_list'])) {
                        if (is_array($fData['course_id_sorted_list'])) {
                            $relCourseIds = $fData['course_id_sorted_list'];
                        } else {
                            $relCourseIds = explode(',', $fData['course_id_sorted_list']);
                        }
                    }
                    
                    if (!empty($fData['bundle_id_sorted_list'])) {
                        if (is_array($fData['bundle_id_sorted_list'])) {
                            $relBundleIds = $fData['bundle_id_sorted_list'];
                        } else {
                            $relBundleIds = explode(',', $fData['bundle_id_sorted_list']);
                        }
                    }

                    // save or update question
                    $courseLinkBlockId = 0;
                    if (!empty($isEdit) && $isEdit === true) {
                        $courseLinkBlockId  = $fData['course_link_block_id'];
                        $linkBlockIds[]     = $fData['course_link_block_id'];
                    }

                    //$allCountry = !empty($fData['all_country']) ? true : false;

                    unset($fData['country_id']);
                    unset($fData['cluster_id']);
                    unset($fData['linkable_id']);
                    unset($fData['linkable_type']);
                    unset($fData['all_country']);
                    $objCourselinkBlock->clean();

                    //mapping data with new/old questionId
                    $dataToSave = array('course_link_block_id' => $courseLinkBlockId);
                    
                    if (!empty($countryIds)) {
                        foreach ($countryIds as $cId) {
                            $dataToSave['country_id'] = $cId;
                            $dataToSave['cluster_id'] = 0;
                            $prepareDataToSave[$fkey][] = $dataToSave;
                        }
                    }

                    if (!empty($clusterIds)) {
                        foreach ($clusterIds as $clId) {
                            $dataToSave['country_id'] = 0;
                            $dataToSave['cluster_id'] = $clId;
                            $prepareDataToSave[$fkey][] = $dataToSave;
                        }
                    }

                    /*if ((empty($countryIds) && empty($clusterIds)) || $allCountry) {
                        $dataToSave['country_id'] = 0;
                        $dataToSave['cluster_id'] = 0;
                        $prepareDataToSave[$fkey][] = $dataToSave;
                    }*/
                    $fkey++;
                }
                
                $existRelCourses = [];
                if( empty($countryId) && empty($clusterId) ){
                    if (!empty($countryIds)) {
                        foreach ($countryIds as $cnId) {
                            $existRelCourses['country'][$cnId] = $this->getCourseContent($courseId,$cnId,0);
                            $allRelCourses   = array_filter(array_unique (array_merge ($relCourseIds, $existRelCourses['country'][$cnId]['course_id'])));
                            if( count($allRelCourses) > 5 ){
                                throw new Zend_Exception(" Course limit exceeded for country Id-".$cnId);
                            }
                            $allRelBundles   = array_filter(array_unique (array_merge ($relBundleIds, $existRelCourses['country'][$cnId]['bundle_id'])));
                            if( count($allRelBundles) > 2 ){
                                throw new Zend_Exception(" Bundle limit exceeded for country Id-".$cnId);
                            }
                        }
                    }

                    if (!empty($clusterIds)) {
                        foreach ($clusterIds as $clId) {
                            $existRelCourses['cluster'][$clId] = $this->getCourseContent($courseId,0,$clId);
                            $allRelCourses   = array_filter(array_unique (array_merge ($relCourseIds, $existRelCourses['cluster'][$clId]['course_id'])));
                            if( count($allRelCourses) > 5 ){
                                throw new Zend_Exception(" Course limit exceeded for clusetr Id-".$clId);
                            }
                            $allRelBundles   = array_filter(array_unique (array_merge ($relBundleIds, $existRelCourses['cluster'][$clId]['bundle_id'])));
                            if( count($allRelBundles) > 2 ){
                                throw new Zend_Exception(" Bundle limit exceeded for clusetr Id-".$clId);
                            }
                        }
                    }
                }

                $newDataToSave = array();
                if (!empty($relCourseIds)) {
                    foreach ($relCourseIds as $couresId) {
                        $newPrepareDataToSave = $prepareDataToSave[0];
                        foreach($prepareDataToSave[0] as $key=>$elem){
                            $newPrepareDataToSave[$key]['courseId'] = $couresId;
                            if(!empty($elem['country_id']) && empty($elem['cluster_id'])){
                                if(in_array($couresId,$existRelCourses['country'][$elem['country_id']]['course_id'])){
                                    unset($newPrepareDataToSave[$key]);
                                }
                            }
                            if( !empty($elem['cluster_id']) && empty($elem['country_id']) ){
                                if(in_array($couresId,$existRelCourses['cluster'][$elem['cluster_id']]['course_id'])){
                                    unset($newPrepareDataToSave[$key]);
                                }
                            }
                        }
                        $newDataToSave = array_merge($newDataToSave,$newPrepareDataToSave);
                    }
                }

                if (!empty($relBundleIds)) {
                    foreach ($relBundleIds as $bundleId) {
                        $newPrepareDataToSave = $prepareDataToSave[0];
                        foreach($prepareDataToSave[0] as $key=>$elem){
                            $newPrepareDataToSave[$key]['bundleId'] = $bundleId;
                            unset($prepareDataToSave[0][$key]['courseId']);
                            
                            if(!empty($elem['country_id'])){
                                if(in_array($bundleId,$existRelCourses['country'][$elem['country_id']]['bundle_id'])){
                                    
                                    unset($newPrepareDataToSave[$key]);
                                }
                            }
                            if(!empty($elem['cluster_id'])){
                                if(in_array($bundleId,$existRelCourses['cluster'][$elem['cluster_id']]['bundle_id'])){
                                    unset($newPrepareDataToSave[$key]);
                                }
                            }
                        }
                        $newDataToSave = array_merge($newDataToSave,$newPrepareDataToSave);
                    }
                }
            }

            if (!empty($newDataToSave)) {
                $cOrder  = $clOrder =  array();
                $bcOrder = $bclOrder =  array();
                foreach ($newDataToSave as $j => $dataToSave) {
                    if(isset($dataToSave['courseId'])){
                        if(!empty($dataToSave['country_id'])){
                            if(!isset($cOrder[$dataToSave['country_id']])){
                                if(isset($existRelCourses['country'][$dataToSave['country_id']]['course_id'])){
                                    $cOrder[$dataToSave['country_id']] = count($existRelCourses['country'][$dataToSave['country_id']]['course_id']);
                                }else{
                                    $cOrder[$dataToSave['country_id']] = 0;
                                }
                                
                            }
                            $cOrder[$dataToSave['country_id']]++;
                            $dataToSave['order'] = $cOrder[$dataToSave['country_id']];
                        }
                        if(!empty($dataToSave['cluster_id'])){
                            if(!isset($clOrder[$dataToSave['cluster_id']])){
                                if(isset($existRelCourses['cluster'][$dataToSave['cluster_id']]['course_id'])){
                                    $clOrder[$dataToSave['cluster_id']] = count($existRelCourses['cluster'][$dataToSave['cluster_id']]['course_id']);
                                }else{
                                    $clOrder[$dataToSave['cluster_id']] = 0;
                                }
                            }
                            $clOrder[$dataToSave['cluster_id']]++;
                            $dataToSave['order'] = $clOrder[$dataToSave['cluster_id']];
                        }
                        $dataToSave['linkable_id']      =   $dataToSave['courseId'];
                        $dataToSave['linkable_type']    =   'course';
                        unset($dataToSave['courseId']);
                    }
                    
                    if(isset($dataToSave['bundleId'])){
                        if(!empty($dataToSave['country_id'])){
                            if(!isset($bcOrder[$dataToSave['country_id']])){
                                if(isset($existRelCourses['country'][$dataToSave['country_id']]['bundle_id'])){
                                    $bcOrder[$dataToSave['country_id']] = count($existRelCourses['country'][$dataToSave['country_id']]['bundle_id']);
                                }else{
                                    $bcOrder[$dataToSave['country_id']] = 0;
                                }
                                
                            }
                            $bcOrder[$dataToSave['country_id']]++;
                            $dataToSave['order'] = $bcOrder[$dataToSave['country_id']];
                        }
                        if(!empty($dataToSave['cluster_id'])){
                            if(!isset($bclOrder[$dataToSave['cluster_id']])){
                                if(isset($existRelCourses['cluster'][$dataToSave['cluster_id']]['bundle_id'])){
                                    $bclOrder[$dataToSave['cluster_id']] = count($existRelCourses['cluster'][$dataToSave['cluster_id']]['bundle_id']);
                                }else{
                                    $bclOrder[$dataToSave['cluster_id']] = 0;
                                }
                            }
                            $bclOrder[$dataToSave['cluster_id']]++;
                            $dataToSave['order'] = $bclOrder[$dataToSave['cluster_id']];
                        }
                        $dataToSave['linkable_id']      =   $dataToSave['bundleId'];
                        $dataToSave['linkable_type']    =   'bundle';
                        unset($dataToSave['bundleId']);
                    }
                    unset($dataToSave['course_link_block_id']);
                    $dataToSave['prod_type']    = 'course';
                    $dataToSave['prod_id']      = $courseId;
                    $dataToSave['status']       = 1;
                    $objCourselinkBlock->clean();
                    $objCourselinkBlock->setFromArray($dataToSave)->save();
                }
            }
            $db->commit();
            return true;
        } catch (Exception $e) {
            $db->rollBack();
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }
}
// End of Class