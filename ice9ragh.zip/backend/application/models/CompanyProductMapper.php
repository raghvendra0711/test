<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Model_CompanyProductMapper extends BaseApp_Dao_CompanyProductMapper {
    public function saveProductMapping($companyId, $linkableType, $dataArr) {
        try{
            $fields = array('company_id =?'=>$companyId, 'linkable_type =?'=>$linkableType,'status =?'=>1);

            $checkExisting = $this->fetchAll($fields);
            if(!empty($checkExisting)){
                foreach ($checkExisting as $key => $value) {
                    $this->clean();
                    $this->setId($value['id']);
                    $this->setFromArray(array('status'=>0))->update();
                }
            }
            if(!empty($dataArr)){
                $order = 1;
                foreach ($dataArr as $key => $value) {
                    $this->clean();
                    $data['linkable_id'] = $value;
                    $data['linkable_type'] = $linkableType;
                    $data['order'] = $order;
                    $data['company_id'] = $companyId;
                    $order++;
                    $this->setFromArray($data)->save();
                }
            }
            return true;
        }catch (Exception $e){
            if (APPLICATION_ENV == 'development')
                throw $e;
           return false;
        }
    }



} // End of Class