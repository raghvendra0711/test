<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Model_CourseInclusions extends BaseApp_Dao_CourseInclusions {

    const LINKABLE_TYPE_COURSE = 'course';
    const LINKABLE_TYPE_BUNDLE = 'bundle';

    public function createcourseInclusion($inclusionData, $learningElements, $courseId, $trainingId) {
        unset($inclusionData);
        $db = $this->getDb();
        $objCourseInc = new self();
        $objSectionTemp = new Model_InclusionTemplates();
        $db->beginTransaction();
        try {
            $conds = array('course_id=?' => $courseId);
            if ($trainingId !== false) {
                $conds['training_id=?'] = $trainingId;
            }
            $properties = $objCourseInc->fetchAll($conds);
            foreach ($properties as $property) {
                if ($property['linkable_type'] == "exam") {
                    $examArr[] = $property;
                    $objCourseInc->clean();
                    $objCourseInc->setId($property['course_inclusion_id']);
                    $objCourseInc->delete();
                }
            }
            if (!empty($examArr)) {
                /**
                 * it is here means an exam is disabled.
                 * delete the data from cost_table_text
                 */
                $examIds = array_column($examArr, 'linkable_id');
                $finalArr = $examIds;
                if (isset($learningElements['exam'])) {
                    $finalArr = array_diff($examIds, $learningElements['exam']);
                }
                $examData = array('course_id' => $courseId, 'exam_id' => $finalArr);
                $courseCostMdl = new Model_Cost();
                $courseCostData = $courseCostMdl->fetchExamCoursesHavingCost($examData);
                if (!empty($courseCostData)) {
                    $costKeys = array_column($courseCostData, 'id');
                    if (!empty($costKeys)) {
                        foreach ($costKeys as $key) {
                            $courseCostMdl->clean();
                            $costUpdateData['status'] = 0;
                            $courseCostMdl->setId($key);
                            $courseCostMdl->setFromArray($costUpdateData)->update();
                        }
                    }
                }
            }
            /*
              $counter = 1;
              $linkableType = $inclusionData['linkable_type'];
              $linkableId = $inclusionData['linkable_id'];
              foreach ($inclusionData['inclusionSave'] as $key => $dataReal) {
              $inclusionIdentifier = $counter + floor(microtime(true));
              $inclusionData['inclusionSave'][$key]['inclusion_identifier'] = $inclusionIdentifier;
              $detailContent = $dataReal;
              unset($dataReal['countryIds']);
              unset($dataReal['clusterIds']);
              $courseIncData = array(
              'course_id' => $courseId,
              'type' => 'inclusion',
              'training_id' => $trainingId,
              'linkable_type' =>$linkableType,
              'linkable_id' => $linkableId,
              'inclusion_identifier' => $inclusionIdentifier
              );
              foreach ($dataReal as $keyName => $keyValue) {
              $courseIncData[$keyName] = $keyValue;
              }
              $courseResult = $objCourseInc->setFromArray($courseIncData)->save();
              $counter ++;
              }
              // Fetch All Course Inclusion
              $conds['status = ?'] = 1;
              $courseInclusionData = $objCourseInc->fetchAll($conds);
              if (!empty($courseInclusionData)) {
              $courseInclusionIdArr = array_column($courseInclusionData, 'course_inclusion_id', 'inclusion_identifier');
              if (!empty($courseInclusionIdArr)) {
              foreach ($inclusionData['inclusionSave'] as $row) {
              if (!empty($row['inclusion_identifier'])) {
              $inclusionIdentifier = $row['inclusion_identifier'];
              $row['course_inclusion_id'] = $courseInclusionIdArr[$inclusionIdentifier];
              unset($row['inclusion_identifier']);
              $detailContent = $row;
              // Save in detail content mapping also
              if (!empty($detailContent['countryIds']) || !empty($detailContent['clusterIds'])) {
              $objDetailContentMapping->createDetailContentMapping($detailContent);
              }
              }
              }
              }
              }
             */
            if (!empty($learningElements)) {
                foreach ($learningElements as $linkableType => $linkableIds) {
                    foreach ($linkableIds as $linkableId) {
                        $courseIncData = array(
                            'course_id' => $courseId,
                            'linkable_id' => $linkableId,
                            'linkable_type' => $linkableType,
                            'type' => 'learning',
                            'training_id' => $trainingId
                        );
                        $courseResult = $objCourseInc->setFromArray($courseIncData)->save();
                    }
                }
            }
            $db->commit();
            return $courseId;
        } catch (Exception $e) {
            $db->rollBack();
            return false;
        }
    }

// end of function createCourse

    public function getCourseInclusionForSelect($courseId, $trainingId = false, $forPricing = false) {
        $returnData = array();
        $conds = array(
            'course_id=?' => $courseId
        );
        if ($trainingId !== false) {
            $conds['training_id=?'] = $trainingId;
        }

        if ($forPricing) {
            foreach ($this->fetchAll($conds) as $tempId => $dataReal) {
                if ($dataReal['type'] == 'inclusion') {
                    continue;
                }
                $returnData[$dataReal['course_inclusion_id']] = $dataReal['linkable_type'] . " (ID-" . $dataReal['linkable_id'] . ")";
            }
        } else {
            foreach ($this->fetchAll($conds) as $tempId => $dataReal) {
                if ($dataReal['type'] == 'inclusion') {
                    $returnData[$dataReal['type']][] = $dataReal['inclusion_id'];
                } else {
                    $returnData[$dataReal['type']][$dataReal['linkable_type'] . $dataReal['linkable_id']] = $dataReal['linkable_type'] . " (ID-" . $dataReal['linkable_id'] . ")";
                }
            }
        }

        return $returnData;
    }

    public function getCourseInclusionToShow($courseId, $trainingId=false) {
            $returnData = array();
            $conds = array(
                'course_id=?' => $courseId
            );
            if($trainingId !== false) {
                $conds['training_id=?'] = $trainingId;
            }
            foreach($this->fetchAll($conds) as $tempId => $dataReal) {
                if($dataReal['type'] == 'inclusion') {
                    $returnData[$dataReal['type']][$dataReal['course_inclusion_id']] = array(
                       'name' => $dataReal['name'],
                       'templateIconPath' => $dataReal['templateIconPath'],
                       'templateData' => $dataReal['templateData'],
                       'isProplus' => $dataReal['isProplus']
                    );
                }
                else {
                    $returnData[$dataReal['type']][$dataReal['linkable_type'].$dataReal['linkable_id']] = $dataReal['linkable_type']." (ID-".$dataReal['linkable_id'].")";
                }

            }
            unset($returnData['inclusion']);
            return $returnData;
        }

    public function updateInclusion($data) {
        $db = $this->getDb();
        $objCourseInc = new self();
        $db->beginTransaction();
        try {
            $contentDetails = $data;
            unset($data['countryIds']);
            unset($data['countries']);
            unset($data['clusterIds']);
            unset($data['clusters']);
            $objCourseInc->setId($data['course_inclusion_id']);
            $objCourseInc->setFromArray($data)->update();
            $countryContentMapObj = new Model_CountryContentMapping();
            $countryContentMapObj->detailContentMapping($contentDetails);
            $db->commit();
            return true;
        } catch (Exception $e) {
            $db->rollBack();
            return false;
        }
    }

}

// End of Class