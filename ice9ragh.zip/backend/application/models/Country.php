<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Model_Country extends BaseApp_Dao_Country{
    

    public function getListDisplay() {
        $conds = array(

        );
        $options = array(
            'order' => array('orderNo DESC')
        );
        $countryData = array();
        foreach($this->fetchAll($conds, $options) as $indexTmp => $data) {
            $countryData[$data['country_id']] = $data['name'];
        }
        return $countryData;
    }

    public function getAllTimezones() {
        $return = array();
        foreach($this->fetchAll(array('timeZone IS NOT NULL' => ''), array('columns' => array('timeZone'), 'group' => array('timeZone'))) as $timeZones) {
            $return[$timeZones['timeZone']] = $timeZones['timeZone'];
        }
        return $return;
    }

    public function getWorkshopTimzone() {
        $return = array();
        foreach($this->fetchAll(array('timeZone = ?' => 'Asia/Kolkata'), array('columns' => array('timeZone'), 'group' => array('timeZone'))) as $timeZones) {
            $return[$timeZones['timeZone']] = $timeZones['timeZone'];
        }
        return $return;
    }

    public function getAllTimezonesWithAbbr() {
        $return = array();
        foreach($this->fetchAll(array('timeZone IS NOT NULL' => ''), array('columns' => array('timeZone'), 'group' => array('timeZone'))) as $timeZones) {
            $dateTime = new DateTime();
            $dateTime->setTimeZone(new DateTimeZone($timeZones['timeZone']));
            $abbr = sprintf("%s - %s", $dateTime->format('T'), $timeZones['timeZone']);
            $return[$timeZones['timeZone']] = $abbr;
        }
        return $return;
    }

    public function getTimeZone($countryId) {
        $conds = array(
            'country_id=?' => $countryId
        );
        $options = array(
            'columns' => 'timeZone'
        );
        $data = current($this->fetchAll($conds, $options, false));
        if($data) {
            return $data['timeZone'];
        }
        return false;
    }

    public function getById($countryIds=array()) {
        $conds = array();
        $return = array();
        if($countryIds) {
            $conds['country_id IN (?)'] = $countryIds;
        }
        foreach($this->fetchAll($conds) as $countryData) {
            $return[$countryData['country_id']] = $countryData['name'];
        }
        return $return;
    }

    public function getCurrencies($countryIds, $returnId=false) {
        $conds = array(
            'country_id IN (?)' => $countryIds
        );
        $options = array(
            'currency_id',
            'country_id'
        );
        $countries = array();
        foreach($this->fetchAll($conds, $options) as $indexTmp => $data) {
            $countries[$data['country_id']] = $data['currency_id'];
        }
        if($returnId) {
            return $countries;
        }
        $modelCurrency = new Model_Currency();
        $currencyData = $modelCurrency->getCurrencyToDisplay();;

        foreach($countries as $countryId => &$currencyId) {
            $currencyId = @$currencyData[$currencyId];
        }
        return $countries;
    }
    public function getCurrenciesIds($countryIds, $returnId=false) {
        $conds = array(
            'country_id IN (?)' => $countryIds
        );
        $options = array(
            'currency_id',
            'country_id'
        );
        $countries = array();
        foreach($this->fetchAll($conds, $options) as $indexTmp => $data) {
            $countries[$data['country_id']] = $data['currency_id'];
        }
        if($returnId) {
            return $countries;
        }
        return $countries;
    }

    public function getCurrenciesByClusterIds($clusterIds, $returnId=false) {
    	$conds = array(
    			'cluster_id IN (?)' => $clusterIds
    	);
    	$options = array(
    			'currency_id',
    			'country_id'
    	);
    	$countries = array();
    	foreach($this->fetchAll($conds, $options) as $indexTmp => $data) {
    		$countries[$data['country_id']] = $data['currency_id'];
    	}
    	if($returnId) {
    		return $countries;
    	}
    	$modelCurrency = new Model_Currency();
    	$currencyData = $modelCurrency->getCurrencyToDisplay();;

    	foreach($countries as $countryId => &$currencyId) {
    		$currencyId = @$currencyData[$currencyId];
    	}
    	return $countries;
    }
    public function getCountriesByCluster($clusterIds) {
        $conds = array(
            'cluster_id IN (?)' => $clusterIds
        );
        $options = array(
            'country_id',
            'name',
            'cluster_id'
        );
        $countries = array();
        foreach ($this->fetchAll($conds, $options) as $indexTmp => $data) {
            $countries[$data['country_id']] = $data['name'];
        }
        return $countries;
    }
    public function getCountryidByClusterId($clusterIds) {
        $conds = array(
            'cluster_id IN (?)' => $clusterIds
        );
        $options = array(
            'country_id',
            'cluster_id'
        );
        $countries = array();
        foreach ($this->fetchAll($conds, $options) as $indexTmp => $data) {
            $countries[$data['cluster_id']][] = $data['country_id'];
        }
        return $countries;
    }
    public function getCountriesByCurrency($currencyId) {
        $conds = array(
            'currency_id = ?' => $currencyId
        );
        $options = array(
            'country_id',
            'name'
        );
        $countries = array();
        foreach ($this->fetchAll($conds, $options) as $indexTmp => $data) {
            $countries[$data['country_id']] = $data['name'];
        }
        return $countries;
    }

    public function getCountryIdsRow(){        
        $notROWIds = array('6','34','35','36');
        $totalCountry =  $this->getListDisplay();
        foreach($totalCountry as $key => $value){
            if(in_array($key,$notROWIds)){
                unset($totalCountry[$key]);
            }
        }
        return $totalCountry;
    }

    public function getCountriesByTag($cTag){
        if ($cTag == "EURO"){
           return $this->getCountriesByCurrency(8);
        }
        else if ($cTag == "ROW"){
            return $this->getCountryIdsRow();
        }
    }
    

    public function getClusterByCountry($countryIds) {
        if(!is_array($countryIds)) {
            $countryIds = array($countryIds);
        }
        $conds = array(
            'country_id IN (?)' => $countryIds
        );
        $options = array(
            'country_id',
            'name',
            'cluster_id'
        );
        $countries = array();
        foreach ($this->fetchAll($conds, $options) as $indexTmp => $data) {
            $countries[$data['country_id']] = $data['cluster_id'];
        }
        if( !empty($countries) && count($countries) == 1) {
            return current($countries);
        }
        return $countries;
    }

    public function removeClusterCountries($clusterIds , $countryIds) {
        $countriesCluster = array_keys($this->getCountriesByCluster($clusterIds));
        return $countries=array_diff($countryIds, $countriesCluster);
    }

    public function getCountryDetails($countryId) {
        $response = array('status' => false, 'msg' => '', 'data' => array());
        if (empty($countryId)) {
            return $response;
        }
        $country = current($this->fetchAll(array('country_id = ?' => $countryId)));
        $response['status'] = true;
        $response['msg'] = "Success";
        $response['data'] = $country;
        return $response;
    }
    public function getCountryIdsFromCluster($clusterIds = array())
    {
        $countryIds = array();
        if (!empty($clusterIds)) {
            $countryIdsData =  $this->getCountriesByCluster($clusterIds);
            if (!empty($countryIdsData)) {
                $countryIds = array_keys($countryIdsData);
            }
        }
        return $countryIds;
    }

} // End of Class
