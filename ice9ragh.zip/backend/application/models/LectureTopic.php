<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_LectureTopic extends BaseApp_Dao_LectureTopic{	
    
} // End of Class