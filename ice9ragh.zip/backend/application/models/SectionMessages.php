<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Model_SectionMessages extends BaseApp_Dao_SectionMessages
{

    public function saveMessage($data)
    {
        $db = $this->getDb();
        try {
            if (!empty($data) && !empty($data['section_name']) && !empty($data['value'])) {
                $obj = new self();
                $db->beginTransaction();
                $obj->clean();
                if ($obj->setFromArray($data)->save()) {
                    $db->commit();
                    return true;
                }
                else {
                    $db->rollBack();
                    return false;
                }
            }
            return true;
        } catch (Exception $e) {
            $db->rollBack();
            throw $e;
            return false;
        }
    }

    public function disableMessages($ids = array())
    {
        if (!is_array($ids)) {
            $ids = array($ids);
        }

        $db = $this->getDb();
        $dataUpdate = array(
            'status' => 0,
        );
        try {
            if (!empty($ids)) {
                foreach ($ids as $key => $value) {
                    $obj = new self();
                    $db->beginTransaction();

                    $obj->clean();
                    $obj->setId($value);
                    if ($obj->setFromArray($dataUpdate)->update()) {
                        $db->commit();
                    }
                    else {
                        $db->rollBack();
                        return false;
                    }
                }
            }
            return true;
        } catch (Exception $e) {
            $db->rollBack();
            throw $e;
            return false;
        }
    }

    public function getMessagesBySection($sectionNames)
    {
        $response = array();
        if (!is_array($sectionNames)) {
            $sectionNames = array($sectionNames);
        }
        if (!empty($sectionNames)) {
            $result =  $this->fetchAll(array('section_name IN (?)' => $sectionNames), array(), false);
            if (!empty($result)) {
                foreach ($result as $key => $value) {
                    if (!empty($value) && !empty($value['section_name'])) {
                        if (empty($response[$value['section_name']])) {
                            $response[$value['section_name']] = array();
                        }
                        $response[$value['section_name']][] = $value;
                    }
                }
            }
        }
        return $response;
    }


} // End of Class