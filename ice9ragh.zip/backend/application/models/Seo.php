<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_Seo extends BaseApp_Dao_Seo{
    
    private $_supportedElements = array(
        'article' => 'article',
        'bundle' => 'bundle',
        'course' => 'course',
        'exam' => 'exam',
        'group' => 'group',
        'label' => 'label',
        'practice_test' => 'practiceTest',
        'video' => 'video', 
        'webinar' => 'webinar'        
    );

    public function getSupportedElementTypes() {
        return $this->_supportedElements;
    }
    
    public function saveSeo($dataSave) {
        $db = $this->getDb();
        $objSeo = new self();
        $db->beginTransaction();
	try{
            $objSeo->setFromArray($dataSave)->save();            
            $db->commit();
            return $objSeo->seo_id;
        }
        catch (Exception $e){
            $db->rollBack();
            return false;
        }
    }
    
    public function getDataByLinkable($linkableId, $linkableType) {
        return current($this->fetchAll(array('linkable_id=?'=>$linkableId, 'linkable_type=?'=>$linkableType)));
    }
    
    public function getElementsByType($element) {
        switch($element) {
            case 'article':
                $model = new Model_Articles();
                return $model->fetchForSelect();                   
            case 'bundle':
                $model = new Model_Bundles();
                return $model->fetchForSelect();                   
            case 'course':
                $model = new Model_Courses();
                return $model->fetchForSelect();       
            case 'group':
                $model = new Model_Groups();
                return $model->fetchForSelect();       
            case 'label':
                $model = new Model_Labels();
                return $model->fetchForSelect();     
            case 'video':    
                $model = new Model_Videos();
                return $model->fetchForSelect();     
            case 'webinar':
                $model = new Model_Webinars();
                return $model->fetchForSelect();       
            default :
                return array(
                    "status" => "error",
                    "message" => "Invalid element passed"
                );
        }
    }
    
    public function getDataByUrl($url) {
        return current($this->fetchAll(array('url=?'=>$url)));
    }
    
    public function getDataByAmpUrl($url) {
        return $this->fetchAll(array('amp_link=?'=>$url));
    }

    public function validateUrl($url){
        $seoData = current($this->fetchAll(array('url=?'=>$url,'linkable_id IS NULL'=>'','linkable_type IS NULL'=>'')));
        if(!empty($seoData)){
            return true;
        }
        return false;
    }
    public function getDataByType($linkableId, $linkableType, $controller, $action) {
        $conds = array(
            'linkable_id=?'=>$linkableId, 
            'linkable_type=?'=>$linkableType,
            'controller=?' => $controller,
            'action=?' => $action
        );
        return current($this->fetchAll($conds));
    }

    public function getFrsPurgeUrls(){
        $resData = array();
        $seoData = $this->fetchAll(array('url IS NOT NULL'=>'','linkable_id IS NOT NULL'=>'','linkable_type in (?)'=>array('article','ebook','video','webinar')), array('columns'=>array('url' => 'DISTINCT(url)')));
        if(!empty($seoData)){
            $resData = array_column($seoData,'url');
            array_push($resData,'/resources/*');
        }
        return $resData;
    }
} // End of Class