<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_Certificates extends BaseApp_Dao_Certificates{

	protected $certificateTypeArr = array('completion'=>'Course Completion','pdu'=>'PDU Certificate');

	public function getCertificateType (){
		return $this->certificateTypeArr;
	}

	public function getCertificateDetails($courseId,$type = 'course',$trainingId){
		$conds = array('linkable_id =?'=>$courseId,'linkable_type =?'=>$type);
		if($trainingId == BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM){
			$conds['training_id IN (?)'] = array(BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM,BaseApp_Dao_TrainingTypes::TYPE_LVC);
		}elseif($trainingId == BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS){
			$conds['training_id = ?'] = BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS;
		}else{
			$conds['training_id = ?'] = BaseApp_Dao_TrainingTypes::TYPE_ELEARNING;
		}
		$res = $this->fetchAll($conds);
		$returnArr = array();
		
		foreach ($res as $key => $value) {
			if($value['certificateType'] == 'pdu'){
				$appendKey =  'pdu_';
			}else{
				$appendKey = 'completion_';
			}
			if($value['training_id'] == BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM){
				foreach ($value as $key1 => $value1) {
					if($key1 == 'accreditor_id'){
						$value1 = explode(',',$value1);
						$returnArr[$appendKey.'classroom_'.$key1.'_1'] = isset($value1[0]) ? $value1[0] : '';
						$returnArr[$appendKey.'classroom_'.$key1.'_2'] = isset($value1[1]) ? $value1[1] : '';
					}else{
						$returnArr[$appendKey.'classroom_'.$key1] = $value1;
					}
				}
			}elseif($value['training_id'] == BaseApp_Dao_TrainingTypes::TYPE_LVC){
				foreach ($value as $key1 => $value1) {
					if($key1 == 'accreditor_id'){
						$value1 = explode(',',$value1);
						$returnArr[$appendKey.'lvc_'.$key1.'_1'] =  $value1 = isset($value1[0]) ? $value1[0] : '';
						$returnArr[$appendKey.'lvc_'.$key1.'_2'] =  $value1 = isset($value1[1]) ? $value1[1] : '';
					}else{
						$returnArr[$appendKey.'lvc_'.$key1] =  $value1;	
					}
				}
			}elseif($value['training_id'] == BaseApp_Dao_TrainingTypes::TYPE_ELEARNING){
				foreach ($value as $key1 => $value1) {
					if($key1 == 'accreditor_id'){
						$value1 = explode(',',$value1);
						$returnArr[$appendKey.'osl_'.$key1.'_1'] =  $value1 = isset($value1[0]) ? $value1[0] : '';
						$returnArr[$appendKey.'osl_'.$key1.'_2'] =  $value1 = isset($value1[1]) ? $value1[1] : '';
					}else{
						$returnArr[$appendKey.'osl_'.$key1] =  $value1;	
					}
				}
			}
			elseif($value['training_id'] == BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS){
				foreach ($value as $key1 => $value1) {
					if($key1 == 'accreditor_id'){
						$value1 = explode(',',$value1);
						$returnArr[$appendKey.'slvc_'.$key1.'_1'] =  $value1 = isset($value1[0]) ? $value1[0] : '';
						$returnArr[$appendKey.'slvc_'.$key1.'_2'] =  $value1 = isset($value1[1]) ? $value1[1] : '';
					}else{
						$returnArr[$appendKey.'slvc_'.$key1] =  $value1;	
					}
				}
			}
		}
		return $returnArr;
	}

	public function getCertificateListings($courseId){
		$returnArr = array();
		$certifcateData = $this->fetchAll(array('linkable_id IN (?)'=>$courseId,'name is not null'=>'','linkable_type =?'=>'course'),array('columns'=>array('certificate_id','linkable_id','training_id','certificateType')));
		if(!empty($certifcateData)){
			foreach ($certifcateData as $key => $value) {
				$returnArr[$value['linkable_id']][] =  array('certifcate_id'=>$value['certificate_id'],'training_id'=>$value['training_id'],'certificate_type'=>$value['certificateType']);
			}
		}
		return $returnArr;
	}

} // End of Class