<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_Coupons extends BaseApp_Dao_Coupons{

    const COUPON_CSV_PATH = '/../uploads/coupons/';

    public function addCoupon($couponData){
        $db = $this->getDb();
        $db->beginTransaction();
        try{
            unset($couponData['coupoCsv']);
            $couponCode = $couponData['code'];
            $courseResult = $this->setFromArray($couponData)->save();	
            $couponId = $this->coupon_id;
            $db->commit();
            return $couponId;
        }catch (Exception $e){
            $db->rollBack();
            return false;
        }
    }	
    
    public function updateCoupon($couponId, $data) {
        $db = $this->getDb();
        $objCoupon = new self();
        $db->beginTransaction();
        try{
            $objCoupon->setId($couponId);
            $objCoupon->setFromArray($data)->update();  
            $db->commit();
            return true;
        }catch (Exception $e){
            $db->rollBack();
            throw $e;
            return false;
        }
    }

    public function updateExpiryDate($data) {
        $db = $this->getDb();
        $objCoupon = new self();
        $couponData = $objCoupon->fetchAll(array('code =?'=>$data['code']));
        if(empty($couponData)){
            return false;
        }
        $couponData = $couponData[0];
        $countDiff  = $couponData['totalCount'] - $couponData['usedCount'];
        if( $countDiff == 0 ){
            return false;   
        }
        unset($data['coupoCsv']);
        unset($data['code']);
        $db->beginTransaction();
        try{
            $objCoupon->setId($couponData['coupon_id']);
            $objCoupon->setFromArray($data)->update();  
            $db->commit();
            return true;
        }catch (Exception $e){
            $db->rollBack();
            throw $e;
            return false;
        }
    }
    
    
    public function _afterFetchAll($data){
        $labels = array();
        $courses = array();
        $bundles = array();
        $pass = array();
        $masters = array();
        $trainings = array();
        $clusters = array();  
        $countries = array();
        
        foreach($data as $row){
           if($row['label_id']) {
                $labels = array_merge($labels, explode(",", $row['label_id']));
           }
           if($row['course_id']) {
                $courses = array_merge($courses, explode(",", $row['course_id']));
           }
           if($row['bundle_id']) {
                $bundles = array_merge($bundles, explode(",", $row['bundle_id']));
           }
           if($row['pass_id']) {
                $pass = array_merge($pass, explode(",", $row['pass_id']));
           }
           if($row['mom_id']) {
                $masters = array_merge($masters, explode(",", $row['mom_id']));
           }
           if($row['cluster_id']) {
                $clusters = array_merge($clusters, explode(",", $row['cluster_id']));
           }
           if($row['country_id']) {
                $countries = array_merge($countries, explode(",", $row['country_id']));
           }
        }
      
        $courseMdl = new Model_Courses();
        $courses = $courseMdl->getCourseByIdMultiple($courses);
        
        $bundleMD1 = new Model_Bundles();
        $bundles = $bundleMD1->getBundleByIds($bundles);
        
        $labelsMdl = new Model_Labels();
        $labels = $labelsMdl->getLabelByIds($labels);

        if(!empty($pass)){
            $passObj = new Model_Pass();
            $pass = $passObj->fetchForSelect(array('pass_id in (?)'=>$pass));    
        }
        
        $clusterMD1 = new Model_Clusters();
        $clusters = $clusterMD1->getById($clusters);
        
        $country = new Model_Country();
        $countries = $country->getById($countries);
        
        $modelTraining = new Model_TrainingTypes();
        $trainings = $modelTraining->getTrainingTypes();
       
        if(!empty($masters)){
        $seoModel = new Model_Seo();
        $masters = array_unique($masters);
        $masters = $seoModel->fetchForSelect(array('linkable_id IN (?)'=>$masters , 'linkable_type =?'=>'master_of_masters'));
        }
  
        
        foreach($data as &$row){
            $row['validFromDate'] = date('Y-m-d', $row['validFrom']);
            $row['validToDate'] = date('Y-m-d', $row['validto']);
            
            if($row['label_id']) {
                $row['labels'] = array();
                $label = explode(",", $row['label_id']);
                foreach($label as $labelId) {
                    $row['labels'][] = @$labels[$labelId];
                }
                $row['labels'] = implode(", ", $row['labels']);
            }
            
            if($row['course_id']) {
                $course = explode(",", $row['course_id']);
                foreach($course as $courseId) {
                    $row['courses'][] = @$courses[$courseId];
                }
                $row['courses'] = implode(", ", $row['courses']);
            }
            
            if($row['bundle_id']) {
                $bundle = explode(",", $row['bundle_id']);
                foreach($bundle as $bundleId) {
                    $row['bundles'][] = @$bundles[$bundleId];
                }
                $row['bundles'] = implode(", ", $row['bundles']);
            }

            if(!empty($row['pass_id'])) {
                $passDetails = explode(",", $row['pass_id']);
                foreach($passDetails as $passId) {
                    $row['pass'][] = @$pass[$passId];
                }
                $row['pass'] = implode(", ", $row['pass']);
            }
           
            if(!empty($row['mom_id'])) {
                foreach($masters as $masterName) {
                    $row['mom'][] = $masterName;
                }
                $row['mom'] = implode(", ", $row['mom']);
            }
  
            if($row['cluster_id']) {
                $cluster = explode(",", $row['cluster_id']);
                foreach($cluster as $clusterId) {
                    $row['clusters'][] = @$clusters[$clusterId];
                }
                $row['clusters'] = implode(", ", $row['clusters']);
            }
            if($row['country_id']) {
                $country = explode(",", $row['country_id']);
                foreach($country as $countryId) {
                    $row['countries'][] = @$countries[$countryId];
                }
                $row['countries'] = implode(", ", $row['countries']);
            }
            if($row['training_id']) {
                $training = explode(",", $row['training_id']);
                foreach($training as $trainingId) {
                    $row['Training Types'][] = $trainings[$trainingId];
                }
                $row['Training Types'] = implode(", ", $row['Training Types']);
            }
        }
        return $data;
    }

    public function buildCdnPurgeData($courseIdArr,$bundleIdArr,$passId,$action){
        $returnArr = array();
        // $objSeo = new Model_Seo();
        // $seoData = $objSeo->fetchAll(array('linkable_id in (?) '=>$courseIdArr,'linkable_type =?'=>'course'),array('columns'=>array('url','linkable_id')));
        // if(!empty($seoUrl)){
        //     foreach ($seoData as $key => $value) {
        //         array_push($returnArr,array('linkable_id'=>$value['linkable_id'],'linkable_type'=>'course','action'=>$action,'url'=>$value['url'],'created_at'=>time(),'updated_at'=>time()) );
        //     }
        // }
        // $seoData = $objSeo->fetchAll(array('linkable_id in (?)'=>$bundleIdArr,'linkable_type =?'=>'bundle'),array('columns'=>array('url','linkable_id')));
        // if(!empty($seoData)){
        //     foreach ($seoData as $key => $value) {
        //         array_push($returnArr,array('linkable_id'=>$value['bundle_id'],'linkable_type'=>'bundle','action'=>$action,'url'=>$value['url'],'created_at'=>time(),'updated_at'=>time()) );
        //     }
        // }
        // $seoData = current($objSeo->fetchAll(array('linkable_id = ?'=>1,'linkable_type =?'=>'lvc_pass'),array('columns'=>array('url','linkable_id'))));
        // if(!empty($seoData))
        //     array_push($returnArr,array('linkable_id'=>$seoData['linkable_id'],'linkable_type'=>'lvc_pass','action'=>$action,'url'=>$seoData['url'],'created_at'=>time(),'updated_at'=>time()) );
        return $returnArr;
    } // end of function

     public function fetchActiveCoupons($courseId = ''){
        $objCoupon = new self();
        $res = array();
        $condsArr = array('purpose = ?' => 'marketing','status = ?' => 1, 'validFrom < ?' => time(), 'validto > ?' => time(),'training_id !=?' =>'','training_id IS NOT NULL' =>'');
        if(!empty($courseId))
            $condsArr['FIND_IN_SET(?, course_id)>0'] = $courseId;
        $couponData  = $objCoupon->fetchForSelect($condsArr,array('order' => array('coupon_id DESC')));
        return $couponData;
    }

    public function checkCouponDisplay($courseIdArr,$countryIdArr,$labelIdArr,$clusterIdArr,$couponCode = ''){
        $countryIds = array();
        $courseIds = array();
        if(!empty($clusterIdArr)){
            $modelCountry = new Model_Country();
            $countries = $modelCountry->fetchForSelect(array("cluster_id IN (?)"=>$clusterIdArr), array(), false);
            if(!empty($countries))
                $countryIds[] = array_keys($countries);
        }
        if(!empty($countryIdArr)){
            $countryIds[] = $countryIdArr;
        }
        if(!empty($labelIdArr)){
            $modelCourses = new Model_Courses();
            $courses = $modelCourses->getbyLables($labelIdArr);
            if(!empty($courses))
                $courseIds[] = array_keys($courses);
        }
        if(!empty($courseIdArr)){
            $courseIds[] = $courseIdArr;
        }
        $courseIds = array_unique(current($courseIds));
        $countryIds = array_unique(current($countryIds));
        $objCoupon = new self();
        $condsArr['FIND_IN_SET(?, course_id)>0'] = new Zend_Db_Expr(implode(', course_id)>0 OR FIND_IN_SET(',$courseIds));
        $condsArr['FIND_IN_SET(?, country_id)>0'] = new Zend_Db_Expr(implode(', country_id)>0 OR FIND_IN_SET(',$countryIds));
        $condsArr['purpose = ?'] = 'marketing';
        $condsArr['validto > ?'] = time();
        $condsArr['displayFrontend = ?'] = 1;
        $condsArr['status = ?'] = 1;
        $couponData = $objCoupon->fetchForSelect($condsArr,array('columns'=>array('code'),'order' => array('code DESC')));
        if(!empty($couponData)){
            if(!empty($couponCode)){
                if(($key = array_search($couponCode, $couponData)) !== false) {
                    unset($couponData[$key]);
                }
            }
            if(count($couponData) >= 2) 
                return array_keys($couponData);
            else
                return array();
        }
        else
            return array();
    }


} // End of Class