<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_Lecture extends BaseApp_Dao_Lecture{
    
    private $_seoWordsSkip = array('certification', 'training', 'all-in-one', 'Certification', 'Training', 'All-in-one', 'All-in-One', 'All-In-One');
            
    public function getCoursePreviewData($courseId) {     
        $previewData = array();
        $courseDao = new Model_Courses($courseId);        
        if(!$courseDao->name) {
            return $previewData;
        }
        
        // from simplex
        $pVideoObj = new BaseApp_Dao_CoursePreviewVideos();
        $conds = array(
            'course_id = ?' => $courseId,
            'training_id = ?' => 0 
        );
        $cols = array(
            'columns' => array(
                'preview_id' => 'preview_video_id',
                'chapter_name',
                'topic' => 'name'
            )
        );
        $chaptersForUrls = array();
        foreach($pVideoObj->fetchAll($conds, $cols, false) as $dataReal) {
            if(isset($chaptersForUrls[$dataReal['chapter_name']])) {
                // not a first lession
                if($chaptersForUrls[$dataReal['chapter_name']]) {
                    $previewData['sections'][$dataReal['chapter_name']]['url'] = $chaptersForUrls[$dataReal['chapter_name']];
                }
                else {
                    $previewData['sections'][$dataReal['chapter_name']]['url'] = $this->generateLectureUrl($dataReal['chapter_name']);
                }
            }
            else {
                // first lesson
                $previewData['sections'][$dataReal['chapter_name']]['url'] = $this->generateLectureUrl($dataReal['chapter_name'], $courseDao->name);               
            }
            $previewData['sections'][$dataReal['chapter_name']]['topics'][] = $dataReal;
        }        
        if($previewData) {
            $previewData['preview_type'] = self::COURSE_PREVIEW_TYPE_MANUAL;
            return $previewData;
        }
        
        //from LMS
        $previewData['preview_type'] = self::COURSE_PREVIEW_TYPE_ELEARNING;
        $previewData['sections'] = array();
        $chaptersForUrls = array();
        
        $childChapters = array();        
        $sql = $this->getDb()->select()
                    ->from(array('c' => 'course_preview_chapter'), array('chapter_name', 'parent_chapter', 'lms_chapter_id'))                    
                    ->where('c.status = ?', 1)
                    ->where('c.parent_chapter > ?', 0)
                    ->where('c.course_id = ?', $courseId);
        //print $sql->__toString()."<br><br>";
        foreach($this->getDb()->fetchAll($sql) as $data) {
            $childChapters[$data['parent_chapter']] = array(
                'lms_chapter_id' => $data['lms_chapter_id'],
                'chapter_name' => html_entity_decode($data['chapter_name'])
            );
        }        
        $allTopics = array();
        $sql = $this->getDb()->select()
                ->from(array('c' => 'course_preview_chapter'), array('lms_chapter_id'))
                ->join(array('t' => 'course_preview_topic'), 'c.lms_chapter_id = t.lms_chapter_id AND t.status = 1', array('title', 'sco_id'))
                ->where('c.status=?', 1)
                ->where('c.course_id = ?', $courseId);
        //print $sql->__toString()."<br><br>";
        foreach($this->getDb()->fetchAll($sql) as $data) {
            $allTopics[$data['lms_chapter_id']][$data['sco_id']] = $data['title'];
        }
        
        $sql = $this->getDb()->select()
                ->from(array('c' => 'course_preview_chapter'), array('chapter_name', 'lms_chapter_id', 'section_name', 'elearning_name', 'course_id', 'elearning_id'))
                ->where('c.status=?', 1)
                ->where('c.parent_chapter=?', 0)
                ->where('c.lms_chapter_id > ?', 0)
                ->where('c.course_id = ?', $courseId)
                ->group(array('c.elearning_id', 'c.lms_chapter_id'))
                ->order(array('c.section_id', 'c.chapter_order'));
       //print $sql->__toString()."<br><br>";
       foreach($this->getDb()->fetchAll($sql) as $data) {
           $sectionName = trim($data['section_name']);
           if(!$sectionName) {
               $sectionName = trim($data['elearning_name']);
           }
           if(isset($chaptersForUrls[$data['elearning_id']][$sectionName])) {
               // not a first lession
               if(isset($chaptersForUrls[$data['elearning_id']][$sectionName][$data['lms_chapter_id']])) {
                   $previewData['sections'][$sectionName]['chapters'][$data['lms_chapter_id']]['url'] = $chaptersForUrls[$data['elearning_id']][$sectionName][$data['lms_chapter_id']];
               }
               else {
                   $previewData['sections'][$sectionName]['chapters'][$data['lms_chapter_id']]['url'] = $this->generateLectureUrl($data['chapter_name']);
               }
           }
           else {
               // first lesson
               $previewData['sections'][$sectionName]['chapters'][$data['lms_chapter_id']]['url'] = $this->generateLectureUrl($data['chapter_name'], $courseDao->name);
           }           
           $chaptersForUrls[$data['elearning_id']][$sectionName][$data['lms_chapter_id']] = $previewData['sections'][$sectionName]['chapters'][$data['lms_chapter_id']]['url'];           
           $childSection = array();
           if(isset($childChapters[$data['lms_chapter_id']])) {
               // If there are any sub chapters
               $childSection['childSection'] = $childChapters[$data['lms_chapter_id']];
               if(isset($allTopics[$childSection['childSection']['lms_chapter_id']])) {
                   $childSection['childSection']['topics'] = $allTopics[$childSection['childSection']['lms_chapter_id']];
               }
           }
           else {
               // no Sub chapters
               if(isset($allTopics[$data['lms_chapter_id']])) {
                   $childSection['topics'] = $allTopics[$data['lms_chapter_id']];
               }
           }
           $previewData['sections'][$sectionName]['section_name'] = $sectionName;
           $previewData['sections'][$sectionName]['course_id'] = $data['course_id'];
           $previewData['sections'][$sectionName]['chapters'][$data['lms_chapter_id']]['course_name'] = $courseDao->name;
           $previewData['sections'][$sectionName]['chapters'][$data['lms_chapter_id']]['chapter_name'] = $data['chapter_name'];
           if($childSection) {
               foreach($childSection as $keyChild => $valueChild) {
                   $previewData['sections'][$sectionName]['chapters'][$data['lms_chapter_id']][$keyChild] = $valueChild;
               }               
           }
       }
       unset($chaptersForUrls);
       return $previewData;        
    }
            
    public function getElearningLectureDataByCourse($courseId) {
        $lectureData = array(
            'lectureCourse' => $courseId,
            'preview_type' => self::COURSE_PREVIEW_TYPE_ELEARNING
        );        
        $lectureByChapter = array();
        // fetch URLs and lecture ids
        $sql = $this->getDb()->select()
                ->from(array('l' => 'lecture'), array('lecture_id', 'lms_chapter_id', 'is_published', 'introduction_text'))
                ->join(array('c' => 'course_preview_chapter'), 'l.lms_chapter_id = c.lms_chapter_id AND c.status = 1', array('lms_chapter_id', 'section_name', 'elearning_name'))
                ->joinLeft(array('s' => 'seo'), "s.linkable_id = l.lecture_id AND s.linkable_type='lecture' AND s.controller='". self::SEO_DEFAULT_CONTROLLER."' AND s.action='".self::SEO_DEFAULT_ACTION."' AND s.status = 1 AND s.seo_id !=0", array('url'))                
                ->where('l.status=?', 1)
                ->where('l.course_id =?', $courseId)
                ->where('l.preview_type = ?', self::COURSE_PREVIEW_TYPE_ELEARNING)
                ;
        //print $sql->__toString()."<br><br>";exit;
        foreach($this->getDb()->fetchAll($sql) as $data) {
            $sectionName = trim($data['section_name']);
            if(!$sectionName) {
                $sectionName = trim($data['elearning_name']);
            }
            $lectureByChapter[$data['lecture_id']] = $data['lms_chapter_id'];
            $lectureData['urls'][$sectionName][$data['lms_chapter_id']] = $data['url'];
            $lectureData['is_published'][$data['lms_chapter_id']] = $data['is_published'];
            $lectureData['lectureByChapter'][$data['lms_chapter_id']] = $data['lecture_id'];      
            $lectureData['intro'][$data['lms_chapter_id']] = $data['introduction_text'];
        }           
        if(!$lectureByChapter) {
            return $lectureData;
        }
        
        //fetch topics
        $lectureTopicModel = new Model_LectureTopic();
        $conds = array(
            'lecture_id IN (?)' => array_keys($lectureByChapter)
        );
        $opts = array(
            'columns' => array(
                'lecture_id',
                'preview_topic_id',
                'transcript'
            )
        );
        $topicLectureData = array();
        foreach($lectureTopicModel->fetchAll($conds, $opts, false) as $topicData) {
            $topicLectureData[$topicData['preview_topic_id']] =  $topicData['transcript'];
            if(isset($lectureByChapter[$topicData['lecture_id']])) {
                $chapterId = $lectureByChapter[$topicData['lecture_id']];
                $lectureData['topics'][$chapterId][$topicData['preview_topic_id']] =  $topicData['transcript'];
            }            
        }   
        if($topicLectureData) {
            $conds = array(
                'topic_id IN (?)' => array_keys($topicLectureData)
            );
            $opts = array(
                'columns' => array(
                    'lms_chapter_id',
                    'topic_id'
                )
            );
            $previewTopicModel = new Model_CoursePreviewTopic();
            foreach($previewTopicModel->fetchAll($conds, $opts, false) as $topicData) {
                if(isset($topicLectureData[$topicData['sco_id']])) {
                    $lectureData['topics'][$topicData['lms_chapter_id']][$topicData['sco_id']] =  $topicLectureData[$topicData['sco_id']];
                }                        
            } 
        }                
        unset($topicLectureData);
        return $lectureData;
    }
    
    public function getManualLectureDataByCourse($courseId) {
        $lectureData = array(
            'lectureCourse' => $courseId,
            'preview_type' => self::COURSE_PREVIEW_TYPE_MANUAL
        );
        
        $lectureByChapter = array();
        // fetch URLs and lecture ids
        $sql = $this->getDb()->select()
                ->from(array('l' => 'lecture'), array('lecture_id', 'chapter_name', 'is_published', 'introduction_text'))
                ->joinLeft(array('s' => 'seo'), "s.linkable_id = l.lecture_id AND s.linkable_type='lecture' AND s.controller='". self::SEO_DEFAULT_CONTROLLER."' AND s.action='".self::SEO_DEFAULT_ACTION."' AND s.status = 1 AND s.seo_id !=0", array('url'))                
                ->where('l.status=?', 1)
                ->where('l.course_id =?', $courseId)
                ->where('l.preview_type = ?', self::COURSE_PREVIEW_TYPE_MANUAL)
                ;
        foreach($this->getDb()->fetchAll($sql) as $data) {
            $lectureByChapter[$data['lecture_id']] = $data['chapter_name'];
            $lectureData['urls'][$data['chapter_name']] = $data['url'];
            $lectureData['is_published'][$data['chapter_name']] = $data['is_published'];
            $lectureData['lectureByChapter'][$data['chapter_name']] = $data['lecture_id'];
            $lectureData['intro'][$data['chapter_name']] = $data['introduction_text'];
        }        
        if(!$lectureByChapter) {
            return $lectureData;
        }                
        
        //fetch topics
        $lectureTopicModel = new Model_LectureTopic();
        $conds = array(
            'lecture_id IN (?)' => array_keys($lectureByChapter)
        );
        $opts = array(
            'columns' => array(
                'lecture_id',
                'preview_topic_id',
                'transcript'
            )
        );
        foreach($lectureTopicModel->fetchAll($conds, $opts, false) as $topicData) {
            $chgapterName = $lectureByChapter[$topicData['lecture_id']];
            $lectureData['topics'][$chgapterName][$topicData['preview_topic_id']] =  $topicData['transcript'];
        }
        return $lectureData;
    }
    
    
    public function saveElearningLecture($data) {   
        $conds = array(
            'course_id = ?' => $data['lectureCourse'],
            'preview_type = ?' => self::COURSE_PREVIEW_TYPE_ELEARNING,
            'lms_chapter_id = ?' => $data['chapter'] 
        );
        $opts = array(
            'columns' => array(
                'lecture_id'
            )
        );   
        $courseModel = new Model_Courses($data['lectureCourse']);
        $seoModel = new Model_Seo();        
        $mailData = array(
            'section_name' => isset($data['sectionName'])?$data['sectionName']:'',
            'chapter_name' => '',
            'course_name' => $courseModel->displayName,
            'url' => isset($data['chapterUrl'])?$data['chapterUrl']:'',
            'type' => ''
        );                      
        
        $lectureId = 0;
        foreach($this->fetchAll($conds, $opts, false) as $lectureData) {
            $lectureId = $lectureData['lecture_id'];
        }
        
        $chapterName = '';        
        $conds = array(
            'lms_chapter_id = ?' => $data['chapter']
        );
        $opts = array(
            'columns' => array(
                'lms_chapter_id',
                'chapter_name'
            )
        );
        $chpterModel = new Model_CoursePreviewChapter();                
        foreach($chpterModel->fetchAll($conds, $opts, false) as $chapterData) {
            $chapterName = $chapterData['chapter_name'];
            $mailData['chapter_name'] = $chapterData['chapter_name'];
        }
        
        //save URLs and lecture        
        $db = $this->getDb();
        $objLecture = new self();
        $db->beginTransaction();
        
        //lecture entry
        $data['introText'] = trim($data['introText']);
        if($lectureId) {            
            // update                                        
            $dataSave = array(
                'chapter_name' => $chapterName,
                'introduction_text' => strip_tags($data['introText'])
            );       
            $objLecture->setId($lectureId);
            $objLecture->setFromArray($dataSave)->update();
            $cdnPurgeData = $this->buildCdnPurgeData($lectureId,$data['lectureCourse'],'Lecture Id '. $lectureId.' with '.$chapterName.' Modified');
            $objCdn = new Model_CdnPurgeLog();
            if(!empty($cdnPurgeData))
                $objCdn->InsertCdnPurgeLog($cdnPurgeData);
        }
        else {
            //insert
            $dataSave = array(
                'lms_chapter_id' => $data['chapter'],
                'chapter_name' => $chapterName,
                'introduction_text' => strip_tags($data['introText']),
                'course_id' => $data['lectureCourse'],
                'seo_id' => 0,
                'preview_type' => self::COURSE_PREVIEW_TYPE_ELEARNING,
                'is_published' => 0                    
            );
            $objLecture->setFromArray($dataSave)->save();            
            $lectureId = $objLecture->lecture_id;
            $cdnPurgeData = $this->buildCdnPurgeData($lectureId,$data['lectureCourse'],'Lecture Id '. $lectureId.' with '.$chapterName.' Added');
            $objCdn = new Model_CdnPurgeLog();
            if(!empty($cdnPurgeData))
                $objCdn->InsertCdnPurgeLog($cdnPurgeData);
        }                                                

        //Topics                
        $topicModel = new Model_LectureTopic();        
        $previewTopicModel = new Model_CoursePreviewTopic();
        
        $chapterTopics = array();
        $conds = array(
            'lms_chapter_id = ?' => $data['subChapter']
        );
        $opts = array(
            'columns' => array(
                'sco_id',
                'title'
            )
        );            
        foreach($previewTopicModel->fetchAll($conds, $opts, false) as $topicData) {
            $chapterTopics[$topicData['sco_id']] = $topicData['title'];
        }        
        
        $topicsExistsing = array();
        $conds = array(
            'lecture_id = ?' => $lectureId
        );
        $opts = array(
            'columns' => array(
                'topic_id',
                'preview_topic_id'
            )
        );            
        foreach($topicModel->fetchAll($conds, $opts, false) as $topicData) {
            $topicsExistsing[$topicData['preview_topic_id']] = $topicData['topic_id'];
        }
        if(isset($data['transcript']) && $data['transcript']) {
            foreach($data['transcript'] as $previewTopicId => $transcript) {
                $transcript = trim($transcript);
                $topicModel->clean();
                if(isset($topicsExistsing[$previewTopicId])) {
                    //update
                    $dataSave = array(
                        'topic_title' => $chapterTopics[$previewTopicId],
                        'transcript' => strip_tags($transcript)
                    );
                    $topicModel->setId($topicsExistsing[$previewTopicId]);
                    $topicModel->setFromArray($dataSave)->update();
                }
                else {
                    //insert
                    if(!$transcript) {
                        continue;
                    }                    
                    $dataSave = array(
                        'topic_title' => $chapterTopics[$previewTopicId],
                        'transcript' => strip_tags($transcript),
                        'preview_topic_id' => $previewTopicId,
                        'lecture_id' => $lectureId
                    );
                    $topicModel->setFromArray($dataSave)->save();
                }
            }
        }                              
        if($mailData['url']) {
            $seoData = $seoModel->getDataByUrl($mailData['url']);
            if($seoData['linkable_type'] != 'lecture' || $seoData['linkable_id'] != $lectureId) {
                $mailData['type'] = 'repeated';
            }            
        }        
        
        $lectureUrl = new Model_LecturePageUrlLog();
        $lectureUrl->add($mailData, $lectureId);
        unset($chapterTopics);
        unset($topicsExistsing);        
        $db->commit();
        return true;
    }
    
    public function saveManualLecture($data) {        
        $conds = array(
            'course_id = ?' => $data['lectureCourse'],
            'preview_type = ?' => self::COURSE_PREVIEW_TYPE_MANUAL,
            'chapter_name = ?' => $data['chapter']  
        );
        $opts = array(
            'columns' => array(
                'lecture_id'
            )
        );    
        $courseModel = new Model_Courses($data['lectureCourse']);
        $seoModel = new Model_Seo();        
        $mailData = array(
            'section_name' => isset($data['sectionName'])?$data['sectionName']:'',
            'chapter_name' => $data['chapter'],
            'course_name' => $courseModel->displayName,
            'url' => isset($data['chapterUrl'])?$data['chapterUrl']:'',
            'type' => ''
        );                   
        
        $lectureId = 0;
        $lectureData = current($this->fetchAll($conds, $opts, false));
        if($lectureData) {
            $lectureId = $lectureData['lecture_id'];
        }
        
        $db = $this->getDb();
        $objLecture = new self();
        $isFirstLesson = true;
        $db->beginTransaction();
        //lecture entry   
        $data['introText'] = trim($data['introText']);
        if($lectureId) {
            // update                                            
            $dataSave = array(
                'chapter_name' => $data['chapter'],
                'introduction_text' => strip_tags($data['introText'])
            );            
            $objLecture->setId($lectureId);
            $objLecture->setFromArray($dataSave)->update();
            $cdnPurgeData = $this->buildCdnPurgeData($lectureId,$data['lectureCourse'],'Lecture Id '. $lectureId.' with '.$data['chapter'].' Added');
            $objCdn = new Model_CdnPurgeLog();
            if(!empty($cdnPurgeData))
                $objCdn->InsertCdnPurgeLog($cdnPurgeData);
        }
        else {
            //insert
            $dataSave = array(
                'chapter_name' => $data['chapter'],
                'course_id' => $data['lectureCourse'],
                'introduction_text' => strip_tags($data['introText']),
                'seo_id' => 0,
                'preview_type' => self::COURSE_PREVIEW_TYPE_MANUAL,
                'is_published' => 0                    
            );
            $objLecture->setFromArray($dataSave)->save();                                    
            $lectureId = $objLecture->lecture_id;
            $cdnPurgeData = $this->buildCdnPurgeData($lectureId,$data['lectureCourse'],'Lecture Id '. $lectureId.' with '.$data['chapter'].' Added');
            $objCdn = new Model_CdnPurgeLog();
            if(!empty($cdnPurgeData))
                $objCdn->InsertCdnPurgeLog($cdnPurgeData);
        }
                               
        //Topics        
        $topicModel = new Model_LectureTopic();        
        $previewTopicModel = new Model_CoursePreviewVideos();
        $chapterTopics = array();
        $conds = array(
            'chapter_name = ?' => $data['chapter'],
            'course_id = ?' => $data['lectureCourse']
        );
        $opts = array(
            'columns' => array(
                'preview_video_id',
                'name'
            )
        );      
        
        foreach($previewTopicModel->fetchAll($conds, $opts, false) as $topicData) {
            $chapterTopics[$topicData['preview_video_id']] = $topicData['name'];
        }
        
        $topicsExistsing = array();
        $conds = array(
            'lecture_id = ?' => $lectureId
        );
        $opts = array(
            'columns' => array(
                'topic_id',
                'preview_topic_id'
            )
        );            
        foreach($topicModel->fetchAll($conds, $opts, false) as $topicData) {
            $topicsExistsing[$topicData['preview_topic_id']] = $topicData['topic_id'];
        }

        foreach($data['transcript'] as $previewTopicId => $transcript) {
            $transcript = trim($transcript);
            $topicModel->clean();
            if(isset($topicsExistsing[$previewTopicId])) {
                //update
                $dataSave = array(
                    'topic_title' => $chapterTopics[$previewTopicId],
                    'transcript' => strip_tags($transcript)
                );
                $topicModel->setId($topicsExistsing[$previewTopicId]);
                $topicModel->setFromArray($dataSave)->update();
            }
            else {
                //insert
                if(!$transcript) {
                    continue;
                }
                $dataSave = array(
                    'topic_title' => $chapterTopics[$previewTopicId],
                    'transcript' => strip_tags($transcript),
                    'preview_topic_id' => $previewTopicId,
                    'lecture_id' => $lectureId
                );
                $topicModel->setFromArray($dataSave)->save();
            }
        }            
        if($mailData['url'] && $seoModel->getDataByUrl($mailData['url'])) {
            $seoData = $seoModel->getDataByUrl($mailData['url']);
            if($seoData['linkable_type'] != 'lecture' || $seoData['linkable_id'] != $lectureId) {
                $mailData['type'] = 'repeated';
            }                        
        } 
        $lectureUrl = new Model_LecturePageUrlLog();
        $lectureUrl->add($mailData);
        unset($chapterTopics);
        unset($topicsExistsing);
        $db->commit();
        return true;        
    }
    
    public function generateLectureUrl($chapterName, $courseName=false) {        
        $wordsToSkip = implode("|", $this->_seoWordsSkip);
        $chapterName = strip_tags($chapterName);
        $chapterName = strtolower($chapterName);        
        $chapterName = preg_replace("/{$wordsToSkip}/", '', $chapterName);
        $chapterName = preg_replace("/\f/", '', $chapterName);
        $chapterName = preg_replace("/[^a-zA-z0-9\s]/", '', $chapterName);
        $chapterName = trim($chapterName);
        $chapterName = preg_replace("/\s+/", '-', $chapterName);
        
        if($courseName) {
            $courseName = strip_tags($courseName);
            $courseName = strtolower($courseName);
            $courseName = preg_replace("/{$wordsToSkip}/", '', $courseName);
            $courseName = preg_replace("/\f/", '', $courseName);
            $courseName = preg_replace("/[^a-zA-z0-9\s]/", '', $courseName);
            $courseName = trim($courseName);
            $courseName = preg_replace("/\s+/", '-', $courseName);
            if(strpos($chapterName, $courseName) !== false) {
                $courseName = false;
            }
        }        
        if($courseName) {
            $url = sprintf("/%s-%s-tutorial", $courseName, $chapterName);
        }
        else {
            $url = sprintf("/%s-tutorial", $chapterName);
        }        
        return $url;
    }
    
    private function _getMetaTitle($chapterName, $courseName = false, $isFirstLesson) {        
        $wordsToSkip = implode("|", $this->_seoWordsSkip);                
        if($courseName && $isFirstLesson) {
            $courseName = preg_replace("/{$wordsToSkip}/", '', $courseName);            
            $chapterNameCheck = strtolower($chapterName);
            $courseNameCheck = strtolower($courseName);
            if(strpos($chapterNameCheck, $courseNameCheck) !== false) {
                $courseName = false;
            }
        }
        if($courseName && $isFirstLesson) {
            return sprintf("%s Tutorial - %s | Simplilearn", trim($chapterName), trim($courseName));
        }
        else {
            return sprintf("%s Tutorial | Simplilearn", trim($chapterName));
        }
    }
    
    private function _getMetaDescription($chapterName, $courseName, $isFirstLesson) {
        $wordsToSkip = implode("|", $this->_seoWordsSkip);                
        $courseName = preg_replace("/{$wordsToSkip}/", '', $courseName);                                    
        if($isFirstLesson) {
            $chapterNameCheck = strtolower($chapterName);
            $courseNameCheck = strtolower($courseName);
            if(strpos($chapterNameCheck, $courseNameCheck) !== false) {
                return sprintf("%s provides you with in-depth tutorial online as a part of %s course.", trim($chapterName), trim($courseName));
            }
            else {
                return sprintf("%s of %s provides you with in-depth tutorial online as a part of %s course.", trim($chapterName), trim($courseName), trim($courseName));
            }            
        }
        else {            
            return sprintf("%s lesson provides you with in-depth tutorial online as a part of %s course.", trim($chapterName), trim($courseName));
        }
    }
    
    private function _getH1Tag($chapterName, $courseName, $isFirstLesson) {
        $wordsToSkip = implode("|", $this->_seoWordsSkip);                
        $courseName = preg_replace("/{$wordsToSkip}/", '', $courseName);                                    
        if($isFirstLesson) {
            $chapterNameCheck = strtolower($chapterName);
            $courseNameCheck = strtolower($courseName);
            if(strpos($chapterNameCheck, $courseNameCheck) !== false) {
                return trim($chapterName);
            }
            else {
                return sprintf("%s - %s", trim($chapterName), trim($courseName));
            }            
        }
        else {            
            return trim($chapterName);
        }
    }
    
    public function _afterFetchAll($data){   
        $courses = array();
        foreach($data as $row) {
            if(!in_array($row['course_id'], $courses)) {
                $courses[] = $row['course_id'];
            }            
        }
        if($courses) {
            $modelCourse = new Model_Courses();
            $courses = $modelCourse->fetchForSelect(array('course_id IN (?)' => $courses));
        }
        foreach($data as &$row) {
            if(isset($courses[$row['course_id']])) {
                $row['courseName'] = $courses[$row['course_id']];
            }            
        }
        return $data;
    }
    
    public function getCoursesToDisplay() {
        $courseIds = array();
        $previewChapterModel = new Model_CoursePreviewChapter();
        foreach($previewChapterModel->fetchAll(array('course_id != ?' => 0), array('columns' => array('course_id' => 'DISTINCT(course_id)'))) as $data) {
            $courseIds[] = $data['course_id'];
        }        
        $previewVideoManual = new Model_CoursePreviewVideos();
        foreach($previewVideoManual->fetchAll(array('course_id != ?' => 0), array('columns' => array('course_id' => 'DISTINCT(course_id)'))) as $data) {
            $courseIds[] = $data['course_id'];
        }                
        $courseModel = new Model_Courses();
        $courses = array();
        if($courseIds) {
            foreach($courseModel->fetchAll(array('is_dummy=?'=>0, 'course_id IN (?)' => $courseIds), array('columns' => array('course_id', 'displayName'), 'order' => 'displayName'), false) as $data) {
                $courses[$data['course_id']] = $data['displayName'];
            }        
        }        
        return $courses;
    }
    
    public function getLectureSeo($lectureId, $isFirstChapter) {
        $sql = $this->getDb()->select()
                ->from(array('l' => 'lecture'), array('chapter_name'))
                ->joinLeft(array('c' => 'courses'), "c.course_id = l.course_id AND c.status = 1", array('course_name' => 'name'))                
                ->where('l.status=?', 1)
                ->where('l.lecture_id =?', $lectureId)
                ;
        $lecture = current($this->getDb()->fetchAll($sql));
        $courseName = false;
        if($isFirstChapter) {
            $courseName = $lecture['course_name'];
        }
        $lectureData = array(
            'url' => $this->generateLectureUrl($lecture['chapter_name'], $courseName),
            'title' => $this->_getMetaTitle($lecture['chapter_name'], $lecture['course_name'], $isFirstChapter), 
            'description' => $this->_getMetaDescription($lecture['chapter_name'], $lecture['course_name'], $isFirstChapter), 
            'h1Tag' => $this->_getH1Tag($lecture['chapter_name'], $lecture['course_name'], $isFirstChapter), 
            'seo_id' => 0
        );
        $sql = $this->getDb()->select()
                ->from(array('l' => 'lecture'), array('lecture_id', 'is_published'))
                ->joinLeft(array('s' => 'seo'), "s.linkable_id = l.lecture_id AND s.linkable_type='lecture' AND s.controller='". self::SEO_DEFAULT_CONTROLLER."' AND s.action='".self::SEO_DEFAULT_ACTION."' AND s.status = 1 AND s.seo_id !=0 AND s.seo_id = l.seo_id", array('url', 'title', 'description', 'h1Tag', 'seo_id'))                
                ->where('l.status=?', 1)
                ->where('l.lecture_id =?', $lectureId)
                ;
        $lectureDataExists = current($this->getDb()->fetchAll($sql));
        foreach($lectureDataExists as $field => $value) {
            if(trim($value) === '') {
                continue;
            }
            $lectureData[$field] = $value;
        }
        return $lectureData;
    }
    
    public function saveLectureSeo($lectureData) {
        $seoModel = new Model_Seo();                
        if(!$lectureData['seo_id']) {
            if($seoModel->getDataByUrl($lectureData['url'])) {
                return false;
            }        
            $seoModel->clean();
            $dataSave = array(
                'controller' => self::SEO_DEFAULT_CONTROLLER,
                'action' => self::SEO_DEFAULT_ACTION,
                'params' => json_encode(array(self::SEO_DEFAULT_PARAM_KEY=>$lectureData['lecture_id'])),
                'linkable_id' => $lectureData['lecture_id'],
                'linkable_type' => 'lecture',
                'url' => $lectureData['url'],
                'title' => $lectureData['title'],
                'description' => $lectureData['description'],
                'h1Tag' => $lectureData['h1Tag']
            );
            $seoModel->setFromArray($dataSave)->save();
            $dataSave = array(
                'seo_id' => $seoModel->seo_id                
            );
            if(isset($lectureData['is_published']) && $lectureData['is_published']) {
                $dataSave['is_published'] = 1;
            }
            $modelLecture = new Model_Lecture();
            $modelLecture->clean();
            $modelLecture->setId($lectureData['lecture_id']);
            $modelLecture->setFromArray($dataSave)->update();                    
        }
        else {
            $seoDataExists = $seoModel->getDataByUrl($lectureData['url']);
            if($seoDataExists && $lectureData['seo_id'] != $seoDataExists['seo_id']) {
                return false;
            }
            $dataSave = array(
                'url' => $lectureData['url'],
                'title' => $lectureData['title'],
                'description' => $lectureData['description'],
                'h1Tag' => $lectureData['h1Tag']
            );
            $seoModel->clean();
            $seoModel->setId($lectureData['seo_id']);
            $seoModel->setFromArray($dataSave)->update();                    
            
            if(isset($lectureData['is_published']) && $lectureData['is_published']) {
                $dataSave = array(
                    'is_published' => 1
                );
                $modelLecture = new Model_Lecture();
                $modelLecture->clean();
                $modelLecture->setId($lectureData['lecture_id']);
                $modelLecture->setFromArray($dataSave)->update();                    
            }            
        }   
        return true;
    }

    public function buildCdnPurgeData($lectureId,$courseId,$action){
        $returnArr = array();
        // $objSeo = new Model_Seo();
        // $seoData = $objSeo->fetchAll(array('linkable_id = ?'=>$lectureId,'linkable_type =?'=>'lecture'),array('columns'=>array('url','linkable_id')));
        // if(!empty($seoData)){
        //     array_push($returnArr,array('linkable_id'=>$seoData['linkable_id'],'linkable_type'=>'lecture','action'=>$action,'url'=>$seoData['url'],'created_at'=>time(),'updated_at'=>time()) );
        // }
        // $seoData = $objSeo->fetchAll(array('linkable_id = ?'=>$courseId,'linkable_type =?'=>'course'),array('columns'=>array('url','linkable_id')));
        // if(!empty($seoData)){
        //     array_push($returnArr,array('linkable_id'=>$seoData['linkable_id'],'linkable_type'=>'course','action'=>$action,'url'=>$seoData['url'],'created_at'=>time(),'updated_at'=>time()) );
        // }
        return $returnArr;
    } // end of function
} // End of Class