<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Model_Referer extends BaseApp_Dao_Referer {

    protected $_useCache = false;

}
