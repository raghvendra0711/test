<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Model_B2BFlatPricing extends BaseApp_Dao_B2BFlatPricing {

    public function saveB2BPricingInfo($companyId, $linkableType, $countryId, $clusterId, $trainingId, $dataArr) {
        try {
            
            if (count($dataArr) == count($dataArr, COUNT_RECURSIVE)) 
            {
                
                $fields = array(
                    'company_id =?' => $companyId,
                    'linkable_type =?' => $linkableType,
                    'country_id =?' => $countryId,
                    'cluster_id =?' => $clusterId,
                    'training_id =?' => $trainingId,
                    'learners_range_id =?'  => $dataArr['learners_range_id'],
                    'status =?' => 1);                    
                $checkExisting = $this->fetchAll($fields);
            
                if (!empty($checkExisting)) {
                    $dataArr = $this->updateExistingRecords($checkExisting,$dataArr);
                }
            }else{
               
                foreach($dataArr as $val){
                    $fields = array(
                        'company_id =?' => $companyId,
                        'linkable_type =?' => $linkableType,
                        'country_id =?' => $countryId,
                        'cluster_id =?' => $clusterId,
                        'training_id =?' => $trainingId,
                        'learners_range_id =?'  => $val['learners_range_id'],
                        'status =?' => 1);
                    
                    $checkExisting = $this->fetchAll($fields);                    
                    
                    if (!empty($checkExisting)) {
                        $dataArr = $this->updateExistingRecords($checkExisting,$dataArr);
                        $dataArr = array_values($dataArr);                        
                    }
                    
                }
                
            }
                          
            
            if (!empty($dataArr)) {
                // foreach ($dataArr as $key => $value) {
                    $this->clean();
                    $dataArr['company_id'] = $companyId;
                    $this->setFromArray($dataArr)->save();
                // }
            }
            return true;
        } catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }

    public function saveB2BPricingData($companyId, $linkableType, $dataArr, $countryId = 0, $clusterId = 0) {
        try {
            $learnersRange = !empty($dataArr['learners_range_id']) ? $dataArr['learners_range_id'] : "";
            $fields = array('company_id =?' => $companyId,
                'linkable_type =?' => $linkableType,
                'status =?' => 1
            );
            if (!empty($countryId)) {
                $fields['country_id = ? '] = $countryId;
            }
            if (!empty($clusterId)) {
                $fields['cluster_id = ? '] = $clusterId;
            }
            if(!empty($learnersRange)){
                $fields['learners_range_id = ?'] = $learnersRange;
            }
            $checkExisting = $this->fetchAll($fields);

            $dataArr['company_id'] = $companyId;             

            if (!empty($checkExisting)) {
                $dataArr = $this->updateExistingRecords($checkExisting,$dataArr);
            }
            if (!empty($dataArr)) {
                    $this->clean();
                if (empty($dataArr['linkable_type']))
                    $dataArr['linkable_type'] = $linkableType;
                $dataArr['company_id'] = $companyId;
                $this->setFromArray($dataArr)->save();
            }
            return true;
        } catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }
    
    /**
     * updateExistingRecords 
     * @params checkExisting - existing records for that purticular company
     * @params dataArr - Entries from the form and its a pass by reference variable
     * function will return only new entries found on dataArr, it will compare database entries and form entries.
     */
    public function updateExistingRecords($checkExisting,&$dataArr){
        if (!empty($checkExisting)) {
            $inc = 0;                
            foreach ($checkExisting as $key => $value) {
                //create an array to compare only existing data
                $compareExisting = array(
                                         'linkable_type'    => !empty($value['linkable_type']) ? $value['linkable_type'] : "",
                                         'linkable_id'      => !empty($value['linkable_id'])  ? $value['linkable_id'] : 0,
                                         'company_id'       => !empty($value['company_id']) ? $value['company_id'] : 0,
                                         'learners_range_id'=> !empty($value['learners_range_id']) ? $value['learners_range_id'] : 0,
                                    );

                //compare with dataArr values agianst 4 attr
                foreach($dataArr as $dKey => $dVal){
                    $dataArrCompare = array(
                        'linkable_type'    => !empty($dVal['linkable_type']) ? $dVal['linkable_type'] : "",
                        'linkable_id'      => !empty($dVal['linkable_id']) ? $dVal['linkable_id'] : 0,
                        'company_id'       => !empty($dVal['company_id']) ? $dVal['company_id'] : 0,
                        'learners_range_id'=> !empty($dVal['learners_range_id']) ? $dVal['learners_range_id'] : 0,
                    );
                   if($dataArrCompare == $compareExisting){
                       //same data update and unset from dataArr
                        if(isset($dataArr[$inc])){
                            $this->clean();
                            $this->setId($value['id']);
                            $this->setFromArray($dataArr[$inc])->update();
                            unset($dataArr[$inc]);
                            unset($checkExisting[$inc]);
                        }
                   }                 
                }                     
                $inc++;                  
            }
            if(!empty($checkExisting)){
                foreach($checkExisting as $cKey=>$cVal){
                    $this->clean();
                    $this->setId($cVal['id']);
                    $this->setFromArray(array('status'=>0))->update();
                }                        
            }
        }
        return $dataArr;
    }

    public function getPricingData($companyId,$limit = array()) {
        $result = $finalPricingArr = array();
        try {
            if (!empty($companyId)) {
                $allowedProductType = $this->_getProductTypeByCompanyId($companyId);
                $linkableTypes = array('course', 'bundle');
                $countryModel = new Model_Country();
                $countryList = $countryModel->fetchForSelect();
                $obj = new Model_Clusters();
                $clusterList = $obj->fetchForSelect();
                $sql = $this->getDb()->select()
                        ->from(array('pricing' => 'b2b_flat_pricing'), array(
                            'ids' => new Zend_Db_Expr('GROUP_CONCAT(pricing.id)'),
                            // 'learnerrange' => new Zend_Db_Expr("CONCAT(pricing.learners_range_min, '-', pricing.learners_range_max)"),
                            'type' => 'pricing.linkable_type',
                            'price' => new Zend_Db_Expr("min(pricing.price)"),
                            'discount' => new Zend_Db_Expr("max(pricing.flat_discount)"),
                            'training_id' => 'pricing.training_id',
                            'country_id' => 'pricing.country_id',
                            'cluster_id' => 'pricing.cluster_id')
                        )
                        ->where('pricing.company_id = ?', $companyId)
                        ->where('pricing.linkable_type IN (?) ', $linkableTypes)
                        ->where('pricing.status = ?', 1)
                        ->group(array(
                    'pricing.training_id',
                    'pricing.linkable_type',
                    'pricing.country_id',
                    'pricing.cluster_id',
                        )
                );
                if (!empty($limit)) {
                    $sql = $sql->limit($limit[0],$limit[1]);
                }
                $result = $this->getDb()->fetchAll($sql);

                if (!empty($result)) {
                    foreach ($result as $key => $row) {

                        if ($row['type'] == 'course') {
                            if ($row['training_id'] == BaseApp_Dao_TrainingTypes::TYPE_ELEARNING) {
                                $result[$key]['training_type'] = 'Online Self Learning';
                                $result[$key]['product_type'] = 'OSL';
                            }
                            if ($row['training_id'] == BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS) {
                                $result[$key]['training_type'] = 'LVC';
                                $result[$key]['product_type'] = 'LVC';
                            }
                        }

                        if ($row['type'] == 'bundle') {
                            $result[$key]['training_type'] = 'Online Self Learning';
                            $result[$key]['product_type'] = 'Bundle';
                        }

                        if (!empty($row['cluster_id'])) {
                            $result[$key]['pricing_level'] = 'Cluster';
                            $result[$key]['cluster_name'] = $clusterList[$row['cluster_id']];
                        }
                        if (!empty($row['country_id'])) {
                            $result[$key]['pricing_level'] = 'Country';
                            $result[$key]['country_name'] = $countryList[$row['country_id']];
                        }
                    }

                    foreach ($result as $row) {

                        if ($row['type'] == BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES) {
                            if (!in_array($row['type'], $allowedProductType))
                                continue;
                        } else {
                            $trainingTypeId = $row['training_id'];
                            if ($trainingTypeId == BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS) {
                                if (!in_array(BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS_NAME, $allowedProductType))
                                    continue;
                            }
                            if ($trainingTypeId == BaseApp_Dao_TrainingTypes::TYPE_ELEARNING) {
                                if (!in_array(BaseApp_Dao_TrainingTypes::TYPE_ELEARNING_NAME, $allowedProductType))
                                    continue;
                            }
                        }

                        $priceIds = $row['ids'];
                        $countryId = $row['country_id'];
                        $clusterId = $row['cluster_id'];
                        $productType = $row['product_type'];
                        $pricingType = 0;
                        if ($countryId) {
                            $pricingLevel = $countryId;
                            $pricingType = 'country';
                        } else {
                            $pricingLevel = $clusterId;
                            $pricingType = 'cluster';
                        }
                        $productNameList=($row['type']==BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES) ? "All Masters" : "All Course";
                        $finalPricingArr[] = array(
                            'ids' => $priceIds,
                            'companyId' => $companyId,
                            'type' => $row['type'],
                            'cluster_id' => $row['cluster_id'],
                            'country_id' => $row['country_id'],
                            'training_type' => $row['training_type'],
                            'productNameList' => $productNameList,
                            'pricing_level' => !empty($row['pricing_level']) ? $row['pricing_level'] : '',
                            'cluster_name' => !empty($row['cluster_name']) ? $row['cluster_name'] : '-',
                            'country_name' => !empty($row['country_name']) ? $row['country_name'] : '-',
                            'price' => $row['price'],
                            'discount' => $row['discount']
                        );
                    }
                }
            }
        } catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
        }
       // prd($finalPricingArr);
        return $finalPricingArr;
    }

    public function updateSyncStatus($currentId) {
        $this->setId($currentId);
        $this->setFromArray(array('status_sync' => 0))->update();
    }
    public function updateSyncStatusOnSync($currentId) {
        $this->setId($currentId);
        $this->setFromArray(array('status_sync' => 1))->update();
    }

    public function disableCompanyPricing($companyId) {
        if (!empty($companyId)) {
            return $this->getDb()->update('b2b_flat_pricing', array('status' => 0), "company_id = " . $companyId);
        }
        return false;
    }

    public function getCoursePricingDataById($companyId, $flatPricingIds) {
        $result = $finalPricingArr = array();
        try {
            if (!empty($companyId)) {
                $linkableTypes = array(BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE, BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES);
                $countryModel = new Model_Country();
                $countryList = $countryModel->fetchForSelect();
                $obj = new Model_Clusters();
                $clusterList = $obj->fetchForSelect();
                $sql = $this->getDb()->select()
                        ->from(array('pricing' => 'b2b_flat_pricing'), array(
                            'learnerrange' => new Zend_Db_Expr("CONCAT(b2b_learners_range.min, '-', b2b_learners_range.max)"),
                            'type' => 'pricing.linkable_type',
                            'price' => 'pricing.flat_price',
                            'discount' => 'pricing.flat_discount',
                            'training_id' => 'pricing.training_id',
                            'country_id' => 'pricing.country_id',
                            'access_day_id' => 'pricing.access_day_id',
                            'cluster_id' => 'pricing.cluster_id')
                        )
                        ->join('b2b_learners_range', 'b2b_learners_range.id=pricing.learners_range_id')
                        ->where('pricing.company_id = ?', $companyId)
                        ->where('pricing.id IN (?) ', explode(',', $flatPricingIds))
                        ->where('pricing.status = ?', 1)
                        ->where('b2b_learners_range.company_id = ?', $companyId)
                        ->where('b2b_learners_range.status = ?', 1);

                $result = $this->getDb()->fetchAll($sql);
                if (!empty($result)) {
                    foreach ($result as $key => $row) {
                        if ($row['type'] == 'course') {
                            if ($row['training_id'] == BaseApp_Dao_TrainingTypes::TYPE_ELEARNING) {
                                $result[$key]['training_type'] = 'Online Self Learning';
                                $result[$key]['product_type'] = 'osl';
                            }
                            if ($row['training_id'] == BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS) {
                                $result[$key]['training_type'] = 'LVC';
                                $result[$key]['product_type'] = 'lvc';
                            }
                        }

                        if ($row['type'] == 'bundle') {
                            $result[$key]['training_type'] = 'Online Self Learning';
                            $result[$key]['product_type'] = 'mp';
                        }

                        if (!empty($row['cluster_id'])) {
                            $result[$key]['pricing_level'] = 1;
                            $result[$key]['cluster_name'] = $clusterList[$row['cluster_id']];
                        }
                        if (!empty($row['country_id'])) {
                            $result[$key]['pricing_level'] = 2;
                            $result[$key]['country_name'] = $countryList[$row['country_id']];
                        }
                    }
                   
                    foreach ($result as $row) {
                        $countryId = $row['country_id'];
                        $clusterId = $row['cluster_id'];
                        $productType = $row['product_type'];
                        $pricingType = 0;
                        if ($countryId) {
                            $pricingLevel = $countryId;
                            $pricingType = 'country';
                        } else {
                            $pricingLevel = $clusterId;
                            $pricingType = 'cluster';
                        }
                        $productNameList=array('All Course');
                        if($row['type']=="bundle"){
                            $productNameList=array('All Masters');
                        }
                        $finalPricingArr[] = array(
                            'product_type' => $row['product_type'],
                            'learnerrange' => $row['learnerrange'],
                            'companyId' => $companyId,
                            'type' => $row['type'],
                            'cluster_id' => $row['cluster_id'],
                            'country_id' => $row['country_id'],
                            'training_type' => $row['training_type'],
                            'productNameList' => $productNameList,
                            'pricing_level' => $row['pricing_level'],
                            'cluster_name' => !empty($row['cluster_name']) ? $row['cluster_name'] : '-',
                            'country_name' => !empty($row['country_name']) ? $row['country_name'] : '-',
                            'flat_price' => $row['price'],
                            'flat_discount' => $row['discount'],
                            'access_day_id' => $row['access_day_id'],
                            'product_category' => 'allcategories'
                        );
                    }
                }
                //Format Data
                $formattedData = array();
                foreach ($finalPricingArr as $row) {
                    $learnerRange = $row['learnerrange'];
                    $row['isflat'] = true;
                    $formattedData[$learnerRange][] = $row;
                }
            }
        } catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
        }
        return $formattedData;
    }

    public function deleteB2BPricingData($companyId, $originalPPIDS) {
        try {
            $ppids = explode(',', $originalPPIDS);
            $fields = array(
                'id IN (?)' => $ppids,
                'company_id =?' => $companyId,
            );
            $checkExisting = $this->fetchAll($fields);
            if (!empty($checkExisting)) {
                foreach ($checkExisting as $key => $value) {
                    $this->clean();
                    $this->setId($value['id']);
                    $this->setFromArray(array('status' => 0))->update();
                }
            }
            return true;
        } catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }

    public function getCategoryPricingData($companyId) {
        $result = $finalPricingArr = $formattedPricingArr = array();
        try {
            if (!empty($companyId)) {
                $linkableTypes = array('category');
                $countryModel = new Model_Country();
                $countryList = $countryModel->fetchForSelect();
                $obj = new Model_Clusters();
                $clusterList = $obj->fetchForSelect();
                $sql = $this->getDb()->select()
                        ->from(array('pricing' => 'b2b_flat_pricing'), array(
                            'ids' => new Zend_Db_Expr('GROUP_CONCAT(pricing.id)'),
                            // 'learnerrange' => new Zend_Db_Expr("CONCAT(pricing.learners_range_min, '-', pricing.learners_range_max)"),
                            'type' => 'pricing.linkable_type',
                            'price' => new Zend_Db_Expr('min(pricing.price)'),
                            'discount' => new Zend_Db_Expr('max(pricing.flat_discount)'),
                            'training_id' => 'pricing.training_id',
                            'country_id' => 'pricing.country_id',
                            'cluster_id' => 'pricing.cluster_id')
                        )
                        ->where('pricing.company_id = ?', $companyId)
                        ->where('pricing.linkable_type IN (?) ', $linkableTypes)
                        ->where('pricing.status = ?', 1)
                        ->group(array(
                    'pricing.training_id',
                    'pricing.linkable_type',
                    'pricing.country_id',
                    'pricing.cluster_id',
                        //'pricing.flat_price',
                        //'pricing.flat_discount'
                        )
                );

                $result = $this->getDb()->fetchAll($sql);
                if (!empty($result)) {
                    foreach ($result as $key => $row) {
                        if ($row['training_id'] == BaseApp_Dao_TrainingTypes::TYPE_ELEARNING) {
                            $result[$key]['training_type'] = 'Online Self Learning';
                        }
                        if ($row['training_id'] == BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS) {
                            $result[$key]['training_type'] = 'LVC';
                        }

                        if (!empty($row['cluster_id'])) {
                            $result[$key]['pricing_level'] = 'Cluster';
                            $result[$key]['cluster_name'] = $clusterList[$row['cluster_id']];
                        }
                        if (!empty($row['country_id'])) {
                            $result[$key]['pricing_level'] = 'Country';
                            $result[$key]['country_name'] = $countryList[$row['country_id']];
                        }
                        $result[$key]['categoryName'] = 'All Category';
                        $result[$key]['pricingType'] = 'flat';
                        $result[$key]['companyId'] = $companyId;
                        $finalPricingArr[] = $result[$key];
                    }
                }
            }
        } catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
        }

        return $finalPricingArr;
    }

    public function deleteDataByTrainingAndType($companyId, $linkableType, $trainingId) {
        try {
            $fields = array(
                'linkable_type = ? ' => $linkableType,
                'training_id = ?' => $trainingId,
                'company_id =?' => $companyId,
            );
            $checkExisting = $this->fetchAll($fields);
            if (!empty($checkExisting)) {
                foreach ($checkExisting as $key => $value) {
                    $this->clean();
                    $this->setId($value['id']);
                    $this->setFromArray(array('status' => 0))->update();
                }
            }
            return true;
        } catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }

    /**
     * Remove this method 
     */
//    public function updateRangeDataByRangeId($updateParams) {
//        try {
//            if (!empty($updateParams)) {
//                $learnerRangeId = $updateParams['learnersRangeId'];
//                $companyId = $updateParams['companyId'];
//                $learnerRangeMin = $updateParams['min'];
//                $learnerRangeMax = $updateParams['max'];
//                $fields = array(
//                    'learners_range_id = ? ' => $learnerRangeId,
//                    'company_id =?' => $companyId,
//                );
//                $checkExisting = $this->fetchAll($fields);
//                if (!empty($checkExisting)) {
//                    foreach ($checkExisting as $key => $value) {
//                        $params = array('learners_range_min' => $learnerRangeMin, 'learners_range_max' => $learnerRangeMax);
//                        $this->clean();
//                        $this->setId($value['id']);
//                        $this->setFromArray($params)->update();
//                    }
//                }
//                return true;
//            }
//        } catch (Exception $e) {
//            if (APPLICATION_ENV == 'development')
//                throw $e;
//            return false;
//        }
//        return false;
//    }

    /**
     * Check If Any Pricing Exist For The Range Id.
     * If Exist Then Update The Pricing Status To Zero(0)
     * Then Update The Learners Range Id Status To Zero(0)
     */
    public function disablePricingAndRange($companyId, $learnerRangeId) {
        if (!empty($companyId) && !empty($learnerRangeId)) {
            $condition = array('company_id = ?' => $companyId, 'learners_range_id = ? ' => $learnerRangeId, 'status = ?' => 1);
            $checkExisting = $this->fetchAll($condition);
            if (!empty($checkExisting)) {
                foreach ($checkExisting as $key => $value) {
                    if ($value['learners_range_id'] == $learnerRangeId) {
                        $this->clean();
                        $this->setId($value['id']);
                        $this->setFromArray(array('status' => 0))->update();
                    }
                }
            }
            $learnerRangeObj = new Model_LearnersRange();
            if ($learnerRangeObj->updateLearnerRangeStatus($learnerRangeId)) {
                return true;
            }
        }
        return false;
    }

    private function _getProductTypeByCompanyId($companyId) {
        $productTypes = array();
        $obj = new Model_ProductSectionData();
        $allowedTypes = array();
        $result = $obj->fetchAll(array(
            'company =?' => $companyId,
            'sectionType IN (?)' => array(BaseApp_Dao_TrainingTypes::B2B_TRAINING_TYPE, BaseApp_Dao_TrainingTypes::B2B_PRODUCT_TYPE)
                ), array('columns' => array('name' => 'description', 'id' => 'name')));
        if (!empty($result)) {
            foreach ($result as $row) {
                $name = $row['name'];
                if ($name == BaseApp_Dao_TrainingTypes::TYPE_ELEARNING_NAME) {
                    $productTypes[BaseApp_Dao_TrainingTypes::TYPE_ELEARNING_NAME] = BaseApp_Dao_TrainingTypes::TYPE_ELEARNING;
                    $allowedTypes[] = BaseApp_Dao_TrainingTypes::TYPE_ELEARNING_NAME;
                }
                if ($name == BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS_NAME) {
                    $productTypes[BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS_NAME] = BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS;
                    $allowedTypes[] = BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS_NAME;
                }
                if ($name == BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES) {
                    $productTypes[BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES] = BaseApp_Dao_ProductTypes::TYPE_ID_BUNDLE;
                    $allowedTypes[] = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES;
                }
            }
        }
        return $allowedTypes;
    }

}

// End of Class
