<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_SeoMetatags extends BaseApp_Dao_SeoMetatags{
    
    
    public function createTag($data) {
        $db = $this->getDb();
        $objTag = new self();
        $db->beginTransaction();
        try{
            $objTag->setFromArray($data)->save();
            $db->commit();
            return $objTag->tag_id;
        }
        catch (Exception $e){
            $db->rollBack();
            throw $e;
            return false;
        }
    }
  
    public function updateTag($data) {
        $db = $this->getDb();
        $objTag = new self();
        $db->beginTransaction();
	try{
            
            $objTag->setId($data['tag_id']);
            $objTag->setFromArray($data)->update();  
            $db->commit();
            return true;
        }
        catch (Exception $e){
            $db->rollBack();
            return false;
        }
    }
    
    public function getByName($name) {
        return  $this->fetchAll(array('name = ?' => $name), array(), false);
    }
    
    public function getNamesToDisplay() {
        $return = array();
        foreach($this->fetchAll(array(), array(), false) as $data) {
            $return[$data['name']] = $data['name'];
        }
        return $return;
    }
    
} // End of Class