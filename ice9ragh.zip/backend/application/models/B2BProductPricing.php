<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Model_B2BProductPricing extends BaseApp_Dao_B2BProductPricing {

    const OPTIONS_INCLUDE = true;
    const OPTIONS_EXCLUDE = false;

    public function saveB2BCategoryPricingData($params, $linkableType, $dataArr) {
        try {
            $countryId = $params['countryId'];
            $countryId = $params['countryId'];
            $clusterId = $params['clusterId'];
            $linkableId = $params['linkableId'];
            $companyId = $params['companyId'];   
            $learnerRange = $dataArr['learners_range_id'];
            $dataArr['company_id'] = $params['companyId'];       
           $categoryData = array($dataArr);
            $fields = array('company_id =?' => $companyId,
                'linkable_type =?' => $linkableType,
                'status =?' => 1,
                'linkable_id =?' => $linkableId
            );
            if (!empty($countryId)) {
                $fields['country_id = ?'] = $countryId;
            }
            if (!empty($clusterId)) {
                $fields['cluster_id = ?'] = $clusterId;
            }
            if (!empty($learnerRange)) {
                $fields['learners_range_id = ?'] = $learnerRange;
            }
            $checkExisting = $this->fetchAll($fields);
            if (!empty($checkExisting)) {
                $dataArr = $this->updateExistingRecordsForCategory($checkExisting,$categoryData);
            }
            if (!empty($dataArr)) {
                    $dataArr['company_id'] = $companyId;
                    $this->setFromArray($dataArr)->save();
            }
            return true;
        } catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }

    public function saveB2BPricingData($companyId, $dataArr) {
        try {
            $linkable_id = $dataArr['linkable_id'];
            $training_id = $dataArr['training_id'];
            $learners_range_id = $dataArr['learners_range_id'];
            $linkableType = $dataArr['linkable_type'];
            $country_id = $dataArr['country_id'];
            $cluster_id = $dataArr['cluster_id'];
            $fields = array(
                'company_id =?' => $companyId,
                'linkable_type =?' => $linkableType,
                'linkable_id = ?' => $linkable_id,
                'training_id = ?' => $training_id,
                'learners_range_id = ?' => $learners_range_id,
                'country_id = ? ' => $country_id,
                'cluster_id = ? ' => $cluster_id,
                'status =?' => 1,
            );
            $checkExisting = $this->fetchAll($fields);
            if (!empty($checkExisting)) {               
                $dataArr = $this->updateExistingRecords($checkExisting,$dataArr);
            }
            if (!empty($dataArr)) {
                $this->clean();
                $dataArr['company_id'] = $companyId;
                $this->setFromArray($dataArr)->save();
            }
            return true;
        } catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }
    //copy updateB2BPricingData
    public function updateB2BPricingDataCopy($companyId, $dataArr, $originalPPIDS) {
        try {

            $linkable_id = $dataArr[0]['linkable_id'];
            $training_id = $dataArr[0]['training_id'];
            $learners_range_id = $dataArr[0]['learners_range_id'];
            $linkableType = $dataArr[0]['linkable_type'];
            $country_id = $dataArr[0]['country_id'];
            $cluster_id = $dataArr[0]['cluster_id'];
            $ppids = explode(',', $originalPPIDS);
            $fields = array(
                'id IN (?)' => $ppids,
                'company_id =?' => $companyId,
                'linkable_type =?' => $linkableType,
                'training_id = ?' => $training_id,
                'country_id = ? ' => $country_id,
                'cluster_id = ? ' => $cluster_id,
                'status =?' => 1,
            );
            $checkExisting = $this->fetchAll($fields);
            if (!empty($checkExisting)) {
                foreach ($checkExisting as $key => $value) {
                    $this->clean();
                    $this->setId($value['id']);
                    $this->setFromArray(array('status' => 0))->update();
                }
            }
            if (!empty($dataArr)) {
                foreach ($dataArr as $key => $value) {
                    $this->clean();
                    $value['company_id'] = $companyId;
                    $this->setFromArray($value)->save();
                }
            }
            return true;
        } catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }
    
    /**
     * updateExistingRecords 
     * @params checkExisting - existing records for that purticular company
     * @params dataArr - Entries from the form and its a pass by reference variable
     * function will return only new entries found on dataArr, it will compare database entries and form entries.
     */
    public function updateExistingRecords($checkExisting,$dataArr){
        if (!empty($checkExisting)) {
            $inc = 0;
            $update = 0;                
            foreach ($checkExisting as $key => $value) {
                //create an array to compare only existing data
                $compareExisting = array(
                                         'linkable_type'    => !empty($value['linkable_type']) ? $value['linkable_type'] : "",
                                         'linkable_id'      => !empty($value['linkable_id']) ? $value['linkable_id'] : "",
                                         'company_id'       => !empty($value['company_id']) ? $value['company_id'] : "",
                                         'learners_range_id'=> !empty($value['learners_range_id']) ? $value['learners_range_id'] : "",                                         
                                    );
                //compare with dataArr values agianst 4 attr
                foreach($dataArr as $dKey => $dVal){
                    $dataArrCompare = array(
                        'linkable_type'    => !empty($dVal['linkable_type']) ? $dVal['linkable_type'] : "",
                        'linkable_id'      => !empty($dVal['linkable_id']) ? $dVal['linkable_id'] : "",
                        'company_id'       => !empty($dVal['company_id']) ? $dVal['company_id'] : "",
                        'learners_range_id'=> !empty($dVal['learners_range_id']) ? $dVal['learners_range_id'] : "",
                    );
                    if($dataArrCompare == $compareExisting){
                        //same data update and unset from dataArr
                       $update = 1;
                        if(isset($dataArr[$dKey])){
                            $this->clean();
                            $this->setId($value['id']);
                            $this->setFromArray($dataArr[$dKey])->update();
                            unset($dataArr[$dKey]);
                            unset($checkExisting[$dKey]);
                        }
                   } 
                   $dKey++;                
                }                                     
            }
            if($update == 0 && !empty($checkExisting)){
                foreach($checkExisting as $cKey=>$cVal){
                    $this->clean();
                    $this->setId($cVal['id']);
                    $this->setFromArray(array('status'=>0))->update();
                }                        
            }
        }
        return $dataArr;
    }

    public function updateExistingRecordsForCategory($checkExisting,$dataArr){
        if (!empty($checkExisting)) {
            $inc = 0;
            $update = 0;                
            foreach ($checkExisting as $key => $value) {
                //create an array to compare only existing data
                $compareExisting = array(
                                         'linkable_type'    => !empty($value['linkable_type']) ? $value['linkable_type'] : "",
                                         'linkable_id'      => !empty($value['linkable_id']) ? $value['linkable_id'] : "",
                                         'company_id'       => !empty($value['company_id']) ? $value['company_id'] : "",
                                         'learners_range_id'=> !empty($value['learners_range_id']) ? $value['learners_range_id'] : "",                                         
                                    );
                //compare with dataArr values agianst 4 attr
                foreach($dataArr as $dKey => $dVal){
                    $dataArrCompare = array(
                        'linkable_type'    => !empty($dVal['linkable_type']) ? $dVal['linkable_type'] : "",
                        'linkable_id'      => !empty($dVal['linkable_id']) ? $dVal['linkable_id'] : "",
                        'company_id'       => !empty($dVal['company_id']) ? $dVal['company_id'] : "",
                        'learners_range_id'=> !empty($dVal['learners_range_id']) ? $dVal['learners_range_id'] : "",
                    );
                
                    if($dataArrCompare == $compareExisting){
                        //same data update and unset from dataArr
                       $update = 1;
                        if(isset($dataArr[$key])){
                            $this->clean();
                            $this->setId($value['id']);
                            $this->setFromArray($dataArr[$key])->update();
                            unset($dataArr[$key]);
                            unset($checkExisting[$key]);
                        }
                   } 
                }                     
                $key++;                
            }
            if($update == 0 && !empty($checkExisting)){
                foreach($checkExisting as $cKey=>$cVal){
                    $this->clean();
                    $this->setId($cVal['id']);
                    $this->setFromArray(array('status'=>0))->update();
                }                        
            }
        }
        return $dataArr;
    }


    public function updateB2BPricingData($companyId, $dataArr, $originalPPIDS) {
        try {
            $linkable_id = $dataArr[0]['linkable_id'];
            $training_id = $dataArr[0]['training_id'];
            $learners_range_id = $dataArr[0]['learners_range_id'];
            $linkableType = $dataArr[0]['linkable_type'];
            $country_id = $dataArr[0]['country_id'];
            $cluster_id = $dataArr[0]['cluster_id'];
            $ppids = explode(',', $originalPPIDS);
            sort($ppids);
            $fields = array(
                'id IN (?)' => $ppids,
                'company_id =?' => $companyId,
                'linkable_type =?' => $linkableType,
                'training_id = ?' => $training_id,
                'country_id = ? ' => $country_id,
                'cluster_id = ? ' => $cluster_id,
                'status =?' => 1,
            );
            $checkExisting = $this->fetchAll($fields);
            if (!empty($checkExisting)) {
                $dataArr =  $this->updateExistingRecords($checkExisting,$dataArr);
            }          
            $insertedIDs = []; 
            if (!empty($dataArr)) {
                foreach ($dataArr as $key => $value) {
                    $this->clean();
                    $value['company_id'] = $companyId;
                    $this->setFromArray($value)->save();
                    $insertedIDs[] = $this->getCurrentId();
                }
            }
            return $insertedIDs;
        } catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
            return [];
        }
    }

    public function updateSyncStatus($currentId) {
        $this->setId($currentId);
        $this->setFromArray(array('status_sync' => 0))->update();
    }
    public function updateSyncStatusOnSync($currentId) {
        $this->setId($currentId);
        $this->setFromArray(array('status_sync' => 1))->update();
    }

    public function getPricingData($companyId,$limit= array()) {
        $result = $finalPricingArr = $response = $formattedPricingArr = array();
        try {
            if (!empty($companyId)) {

                $allowedProductType = $this->_getProductTypeByCompanyId($companyId);
                $linkableTypes = array('course', 'bundle');
                $countryModel = new Model_Country();
                $countryList = $countryModel->fetchForSelect();
                $obj = new Model_Clusters();
                $clusterList = $obj->fetchForSelect();
                $sql = $this->getDb()->select()
                        ->from(array('pricing' => 'b2b_product_pricing'), array(
                            'ids' => new Zend_Db_Expr('GROUP_CONCAT(pricing.id)'),
                            'productids' => new Zend_Db_Expr('GROUP_CONCAT(pricing.linkable_id)'),
                            'learnerrange' => new Zend_Db_Expr("CONCAT(b2b_learners_range.min, '-', b2b_learners_range.max)"),
                            'type' => 'pricing.linkable_type',
                            'price' => new Zend_Db_Expr('min(pricing.price)'),
                            'discount' => new Zend_Db_Expr('max(pricing.flat_discount)'),
                            'training_id' => 'pricing.training_id',
                            'country_id' => 'pricing.country_id',
                            'cluster_id' => 'pricing.cluster_id')
                        )
                        ->join('b2b_learners_range', 'b2b_learners_range.id=pricing.learners_range_id')
                        ->where('pricing.company_id = ?', $companyId)
                        ->where('pricing.linkable_type IN (?) ', $linkableTypes)
                        ->where('pricing.status = ?', 1)
                        ->where('b2b_learners_range.company_id = ?', $companyId)
                        ->where('b2b_learners_range.status = ?', 1)
                        ->group(array(
                    'pricing.training_id',
                    'pricing.linkable_type',
                    'pricing.country_id',
                    'pricing.cluster_id',
                    'pricing.flat_price',
                    'pricing.flat_discount'
                        )
                );
                if (!empty($limit)) {
                    $sql = $sql->limit($limit[0],$limit[1]);
                }
                $result = $this->getDb()->fetchAll($sql);

                if (!empty($result)) {
                    foreach ($result as $key => $row) {
                        if ($row['type'] == BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES) {
                            if (!in_array($row['type'], $allowedProductType))
                                continue;
                        } else {
                            $trainingTypeId = $row['training_id'];
                            if ($trainingTypeId == BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS) {
                                if (!in_array(BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS_NAME, $allowedProductType))
                                    continue;
                            }
                            if ($trainingTypeId == BaseApp_Dao_TrainingTypes::TYPE_ELEARNING) {
                                if (!in_array(BaseApp_Dao_TrainingTypes::TYPE_ELEARNING_NAME, $allowedProductType))
                                    continue;
                            }
                        }

                        $pricingLevel = $pricingType = 0;
                        $productIdsStr = $row['productids'];
                        $productIdsArr = explode(',', $productIdsStr);
                        sort($productIdsArr);
                        $productIdsSortedStr = implode(',', $productIdsArr);
                        $result[$key]['productids'] = $productIdsSortedStr;
                        if ($row['training_id'] == BaseApp_Dao_TrainingTypes::TYPE_ELEARNING) {
                            $result[$key]['training_type'] = 'Online Self Learning';
                        }
                        if ($row['training_id'] == BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS) {
                            $result[$key]['training_type'] = 'LVC';
                        }
                        if ($row['type'] == 'course' && !empty($row['productids'])) {
                            $courseIds = explode(',', $row['productids']);
                            $courseObj = new Model_Courses();
                            $courseNameList = $courseObj->getCourseByIdMultiple($courseIds);
                            $result[$key]['productNameList'] = implode(',', $courseNameList);
                        }
                        if ($row['type'] == 'bundle' && !empty($row['productids'])) {
                            $bundleIds = explode(',', $row['productids']);
                            $bundleObj = new Model_Bundles();
                            $bundleNameList = $bundleObj->getBundleByIds($bundleIds);
                            $result[$key]['productNameList'] = implode(',', $bundleNameList);
                        }

                        if (!empty($row['cluster_id'])) {
                            $pricingLevel = $row['cluster_id'];
                            $pricingType = 'Cluster';
                            $result[$key]['pricing_level'] = 'Cluster';
                            $result[$key]['cluster_name'] = $clusterList[$row['cluster_id']];
                        }
                        if (!empty($row['country_id'])) {
                            $pricingLevel = $row['country_id'];
                            $pricingType = 'Country';
                            $result[$key]['pricing_level'] = 'Country';
                            $result[$key]['country_name'] = $countryList[$row['country_id']];
                        }
                        $learnerRange = $row['learnerrange'];
                        $trainingId = $row['training_id'];
                        $finalPricingArr[$productIdsSortedStr][$trainingId][$pricingType][$pricingLevel][$learnerRange] = $result[$key];
                    }

                    $finalRes = array();
                    $pricingProductIds = array();
                    $formattedPricingArr = array();
                    foreach ($finalPricingArr as $key => $tData) {
                        $productIds = $key;
                        foreach ($tData as $key => $pLData) {
                            $trainingId = $key;
                            foreach ($pLData as $cData) {
                                foreach ($cData as $rData) {
                                    $allIds = array_column($rData, 'ids');
                                    $allIdsStr = implode(",", $allIds);
                                    $clusterArr = array_column($rData, 'cluster_id');
                                    $clusterArr = array_filter($clusterArr);
                                    $clusterIdsArr = array_unique($clusterArr);

                                    $countryArr = array_column($rData, 'country_id');
                                    $countryArr = array_filter($countryArr);
                                    $countryIdsArr = array_unique($countryArr);

                                    $flatPrice = array_column($rData, 'price');
                                    $flatPrice = array_filter($flatPrice);
                                    $flatPrice = !empty($flatPrice) ? min($flatPrice) : 0;

                                    $flatDiscount = array_column($rData, 'discount');
                                    $flatDiscount = array_filter($flatDiscount);
                                    $flatDiscount = !empty($flatDiscount) ? max($flatDiscount) : 0;

                                    $type = array_column($rData, 'type');
                                    $type = array_unique($type);
                                    $training_type = array_column($rData, 'training_type');
                                    $training_type = array_unique($training_type);
                                    $learnerRange = array_column($rData, 'learnerrange');
                                    $productNameList = array_column($rData, 'productNameList');
                                    $productNameList = array_unique($productNameList);

                                    $clusterName = array_column($rData, 'cluster_name');
                                    $clusterName = array_unique($clusterName);

                                    $pricingLevel = array_column($rData, 'pricing_level');
                                    $pricingLevel = array_unique($pricingLevel);
                                    $countryName = array_column($rData, 'country_name');
                                    $countryName = array_unique($countryName);
                                    $formattedPricingArr[] = array(
                                        'ids' => $allIdsStr,
                                        'type' => !empty($type[0]) ? $type[0] : '',
                                        'companyId' => $companyId,
                                        'productIds' => $productIds,
                                        'productNameList' => !empty($productNameList[0]) ? $productNameList[0] : '-',
                                        'cluster_id' => !empty($clusterIdsArr[0]) ? $clusterIdsArr[0] : 0,
                                        'country_id' => !empty($countryIdsArr[0]) ? $countryIdsArr[0] : 0,
                                        'training_id' => $trainingId,
                                        'price' => $flatPrice,
                                        'discount' => $flatDiscount,
                                        'learner_range' => implode(',', $learnerRange),
                                        'training_type' => !empty($training_type[0]) ? $training_type[0] : '',
                                        'cluster_name' => !empty($clusterName[0]) ? $clusterName[0] : '-',
                                        'country_name' => !empty($countryName[0]) ? $countryName[0] : '-',
                                        'pricing_level' => !empty($pricingLevel[0]) ? $pricingLevel[0] : '-'
                                    );
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
        }
        return $formattedPricingArr;
    }

    /**
     * Check If Any Pricing Exist For The Range Id.
     * If Exist Then Update The Pricing Status To Zero(0)
     * Then Update The Learners Range Id Status To Zero(0)
     */
    public function disablePricingAndRange($companyId, $learnerRangeId) {
        if (!empty($companyId) && !empty($learnerRangeId)) {
            $condition = array('company_id = ?' => $companyId, 'learners_range_id = ? ' => $learnerRangeId, 'status = ?' => 1);
            $checkExisting = $this->fetchAll($condition);
            if (!empty($checkExisting)) {
                foreach ($checkExisting as $key => $value) {
                    if ($value['learners_range_id'] == $learnerRangeId) {
                        $this->clean();
                        $this->setId($value['id']);
                        $this->setFromArray(array('status' => 0))->update();
                    }
                }
            }
            $learnerRangeObj = new Model_LearnersRange();
            if ($learnerRangeObj->updateLearnerRangeStatus($learnerRangeId)) {
                return true;
            }
        }
        return false;
    }

    public function disableCompanyPricing($companyId) {
        if (!empty($companyId)) {
            return $this->getDb()->update('b2b_product_pricing', array('status' => 0), "company_id = " . $companyId);
        }
        return false;
    }

    public function getCoursePricingDataById($companyId, $productPricingIds) {
        $result = $finalPricingArr = $formattedData = array();
        try {

            if (!empty($companyId)) {
                $linkableTypes = array('course', 'bundle');
                $productPricingIds = explode(',', $productPricingIds);
                $countryModel = new Model_Country();
                $countryList = $countryModel->fetchForSelect();
                $obj = new Model_Clusters();
                $clusterList = $obj->fetchForSelect();
                $sql = $this->getDb()->select()
                        ->from(array('pricing' => 'b2b_product_pricing'), array(
                            'productids' => new Zend_Db_Expr('GROUP_CONCAT(pricing.linkable_id)'),
                            'learnerrange' => new Zend_Db_Expr("CONCAT(b2b_learners_range.min, '-', b2b_learners_range.max)"),
                            'linkable_type' => 'pricing.linkable_type',
                            'access_day_id' => 'pricing.access_day_id',
                            'learner_range_id' => 'pricing.learners_range_id',
                            'flat_price' => 'pricing.flat_price',
                            'flat_discount' => 'pricing.flat_discount',
                            'training_id' => 'pricing.training_id',
                            'country_id' => 'pricing.country_id',
                            'cluster_id' => 'pricing.cluster_id'))
                        ->join('b2b_learners_range', 'b2b_learners_range.id=pricing.learners_range_id')
                        ->where('pricing.company_id = ?', $companyId)
                        ->where('pricing.linkable_type IN (?) ', $linkableTypes)
                        ->where('pricing.id IN (?) ', $productPricingIds)
                        ->where('pricing.status = ?', 1)
                        ->where('b2b_learners_range.company_id = ?', $companyId)
                        ->where('b2b_learners_range.status = ?', 1)
                        ->group(array(
                    'pricing.training_id',
                    'pricing.linkable_type',
                    'pricing.country_id',
                    'pricing.cluster_id',
                    'pricing.flat_price',
                    'pricing.flat_discount'
                ));
                $result = $this->getDb()->fetchAll($sql);
                if (!empty($result)) {
                    foreach ($result as $key => $row) {
                        if ($row['training_id'] == BaseApp_Dao_TrainingTypes::TYPE_ELEARNING) {
                            $row['training_type'] = 'Online Self Learning';
                            $result[$key]['product_type'] = "osl";
                        }
                        if ($row['training_id'] == BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS) {
                            $result[$key]['training_type'] = 'LVC';
                            $result[$key]['product_type'] = "lvc";
                        }

                        if ($row['linkable_type'] == 'bundle') {
                            $result[$key]['product_type'] = "mp";
                        }

                        if (!empty($row['cluster_id'])) {
                            $result[$key]['pricing_level'] = 1;
                            $result[$key]['cluster_name'] = $clusterList[$row['cluster_id']];
                        }

                        if (!empty($row['country_id'])) {
                            $result[$key]['pricing_level'] = 2;
                            $result[$key]['country_name'] = $countryList[$row['country_id']];
                        }

                        if ($row['linkable_type'] == 'course' && !empty($row['productids'])) {
                            $courseIds = explode(',', $row['productids']);
                            $courseObj = new Model_Courses();
                            $courseNameList = $courseObj->getCourseByIdMultiple($courseIds);
                            $result[$key]['productNameList'] = $courseNameList;
                        }
                        if ($row['linkable_type'] == 'bundle' && !empty($row['productids'])) {
                            $bundleIds = explode(',', $row['productids']);
                            $bundleObj = new Model_Bundles();
                            $bundleNameList = $bundleObj->getBundleByIds($bundleIds);
                            $result[$key]['productNameList'] = $bundleNameList;
                        }
                    }

                    //Format Data
                    $formattedData = array();
                    foreach ($result as $row) {
                        $learnerRange = $row['learnerrange'];
                        $formattedData[$learnerRange][] = $row;
                    }
                }
            }
        } catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
        }
        //prd($formattedData);
        return $formattedData;
    }

    public function deleteB2BPricingData($companyId, $originalPPIDS) {
        try {
            $ppids = explode(',', $originalPPIDS);
            $fields = array(
                'id IN (?)' => $ppids,
                'company_id =?' => $companyId,
            );
            $checkExisting = $this->fetchAll($fields);
            if (!empty($checkExisting)) {
                foreach ($checkExisting as $key => $value) {
                    $this->clean();
                    $this->setId($value['id']);
                    $this->setFromArray(array('status' => 0))->update();
                }
            }

            return true;
        } catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }

    public function getCategoryPricingData($companyId) {
        $result = $finalPricingArr = $formattedPricingArr = array();
        try {
            if (!empty($companyId)) {
                $linkableTypes = array('category');
                $countryModel = new Model_Country();
                $countryList = $countryModel->fetchForSelect();
                $obj = new Model_Clusters();
                $clusterList = $obj->fetchForSelect();
                $sql = $this->getDb()->select()
                        ->from(array('pricing' => 'b2b_product_pricing'), array(
                            'ids' => new Zend_Db_Expr('GROUP_CONCAT(pricing.id)'),
                            'linkable_id' => 'pricing.linkable_id',
                            // 'learnerrange' => new Zend_Db_Expr("CONCAT(pricing.learners_range_min, '-', pricing.learners_range_max)"),
                            'type' => 'pricing.linkable_type',
                            'price' => new Zend_Db_Expr('min(pricing.price)'),
                            'discount' => new Zend_Db_Expr('max(pricing.flat_discount)'),
                            'training_id' => 'pricing.training_id',
                            'country_id' => 'pricing.country_id',
                            'cluster_id' => 'pricing.cluster_id')
                        )
                        ->where('pricing.company_id = ?', $companyId)
                        ->where('pricing.linkable_type IN (?) ', $linkableTypes)
                        ->where('pricing.status = ?', 1)
                        ->group(array(
                    'pricing.training_id',
                    'pricing.linkable_type',
                    'pricing.country_id',
                    'pricing.cluster_id',
                    'pricing.linkable_id',
                        //'pricing.flat_price',
                        //'pricing.flat_discount'
                        )
                );
                $result = $this->getDb()->fetchAll($sql);
                if (!empty($result)) {
                    foreach ($result as $key => $row) {
                        $linkableId = $row['linkable_id'];
                        if ($row['training_id'] == BaseApp_Dao_TrainingTypes::TYPE_ELEARNING) {
                            $result[$key]['training_type'] = 'Online Self Learning';
                        }
                        if ($row['training_id'] == BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS) {
                            $result[$key]['training_type'] = 'LVC';
                        }

                        if (!empty($row['cluster_id'])) {
                            $result[$key]['pricing_level'] = 'Cluster';
                            $result[$key]['cluster_name'] = $clusterList[$row['cluster_id']];
                        }
                        if (!empty($row['country_id'])) {
                            $result[$key]['pricing_level'] = 'Country';
                            $result[$key]['country_name'] = $countryList[$row['country_id']];
                        }

                        $courseObj = new Model_Labels();
                        $categoryName = $courseObj->getNameById($linkableId);
                        $result[$key]['categoryName'] = $categoryName;
                        $result[$key]['pricingType'] = 'product';
                        $result[$key]['companyId'] = $companyId;
                        $finalPricingArr[] = $result[$key];
                    }
                }
            }
        } catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
        }

        // prd($finalPricingArr);
        return $finalPricingArr;
    }

    public function deleteDataByTrainingAndType($companyId, $linkableType, $trainingId) {
        try {
            $fields = array(
                'linkable_type = ? ' => $linkableType,
                'training_id = ?' => $trainingId,
                'company_id =?' => $companyId,
            );
            $checkExisting = $this->fetchAll($fields);
            if (!empty($checkExisting)) {
                foreach ($checkExisting as $key => $value) {
                    $this->clean();
                    $this->setId($value['id']);
                    $this->setFromArray(array('status' => 0))->update();
                }
            }
            return true;
        } catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }

    /**
     * Remove this method
     */
//    public function updateRangeDataByRangeId($updateParams) {
//        try {
//            if (!empty($updateParams)) {
//                $learnerRangeId = $updateParams['learnersRangeId'];
//                $companyId = $updateParams['companyId'];
//                $learnerRangeMin = $updateParams['min'];
//                $learnerRangeMax = $updateParams['max'];
//                $fields = array(
//                    'learners_range_id = ? ' => $learnerRangeId,
//                    'company_id =?' => $companyId,
//                );
//                $checkExisting = $this->fetchAll($fields);
//                if (!empty($checkExisting)) {
//                    foreach ($checkExisting as $key => $value) {
//                        $params = array('learners_range_min' => $learnerRangeMin, 'learners_range_max' => $learnerRangeMax);
//                        $this->clean();
//                        $this->setId($value['id']);
//                        $this->setFromArray($params)->update();
//                    }
//                }
//                return true;
//            }
//        } catch (Exception $e) {
//            if (APPLICATION_ENV == 'development')
//                throw $e;
//            return false;
//        }
//        return false;
//    }

    public function getCategoryPricingDataById($companyId, $ppidsArr, $ptype) {
        $result = $finalPricingArr = $formattedPricingArr = array();
        try {
            if (!empty($companyId) && $ptype == 'product') {
                $linkableTypes = array('category');
                $countryModel = new Model_Country();
                $countryList = $countryModel->fetchForSelect();
                $obj = new Model_Clusters();
                $clusterList = $obj->fetchForSelect();
                $sql = $this->getDb()->select()
                        ->from(array('pricing' => 'b2b_product_pricing'), array(
                            'id' => 'pricing.id',
                            'linkable_id' => 'pricing.linkable_id',
                            // 'pricing.learners_range_min',
                            // 'pricing.learners_range_max',
                            'pricing.access_day_id',
                            'type' => 'pricing.linkable_type',
                            'price' => 'pricing.flat_price',
                            'discount' => 'pricing.flat_discount',
                            'training_id' => 'pricing.training_id',
                            'country_id' => 'pricing.country_id',
                            'cluster_id' => 'pricing.cluster_id')
                        )
                        ->where('pricing.company_id = ?', $companyId)
                        ->where('pricing.linkable_type IN (?) ', $linkableTypes)
                        ->where('pricing.status = ?', 1)
                        ->where('pricing.id IN (?)', $ppidsArr);
                $result = $this->getDb()->fetchAll($sql);
            }

            if (!empty($companyId) && $ptype == 'flat') {
                $linkableTypes = array('category');
                $countryModel = new Model_Country();
                $countryList = $countryModel->fetchForSelect();
                $obj = new Model_Clusters();
                $clusterList = $obj->fetchForSelect();
                $sql = $this->getDb()->select()
                        ->from(array('pricing' => 'b2b_flat_pricing'), array(
                            'id' => 'pricing.id',
                            // 'pricing.learners_range_min',
                            // 'pricing.learners_range_max',
                            'pricing.access_day_id',
                            'type' => 'pricing.linkable_type',
                            'price' => 'pricing.flat_price',
                            'discount' => 'pricing.flat_discount',
                            'training_id' => 'pricing.training_id',
                            'country_id' => 'pricing.country_id',
                            'cluster_id' => 'pricing.cluster_id')
                        )
                        ->where('pricing.company_id = ?', $companyId)
                        ->where('pricing.linkable_type IN (?) ', $linkableTypes)
                        ->where('pricing.status = ?', 1)
                        ->where('pricing.id IN (?)', $ppidsArr);
                $result = $this->getDb()->fetchAll($sql);
            }
        } catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
        }
        return $result;
    }

    private function _getProductTypeByCompanyId($companyId) {
        $productTypes = array();
        $obj = new Model_ProductSectionData();
        $allowedTypes = array();
        $result = $obj->fetchAll(array(
            'company =?' => $companyId,
            'sectionType IN (?)' => array(BaseApp_Dao_TrainingTypes::B2B_TRAINING_TYPE, BaseApp_Dao_TrainingTypes::B2B_PRODUCT_TYPE)
                ), array('columns' => array('name' => 'description', 'id' => 'name')));
        if (!empty($result)) {
            foreach ($result as $row) {
                $name = $row['name'];
                if ($name == BaseApp_Dao_TrainingTypes::TYPE_ELEARNING_NAME) {
                    $productTypes[BaseApp_Dao_TrainingTypes::TYPE_ELEARNING_NAME] = BaseApp_Dao_TrainingTypes::TYPE_ELEARNING;
                    $allowedTypes[] = BaseApp_Dao_TrainingTypes::TYPE_ELEARNING_NAME;
                }
                if ($name == BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS_NAME) {
                    $productTypes[BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS_NAME] = BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS;
                    $allowedTypes[] = BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS_NAME;
                }
                if ($name == BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES) {
                    $productTypes[BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES] = BaseApp_Dao_ProductTypes::TYPE_ID_BUNDLE;
                    $allowedTypes[] = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES;
                }
            }
        }
        return $allowedTypes;
    }
    /**
     * deleteProductPriceClusterCountryLevel -  
     * deletes records from pricings table 
     * if price is deleted from pricing table based on cluster or country,
     * delete it from b2bproduct table, 
     * @params courseId  
     * @params cId - cluster or country id
     * @params isCluser(Boolean) - true if its a cluster 
     * 
     * 
     */
    public function deleteProductPriceClusterCountryLevel($courseId, $cId, $isCluster,$linkebleType="",$trainingTypeId) {
        try {
                        
            $fields = array(
                'linkable_id = ? ' => $courseId,                
            );
            if($isCluster){                
                //isCluster and find country inside
                                
                $modelCountry = new Model_Country();
                $countryIds = array();
                foreach($modelCountry->fetchAll(array('cluster_id=?'=>$cId), array('columns'=> array('country_id'))) as $countryData) {
                    $countryIds[] = $countryData['country_id'];
                }               
                if(!empty($countryIds)) {
                    $cntry = [];
                    if($linkebleType == "course"){
                        $modelPrice = new Model_Pricings();
                        $cond = array(
                            
                            'training_id=?' => $trainingTypeId,
                            'course_id =?' => $courseId,
                            'status=?'    => 1,
                            'country_id IN (?)' => $countryIds

                        );                       
                        $existingCountries = $modelPrice->fetchAll($cond);                        
                        if(!empty($existingCountries)){
                            foreach($existingCountries as $countries){
                                $cntry[] = $countries['country_id'];
                            }
                        }                        
                    }
                    
                    if($linkebleType == "bundle"){
                        $modelBudlePrice = new Model_SubscriptionPricing();
                        $cond = array(
                            'country_id IN (?)' => $countryIds,
                            'training_id=?' => $trainingTypeId,
                            'linkable_id=?' => $courseId,
                            'status=?'    => 1
                        );
                        $existingCountries = $modelBudlePrice->fetchAll($cond);
                        if(!empty($existingCountries)){
                            foreach($existingCountries as $countries){
                                $cntry[] = $countries['country_id'];
                            }
                        }
                    }
                   
                    $cntry = array_diff($countryIds,$cntry);
                   
                    if(!empty($cntry)){                       
                        $fields["cluster_id = $cId or country_id IN (?) "] = array_values($cntry);                       
                    }else{
                        $fields['cluster_id = ?'] = $cId;
                    }
                }else{
                    $fields['cluster_id = ?'] = $cId;
                }

            }else{
                $fields['country_id = ?'] = $cId;
            }
            if($linkebleType !=""){
                $fields['linkable_type = ?'] = $linkebleType;
            }
            
            if(!empty($trainingTypeId)){
                $fields['training_id = ?'] = $trainingTypeId;
            }            
            $checkExisting = $this->fetchAll($fields);  
                        //prd($checkExisting);                                     
            if (!empty($checkExisting)) {
                $db  = new Model_Default;
                foreach ($checkExisting as $key => $value) {  
                    
                    /*check in product section data for company price plan 
                    * there id is company id and sectionType = 'company'
                    *priceplan 1 = Discount Price Plan ,2 = Fixed Price Plan
                    */
                    $obj = new Model_ProductSectionData();
                    $idData = $obj->fetchAll(array('id = ?' => $value['company_id'],'sectionType = ?'=>'company')); 
                    $idData = current($idData);

                    
                    //remove all documents from b2bCartPricings collection based on pricing id                   
                    if(!empty($idData['company_price_plans'])&&($idData['company_price_plans']==1)){
                        
                        try {
                            $remove = $db->b2bCartPricings->remove(array("pricing_id"   => $value['id'] ,"type_of_price"   => "product_price"));            
                        }catch(exception $e){                
                            $this->view->data = array(
                                'error' => true,
                                'errorMessage' => $e
                            );
                            file_put_contents(APPLICATION_PATH . '/../error.log', __METHOD__ .'error occured on delete action from b2bCartPricing collection : '. print_r($e,true), FILE_APPEND);
                        }
                        $this->clean();
                        $this->setId($value['id']);
                        $this->setFromArray(array('status' => 0))->update();
                    }
                    
                }
            }
            return true;
        } catch (Exception $e) {           
            if (APPLICATION_ENV == 'development')                
                throw $e;

            file_put_contents(APPLICATION_PATH . '/../error.log', __METHOD__ .'error occured on delete action on b2bProducts  : '. print_r($e,true), FILE_APPEND);                
            return false;
        }
    }

    public function deletePricingByProduct($linkableType, $linkableId) {
        $b2bCartPricing = new Model_B2bCartPricing();
        $b2bCompanies = new Model_B2BCompanies();
        $query = "
            update b2b_product_pricing 
            set status = 0
            where 
                linkable_type = '$linkableType' and linkable_id = '$linkableId' and status = 1
        ";
        $db = $this->getDb();
        $data = $db->query($query);
        $b2bCartPricing->deleteB2bCartProductData($linkableType,$linkableId);
        $b2bCompanies->updateExclusionList($linkableType,$linkableId);
        return $data;
    }
    
    public function deleteProductPricingByAgencies($linkableType, $linkableId, $agencies, $agencyOption = self::OPTIONS_INCLUDE) {
        $b2bCartPricing = new Model_B2bCartPricing();
        $b2bCompany = new Model_B2BCompanies();
        $agencyStr = '"' . implode('","', $agencies) . '"';
        $agencyOptionStr = "in";
        $inclusionFlag = '$in';
        if($agencyOption == self::OPTIONS_EXCLUDE) {
            $agencyOptionStr = "not in";
            $inclusionFlag = '$nin';
        }
        $query = "
            update b2b_product_pricing 
            set status = 0
            where 
                linkable_type = '$linkableType' and linkable_id = '$linkableId' and status = 1 and 
                company_id $agencyOptionStr (
                    select 
                        company.id
                    from productSectionData company
                    join productSectionData agency on agency.company = company.id
                    left join b2bAgencyDetails agency_mapping on agency_mapping.agency_id = agency.id
                    where 
                        company.sectionType='company' and company.status = 1 and 
                        agency.sectionType='agency' and agency.status = 1 and
                        agency_mapping.status = 1 and
                        agency_mapping.gid in ($agencyStr)
                )
                ";
                $db = $this->getDb();
                 $sql = "
                    select 
                        company.id
                    from productSectionData company
                    join productSectionData agency on agency.company = company.id
                    left join b2bAgencyDetails agency_mapping on agency_mapping.agency_id = agency.id
                    where 
                        company.sectionType='company' and company.status = 1 and 
                        agency.sectionType='agency' and agency.status = 1 and
                        agency_mapping.status = 1 and
                        agency_mapping.gid in ($agencyStr)";
        $companyIds = $db->fetchAll($sql);
        $result = $db->query($query);
        $b2bCartPricing->deleteB2bCartAgencyData($linkableType, $linkableId, $companyIds, $inclusionFlag);
        $b2bCompany->updateExclusionByAgency($linkableType, $linkableId, $companyIds,$inclusionFlag);
        return $result;
    }
    public function deleteProductPricingByIds($linkableIdArr, $linkableType, $companyId)
    {
        $linkableIdArr = '"' . implode('","', $linkableIdArr) . '"';
        $query = "
            update b2b_product_pricing 
            set status = 0
            where 
                linkable_type = '$linkableType' and company_id = '$companyId' and linkable_id  in ($linkableIdArr) and status = 1";
        $db = $this->getDb();
        return $db->query($query);
    }
}

// End of Class
