<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_Videos extends BaseApp_Dao_Videos{	

    const VIDEOS_ENTRIES_PER_FRS_LIMIT = 6;

    protected $fileFormatsArr = array('.wmv'=>'.wmv','.rm'=>'.rm','.m4p'=>'.m4p','.mpg'=>'.mpg','.mpeg'=>'.mpeg','3gp'=>'3gp','.flv'=>'.flv');

    public function getFileFormats(){
            return $this->fileFormatsArr;
    }

    public function getByCourse($courseId, $traingId, $type) {
        $conds = array(
            'course_id=?' => $courseId,
            'name=?' => $type
        );
        if($traingId === false) {
            $conds['training_id IS NULL'] = '';    
        }
        else {
            $conds['training_id=?'] = $traingId;    
        }
        return current($this->fetchAll($conds));
    }
    
    public function getByLinkableId($linkableId, $linkableType, $traingId, $type) {
    	$conds = array(
    			'linkable_id=?' => $linkableId,
    			'linkable_type=?' => $linkableType,
    			'name=?' => $type
    	);
    	if($traingId === false) {
    		$conds['training_id IS NULL'] = '';
    	}
    	else {
    		$conds['training_id=?'] = $traingId;
    	}
    	return current($this->fetchAll($conds));
    }

    public function getVideoLink($courseId, $traingId, $type) {        
        if($data = $this->getByCourse($courseId, $traingId, $type)) {
            return $data['videoLink'];
        }  
        return '';
    }
    
    public function createVideo($data) {
        $db = $this->getDb();
	    $objVideo = new self();
        $pageUrl = '';
        $db->beginTransaction();
        try{
            if(isset($data['url'])) {
                $pageUrl = trim($data['url']);
                $checkSlash = substr($pageUrl, 0,1);
                if($checkSlash != '/'){
                    $pageUrl = trim('/'.$pageUrl);
                }
                $objVideo->setPageUrl($pageUrl);
                unset($data['url']);
            }
            $data['dateCreated'] = date('Y-m-d H:i:s');
            $objVideo->setFromArray($data)->save();
            $dataSave = array(
                'controller' => self::SEO_DEFAULT_CONTROLLER,
                'action' => self::SEO_DEFAULT_ACTION,
                'params' => json_encode(array(self::SEO_DEFAULT_PARAM_KEY=>$objVideo->video_id)),
                'linkable_id' => $objVideo->video_id,
                'linkable_type' => 'video'
            );
            $modelSeo = new Model_Seo();
            $seoData = $modelSeo->getDataByUrl($pageUrl);
            $modelSeo->setId($seoData['seo_id']);
            $modelSeo->setFromArray($dataSave)->update();
            $cdnPurgeData = $this->buildCdnPurgeData($objVideo->video_id,'video New Video Added '.$objVideo->name);
            $objCdn = new Model_CdnPurgeLog();
            if(!empty($cdnPurgeData))
                $objCdn->InsertCdnPurgeLog($cdnPurgeData);
            $db->commit();
            return $objVideo->video_id;
        }
        catch (Exception $e){
            $db->rollBack();
            return false;
        }
    }
    
    public function updateVideo($data) {
        $db = $this->getDb();
	$objVideo = new self();
        $data['last_updated_time'] = date('Y-m-d H:i:s');
        $db->beginTransaction();
        try{
            $objVideo->setId($data['video_id']);
            $objVideo->setFromArray($data)->update();
            $cdnPurgeData = $this->buildCdnPurgeData($data['video_id'],'video Video Modified '.$objVideo->name);
            $objCdn = new Model_CdnPurgeLog();
            if(!empty($cdnPurgeData))
                $objCdn->InsertCdnPurgeLog($cdnPurgeData);
            $db->commit();
            return true;
        }
        catch (Exception $e){
            $db->rollBack();
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }
    
    public function getAssociatedArticlesByCourse($courseId) {
        $conds = array(
            'course_id = ?' => $courseId
        );        
        $opts = array(
            'columns' => array(
                'video_id',
                'displayName'
            )
        );
        return $this->fetchAll($conds, $opts, false);
    }
    
    public function deleteCourseIntroVideo($courseId) {
        $db = $this->getDb();
	$objVideo = new self();
        $db->beginTransaction();
        try{
            $videoData = $objVideo->getByCourse($courseId, 0, 'about_course');
            if(!$videoData) {
                $db->commit();
                return true;
            }
            $objVideo->clean();
            $objVideo->setId($videoData['video_id']);
            $objVideo->delete();
            $db->commit();
            return true;
        }
        catch (Exception $e){
            $db->rollBack();
            return false;
        }
    }
    
    public function deleteVideo($linkableId, $linkableType, $traingId, $type) {
    	$db = $this->getDb();
    	$objVideo = new self();
    	$db->beginTransaction();
    	try{
    		$videoData = $objVideo->getByLinkableId($linkableId, $linkableType, $traingId, $type);
    		if(!$videoData) {
    			$db->commit();
    			return true;
    		}
    		$objVideo->clean();
    		$objVideo->setId($videoData['video_id']);
    		$objVideo->delete();
    		$db->commit();
    		return true;
    	}
    	catch (Exception $e){
    		$db->rollBack();
    		return false;
    	}
    }
    

    public function buildCdnPurgeData($videoId,$action){
        $returnArr = array();
        // $objSeo = new Model_Seo();
        // $seoData = current($objSeo->fetchAll(array('linkable_id = ? '=>$videoId,'linkable_type =?'=>'video'),array('columns'=>array('url','linkable_id'))));
        // if(!empty($seoData)){
        //  array_push($returnArr,array('linkable_id'=>$seoData['linkable_id'],'linkable_type'=>'video','action'=>$action,'url'=>$seoData['url'],'created_at'=>time(),'updated_at'=>time()) );
        // }

        // $seoData = current($seoObj->fetchAll(array('linkable_id IS NULL'=>'','linkable_type IS NULL'=>'','url_type =?'=>'Videos List'),array('columns'=>array('url'))));
        // if(!empty($seoData)){
        //  array_push($returnArr,array('linkable_id'=>$seoData['linkable_id'],'linkable_type'=>'video','action'=>$action,'url'=>$seoData['url'],'created_at'=>time(),'updated_at'=>time()) );
        // }

        // $db = $this->getDb();
        // $videoSql = $this->getDb()->select()
        //                  ->from(array('v' => 'videos'), array('video_id'))
        //                  ->where('v.status = ?', 1)
        //                  ->order('video_id DESC')
        //                  ->limit(self::VIDEOS_ENTRIES_PER_FRS_LIMIT);
        // $videoData = $this->getDb()->fetchAll($videoSql);
        // if(!empty($videoData)){
        //     $videoData = array_values($videoData);
        //     if(in_array($videoId, $videoData)){
        //         array_push($returnArr,array('linkable_id'=>$videoId,'linkable_type'=>'video','action'=>$action,'url'=>PURGE_WEBSITE,'created_at'=>time(),'updated_at'=>time()) );
        //     }
        // }
        return $returnArr;
    } // end of function
} // End of Class