<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_Clusters extends BaseApp_Dao_Clusters{	

    public function getListDisplay($clusterIds=array()) {
        $conds = array(
            
        );
        $options = array(
        );
        if($clusterIds) {
            $conds['cluster_id IN (?)'] = $clusterIds;
        }
        $clusterData = array();
        foreach($this->fetchAll($conds, $options) as $indexTmp => $data) {
            $clusterData[$data['cluster_id']] = $data['name'];
        }
        return $clusterData;
    }        
    
    public function getCurrencies($clusterIds) {
        $conds = array(
            'cluster_id IN (?)' => $clusterIds
        );
        $options = array(
            'currency_id',
            'cluster_id'
        );
        $modelCurrency = new Model_Currency();
        $currencyData = $modelCurrency->getCurrencyToDisplay();;
        
        $clusters = array();
        foreach($this->fetchAll($conds, $options) as $indexTmp => $data) {
            $clusters[$data['cluster_id']] = $data['currency_id'];
        }
        foreach($clusters as $clusterId => &$currencyId) {
            $currencyId = $currencyData[$currencyId];
        }
        return $clusters; 
    }
    public function getCurrenciesIds($clusterIds) {
        $conds = array(
            'cluster_id IN (?)' => $clusterIds
        );
        $options = array(
            'currency_id',
            'cluster_id'
        );
        $modelCurrency = new Model_Currency();
        $currencyData = $modelCurrency->getCurrencyToDisplay();;
        
        $clusters = array();
        foreach($this->fetchAll($conds, $options) as $indexTmp => $data) {
            $clusters[$data['cluster_id']] = $data['currency_id'];
        }
        return $clusters; 
    }
    public function getById($clusterIds) {
        if(!$clusterIds) {
            return array();
        }
        $conds = array(
            'cluster_id IN (?)' => $clusterIds
        );
        $options = array(
        );
        $clusterData = array();
        foreach($this->fetchAll($conds, $options, false) as $indexTmp => $data) {
            $clusterData[$data['cluster_id']] = $data['name'];
        }
        return $clusterData;
    }   
} // End of Class