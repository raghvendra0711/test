<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_FreePracticeTest extends BaseApp_Dao_FreePracticeTest{
		

    public function createPracticeTest($data) { 
        $db = $this->getDb();
	    $objPractice = new self();
        $pageUrl = '';
        $db->beginTransaction();
        try{
            if(isset($data['url'])) {
                $pageUrl = trim($data['url']);
                $checkSlash = substr($pageUrl, 0,1);
                if($checkSlash != '/'){
                    $pageUrl = trim('/'.$pageUrl);
                }
                $objPractice->setPageUrl($pageUrl);
                unset($data['url']);
            }
            $objPractice->setFromArray($data)->save();
            $dataSave = array(
                'controller' => $data['test_type'] == 'free_practice_test' ? self::SEO_DEFAULT_CONTROLLER : self::SEO_SCHOLARSHIP_CONTROLLER,
                'action' => self::SEO_DEFAULT_ACTION,
                'params' => json_encode([self::SEO_DEFAULT_PARAM_KEY => $objPractice->free_practice_test_id]),
                'linkable_id' => $objPractice->free_practice_test_id,
                'linkable_type' => 'practice_test'
            );
            $modelSeo = new Model_Seo();
            $seoData = $modelSeo->getDataByUrl($pageUrl);
            $modelSeo->setId($seoData['seo_id']);
            $modelSeo->setFromArray($dataSave)->update();
            $db->commit();
            return $objPractice->free_practice_test_id;
        }
        catch (Exception $e){
            $db->rollBack();
            return false;
        }
    }
    
    public function updatePracticeTest($data) {
        $db = $this->getDb();
	$objPractice = new self();
        $db->beginTransaction();
        try{
            $objPractice->setId($data['free_practice_test_id']);
            /* if(isset($data['secondary_course_id']) && is_array($data['secondary_course_id'])){
                $data['secondary_course_id'] = implode(",",$data['secondary_course_id']);
            } */
            $objPractice->setFromArray($data)->update();  
            $db->commit();
            return true;
        }
        catch (Exception $e){
            $db->rollBack();
            return false;
        }
    }
    
    public function getForInclusion($courseId, $trainingId = 0) {
        $returnData = array();
        $data = $this->fetchAll(array('course_id = ?' => $courseId), array(), false);
        foreach($data as $tempId => $dataReal) {
            $returnData['freepracticeTests']['practice_test'.$dataReal['free_practice_test_id']] = 'Practice Test (ID-'.$dataReal['free_practice_test_id'].')';
        }
        return $returnData;
    }
    
    public function _afterFetchAll($data){
        return $data;
    }
   
   public function select_multiple_pre_select($data) {
    //    return explode(",",$data);
        if(!empty($data)){
            $secondaryProductIds = json_decode($data);
            if(!empty($secondaryProductIds) && is_array($secondaryProductIds)){
                $secondaryProductIds = array_map(function($val){
                    return $val->id .'#'.$val->type;
                },$secondaryProductIds);
                $data = $secondaryProductIds;
            }
        }
        return $data;
   }
    
   public function paperclip_fpt_forselect() {
        $db = new Model_Default;
        $test_data_mongo = $db->FreePracticeTests->find()->toArray();
        $return_data = NULL;
        foreach($test_data_mongo as $test){
            if(empty($test['practiceTest_id']) && ($test['timeLimit'] != NULL) && !empty($test['questions'])){
                $return_data[$test['testId']] = $test['title'] . " ( PC ID : ".$test['testId']." and " . $test['numberOfQuestions'] ." Questions )";
            }
        }
        return $return_data;
    }
    
    public function paperclipById($testId) {
        $db = new Model_Default;
        $conds = array('testId'=>$testId,'practiceTest_id'=>"");
        $filters =array('_id'=>FALSE,'testId' =>true,'numberOfQuestions' =>true,'timeLimit' =>true);
        $return_data = $db->FreePracticeTests->find($conds,$filters)->toArray();
        return count($return_data) > 0 ? $return_data[0] : null;
    } 
    
} // End of Class