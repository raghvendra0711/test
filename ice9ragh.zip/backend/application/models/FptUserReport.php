<?php 

class Model_FptUserReport extends BaseApp_Dao_FptUserReport {
    
    public function getUserData($email){
        try {
            if(empty($email)){
                throw new BaseApp_Exception('Cannot get User Data. Email is empty');
            }
            $tableName = $this->_name;
            $key = array($this->_pk => $email);
            $params['ProjectionExpression'] = 'course_id,product_name,practice_test_id,practice_test_name,total_questions,questions_attempted,questions_correct,correct_percentage,fpt_time,email_id,phone,test_type'; //fields to fetch
            $params['ScanIndexForward'] = false;
            $data = $this->query($tableName,$key,$params);
            return $data;
        } catch (Exception $e){
            if (APPLICATION_ENV == 'development')
                throw $e;

            file_put_contents(APPLICATION_PATH . '/../error.log','getUserData Failed '. ' Exception: '.$e->getMessage(), FILE_APPEND);
            return false;
        }
    }

    public function insertBatchUserData($data){
        try {
            if(empty($data)){
                throw new BaseApp_Exception('Invalid Data');
            }
            $tableName = $this->_name;
            $data = $this->batchWrite($tableName,$data);
            return $data;
        } catch (Exception $e){
            if (APPLICATION_ENV == 'development')
                throw $e;

            file_put_contents(APPLICATION_PATH . '/../error.log','InsertBatchUserData Failed '. ' Exception: '.$e->getMessage(), FILE_APPEND);
            return false;
        }
    }
}
?>