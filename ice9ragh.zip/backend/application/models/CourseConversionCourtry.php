<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_CourseConversionCourtry extends BaseApp_Dao_CourseConversionCourtry{


} // End of Class