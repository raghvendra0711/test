<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Model_CourseMapping extends BaseApp_Dao_CourseMapping {

    public function deleteBundleMappingById($_ids) {
        $_ids = is_array($_ids) ? $_ids : array($_ids);
        $db = $this->getDb();
        $bEObj = new self();
        $db->beginTransaction();
        try {
            foreach ($_ids as $id) {
                $bEObj->clean();
                $bEObj->setId($id);
                $bEObj->delete();
            }
            $bEObj->clean();
            $db->commit();
            return true;
        } catch (Exception $e) {
            $db->rollBack();
            return false;
        }
    }
    
    public function deleteBundleCoursesById($_ids) {
    	$_ids = is_array($_ids) ? $_ids : array($_ids);
    	$db = $this->getDb();
    	$bEObj = new self();
    	$db->beginTransaction();
    	try {
    		foreach ($_ids as $id) {
    			$bEObj->clean();
    			$bEObj->setId($id);
    			$bEObj->delete();
    		}
    		$bEObj->clean();
    		$db->commit();
    		return true;
    	} catch (Exception $e) {
    		$db->rollBack();
    		return false;
    	}
    }

    public function getBundleElectives($b_id) {
        return $this->fetchAll(array('linkable_id = ?' => $b_id, 'isElective = ?' => 1));
    }
    
    public function getBundleCourses($b_id) {
        return $this->fetchAll(array('linkable_id = ?' => $b_id, 'isElective = ?' => 0, 'status = ?' => 1, 'product_type = ?' => 'course', 'product_id <> ?' => 0));
    }
    
    
    public function getBundleCoursesIds($bundleIds) {
        $return = array();
        if(!$bundleIds) {
            return $return;
        }
        $objBundle = new self();
        foreach ($objBundle->fetchAll(array('linkable_id IN (?)'=>$bundleIds), array(), false) as $bundleData) {
            if(empty( $return[$bundleData['linkable_id']]))
                $return[$bundleData['linkable_id']] = array('courses'=>array());
             $return[$bundleData['linkable_id']]['courses'][$bundleData['product_id']] = $bundleData;
        }
        return $return;
    }
    

    public function saveBundleElectives($bid, $cid, $seq, $created_by) {
        $db = $this->getDb();
        $bElectivesObj = new self();
        $db->beginTransaction();
        $data = array(
            'linkable_id' => $bid,
            'product_id' => $cid,
            'seq' => $seq,
            'created_by' => $created_by,
            'isElective' => 1
        );
        try {
            $bElectivesObj->setFromArray($data)->save();
            $db->commit();
            return true;
        } catch (Exception $e) {
            $db->rollBack();
            return false;
        }
    }
    
    public function saveBundleCourses($data) {
    	$db = $this->getDb();
    	$mappingObj = new self();
    	$db->beginTransaction();
    	try {
    		if(!empty($data['id'])){
    			$mappingObj->setId($data['id']);
    			$mappingObj->setFromArray($data)->update();
    		} else
    			$mappingObj->setFromArray($data)->save();
    			 
    		$db->commit();
    		return true;
    	} catch (Exception $e) {
    		$db->rollBack();
    		return false;
    	}
    }

    public function fetchBundleCoursesAndElectives(array $bundleIds) {
        if (empty($bundleIds)) {
            return array();
        }

        $sql = $this->getDb()->select()
                ->from('courseMapping', array('courseMapping.linkable_id', 'courseMapping.product_id'))
                ->where('courseMapping.linkable_id IN (?)', $bundleIds)
                ->where('courseMapping.status =?', 1)
                ->where('courseMapping.product_id >?', 0);

        $courseData = $this->getDb()->fetchAll($sql, array(), PDO::FETCH_GROUP);
        if (empty($courseData)) {
            return array();
        }

        $preparedData = [];
        foreach ($courseData as $key => $item) {
            foreach ($item as $i) {
                if (empty($i['product_id'])) {
                    continue;
                }
                $preparedData[$key][] = $i['product_id'];
            }
        }
        return $preparedData;
    }
    
    
    public function fetchBundleCoursesAndElectivesMom(array $bundleIds) {
        if (empty($bundleIds)) {
            return array();
        }

        $sql = $this->getDb()->select()
                ->from('courseMapping', array('courseMapping.linkable_id', 'courseMapping.product_id'))
                ->where('courseMapping.linkable_id IN (?)', $bundleIds)
                ->where('courseMapping.status =?', 1)
                ->where('courseMapping.isElective = 0')
                ->where('courseMapping.product_type = ?', 'course')
                ->where('courseMapping.product_id >?', 0)
                ->order('courseMapping.product_id');

        $courseData = $this->getDb()->fetchAll($sql, array(), PDO::FETCH_GROUP);
        if (empty($courseData)) {
            return array();
        }

        $preparedData = [];
        foreach ($courseData as $key => $item) {
            foreach ($item as $i) {
                if (empty($i['product_id'])) {
                    continue;
                }
                $preparedData[] = $i['product_id'];
            }
        }
        $preparedData = !empty($preparedData) ?  array_unique($preparedData) : array();
        return $preparedData;
    }
    
        public function fetchMomCoursesAndElectives(array $mastersIds) {   
        $result = array();
        if (empty($mastersIds)) {
            return array();
        }
        $sql = $this->getDb()->select()
                ->from('courseMapping', array('courseMapping.linkable_id', 'courseMapping.product_id'))
                ->where('courseMapping.linkable_id IN (?)', $mastersIds)
                ->where('courseMapping.status =?', 1)
                ->where('courseMapping.product_id >?', 0)
                ->where('courseMapping.product_type = ?', 'bundle');

        $bundleData = $this->getDb()->fetchAll($sql, array(), PDO::FETCH_GROUP);
        if (empty($bundleData)) {
            return array();
        }
        if(!empty($bundleData)){
            foreach($bundleData as $master_id => $index){
                foreach($index as $key => $value){
                    if(!empty($value['product_id'])){
                    $result[$master_id][]=$value['product_id'];
                    }
                }
            }
        }
        if (empty($result)) {
            return array();
        }
     
        return $result;
    }

    /**
     * Method to fetch bundle list
     * @param array $bundleIds
     * @return array
     */
    public function getMultipleBundleCourses($bundleIds) {
        if (!(!empty($bundleIds) && is_array($bundleIds))) {
            return array();
        }
        return $this->fetchAll(array(
                    'linkable_id IN (?)' => $bundleIds,
                    'isElective = ?' => 0,
                    'status = ?' => 1,
                    'product_type = ?' => 'course',
                    'product_id <> ?' => 0));
    }
}
