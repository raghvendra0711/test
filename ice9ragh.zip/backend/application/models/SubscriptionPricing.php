<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Model_SubscriptionPricing extends BaseApp_Dao_SubscriptionPricing{

    public function savePricing($linkableId, $linkableType, $subscriptionPrice) {
        $db = $this->getDb();
        $objSubPrice = new self();
        $objCountry = new Model_Country();
        foreach ($subscriptionPrice as $indexId => $dataSave) {
            if (!empty($dataSave['country_id'])) {
                $priceExCountry = current($objSubPrice->getPricingByCountry($dataSave['country_id'], $linkableType, $dataSave['training_id'], $linkableId));
                if (!empty($priceExCountry) && $priceExCountry['free_trial'] == 1) {
                    $subscriptionPrice[$indexId]['free_trial'] = 1;
                }
                $countryData = $objCountry->getCountryDetailsById($dataSave['country_id']);
                if (!empty($countryData) && !empty($countryData['cluster_id'])) {
                    $priceExCluster = current($objSubPrice->getPricingByCluster($countryData['cluster_id'], $linkableType, $dataSave['training_id'], $linkableId));
                    if (!empty($priceExCluster) && $priceExCluster['free_trial'] == 1) {
                        $subscriptionPrice[$indexId]['free_trial'] = 1;
                    }
                }
            }
            if (!empty($dataSave['cluster_id'])) {
                $priceExCluster = current($objSubPrice->getPricingByCluster($dataSave['cluster_id'], $linkableType, $dataSave['training_id'], $linkableId));
                if (!empty($priceExCluster) && $priceExCluster['free_trial'] == 1) {
                    $subscriptionPrice[$indexId]['free_trial'] = 1;
                }
            }
            $subscriptionPrice[$indexId]['linkable_id'] = $linkableId;
            $subscriptionPrice[$indexId]['linkable_type'] = $linkableType;
        }
        $db->beginTransaction();
        try{
            $properties = $objSubPrice->fetchAll(array("linkable_id = ?" => $linkableId, 'linkable_type=?'=>$linkableType));
            
            $existingSub =  array_column($properties,'subscription_id');
            $newSub = array_column($subscriptionPrice,'subscriptionId');
            $sub = array_diff($existingSub,$newSub);
            
            foreach($properties as $property){
                foreach($sub as $del){
                    if($del == $property['subscription_id']){
                        //delete b2b side based oon 
                        $isCluster = true;
                        $cId = $property['cluster_id'];
                        if($property['cluster_id']==""){
                            $isCluster = false;
                            $cId = $property['country_id'];
                        }
                        $bundleTrainingId = $property['training_id'];                
                        $objB2bProduct = new Model_B2BProductPricing();
                        if(!$objB2bProduct->deleteProductPriceClusterCountryLevel($property['linkable_id'],$cId,$isCluster,'bundle',$bundleTrainingId)){
                            return false;
                        }  

                    }
                }
                
                
                
                $objSubPrice->clean();
                $objSubPrice->setId($property['subscription_id']);
                $objSubPrice->delete();
            }



            


            
            $objSubPrice->clean();
            $cleanPartPayment = false;
            foreach ($subscriptionPrice as $indexId => $dataSave) {
                $partPaymentData = array();
                unset($dataSave['subscriptionId']);
                if(isset($dataSave['part_payment']) && !empty($dataSave['part_payment'])){ 
                    $partPaymentData = $dataSave['part_payment'];
                    unset($dataSave['part_payment']); 
                }
                $objSubPrice->setFromArray($dataSave)->save();
                
                if(!empty($partPaymentData)){
                    $installment_number = 0;
                    foreach($partPaymentData as $oldSubscriptionId=>$partPaymentArr){
                        //Delete previous Subscription Data
                        $partPaymentModel = new Model_PartPaymentBreakups();
                        $partPaymentModel->deleteBreakup($oldSubscriptionId);
                        //Add new Data
                        foreach($partPaymentArr as $partPaymentInfo){
                            if($partPaymentInfo['amount'] > 0){
                                $installment_number++;
                                $insertPartData = array();
                                $insertPartData['subscription_id'] = $objSubPrice->subscription_id;
                                $insertPartData['installment_number'] = $installment_number;
                                $insertPartData['installment_text'] = $partPaymentInfo['text'];
                                $insertPartData['installment_amount'] = $partPaymentInfo['amount'];
                                $partPaymentModel->saveBreakup($insertPartData);
                            }
                        }
                    }
                }else if(!$cleanPartPayment){
                    $cleanPartPayment = true;
                    foreach($properties as $property){
                        $partPaymentModel = new Model_PartPaymentBreakups();
                        $partPaymentModel->deleteBreakup($property['subscription_id']);
                    }
                }
            }
            $db->commit();
            return true;
        }
        catch (Exception $e){
            $db->rollBack();
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }

    public function getByLinkable($linkableId, $linkableType, $pricingType=false) {
        $conds = array(
            'linkable_id = ?' => $linkableId,
            'linkable_type=?'=>$linkableType
        );
        $options = array(
            'order' => array(
                array('subscription_id', 'country_id')
            )
        );
        if($pricingType == 'bundle') {
            $conds['frequency_id = ?'] = 0;
        }
        elseif($pricingType == 'subscription') {
            $conds['frequency_id > ?'] = 0;
        }
        return $this->fetchAll($conds, $options);
    }

    public function getPricingByCountry($countryId, $linkableType, $trainingId, $linkableId = '', $free_trial='') {
        $conds = array(
            'linkable_type=?'=>$linkableType,
            'country_id =?' => $countryId,
            'frequency_id =?' => 0,
            'training_id =?'=> intval($trainingId),
            'status =?' => 1,
        );
        if(!empty($linkableId)) {
            $conds['linkable_id = ?'] = $linkableId;
        }
        if (!empty($free_trial)) {
            $conds['free_trial =?'] = 1;
        }

        return $this->fetchAll($conds);
    }



    public function getPricingByBundleIds($isClusterOrCountry, $countryOrClusterId, $bundleIds = array())
    {
        if ($isClusterOrCountry == BaseApp_Dao_Country::TYPE_CLUSTER) {
            $conds = array(
                "cluster_id=?" => $countryOrClusterId
            );
        }
        else if ($isClusterOrCountry == BaseApp_Dao_Country::TYPE_COUNTRY) {
            $conds = array(
                'country_id =?' => $countryOrClusterId
            );
        }
        if (!empty($bundleIds)) {
            $conds['linkable_id IN (?)'] = $bundleIds;
        }
        
        $data = $this->fetchAll($conds);

        if(!empty($data)){
            $data = array_column($data,'linkable_id');
        }

        else {
            if ($isClusterOrCountry == BaseApp_Dao_Country::TYPE_COUNTRY) {

                $bundle = new Model_Courses();
                $clusterIdBasedOnCountryId = $bundle->getClusterId($countryOrClusterId);

                $conds = array(
                    'cluster_id=?'=> $clusterIdBasedOnCountryId 
                );

            }
            if(!empty($bundleIds)) {
                $conds['linkable_id IN (?)'] = $bundleIds;
            }

            $data = $this->fetchAll($conds);
            if(!empty($data)){
                $data = array_column($data,'linkable_id');
            }           
        }
        return $data;
}

    public function getPricingByCluster($clusterId, $linkableType, $trainingId, $linkableId='', $free_trial='') {
        $conds = array(
            'linkable_type=?'=>$linkableType,
            'cluster_id =?' => $clusterId,
            'frequency_id =?' => 0,
            'training_id =?'=> intval($trainingId),
            'status =?' => 1,
        );
        if(!empty($linkableId)) {
            $conds['linkable_id = ?'] = $linkableId;
        }
        if (!empty($free_trial)) {
            $conds['free_trial =?'] = 1;
        }

        return $this->fetchAll($conds);
    }

    public function enableMPFreeTrial($pricingId) {
        $db = $this->getDb();
        $objPricing = new self();
        $dataUpdate = array(
            'free_trial' => 1,
        );
        $db->beginTransaction();
        try{
            $objPricing->clean();
            $objPricing->setId($pricingId);
            if($objPricing->setFromArray($dataUpdate)->update()) {
                $db->commit();
                return true;
            }
            else {
                $db->rollBack();
                return false;
            }
        }catch (Exception $e){
            $db->rollBack();
            throw $e;
            return false;
        }
    }

    public function disableFreeTrial($data) {
        $pricingData = array();
        if (!empty($data['country_id'])) {
            $pricingData = $this->getPricingByCountry($data['country_id'],BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES, BaseApp_Dao_TrainingTypes::TYPE_ELEARNING,'',1);
        } else if (!empty($data['cluster_id'])) {
            $pricingData = $this->getPricingByCluster($data['cluster_id'],BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES, BaseApp_Dao_TrainingTypes::TYPE_ELEARNING,'',1);
        }
        $db = $this->getDb();
        $dataUpdate = array(
            'free_trial' => 0,
        );
        try{
            if (!empty($pricingData)) {
                foreach ($pricingData as $key => $value) {
                    if (!empty($value['subscription_id'])) {
                        $pricingId = $value['subscription_id'];
                        $objPricing = new self();
                        $db->beginTransaction();

                        $objPricing->clean();
                        $objPricing->setId($pricingId);
                        if($objPricing->setFromArray($dataUpdate)->update()) {
                            $db->commit();
                        }
                        else {
                            $db->rollBack();
                            return false;
                        }
                    }
                }
            }
            return true;
        } catch (Exception $e){
            $db->rollBack();
            throw $e;
            return false;
        }
    }

    public function getDiscountedPrice($price, $discount){
        return $price -($price * ($discount / 100));
    }

    public function _afterFetchAll($data) {
        $accessDaysAll = array();
        $trainings = array();
        $countries = array();
        $clusters = array();
        $currencies = array(
            'country' => array(),
            'cluster' => array()
        );

        foreach($data as $row) {
            if($row['country_id']) {
                $countries[] = $row['country_id'];
            }
            if($row['cluster_id']) {
                $clusters[] = $row['cluster_id'];
            }
        }

        $accessDaysObj = new Model_AccessDays();
        $accessDaysAll = $accessDaysObj->getAccessDaysById();

        $modelTraining = new Model_TrainingTypes();
        $trainings = $modelTraining->getTrainingTypes();

        if($countries) {
            $country = new Model_Country();
            $currencies['country'] = $country->getCurrencies($countries);
            $countries = $country->getById($countries);
        }

        if($clusters) {
            $cluster = new Model_Clusters();
            $currencies['cluster'] = $cluster->getCurrencies($clusters);
            $clusters = $cluster->getListDisplay($clusters);
        }

        $frequency = new Model_PricingFrequency();
        $frequencyData = $frequency->getByFrequencyId();

        foreach($data as &$row) {
            $row['Price Frequency'] = @$frequencyData[$row['frequency_id']]['displayName'];
            if($row['country_id']) {
                $row['Country'] = @$countries[$row['country_id']];
                $row['Currency'] = @$currencies['country'][$row['country_id']];
            }
            if($row['cluster_id']) {
                $row['Cluster'] = @$clusters[$row['cluster_id']];
                $row['Currency'] = @$currencies['cluster'][$row['cluster_id']];
            }
            if($row['training_id']) {
                $row['TrainingType'] = $trainings[$row['training_id']];
            }
            if($row['access_day_id']) {
                $row['AccessDays'] = @$accessDaysAll[$row['access_day_id']];
            }

            $row['discountedPrice'] = $this->getDiscountedPrice($row['subscriptionPrice'], $row['discountValue']);
        }
        return $data;
    }

    public function deleteByLinkable($linkableId, $linkableType) {
        $objPrice = new self();
        $conds = array(
            'linkable_id=?' => $linkableId,
            'linkable_type=?' => $linkableType
        );
        $opts = array(
            'columns' => ['subscription_id','country_id','cluster_id','linkable_type','linkable_id'],            
        );

        foreach($objPrice->fetchAll($conds, $opts, false) as $priceData) {
            
            $objPrice->clean();
            $objPrice->setId($priceData['subscription_id']);
            if(!$objPrice->delete()) {
                return false;
            }
        }
        return true;
    }

} // End of Class