<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_Vendors extends BaseApp_Dao_Vendors{

    public function createVendor($dataSave,$splitData){
        $db = $this->getDb();
        $objVendor = new self();
        $pageUrl = '';
        $db->beginTransaction();
        try{
            
            $accreditorArr = $dataSave['accreditor_id'];
            unset($dataSave['accreditor_id']);
            if(isset($dataSave['url'])) {
                $pageUrl = trim($dataSave['url']);
                $checkSlash = substr($pageUrl, 0,1);
                if($checkSlash != '/'){
                    $pageUrl = trim('/'.$pageUrl);
                }
                $objVendor->setPageUrl($pageUrl);
                unset($dataSave['url']);
            }

            $objVendor->setFromArray($dataSave)->save();
            $vendorId = $objVendor->vendor_id;
            $dataSave = array(
                'controller' => self::SEO_DEFAULT_CONTROLLER,
                'action' => self::SEO_DEFAULT_ACTION,
                'params' => json_encode(array(self::SEO_DEFAULT_PARAM_KEY=>$vendorId)),
                'linkable_id' => $vendorId,
                'linkable_type' => 'vendor'
            );
            $modelSeo = new Model_Seo();
            $seoData = $modelSeo->getDataByUrl($pageUrl);
            $modelSeo->setId($seoData['seo_id']);
            $modelSeo->setFromArray($dataSave)->update();

            /* Store Accreditor in AccMapping Table */

            if (!empty($accreditorArr)) {
                $accreditorMappingObj = new Model_AccreditorMapping();
                foreach ($accreditorArr as $accreditorId) {
                    $accreditorRow = array();
                    $accreditorRow['accreditor_id']= $accreditorId;
                    $accreditorRow['linkable_type'] = 'vendor';
                    $accreditorRow['linkable_id'] = $vendorId;
                    $accreditorMappingObj->setFromArray($accreditorRow)->save();
                }
            }

            /* Store Accreditor in AccMapping Table */

            /* Store Image in Image Table */

            $image = new Model_Images();
            $image->saveBannerOfferImages($vendorId, 'vendor', $splitData);

            /* Store Image in Image Table */

            /* store Course Advisor,Alumni ,Company Mappings */

            $objSectionMapping = new Model_SectionMapping();
            $sectionMappingArr = array();
            if(isset($splitData['section_id_arr'])){
                $sectionMappingArr = $splitData['section_id_arr'];   
                if(!empty($sectionMappingArr)){
                    $sectionMappingArr = call_user_func_array('array_merge', $sectionMappingArr);
                    $objSectionMapping->saveProductSectionData($vendorId,'vendor',$sectionMappingArr);
                }
            }

            /* store Course Advisor,Alumni ,Company Mappings */
            
            /* store Vendor intro video */
            if(!empty($splitData['video_data'])){
                $videoVals = $splitData['video_data'];
                $objVideos = new Model_Videos();
                $videosArr = array(
                    'linkable_id'=>$vendorId,
                    'linkable_type'=>'vendor',
                    'name'=>'about_vendor',
                    'videoLink'=>$videoVals['videoLink'],
                    'thumbnailImage'=>$videoVals['videoThumbnail']
                );
                if(isset($videoVals['videoDescription']) && $videoVals['videoDescription']){
                    $videosArr['shortDescription'] = $videoVals['videoDescription'];
                }
                if (isset($videoVals['dateCreated']) && $videoVals['dateCreated']) {
                    $videosArr['dateCreated'] = $videoVals['dateCreated'];
                }
                if (isset($videoVals['displayName']) && $videoVals['displayName']) {
                    $videosArr['displayName'] = $videoVals['displayName'];
                }
                if (isset($videoVals['duration']) && $videoVals['duration']) {
                    $videosArr['duration'] = $videoVals['duration'];
                }
                $objVideos->clean();
                $resultInsert = $objVideos->setFromArray($videosArr)->save();
                $this->_saveVideoSeo($objVideos->video_id, $vendorId, $videoVals['videoThumbnail']);
            }
            
            /* store Vendor intro video */
            $db->commit();
            return $vendorId;
        }
        catch (Exception $e){
            $db->rollBack();
            return false;
        }
    }


    public function updateVendor($Id,$dataSave,$splitData){
        $db = $this->getDb();
        $objVendor = new self();
        $pageUrl = '';
        $db->beginTransaction();
        try{
            
            $accreditorArr = $dataSave['accreditor_id'];
            unset($dataSave['accreditor_id']);
            
            $objVendor->setId($Id);
            $objVendor->setFromArray($dataSave)->update();

            /* Store Accreditor in AccMapping Table */

            $accreditorMappingObj = new Model_AccreditorMapping();
            $conds = array(
                'linkable_id=?' => $Id,
                'linkable_type=?' => 'vendor',
            );

            $courseAccreditorArr = $accreditorMappingObj->fetchAll($conds);
            // delete
            if(!empty($courseAccreditorArr)) {
                foreach($courseAccreditorArr as $courseAccreditorRow){
                    $accreditorMappingObj->clean();
                    $accreditorMappingObj->setId($courseAccreditorRow['id']);
                    $accreditorMappingObj->delete();
                }
            }

            // add
            if (!empty($accreditorArr)) {
                $accreditorMappingObj->clean();
                foreach ($accreditorArr as $accreditorId) {
                    $accreditorRow = array();
                    $accreditorRow['accreditor_id']= $accreditorId;
                    $accreditorRow['linkable_type'] = 'vendor';
                    $accreditorRow['linkable_id'] = $Id;
                    $accreditorMappingObj->setFromArray($accreditorRow)->save();
                }
            }

            /* Store Accreditor in AccMapping Table */

            /* Store Image in Image Table */

            $image = new Model_Images();
            $image->saveBannerOfferImages($Id, 'vendor', $splitData);

            /* Store Image in Image Table */

            /* store Course Advisor,Alumni ,Company Mappings */

            $objSectionMapping = new Model_SectionMapping();
            $sectionMappingArr = array();
            if(isset($splitData['section_id_arr'])){
                $sectionMappingArr = $splitData['section_id_arr'];   
                if(!empty($sectionMappingArr))
                    $sectionMappingArr = call_user_func_array('array_merge', $sectionMappingArr);
                $objSectionMapping->saveProductSectionData($Id,'vendor',$sectionMappingArr);
            }

            /* store Course Advisor,Alumni ,Company Mappings */
            
            /* store Vendor intro video */
            
            if(!empty($splitData['video_data'])){
                $videoVals = $splitData['video_data'];
                $objVideos = new Model_Videos();
                $videosArr = array(
                    'linkable_id'=>$Id,
                    'linkable_type'=>'vendor',
                    'name'=>'about_vendor',
                    'videoLink'=>$videoVals['videoLink'],
                    'thumbnailImage'=>$videoVals['videoThumbnail']
                );
                if(isset($videoVals['videoDescription']) && $videoVals['videoDescription']){
                    $videosArr['shortDescription'] = $videoVals['videoDescription'];
                }
                if (isset($videoVals['dateCreated']) && $videoVals['dateCreated']) {
                    $videosArr['dateCreated'] = $videoVals['dateCreated'];
                }
                if (isset($videoVals['displayName']) && $videoVals['displayName']) {
                    $videosArr['displayName'] = $videoVals['displayName'];
                }
                if (isset($videoVals['duration']) && $videoVals['duration']) {
                    $videosArr['duration'] = $videoVals['duration'];
                }
                if($videoExists = $objVideos->getByLinkableId($Id,'vendor', false, 'about_vendor')) {
                    $videosArr['video_id'] = $videoExists['video_id'];
                    $objVideos->clean();
                    $objVideos->setId($videosArr['video_id']);
                    $resultUpdate = $objVideos->setFromArray($videosArr)->update();
                    $this->_saveVideoSeo($videosArr['video_id'], $Id, $videoVals['videoThumbnail']);
                }else {
                    $objVideos->clean();
                    $resultInsert = $objVideos->setFromArray($videosArr)->save();
                    if($resultInsert)
                        $this->_saveVideoSeo($objVideos->video_id, $Id, $videoVals['videoThumbnail']);
                }
            }else{
                $objVideos = new Model_Videos();
                if($videoExists = $objVideos->getByLinkableId($Id,'vendor', false, 'about_vendor')) {
                    $videosArr['video_id'] = $videoExists['video_id'];
                    $objVideos->clean();
                    $objVideos->setId($videosArr['video_id']);
                    $resultUpdate = $objVideos->setFromArray(array('status'=>0))->update();
                    $this->_saveVideoSeo($videosArr['video_id'], $dataSave['label_id'], $videoVals['videoThumbnail']);
                }
            }
            
            /* store Vendor intro video */
            $db->commit();
            return true;
        }
        catch (Exception $e){
            pr($e->getMessage());
            $db->rollBack();
            return false;
        }
    }

    private function _saveVideoSeo($videoId, $vendorId, $thumbIMage) {
        $return = false;
        $seoMd = new Model_Seo();
        $conds = array(
                'controller=?' => Model_Videos::SEO_DEFAULT_CONTROLLER,
                'action=?' => Model_Videos::SEO_DEFAULT_ACTION,
                'linkable_id=?' => $videoId,
                'linkable_type=?' => 'video'
        );
        if($seoData = current($seoMd->fetchAll($conds, array(), false))) {
            $dataSave = array(
                    'thumb_image' => $thumbIMage
            );
            $seoMd->clean();
            $seoMd->setId($seoData['seo_id']);
            $seoMd->setFromArray($dataSave)->update();
            $return = true;
        }
        else {
            $dataSave = array(
                    'thumb_image' => $thumbIMage,
                    'controller' => Model_Videos::SEO_DEFAULT_CONTROLLER,
                    'action' => Model_Videos::SEO_DEFAULT_ACTION,
                    'params' => json_encode(array(Model_Videos::SEO_DEFAULT_PARAM_KEY=>$videoId,Model_Labels::SEO_DEFAULT_PARAM_KEY=>$vendorId)),
                    'linkable_id' => $videoId,
                    'linkable_type' => 'video'
            );
            $return = $seoMd->setFromArray($dataSave)->save();
        }
        return $return;
    }
    
} // End of Class