<?php

class Model_MongoDbWrapperFrs {

    protected $_db = null;
    protected $_columns = array();
    protected $collectionName;
    protected $_cacheNameSpace = '';
    protected $_valueTypesCompressed = array();
    protected $_valueTypesUnCompressed = array();
    protected $_columnsTypes = array();

    public function __construct() {
        $this->_db = new Model_DefaultFrs();
        $collectionName = $this->collectionName;
        $this->collection = $this->_db->$collectionName;
        $this->_cacheNameSpace = $this->getCacheNamespace();
        if (count($this->_valueTypesCompressed) != count(array_unique($this->_valueTypesCompressed))) {
            pr('issue in compressed array');
        }
        $this->_valueTypesUnCompressed = array_flip($this->_valueTypesCompressed);
    }

    protected function getCacheNamespace() {
        $nameSpaceKey = 'cacheNamespace_mongo_' . $this->collectionName . $this->_generateCacheNamespaceValue();
        return $nameSpaceKey;
    }

    protected function _generateCacheNamespaceValue() {
        $cacheNamespaceValue = cache_fetch('cacheNamespace_mongo_' . $this->collectionName);
        if (!$cacheNamespaceValue) {
            $cacheNamespaceValue = $this->_cacheNamespaceRegenerate();
        }
        return $cacheNamespaceValue;
    }

    protected function _cacheNamespaceRegenerate() {
        $cacheNamespaceKey = 'cacheNamespace_mongo_';
        $cacheNamespaceKey .= $this->collectionName;
        $oldCacheNamespace = cache_fetch($cacheNamespaceKey);
        $cacheNamespace = rand(9999, 99999);
        if ($oldCacheNamespace) { //avoid collision
            while ($oldCacheNamespace == $cacheNamespace) {
                $cacheNamespace = rand(9999, 99999);
            }
        }
        if (cache_store($cacheNamespaceKey, $cacheNamespace)) {
            $this->_cacheNameSpace = 'cacheNamespace_mongo_' . $this->collectionName . $cacheNamespace;
        }
        return $cacheNamespace;
    }

    public function recursiveEncode($array) {
        $return = array();
        $this->recursiveRenamingOfKeys($array, $return, $this->_valueTypesCompressed);
        return $return;
    }

    public function recursiveDecode($array) {
        $return = array();
        $this->recursiveRenamingOfKeys($array, $return, $this->_valueTypesUnCompressed);
        return $return;
    }

    private function recursiveRenamingOfKeys($array, &$return, $checkWith) {
        foreach ($array as $key => $temp) {
            if ($key === '_id') {
                continue;
            }
            if (is_array($temp)) {
                $tempReturn = array();
                $this->recursiveRenamingOfKeys($temp, $tempReturn, $checkWith);
            } else {
                $tempReturn = $temp;
            }
            if (is_numeric($key)) {
                $insertKey = $key;
            } else {
                if (!isset($checkWith[$key])) {
                    pr($array);
                    pr('issue with missing key ' . $key);
                }
                $insertKey = $checkWith[$key];
            }
            $return[$insertKey] = $tempReturn;
        }
        return $return;
    }

    protected function makeCacheKey() {
        $args = func_get_args();
        $cacheString = $this->_cacheNameSpace;
        foreach ($args as $temp) {
            $cacheString .= serialize($temp);
        }
        return md5($cacheString);
    }

}
