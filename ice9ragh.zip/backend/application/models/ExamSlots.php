<?php
/**
 * @author Akash Agarwal <akash.agarwal@simplilearn.net>
 */
class Model_ExamSlots extends BaseApp_Dao_ExamSlots
{
    protected function _beforeSave() {
        if(!self::checkSlotAddExists($this->_data))
        { 
            $loggedInUserData = BaseApp_Auth::getLoggedInUserData();
            $this->_data['city_id'] = $this->_data['exam_slot_city_id'];
            $this->_data['exam_slot'] = $this->_data['start_time'] . '-' . $this->_data['end_time'];
            $this->_data['exam_start_time']= strtotime($this->_data['exam_date'].' '.$this->_data['start_time']);
            $this->_data['exam_end_time']= strtotime($this->_data['exam_date'].' '.$this->_data['end_time']);
            $this->_data['updated_by'] = $this->_data['created_by'] = $loggedInUserData['id'];
            $this->_data['created_on'] = $this->_data['updated_on'] = time();
            unset($this->_data['start_time'], $this->_data['end_time'],$this->_data['country_id'],$this->_data['exam_slot_city_id']);
            return true;
        }
        return false;
    }
    
    protected function _beforeDelete() {
        $loggedInUserData = BaseApp_Auth::getLoggedInUserData();
        $this->_data['updated_by'] = $loggedInUserData['id'];
        $this->_data['updated_on'] = time();
        return true;
    }

    /**
     * Not deleting the following function,
     * as the product may require to provide update feature in future.
     */
//     protected function _beforeUpdate() {
//         if(!self::checkSlotUpdateExists($this->_data, $this->_id))
//        {
//            $loggedInUserData = BaseApp_Auth::getLoggedInUserData();
//            $this->_data['exam_slot'] = $this->_data['start_time'] . '-' . $this->_data['end_time'];
//            $this->_data['exam_start_time']= strtotime($this->_data['exam_date'].' '.$this->_data['start_time']);
//            $this->_data['exam_end_time']= strtotime($this->_data['exam_date'].' '.$this->_data['end_time']);
//            $this->_data['updated_by'] = $loggedInUserData['id'];
//            $this->_data['updated_on'] = time();
//            unset($this->_data['start_time'], $this->_data['end_time'], $this->_data['country_id']);
//            return true;
//        }
//        return false;
//    }
    
    
    /**
     * @param array $itemData
     * @return boolean
     */
    public static function checkSlotAddExists(array $itemData)
    {
        $examslotMdl = new Model_ExamSlots();
        
        $itemData['start_time']= strtotime($itemData['exam_date'].' '.$itemData['start_time']);
        $itemData['end_time']= strtotime($itemData['exam_date'].' '.$itemData['end_time']);
        
        
        $fetchCnt=$examslotMdl->fetchCount(array('exam_id=?'=>$itemData['exam_id'],
                                'city_id=?'=>$itemData['exam_slot_city_id'],
                                'exam_venue_id =?'=>$itemData['exam_venue_id'],
                                'exam_date=?'=> $itemData['exam_date'],
                                "(exam_start_time<=".$itemData['start_time']." and exam_end_time>=".$itemData['start_time'].") or ".
				"(exam_start_time<=".$itemData['end_time']." and exam_end_time>=".$itemData['end_time'].")"=>''
                                ));
        
        if($fetchCnt){
            return true;
        }
        return false;
    }
    
    public static function checkSlotUpdateExists(array $itemData,$id)
    {
        $examslotMdl = new Model_ExamSlots();
        
        $itemData['start_time']= strtotime($itemData['exam_date'].' '.$itemData['start_time']);
        $itemData['end_time']= strtotime($itemData['exam_date'].' '.$itemData['end_time']);
        
        $fetchCnt=$examslotMdl->fetchCount(array('exam_id=?'=>$itemData['exam_id'],
                                'slot_id!=?'=>$id,
                                'city_id=?'=>$itemData['exam_slot_city_id'],
                                'exam_venue_id =?'=>$itemData['exam_venue_id'],
                                'exam_date=?'=> $itemData['exam_date'],
                                "(exam_start_time<=".$itemData['start_time']." and exam_end_time>=".$itemData['start_time'].") or ".
				"(exam_start_time<=".$itemData['end_time']." and exam_end_time>=".$itemData['end_time'].")"=>''
                                ));
        
        if($fetchCnt){
            return true;
        }
        return false;
    }
    
    /**
     * @param array $itemData
     * @return array
     */
    /*public function addSlotItem(array $itemData)
    {
        $slotData = [];
        $mandatoryFields = ['course_id', 'country_id', 'city_id', 'exam_date', 'exam_slot', 'created_by'];
        foreach ($mandatoryFields as $mandatoryField) {
            if (!array_key_exists($mandatoryField, $itemData)) {
                return ['status' => false, 'msg' => "{$mandatoryField} is missing"];
            } else if (empty($itemData[$mandatoryField])) {
                return ['status' => false, 'msg' => "{$mandatoryField} is empty"];
            }

            $slotData[$mandatoryField] = $itemData[$mandatoryField];
        }

        $slotData['updated_by'] = $slotData['created_by'];
        $slotData['created_on'] = $slotData['updated_on'] = time();

        if (!$this->setFromArray($slotData)->save()) {
            return ['status' => false, 'msg' => 'Failed to save slot item.'];
        }

        return ['status' => true, 'msg' => 'Successfully inserted, want to add more', 'id' => $this->getDb()->lastInsertId()];
    }
    */
    /**
     * @param int $slotId
     * @param array $itemData
     * @return array
     */
    /*public function updateSlotItem($slotId, array $itemData)
    {
        $slotData = [];
        $mandatoryFields = ['exam_date', 'exam_slot', 'updated_by'];
        foreach ($mandatoryFields as $mandatoryField) {
            if (!array_key_exists($mandatoryField, $itemData)) {
                return ['status' => false, 'msg' => "{$mandatoryField} is missing"];
            } else if (empty($itemData[$mandatoryField])) {
                return ['status' => false, 'msg' => "{$mandatoryField} is empty"];
            }

            $slotData[$mandatoryField] = $itemData[$mandatoryField];
        }

        $slotData['updated_on'] = time();

        $this->setId($slotId);
        if (!$this->setFromArray($slotData)->update()) {
            return ['status' => false, 'msg' => 'Failed to update slot item.'];
        }

        return ['status' => true, 'msg' => 'Updated successfully'];

    }
    */
    /**
     * @param int $id
     * @return array
     */
    /*
    public function deleteSlotItem($id)
    {
        $this->setId($id);
        if (!$this->delete()) {
            return ['status' => false, 'msg' => 'Failed to delete slot item.'];
        }

        return ['status' => true, 'msg' => 'Deleted successfully'];
    }
    */
    /**
     * @param int $courseId
     * @return array
     */
    /*
    public function getSlotItemsOnCourseId($courseId)
    {
        return $this->fetchAll(array('course_id' => $courseId));
    }
    */
    /**
     * @param int $slotId
     * @return array
     */
    /*
    public function getOnSlotId($slotId)
    {
        $slot = $this->fetchAll(array('slot_id' => $slotId));
        if (empty($slot)) {
            return [];
        }

        return current($slot);
    }
     */
    public function fetchExamNameFromSlot($slotId = 0) {
        if (empty($slotId)) {
            return "";
        }
        $sql = $this->getDb()->select()
                ->from(array('es' => 'examSlots'), array())
                ->join(array('ed' => 'exam_details'), 'es.exam_id = ed.id', array('ed.name'))
                ->where('es.status=?', 1)
                ->where('es.slot_id=?', $slotId)
//                ->where('ed.status = ?', 1)
        ;
        $result = $this->getDb()->fetchOne($sql);
        return $result;
    }

    public function fetchFutureSlotCountHavingVenue($venueId=0){
        if(empty($venueId)){
            return 0;
        }
        $fetchCnt = $this->fetchCount(array('exam_venue_id=?' => $venueId,
                                        'exam_start_time >=?' => time()
                                    ));
        return $fetchCnt;
    }

}