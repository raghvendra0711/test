<?php

class Model_ApplicationSectionData extends BaseApp_Dao_ApplicationSectionData
{
    const ID = 'id';
    const LINKABLE_ID = 'linkable_id';
    const LINKABLE_TYPE = 'linkable_TYPE';
    const TYPE = 'type';
    const INTRO = 'intro';
    const FIRST_SEC_TITLE = 'first_sec_title';
    const SECOND_SEC_TITLE = 'second_sec_title';
    const DETAILS1 = 'details1';
    const DETAILS2 = 'details2';
    // const DETAILS3 = 'details3';
    const STATUS = 'status';

    public function manageApplicationSectionData($data,$linkableId,$linkableType)
    {   
        // prd($data,$productSectionDataId);
        if (empty($data)) {
            throw new BaseApp_Exception('Invalid Data');
        }
        if (empty($linkableId)) {
            throw new BaseApp_Exception('Invalid linkableId');
        }
        if (empty($linkableType)) {
            throw new BaseApp_Exception('Invalid linkableType');
        }
        $objAppSecData = new self();
        $db = $this->getDb();
        $db->beginTransaction();
        $response = array();

        try {
            if (!empty($data)) {
                foreach ($data as $key => $value) {
                    $id = $value[self::ID];
                    $type = $key;
                    
                    $dataArr[self::INTRO] = !empty($value[self::INTRO]) ? $value[self::INTRO] : null;
                    $dataArr[self::FIRST_SEC_TITLE] = !empty($value[self::FIRST_SEC_TITLE]) ? $value[self::FIRST_SEC_TITLE] : null;
                    $dataArr[self::SECOND_SEC_TITLE] = !empty($value[self::SECOND_SEC_TITLE]) ? $value[self::SECOND_SEC_TITLE] : null;
                    $dataArr[self::DETAILS1] = !empty($value[self::DETAILS1]) ? $value[self::DETAILS1] : null;
                    $dataArr[self::DETAILS2] = !empty($value[self::DETAILS2]) ? $value[self::DETAILS2] : null;
                    // $dataArr[self::DETAILS3] = !empty($value[self::DETAILS3]) ? $value[self::DETAILS3] : null;
                    // $existingData = $objAppSecData->checkAlreadyExits($linkableId,$type);
                    if(!empty($id)){
                        $objAppSecData->clean();
                        $objAppSecData->setId($id);
                        $objAppSecData->setFromArray($dataArr)->update();
                    } else {
                        $dataArr[self::LINKABLE_ID] = $linkableId;
                        $dataArr[self::LINKABLE_TYPE] = $linkableType;
                        $dataArr[self::TYPE] = $type;
                        $res = $objAppSecData->setFromArray($dataArr)->save();
                    }
                }
            }
            $db->commit();
            return true;
            return $response;
        } catch (Exception $e) {
            $db->rollBack();
            if (APPLICATION_ENV == 'development')
                throw $e;

            return false;
        }
    }

    private function checkAlreadyExits($productSectionDataId,$type){
        if(empty($productSectionDataId) || empty($type)){
            throw new BaseApp_Exception('Invalid Data');
        }
        try {
            $conds = array('productSectionDataId = ?' => $productSectionDataId,'type=?' => $type);
            $result = $this->fetchAll($conds);
            return $result;
        } catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;

            return false;
        }
    }
} // End of Class
