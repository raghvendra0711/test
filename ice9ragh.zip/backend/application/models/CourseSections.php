<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Model_CourseSections extends BaseApp_Dao_CourseSections
{

    public function getCourseSection($courseId)
    {
        $objCourse = new self();
        $cond = array(
            'course_id = ?' => $courseId,
            'sticky_status =?' => 0
        );
        $options = array(
            'columns' => array(
                'name',
                'menuItem',
                'section_id',
                'training_id',
                'course_section_id'
            ),
            'order' => array(
                array(
                    'training_id ASC',
                    'orderNo ASC'
                )
            )
        );
        $sectionTemplates = $objCourse->fetchAll($cond, $options);
        return $sectionTemplates;
    }


    public function getCourseSectionToShow($courseId, $trainingInclude = array(), $returnDefault = false)
    {
        $isNew = true;
        $trainingModel = new Model_TrainingTypes();
        $trainingData = $trainingModel->getInclusionTrainingTypes();
        foreach ($trainingData as $Id => $name) {
            if ($Id == 0 || in_array($Id, $trainingInclude)) {
                $returnData[$name] = array();
            }
        }
        $courseSections = $this->getCourseSection($courseId);
        foreach ($courseSections as $insexTemp => $dataReal) {
            if ($dataReal['training_id'] == 0 || in_array($dataReal['training_id'], $trainingInclude)) {
                $isNew = false;
                $returnData[$trainingData[$dataReal['training_id']]][] = $dataReal;
            }
        }

        if ($isNew && $returnDefault) {
            // Generate default template for new courses
            $sectionTemplateModel = new BaseApp_Dao_SectionTemplates();
            $cond = array('status = ?' => 1, 'sticky_status = ?' => 0);
            $sections = $sectionTemplateModel->fetchAll($cond);
            foreach ($trainingData as $Id => $name) {
                if ($Id == 0 || in_array($Id, $trainingInclude)) {
                    $returnData[$name] = array();
                    // add allowed sections
                    foreach ($sections as $section) {
                        $allowedTrainingIds = explode(',', isset($section['allowed_training_ids']) ? $section['allowed_training_ids'] : '');
                        if (in_array($Id, $allowedTrainingIds)) {
                            $sectionData = $section;
                            $sectionData['training_id'] = $Id;
                            $returnData[$name][] = $sectionData;
                        }
                    }
                }
            }
        }
        return $returnData;
    }

    public function getById($courseSectionId)
    {
        return current($this->fetchAll(array('course_section_id=?' => $courseSectionId)));
    }

    public function getSectionByCourseIdSectionId($courseId, $sectionId)
    {
        return current($this->fetchAll(array('course_id=?' => $courseId, 'section_id=?' => $sectionId)));
    }
} // End of Class
