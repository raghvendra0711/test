<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_TrainingRelations extends BaseApp_Dao_TrainingRelations {	

    public function createRelation($linkable_id, $linkable_type, $trainingData) {  
        $db = $this->getDb();
        $objRelation = new self();
        $db->beginTransaction();
        try{
            
            $properties = $objRelation->fetchAll(array('linkable_id=?'=>$linkable_id,'linkable_type=?'=>$linkable_type));
            foreach($properties as $property){
                $objRelation->clean();
                $objRelation->setId($property['training_relation_id']);
                $objRelation->delete();
            }     
            $objRelation->clean();            
            
            $traingType = new Model_TrainingTypes();
            $trainingTypeIds = $traingType->loadAll();
            foreach($trainingTypeIds as $trainingTypeId => $trainingTypeData) {
                $data = array(
                    'training_id' => $trainingTypeData['training_id'],
                    'linkable_id' => $linkable_id,
                    'linkable_type' => $linkable_type
                );
                if(!isset($trainingData[$trainingTypeData['type'].$trainingTypeId])) {
                    continue;
                }                
                switch($trainingTypeData['type'].$trainingTypeId) {
                    case 'osl'.BaseApp_Dao_TrainingTypes::TYPE_ELEARNING:
                        $data['accessDays'] = $trainingData['oslAccessDays'];
                        break;
                    case 'ilt'.BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM:
                        $data['accessDays'] = $trainingData['classRoomAccessDays'];
                        $data['fromDate'] = isset($trainingData['classRoomFromDate']) ? strtotime($trainingData['classRoomFromDate']) : null;
                        $data['toDate'] = isset($trainingData['classRoomToDate']) ? strtotime($trainingData['classRoomToDate']) : null;
                        break;
                    case 'ilt'.BaseApp_Dao_TrainingTypes::TYPE_LVC:
                        $data['accessDays'] = $trainingData['iloAccessDays'];
                        $data['fromDate'] = isset($trainingData['iloFromDate']) ? strtotime($trainingData['iloFromDate']) : null;
                        $data['toDate'] = isset($trainingData['iloToDate']) ? strtotime($trainingData['iloToDate']) : null;
                        break;
                    case 'ilt'.BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS:
                        $data['accessDays'] = $trainingData['onlineClassRoomAccessDays'];
                        break;
                }
                $objRelation->setFromArray($data)->save();
            }            
            $db->commit();
            return true;
        }
        catch (Exception $e){
            $db->rollBack();
            throw $e;
            return false;
        }        	
    }
    
    public function getByLinkable($linkableId, $linkableType) {
        $returnData = array();
        $traingType = new Model_TrainingTypes();
        $data = $this->fetchAll(array("linkable_id = ?" => $linkableId,"linkable_type = ?" => $linkableType));
        foreach($data as $tempId => $data) {
            $trainingTypeData = current($traingType->loadById(array($data['training_id'])));
            switch($trainingTypeData['type'].$data['training_id']) {
                case 'osl2':
                    $returnData['osl2'] = 'osl2';
                    $returnData['oslAccessDays'] = $data['accessDays'];
                    break;
                case 'ilt1':
                    $returnData['ilt1'] = 'ilt1';
                    $returnData['classRoomAccessDays'] = $data['accessDays'];
                    $returnData['classRoomFromDate'] = date('m/d/Y', $data['fromDate']);
                    $returnData['classRoomToDate'] = date('m/d/Y', $data['toDate']);
                    break;
                case 'ilt3':
                    $returnData['ilt3'] = 'ilt3';
                    $returnData['iloAccessDays'] = $data['accessDays'];
                    $returnData['iloFromDate'] = date('m/d/Y', $data['fromDate']);
                    $returnData['iloToDate'] = date('m/d/Y', $data['toDate']);
                    break;
            }        
        }
        return $returnData;
    }
    
    public function getCourseTrainingIds($linkableId, $linkableType) {
        $return = array();
         foreach($this->fetchAll(array("linkable_id = ?" => $linkableId,"linkable_type = ?" => $linkableType,'training_id <> ?'=>BaseApp_Dao_TrainingTypes::TYPE_LVC), array('columns'=> array('training_id'))) as $trainingData) {
            $return[] = $trainingData['training_id'];
        }
        return $return;
    }
    
    public function getCourseTrainingData($linkableId, $linkableType) {
        $return = array();
         foreach($this->fetchAll(array("linkable_id = ?" => $linkableId,"linkable_type = ?" => $linkableType), array('columns'=> array('training_id', 'accessDays'))) as $trainingData) {
            $return[$trainingData['training_id']] = $trainingData;
        }
        return $return;
    }

    public function getOslAccessDaysForCourse($linkableId, $linkableType) {
        $return = array();
        $result = current($this->fetchAll(array("linkable_id = ?" => $linkableId,"linkable_type = ?" => $linkableType,'training_id = ?'=>BaseApp_Dao_TrainingTypes::TYPE_ELEARNING), array('columns'=> array('accessDays'))));
        if(!empty($result)){
            $objAccessDays = new Model_AccessDays();
            $dayIdArr = explode(',',$result['accessDays']);
            $return = $objAccessDays->fetchAll(array('day_id in (?)'=>$dayIdArr),array('columns'=> array('noOfDays')));
        }
        return $return;
    }
} // End of Class