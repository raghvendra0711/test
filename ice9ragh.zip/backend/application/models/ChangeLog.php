<?php
class Model_ChangeLog extends BaseApp_Dao_ChangeLog{
        protected $_useCache = false;

}
