<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_SectionTemplates extends BaseApp_Dao_SectionTemplates{

    public function getTemplates() {
        $data = $this->fetchAll();
        $returnData = array();
        foreach($data as $insexTemp => $dataReal) {
            $returnData[$dataReal['section_id']] = array(
                'name' => $dataReal['name'],
                'menuItem' => $dataReal['menuItem'],
            );
        }
        return $returnData;
    }

    public function getTemplatesForTrainingType($typeId) {
        $data = $this->fetchAll();
        $returnData= array();
        $order = 0;
        foreach($data as $template) { 
            if (!empty($template)) {          
                $allowedTrainingIds = explode(',', $template['allowed_training_ids']);
                if(in_array($typeId, $allowedTrainingIds)){
                    $order = $order + 1;
                    $returnData[$template['section_id']] = array(                                        
                                            'name'=> $template['name'],
                                            'menuItem'=> $template['menuItem'],
                                            'orderNo' => $order,
                                            'sticky_title' => $template['sticky_title'],
                                            'sticky_on' => $template['sticky_on'],
                                            'content_title_key' => $template['content_title_key'],
                                            'sticky_status' => $template['sticky_status'],
                                            'header_suffix' => $template['header_suffix']
                                            );
                }
            }
        }
        return $returnData;
    }
    
    public function getSectionId($templateName) {
        $templates = $this->fetchAll(array('name = ?' => $templateName), array(), false);
        if (!empty($templates)){
            $template = $templates[0];
            return $template['section_id'];
        }
        return null;
    }
} // End of Class