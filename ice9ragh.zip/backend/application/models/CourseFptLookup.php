<?php

class Model_CourseFptLookup extends BaseApp_Dao_CourseFptLookup {

    public function getLookupIdData($productId,$productType) {
        $data = parent::getLookupIdData($productId,$productType);
        return $data;
    }

}
