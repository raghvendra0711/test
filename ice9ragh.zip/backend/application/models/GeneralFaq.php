<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_GeneralFaq extends BaseApp_Dao_GeneralFaq{
	
    public function createFaq($data) {
        $db = $this->getDb();
        $objFaq = new self();
        $db->beginTransaction();
	try{
            $objFaq->setFromArray($data)->save();            
            $db->commit();
            return $objFaq->faq_id;
        }
        catch (Exception $e){
            $db->rollBack();
            return false;
        }
    }
    
    public function updateFaq($data) {
        $db = $this->getDb();
	$objFaq = new self();
        $db->beginTransaction();
        try{
            $objFaq->setId($data['faq_id']);
            $objFaq->setFromArray($data)->update();  
            $db->commit();
            return true;
        }
        catch (Exception $e){
            $db->rollBack();
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }
    
    public function saveFaq($linkableId, $linkableType, $section, $faqData) {       
        $db = $this->getDb();
        $objFaq = new self();
        $db->beginTransaction();
	try{
            $conds = array(
                'linkable_id=?' => $linkableId,
                'linkable_type=?' => $linkableType,
                'section=?'=>$section
            );
            $properties = $objFaq->fetchAll($conds);
            foreach($properties as $property){
                $objFaq->clean();
                $objFaq->setId($property['faq_id']);
                $objFaq->delete();
            }
            foreach($faqData as $faqDataSingle) {
                $faqDataSingle['section'] = $section;
                $faqDataSingle['linkable_id'] = $linkableId;
                $faqDataSingle['linkable_type'] = $linkableType;
                $objFaq->setFromArray($faqDataSingle)->save();            
            }            
            $db->commit();
            return true;
        }
        catch (Exception $e){
            $db->rollBack();
            return false;
        }
    }
    
    public function getBySection($section, $linkabelId=false, $linkableType=false) {
        $conds = array(
            'section=?'=>$section
        );
        if($linkabelId){
            $conds['linkable_id=?'] = $linkabelId;
        }
        if($linkableType){
            $conds['linkable_type=?'] = $linkableType;
        }
        return $this->fetchAll($conds);
    }
    public function deleteAboutBundle($faqData,$section){
        $db = $this->getDb();
        $objFaq = new self();
        $objDetailContentMapping = new Model_CountryContentMapping();
        $db->beginTransaction();
        try {
            $faqLinkableType = !empty($faqData['linkable_type']) ? $faqData['linkable_type'] :'';
            $faqLinkableId = !empty($faqData['linkable_id']) ? $faqData['linkable_id'] : '';
            if(empty($faqLinkableType)) {
                throw new Exception("Failed Linkable Type Is Missing !");
            }
            if(isset($faqData['linkable_type'])){
                unset($faqData['linkable_type']);
            }
            if(isset($faqData['linkable_id'])){
                unset($faqData['linkable_id']);
            }
            foreach ($faqData as $indexId => $dataSave) {
                $faqId = $dataSave['faq_id'];
                $linkableId = !empty($dataSave['linkable_id']) ? $dataSave['linkable_id'] : $faqLinkableId;
                $linkableType = !empty($dataSave['linkable_type']) ? $dataSave['linkable_type'] : $faqLinkableType;

                //delete from generalFaq
                $objFaq->clean();
                $conds = array('faq_id = ?' => $faqId,'section=?' =>$section);
                $objFaq->deleteWhere($conds);

                //delete from country_content_mapping

                $objDetailContentMapping->clean();
                $conds = array('content_id = ?' => $faqId,'linkable_id = ?'=>$linkableId,'linkable_type = ?'=>$linkableType);
                $objDetailContentMapping->deleteWhere($conds);
            }
            $db->commit();
            return true;
        } catch (Exception $e) {
            $db->rollBack();
            return false;
        }
    }
    
} // End of Class