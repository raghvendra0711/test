<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_KeyFeatures extends BaseApp_Dao_KeyFeatures{
		
    public function saveFeature($linkable_id, $linkable_type, $keyFeatures) {
        unset($keyFeatures['__template__']);
        // $db = $this->getDb();
	    $objFeatures = new self(); 
        //$db->beginTransaction();
        try{            
            $properties = $objFeatures->fetchAll(array('linkable_id=?'=>$linkable_id,'linkable_type=?'=>$linkable_type));
            foreach($properties as $property){
                $objFeatures->clean();
                $objFeatures->setId($property['feature_id']);
                $objFeatures->delete();
            }     
            $objFeatures->clean();
            
            foreach($keyFeatures as $indexId => $dataSave) {
                if($dataSave['name'] || $dataSave['featureText']) {
                    $dataSave['linkable_id'] = $linkable_id;
                    $dataSave['linkable_type'] = $linkable_type;
                    $objFeatures->setFromArray($dataSave)->save();
                }                
            }            
           // $db->commit();
            return true;
        }
        catch (Exception $e){
          //  $db->rollBack();
            return false;
        }
    }
    
    public function getByLinkable($linkableId, $linkableType) {
        return $this->fetchAll(array("linkable_id = ?" => $linkableId,"linkable_type = ?" => $linkableType));
    }
} // End of Class