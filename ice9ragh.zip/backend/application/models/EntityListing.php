<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_EntityListing extends BaseApp_Dao_EntityListing{

	public function createListings($data){
		$db = $this->getDb();
	    $objEl = new self();
        $pageUrl = '';
        $db->beginTransaction();
        try{
            if(isset($data['url'])) {
                $pageUrl = trim($data['url']);
                $checkSlash = substr($pageUrl, 0,1);
                if($checkSlash != '/'){
                    $pageUrl = trim('/'.$pageUrl);
                }
                unset($data['url']);
            }
            $imageUrl = $data['imageUrl'];
            unset($data['imageUrl']);
            
            $objEl->setFromArray($data)->save();

            $imageData = array(
            					'linkable_id'=>$objEl->entity_listing_id,
            					'linkable_type'=>'entityListing',
            					'imagePath'=>$imageUrl
            					);
            $objimage = new Model_Images();
            $objimage->setFromArray($imageData)->save();
            
            $dataSave = array(
            	'url'=>$pageUrl,
                'controller' => self::SEO_DEFAULT_CONTROLLER,
                'action' => self::SEO_DEFAULT_ACTION,
                'params' => json_encode(array('entity_listing_id'=>$objEl->entity_listing_id,
            	  							  'course_id'=>$data['course_id'],
            	  		 					  'training_type'=>$data['training_id'],
            	  							  'banner_path'=>$imageUrl,
            	  							  'shortDescription'=>$data['shortDescription'],
            	  		 					  'longDescription'=>$data['longDescription'],
            	  		 					  'displayName'=>$data['displayName']
            	 							 )
                						),
                'linkable_id' => $objEl->entity_listing_id,
                'linkable_type' => 'entityListing',
                'title'=>$data['name'],
                'description'=>$data['shortDescription'],
                'h1Tag'=>$data['displayName'],
                'noindex'=>1
            );
            $modelSeo = new Model_Seo();
            $modelSeo->setFromArray($dataSave)->save();
            $db->commit();
            return $objEl->entity_listing_id;
        }
        catch (Exception $e){
            print $e->getMessage();
            $db->rollBack();
            return false;
        }
	}


	public function UpdateListings($Id,$data){
		$db = $this->getDb();
	    $objEl = new self();
        $pageUrl = '';
        $db->beginTransaction();
        try{
            $imageUrl = $data['imageUrl'];
            $imageId  = $data['image_id'];
            unset($data['url']);
            unset($data['imageUrl']);
            unset($data['image_id']);
            $objEl->setId($Id);
            $objEl->setFromArray($data)->update();

            if(!empty($imageId) && !empty($imageUrl)){
            	$objimage = new Model_Images();
				$objimage->setId($imageId);
            	$imageData = array('imagePath'=>$imageUrl);
            	$objimage->setFromArray($imageData)->update();	
            }

            $dataSave = array(
                'params' => json_encode(array('entity_listing_id'=>$Id,
            	  							  'course_id'=>explode(',',$data['course_id']),
            	  		 					  'training_type'=>explode(',',$data['training_id']),
            	  		 					  'shortDescription'=>$data['shortDescription'],
            	  		 					  'longDescription'=>$data['longDescription'],
            	  		 					  'displayName'=>$data['displayName'],
            	  							  'banner_path'=>$imageUrl
            	 							 )
                						),
                'title'=>$data['name'],
                'description'=>$data['shortDescription'],
                'h1Tag'=>$data['displayName'],
                'noindex'=>1
            );
            $modelSeo = new Model_Seo();
            $seoData = $modelSeo->fetchAll(array('linkable_id = ?'=>$Id,'linkable_type =?'=>'entityListing'));
            if(!empty($seoData)){
            	$modelSeo->setId($seoData[0]['seo_id']);
            	$modelSeo->setFromArray($dataSave)->update();	
            }
            $db->commit();
            return true;
        }
        catch (Exception $e){
            print $e->getMessage();
            $db->rollBack();
            return false;
        }
	}

    public function deleteEntityListing($entityListingId){
        $db = $this->getDb();
        $enityObj = new self();
        $db->beginTransaction();
        $linkableType = 'entityListing';

        $objSeo = new Model_Seo();        
        $seoData = current($objSeo->fetchAll(array('linkable_id=?'=>$entityListingId, 'linkable_type=?'=>$linkableType), array('columns' => 'seo_id'), false));
        if(!empty($seoData)){
            $objSeo->clean();
            $objSeo->setId($seoData['seo_id']);
            if(!$objSeo->delete()) {
                $db->rollBack();
                return false;
            }
        }
        $enityObj->clean();
        $enityObj->setId($entityListingId);
        if(!$enityObj->delete()) {
            $db->rollBack();
            return false;
        }
        $db->commit();
        return true;
    }

} // End of Class