<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Model_ProductSectionData extends BaseApp_Dao_ProductSectionData {
    /**
     * B2B Company Price Plans
     * @var array
     */
    protected $companyPricePlans = array('1' => 'Discount Price Plan', '2' => 'Fixed Price Plans');
    public $segmentMapId = 0;

    public function getCompanyPricePalns (){
            return $this->companyPricePlans;
    }
    public function setDisplayField($val) {
        $this->_displayField = $val;
    }
   
    public function saveProductSectionData($data) {
      
        try {
            $industryTrendsArr = $labelIdArr = $courseIdArr = $bundleIdArr = $bundleAccrArr = $courseFaqIdArr = $sectionIdArr = $seoArr = array();
            if (!empty($data['label_id_arr']))
                $labelIdArr = $data['label_id_arr'];
            if (!empty($data['course_id_arr']))
                $courseIdArr = $data['course_id_arr'];
            if (!empty($data['bundle_id_arr']))
                $bundleIdArr = $data['bundle_id_arr'];
               
            if (!empty($data['bundle_accreditor_id_arr']))
                $bundleAccrArr = $data['bundle_accreditor_id_arr'];
            if (!empty($data['course_faq_id_arr']))
                $courseFaqIdArr = $data['course_faq_id_arr'];  
            if (!empty($data['hiring_company_arr']))
                $hiringCompanyIdArr = $data['hiring_company_arr'];      
            if (!empty($data['seo_id_arr']))
                $seoArr = $data['seo_id_arr'];
            if(!empty($data['course_faq_arr']))
                $industryTrendsArr = $data['course_faq_arr'];

            unset($data['label_id_arr']);
            unset($data['course_id_arr']);
            unset($data['bundle_id_arr']);
            unset($data['bundle_accreditor_id_arr']);
            unset($data['course_faq_id_arr']);
            unset($data['hiring_company_arr']);
            unset($data['seo_id_arr']);
            unset($data['course_faq_arr']);
            $objSection = new Model_SectionMapping();
            $this->setFromArray($data)->save();
            if (!empty($labelIdArr))
                $objSection->saveProductSectionDataBySectionId($labelIdArr, 'Category', $this->_id);
            if (!empty($courseIdArr))
                $objSection->saveProductSectionDataBySectionId($courseIdArr, 'course', $this->_id);
            if (!empty($bundleIdArr))
           
                $objSection->saveProductSectionDataBySectionId($bundleIdArr, 'bundle', $this->_id);
            if(!empty($bundleAccrArr))
                $objSection->saveProductSectionDataBySectionId($bundleAccrArr, BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLE_ACCREDITOR_LABEL, $this->_id);
            if(!empty($courseFaqIdArr)){
                $this->segmentMapId = $objSection->saveProductSectionDataBySectionId($courseFaqIdArr, BaseApp_Dao_SectionMapping::COURSE_FAQ_LINKABLE_TYPE, $this->_id);            
            }
            if(!empty($hiringCompanyIdArr))
                $objSection->saveProductSectionDataBySectionId($hiringCompanyIdArr, BaseApp_Dao_SectionMapping::HIRING_COMPANY_LINKABLE_TYPE, $this->_id);
            
            if(!empty($industryTrendsArr)) {                
                $objSection->saveProductSectionDataBySectionId($industryTrendsArr, BaseApp_Dao_SectionMapping::COURSE_FAQ_LINKABLE_TYPE,  $this->_id);
            }

            if (!empty($seoArr))
                $objSection->saveProductSectionDataBySectionId($seoArr, BaseApp_Dao_SectionMapping::LINKABLE_TYPE_SEO, $this->_id);
            return $this->_id;
        } catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }

    public function updateProductSectionData($id, $data, $contentType = 0,$sectionMapId = 0) {      
        $db = $this->getDb();
        $db->beginTransaction();
         
        try {
            $labelIdArr = $courseIdArr = $bundleIdArr = $seoArr =  array();
            if (isset($data['label_id_arr'])) {
                $labelIdArr = $data['label_id_arr'];
            }
            if (isset($data['course_id_arr'])) {
                $courseIdArr = $data['course_id_arr'];
            }
            if (isset($data['bundle_id_arr'])) {
                $bundleIdArr = $data['bundle_id_arr'];
            }
            if (!empty($data['course_faq_id_arr']))
                $courseFaqIdArr = $data['course_faq_id_arr'];  
                
            if (!empty($data['hiring_company_arr'])){
                $hiringCompanyIdArr = $data['hiring_company_arr']; 
            }
            if (isset($data['seo_id_arr'])){
                $seoArr = $data['seo_id_arr'];
            }  
                            
            unset($data['label_id_arr']);
            unset($data['course_id_arr']);
            unset($data['bundle_id_arr']);
            unset($data['course_faq_id_arr']);
            unset($data['hiring_company_arr']);
            unset($data['seo_id_arr']); 
            $this->setId($id);
            $this->setFromArray($data)->update();
            $objSection = new Model_SectionMapping();
            $objSection->saveProductSectionDataBySectionId($labelIdArr, 'Category', $id);
            $objSection->saveProductSectionDataBySectionId($courseIdArr, 'course', $id);
            $objSection->saveProductSectionDataBySectionId($bundleIdArr, 'bundle', $id);
            if (!empty($seoArr))
                $objSection->saveProductSectionDataBySectionId($seoArr, BaseApp_Dao_SectionMapping::LINKABLE_TYPE_SEO, $id);
                
            //$objSection->saveProductSectionDataBySectionId($bundleIdArr, 'bundle', $id);
            if(!empty($courseFaqIdArr)){
                $this->segmentMapId = $objSection->saveProductSectionDataBySectionId($courseFaqIdArr, BaseApp_Dao_SectionMapping::COURSE_FAQ_LINKABLE_TYPE, $id,$contentType,$sectionMapId);
            }

            if(!empty($hiringCompanyIdArr)){                 
                $objSection->saveProductSectionDataBySectionId($hiringCompanyIdArr, BaseApp_Dao_SectionMapping::HIRING_COMPANY_LINKABLE_TYPE, $id,$contentType);
            }
                         
            $db->commit();
            return true;
        } catch (Exception $e) {
            $db->rollBack();
            if (APPLICATION_ENV == 'development')
                prd($e->getMessage());
            return false;
        }
    }

    public function updateSyncStatus($id){
        $this->setId($id);
        $this->setFromArray(array('status_sync' => 1))->update();
    }

    public function updateProductSectionColumn($id, $data, $column) {
        $db = $this->getDb();
        $db->beginTransaction();
        try {
            $checkExisting = $this->fetchAll(array("$column =?" => $id));
            if (!empty($checkExisting)) {
                foreach ($checkExisting as $key => $value) {
                    $this->clean();
                    $this->setId($value['id']);
                    $this->setFromArray(array("$column" => ''))->update();
                }
            }
            if (!empty($data)) {
                foreach ($data as $row) {
                    $this->setId($row);
                    $this->setFromArray(array($column => $id))->update();
                }
            }
            $db->commit();
            return true;
        } catch (Exception $e) {
            $db->rollBack();
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }
    public function savebannerSectionData($bannerImage, $bannerText, $companyId) {
        $db = $this->getDb();
        $db->beginTransaction();
        $bannerSectionResult = array();
        $bannerSectionIds = array();
        try {
            $objSection = new Model_SectionMapping();
            $bannerSectionData = $objSection->getCourseCardsByProduct($companyId, 'company', 'banner_section');   
            $bannerSectionImage = '';
            $bannerSectionText = '';
            if($bannerSectionData){
            foreach ($bannerSectionData as $cKey => $cValue) {
                if ($cValue['sectionTitle'] == 'banner_image') {
                    $bannerSectionImage = $cValue['sectionTitle'];
                }
                elseif ($cValue['sectionTitle'] == 'banner_text') {
                    $bannerSectionText = $cValue['sectionTitle'];
                }
               }
            }  
            if (!$bannerSectionImage) {
                // no mapping present so insert into productSection and aslo in sectionMapping
                if (!empty($bannerImage)) {
                    $this->clean();
                    $this->setFromArray(array('sectionType' => 'banner_section', 'sectionTitle' => 'banner_image', 'name' => $bannerImage))->save();
                    $objSection->clean();
                    $objSection->setFromArray(array('section_id' => $this->_id, 'linkable_id' => $companyId, 'linkable_type' => 'company','status' => 1))->save();                         
                }
                else
                    $objSection->setFromArray(array('section_id' => $this->_id, 'linkable_id' => $companyId, 'linkable_type' => 'company','status' => 0))->save();
            }
            $bannerSectionIds[] = $this->_id;
            if (!$bannerSectionText) {
                if (!empty($bannerText)) {
                    $this->clean();
                    $this->setFromArray(array('sectionType' => 'banner_section', 'sectionTitle' => 'banner_text', 'name' => $bannerText))->save();
                    $objSection->clean();
                    $objSection->setFromArray(array('section_id' => $this->_id, 'linkable_id' => $companyId, 'linkable_type' => 'company','status' => 1))->save();
                }
                else{
                    $objSection->setFromArray(array('section_id' => $this->_id, 'linkable_id' => $companyId, 'linkable_type' => 'company','status' => 0))->save();
            
                }
                }
            $bannerSectionIds[] = $this->_id;
            if(!empty($bannerSectionData)) {
                $updateStatus = array('status' => 1);
                // There exists course cards for the company.Update depending upon the form values
                foreach ($bannerSectionData as $cKey => $cValue) {
                    $bannerSectionIds[] = $cValue['section_id'];
                    $updateData = NULL;
                    if ($cValue['sectionTitle'] == 'banner_image') {
                        $updateData = array('status' => 1, 'name' => $bannerImage);
                        if(empty($bannerImage))
                            $updateStatus = array('status' => 0);
                    } elseif ($cValue['sectionTitle'] == 'banner_text') {
                        $updateData = array('status' => 1, 'name' => $bannerText);
                        if(empty($bannerText))
                            $updateStatus = array('status' => 0);
                    }
                    if ($updateData) {                       
                        $this->clean();
                        $this->setId($cValue['section_id']);
                        $this->setFromArray($updateData)->update();
                        $objSection->clean();
                        $objSection->setId($cValue['sm_pk']);
                        $objSection->setFromArray($updateStatus)->update();
                    }
                }
                
            }
            $db->commit();
            $bannerSectionResult = (object) array('value' => true, 'sectionId' => array_unique($bannerSectionIds));
            return $bannerSectionResult;
        } catch (Exception $e) {
            $db->rollBack();
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }



    public function savePartnershipSectionData($headerInfo, $advInfo,$getStartInfo, $companyId) {
        $db = $this->getDb();
        $db->beginTransaction();
        $partnershipResults = array();
        $partnershipSectionIds = array();
        $partnershipHeader = array();
        $partnershipAdvantage = array();
        $partnershipGetStart = array();

        try {
            $objSection = new Model_SectionMapping();
            $partnershipSectionData = $objSection->getCourseCardsByProduct($companyId, 'company', 'partnership_section');  
            if($partnershipSectionData){
            foreach ($partnershipSectionData as $cKey => $cValue) {
                if ($cValue['sectionTitle'] == 'partnership_heading') {
                    $partnershipHeader = $cValue['sectionTitle'];
                }
                elseif ($cValue['sectionTitle'] == 'partnership_advantage') {
                    $partnershipAdvantage = $cValue['sectionTitle'];
                }
                elseif ($cValue['sectionTitle'] == 'partnership_get_start') {
                    $partnershipGetStart = $cValue['sectionTitle'];
                }
               }
            }   
            if (!$partnershipHeader) {
                // no mapping present so insert into productSection and aslo in sectionMapping
                if (!empty($headerInfo)) {
                    $this->clean();
                    $this->setFromArray(array('sectionType' => 'partnership_section', 'sectionTitle' => 'partnership_heading', 'name' => $headerInfo['name'],'description'=>$headerInfo['description'],'company' => $companyId))->save();
                    $objSection->clean();
                    $objSection->setFromArray(array('section_id' => $this->_id, 'linkable_id' => $companyId, 'linkable_type' => 'company','status' => 1))->save();                        
                }
                else
                    $objSection->setFromArray(array('section_id' => $this->_id, 'linkable_id' => $companyId, 'linkable_type' => 'company','status' => 0))->save();
            }
            $partnershipSectionIds[] = $this->_id;
            if (!$partnershipAdvantage) {
                if (!empty($advInfo)) {
                    $this->clean();
                    $this->setFromArray(array('sectionType' => 'partnership_section', 'sectionTitle' => 'partnership_advantage', 'name' => $advInfo['name'],'description' =>$advInfo['description'],'company' => $companyId ))->save();
                    $objSection->clean();
                    $objSection->setFromArray(array('section_id' => $this->_id, 'linkable_id' => $companyId, 'linkable_type' => 'company','status' => 1))->save();
                }
                else{
                    $objSection->setFromArray(array('section_id' => $this->_id, 'linkable_id' => $companyId, 'linkable_type' => 'company','status' => 0))->save();
            
                }
                }
                $partnershipSectionIds[] = $this->_id;
                if (!$partnershipGetStart) {
                    if (!empty($getStartInfo)) {
                        $this->clean();
                        $this->setFromArray(array('sectionType' => 'partnership_section', 'sectionTitle' => 'partnership_get_start', 'name' => $getStartInfo['name'],'description' =>$getStartInfo['description'] ,'company' => $companyId))->save();
                        $objSection->clean();
                        $objSection->setFromArray(array('section_id' => $this->_id, 'linkable_id' => $companyId, 'linkable_type' => 'company','status' => 1))->save();
                    }
                    else{
                        $objSection->setFromArray(array('section_id' => $this->_id, 'linkable_id' => $companyId, 'linkable_type' => 'company','status' => 0))->save();
                
                    }
                    }
            $partnershipSectionIds[] = $this->_id;
            if(!empty($partnershipSectionData)) {
                $updateStatus = array('status' => 1);
                // There exists data for the company.Update depending upon the form values
                foreach ($partnershipSectionData as $cKey => $cValue) {
                    $partnershipSectionIds[] = $cValue['section_id'];
                    $updateData = NULL;
                    if ($cValue['sectionTitle'] == 'partnership_heading') {
                        $updateData = array('status' => 1, 'name' => $headerInfo['name'],'description'=>$headerInfo['description']);
                        if(empty($headerInfo))
                            $updateStatus = array('status' => 0);
                    } elseif ($cValue['sectionTitle'] == 'partnership_advantage') {
                        $updateData = array('status' => 1, 'name' => $advInfo['name'],'description'=>$advInfo['description']);
                        if(empty($advInfo))
                            $updateStatus = array('status' => 0);
                    } elseif ($cValue['sectionTitle'] == 'partnership_get_start') {
                        $updateData = array('status' => 1, 'name' => $getStartInfo['name'],'description'=>$getStartInfo['description']);
                        if(empty($getStartInfo))
                            $updateStatus = array('status' => 0);
                    }
                    if ($updateData) {                       
                        $this->clean();
                        $this->setId($cValue['section_id']);
                        $this->setFromArray($updateData)->update();
                        $objSection->clean();
                        $objSection->setId($cValue['sm_pk']);
                        $objSection->setFromArray($updateStatus)->update();
                    }
                }
                
            }
            $db->commit();
            $partnershipResults = (object) array('value' => true, 'sectionId' => array_unique($partnershipSectionIds));
            return $partnershipResults;
        } catch (Exception $e) {
            $db->rollBack();
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }

    public function getByProduct($id, $sectionType) {
        return $this->fetchAll(array("id = ?" => $id, "sectionType =?" => $sectionType));
    }
    public function getAgencyData($companyId, $sectionType) {
        return $this->fetchAll(array("company = ?" => $companyId, "sectionType =?" => $sectionType));
    }

    public function getBySectionName($sectionName, $sectionType) {
        $returnArr = array();
        $sql = $this->getDb()->select()
                ->from(array('sm' => 'sectionMapping'), array('linkable_id', 'linkable_type'))
                ->join(array('ps' => 'productSectionData'), 'sm.section_id = ps.id', array())
                ->where('ps.name = ?', $sectionName)
                ->where('ps.sectionType = ?', $sectionType)
                ->where('sm.status <> ?', 0)
                ->where('ps.status <> ?', 0)
                ->order(array('ps.name ASC'));
        $sectionData = $this->getDb()->fetchAll($sql);
        if (!empty($sectionData)) {
            foreach ($sectionData as $key => $value) {
                $returnArr[$value['linkable_type']][] = $value['linkable_id'];
            }
        }

        return $returnArr;
    }

    public function getDetailsByType($sectionType) {
        $returnArr = array();
        $resultSet = $this->fetchAll(array("sectionType =?" => $sectionType));
        if (!empty($resultSet)) {
            foreach ($resultSet as $key => $value) {
                $returnArr[$value['id']] = $value['company'];
            }
        }
        return $returnArr;
    }

    /**
     * Get Section Info By type
     * @param type $sectionType
     * @return array
     */
    public function getBySectionType($sectionType,$sectionName='') {
        $returnArr = array();
        if (!empty($sectionType)) {
            $defaultColumns = array('id', 'name');
            $sql = $this->getDb()->select()
                    ->from(array('ps' => 'productSectionData'), $defaultColumns)
                    ->where('ps.sectionType = ?', $sectionType)
                    ->where('ps.status <> ?', 0)
                    ->order(array('ps.name ASC'));
            if(!empty($sectionName)):
                $sql->where('LOWER(ps.name) = ? ',$sectionName);
            endif;
            $sectionData = $this->getDb()->fetchAll($sql);
            if (!empty($sectionData)) {
                foreach ($sectionData as $key => $value) {
                    $returnArr[$value['id']] = $value['name'];
                }
            }
        }
        return $returnArr;
    }

    public function getLinkabaleInfoBySectionName($sectionName, $sectionType, $linkableId = 0, $toolLinkableType = '') {
        $returnArr = array();
        $sql = $this->getDb()->select()
                ->from(array('sm' => 'sectionMapping'), array('id','linkable_id', 'linkable_type', 'section_id'))
                ->join(array('ps' => 'productSectionData'), 'sm.section_id = ps.id', array())
                ->where('ps.name = ?', $sectionName)
                ->where('ps.sectionType = ?', $sectionType)
                ->where('ps.status <> ?', 0)
                ->order(array('ps.name ASC'));
        if (!empty($toolLinkableType) && is_string($toolLinkableType)) {
            $sql->where('sm.linkable_type = ?', $toolLinkableType);
        }
        if ($linkableId && is_numeric($linkableId)) {
            $sql->where('sm.linkable_id = ?', $linkableId)
                    ->limit(1);
        }
        $sectionData = $this->getDb()->fetchAll($sql);
        if (!empty($sectionData)) {
            foreach ($sectionData as $key => $value) {
                $returnArr[$value['section_id']][] = array('id'=>$value['id'],'linkable_id' => $value['linkable_id'], 'linkable_type' => $value['linkable_type']);
            }
        }
        return $returnArr;
    }

    public function getDataByType($linkableId, $linkableType, $sectionType, $status = FALSE, $order = '', $conditions = array()) {
        if(empty($order)) {
            $order = 'ps.name ASC';
        }
        $returnArr = array();
        $sql = $this->getDb()->select()
                ->from(array('sm' => 'sectionMapping'), array('linkable_id', 'linkable_type', 'section_id', 'id'))
                ->join(array('ps' => 'productSectionData'), 'sm.section_id = ps.id', array('ps.sectionTitle', 'ps.name','ps_linkable_id'=>'ps.linkable_id','ps_description'=>'ps.description','ps_sectiontype'=> 'ps.sectionType'))
                ->where('sm.linkable_id = ?', $linkableId)
                ->where('sm.linkable_type = ?', $linkableType)
                ->where('ps.sectionType = ?', $sectionType)
                ->where('ps.status <> ?', 0)
                ->order(array($order));
        if (!empty($conditions)) {
            foreach ($conditions as $cond => $value) {
                $sql->where($cond, $value);
            }
        }
        if ($status === TRUE) {
            $sql->where('sm.status <> ?', 0);
        }
        $sectionData = $this->getDb()->fetchAll($sql);
        if (!empty($sectionData)) {
            foreach ($sectionData as $key => $value) {
                $returnArr[$value['section_id']] = array('linkable_id' => $value['linkable_id'], 'linkable_type' => $value['linkable_type'], 'sectionTitle' => $value['sectionTitle'], 'name' => $value['name'], 'section_id' => $value['section_id'],'section_map_id' => $value['id'], 'ps_linkable_id' => $value['ps_linkable_id'], 'id' => $value['id'], 'ps_description' => $value['ps_description'], 'ps_sectiontype' => $value['ps_sectiontype']);
            }
        }
        return $returnArr;
    }

    public function updateToolProductSectionData($linkableId, $linkableType) {
        try {
            $fields = array('id =?' => $linkableId, 'sectionType =?' => $linkableType);
            $checkExisting = $this->fetchAll($fields);
            if (!empty($checkExisting)) {
                foreach ($checkExisting as $key => $value) {
                    $this->clean();
                    $this->setId($value['id']);
                    $this->setFromArray(array('status' => 0))->update();
                }
            }
            return true;
        } catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }
    public function disableB2BProdTrainingMap($companyId) {
        try {
            if (!empty($companyId)) {
                $checkExisting = $this->fetchAll(array(
                    'sectionType IN (?) ' => array(BaseApp_Dao_TrainingTypes::B2B_TRAINING_TYPE, BaseApp_Dao_TrainingTypes::B2B_PRODUCT_TYPE),
                    'company=?' => $companyId,
                ));
                $sectionIdArr = array();
                if (!empty($checkExisting)) {
                    foreach ($checkExisting as $key => $value) {
                        $sectionIdArr[] = $value['id'];
                        $this->clean();
                        $this->setId($value['id']);
                        $this->setFromArray(array('status' => 0))->update();
                    }
                    if (!empty($sectionIdArr)) {
                        $objSection = new Model_SectionMapping();
                        foreach ($sectionIdArr as $sectionId) {
                            $objSection->disableSecMapBySectionId($companyId, 'company', $sectionId);
                        }
                    }
                }
                return true;
            }
        } catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
        return false;
    }

    public function saveProductSectionDataB2BCompany($param) {
        try {
            if (!empty($param)) {
                $sectionType = $param['sectionType'];
                $linkableTypeId = $param['linkableTypeId'];
                $name = $param['name'];
                $description = $param['description'];
                $companyId = $param['companyId'];
                $checkExisting = $this->fetchAll(array(
                    'sectionType =?' => $sectionType,
                    'company=?' => $companyId,
                    'linkable_type_id' => $linkableTypeId));
                if (!empty($checkExisting)) {
                    foreach ($checkExisting as $key => $value) {
                        $this->clean();
                        $this->setId($value['id']);
                        $this->setFromArray(array('status' => 0))->update();
                    }
                }
                $this->clean();
                $data['linkable_type_id'] = !empty($linkableTypeId) ? $linkableTypeId : NULL;
                $data['company'] = $companyId;
                $data['sectionType'] = $sectionType;
                $data['name'] = $name;
                $data['description'] = $description;
                $this->setFromArray($data)->save();
                return $this->_id;
            }
        } catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }


    public function getDescription($params) {
        if(!empty($params['id'])){
            $sql = $this->getDb()->select()
            ->from('productSectionData')
            ->where('productSectionData.description =?', $params['data'])
            ->where('productSectionData.id NOT IN (?)' , $params['id']);
           
            $descriptionData = $this->getDb()->fetchAll($sql);
        }

        else{
            $sql = $this->getDb()->select()
            ->from('productSectionData')
            ->where('productSectionData.description =?', $params['data']);
            $descriptionData = $this->getDb()->fetchAll($sql);
        }
        $count = count($descriptionData);
        return $count;
    }
    

    public function disableProductSectionById($sectionId,$sectionLinkableId,$sectionlinkableType) {
        try {
            $fields = array('id IN (?)' => $sectionId);
            $checkExisting = $this->fetchAll($fields);
            if (!empty($checkExisting)) {
                $objSection = new Model_SectionMapping();
                foreach ($checkExisting as $key => $value) {
                    $sectionId = $value['id'];
                    $linkableType = $sectionlinkableType;
                    $linkableId = $sectionLinkableId;
                    $objSection->disableSecMapBySectionId($linkableId,$linkableType,$sectionId);
                    $this->clean();
                    $this->setId($value['id']);
                    $this->setFromArray(array('status' => 0))->update();
                }
            }
            return true;
        } catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }

    public function updatedPSDataProjects($id, $data) {
       
        $db = $this->getDb();
        $db->beginTransaction();
        try {
            $idFiels = array('bundle_id_arr', 'course_id_arr');
            foreach($idFiels as $field) {
                if(isset($data[$field])) {
                    unset($data[$field]);
                }
            }
            $this->setId($id);
            $this->setFromArray($data)->update();
            $db->commit();
            return true;
        } catch (Exception $e) {
            $db->rollBack();
            if (APPLICATION_ENV == 'development')
                prd($e->getMessage());
            return false;
        }
    }

    public function updatedBundleSkillSets($id, $data) {
       
        $db = $this->getDb();
        $db->beginTransaction();
        try {
            unset($data['bundle_id_arr']);
            $this->setId($id);
            $this->setFromArray($data)->update();
            $db->commit();
            return true;
        } catch (Exception $e) {
            $db->rollBack();
            if (APPLICATION_ENV == 'development')
                prd($e->getMessage());
            return false;
        }
    }


    public function updatedPSBundleData($id, $data) {
       
      
         $db = $this->getDb();
         $db->beginTransaction();
         try {
             if($data['bundle_id_arr']){
                 unset($data['bundle_id_arr']);
             }
             $this->setId($id);
             $this->setFromArray($data)->update();
             $db->commit();
             return true;
         } catch (Exception $e) {
             $db->rollBack();
             if (APPLICATION_ENV == 'development')
                 prd($e->getMessage());
             return false;
         }
     }

    public function disableById($sectionId){
        try {
            if (!empty($sectionId)) {
                $fields = array('id IN (?)' => $sectionId);
                $checkExisting = $this->fetchAll($fields);
                if (!empty($checkExisting)) {
                    foreach ($checkExisting as $key => $value) {
                        $sectionId = $value['id'];                    
                        $this->clean();
                        $this->setId($sectionId);
                        $this->setFromArray(array('status' => 0))->update();
                    }
                }
                return true;
            } else {
                throw new BaseApp_Exception('No section Id passed to disableById');
            }
        } catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }

    public function deleteById($sectionId) {
        try {
            $condition = array('id = ?' => $sectionId);
            $checkExisting = $this->fetchAll($condition);
            if (!empty($checkExisting)) {
                $objSection = new Model_SectionMapping();
                foreach ($checkExisting as $key => $value) {
                    $sectionId = $value['id'];
                    if ($objSection->deleteAllBySectionId($sectionId)){
                        $this->clean();
                        $this->setId($value['id']);
                        $this->setFromArray(array('status' => 0))->update();
                    } else {
                        throw new BaseApp_Exception('Error deleting section data');
                    }
                }
            }
            return true;
        } catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }
    public function savePartnershipSectionDataMigration($data) {             
        try {
            $objSection = new Model_SectionMapping();
            if(!empty($data)){
                foreach($data as $row){
                    
                    $this->clean();
                    $this->setFromArray(array('sectionType' => $row['sectionType'], 'sectionTitle' => $row['sectionTitle'], 'name' => $row['name'],'description'=>$row['description'],'company' => $row['company']))->save();                    
                    $objSection->clean();
                    $objSection->setFromArray(array('section_id' => $this->_id, 'linkable_id' => $row['company'], 'linkable_type' => 'company','status' => 1))->save();
                }
                return true;
            }                            
        } catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }
}

// End of Class
