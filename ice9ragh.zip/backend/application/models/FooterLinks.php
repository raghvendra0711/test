<?php

class Model_FooterLinks extends BaseApp_Dao_FooterLinks
{

    public function saveFooterLinks($request = array(), $footer_link_id = '')
    {
        $response = array('status' => false, 'msg' => 'Failed');
        if (!empty($request)) {
            $response = parent::saveFooterLinks($request, $footer_link_id);
        }
        return $response;
    }


    public function fetchLinksByCountry($countries = array(), $productTypeId = '')
    {
        $result = array();
        if (!empty($countries) && !empty($productTypeId)) {
            $result = parent::fetchLinksByCountry($countries, $productTypeId);
        }
        return $result;
    }

    public function fetchAllCountryData($productTypeId = '')
    {
        $result = array();
        if (!empty($productTypeId)) {
            $result = parent::fetchAllCountryData($productTypeId);
        }
        return $result;
    }

    public function fetchClusterData($productTypeId = '',$clusterId = 0){
        $result = array();
        if (!empty($productTypeId) && !empty($clusterId)) {
            $result = parent::fetchClusterData($productTypeId,$clusterId);
        }
        return $result;
    }

    public function fetchCountryData($productTypeId = '',$countryId = 0){
        $result = array();
        if (!empty($productTypeId) && !empty($countryId)) {
            $result = parent::fetchCountryData($productTypeId,$countryId);
        }
        return $result;
    }

    public function fetchLinksByCluster($clusters = array(), $productTypeId = '')
    {
        $result = array();
        if (!empty($clusters) && !empty($productTypeId)) {
            $result = parent::fetchLinksByCluster($clusters, $productTypeId);
        }
        return $result;
    }

    public function getAllFooterLinks($countryId = '', $clusterId = '')
    {
        $result = parent::getAllFooterLinks($countryId, $clusterId);
        return $result;
    }

    public function getFooterLinkDetailById($id = 0)
    {
        $result = array();
        if (!empty($id)) {
            $result = parent::getFooterLinkDetailById($id);
        }
        return $result;
    }

    public function deleteFooterLink($footer_link_id)
    {
        $response = array('status' => false, 'message' => 'Failed to delete record.');
        if (!empty($footer_link_id)) {
            $response = parent::deleteFooterLink($footer_link_id);
        }
        return $response;
    }

    public function disableFooterLink($footer_link_id)
    {
        $response = array('status' => false, 'message' => 'Failed to disable record.');
        if (!empty($footer_link_id)) {
            $response = parent::disableFooterLink($footer_link_id);
        }
        return $response;
    }

    public function enableFooterLink($footer_link_id)
    {
        $response = array('status' => false, 'message' => 'Failed to enable record.');
        if (!empty($footer_link_id)) {
            $response = parent::enableFooterLink($footer_link_id);
        }
        return $response;
    }

    public function getAllCoursesLinks()
    {
        $result = array();
        $courseList = parent::getSeoEnabledCourseList();
        if (!empty($courseList)) {
            $result = $courseList;
        }
        return $result;
    }

    public function getAllBundlesLinks()
    {
        $result = array();
        $list = parent::getSeoEnabledBundleList();
        if (!empty($list)) {
            $result = $list;
        }
        return $result;
    }
}
