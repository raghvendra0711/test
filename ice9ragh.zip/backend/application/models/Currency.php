<?php
class Model_Currency extends BaseApp_Dao_Currency {
    protected $_useCache = true;

    public function getCurrencyToDisplay() {
        $returnData = array();
        foreach($this->fetchAll(array(), array('columns'=> array('currency_id', 'code', 'countryCode'), 'order' => array('defaults DESC'))) as $tempId => $dataReal) {
            if ($dataReal['countryCode']){
                $dataReal['code'] .= ' - '.$dataReal['countryCode'];
            }
            $returnData[$dataReal['currency_id']] = $dataReal['code'];
        }
        return $returnData;
    }

    public function getCurrencyFromCountryId($countryId){
        $defaultCurrency = '';
        if($countryId){
            $currencies =$this->fetchAll(array(
                'country_id = ?' => $countryId
            ));
            if (!$currencies)
                $currencies =$this->fetchAll(array(
                    'defaults = ?' => 1
                ));
            return $currencies[0]['code'];
        }
         return false;
  	}

  	public function converToGivenCurrency($amount, $currencyCode,$numberformat = true) {
        if (!is_numeric($amount) && $amount)
            throw new BaseApp_Exception('Amount has to be numeric.');
	    //get conversion rate by currency code
		$currencyDet = $this->fetchAll(array('code=?'=>$currencyCode));

        if ($currencyDet && $currencyDet[0]['conversionRate']) {
            if ($numberformat)
            return number_format($currencyDet[0]['conversionRate'] * $amount, 2);
	    else
            return array('conversionRate'=>$currencyDet[0]['conversionRate'],'convertedAmount'=>$currencyDet[0]['conversionRate'] * $amount);
        }else
	    return false;
    }

    public function getActualAmount($amount, $currencyCode, $numberformat = true) {
        if (!is_numeric($amount) && $amount)
            throw new BaseApp_Exception('Amount has to be numeric.');
        $currencyDet = $this->fetchAll(array('code=?'=>$currencyCode));
        if ($currencyDet && $currencyDet[0]['conversionRate']) {
            if ($numberformat)
                return number_format($currencyDet[0]['conversionRate'] / $amount, 0);
            else
                return round($amount / $currencyDet[0]['conversionRate'], 4);
        }else
            return false;
    }

    public function getCurrencyCodes() {
        $returnData = array();
        foreach($this->fetchAll(array(), array('columns'=> array('code'), 'order' => array('defaults DESC'))) as $tempId => $dataReal) {
            $returnData[$dataReal['code']] = $dataReal['code'];
        }
        return $returnData;
    }

    public function getCurrencyDetails($countryId){
        $currencyData = array();
        $sql=  $this->getDb()->select()
                     ->from('country as co',array( 'co.name',
                                                   'co.code as countryCode',
                                                   'co.country_id',
                                                   'co.serviceTax',
                                                   'co.serviceTaxString'
                                                 )
                           )
                     ->join('currencies as cr','cr.currency_id = co.currency_id',array('cr.currency_id','cr.country_id as CurrencyCountryId','cr.code','cr.symbol','cr.defaults','cr.conversionRate','cr.countryCode as CurrencyCountryCode','cr.invoiceAddress','cr.registrationNumber','cr.invoiceString','cr.status','cr.symbol_original'))
                     ->where('co.country_id = ?',$countryId)
                     ->where('co.status = ?',1)
                     ->where('cr.status = ?',1);
        $currencyData = current($this->getDb()->fetchAll($sql));
        if(empty($currencyData)){
            $currencyData = current($this->fetchAll(array('defaults =?'=>1)));
        }
        return $currencyData;
    }
}
