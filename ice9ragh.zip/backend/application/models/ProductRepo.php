<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Model_ProductRepo extends BaseApp_Dao_ProductRepo{


 public function saveData($linkable_id, $linkable_type,$section_type,$saveData,$hardWrite=0) {
        try{
            $properties = $this->fetchAll(array('linkable_id=?'=>$linkable_id,'linkable_type=?'=>$linkable_type,'section_type =?'=>$section_type));
            foreach($properties as $property){
                $this->clean();
                $this->setId($property['id']);
                $this->delete();
            }
            $this->clean();
            if(!empty($saveData)){
                foreach($saveData as $indexId => $dataSave) {
                    if(!empty($linkable_id)){
                        if($section_type == 'certificate'){
                            if(!empty($dataSave['header_text']) || $hardWrite==1){
                                $dataSave['linkable_id'] = $linkable_id;
                                $dataSave['linkable_type'] = $linkable_type;
                                $dataSave['section_type'] = $section_type;
                                $this->setFromArray($dataSave)->save();
                            }
                        }elseif($section_type == 'promotional'){
                            if(!empty($dataSave['long_description'])){
                                $dataSave['linkable_id'] = $linkable_id;
                                $dataSave['linkable_type'] = $linkable_type;
                                $dataSave['section_type'] = $section_type;
                                $this->setFromArray($dataSave)->save();
                            }
                        }
                    }
                }
            }
            return true;
        }
        catch (Exception $e){
            prd($e->getMessage());
            return false;
        }
    }

    public function getByLinkable($linkable_id,$linkable_type){
        $returnArr = array();
        $properties = $this->fetchAll(array('linkable_id=?'=>$linkable_id,'linkable_type=?'=>$linkable_type));
        foreach ($properties as $key => $value) {
            $returnArr[$value['section_type']][] = $value;
        }
        return $returnArr;
    }

    public function getByType($linkable_type){
        $returnArr = array();
        $properties = $this->fetchAll(array('linkable_type=?'=>$linkable_type));
        foreach ($properties as $key => $value) {
            $returnArr[$value['section_type']] = $value;
        }
        return $returnArr;
    }


} // End of Class
