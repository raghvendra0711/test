<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_Testimonials extends BaseApp_Dao_Testimonials{	


    public function getForInclusion($courseId, $trainingId = 0) {
        $returnData = array();
        $data = $this->fetchAll(array('course_id = ?' => $courseId));
        foreach($data as $tempId => $dataReal) {
            $returnData['testimonials']['testimonials'.$dataReal['testimonial_id']] = 'Testimonial (ID-'.$dataReal['testimonial_id'].')';
        }
        return $returnData;
    }
    
} // End of Class