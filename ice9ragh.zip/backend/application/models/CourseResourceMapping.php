<?php

class Model_CourseResourceMapping extends BaseApp_Dao_CourseResourceMapping {

    public function getLinkableTypeByProductTypeId($productTypeId) {
        $linkableType = BaseApp_Dao_Courses::PRODUCT_TYPE_NAME;
        switch(strval($productTypeId)) {
            case strval(BaseApp_Dao_Bundles::PRODUCT_TYPE_ID): $linkableType = BaseApp_Dao_Bundles::PRODUCT_TYPE_NAME; break;
        }
        return $linkableType;
    }

    public function getCityCourseResourceMapByLookupId($courseCityLookupId, $type, $trainingTypeId, $courseId, $cityId) {
        $result = array();
        if ($courseCityLookupId && $type && $courseId && $cityId) {
            $result = parent::getCityCourseResourceMapByLookupId($courseCityLookupId, $type, $trainingTypeId, $courseId, $cityId);
        }
        return $result;
    }
    public function getFptFaqsResourceMapByLookupId($courseCityLookupId, $type, $courseId) {
        $result = array();
        if ($courseCityLookupId && $type && $courseId) {
            $result = parent::getFptFaqsResourceMapByLookupId($courseCityLookupId, $type, $courseId);
        }
        return $result;
    }

    public function getAllOrdersByLookupIds($lookupIds = array()) {
        $result = array();
        if (is_array($lookupIds)) {
            $result = parent::getOrderByLookupIds($lookupIds);
        }
        return $result;
    }

    public function getAllLookupIdByParentFaqId($faqId) {
        $result = array();
        if (!empty($faqId)) {
            $result = parent::getAllLookupIdByParentFaqId($faqId);
        }
        return $result;
    }

    public function getResourceMappingInfo($faqId, $cityId, $productId, $productType) {
        $result = array();
        if (!empty($faqId) && !empty($cityId) && !empty($productId) && !empty($productType)) {
            $result = parent::getResourceMappingInfo($faqId, $cityId, $productId, $productType);
        }
        return $result;
    }

    public function getResouceMapByFaqAndLookup($faqId, $lookupId) {
        $result = array();
        if (!empty($faqId) && !empty($lookupId)) {
            $result = parent::getResouceMapByFaqAndLookup($faqId, $lookupId);
        }
        return $result;
    }

}
