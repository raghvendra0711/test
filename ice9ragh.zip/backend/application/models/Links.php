<?php

class Model_Links extends BaseApp_Dao_Links {

    public function __construct() {
        parent::__construct();
    }

}
