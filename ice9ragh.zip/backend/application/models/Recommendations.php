<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_Recommendations extends BaseApp_Dao_Recommendations{
		
        private $_recommendElements = array(
            'lebel'=>'Label',
            'course'=>'Course',
            'practiceTests'=>'Practice Test', 
            'webinars'=>'Webinar'
        );
	public function createRecommendation($recData){
		$db = $this->getDb();
        $objRecom = new self();
        $db->beginTransaction();
        try{
            $counter = 1;
            foreach ($recData as $key => $value) {
                $recomData = array( 
                    'linkable_id' =>$value,
                    'linkable_type' =>$key,
                    'applicableEntity' =>'',
                    'applicableEntityId' =>'',
                    'trainingType' =>'',
                    'orderNo' =>$counter
                );
                $res = $objRecom->setFromArray($recomData)->save();
                $counter ++ ;
            }
            $db->commit();
            return true;
        }catch (Exception $e){
            $db->rollBack();
            return false;
        }
	}

    public function saveRecommendations($linkableId, $linkableType, $recommendations) {        
        unset($recommendations['__template__']);
        $db = $this->getDb();
	    $objRecommend = new self(); 
        $db->beginTransaction();
        try{       
            $properties = $objRecommend->fetchAll(array('linkable_id=?'=>$linkableId,'linkable_type=?'=>$linkableType));
            foreach($properties as $property){
                $objRecommend->clean();
                $objRecommend->setId($property['recommendation_id']);
                $objRecommend->delete();
            }
            foreach($recommendations as $indexId => $dataSave) {
                if($dataSave['applicableEntity'] || $dataSave['applicableEntityId'] || $dataSave['trainingType']) {
                    $dataSave['linkable_id'] = $linkableId;
                    $dataSave['linkable_type'] = $linkableType;
                    $objRecommend->setFromArray($dataSave)->save();        
                }
            }          
            $db->commit();
            return true;
        }
        catch (Exception $e){
            $db->rollBack();
            return false;
        }
    }
    
    public function getByLinkable($linkableId, $linkableType) {
        return $this->fetchAll(array("linkable_id = ?" => $linkableId,"linkable_type = ?" => $linkableType));
    }
    
    public function getRecommendElements() {
        return $this->_recommendElements;
    }
    
    public function getByElement($element) {
        switch($element) {
            case 'lebel':
                $model = new Model_Labels();
                return $model->fetchForSelect();       
            case 'course':
                $model = new Model_Courses();
                return $model->fetchForSelect();       
            case 'practiceTests':
                $model = new Model_PracticeTest();
                return $model->fetchForSelect();       
            case 'webinars':
                $model = new Model_Webinars();
                return $model->fetchForSelect();       
            default :
                return array(
                    "status" => "error",
                    "message" => "Invalid element passed"
                );
        }
    }
} // End of Class