<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_AccreditorMapping extends BaseApp_Dao_AccreditorMapping{	

} // End of Class