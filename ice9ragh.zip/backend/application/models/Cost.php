<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
class Model_Cost extends BaseApp_Dao_Cost {
    public function saveCostData($data, $courseId, $costLabelId) {
        if (!empty($data) && !empty($courseId) && !empty($costLabelId)) {
            unset($data['price']);
            foreach ($data as $key => $value) {
                $size = sizeof($value);
                break;
            }
            
            $i = 0;
            for ($j = 0; $j < $size; $j++) {
                foreach ($data as $key => $value) {
                    while ($i < $size) {
                        $costData[$key] = $value[$i];
                        break;
                    }
                }
                $i++;
                if (!empty($costData)) {
                    foreach ($costData as $key1 => $value1) {
                        if (is_array($value1)) {
                            foreach ($value1 as $key2 => $value2) {
                                $saveData[$key1] = $key2;
                            }
                        } else {
                            $saveData[$key1] = $value1;
                        }
                    }
                }
                $saveData['course_id'] = $courseId;
                $saveData['cost_lable_id'] = $costLabelId[0];
                $saveData['status'] = 1;
                $saveData['cost_text_id'] = !empty($saveData['cost_table_text_id']) ? $saveData['cost_table_text_id'] : 0 ;
                unset($saveData['cost_table_text_id']);
                unset($saveData['currency']);
//                if (!empty($saveData['cost'])) {
                    $this->setFromArray($saveData)->save();
//                }
            }
            if (!empty($costText)) {
                $this->saveTextData($costText, $courseId, $costLabelId);
            }
        }
    }
    public function updateCostData($data, $courseId, $costLabelId) {
        if (!empty($data) && !empty($courseId) && !empty($costLabelId)) {
            $costText = $data['text'];
            unset($data['price']);
            unset($data['text']);
            foreach ($data as $key => $value) {
                $size = sizeof($value);
                break;
            }
            $i = 0;
            for ($j = 0; $j < $size; $j++) {
                foreach ($data as $key => $value) {
                    while ($i < $size) {
                        $costData[$key] = $value[$i];
                        break;
                    }
                }
                $i++;
                if (!empty($costData)) {
                    foreach ($costData as $key1 => $value1) {
                        if (is_array($value1)) {
                            foreach ($value1 as $key2 => $value2) {
                                $saveData[$key1] = $key2;
                            }
                        } else {
                            $saveData[$key1] = $value1;
                        }
                    }
                }
                $saveData['course_id'] = $courseId;
                $saveData['cost_lable_id'] = $costLabelId[0];
                $saveData['status'] = 1;
                $saveData['cost_text_id'] = !empty($saveData['cost_table_text_id']) ? $saveData['cost_table_text_id'] : 0 ;
                unset($saveData['cost_table_text_id']);
                unset($saveData['currency']);
                if (!empty($saveData['id'])) {
                    $this->setId($saveData['id']);
                    $r = $this->setFromArray($saveData)->update();
                } else {
//                    if (!empty($saveData['cost'])) {
                        $this->setFromArray($saveData)->save();
//                    }
                }
            }
        }
    }
    public function delete($data) {
        $costDataOld = $data;
        foreach ($costDataOld as $key => $cost) {
            $cost['status'] = '0';
            $this->setId($cost['id']);
            $r = $this->setFromArray($cost)->update();
        }
        if (!empty($costText)) {
            $this->saveTextData($costText, $courseId, $costLabelId);
        }
    }
    public function getCourseDetails($data) {
        $courseName = new Model_Courses();
        foreach ($data as $key => &$value) {
            $cName = $courseName->getNameById($value['course_id']);
            $value['course_name'] = $cName;
        }
        return $data;
    }
    public function getDataByCourseId($courseId) {
        return $this->fetchAll(array('course_id=?' => $courseId));
    }
    public function saveTextData($data, $courseId, $costLabelId) {
        if (!empty($data) && !empty($courseId) && !empty($costLabelId)) {
            $costText = new Model_CostText();
            $saveCostText['course_id'] = $courseId;
            $saveCostText['cost_label_id'] = $costLabelId[0];
            $saveCostText['text'] = $data;
            $costText->setFromArray($saveCostText)->save();
        }
    }

    public function fetchExamCoursesHavingCost($costData = array()) {
        $result = array();
        if (!empty($costData['course_id']) && !empty($costData['exam_id'])) {
            $examIds = implode(',', ($costData['exam_id']));
            $sql = $this->getDb()->select()
                    ->from(array('cc' => 'course_cost'), array('id'))
                    ->join(array('ct' => 'cost_table_text'),'ct.course_id = cc.course_id and cc.cost_text_id= ct.id', array())
                    ->where('ct.course_id=?', $costData['course_id'])
                    ->where('ct.exam_id IN (?)', $examIds)
                    ->where('ct.cost_label_id=?', 1)
                    ->where('cc.cost_lable_id=?', 1)
                    ->where('cc.status=?', 1)
                    ->where('ct.status=?', 1)
            ;
            $result = $this->getDb()->fetchAll($sql);
        }
        return $result;
    }

    /**
    * Check if $courseId has any exam mapped.
    * @param type $courseId
    * @return string
    */
    public function getForInclusion($courseId = 0, $trainingId = 0) {
        $returnData = array();
        $sql = $this->getDb()->select()
                ->from(array('cc' => 'course_cost'), array())
                ->join(array('ct' => 'cost_table_text'), 'ct.id = cc.cost_text_id', array('course_id', 'exam_id'))
                ->join(array('ed' => 'exam_details'), 'ed.id=ct.exam_id', array('name'))
                ->join(array('ci' => 'courseInclusion'), 'ct.course_id = ci.course_id', array())
                ->where('cc.course_id=?', $courseId)
                ->where('ct.cost_label_id=?', 1)
                ->where('cc.cost_lable_id=?', 1)
                ->where('ct.status =?', 1)
                ->where('cc.status =?', 1)
                ->where('ed.status =?', 1)
                ->where("ci.linkable_type = 'exam'")
                ;
        //->where('ci.status =?', 1)
        ;
        if($trainingId != 0 ) {
            $sql->where('ci.training_id=?', $trainingId);
            $sql->where('ci.status=?', 1);
        }
//        prd($sql->__toString());
        $resultData = $this->getDb()->fetchAll($sql);
        $returnData = array();
        if (!empty($resultData)) {
            foreach ($resultData as $res) {
                if (!empty($res['exam_id'])) {
                    $returnData['exams']['exam' . $res['exam_id']] = 'exam (Name-' . $res['name'] . ')';
                }
            }
        }
        return $returnData;
    }


}