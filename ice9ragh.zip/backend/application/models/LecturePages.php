<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Model_LecturePages extends BaseApp_Dao_LecturePages {

    const ORDER_LIMIT = 20;
    const KEY_LIMIT = 6;
    
    public function saveLecturePagesData($data) {

        $linkable_id = $data['primary_course_id'];
        $lecturePageData = array();
        $lecturePageData = $data;

        unset($lecturePageData['primary_course_id']);
        unset($lecturePageData['url']);
        unset($lecturePageData['SaveSeoCourse']);
        $lecturePageData['linkable_id'] = $linkable_id;
        $lecturePageData['linkable_type'] = 'course';
        $lecturePageData['status'] = 1;
        try {
            $objSection = new Model_SectionMapping();
            $this->setFromArray($lecturePageData)->save();
            return $this->_id;
        } catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }

}

// End of Class