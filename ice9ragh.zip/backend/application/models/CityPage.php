<?php

class Model_CityPage extends BaseApp_Dao_CityPage {

    public function getNameById($cityIds = array()) {
        $conds = array();
        $return = array();
        if ($cityIds) {
            $conds['city_id IN (?)'] = $cityIds;
        }
        $this->setFetchDisabled(true);
        foreach ($this->fetchAll($conds) as $cityData) {
            $return[$cityData['city_id']] = $cityData['name'];
        }
        $this->setFetchDisabled(false);
        return $return;
    }

    public function getCourseList() {
        $result = array();
        $courseList = parent::getSeoEnabledCourseList();
        if (!empty($courseList)) {
            $result = $courseList;
        }
        return $result;
    }
    
    public function getBundleList() {
        $result = array();
        $list = parent::getSeoEnabledBundleList();
        if (!empty($list)) {
            $result = $list;
        }
        return $result;
    }

    public function getCourseCities($courseId = '') {
        $cityList = array();
        if (!empty($courseId)) {
            $courseCitiesList = parent::getCourseCities($courseId);
            if (!empty($courseCitiesList)) {
                $courseCityInfo = $courseCitiesList;
                if (!empty($courseCityInfo)) {
                    foreach ($courseCityInfo as $row) {
                        if (!empty($row['params'])) {
                            $params = Zend_Json_Decoder::decode($row['params']);
                            if (!empty($params['course_id'] && !empty($params['city_id'])) && !empty($params['city_id'])) {
                                $cityList[$params['city_id']] = $params['city_name'];
                            }
                        }
                    }
                }
            }
        }
        return $cityList;
    }
    
    public function getBundleCities($courseId = '') {
        $cityList = array();
        if (!empty($courseId)) {
            $courseCityInfo = parent::getBundleCities($courseId);
            if (!empty($courseCityInfo)) {
                foreach ($courseCityInfo as $row) {
                    if (!empty($row['params'])) {
                        $params = Zend_Json_Decoder::decode($row['params']);
                        if (!empty($params['bundle_id'] && !empty($params['city_id'])) && !empty($params['city_name'])) {
                            $cityList[$params['city_id']] = $params['city_name'];
                        }
                    }
                }
            }
        }
        return $cityList;
    }

    public function getCountryByCityId($cityId) {
        $result = array();
        if (!empty($cityId)) {
            $result = parent::getCountryIdByCityId($cityId);
        }
        return $result;
    }

    public function getCourseFaqs($cityId, $courseId, $trainingTypeId,$countryId=0) {
        $reponse = $courseFaqs = $mergedCourseFaqs = $inActiveParentFaqs = array();
        if (!empty($cityId) && !empty($courseId)) {
            $result = parent::getCourseFaqs($cityId, $courseId, $trainingTypeId,$countryId);
            $mergedCourseFaqs = !empty($result['mergedFaqs']) ? $result['mergedFaqs'] : array();
            $inActiveParentFaqs = !empty($result['inActiveParentFaqs']) ? $result['inActiveParentFaqs'] : array();
            $inActiveParentFaqIds = !empty($inActiveParentFaqs) ? array_column($inActiveParentFaqs, 'course_faq_id') : array();
            /**
             * Remove Parent Clone City Page Question If  Question Is Disbale In Course Page.
             */
            if (!empty($inActiveParentFaqIds)) {
                foreach ($mergedCourseFaqs as $key => $row) {
                    $faqId = $row['course_faq_id'];
                    if (in_array($faqId, $inActiveParentFaqIds)) {
                        unset($mergedCourseFaqs[$key]);
                    }
                }
                $mergedCourseFaqs = array_values($mergedCourseFaqs);
            }
            if (!empty($mergedCourseFaqs))
                foreach ($mergedCourseFaqs as $row) {
                    if ((int) $row['type'] === BaseApp_Dao_CityPage::CITY_PAGE_EXAM_CERTIFICATION && !$row['is_b2c'])
                        continue;
                    if (empty($row['city_id'])) {
                        $row['is_parent'] = true;
                        $row['is_clone'] = true;
                        $row['action'] = 'Clone';
                    } else {
                        $row['is_parent'] = false;
                        $row['is_clone'] = false;
                        $row['action'] = 'Edit';
                    }
                    $courseFaqs[] = $row;
                }
        }
        $reponse = array('courseFaqs' => $courseFaqs);
        return $reponse;
    }

    public function getCourseIntroText($cityId, $courseId, $trainingTypeId, $productTypeId) {
        $result = array();
        if (!empty($cityId) && !empty($courseId)) {
            $result = parent::getCourseIntroText($courseId, $cityId, $trainingTypeId, $productTypeId);
            foreach ($result as &$row) {
                $row['action'] = 'Edit';
            }
        }
        return $result;
    }

    public function updateCourseIntroText($id, $courseIntroText) {
        $updateStatus = false;
        if (!empty($id) && !empty($courseIntroText)) {
            $dataSave = array('course_intro_text' => $courseIntroText, 'status' => 1);
            try {
                $modelSeo = new Model_Seo();
                $modelSeo->setId($id);
                if ($modelSeo->setFromArray($dataSave)->update()) {
                    $updateStatus = true;
                }
            } catch (Exception $e) {
                $updateStatus = false;
            }
        }
        return $updateStatus;
    }

    public function updateCityPageFaqs($courseFaqId, $answer, $question, $cityId, $type, $courseId, $trainingTypeId, $order, $parentLookupId, $mapId, $jumpToSection, $isClonFlag,$productTypeId=1) {
        $response = array('status' => false, 'msg' => null);
        $dataSave = $dataDisableMapping = array();
        if (!empty($courseId) && !empty($answer) && !empty($question)) {
            $db = $this->getDb();
            if ($isClonFlag && $parentLookupId && $mapId) {
                try {
                    $courseCityLookupId = $courseCityOrder = $courseCityStatus = 0;
                    $db->beginTransaction();
                     $objCourseCityLookUp = new Model_CourseCityLookup();
                    $lookupResult = $objCourseCityLookUp->getAllLookUpByCourseId($courseId,$productTypeId);
                    $pLookUpId = $cLookUpId = 0;
                    if (!empty($lookupResult)) {
                        foreach ($lookupResult as $row) {
                            if ((int) $row['course_id'] === (int) $courseId && empty($row['city_id']) && empty($parentLookUpId)) {
                                $pLookUpId = $row['id'];
                            } else if ((int) $row['course_id'] === (int) $courseId && !empty($row['city_id']) && (int) $row['city_id'] === (int) $cityId && empty($childLookUpId)) {
                                $cLookUpId = $row['id'];
                            }
                        }
                        $lookupIds = array();
                        /* if (!empty($pLookUpId)) {
                            $lookupIds[] = $pLookUpId;
                            if (!empty($cLookUpId)) {
                                $lookupIds[] = $cLookUpId;
                            }
                            $objCourseResourceMapping = new Model_CourseResourceMapping();
                            $result = $objCourseResourceMapping->getChildOrder($courseId, $trainingTypeId, $type, $lookupIds);
                            if (!empty($result)) {
                                $orderList = array_column($result, 'order');
                                if (in_array($order, $orderList)) {
                                    $db->rollBack();
                                    $response = array('status' => false, 'msg' => "Order Value ( $order ) Already Exist.Please Try With Different Order Value.");
                                    return $response;
                                }
                            }
                        } */
                    }

                    $objCourseResourceMapping = new Model_CourseResourceMapping();
                    /* $parentResourceMappingData = $objCourseResourceMapping->getResouceMapByFaqAndLookup($courseFaqId, $parentLookupId);
                    $parentOrder = !empty($parentResourceMappingData[0]['order']) ? (int) $parentResourceMappingData[0]['order'] : 0; */
                    $courseCityLookUpData = $objCourseCityLookUp->getLookupIdData($courseId, $cityId,$productTypeId);
                    /**
                     * Check $courseCityLookUpData if any lookup id exist for courseid and cityid 
                     * If exist then fetch the lookup id and assign it to $courseCityLookupId
                     * Then disable the $courseFaqId by making an entry into "course_resouce_mapping"
                     * with params {courseCityLookupId,courseFaqId,Order=0,Status=0}
                     * 
                     */
                    if (!empty($courseCityLookUpData['id'])) {
                        $courseCityLookupId = $courseCityLookUpData['id'];
                        $lastOrder = $objCourseResourceMapping->getMaxOrderByLookupId($courseCityLookupId,$type,$trainingTypeId);
                        $parentOrder = $lastOrder + BaseApp_Dao_CourseResourceMapping::ORDER_STEP;
                        $dataDisableMapping = array('lookup_id' => $courseCityLookupId, 'faq_id' => $courseFaqId, 'order' => $parentOrder, 'status' => 0);
                        $objCourseResourceMapping = new Model_CourseResourceMapping();
                        /**
                         * Check If Parent Faq Id And Look Up Id Exist Before Insert If Not Exist Then Insert.
                         *
                         */
                        $isLookIpIdNotMapped = true;
                        $resourceMappingData = $objCourseResourceMapping->getResouceMapByFaqAndLookup($courseFaqId, $courseCityLookupId);
                        if (!empty($resourceMappingData)) {
                            $allLookupIds = array_column($resourceMappingData, 'lookup_id');
                            if (!empty($allLookupIds)) {
                                $allLookupIds = array_unique($allLookupIds);
                                if (in_array($courseCityLookupId, $allLookupIds)) {
                                    $isLookIpIdNotMapped = false;
                                }
                            }
                        }

                        if ($isLookIpIdNotMapped) {
                            $res = $objCourseResourceMapping->setFromArray($dataDisableMapping)->save();
                        } else {
                            $mappingId = !empty($resourceMappingData[0]['id']) ? $resourceMappingData[0]['id'] : 0;
                            if (!empty($mappingId)) {
                                $updateMappingStatus = array('status' => 0);
                                $objCourseResourceMapping->setId($mappingId);
                                $res = $objCourseResourceMapping->setFromArray($updateMappingStatus)->update();
                            }
                        }
                    }
                    /**
                     * If $courseCityLookUpData is empty then make an entry into course_city_lookup for courseid and cityid
                     * and get the lookup id and assign it to $courseCityLookupId.
                     * Then disable  the $courseFaqId by making an entry into "course_resouce_mapping"
                     * with params {courseCityLookupId,courseFaqId,Order=0,Status=0}
                     * 
                     */ else {
                        $dataCourseCityLookup = array('course_id' => (int) $courseId, 'city_id' => (int) $cityId, 'status' => 1);
                        if (!empty($productTypeId) && $productTypeId == BaseApp_Dao_ProductTypes::TYPE_ID_BUNDLE) {
                            $dataCourseCityLookup['linkable_type'] = BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES;
                        }
                        $res = $objCourseCityLookUp->setFromArray($dataCourseCityLookup)->save();
                        $courseCityLookupId = (int) $objCourseCityLookUp->id;
                        $dataDisableMapping = array('lookup_id' => $courseCityLookupId, 'faq_id' => $courseFaqId, 'order' => 1, 'status' => 0);
                        $objCourseResourceMapping = new Model_CourseResourceMapping();
                        $res = $objCourseResourceMapping->setFromArray($dataDisableMapping)->save();
                    }
                    if ($courseCityLookupId) {
                        $dataSave = array(
                            'type' => (int) $type,
                            'question' => $question,
                            'answer' => $answer,
                            'training_id' => (int) $trainingTypeId,
                            'status' => 1,
                            'jump_to_section' => $jumpToSection,
                            'is_b2c' => 1
                        );
                        /* if ((int) $type === BaseApp_Dao_CityPage::CITY_PAGE_EXAM_CERTIFICATION) {
                            $dataSave['is_b2c'] = 1;
                        } */
                        $objCourseFaq = new Model_CourseFaq();
                        $objCourseResourceMapping = new BaseApp_Dao_CourseResourceMapping();
                        $status = $objCourseFaq->setFromArray($dataSave)->save();
                        if ($status) {
                            $lastOrder = $objCourseResourceMapping->getMaxOrderByLookupId($courseCityLookupId,$type,$trainingTypeId);
                            $maxOrder = $lastOrder + BaseApp_Dao_CourseResourceMapping::ORDER_STEP;
                            $courseCityFaqId = (int) $objCourseFaq->course_faq_id;
                            /**
                             * Mapping Of Lookup Id and City Course Faq Id
                             */
                            if ($courseCityLookupId && $courseCityFaqId) {
                                $courseResourceMappingData = array('lookup_id' => $courseCityLookupId, 'faq_id' => $courseCityFaqId, 'order' => (int) $maxOrder, 'status' => 1);
                                if ($objCourseResourceMapping->setFromArray($courseResourceMappingData)->save()) {
                                    $mapId = (int) $objCourseResourceMapping->id;
                                    $response = array('status' => true, 'msg' => 'Success', 'data' => array('map_id' => $mapId, 'order' => (int) $maxOrder, 'faq_id' => $courseCityFaqId, 'lookup_id' => $courseCityLookupId));
                                    $db->commit();
                                }
                            }
                        }
                    }
                } catch (Exception $e) {
                    $db->rollBack();
                    $response = array('status' => false, 'msg' => $e->getMessage(), 'traces' => $e->getTraceAsString());
                }
            } else {
                try {
                    $db->beginTransaction();
                    $objCourseCityLookUp = new Model_CourseCityLookup();
                    $courseCityLookUpData = $objCourseCityLookUp->getLookupIdData($courseId, $cityId,$productTypeId);
                    if (!empty($courseCityLookUpData['id'])) {
                        $courseCityLookupId = $courseCityLookUpData['id'];
                        $lookupResult = $objCourseCityLookUp->getAllLookUpByCourseId($courseId,$productTypeId);
                        $pLookUpId = $cLookUpId = 0;
                        if (!empty($lookupResult)) {
                            foreach ($lookupResult as $row) {
                                if ((int) $row['course_id'] === (int) $courseId && empty($row['city_id']) && empty($parentLookUpId)) {
                                    $pLookUpId = $row['id'];
                                } else if ((int) $row['course_id'] === (int) $courseId && !empty($row['city_id']) && (int) $row['city_id'] === (int) $cityId && empty($childLookUpId)) {
                                    $cLookUpId = $row['id'];
                                }
                            }
                            $lookupIds = array();
                            if (!empty($pLookUpId)) {
                                $lookupIds[] = $pLookUpId;
                                if (!empty($cLookUpId)) {
                                    $lookupIds[] = $cLookUpId;
                                }
                                $objCourseResourceMapping = new Model_CourseResourceMapping();
                                $result = $objCourseResourceMapping->getChildOrder($courseId, $trainingTypeId, $type, $lookupIds);
                                $currentStatus = 0;
                                $faqStatus = 0;
                                if (!empty($result)) {
                                    foreach ($result as $key => $row) {
                                        if ((int) $row['faq_id'] === (int) $courseFaqId) {
                                            $currentStatus = $result[$key]['status'];
                                            $faqStatus = $result[$key]['faqStatus'];
                                            unset($result[$key]);
                                        }
                                    }
                                    /* $orderList = array_column($result, 'order');
                                    if (in_array($order, $orderList)) {
                                        $db->rollBack();
                                        $response = array('status' => false, 'msg' => "Order Value ( $order ) Already Exist.Please Try With Different Order Value.");
                                        return $response;
                                    } */
                                }
                            }
                        }
                    }
                    /**
                     * Update Course City Faq
                     */
                    $updateCoursecityFaq = array(
                        'question' => $question,
                        'answer' => $answer,
                        'status' => $faqStatus,
                        'jump_to_section' => (int) $jumpToSection
                    );
                    $objCourseFaq = new Model_CourseFaq();
                    $objCourseFaq->setId($courseFaqId);
                    $objCourseFaq->setFromArray($updateCoursecityFaq)->update();
                    /**
                     * Update Order In Course Mapping 
                     */
                    $updateCourseMappingData = array(/* 'order' => (int) $order, */ 'status' => $currentStatus);
                    $objCourseResourceMapping = new Model_CourseResourceMapping();
                    $objCourseResourceMapping->setId($mapId);
                    $objCourseResourceMapping->setFromArray($updateCourseMappingData)->update();
                    $response = array('status' => true, 'msg' => 'Success', 'data' => array('map_id' => $mapId, /* 'order' => (int) $order, */ 'faq_id' => $courseFaqId, 'lookup_id' => $courseCityLookupId));
                    $db->commit();
                } catch (Exception $e) {
                    $db->rollBack();
                    $response = array('status' => false, 'msg' => $e->getMessage());
                }
            }
        }
        return $response;
    }
/**
 * 
 * @param type $courseFaqId
 * @param type $question
 * @param type $cityId
 * @param type $type
 * @param type $courseId
 * @param type $trainingTypeId
 * @param type $productTypeId
 * @return type
 */
    public function updateCityPageAddionalContent($courseFaqId, $question, $cityId, $type, $courseId, $trainingTypeId, $productTypeId=1) {
        $response = array('status' => false, 'msg' => "Failed");
        $dataSave = $dataDisableMapping = array();
        if (!empty($courseId) && !empty($question)) {
            $db = $this->getDb();            
            try {
                $db->beginTransaction();
                $objCourseCityLookUp = new Model_CourseCityLookup();
                $courseCityLookUpData = $objCourseCityLookUp->getLookupIdData($courseId, $cityId, $productTypeId);                
                //pr($courseCityLookUpData);//testing done
                if (empty($courseCityLookUpData['id'])) { 
                    /*
                        Insert new record with above data in course_city_lookup table
                        Insert a new record in courseFaq table.Insert new record with above lookup id and faq id in course_resource_mapping table
                     */
                    $objCourseCityLookUp = new Model_CourseCityLookup();
                    $linkableType = $objCourseCityLookUp->getLinkableTypeByProductTypeId($productTypeId);
                    $dataCourseCityLookup = array('course_id' => (int) $courseId, 'city_id' => (int) $cityId, 'status' => 1, 'linkable_type' => $linkableType);
                    $res = $objCourseCityLookUp->setFromArray($dataCourseCityLookup)->save();
                    $courseCityLookupId = (int) $objCourseCityLookUp->id;
                    if ($courseCityLookupId) {//insert into courseFaq and course_resource_mapping
                        $response = $this->insertIntoFaqAndMap($courseCityLookupId, $courseId, $type, $trainingTypeId, $question);                        
                        $db->commit();
                    }
                } else {
                    /*
                    Fetch the faq id from course_resource_mapping and courseFaq having $courseCityLookupId, $type, $trainingTypeId, $courseId, $cityId
                      (Ex: - type = 7 (eligibility) and trainin_id = 0 (generic))
                    If above record does not exists
                        Insert a new record in courseFaq table.Insert new record with above lookup id and faq id in course_resource_mapping table
                    else
                    	update courseFaq table question column content of the above faq id
                    */
                    $courseCityLookupId = (int) $courseCityLookUpData['id'];
                    $objCourseResourceMapping = new Model_CourseResourceMapping();
                    $courseResourceMappingResult = $objCourseResourceMapping->getCityCourseResourceMapByLookupId($courseCityLookupId, $type, $trainingTypeId, $courseId, $cityId);
                    //pr($courseResourceMappingResult);
                    if (empty($courseResourceMappingResult)) {//insert into courseFaq and mapping
                        $response = $this->insertIntoFaqAndMap($courseCityLookupId, $courseId, $type, $trainingTypeId, $question);                        
                        $db->commit();
                    } else {
                        $courseFaqId = $courseResourceMappingResult[0]['faq_id'];
                        $mapId = $courseResourceMappingResult[0]['id'];
                        //update courseFaq table question column content of the above faq id
                        $updateCoursecityFaq = array(
                            'question' => $question,
                            'status' => 1,
                        );
                        $objCourseFaq = new Model_CourseFaq();
                        $objCourseFaq->setId($courseFaqId);
                        $objCourseFaq->setFromArray($updateCoursecityFaq)->update();
                        $response = array('status' => true, 'msg' => 'Success', 'data' => array('map_id' => $mapId, 'faq_id' => $courseFaqId, 'lookup_id' => $courseCityLookupId));
                        $db->commit();
                    }
                }
            } catch (Exception $ex) {
                $db->rollBack();
                $response = array('status' => false, 'msg' => $e->getMessage());
            }
        }
        return $response;
    }
    /**
     * 
     * @param type $courseCityLookupId
     * @param type $courseId
     * @param type $type
     * @param type $trainingTypeId
     * @param type $question
     * @return array
     */
    private function insertIntoFaqAndMap($courseCityLookupId, $courseId, $type, $trainingTypeId, $question){
        $dataSave = array(
            //'course_id' => (int) $courseId,
            'type' => (int) $type,
            'training_id' => (int) $trainingTypeId,
            'question' => $question,
            'status' => 1,
            //'jump_to_section' => $jumpToSection,
            //'is_b2c' => 1
        );
        $objCourseFaq = new Model_CourseFaq();                    
        //Insert a new record in courseFaq table : take the new faq id
        $status = $objCourseFaq->setFromArray($dataSave)->save();
        /**
         * Mapping Of Lookup Id and City Course Faq Id
         */
        if ($status) {
            $courseCityFaqId = (int) $objCourseFaq->course_faq_id;
            /**
            * Check order is unique across courseid and type.
            * If order exist then return with the max order for selected courseId and type.
            */
            $maxExistingOrderVal = 0;
            $objCourseResourceMapping = new Model_CourseResourceMapping();
            $maxExistingOrderVal = $objCourseResourceMapping->getMaxOrderByLookupId($courseCityLookupId, $type, $trainingTypeId);
            $newOrder = $maxExistingOrderVal + 1;
            $courseResourceMappingData = array('lookup_id' => $courseCityLookupId, 'faq_id' => $courseCityFaqId, 'order' => (int) $newOrder, 'status' => 1);

            //Insert new mapping record with above lookup id and faq id in course_resource_mapping table
            if ($objCourseResourceMapping->setFromArray($courseResourceMappingData)->save()) {
                $mapId = (int) $objCourseResourceMapping->id;
                $response = array('status' => true, 'msg' => 'Success', 'data' => array('map_id' => $mapId, 'order' => (int) $newOrder, 'faq_id' => $courseCityFaqId, 'lookup_id' => $courseCityLookupId));
                return $response;
            }
        }
        return array('status' => false, 'msg' => "Failed");
    }
/**
 * 
 * @param type $faqId
 * @param type $productId
 * @param type $cityId
 * @param type $productTypeId
 * @param type $type
 * @param type $trainingTypeId
 * @param type $newStatus
 * @param type $order
 * @return boolean
 */
    public function disableCityPageFaq($faqId, $productId, $cityId, $productTypeId, $type, $trainingTypeId, $newStatus, $order) {
        $response = array('status' => false, 'msg' => "Failed");
        $dataSave = $dataDisableMapping = array();
        if (!empty($productId) && !empty($cityId) && !empty($productTypeId)) {
            $db = $this->getDb();
            try {
                $db->beginTransaction();
                $objCourseCityLookUp = new Model_CourseCityLookup();
                $courseCityLookUpData = $objCourseCityLookUp->getLookupIdData($productId, $cityId, $productTypeId);
                if (empty($courseCityLookUpData['id'])) {
                    $objCourseCityLookUp = new Model_CourseCityLookup();
                    $linkableType = $objCourseCityLookUp->getLinkableTypeByProductTypeId($productTypeId);
                    $dataCourseCityLookup = array('course_id' => (int) $productId, 'city_id' => (int) $cityId, 'status' => 1, 'linkable_type' => $linkableType);
                    $objCourseCityLookUp->setFromArray($dataCourseCityLookup)->save();
                    $courseCityLookupId = (int) $objCourseCityLookUp->id;
                    if ($courseCityLookupId) {
                        $response = $this->mapAndDisableFaq($faqId, $courseCityLookupId, $type, $trainingTypeId, $newStatus);
                        $db->commit();
                    }
                } else {
                    $courseCityLookupId = (int) $courseCityLookUpData['id'];
                    $objCourseResourceMapping = new Model_CourseResourceMapping();
                    $courseResourceMappingResult = $objCourseResourceMapping->getResouceMapByFaqAndLookup($faqId, $courseCityLookupId);
                    if (empty($courseResourceMappingResult)) {
                        $response = $this->mapAndDisableFaq($faqId, $courseCityLookupId, $type, $trainingTypeId, $newStatus);
                        $db->commit();
                    } else {
                        $mapId = $courseResourceMappingResult[0]['id'];
                        $updateCourseMappingData = array('status' => (int) $newStatus);
                        $objCourseResourceMapping = new Model_CourseResourceMapping ();
                        $objCourseResourceMapping->setId($mapId);
                        if ($objCourseResourceMapping->setFromArray($updateCourseMappingData)->update()) {
                            $response = array('status' => true, 'msg' => 'Success', 'newStatus' => $newStatus, 'mappingIdUpdated' => $mapId);
                        }
                        $db->commit();
                    }
                }
            } catch (Exception $ex) {
                $db->rollBack();
                $response = array('status' => false, 'msg' => $e->getMessage());
            }
        }
        return $response;
    }
/**
 * 
 * @param type $faqId
 * @param type $courseCityLookupId
 * @param type $type
 * @param type $trainingTypeId
 * @param type $newStatus
 * @param type $order
 * @return type
 */
    private function mapAndDisableFaq($faqId, $courseCityLookupId, $type, $trainingTypeId, $newStatus){
        $objCourseResourceMapping = new Model_CourseResourceMapping();
        $maxExistingOrderVal = 0;
        $maxExistingOrderVal = $objCourseResourceMapping->getMaxOrderByLookupId($courseCityLookupId, $type, $trainingTypeId);
        $order = (int) $maxExistingOrderVal + 1;
        $courseResourceMappingData = array('lookup_id' => $courseCityLookupId, 'faq_id' => $faqId, 'status' => $newStatus, 'order' => $order);
        //Insert new mapping record with above lookup id and faq id in course_resource_mapping table
        if ($objCourseResourceMapping->setFromArray($courseResourceMappingData)->save()) {
            $mapId = (int) $objCourseResourceMapping->id;
            return array('status' => true, 'msg' => 'Success', 'newStatus' => $newStatus, 'mappingIdUpdated' => $mapId);            
        }
        return array('status' => false, 'msg' => "Mapping failed");
    }

    public function addMoreQuestionAnswer($answer, $question, $cityId, $type, $courseId, $trainingTypeId, $order, $jumpToSection, $isClonFlag, $extraData) {
        $productTypeId = empty($extraData['productTypeId'])?null:$extraData['productTypeId'];
        $response = array('status' => false, 'msg' => null);
        $dataSave = $dataDisableMapping = array();
        if (!empty($courseId) && !empty($answer) && !empty($question)) {
            $db = $this->getDb();
            try {
                $courseCityLookupId = $courseCityOrder = $courseCityStatus = 0;
                $db->beginTransaction();
                $objCourseCityLookUp = new Model_CourseCityLookup();
                $linkableType = $objCourseCityLookUp->getLinkableTypeByProductTypeId($productTypeId);
                /* $lookupResult = $objCourseCityLookUp->getAllLookUpByCourseId($courseId);
                $pLookUpId = $cLookUpId = 0;
                if (!empty($lookupResult)) {
                    foreach ($lookupResult as $row) {
                        if ((int) $row['course_id'] === (int) $courseId && empty($row['city_id']) && empty($parentLookUpId)) {
                            $pLookUpId = $row['id'];
                        } else if ((int) $row['course_id'] === (int) $courseId && !empty($row['city_id']) && (int) $row['city_id'] === (int) $cityId && empty($childLookUpId)) {
                            $cLookUpId = $row['id'];
                        }
                    }
                    $lookupIds = array();
                    if (!empty($pLookUpId)) {
                        $lookupIds[] = $pLookUpId;
                        if (!empty($cLookUpId)) {
                            $lookupIds[] = $cLookUpId;
                        }
                        $objCourseResourceMapping = new Model_CourseResourceMapping();
                        $result = $objCourseResourceMapping->getChildOrder($courseId, $trainingTypeId, $type, $lookupIds);
                        if (!empty($result)) {
                            $orderList = array_column($result, 'order');
                            if (in_array($order, $orderList)) {
                                $db->rollBack();
                                $response = array('status' => false, 'msg' => "Order Value ( $order ) Already Exist.Please Try With Different Order Value.");
                                return $response;
                            }
                        }
                    }
                } */
                $courseCityLookUpData = $objCourseCityLookUp->getLookupIdData($courseId, $cityId, $productTypeId);
                /**
                 * Check $courseCityLookUpData if any lookup id exist for courseid and cityid 
                 * If exist then fetch the lookup id and assign it to $courseCityLookupId
                 * Then disable the $courseFaqId by making an entry into "course_resouce_mapping"
                 * with params {courseCityLookupId,courseFaqId,Order=0,Status=0}
                 * 
                 */
                if (!empty($courseCityLookUpData['id'])) {
                    $courseCityLookupId = $courseCityLookUpData['id'];
                }
                /**
                 * If $courseCityLookUpData is empty then make an entry into course_city_lookup for courseid and cityid
                 * and get the lookup id and assign it to $courseCityLookupId.
                 * Then disable  the $courseFaqId by making an entry into "course_resouce_mapping"
                 * with params {courseCityLookupId,courseFaqId,Order=0,Status=0}
                 * 
                 */ else {
                    $dataCourseCityLookup = array('course_id' => (int) $courseId, 'city_id' => (int) $cityId, 'status' => 1, 'linkable_type' => $linkableType);
                    $res = $objCourseCityLookUp->setFromArray($dataCourseCityLookup)->save();
                    $courseCityLookupId = (int) $objCourseCityLookUp->id;
                }
                if ($courseCityLookupId) {
                    /**
                     * Check order is unique across courseid and type.
                     * If order exist then return with the max order for selected courseId and type.
                     */
                    $maxExistingOrderVal = 0;
                    $objCourseResourceMapping = new Model_CourseResourceMapping();
                    // $courseResourceMappingResult = $objCourseResourceMapping->getCityCourseResourceMapByLookupId($courseCityLookupId, $type, $trainingTypeId, $courseId, $cityId);
                    $maxExistingOrderVal = $objCourseResourceMapping->getMaxOrderByLookupId($courseCityLookupId,$type,$trainingTypeId);

                    /* if (!empty($courseResourceMappingResult)) {
                        $existingOrders = array_column($courseResourceMappingResult, 'order');
                        $existingOrders = array_filter($existingOrders);
                        if (!empty($existingOrders)) {
                            $maxExistingOrderVal = max($existingOrders);
                        }
                        //  if (in_array($order, $existingOrders)) {
                        //     $db->rollBack();
                        //     $response = array('status' => false, 'msg' => "Order Value ( $order ) Already Exist.Please Try With Different Order Value.");
                        //     return $response;
                        // }
                    } */
                    $dataSave = array(
                        // 'course_id' => (int) $courseId,
                        'type' => (int) $type,
                        'question' => $question,
                        'answer' => $answer,
                        // 'orderNo' => (int) $order,
                        'training_id' => (int) $trainingTypeId,
                        'status' => 1,
                        'jump_to_section' => !empty($jumpToSection) ? $jumpToSection : 0,
                        'is_b2c' => 1
                    );
                    /* if ((int) $type === BaseApp_Dao_CityPage::CITY_PAGE_EXAM_CERTIFICATION) {
                        $dataSave['is_b2c'] = 1;
                    } */
                    $objCourseFaq = new Model_CourseFaq();
                    $status = $objCourseFaq->setFromArray($dataSave)->save();
                    if ($status) {
                        $courseCityFaqId = (int) $objCourseFaq->course_faq_id;
                        /**
                         * Mapping Of Lookup Id and City Course Faq Id
                         */
                        if ($courseCityLookupId && $courseCityFaqId) {
                            $newOrder = $maxExistingOrderVal + 1;
                            $courseResourceMappingData = array('lookup_id' => $courseCityLookupId, 'faq_id' => $courseCityFaqId, 'order' => (int) $newOrder, 'status' => 1);
                            if ($objCourseResourceMapping->setFromArray($courseResourceMappingData)->save()) {
                                $mapId = (int) $objCourseResourceMapping->id;
                                $response = array('status' => true, 'msg' => 'Success', 'data' => array('map_id' => $mapId, 'order' => (int) $newOrder, 'faq_id' => $courseCityFaqId, 'lookup_id' => $courseCityLookupId));
                                $db->commit();
                            }
                        }
                    }
                }
            } catch (Exception $e) {
                $db->rollBack();
                $response = array('status' => false, 'msg' => $e->getMessage());
            }
            return $response;
        }
    }

    public function getAllCourseCity() {
        $result = parent::getCourseCities();
        return $result;
    }
    
    public function getAllBundleCities() {
        $result = parent::getBundleCities();
        return $result;
    }

    public function checkIfOrderValueExist($courseId, $trainingTypeId, $type, $lookupIds, $lowerCloneLimit, $upperCloneLimit) {
        $objCourseResourceMapping = new Model_CourseResourceMapping();
        $result = $objCourseResourceMapping->getChildOrder($courseId, $trainingTypeId, $type, $lookupIds, $lowerCloneLimit, $upperCloneLimit);
        $newOrderValue = $lowerCloneLimit + BaseApp_Dao_CityPage::CLONE_QUESTION_INCREMENT_COUNTER;
        if (!empty($result)) {
            $orderList = array_column($result, 'order');
            $orderList = array_unique($orderList);
            $maxOrder = max($orderList);
            $newOrderValue = $maxOrder + BaseApp_Dao_CityPage::CLONE_QUESTION_INCREMENT_COUNTER;
            $objCourseResourceMapping = new Model_CourseResourceMapping();
            $result = $objCourseResourceMapping->getChildOrder($courseId, $trainingTypeId, $type, $lookupIds);
            if (!empty($result)) {
                $orderList = array_column($result, 'order');
                if (in_array($newOrderValue, $orderList)) {
                    $lowerCloneLimit = $upperCloneLimit;
                    $upperCloneLimit = (int) $lowerCloneLimit + BaseApp_Dao_CityPage::COURSE_INCREMENT_COUNTER;
                    $cityPage = new Model_CityPage();
                    $newOrderValue = $this->checkIfOrderValueExist($courseId, $trainingTypeId, $type, $lookupIds, $lowerCloneLimit, $upperCloneLimit);
                }
            }
        }
        return $newOrderValue;
    }

    public function countryDataByCityId($cityIds = array()) {
        $result = array();
        if (is_array($cityIds)) {
            $result = parent::countryDataByCityId($cityIds);
        }
        return $result;
    }

}
