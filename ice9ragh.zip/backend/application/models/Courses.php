<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Model_Courses extends BaseApp_Dao_Courses{

    protected $certificateArr;

     public function saveSettings($courseId = null, $courseData) {
        try {
            $db = $this->getDb();
            $objCourse = new self();
            $db->beginTransaction();
            if (empty($courseId)) {
                $courseResult = $objCourse->setFromArray($courseData)->save();
                $courseId = $objCourse->course_id;
            } else {
                $objCourse->setId($courseId);
                $objCourse->setFromArray($courseData)->update();
            }
            $db->commit();
            return $courseId;
        } catch (Exception $e) {
            $db->rollBack();
            throw $e;
            return false;
        }
    }
    public function createCourse($courseData, $imageData){
        $db = $this->getDb();
        $objCourse = new self();
        $pageUrl = '';
        $db->beginTransaction();
        try{
            /** Video Info **/
            $videoInfoSave = array(
                'videoLink'=>$courseData['videoLink'],
                'videoThumbnail'=>$courseData['videoThumbnail'],
                'pre_run_video'=>$courseData['pre_run_video'],
                'flexi_pass_video'=>$courseData['flexi_pass_video'],
                'previewFromElearning'=>!empty($courseData['previewFromElearning']) ? $courseData['previewFromElearning'] : ""
            );
            if(isset($courseData['videoDescription']) && $courseData['videoDescription']){
                $videoInfoSave['videoDescription'] = $courseData['videoDescription'];
            }
            if (isset($courseData['dateCreated']) && $courseData['dateCreated']) {
                $videoInfoSave['dateCreated'] = $courseData['dateCreated'];
            }
            if (isset($courseData['displayName']) && $courseData['displayName']) {
                $videoInfoSave['displayName'] = $courseData['displayName'];
            }
            if (isset($courseData['duration']) && $courseData['duration']) {
                $videoInfoSave['duration'] = $courseData['duration'];
            }
            unset($courseData['videoLink']);
            unset($courseData['dateCreated']);
            unset($courseData['videoThumbnail']);
            unset($courseData['videoDescription']);
            unset($courseData['duration']);
            unset($courseData['pre_run_video']);
            unset($courseData['flexi_pass_video']);
            unset($courseData['previewFromElearning']);
            /** End of video info **/
            // remove the accreditor info from course object
            // and save it in the accreditorMapping table
            $accreditorOldArr = $courseData['accreditor_id'];
            $accreditorNewArr = $courseData['accreditor_id_new'];
            $introText = $courseData['intro_text'];
            $is_classroom_page = $courseData['is_classroom_page'];
            unset($courseData['accreditor_id']);
            unset($courseData['accreditor_id_new']);
            unset($courseData['intro_text']);
            unset($courseData['is_classroom_page']);

            if(isset($courseData['url'])) {
                $pageUrl = trim($courseData['url']);
                $checkSlash = substr($pageUrl, 0,1);
                if($checkSlash != '/'){
                    $pageUrl = trim('/'.$pageUrl);
                }
                $objCourse->setPageUrl($pageUrl);
                $courseData['courseUrl'] = $pageUrl;
                unset($courseData['url']);
            }
            $courseData['osl_exam_fee_included_update_time'] = date('Y-m-d H:i:s');
            $courseData['learners'] = rand(200,600);
            $courseResult = $objCourse->setFromArray($courseData)->save();
            $courseId = $objCourse->course_id;
            $paramsInfo = array(self::SEO_DEFAULT_PARAM_KEY=>$objCourse->course_id);
            if($is_classroom_page){
                $paramsInfo['is_classroom_page'] = 1;
            }
            $dataSave = array(
                'controller' => self::SEO_DEFAULT_CONTROLLER,
                'action' => self::SEO_DEFAULT_ACTION,
                'params' => json_encode($paramsInfo),
                'linkable_id' => $objCourse->course_id,
                'linkable_type' => 'course'
            );
            if(!empty($introText)) {
                $dataSave['course_intro_text'] = $introText;
            }
            $modelSeo = new Model_Seo();
            $seoData = $modelSeo->getDataByUrl($pageUrl);
            $modelSeo->setId($seoData['seo_id']);
            $modelSeo->setFromArray($dataSave)->update();

            $courseData['label_id'] = explode(",", $courseData['label_id']);
            $labelModel = new Model_Labels();
            $labelData = $labelModel->fetchAll(array('label_id IN (?)' => $courseData['label_id']), array('columns' => array('label_id', 'popularCourses')), false);
            foreach($labelData as $labelDataSingle) {
                if($labelDataSingle['popularCourses']) {
                   $labelDataSingle['popularCourses'] .= ','. $courseId;
                   $labelModel->setId($labelDataSingle['label_id']);
                   $labelModel->setFromArray($labelDataSingle)->update();
                }
            }
            $this->saveBasicImages($courseId, $imageData);
            // save accreditor info
            if (!empty($accreditorOldArr)) {
                $accreditorMappingObj = new Model_AccreditorMapping();
                foreach ($accreditorOldArr as $accreditorId) {
                    $accreditorRow = array();
                    $accreditorRow['accreditor_id']= $accreditorId;
                    $accreditorRow['accreditor_type']= BaseApp_Dao_AccreditorMapping::TYPE_CLASSIC_COURSE_PAGE;
                    $accreditorRow['linkable_type'] = 'course';
                    $accreditorRow['linkable_id'] = $courseId;
                    $accreditorMappingObj->setFromArray($accreditorRow)->save();
                }
            }
            if (!empty($accreditorNewArr)) {
                $accreditorMappingObj = new Model_AccreditorMapping();
                foreach ($accreditorNewArr as $accreditorId) {
                    $accreditorRow = array();
                    $accreditorRow['accreditor_id']= $accreditorId;
                    $accreditorRow['accreditor_type']= BaseApp_Dao_AccreditorMapping::TYPE_NEW_COURSE_PAGE;
                    $accreditorRow['linkable_type'] = 'course';
                    $accreditorRow['linkable_id'] = $courseId;
                    $accreditorMappingObj->setFromArray($accreditorRow)->save();
                }
            }
            // --
            $db->commit();
            // Video Info Save
            $this->saveVideoInfo($courseId,$videoInfoSave);
            return $courseId;
        }catch (Exception $e){
            $db->rollBack();
            throw $e;
            return false;
        }
    } // end of function createCourse
    
     

    public function updateCourse($courseId, $courseData, $imageData){
        //prd($courseData);
        $db = $this->getDb();
        $objCourse = new self();
        $db->beginTransaction();
        try{
            /** Video Info **/
            $videoInfoSave = array(
                'videoLink'=>$courseData['videoLink'],
                'videoThumbnail'=>$courseData['videoThumbnail'],
                'pre_run_video'=>$courseData['pre_run_video'],
                'flexi_pass_video'=>$courseData['flexi_pass_video'],
                'previewFromElearning'=>!empty($courseData['previewFromElearning']) ? $courseData['previewFromElearning'] : ""
            );
            if(isset($courseData['videoDescription']) && $courseData['videoDescription']){
                $videoInfoSave['videoDescription'] = $courseData['videoDescription'];
            }
            if (isset($courseData['dateCreated']) && $courseData['dateCreated']) {
                $videoInfoSave['dateCreated'] = $courseData['dateCreated'];
            }
            if (isset($courseData['displayName']) && $courseData['displayName']) {
                $videoInfoSave['displayName'] = $courseData['displayName'];
            }
            if (isset($courseData['duration']) && $courseData['duration']) {
                $videoInfoSave['duration'] = $courseData['duration'];
            }
            $is_classroom_page = $courseData['is_classroom_page'];
            unset($courseData['videoLink']);
            unset($courseData['dateCreated']);
            unset($courseData['videoThumbnail']);
            unset($courseData['videoDescription']);
            unset($courseData['duration']);
            unset($courseData['pre_run_video']);
            unset($courseData['flexi_pass_video']);
            unset($courseData['previewFromElearning']);
            unset($courseData['is_classroom_page']);
            /** End of video info **/
            
            $modelSeo = new Model_Seo();
            // Course Routes Update
            $seoDataCourseInfo = $modelSeo->getSeoDetails($courseId, array('course','course_city'));
            foreach($seoDataCourseInfo as $seoDataCourse){
                $dataSave = array();
                $seoDataUpdate = false;
                if($seoDataCourse['linkable_type'] == 'course'){
                    // Update course intro text
                    $dataSave = array(
                        'course_intro_text' => empty($courseData['intro_text'])?'':$courseData['intro_text'],
                    );
                    $seoDataUpdate = true;
                }
                $seoParams = json_decode($seoDataCourse['params'],true);
                $routeParamUpdated = false;
                if($is_classroom_page){
                    $seoParams['is_classroom_page'] = 1;
                    $routeParamUpdated = true;
                }else if(isset($seoParams['is_classroom_page']) && $seoParams['is_classroom_page'] == 1){
                    unset($seoParams['is_classroom_page']);
                    $routeParamUpdated = true;
                }

                if($routeParamUpdated){
                    $dataSave['params'] = json_encode($seoParams);
                }
                if($seoDataUpdate || $routeParamUpdated){
                    if(empty($seoDataCourse) || empty($seoDataCourse['seo_id'])) {
                        throw new Exception('Seo url mapping failed');
                    }
                    $modelSeo->setId($seoDataCourse['seo_id']);
                    $modelSeo->setFromArray($dataSave)->update();
                }
            }
            unset($courseData['intro_text']);

            // remove the accreditor info from course object
            // and save it in the accreditorMapping table
            $accreditorArr = $courseData['accreditor_id'];
            $accreditorNewArr = $courseData['accreditor_id_new'];
            unset($courseData['accreditor_id']);
            unset($courseData['accreditor_id_new']);

            $objCourse->setId($courseId);
            if(isset($courseData['label_id'])) {
                $oldLabels = explode(",", trim($objCourse->label_id));
                $newLabels = explode(",", trim($courseData['label_id']));
                $missingLabels = array_diff($oldLabels, $newLabels);
                foreach($missingLabels as $labelId) {
                    $this->removeCourseInLabelFlyout($labelId, $courseId);
                }
            }
            if(isset($courseData['osl_exam_fee_included'])
                    && $objCourse->getData('osl_exam_fee_included') != $courseData['osl_exam_fee_included']) {
                $courseData['osl_exam_fee_included_update_time'] = date('Y-m-d H:i:s');
            }
            $objCourse->setFromArray($courseData)->update();
            $this->saveBasicImages($courseId, $imageData);

            // delete old info and save new accreditor info
            $accreditorMappingObj = new Model_AccreditorMapping();
            $conds = array(
                'linkable_id=?' => $courseId,
                'linkable_type=?' => 'course',
            );
            $courseAccreditorArr = $accreditorMappingObj->fetchAll($conds);
            // delete
            if(!empty($courseAccreditorArr)) {
                foreach($courseAccreditorArr as $courseAccreditorRow){
                    $accreditorMappingObj->clean();
                    $accreditorMappingObj->setId($courseAccreditorRow['id']);
                    $accreditorMappingObj->delete();
                }
            }
            // add
            if(!empty($accreditorArr)) {
                foreach ($accreditorArr as $accreditorId) {
                    $accreditorRow = array();
                    $accreditorRow['accreditor_id']= $accreditorId;
                    $accreditorRow['accreditor_type']= BaseApp_Dao_AccreditorMapping::TYPE_CLASSIC_COURSE_PAGE;
                    $accreditorRow['linkable_type'] = 'course';
                    $accreditorRow['linkable_id'] = $courseId;
                    $accreditorMappingObj->setFromArray($accreditorRow)->save();
                }
            }
            if(!empty($accreditorNewArr)) {
                foreach ($accreditorNewArr as $accreditorId) {
                    $accreditorRow = array();
                    $accreditorRow['accreditor_id']= $accreditorId;
                    $accreditorRow['accreditor_type']= BaseApp_Dao_AccreditorMapping::TYPE_NEW_COURSE_PAGE;
                    $accreditorRow['linkable_type'] = 'course';
                    $accreditorRow['linkable_id'] = $courseId;
                    $accreditorMappingObj->setFromArray($accreditorRow)->save();
                }
            }
            // --
            $db->commit();
            // Video Info Save 
            $this->saveVideoInfo($courseId,$videoInfoSave);
            return $courseId;
        }catch (Exception $e){
            $db->rollBack();
            throw $e;
            return false;
        }
    } // end of function createCourse

    public function saveVideoInfo($courseId,$data) {
        $vidObj = new Model_Videos();
        $preRunData = $vidObj->getByCourse($courseId, FALSE, 'pre_run_video');
        $preRunArray = array(
            'course_id' => $courseId,
            'name' => 'pre_run_video',
            'videoLink' => empty($data['pre_run_video']) ? '' : $data['pre_run_video'],
        );
        if (empty($preRunData) && !empty($data['pre_run_video'])) {
            $vidObj->createVideo($preRunArray);
        } elseif (!empty($preRunData)) {
            $preRunArray['video_id'] = $preRunData['video_id'];
            $vidObj->updateVideo($preRunArray);
        }
        $abtFlexiPass = $vidObj->getByCourse($courseId, FALSE, 'flexi_pass_video');
        $abtFlexiArray = array(
            'course_id' => $courseId,
            'name' => 'flexi_pass_video',
            'videoLink' => empty($data['flexi_pass_video']) ? '' : $data['flexi_pass_video'],
        );
        if (empty($abtFlexiPass) && !empty($data['flexi_pass_video'])) {
            $vidObj->createVideo($abtFlexiArray);
        } elseif (!empty($abtFlexiPass)) {
            $abtFlexiArray['video_id'] = $abtFlexiPass['video_id'];
            $vidObj->updateVideo($abtFlexiArray);
        }
        if ($data['videoLink']) {
            $courseData = $this->getCourseById($courseId);
            //prd($courseData);
            // add or edit course intro video
            $objVideos = new Model_Videos();
            $videosArr = array(
                'course_id' => $courseId,
                'name' => 'about_course',
                'videoLink' => $data['videoLink'],
                'thumbnailImage' => $data['videoThumbnail'],
                'training_id' => 0
            );
            if(isset($data['videoDescription']) && $data['videoDescription']){
                $videosArr['shortDescription'] = $data['videoDescription'];
            }
            if (isset($data['dateCreated']) && $data['dateCreated']) {
                $videosArr['dateCreated'] = $data['dateCreated'];
            }
            if (isset($data['displayName']) && $data['displayName']) {
                $videosArr['displayName'] = $data['displayName'];
            }
            if (isset($data['duration']) && $data['duration']) {
                $videosArr['duration'] = $data['duration'];
            }
            if ($videoExists = $objVideos->getByCourse($courseId, 0, 'about_course')) {
                $videosArr['video_id'] = $videoExists['video_id'];
                $objVideos->clean();
                $objVideos->setId($videosArr['video_id']);
                $resultUpdate = $objVideos->setFromArray($videosArr)->update();
                if (!empty($videosArr['video_id']) && !empty($courseData['primary_label_id']) &&  !empty($data['videoThumbnail'])) {
                    $this->_saveVideoSeo($videosArr['video_id'], $courseData['primary_label_id'], $data['videoThumbnail']);
                }
            } else {
                $objVideos->clean();
                $resultInsert = $objVideos->setFromArray($videosArr)->save();
                if ($resultInsert) {
                    $this->_saveVideoSeo($objVideos->video_id, $courseData['primary_label_id'], $data['videoThumbnail']);
                }
            }
        } else {
            // Delete course intro video
            $objVideos = new Model_Videos();
            $objVideos->deleteCourseIntroVideo($courseId);
        }
        return;
    }
    public function removeCourseInLabelFlyout($labelId, $courseId) {
        $objLabel = new Model_Labels();
        $objLabel->clean();
        $objLabel->setId($labelId);
        $popularCourses = explode(",", trim($objLabel->popularCourses));
        $recentCourses = explode(",", trim($objLabel->recentCourses));
        $indexKey = array_search($courseId, $popularCourses);
        $isChanged = false;
        if($indexKey !== false) {
            unset($popularCourses[$indexKey]);
            $isChanged = true;
        }
        $indexKey = array_search($courseId, $recentCourses);
        if($indexKey !== false) {
            unset($recentCourses[$indexKey]);
            $isChanged = true;
        }
        if($isChanged) {
            $popularCourses = implode(",", $popularCourses);
            $recentCourses = implode(",", $recentCourses);
            $objLabel->setFromArray(array('popularCourses' => $popularCourses, 'recentCourses' => $recentCourses))->update();
        }
        return true;
    }

    public function saveBasicImages($linkableId, $imageData, $linkableType = "course") {
        $objImaegs = new Model_Images();
        $imageDataExistsing = $objImaegs->getInclusionImages($linkableId,$linkableType);
        foreach ($imageData as $key => $imageValue) {
            $objImaegs->clean();
            if(!$imageValue['linkable_id']) {
                $imageValue['linkable_id'] = $linkableId;
            }
            if(isset($imageDataExistsing[$imageValue['name']])) {
                $objImaegs->setId($imageDataExistsing[$imageValue['name']]['image_id']);
                $objImaegs->setFromArray($imageValue)->update();
            }
            else {
                $objImaegs->setFromArray($imageValue)->save();
            }
        }
    }

    public function saveCourseSections($sectionData, $courseId){
        $db = $this->getDb();
        $db->beginTransaction();
        try{
            //delete all course sections before saving the new ones.        
            $courseSection = new Model_CourseSections();
            $courseSection->deleteWhere(array('course_id = ?' => $courseId));
            foreach($sectionData as $trainingId => $sectionData) {
                if (!empty($sectionData)){
                    foreach($sectionData as $sectionId => $templateData){
                        if (!empty($templateData)){
                            $objCourseSection = new Model_CourseSections();
                            $objCourseSection->course_id = $courseId;
                            $objCourseSection->training_id = $trainingId;
                            $objCourseSection->section_id = $sectionId;
                            $objCourseSection->name = $templateData['name'];
                            $objCourseSection->menuItem = $templateData['menuItem'];
                            $objCourseSection->orderNo = $templateData['orderNo'];
                            $objCourseSection->status = 1;//hard coding the satus          

                            $objCourseSection->sticky_title = !empty($templateData['sticky_title'])?$templateData['sticky_title'] :'';
                            $objCourseSection->sticky_on = !empty($templateData['sticky_on'])?$templateData['sticky_on']:0;
                            $objCourseSection->content_title_key = !empty($templateData['content_title_key'])?$templateData['content_title_key']:'';
                            $objCourseSection->sticky_status = $templateData['sticky_status'];
                            $objCourseSection->header_suffix = $templateData['header_suffix'];
                            $objCourseSection->save();
                        }
                    }       
                }                         
            }
            $db->commit();
            return true;
        }catch (Exception $e){
            $db->rollBack();
            throw $e;
            return false;
        }
    }


    // public function courseSection($sectionData,$courseId){
    //     $db = $this->getDb();
    //     $objCourse = new self($courseId);
    //     $db->beginTransaction();
    //     try{
    //         $modelSection = new Model_SectionTemplates();
    //         $templateData = $modelSection->getTemplates();

    //         foreach($sectionData as $trainingId => $dataSave) {
    //             $this->loopSectionData($templateData, $dataSave, $courseId, $trainingId);
    //         }
    //         $db->commit();
    //         return true;
    //     }catch (Exception $e){
    //         $db->rollBack();
    //         throw $e;
    //         return false;
    //     }
    // } // end of function courseSection

    public function getNameById($courseId){
        $objCourse = new self();
        $data = current($objCourse->fetchAll( array('course_id = ?'=>$courseId, 'is_dummy = ?' => 0, 'is_free = ?' => 0), array('columns'=>array('name')), false));
        return $data['name'];
    }

    public function getByPartName($partName) {
        return $this->fetchAll( array('name LIKE ?'=>'%'.$partName.'%', 'is_dummy = ?' => 0, 'is_free = ?' => 0), array(), false);
    }

    public function getCourseById($courseId) {
        $objCourse = new self();
        return current($objCourse->fetchAll( array('course_id = ?'=>$courseId), array(), false));
    }
    public function getCourseByIdMultiple($courseIds) {
        $return = array();
        if(!$courseIds) {
            return $return;
        }
        $objCourse = new self();
        foreach ($objCourse->fetchAll(array('course_id IN (?)'=>$courseIds), array(), false) as $courseData) {
            $return[$courseData['course_id']] = $courseData['name'];
        }
        return $return;
    }
    public function getCourseDetailsByIds($courseIds) {
        $return = array();
        if(!$courseIds) {
            return $return;
        }
        $objCourse = new self();
        foreach ($objCourse->fetchAll(array('course_id IN (?)'=>$courseIds), array(), false) as $courseData) {
            $data = array();
            $data['name'] = $courseData['name'];
            $data['courseId'] = (int)$courseData['course_id'];
            $data['elearningId'] = (int)$courseData['primary_eLearning_id'];
            $return[] = $data;
        }
        return $return;
    }



    public function getbyLables($labelIds) {
        $labelIdsReal = array();
        foreach($labelIds as $labelId) {
            if(!$labelId) {
                continue;
            }
            $labelIdsReal[] = $labelId;
        }
        if(!$labelIdsReal) {
            return array();
        }
        $objCourse = new self();
        $conds = array(
            'is_dummy = ?' => 0,
            'is_free = ?' => 0,
            'FIND_IN_SET(?, label_id)>0' => new Zend_Db_Expr(implode(', label_id)>0 OR FIND_IN_SET(',$labelIdsReal))
        );
        return $objCourse->fetchForSelect($conds);
    }
    public function getCoursesbyLables($labelIds)
    {
        $labelIdsReal = $data = $return = array();
        foreach ($labelIds as $labelId) {
            if (!$labelId) {
                continue;
            }
            $labelIdsReal[] = $labelId;
        }
        $objCourse = new self();
        $conds = array(
            'is_dummy = ?' => 0,
            'is_free = ?' => 0,
        );
        if (count($labelIdsReal) > 0) {
            $conds['FIND_IN_SET(?, label_id)>0'] = new Zend_Db_Expr(implode(', label_id)>0 OR FIND_IN_SET(', $labelIdsReal));
        }
        return $objCourse->fetchForSelect($conds);
    }
    public function fetchbyLables($labelIds=array()) {
        $labelIdsReal = $data = $return = array();
        foreach($labelIds as $labelId) {
            if(!$labelId) {
                continue;
            }
            $labelIdsReal[] = $labelId;
        }
        $objCourse = new self();
        $conds = array(
            'is_dummy = ?' => 0,
            'is_free = ?' => 0,
        );
        if(count($labelIdsReal)>0){
            $conds['FIND_IN_SET(?, label_id)>0'] = new Zend_Db_Expr(implode(', label_id)>0 OR FIND_IN_SET(',$labelIdsReal));
        }
        $data = $objCourse->fetchForSelect($conds);
        if (!empty($data)) {
            uasort($data, function ($a, $b) {
                return strcmp($a, $b);
            });
            foreach ($data as $key => $value) {
                $return[$key] = $key . ' - ' . $value;
            }
        }
        return $return;
    }

    public function getDispalyWiseSortedCourse(){
        $courseModel = new self();
        $sql=$courseModel->getDb()->select()->from('courses', array('courses.course_id'))
            ->join('labels', 'labels.label_id=courses.label_id',array())
            ->join('pricings', 'pricings.course_id=courses.course_id',array())->order('labels.designOrderNo desc')
            ->where( 'courses.status=?', '1')->where( 'courses.is_dummy=?', '0')->where( 'courses.is_free=?', '0')->where('labels.status=?', '1')->where('pricings.training_id=?', BaseApp_Dao_TrainingTypes::TYPE_ELEARNING)->group('courses.course_id');
        $return = $courseModel->getDb()->fetchAll($sql);
        return $return;
    }

    public function getCoursesByPricing($data = array())
    {
        $response = array();
        $courseModel = new self();
        $sql=$courseModel->getDb()->select()->from('courses', array('courses.course_id','courses.name'))
            ->join('labels', 'labels.label_id=courses.primary_label_id', array('labels.label_id'))
            ->join('pricings', 'pricings.course_id=courses.course_id', array('free_trial'))
            ->order('labels.label_id asc')
            ->order('courses.name asc')
            ->where('courses.status=?', '1')
            ->where('courses.hideFromSearch=?', '0')
            ->where('courses.is_dummy=?', '0')
            ->where('courses.is_free=?', '0')
            ->where('labels.status=?', '1')
            ->group('courses.course_id')
            ->where('pricings.status = ?', 1);
        if (!empty($data['label_id']) && $data['label_id'] != '') {
            $sql = $sql->where('labels.label_id=?', $data['label_id']);
        }
        if (!empty($data['training_id']) && !is_array($data['training_id'])) {
            $sql = $sql->where('pricings.training_id=?', $data['training_id']);
        } else if (!empty($data['training_id']) && is_array($data['training_id'])) {
            $sql = $sql->where('pricings.training_id IN (?)', $data['training_id']);
        }
        if (!empty($data['cluster_id']) && $data['cluster_id'] != '' && empty($data['country_id'])) {
            $sql = $sql->where('pricings.cluster_id = ?', $data['cluster_id']);
        }
        if (!empty($data['country_id']) && $data['country_id'] != '') {
            $sql = $sql->where('pricings.country_id = ?', $data['country_id']);
        }
        $return = $courseModel->getDb()->fetchAll($sql);
        if (!empty($return)) {
            foreach ($return as $key => $value) {
                if (!empty($data['free_trial']) && $value['free_trial'] == 1) {
                    $value['name'] .= '#1';
                }
                $response[$value['course_id']] = $value['name'];
            }
        }
        return $response;
    }
    public function getTotalElearningHours($courseId){
        $courseModel = new self();
        $sql=$courseModel->getDb()->select()->from('courses', array('courses.totalDuration'))
            ->where( 'courses.status=?', '1')
            ->where( 'courses.course_id=?', $courseId);
        $return = $courseModel->getDb()->fetchAll($sql);
        return $return;
    }

    public function getCourseByTrainingTypeId($trainingTypeId,$courseId,$checkApproved=0){
        if(!is_numeric($trainingTypeId) || !$trainingTypeId ){
            throw new BaseApp_Exception_Notice('Insufficient parameter passed! trainingType_id and course_id expected');
        }
        // need to add checkApproved condition
        $return = array();
        $courseModel = new self();
        $sql=$courseModel->getDb()->select()->from('courses', array('courses.course_id','courses.name'))
            ->join('trainingRelations', 'trainingRelations.linkable_id=courses.course_id',array())
            ->where('trainingRelations.linkable_type=?', 'course')
            ->where('trainingRelations.linkable_id=?', $courseId)
            ->where('courses.is_dummy=?', 0)
            ->where('courses.is_free = ?', 0)
            ->where('trainingRelations.training_id=?', $trainingTypeId);
        $courseData = $courseModel->getDb()->fetchAll($sql);
        foreach($courseData as $package){
            $return[$package['course_id']]=$package['name'].' [package_id-'.$package['course_id'].']';
        }
        return $return;
    }


    public function getTrainingTypeForCountryCityCourse($courseId,$countryId,$cityId){
        $courseModel = new self();
        $courseData = array();
        $sql=$courseModel->getDb()->select()->from('courses', array('courses.course_id'))
            ->join('workshop', 'workshop.course_id=courses.course_id',array())
            ->where('workshop.country_id=?', $countryId)
            ->where('workshop.training_id=?', BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM)
            ->where('workshop.city_id=?', $cityId)
            ->where('courses.is_dummy=?', 0)
            ->where('courses.is_free = ?', 0)
            ->where('courses.course_id=?', $courseId);
        $courseData = $courseModel->getDb()->fetchAll($sql);
        if(!empty($courseData)){
            return true;
        }

        $objCity = new Model_City();
        $cityData = $objCity->getCityDetailsByCityIdForInvoice($cityId);
        if(!empty($cityData)){
            $cityData = $cityData[0];
            $altCityId = $cityData['workshopCities'];
            if(!empty($altCityId)){
                $altCityId = explode(',',$altCityId);
                $sql=$courseModel->getDb()->select()->from('courses', array('courses.course_id'))
                    ->join('workshop', 'workshop.course_id=courses.course_id',array())
                    ->where('workshop.country_id=?', $countryId)
                    ->where('workshop.city_id in (?)', $altCityId)
                    ->where('workshop.training_id=?', BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM)
                    ->where('courses.is_dummy=?', 0)
                    ->where('courses.is_free = ?', 0)
                    ->where('courses.course_id=?', $courseId);
                $courseData = $courseModel->getDb()->fetchAll($sql);
                if(!empty($courseData)){
                    return true;
                }
            }
        }
        $sql=$courseModel->getDb()->select()->from('courses', array('courses.course_id'))
            ->join('workshop', 'workshop.course_id=courses.course_id',array())
            ->where('workshop.country_id=?', $countryId)
            ->where('courses.course_id=?', $courseId)
            ->where('courses.is_dummy=?', 0)
            ->where('courses.is_free = ?', 0)
            ->where('workshop.training_id=?', BaseApp_Dao_TrainingTypes::TYPE_LVC);
        $courseData = $courseModel->getDb()->fetchAll($sql);
        if(empty($courseData)){
            return false;
        }else{
            return true;
        }
    }


    public function fetchCourseDetails($courseId){
            $courseModel = new self();
            $sql = $courseModel->getDb()->select()->from('courses as co',
                                                        array(  'co.*',
                                                                'im.imagePath as courseImageUrl',
                                                                'acc.imagePath as accreditationLogo'
                                                             )
                                                 )
                         ->join('images as im','im.linkable_id=co.course_id',array())
                         ->joinLeft('accreditors as acc','acc.accreditor_id=co.accreditor_id',array())
                         ->joinLeft(array('s' => 'seo'),'s.linkable_id=co.course_id', array('course_url' => 'url'))
                         ->where('co.course_id = ? ',$courseId)
                         ->where('im.linkable_id = ? ',$courseId)
                         ->where('im.linkable_type = ?','course')
                         ->where('im.name = ?','image_home_page')
                         ->where('s.linkable_type=?', "course")
                         ->where('s.controller = ?', BaseApp_Dao_Courses::SEO_DEFAULT_CONTROLLER)
                         ->where('s.action = ?', BaseApp_Dao_Courses::SEO_DEFAULT_ACTION)
                         ->where('s.status = ?', 1)
                         ->group('co.course_id');
        $courseData = $courseModel->getDb()->fetchAll($sql);
        return $courseData;
    }
    
    
    public function fetchCourseCertDesc($courseId,$trainingType = 'completionImage1'){
        $courseModel = new self();
            $sql = $courseModel->getDb()->select()->from('courses as co',
                                                        array(
                                                                'im.imageDescription'
                                                             )
                                                 )
                         ->join('images as im','im.linkable_id=co.course_id',array())
                         ->where('co.course_id = ? ',$courseId)
                         ->where('co.is_dummy = ? ', 0)
                         ->where('co.is_free = ?', 0)
                         ->where('im.linkable_id = ? ',$courseId)
                         ->where('im.linkable_type = ?','course')
                         ->where('im.name =?',$trainingType);
        $courseData = $courseModel->getDb()->fetchAll($sql);
        return $courseData;
    }

    public function _afterFetchAll($data){
        $labels =array();
        $accreditor = array();
        $vendor = array();
        $objAcc = new Model_AccreditorMapping();
        foreach($data as $key => $row) {
            if(@$row['primary_label_id']) {
                $labels[] = $row['primary_label_id'];
            }
            if(@$row['label_id']) {
                 $labels = array_merge($labels, explode(",", $row['label_id']));
            }
            if(isset($row['course_id']) && !empty($row['course_id']))
                $accDetails = current($objAcc->fetchAll(array('linkable_id = ?'=>$row['course_id'],'linkable_type =?'=>'course')));
            if(!empty($accDetails)){
                $accreditor[] = $accDetails['accreditor_id'];
                $data[$key]['accreditor_id'] = $accDetails['accreditor_id'];
            }
            if(@$row['vendor_id']) {
                $vendor[] = $row['vendor_id'];
            }
        }

        if($labels) {
            $labelMode = new Model_Labels();
            $labelMode->setFetchDisabled(true);
            $labels = $labelMode->fetchForSelect(array('label_id IN (?)' => $labels));
            $labelMode->setFetchDisabled(false);
        }
        if($accreditor) {
            $modelAcr = new Model_Accreditors();
            $accreditor = $modelAcr->fetchForSelect(array('accreditor_id IN (?)'=>$accreditor));
        }
        if($vendor) {
            $modelVendor = new Model_Vendors();
            $vendor = $modelVendor->fetchForSelect(array('vendor_id IN (?)'=>$vendor));
        }
        foreach($data as &$row) {
            if(@$row['primary_label_id']) {
                $row['primary_label'] = isset($labels[$row['primary_label_id']])? $labels[$row['primary_label_id']]:'';
            }

            if(@$row['label_id']) {
                $label = explode(",", $row['label_id']);
                foreach($label as $labelId) {
                    $row['labels'][] = isset($labels[$labelId]) ? $labels[$labelId] : '';
                }
                $row['labels'] = implode(", ", $row['labels']);
            }
            if(@$row['accreditor_id']) {
                $row['accreditor'] = @$accreditor[$row['accreditor_id']];
            }

            if(@$row['vendor_id']) {
                $row['vendor'] = @$vendor[$row['vendor_id']];
            }
        }

        return $data;
    }

    public function getAllCoursesByTrainingType($trainingIds=array()){
        if(!$trainingIds) {
            return array();
        }
        $modelRelation = new Model_TrainingRelations();
        $conds = array(
            'linkable_type=?' => 'course',
            'training_id IN (?)' => $trainingIds
        );
        $options = array(
            'columns' => array(
                'linkable_id'
            )
        );
        $courseIds = array();
        foreach($modelRelation->fetchAll($conds, $options, false) as $relationData) {
            $courseIds[] = $relationData['linkable_id'];
        }
        if(!$courseIds) {
            return array();
        }
        return $this->fetchForSelect(array('course_id IN (?)'=>$courseIds, 'is_dummy = ?' => 0, 'is_free = ?' => 0));
    }

   public function deleteCourse($courseId, &$message='') {
        $db = $this->getDb();
        $courseObj = new self();

        $db->beginTransaction();

        $linkableType = 'course';

        // delete pricing
        $modelPrice = new Model_Pricings();
        foreach($modelPrice->fetchAll(array('course_id=?'=>$courseId), array('columns' => 'pricing_id'), false) as $pricingData) {
            $modelPrice->clean();
            $modelPrice->setId($pricingData['pricing_id']);
            if(!$modelPrice->delete()) {
                $db->rollBack();
                $message = "failed to delete pricing data:{$pricingData['pricing_id']}";
                return false;
            }
        }

        // delete seo
        $objSeo = new Model_Seo();
        foreach($objSeo->fetchAll(array('linkable_id=?'=>$courseId, 'linkable_type=?'=>$linkableType), array('columns' => 'seo_id'), false) as $seoData) {
            $objSeo->clean();
            $objSeo->setId($seoData['seo_id']);
            if(!$objSeo->delete()) {
                $db->rollBack();
                $message = "failed to delete seo data:{$seoData['seo_id']}";
                return false;
            }
        }

        // delete TrainingRelations
        $objrelation = new Model_TrainingRelations();
        foreach($objrelation->fetchAll(array('linkable_id=?'=>$courseId, 'linkable_type=?'=>$linkableType), array('columns' => 'training_relation_id'), false) as $relationData) {
            $objrelation->clean();
            $objrelation->setId($relationData['training_relation_id']);
            if(!$objrelation->delete()) {
                $db->rollBack();
                $message = "failed to delete training relation data:{$relationData['training_relation_id']}";
                return false;
            }
        }

        // delete course section
        $sectionObj = new Model_CourseSections();
        foreach($sectionObj->fetchAll(array('course_id=?'=>$courseId), array('columns' => array('course_section_id')), false) as $sectionData) {
            $sectionObj->clean();
            $sectionObj->setId($sectionData['course_section_id']);
            if(!$sectionObj->delete()) {
                $db->rollBack();
                $message = "failed to delete section data:{$sectionData['course_section_id']}";
                return false;
            }
        }

        // delete inclusions
        $inclusionObj = new Model_CourseInclusions();
        foreach($inclusionObj->fetchAll(array('course_id=?'=>$courseId), array('columns' => array('course_inclusion_id')), false) as $inclusionData) {
            $inclusionObj->clean();
            $inclusionObj->setId($inclusionData['course_inclusion_id']);
            if(!$inclusionObj->delete()) {
                $db->rollBack();
                $message = "failed to delete inclusion data:{$inclusionData['course_inclusion_id']}";
                return false;
            }
        }

        // delete course faq
        $faqObj = new Model_CourseFaq();
        foreach($faqObj->fetchAll(array('course_id=?'=>$courseId), array('columns' => array('course_faq_id')), false) as $faqData) {
            $faqObj->clean();
            $faqObj->setId($faqData['course_faq_id']);
            if(!$faqObj->delete()) {
                $db->rollBack();
                $message = "failed to delete faq data:{$faqData['course_faq_id']}";
                return false;
            }
        }

        // delete videos
        $videoObj = new Model_Videos();
        foreach($videoObj->fetchAll(array('course_id=?'=>$courseId), array('columns' => array('video_id')), false) as $videoData) {
            $videoObj->clean();
            $videoObj->setId($videoData['video_id']);
            if(!$videoObj->delete()) {
                $db->rollBack();
                $message = "failed to delete faq data:{$videoData['video_id']}";
                return false;
            }
        }

        // delete images
        $objImages = new Model_Images();
        foreach($objImages->fetchAll(array('linkable_id=?'=>$courseId, 'linkable_type=?'=>$linkableType), array('columns' => 'image_id'), false) as $imageData) {
            $objImages->clean();
            $objImages->setId($imageData['image_id']);
            if(!$objImages->delete()) {
                $db->rollBack();
                $message = "failed to delete image data:{$imageData['image_id']}";
                return false;
            }
        }



        // delete from popular courses
        $labelIds = current($this->fetchAll(array('course_id=?'=>$courseId), array('columns' => array('label_id')), false));
        $labelIds = explode(",", $labelIds['label_id']);
        $labelModel = new Model_Labels();
        $labelData = $labelModel->fetchAll(array('label_id IN (?)' => $labelIds), array('columns' => array('label_id', 'popularCourses')), false);
        foreach($labelData as $labelDataSingle) {
            if($labelDataSingle['popularCourses']) {
               $labelDataSingle['popularCourses'] = explode(",", $labelDataSingle['popularCourses']);
               $indexTemp = array_search($courseId, $labelDataSingle['popularCourses']);
               if($indexTemp !== false) {
                   unset($labelDataSingle['popularCourses'][$indexTemp]);
                   $labelDataSingle['popularCourses'] = implode(",", $labelDataSingle['popularCourses']);
                   $labelModel->setId($labelDataSingle['label_id']);
                   $labelModel->setFromArray($labelDataSingle)->update();
               }
            }
        }

        //delete course
        $courseObj->clean();
        $courseObj->setId($courseId);
        if(!$courseObj->delete()) {
            $db->rollBack();
            $message = "failed to delete course";
            return false;
        }
        $db->commit();
        return true;
    }


    public function getCoursesForTrainingType($trainingArr){
        $courseModel = new self();
        $returnArr = array();
        $sql= $courseModel->getDb()->select()->from('courses', array('courses.course_id','courses.name','courses.displayName','eLearning_id' => 'courses.primary_eLearning_id','courses.learners','courses.rating','courses.courseAgenda','courses.certificateCode','courses.pduNumber','courses.courseCode','courses.certificateName'))
            ->join('trainingRelations', 'trainingRelations.linkable_id=courses.course_id',array())
            ->where('trainingRelations.linkable_type=?', 'course')
            ->where('courses.is_dummy=?', 0)
            ->where('courses.is_free=?', 0)
            ->where('trainingRelations.training_id IN (?)', $trainingArr)
            ->group('courses.course_id');
        $courseData = $courseModel->getDb()->fetchAll($sql);
        if(!empty($courseData)){
            foreach($courseData as $row => $course){
                foreach ($course as $key => $value) {
                    if($key != 'course_id')
                        $tempArr[$key] = $value;
                }
                $returnArr[$course['course_id']] = $tempArr;
            }
            return $returnArr;
        }else{
            return $returnArr;
        }
    }

    public function isErpCourse($courseIds) {
        $conds = array(
            'is_dummy = ?' => 0,
            'is_free = ?' => 0,
            'course_id IN (?)' => $courseIds,
            'FIND_IN_SET(?, label_id)>0' => BaseApp_Controller_Action::ERP_CATEGORY_ID
        );
        if($this->fetchAll($conds, array(), false)) {
            return true;
        }
        return false;
    }

    public function fetchAllCoursesByTrainingId($trainingId,$isB2b = '',$getElearningId='', $includeDisabledCourses = ''){
        $courseModel = new self();
        $returnArr = array();
        if($trainingId != BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM){
            $sql= $courseModel->getDb()->select()->from('courses', array('courses.course_id','courses.displayName','courses.primary_eLearning_id', 'course_available_for'))
            ->join('trainingRelations', 'trainingRelations.linkable_id = courses.course_id',array())
            ->join('pricings', 'pricings.course_id = courses.course_id',array())
            ->where('trainingRelations.linkable_type=?', 'course')
            ->where('courses.is_dummy=?', 0)
            ->where('courses.status <> ?', 0)
            ->where('trainingRelations.status <> ?', 0)
            ->where('pricings.status <> ?', 0)
            ->where('trainingRelations.training_id = ?', $trainingId)
            ->where('pricings.training_id = ?', $trainingId)
            ->group('courses.course_id');
        }else{
            $sql = $courseModel->getDb()->select()->from('courses', array('courses.course_id','courses.displayName','courses.primary_eLearning_id', 'course_available_for'))
            ->join('workshop', 'workshop.course_id = courses.course_id',array())
            ->where('courses.is_dummy=?', 0)
            ->where('courses.status <> ?', 0)
            ->where('workshop.status <> ?', 0)
            ->where('workshop.isSold <> ?', 1)
            ->where('workshop.startDate > now()')
            ->where('workshop.training_id = ?', $trainingId);
            if(empty($isB2b))
                $sql->where('workshop.isCorporate <> ?',0);
        }
        $sql->group('courses.course_id');
        $courseData = $courseModel->getDb()->fetchAll($sql);
        if(!empty($courseData)){
            if(empty($getElearningId)){
                foreach ($courseData as $courseKey => $courseValue) {
                   $returnArr[$courseValue['course_id']]  = $courseValue['displayName'];
                }
            }else{
                foreach ($courseData as $courseKey => $courseValue) {
                    if(!empty($courseValue['primary_eLearning_id']) || $courseValue['primary_eLearning_id'] != 0)
                        $returnArr[$courseValue['course_id']]  = array(
                                                                    'courseId' => $courseValue['course_id'],
                                                                    'courseName' => $courseValue['displayName'],
                                                                    'courseElearningId' => $courseValue['primary_eLearning_id'],
                                                                    'disabledCourse' => 0,
                                                                    'available_for' => $courseValue['course_available_for']
                                                                    );
                }
            }

        }

        // add disables courses to response data
        if($includeDisabledCourses == 1 && $getElearningId == 1) {
            $disabledCoursesSql = $courseModel->getDb()->select()->from('courses', array('courses.course_id','courses.displayName','courses.primary_eLearning_id', 'course_available_for'))
                    ->where('courses.status = ?', 0)
                    ->where('courses.is_dummy = ?', 0);
            $disabledCoursesData = $courseModel->getDb()->fetchAll($disabledCoursesSql);
            if(!empty($disabledCoursesData)) {
                foreach($disabledCoursesData as $courseKey => $courseValue) {
                    $returnArr[$courseValue['course_id']] = array(
                                                                'courseId' => $courseValue['course_id'],
                                                                'courseName' => $courseValue['displayName'],
                                                                'courseElearningId' => $courseValue['primary_eLearning_id'],
                                                                'disabledCourse' => 1,
                                                                'available_for' => $courseValue['course_available_for']
                                                                );
                }
            }
        }
        return $returnArr;
    }

    public function fetchCourseForElearning($id){
        return $this->fetchAll(array('primary_eLearning_id = ?' => $id, 'status = ?' => 1));

    }
    public function fetchCertificateForAllCourse(){
        $this->certificateArr = array();
        $coursesql = $this->getDb()->select()
            ->from('courses', array('courses.course_id','courses.displayName as course_display_name','courses.primary_eLearning_id', 'course_accreditor_id' => 'courses.accreditor_id', 'courses.old_eLearning_id'))
            ->where('courses.primary_eLearning_id <> ?', 0)
            ->where('courses.status = ?', 1)
            ->order(array('courses.course_id ASC'));

        $courseData = $this->getDb()->fetchAll($coursesql);
        if(empty($courseData)){
            return array();
        }

        $courseIdArr = array_column($courseData,'course_id');
        $certifcateSql = $this->getDb()->select()
            ->from('certificates',array('*'))
            ->join('trainingTypes', 'trainingTypes.training_id = certificates.training_id',array('trainingTypes.name as training_name'))
            ->where('certificates.name is not null', '')
            ->where('certificates.linkable_id in (?)', $courseIdArr)
            ->where('certificates.status=?', 1)
            ->order(array('certificates.linkable_id ASC'));

        $certificateRes = $this->getDb()->fetchAll($certifcateSql);
        if(empty($certificateRes))
            return array();

        $certificateData = array();
        foreach ($certificateRes as $key => $value) {
            $certificateData[$value['linkable_id']][] = $value;
        }

        if(empty($certificateData))
            return array();

        $objAccreditor = new Model_Accreditors();
        $accDetails = array();
        $allAccreditors = array();
        foreach($objAccreditor->fetchAll() as $accrData) {
            $allAccreditors[$accrData['accreditor_id']] = $accrData;
            if($accrData['is_default'] == 1) {
                $accDetails[] = $accrData;
            }
        }
        foreach ($courseData as $key => $value) {
            if(!array_key_exists($value['course_id'],$certificateData)){
                $this->_buildCompletionData($value['course_display_name'],$value['course_id'],$value['primary_eLearning_id'],$accDetails);
                if(isset($value['old_eLearning_id']) && $value['old_eLearning_id']) {
                    $value['old_eLearning_id'] = explode(",", $value['old_eLearning_id']);
                    foreach($value['old_eLearning_id'] as $eLearningIdOld) {
                        if(isset($this->certificateArr[$eLearningIdOld])) {
                            continue;
                        }
                        $this->_buildCompletionData($value['course_display_name'],$value['course_id'],$eLearningIdOld,$accDetails);
                    }
                }
            }else{
                    $certificateCourseDetails = $certificateData[$value['course_id']];
                    $this->_buildCompletionData($value['course_display_name'],$value['course_id'],$value['primary_eLearning_id'],$accDetails);
                    $value['old_eLearning_id'] = explode(",", $value['old_eLearning_id']);
                    foreach($value['old_eLearning_id'] as $eLearningIdOld) {
                        if(isset($this->certificateArr[$eLearningIdOld])) {
                            continue;
                        }
                        $this->_buildCompletionData($value['course_display_name'],$value['course_id'],$eLearningIdOld,$accDetails);
                    }

                    foreach ($certificateCourseDetails as $certiKey => $certiValue) {
                        $accreditorIdArr = explode(',', $certiValue['accreditor_id']);
                        $accData = array();
                        if(!empty($accreditorIdArr)){
                            $accIds =array_values($accreditorIdArr);
                            foreach($accIds as $accId) {
                                if($value['course_accreditor_id'] == $accId && isset($allAccreditors[$accId])) {
                                    $accData[$value['course_id']][] = $allAccreditors[$accId];
                                }
                            }
                        }
                        $this->certificateArr[$value['primary_eLearning_id']]['course_name'] = $value['course_display_name'];
                        $trainingName = $certiValue['training_id'];
                        $this->certificateArr[$value['primary_eLearning_id']][$value['course_id']][$trainingName][$certiValue['certificateType']] =  array(
                            'certifcate_displayName'=>$certiValue['displayName'],
                            'activityNumber'=>$certiValue['activityNumber'],
                            'pdu'=>$certiValue['pdu'],
                            'oneLiner'=>$certiValue['oneLiner'],
                            'accreditor_details' => isset($accData[$value['course_id']]) ? $accData[$value['course_id']] : array()
                        );
                        if(isset($value['old_eLearning_id']) && $value['old_eLearning_id']) {
                            foreach($value['old_eLearning_id'] as $eLearningIdOld) {
                                if(isset($this->certificateArr[$eLearningIdOld])) {
                                   continue;
                                }
                                $this->certificateArr[$eLearningIdOld]['course_name'] = $value['course_display_name'];
                                $this->certificateArr[$eLearningIdOld][$value['course_id']][$trainingName][$certiValue['certificateType']] =  array(
                                    'certifcate_displayName'=>$certiValue['displayName'],
                                    'activityNumber'=>$certiValue['activityNumber'],
                                    'pdu'=>$certiValue['pdu'],
                                    'oneLiner'=>$certiValue['oneLiner'],
                                    'accreditor_details' => isset($accData[$value['course_id']]) ? $accData[$value['course_id']] : array()
                                );
                            }
                        }
                    }
                }

        }

        // For Deleted Courses
        $coursesql = $this->getDb()->select()
            ->from('courses', array('courses.course_id','courses.displayName as course_display_name','courses.primary_eLearning_id', 'course_accreditor_id' => 'courses.accreditor_id', 'courses.old_eLearning_id'))
            ->where('courses.status = ?', 0)
            ->where('courses.primary_eLearning_id != 0 OR courses.old_eLearning_id != ?', '');
        $courseData = $this->getDb()->fetchAll($coursesql);
        foreach ($courseData as $key => $value) {
            if(!array_key_exists($value['course_id'],$certificateData)){
                if(!isset($this->certificateArr[$value['primary_eLearning_id']])) {
                    $this->_buildCompletionData($value['course_display_name'],$value['course_id'],$value['primary_eLearning_id'],$accDetails);
                }
                if(isset($value['old_eLearning_id']) && $value['old_eLearning_id']) {
                    $value['old_eLearning_id'] = explode(",", $value['old_eLearning_id']);
                    foreach($value['old_eLearning_id'] as $eLearningIdOld) {
                        if(!isset($this->certificateArr[$eLearningIdOld])) {
                            $this->_buildCompletionData($value['course_display_name'],$value['course_id'],$eLearningIdOld,$accDetails);
                        }
                    }
                }
            }
            else{
                $certificateCourseDetails = $certificateData[$value['course_id']];
                if(!isset($this->certificateArr[$value['primary_eLearning_id']])) {
                    $this->_buildCompletionData($value['course_display_name'],$value['course_id'],$value['primary_eLearning_id'],$accDetails);
                }
                $value['old_eLearning_id'] = explode(",", $value['old_eLearning_id']);
                foreach($value['old_eLearning_id'] as $eLearningIdOld) {
                    if(!isset($this->certificateArr[$eLearningIdOld])) {
                        $this->_buildCompletionData($value['course_display_name'],$value['course_id'],$eLearningIdOld,$accDetails);
                    }
                }

                foreach ($certificateCourseDetails as $certiKey => $certiValue) {
                    $accreditorIdArr = explode(',', $certiValue['accreditor_id']);
                    $accData = array();
                    if(!empty($accreditorIdArr)){
                        $accIds =array_values($accreditorIdArr);
                        foreach($accIds as $accId) {
                            if($value['course_accreditor_id'] == $accId && isset($allAccreditors[$accId])) {
                                $accData[$value['course_id']][] = $allAccreditors[$accId];
                            }
                        }
                    }
                    if(!isset($this->certificateArr[$value['primary_eLearning_id']])) {
                        $this->certificateArr[$value['primary_eLearning_id']]['course_name'] = $value['course_display_name'];
                        $trainingName = $certiValue['training_id'];
                        $this->certificateArr[$value['primary_eLearning_id']][$value['course_id']][$trainingName][$certiValue['certificateType']] =  array(
                            'certifcate_displayName'=>$certiValue['displayName'],
                            'activityNumber'=>$certiValue['activityNumber'],
                            'pdu'=>$certiValue['pdu'],
                            'oneLiner'=>$certiValue['oneLiner'],
                            'accreditor_details' => isset($accData[$value['course_id']]) ? $accData[$value['course_id']] : array()
                        );
                    }
                    if(isset($value['old_eLearning_id']) && $value['old_eLearning_id']) {
                        foreach($value['old_eLearning_id'] as $eLearningIdOld) {
                            if(!isset($this->certificateArr[$eLearningIdOld])) {
                                $this->certificateArr[$eLearningIdOld]['course_name'] = $value['course_display_name'];
                                $this->certificateArr[$eLearningIdOld][$value['course_id']][$trainingName][$certiValue['certificateType']] =  array(
                                    'certifcate_displayName'=>$certiValue['displayName'],
                                    'activityNumber'=>$certiValue['activityNumber'],
                                    'pdu'=>$certiValue['pdu'],
                                    'oneLiner'=>$certiValue['oneLiner'],
                                    'accreditor_details' => isset($accData[$value['course_id']]) ? $accData[$value['course_id']] : array()
                                );
                            }
                        }
                    }
                }
            }
        }

        return $this->certificateArr;
    }

    private function _buildCompletionData($courseName,$courseId,$eLearningId,$accDetails,$trainingTypeArr = array( BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM,BaseApp_Dao_TrainingTypes::TYPE_ELEARNING,BaseApp_Dao_TrainingTypes::TYPE_LVC,BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS)){

        foreach ($trainingTypeArr as $key => $value) {
            $this->certificateArr[$eLearningId]['course_name'] = $courseName;
            $trainingName = $value;
            $this->certificateArr[$eLearningId][$courseId][$trainingName]['completion'] =  array('certifcate_displayName'=>$courseName,
                                                                                        'activityNumber'=>'',
                                                                                        'pdu'=>'',
                                                                                        'oneLiner'=>'',
                                                                                        'accreditor_details' => $accDetails
                                                                                       );
        }
    }

    public function buildCdnPurgeData($courseId,$action){
        $returnArr = array();
        // $objSeo = new Model_Seo();
        // $seoUrl = current($objSeo->fetchAll(array('linkable_id =?'=>$courseId,'linkable_type =?'=>'course'),array('columns'=>array('url'))));
        // if(!empty($seoUrl))
        //     array_push($returnArr,array('linkable_id'=>$courseId,'linkable_type'=>'course','action'=>$action,'url'=>$seoUrl['url'],'created_at'=>time(),'updated_at'=>time()) );

        // $objBundles = new Model_Bundles();
        // $condition["FIND_IN_SET(?, course_id)>0"] = $courseId;
        // $bunldeData = $objBundles->fetchAll($condition,array('columns'=>array('bundle_id')),false);
        // if(!empty($bunldeData)){
        //     $bundleIds = array_column($bunldeData,'bundle_id');
        //     $seoData = $objSeo->fetchAll(array('linkable_id in (?)'=>$bundleIds,'linkable_type =?'=>'bundle'),array('columns'=>array('url','linkable_id')));
        //     if(!empty($seoData)){
        //         foreach ($seoData as $key => $value) {
        //             array_push($returnArr,array('linkable_id'=>$value['bundle_id'],'linkable_type'=>'bundle','action'=>$action,'url'=>$value['url'],'created_at'=>time(),'updated_at'=>time()) );
        //         }
        //     }
        // }
        // $courseData = current($this->fetchAll(array('course_id =?'=>$courseId),array('columns'=>array('primary_label_id'))));
        // if(!empty($courseData)){
        //     $labelId = $courseData['primary_label_id'];
        //     $seoData = current($objSeo->fetchAll(array('linkable_id = ?'=>$labelId,'linkable_type =?'=>'label'),array('columns'=>array('url','linkable_id'))));
        //     if(!empty($seoData)){
        //         array_push($returnArr,array('linkable_id'=>$seoData['linkable_id'],'linkable_type'=>'label','action'=>$action,'url'=>$seoData['url'],'created_at'=>time(),'updated_at'=>time()) );
        //     }
        //     if(!empty($labelId)){
        //         $objLabel = new Model_Labels($labelId);
        //         if(!empty($objLabel->popularCourses)){
        //             if(strpos($objLabel->popularCourses, $courseId) !== false ){
        //                 array_push($returnArr,array('linkable_id'=>$courseId,'linkable_type'=>'course','action'=>$action,'url'=>PURGE_WEBSITE,'created_at'=>time(),'updated_at'=>time()) );
        //             }
        //         }
        //     }

        //     $condition['FIND_IN_SET(?, course_id)>0'] = new Zend_Db_Expr(implode(', label_id)>0 OR FIND_IN_SET(',array($courseId, $labelId)));
        //     $objArticle = New Model_Articles();
        //     $articleData = $objArticle->fetchAll($condition,array('columns'=>array('article_id')));
        //     if(!empty($articleData)){
        //         $articleIds = array_column($articleData,'article_id');
        //         $seoData = $objSeo->fetchAll(array('linkable_id in (?)'=>$articleIds,'linkable_type =?'=>'article'),array('columns'=>array('url','linkable_id')));
        //         if(!empty($seoData)){
        //             foreach ($seoData as $key => $value) {
        //                 array_push($returnArr,array('linkable_id'=>$value['linkable_id'],'linkable_type'=>'article','action'=>$action,'url'=>$value['url'],'created_at'=>time(),'updated_at'=>time()) );
        //             }
        //         }
        //     }
        //     $objWebinar = New Model_Webinars();
        //     $webinarData = $objWebinar->fetchAll($condition,array('columns'=>array('webinar_id')));
        //     if(!empty($webinarData)){
        //         $webinarIds = array_column($webinarData,'webinar_id');
        //         $seoData = $objSeo->fetchAll(array('linkable_id in (?)'=>$webinarIds,'linkable_type =?'=>'webinar'),array('columns'=>array('url','linkable_id')));
        //         if(!empty($seoData)){
        //             foreach ($seoData as $key => $value) {
        //                 array_push($returnArr,array('linkable_id'=>$value['linkable_id'],'linkable_type'=>'webinar','action'=>$action,'url'=>$value['url'],'created_at'=>time(),'updated_at'=>time()) );
        //             }
        //         }
        //     }
        //     $objEbooks = New Model_Ebooks();
        //     $ebookData = $objEbooks->fetchAll($condition,array('columns'=>array('ebook_id')));
        //     if(!empty($ebookData)){
        //         $ebookIds = array_column($ebookData,'ebook_id');
        //         $seoData = $objSeo->fetchAll(array('linkable_id in (?)'=>$ebookIds,'linkable_type =?'=>'ebook'),array('columns'=>array('url','linkable_id')));
        //         if(!empty($seoData)){
        //             foreach ($seoData as $key => $value) {
        //                 array_push($returnArr,array('linkable_id'=>$value['linkable_id'],'linkable_type'=>'ebook','action'=>$action,'url'=>$value['url'],'created_at'=>time(),'updated_at'=>time()) );
        //             }
        //         }
        //     }
        // }
        // $config = Zend_Registry::get('config');
        // $popularCourses = $config->get('popular_courses');
        // $popularCourses = $popularCourses->toArray();
        // $objSeo = new Model_Seo();
        // if(in_array($courseId,$popularCourses)){
        //     array_push($returnArr,array('linkable_id'=>$courseId,'linkable_type'=>'course','action'=>$action,'url'=>PURGE_WEBSITE,'created_at'=>time(),'updated_at'=>time()));
        // }
        return $returnArr;
    } // end of function

    public function fetchProductDetails(){
        $returnArr = array();
        $courseData = $this->fetchForSelect();
        foreach ($courseData as $key => $value) {
            $returnArr[$key] = $value.' ( '.$key.' ) ';
        }
        return $returnArr;
    }
//
//    public function fetchCoursesByLabels($labels = array()){
//        $returnArr = array();
//        $orStr = '';
//        foreach ($labels as $key => $value) {
//            $orStr .= " or find_in_set ('".$value."',label_id)";
//        }
//        if(!empty($labels))
//            $returnArr = $this->fetchForSelect(array('primary_label_id in(?)'.$orStr => $labels,'is_dummy = ?' => 0, 'is_free = ?' => 0));
//        return $returnArr;
//    }

//    public function fetchCoursesByLabels($labels = array(),$isb2bAndHideFormSearch=0){
//        $returnArr = array();
//        $orStr = '';
//        foreach ($labels as $key => $value) {
//            $orStr .= " or find_in_set ('".$value."',label_id)";
//        }
//        if(!empty($labels)){
//           $cond=array('primary_label_id in(?)'.$orStr => $labels,'is_dummy = ?' => 0, 'is_free = ?' => 0);  
//          if($isb2bAndHideFormSearch){
//               $isb2b=1;
//               $hideFormSearch=0;
//               $searchCond=" OR (is_b2b='".$isb2b."' AND hideFromSearch='".$hideFormSearch."')";
//               $cond['is_b2b  = ?']=$isb2b.$searchCond; 
//           }
//           $returnArr = $this->fetchForSelect($cond); 
//        }
//        prd($returnArr);
//        return $returnArr;
//    }
    public function fetchCoursesByLabels($labels = array(), $isb2bAndHideFormSearch = 0) {
        $returnArr = array();
        $orStr = '';
        if (!empty($labels)) {
            foreach ($labels as $key => $value) {
                $orStr .= " or find_in_set ('" . $value . "',label_id)";
            }
            $sql = "SELECT
                       `courses`.`course_id`, `courses`.`name`
                    FROM
                        courses
                    WHERE
                        (primary_label_id IN (" . implode(",", $labels) . ") $orStr)
                    AND (is_dummy = 0) 
                    AND (is_free = 0 ) 
                    AND (status=1)";
            // $cond="";
            if ($isb2bAndHideFormSearch) {
                $sql .= " AND (
                    ((is_b2b = 1)) AND 
                    (`courses`.`course_available_for` = 'b2b_only') OR 
                    (`courses`.`course_available_for` = 'universal')
                )";
            }
            // if ($isb2bAndHideFormSearch) {
            //     $cond = " AND ( (is_b2b = 1)  OR (is_b2b = 0 AND hideFromSearch= 0) )";
            //     $sql.=$cond;
            // }
            $sql.=" ORDER BY courses.name ASC";      
            $db = $this->getDb();
            $stmt = $db->query($sql);
            $result = $stmt->fetchAll();
            if(!empty($result)){
                $returnArr=array_column($result,'name','course_id');
                
            }
        }
        return $returnArr;
    }

    public function getClusterId($placeId){
        $returnId = array();
        $sql = "SELECT
            c.cluster_id FROM country c
            WHERE c.country_id = '" . $placeId . "' ";

        $db = $this->getDb();
        $stmt = $db->query($sql);
        $result = $stmt->fetchAll();
        if(!empty($result)){
            $returnId=array_column($result,'cluster_id');
}
        return $returnId[0];

    }

    public function fetchCoursesByLabelsHavingB2cPrice($labels = array(), $isClusterOrCountry,$placeId, $trainingType, $isB2b = 0) {
        $returnArr = array();
        $orStr = '';
        if (!empty($labels)) {
            foreach ($labels as $key => $value) {
                $orStr .= " or find_in_set ('" . $value . "',label_id)";
            }

            if($trainingType == BaseApp_Dao_TrainingTypes::TYPE_ELEARNING_NAME) { 
                $trainingId = BaseApp_Dao_TrainingTypes::TYPE_ELEARNING;
            }
            else if($trainingType == BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS_NAME) {
                $trainingId = BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS;
            }

            $sql = "SELECT
            c.`course_id`, c.`name` 
            FROM
            courses c,pricings p
            WHERE
            c.course_id = p.course_id ";

            if($isClusterOrCountry == BaseApp_Dao_Country::TYPE_CLUSTER) {

                $sql .= "AND p.cluster_id = '" . $placeId . "' ";
            }

            else if($isClusterOrCountry == BaseApp_Dao_Country::TYPE_COUNTRY) {
                $clusterIdBasedOnCountryId = $this->getClusterId($placeId);
                $sql .= " AND  ( p.country_id = '" . $placeId . "'  
                OR  p.cluster_id = '" . $clusterIdBasedOnCountryId . "' )" ;
            }

            $sql .= " AND  
                (primary_label_id IN (" . implode(",", $labels) . ") $orStr)
                AND (is_dummy = 0) 
                AND (is_free = 0 ) 
                AND (c.status = 1) AND
                (p.status = 1) AND
                (p.minPrice > 0) AND
                (p.training_id = '". $trainingId ."') 
                ";
            
            if ($isB2b) {
                $sql .= " AND (
                ((is_b2b = 1)) AND
                (c.`course_available_for` = 'b2b_only') OR 
                (c.`course_available_for` = 'universal')
                )";
            }

            $sql.=" ORDER BY c.name ASC";
            $db = $this->getDb();
            $stmt = $db->query($sql);
            $result = $stmt->fetchAll();
            if(!empty($result)){
                $returnArr=array_column($result,'name','course_id');
            }
        }
        return $returnArr;
    }

    public function fetchCoursesByLabelsBasedOnAgency($labels = array(), $agency) {
        $returnArr = array();
        $orStr = '';
        if (!empty($labels)) {
            foreach ($labels as $key => $value) {
                $orStr .= " or find_in_set ('" . $value . "',label_id)";
            }
        }
        if(!empty($agency)) {
            $cloud6_db = CLOUD6_DB;
            $ice9_db = MONGO_DB;
            $sql = " SELECT 
            c.course_id as linkable_id, c.name
            FROM " . $cloud6_db . ".groups g 
            JOIN
            ". $cloud6_db .".enterprise_course_mapping ff ON g.gid = ff.group_id
            JOIN
            ". $ice9_db .".courses c ON ff.entity_id = c.course_id
            JOIN
            ". $cloud6_db .".group_membership gm ON g.gid = gm.gid
            JOIN
            ". $cloud6_db .".group_membership_role gmr ON gm.mid = gmr.mid
            JOIN
            ". $cloud6_db .".users u ON gm.uid = u.uid
            JOIN
            ". $cloud6_db .".field_data_field_domain d ON g.gid = d.entity_id
            JOIN
            ". $cloud6_db .".field_data_field_agreement_expiry e ON g.gid = e.entity_id
            where (primary_label_id IN (" . implode(",", $labels) . ") $orStr) 
            AND g.title = '" . $agency . "'
            AND ff.entity_type = '" . BaseApp_Dao_EntityListing::ENTITY_TYPE_COURSE . "'
            AND c.course_available_for IN ('private_b2b')
            AND ff.status = 1 AND c.status = 1
            GROUP BY g.gid,c.course_id";
        }
        else {
            $sql = "SELECT
            `courses`.`course_id` as linkable_id, `courses`.`name`
            FROM
            courses
            WHERE
            (primary_label_id IN (" . implode(",", $labels) . ") $orStr) 
            AND (status=1)
            AND `courses`.`course_available_for` IN ('b2b_only','universal') 
            ORDER BY courses.name ASC";  
        }
        $db = $this->getDb();
        $stmt = $db->query($sql);
        $result = $stmt->fetchAll();
        if (!empty($result)) {
            foreach ($result as $key => $row) {
                $returnArr[] = $row;
            }
        }
        return $returnArr;
    }

    //get agency for course
    public function fetchAgencyBasedOnCourseId($courseIds = array())
    {
        $returnArr = array();
        $orStr = '';
        if (!empty($courseIds)) {
            $cloud6_db = CLOUD6_DB;
            $ice9_db = MONGO_DB;
            $sql = " SELECT 
            c.course_id ,g.gid
            FROM " . $cloud6_db . ".groups g 
            JOIN
            " . $cloud6_db . ".enterprise_course_mapping ff ON g.gid = ff.group_id
            JOIN
            " . $ice9_db . ".courses c ON ff.entity_id = c.course_id
            JOIN
            " . $cloud6_db . ".group_membership gm ON g.gid = gm.gid
            JOIN
            " . $cloud6_db . ".group_membership_role gmr ON gm.mid = gmr.mid
            JOIN
            " . $cloud6_db . ".users u ON gm.uid = u.uid
            JOIN
            " . $cloud6_db . ".field_data_field_domain d ON g.gid = d.entity_id
            JOIN
            " . $cloud6_db . ".field_data_field_agreement_expiry e ON g.gid = e.entity_id
            where (course_id IN (" . implode(",", $courseIds) . ")) 
            AND ff.entity_type = '" . BaseApp_Dao_EntityListing::ENTITY_TYPE_COURSE . "'
            AND c.course_available_for IN ('private_b2b')
            AND ff.status = 1 AND c.status = 1
            GROUP BY g.gid,c.course_id";
        }
        $db = $this->getDb();
        $stmt = $db->query($sql);
        $result = $stmt->fetchAll();
        if (!empty($result)) {
            foreach ($result as $key => $row) {
                $returnArr[] = $row;
            }
        }
        return $returnArr;
    }


    //---------------------------------------------------------------------------------------

    public function fetchCoursesByLabelsBasedOnAgencyAjax($labels = array(), $agency) {
        $returnArr = array();
        $orStr = '';
        if (!empty($labels)) {
            foreach ($labels as $key => $value) {
                $orStr .= " or find_in_set ('" . $value . "',label_id)";
            }
        }

        if (!empty($agency)) {
            $cloud6_db = CLOUD6_DB;
            $ice9_db = MONGO_DB;
            $sqlPrivate = " SELECT 
            c.course_id as linkable_id, c.name
            FROM " . $cloud6_db . ".groups g 
            JOIN
            " . $cloud6_db . ".enterprise_course_mapping ff ON g.gid = ff.group_id
            JOIN
            " . $ice9_db . ".courses c ON ff.entity_id = c.course_id
            JOIN
            " . $cloud6_db . ".group_membership gm ON g.gid = gm.gid
            JOIN
            " . $cloud6_db . ".group_membership_role gmr ON gm.mid = gmr.mid
            JOIN
            " . $cloud6_db . ".users u ON gm.uid = u.uid
            JOIN
            " . $cloud6_db . ".field_data_field_domain d ON g.gid = d.entity_id
            JOIN
            " . $cloud6_db . ".field_data_field_agreement_expiry e ON g.gid = e.entity_id
            where (primary_label_id IN (" . implode(",", $labels) . ") $orStr) 
            AND ff.entity_type = '" . BaseApp_Dao_EntityListing::ENTITY_TYPE_COURSE . "'
            AND c.course_available_for = 'private_b2b' AND g.title = '" . $agency . "'
            AND ff.status = 1 AND c.status = 1
            GROUP BY g.gid,c.course_id";
            
            $sqlPublic = "SELECT
            `courses`.`course_id` as linkable_id, `courses`.`name`
            FROM
            courses
            WHERE
            (primary_label_id IN (" . implode(",", $labels) . ") $orStr) 
            AND (status=1)
            AND `courses`.`course_available_for` IN ('b2b_only','universal') 
            ORDER BY courses.name ASC";

            $db = $this->getDb();
            $stmtPrivate = $db->query($sqlPrivate);
            $resultPrivate = $stmtPrivate->fetchAll();
            if (!empty($resultPrivate)) {
                foreach ($resultPrivate as $key => $row) {
                    $returnArr[] = $row;
                }
            }
            $stmtPublic = $db->query($sqlPublic);
            $resultPublic = $stmtPublic->fetchAll();
            if (!empty($resultPublic)) {
                foreach ($resultPublic as $key => $row) {
                    $returnArr[] = $row;
                }
            }
        } else {
            $sql = "SELECT
            `courses`.`course_id` as linkable_id, `courses`.`name`
            FROM
            courses
            WHERE
            (primary_label_id IN (" . implode(",", $labels) . ") $orStr) 
            AND (status=1)
            AND `courses`.`course_available_for` IN ('b2b_only','universal') 
            ORDER BY courses.name ASC";
            $db = $this->getDb();
            $stmt = $db->query($sql);
            $result = $stmt->fetchAll();
            if (!empty($result)) {
                foreach ($result as $key => $row) {
                    $returnArr[] = $row;
                }
            }
        }
        
        return $returnArr;
    }



    //=======================================================================================


    
    public function fetchElearningOnIds(array $courseId)
    {
        $sql = $this->getDb()->select()
            ->from('courses', array('courses.course_id', 'courses.primary_eLearning_id'))
            ->where('course_id IN (?)', $courseId)
            ->where('courses.primary_eLearning_id <> ?', 0)
            ->where('courses.status = ?', 1)
            ->order(array('courses.course_id ASC'));

        $courseData = $this->getDb()->fetchAssoc($sql);
        if(empty($courseData)){
            return array();
        }

        return $courseData;
    }
    
    /**
     * Method to get course catalogue details  
     * @param array $courseIds
     * @return array
     */
    public function getCatalogueDetails($courseIds) {
        $result = array(
            'status' => 'failed',
            'msg' => 'Data not found',
            'data' => NULL
        );
        $courseType = 'course';
        $bundleType = 'bundle';
        $videoType = 'about_course';
        $activeStatus = '1';
        $oslQuery = $bundleQuery = $lvcQuery = NULL;
        $finalQuery = array();
        $db = $this->getDb();

        //query to get osl details
        if (!empty($courseIds['osl']) && is_array($courseIds['osl'])) {
            $oslQuery = $db->select()->from('courses as co', array(
                        'la.name AS category',
                        'co.primary_elearning_id AS course_id',
                        'co.course_id AS product_id',
                        'co.name AS course_name',
                        'co.shortDescription AS description',
                        new Zend_Db_Expr('"OSL" AS course_type'),
                        new Zend_Db_Expr('"" AS duration'),
                        'se.thumb_image AS image_url',
                        new Zend_Db_Expr('"" AS course_url'),
                        'vi.videoLink AS intro_url',
                        new Zend_Db_Expr('"" AS price'),
                        'se.keyword AS keywords'
                    ))
                    ->joinLeft('labels as la', 'la.label_id = co.primary_label_id AND la.status = '.$activeStatus, array())
                    ->joinLeft('seo as se', "se.linkable_id = co.course_id AND se.linkable_type = '".$courseType."' AND se.status = ".$activeStatus, array())
                    ->joinLeft('videos as vi', "vi.course_id = co.course_id AND vi.name = '".$videoType."' AND vi.status = ".$activeStatus, array())
                    ->where('co.course_id IN (?)', $courseIds['osl'])
                    ->where('co.status = ?', $activeStatus)
                    ->group('co.course_id');
            $finalQuery[] = $oslQuery;
        }

        //query to get bundle details
        if (!empty($courseIds['bundle']) && is_array($courseIds['bundle'])) {
            $bundleQuery = $db->select()->from('bundles as bu', array(
                        'la.name AS category',
                        'bu.bundle_id AS course_id',
                        'bu.bundle_id AS product_id',
                        'bu.name AS course_name',
                        'bu.description AS description',
                        new Zend_Db_Expr('"MP" AS course_type'),
                        new Zend_Db_Expr('"" AS duration'),
                        'se.thumb_image AS image_url',
                        new Zend_Db_Expr('"" AS course_url'),
                        new Zend_Db_Expr('"" AS intro_url'),
                        new Zend_Db_Expr('"" AS price'),
                        'se.keyword AS keywords',
                    ))
                    ->joinLeft('labels as la', 'la.label_id = bu.primary_label_id AND la.status = '.$activeStatus, array())
                    ->joinLeft('seo as se', "se.linkable_id = bu.bundle_id AND se.linkable_type = '".$bundleType."' AND se.status = ".$activeStatus, array())
                    ->where('bu.bundle_id IN (?)', $courseIds['bundle'])
                    ->where('bu.status = ?', $activeStatus);
            $finalQuery[] = $bundleQuery;
        }

        //query to get lvc details
        if (!empty($courseIds['lvc']) && is_array($courseIds['lvc'])) {
            $lvcQuery = $db->select()->from('courses as co', array(
                        'la.name AS category',
                        'co.primary_elearning_id AS course_id',
                        'co.course_id AS product_id',
                        'co.name AS course_name',
                        'co.shortDescription AS description',
                        new Zend_Db_Expr('"LVC" AS course_type'),
                        new Zend_Db_Expr('"" AS duration'),
                        'se.thumb_image AS image_url',
                        new Zend_Db_Expr('"" AS course_url'),
                        'vi.videoLink AS intro_url',
                        new Zend_Db_Expr('"" AS price'),
                        'se.keyword AS keywords',
                    ))
                    ->joinLeft('labels as la', 'la.label_id = co.primary_label_id AND la.status = '.$activeStatus, array())
                    ->joinLeft('seo as se', "se.linkable_id = co.course_id AND se.linkable_type = '".$courseType."' AND se.status = ".$activeStatus, array())
                    ->joinLeft('videos as vi', "vi.course_id = co.course_id AND vi.name = '".$videoType."' AND vi.status = ".$activeStatus, array())
                    ->where('co.course_id IN (?)', $courseIds['lvc'])
                    ->where('co.status = ?', $activeStatus)
                    ->group('co.course_id');
            $finalQuery[] = $lvcQuery;
        }
        $catalogueDetails = NULL;
        if (!empty($finalQuery)) {
            $unionQuery = $db->select()->union($finalQuery);
            $catalogueDetails = $db->fetchAll($unionQuery);
        }
        if (!empty($catalogueDetails) && is_array($catalogueDetails)) {
            $result['status'] = 'success';
            $result['msg'] = 'Ok';
            $result['data'] = $catalogueDetails;
        }
        return $result;
    }

    /**
     * Method to fetch course data for SSP course catalog API
     * @param array $courseIds
     * @return type
     */
    public function getCourseDataForSSP($courseIds = array()) {
        $result = array(
            'status' => 'failed',
            'msg' => 'Data not found',
            'data' => NULL
        );
        if (empty($courseIds)) {
            return $result;
        }
        try {
            $db = $this->getDb();
            $videoType = 'about_course';
            $courseType = 'course';
            $activeStatus = '1';

            $courseQuery = $db->select()->from('courses AS c', array(
                    'c.course_id',
                    's.keyword AS keywords',
                    'v.videoLink AS intro_url',
                ))
                ->joinLeft('seo AS s', 's.linkable_id = c.course_id', array())
                ->joinLeft('videos AS v', 'v.course_id = c.course_id', array())
                ->where('c.course_id IN (?)', $courseIds)
                ->where('c.status = ?', $activeStatus)
                ->where('s.linkable_type IN (?)', $courseType)
                ->where('s.status = ?', $activeStatus)
                ->where('v.name = ?', $videoType)
                ->where('v.status = ?', $activeStatus);
            $response = $db->fetchAll($courseQuery);

            if (!empty($response) && is_array($response)) {
                $result['status'] = 'success';
                $result['msg'] = 'Ok';
                $result['data'] = $response;
            }
        } catch (Exception $ex) {
            $result['msg'] = 'Some error occurred while fetching data.';
        }
        return $result;
    }

    /**
     * Method to get the course name by IDs
     * @param array $courseIds
     * @return array
     */
    public function fetchCourseNames($courseIds) {
        if (!(!empty($courseIds) && is_array($courseIds))) {
            return array();
        }
        try {
            $status = 1;
            $sql = $this->getDb()->select()
                    ->from('courses as co', array('course_id', 'displayName'))
                    ->where('co.course_id IN (?)', $courseIds)
                    ->where('co.status = ?', $status);
            return $this->getDb()->fetchAll($sql, [], PDO::FETCH_KEY_PAIR);
        } catch (Exception $ex) {
            SelfServePortal_Utility::log(
                    array(
                        "TRACE" => array("METHOD" => __METHOD__, "LINE" => __LINE__),
                        "MESSAGE" => $ex->getMessage(),
                        "REQUEST" => array('course_ids' => $courseIds),
                        "RESPONSE" => $ex->getTraceAsString()
            ));
        }
        return array();
    }

    private function _saveVideoSeo($videoId, $labelId, $thumbIMage) {
        $return = false;

        $labelMd = new Model_Labels();
        $labelName = $labelMd->getDisplayNameById($labelId);
        $labelName = strtolower($labelName);
        $labelName = preg_replace("/[^a-z0-9]/", "-", $labelName);

        $url = sprintf("/resources/%s-videos/about-course-rrt%d", $labelName, $videoId);

        $seoMd = new Model_Seo();
        $conds = array(
            'controller=?' => Model_Videos::SEO_DEFAULT_CONTROLLER,
            'action=?' => Model_Videos::SEO_DEFAULT_ACTION,
            'linkable_id=?' => $videoId,
            'linkable_type=?' => 'video'
        );
        if ($seoData = current($seoMd->fetchAll($conds, array(), false))) {
            $dataSave = array(
                'url' => $url,
                'thumb_image' => $thumbIMage
            );
            $seoMd->clean();
            $seoMd->setId($seoData['seo_id']);
            $seoMd->setFromArray($dataSave)->update();
            $return = true;
        } else {
            $dataSave = array(
                'url' => $url,
                'thumb_image' => $thumbIMage,
                'controller' => Model_Videos::SEO_DEFAULT_CONTROLLER,
                'action' => Model_Videos::SEO_DEFAULT_ACTION,
                'params' => json_encode(array(Model_Videos::SEO_DEFAULT_PARAM_KEY => $videoId)),
                'linkable_id' => $videoId,
                'linkable_type' => 'video'
            );
            $return = $seoMd->setFromArray($dataSave)->save();
        }
        return $return;
    }
    public function getFreeCourseData($cond)
    {
        $return = array();
        $data = $this->fetchAll($cond);
        if (!empty($data)) {
            uasort($data, function ($a, $b) {
                return strcmp($a['name'], $b['name']);
            });
            foreach ($data as $key => $value) {
                $return[$value['course_id']] = $value['course_id'] . ' - ' . $value['name'];
            }
        }
        return $return;
    }

    public function getAllCourses($course){
        $retCourses = array();
        if ($course == "ALL_COURSE") {
            $retCourses = $this->fetchForSelect(array('is_dummy = ?' => 0, 'is_free = ?' => 0,'hideFromSearch = ?' => 0,'status = ?' => 1));
        } else if($course != "NONE"){            
            $isExam = ' ci.linkable_type = ?';
            $mCourses  = $this->getDb()->fetchAll($this->getDb()->select()->distinct()->from(array('ci' => 'courseInclusion'),array('ci.course_id','c.displayName'))->joinInner(array('ed' => 'exam_details'), 'ci.linkable_id = ed.id',array())->joinInner(array('c' => 'courses'), 'c.course_id = ci.course_id',array())->where($isExam,'exam')->where('ci.status = ?' ,1)->where('ed.status = ?' , 1)->where('c.status = ?', 1)->order('ci.course_id'));            
            foreach($mCourses as $cCourse) { 
                $retCourses[$cCourse['course_id']] = $cCourse['displayName'];
            }
            if($course == "COURSE_WITHOUT_EXAM"){
                $courseKeys = array_keys($retCourses);
                $allCourses = $this->fetchForSelect(array('is_dummy = ?' => 0, 'is_free = ?' => 0,'hideFromSearch = ?' => 0,'status = ?' => 1));
                foreach($allCourses as $key => $value){
                    if(in_array($key,$courseKeys)){
                        unset($allCourses[$key]);
                    }
                }
                return $allCourses;
            }      
        }
        return $retCourses;        
    }
    public function fetchFreeCourseByLabels($labels = array())
    {
        $orStr = '';
        $retArr = [];
        $courseArr = array();
        if (!empty($labels)) {
            $orStrNew = '';
            foreach ($labels as $key => $value) {
                $orStrNew .= " or find_in_set ('" . $value . "',label_id)";
            }
            $orStr .= "(label_id IN (" . implode(",", $labels) . ") $orStrNew) AND";
        }
        $sql = "SELECT
                   `courses`.`course_id`, `courses`.`name`
                FROM
                    courses
                WHERE
                    $orStr
                (is_dummy = 0) 
                AND (is_free = 0 ) 
                AND (status=1)";
        $sql .= " ORDER BY courses.name ASC";
        $db = $this->getDb();
        $stmt = $db->query($sql);
        $courseArr = $stmt->fetchAll();

        $currDate = time();
        $sql = "SELECT 
                        c.course_id
                    FROM
                        ice9.coupons c
                    WHERE
                        status = 1 AND c.training_id IS NOT NULL
                            AND c.purpose = 'mobile'
                            AND c.validFrom < $currDate and c.discountValue = 100
                            AND c.validto > $currDate 
                            AND c.totalCount > c.usedCount
                    ";
        $db = $this->getDb();
        $stmt = $db->query($sql);
        $result = $stmt->fetchAll();
        $freeCourses = array();
        if (!empty($result)) {
            foreach ($result as $res) {
                $courseIds = explode(",", $res['course_id']);
                $freeCourses = array_merge($freeCourses, $courseIds);
            }
        }
        $freeCourses =  array_unique($freeCourses);
        if (!empty($courseArr)) {
            $freeCourses =  array_intersect($freeCourses, array_column($courseArr, 'course_id'));
        }
        $retArr = array();
        if (!empty($freeCourses)) {
            foreach ($courseArr as $allCourse) {
                if (in_array($allCourse['course_id'], $freeCourses)) {
                    $retArr[] =  $allCourse;
                }
            }
            $retArr = array_column($retArr, 'name', 'course_id');
        }
        return $retArr;
    }

    public function getSeoContents($pType, $linkebleType ,$label){   
        $productIds = [];
        $result = [];
        if(!empty($label)){
            if($pType == 'course'){
                $sqlCourses = "SELECT 
                                    course_id, label_id
                                FROM
                                    ice9.courses
                                WHERE  status = 1 and  find_in_set ( $label,label_id);
                                    ";
                $db = $this->getDb();               
                $stmt = $db->query($sqlCourses);        
                $resultCourses = $stmt->fetchAll();                
                foreach($resultCourses as $val){
                        $productIds[] = $val['course_id'];
                    }
                $products = implode(",",$productIds);
            }else{
                $sqlBundles = "SELECT 
                                        bundle_id, label_id
                                    FROM
                                        ice9.bundles
                                    WHERE status = 1 and  
                                    find_in_set ( $label,label_id) ";
                    $db = $this->getDb();                    
                    $stmt = $db->query($sqlBundles);  

                    $resultCourses = $stmt->fetchAll();                
                    foreach($resultCourses as $val){
                            $productIds[] = $val['bundle_id'];
                        }
                    $products = implode(",",$productIds);
            }
            

            $sql = "SELECT 
                    seo_id ,  h1Tag as name
                    FROM
                        ice9.seo
                    WHERE
                        linkable_type ='$linkebleType' 
                        AND product_type='$pType' AND status = 1 ";

            if(!empty($productIds)){
                $sql .= " And product_id IN ($products)";
            }

            $db = $this->getDb();        
            $stmt = $db->query($sql);        
            $resultData = $stmt->fetchAll();            
            foreach($resultData as $val){
                $result[$val['seo_id']] = $val['name'];
            }
            return $result; 
        }
        
        
    }

    public function fetchPrimaryLabelIdByCourseId($courseId)
    {
        $sql = $this->getDb()->select()
            ->from("courses", ['courses.course_id', 'courses.primary_label_id'])
            ->join('labels', 'labels.label_id = courses.primary_label_id AND labels.status = 1', ['labels.displayName as primary_label_name'])
            ->where('courses.course_id = ?', $courseId)
            ->where('courses.status = ?', 1)
            ->limit(1);

        $courseData = $this->getDb()->fetchRow($sql);
        return empty($courseData) ? null : $courseData;
    }
}

// End of Class
