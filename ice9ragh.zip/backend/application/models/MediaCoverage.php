<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_MediaCoverage extends BaseApp_Dao_MediaCoverage{	

 public function _beforeSave() {
     $this->publishDate = strtotime($this->publishDate);
     return true;
 }
 
} // End of Class