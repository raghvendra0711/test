<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Model_FreeTrial extends BaseApp_Dao_FreeTrial{

     public function updateCourseFT($data) {
        try{
            $pricingObj = new Model_Pricings();
            if (!empty($data['course_id']) && !empty($data['country_id'])) {
                $pricingData = $pricingObj->getPricingByCountry($data['country_id'], $data['course_id'], $data['training_id']);
            } else if (!empty($data['course_id']) && !empty($data['cluster_id'])) {
                $pricingData = $pricingObj->getPricingByCluster($data['cluster_id'], $data['course_id'], $data['training_id']);
                $objCountry = new Model_Country();
                $countryData = $objCountry->getCountryDetailsByCluster($data['cluster_id']);
                if(!empty($countryData)) {
                    foreach ($countryData as $keyC => $country) {
                        $pricingDataC = $pricingObj->getPricingByCountry($country['country_id'], $data['course_id'], $data['training_id']);
                        if (!empty($pricingDataC)) {
                            $pricingData = array_merge($pricingData, $pricingDataC);
                        }
                    }
                }
            }
            if (!empty($pricingData)) {
                foreach ($pricingData as $key => $value) {
                    if (!empty($value['pricing_id']) && $value['free_trial'] != 1) {
                        $updateCourseFT = $pricingObj->enableFreeTrial($value['pricing_id']);
                        if (!$updateCourseFT) {
                            return false;
                        }
                    }
                }
            }
            return true;
        }
        catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }

    public function updateMPFT($data) {
        $pricingData = array();
        try{
            $pricingObj = new Model_SubscriptionPricing();
            if (!empty($data['bundle_id']) && !empty($data['country_id'])) {
                $pricingData = $pricingObj->getPricingByCountry($data['country_id'], $data['linkable_type'], $data['training_id'], $data['bundle_id']);
            } else if (!empty($data['bundle_id']) && !empty($data['cluster_id'])) {
                $pricingData = $pricingObj->getPricingByCluster($data['cluster_id'], $data['linkable_type'], $data['training_id'], $data['bundle_id']);
                $objCountry = new Model_Country();
                $countryData = $objCountry->getCountryDetailsByCluster($data['cluster_id']);
                if(!empty($countryData)) {
                    foreach ($countryData as $keyC => $country) {
                        $pricingDataMP = $pricingObj->getPricingByCountry($country['country_id'],  $data['linkable_type'], $data['training_id'], $data['bundle_id']);
                        if (!empty($pricingDataMP)) {
                            $pricingData = array_merge($pricingData, $pricingDataMP);
                        }
                    }
                }
            }
            if(!empty($pricingData)) {
                foreach ($pricingData as $key => $value) {
                    if(!empty($value['subscription_id'])){
                        $updateBundleFT = $pricingObj->enableMPFreeTrial($value['subscription_id']);
                        if (!$updateBundleFT) {
                            return false;
                        }
                    }
                }
            }
            return true;
        }
        catch (Exception $e){
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }


    public function updateMessages($data)
    {
        $savedData = array();
        $msgObj = new Model_SectionMessages();
        try {
            if (!empty($data['section_name']) && !empty($data['value'])) {
                $savedData = $msgObj->getMessagesBySection($data['section_name']);
            }
            if (!empty($savedData) && !empty($savedData[$data['section_name']])) {
                $ids = array_column($savedData[$data['section_name']],'id');
                if (!empty($ids)) {
                    $disableMessage = $msgObj->disableMessages($ids);
                    if (!$disableMessage) {
                        return false;
                    }
                }
            }
            $saveMsg = $msgObj->saveMessage($data);
            return $saveMsg;
        }
        catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }

    public function getFTMessages($data)
    {
        $result = array();
        $msgObj = new Model_SectionMessages();
        if (!empty($data)) {
            $result = $msgObj->getMessagesBySection($data);
        }
        return $result;
    }

} // End of Class