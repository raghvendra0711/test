<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Model_workshopEvent extends BaseApp_Dao_workshopEvent {
    
}

// End of Class