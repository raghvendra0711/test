<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_PassPricings extends BaseApp_Dao_PassPricings{

    public function savePricing($passId, $priceData) {
        $db = $this->getDb();
	$objSubPrice = new self();   
        $db->beginTransaction();
        try{     
            $properties = $objSubPrice->fetchAll(array("pass_id = ?" => $passId));
            foreach($properties as $property){
                $objSubPrice->clean();
                $objSubPrice->setId($property['pass_pricings_id']);
                $objSubPrice->delete();
            }     
            $objSubPrice->clean();
            foreach($priceData as $indexId => $dataSave) {
                $dataSave['pass_id'] = $passId;
                $dataSave['training_id'] = BaseApp_Dao_TrainingTypes::TYPE_LVC;                
                $dataSave['discounted_price'] = $this->_getDiscountedPrice($dataSave['price'], $dataSave['discount']);
                $objSubPrice->setFromArray($dataSave)->save();
            }        
            $db->commit();
            return true;
        }
        catch (Exception $e){
            $db->rollBack();
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }
    
    private function _getDiscountedPrice($basePrice, $maxDiscount){
        if(!$maxDiscount) {
            return $basePrice;
        }
        return $basePrice -($basePrice * ($maxDiscount / 100));
    }
    
    public function getByPassId($passId) {
        $conds = array(
            'pass_id = ?' => $passId
        );
        $options = array(
            'order' => array(
                array('pass_pricings_id', 'country_id')
            )
        );
        return $this->fetchAll($conds, $options);
    }
    
    public function _afterFetchAll($data) {
        $trainings = array();
        $countries = array();
        $clusters = array();
        $currencies = array(
            'country' => array(),
            'cluster' => array()
        );        

        foreach($data as $row) {
            if($row['country_id']) {
                $countries[] = $row['country_id'];
            }
            if($row['cluster_id']) {
                $clusters[] = $row['cluster_id'];
            }
        }
        
        $modelTraining = new Model_TrainingTypes();
        $trainings = $modelTraining->getTrainingTypes();
        
        if($countries) {
            $country = new Model_Country();
            $currencies['country'] = $country->getCurrencies($countries); 
            $countries = $country->getById($countries);
        }
        
        if($clusters) {
            $cluster = new Model_Clusters();
            $currencies['cluster'] = $cluster->getCurrencies($clusters); 
            $clusters = $cluster->getListDisplay($clusters);
        }        
        
        foreach($data as &$row) {
            if($row['country_id']) {
                $row['Country'] = @$countries[$row['country_id']];                
                $row['Currency'] = @$currencies['country'][$row['country_id']];                
            }
            if($row['cluster_id']) {
                $row['Cluster'] = @$clusters[$row['cluster_id']];
                $row['Currency'] = @$currencies['cluster'][$row['cluster_id']];
            }
            if($row['training_id']) {
                $row['TrainingType'] = @$trainings[$row['training_id']];
            }
            
            $row['discountedPrice'] = $this->_getDiscountedPrice($row['price'], $row['discount']);
        }
        return $data;
    }
} // End of Class