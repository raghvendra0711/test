<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_Tags extends BaseApp_Dao_Tags{	

    public function saveTags($linkable_id, $linkable_type, $searchTags) {
        $db = $this->getDb();
	    $objTags = new self();
        $db->beginTransaction();
        try{       
            $dataSave = array(
                'linkable_id' => $linkable_id,
                'linkable_type' => $linkable_type,
                'tag' => $searchTags
            );
            if($tagData = $this->getByLinkable($linkable_id, $linkable_type)) {
                $objTags->setId($tagData['search_id']);
                $objTags->setFromArray($dataSave)->update();  
            }
            else {
                $objTags->setFromArray($dataSave)->save();                    
            }
            $db->commit();
            return true;
        }
        catch (Exception $e){
            $db->rollBack();
            return false;
        }
    }
    
    public function getByLinkable($linkableId, $linkableType) {
        return current($this->fetchAll(array('linkable_id = ?' => $linkableId, 'linkable_type = ?' => $linkableType)));
    }
} // End of Class