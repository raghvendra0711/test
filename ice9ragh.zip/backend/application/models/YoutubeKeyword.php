<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Model_YoutubeKeyword extends BaseApp_Model {

    protected $_allowDelete = false;
    protected $_serial = true;
    protected $_name = 'youtubeKeyword';
    protected $_pk = 'idyoutubeKeyword';

    public function getAll() {

        $sql = $this->getDb()->select()
                ->from('youtubeKeyword as co', array('co.course', 'co.keyword', 'videoId')
        );

        $data = $this->getDb()->fetchAll($sql);

        return $data;
    }

}
