<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_Referers extends BaseApp_Dao_Referer{	

	protected $_useCache = false;

} // End of Class