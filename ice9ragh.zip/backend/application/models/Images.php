<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_Images extends BaseApp_Dao_Images{	

    public function saveImage($linkable_id, $linkable_type, $imagePath, $imageDescription='') {
	    $objImage = new self();
        $data = array(
            'linkable_id' => $linkable_id,
            'linkable_type' => $linkable_type,
            'imagePath'=> $imagePath,
            'imageDescription'=> $imageDescription,
        );
        try{
            if($imageData = $this->getByLinkable($linkable_id, $linkable_type)) {
                $objImage->setId($imageData['image_id']);
                $objImage->setFromArray($data)->update();
            }
            else {
                $objImage->setFromArray($data)->save(); 
            }
            return true;
        }
        catch (Exception $e){
            return false;
        }
    }
    
    public function saveImageByName($linkable_id, $linkable_type, $imageData) {
        $db = $this->getDb();
	$objImage = new self();
        $db->beginTransaction();
        $data = array(
            'linkable_id' => $linkable_id,
            'linkable_type' => $linkable_type,
            'name' => $imageData['name'],
            'imagePath'=> $imageData['imagePath'],
            'imageDescription'=> $imageData['imageDescription']
        );
        try{
            if($imageDataExists = $this->getByLinkableAndName($linkable_id, $linkable_type, $imageData['name'])) {
                $objImage->setId($imageDataExists['image_id']);
                $objImage->setFromArray($data)->update();
            }
            else {
                $objImage->setFromArray($data)->save(); 
            }
            $db->commit();
            return true;
        }
        catch (Exception $e){
            $db->rollBack();
            throw $e;
            return false;
        }
    }


    public function saveBannerOfferImages($linkable_id, $linkable_type, $imageData) {
        $objImage = new self();
        $data = array(
            'linkable_id' => $linkable_id,
            'linkable_type' => $linkable_type,
            'name' => $imageData['name'],
            'imagePath'=> $imageData['imagePath'],
            'imageDescription'=> $imageData['imageDescription']
        );

        try{
            if($imageDataExists = $this->getByLinkableAndName($linkable_id, $linkable_type, $imageData['name'])) {
                $objImage->setId($imageDataExists['image_id']);
                $objImage->setFromArray($data)->update();
            }
            else {
                $objImage->setFromArray($data)->save(); 
            }
            return true;
        }
        catch (Exception $e){
            throw $e;
            return false;
        }
    }
    
    public function getByLinkableAndName($linkableId, $linkableType, $imageName) {
        $conds = array(
            'linkable_id = ?' => $linkableId, 
            'linkable_type = ?' => $linkableType,
            'name=?' => $imageName
        );
        return current($this->fetchAll($conds));
    }
    
    public function getByLinkable($linkableId, $linkableType) {
        return current($this->fetchAll(array('linkable_id = ?' => $linkableId, 'linkable_type = ?' => $linkableType)));
    }
    
    public function getInclusionImages($linkableId, $linkableType = "course") {
        $returnData = array();
        $data = $this->fetchAll(array('linkable_id = ?' => $linkableId, 'linkable_type = ?' => $linkableType));
        foreach($data as $tempId => $dataReal) {
            $returnData[$dataReal['name']] = $dataReal;
        }
        return $returnData;
    }
    
    public function getAllByLinkable($linkableId, $linkableType) {
        return $this->fetchAll(array('linkable_id = ?' => $linkableId, 'linkable_type = ?' => $linkableType));
    }
    
    public function deleteByLinkableAndName($linkableId, $linkableType, $imageName) {
        $conds = array(
            'linkable_id = ?' => $linkableId, 
            'linkable_type = ?' => $linkableType,
            'name=?' => $imageName
        );
        $objImage = new self();   
        $properties = $objImage->fetchAll($conds);
        if(!$properties) {
            return true;
        }
        foreach($properties as $property){
            $objImage->clean();
            $objImage->setId($property['image_id']);
            if(!$objImage->delete()) {
                return false;
            }
        }     
        $objImage->clean();
        return true;
    }
} // End of Class