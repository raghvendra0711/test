<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_Accreditors extends BaseApp_Dao_Accreditors{	

} // End of Class