<?php

/*
* To change this template, choose Tools | Templates
* and open the template in the editor.
*/

class Model_CdnPurgeLog extends BaseApp_Dao_CdnPurgeLog{

public function InsertCdnPurgeLog($cdnPurgeData){
	try{	
		// foreach ($cdnPurgeData as $key => $value) {
		// 	$this->setFromArray($value)->save();
		// }
		return true;
	}catch (Exception $e){
		prd($e->getMessage());
		return false;
	}
} // end of function InsertCdnPurgeLog

} // End of Class