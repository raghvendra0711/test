<?php

class Model_YoutubeCourseName extends BaseApp_Model {

    protected $_allowDelete = false;
    protected $_serial = true;
    protected $_name = 'youtubecoursename';
    protected $_pk = 'idyoutubecoursename';

    public function getAll() {

        $sql = $this->getDb()->select()
                ->from('youtubecoursename as co', array('co.coursename')
        );

        $data = $this->getDb()->fetchAll($sql);

        return $data;
    }

}
