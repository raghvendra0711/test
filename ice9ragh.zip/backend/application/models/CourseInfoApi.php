<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Model_CourseInfoApi extends BaseApp_Dao_CourseInfoApi{

     public function updateMapping($data) {
        $db = $this->getDb();
        $objLabel = new self();
        $db->beginTransaction();
        try{
            $objLabel->setId($data['id']);
            $objLabel->setFromArray($data)->update();

            $db->commit();
            return true;
        }
        catch (Exception $e){
            $db->rollBack();
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }

    public function getByIdentifier($identifier, $id) {
        return current($this->fetchAll(array("identifier = ?" => $identifier, "id <> ?" => $id)));
    }

} // End of Class