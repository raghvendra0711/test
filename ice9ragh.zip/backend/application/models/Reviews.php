<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_Reviews extends BaseApp_Dao_Reviews{

		public function saveUserTestimonial($testimonialData){
			$courseData = array();
			$cityData = array();
			$cityId = '';
			if( isset($testimonialData['courseId']) && !empty($testimonialData['courseId'])){
				$course = new Model_Courses($testimonialData['courseId']);
				$courseData = $course->toArray();
			}
			if( isset($testimonialData['ip']) && !empty($testimonialData['ip'])){
				$cityModel = new Model_City();
				$cityData = $cityModel->getCityIdbyIp($testimonialData['ip']);
				$modelCountry = new Model_Country($cityData['country_id']);
			}

			$isApprovedFlag = REVIEW_TO_BE_APPROVED_STATUS;
			$disApprovedReason = NULL;
			if(empty($testimonialData['courseId'])){
				$isApprovedFlag = REVIEW_DISAPPROVED_STATUS;
				$disApprovedReason = 'empty course Id';
			}elseif(empty($testimonialData['rating'])){
				$isApprovedFlag = REVIEW_DISAPPROVED_STATUS;
				$disApprovedReason = 'empty rating';
			}elseif(empty($testimonialData['feedback'])){
				$isApprovedFlag = REVIEW_DISAPPROVED_STATUS;
				$disApprovedReason = 'empty review';
			}elseif(empty($cityData['city_id'])){
				$isApprovedFlag = REVIEW_DISAPPROVED_STATUS;
				$disApprovedReason = 'empty city id';
			}elseif(empty($cityData['country_id'])){
				$isApprovedFlag = REVIEW_DISAPPROVED_STATUS;
				$disApprovedReason = 'empty country id';
			}elseif($testimonialData['rating'] < 3){
				$isApprovedFlag = REVIEW_DISAPPROVED_STATUS;
				$disApprovedReason = 'rating less than 3';
			}elseif ( strlen($testimonialData['feedback']) < 15) {
				$isApprovedFlag = REVIEW_DISAPPROVED_STATUS;
				$disApprovedReason = 'review less than 15 characters';
			}
                        /*
                         * Search for the incoming testimonail save request with email,course 
                         * & rating values but with empty text. 
                         * If yes, update the same record, else create a new entry in DB. 
                         * This check if for course reviews coming from LMS with empty review text.                          * 
                         */
                        $emptyUserReviews = $this->fetchAll(
                                array(
                                    'course_id = ?'=>$testimonialData['courseId'], 
                                    'email = ?' => $testimonialData['email'], 
                                    'rating = ?'=>$testimonialData['rating'],
                                    'review = ?' => '',
                                    'status = ?' => 1
                                ));
                        $createDate=date('Y/m/d H:i:s');
                        if(!empty($emptyUserReviews)){
                            unset($emptyUserReviews[0]['Course']);
                            $emptyUserReviews[0]['createDate']=$createDate;
                            $emptyUserReviews[0]['rating']=$testimonialData['rating'];
                            $emptyUserReviews[0]['review']=$testimonialData['feedback'];
                            $emptyUserReviews[0]['isApproved']= $isApprovedFlag;
                            $this->setId($emptyUserReviews[0]['review_id']);
                            $this->setFromArray($emptyUserReviews[0]);
                            $res=$this->update();
                        }else{
                            $data=array(
                                    'course_id'=>isset($testimonialData['courseId']) ? $testimonialData['courseId'] : NULL,
                                    'name'=>$testimonialData['firstName'].' '.$testimonialData['lastName'],
                                    'linkedinUrl'=>$testimonialData['profileUrl'],
                                    'company'=>NULL,
                                    'industry'=>NULL,
                                    'position'=>NULL,
                                    'rating'=>$testimonialData['rating'],
                                    'review'=>$testimonialData['feedback'],
                                    'email'=>$testimonialData['email'],
                                    'city_id'=>isset($cityData['city_id']) ? $cityData['city_id'] : NULL,
                                    'country_id'=>isset($cityData['country_id']) ? $cityData['country_id'] : NULL,
                                    'training_id'=>isset($testimonialData['training_id']) ? $testimonialData['training_id'] :BaseApp_Dao_TrainingTypes::TYPE_ELEARNING,
                                    'imgUrl'=>UPLOAD_CDN_URL.'/ice9/testimonial_images/default_avatar.png',
                                    'createDate'=>$createDate,
                                    'isLms'=>1,
                                    'isApproved'=>$isApprovedFlag,
                                    'disApprovedReason'=>$disApprovedReason,
                                    'status'=>1
                            );
                            $this->setFromArray($data);
                            $res=$this->save();
                        }
			if($res){
				$mailData = array(
					"firstName"=>$testimonialData['firstName'],
					"lastName"=>$testimonialData['lastName'],
					"course"=>isset($courseData['displayName']) ? $courseData['displayName'] : '',
					"city"=>isset($cityData['name']) ? $cityData['name'] : '',
					"country"=>isset($modelCountry->name) ? $modelCountry->name : '',
					"date"=>$createDate,
					'feedback'=>isset($testimonialData['feedback']) ? $testimonialData['feedback'] : ''
				);
				$config = Zend_Registry::get('config');
				$testimonialMailer = $config->get('testimonial_mailer');
				$testimonialMailer = $testimonialMailer->toArray();
				$emailIds = $testimonialMailer['emailIds'];
                                /*
				try{
					$mailer = new BaseApp_Mailer();
					$mailer->setSubject('New Testimonial Alert');
					$mailer->setTemplate(BaseApp_Mailer::TEMPLATE_NEW_TESTIMONIAL);
					$mailer->setVariables($mailData);
					foreach($emailIds as $key => $value){
					$mailer->addTo($value);
					}
					$mailer->send();
				}catch (Exception $e) {
					if (APPLICATION_ENV != 'production')
						throw $e;
				}
                                 * 
                                 */
			}
			return array('status'=>'Success');
		}

        public function _afterFetchAll($data){   
            $courses = array();
            foreach($data as $row){
               $courses[] = $row['course_id'];
            }
            
            $courseMdl = new Model_Courses();
            $courses = $courseMdl->getCourseByIdMultiple($courses);
            
            foreach($data as &$row){
                $row['Course'] = @$courses[$row['course_id']];
            }
            unset($courses);
            return $data;
        }

        public function getAllReviewStatus(){
        	return array(REVIEW_APPROVED_STATUS=>'Approved',REVIEW_DISAPPROVED_STATUS=>'DisApproved');
        }

    public function buildCdnPurgeData($courseId,$action){
        $returnArr = array();
        // $objSeo = new Model_Seo();
        // $seoUrl = current($objSeo->fetchAll(array('linkable_id =?'=>$courseId,'linkable_type =?'=>'course'),array('columns'=>array('url'))));
        // if(!empty($seoUrl))
        //     array_push($returnArr,array('linkable_id'=>$courseId,'linkable_type'=>'course','action'=>$action,'url'=>$seoUrl['url'],'created_at'=>time(),'updated_at'=>time()) );
        
        // $objBundles = new Model_Bundles();
        // $condition["FIND_IN_SET(?, course_id)>0"] = $courseId;
        // $bunldeData = $objBundles->fetchAll($condition,array('columns'=>array('bundle_id')),false);
        // if(!empty($bunldeData)){
        //     $bundleIds = array_column($bunldeData,'bundle_id');
        //     $seoData = $objSeo->fetchAll(array('linkable_id in (?)'=>$bundleIds,'linkable_type =?'=>'bundle'),array('columns'=>array('url','linkable_id')));
        //     if(!empty($seoData)){
        //         foreach ($seoData as $key => $value) {
        //             array_push($returnArr,array('linkable_id'=>$value['bundle_id'],'linkable_type'=>'bundle','action'=>$action,'url'=>$value['url'],'created_at'=>time(),'updated_at'=>time()) );
        //         }
        //     }
        // }
        // $courseData = current($this->fetchAll(array('course_id =?'=>$courseId),array('columns'=>array('primary_label_id'))));
        // if(!empty($courseData)){
        //     $labelId = $courseData['primary_label_id'];
        //     if(!empty($labelId)){
        //     	$seoData = current($objSeo->fetchAll(array('linkable_id = ?'=>$labelId,'linkable_type =?'=>'label'),array('columns'=>array('url','linkable_id'))));
        //     	if(!empty($seoData)){
        //         	array_push($returnArr,array('linkable_id'=>$seoData['linkable_id'],'linkable_type'=>'webinar','action'=>$action,'url'=>$seoData['url'],'created_at'=>time(),'updated_at'=>time()) );
        //     	}
        // 	}
        // }
        // $objWorkshop = new Model_Workshop();
        // if(in_array($courseId,$objWorkshop->getLVCPassCourses())){
	       //  $seoData = current($objSeo->fetchAll(array('linkable_id = ?'=>1,'linkable_type =?'=>'lvc_pass'),array('columns'=>array('url','linkable_id'))));
	       //  if(!empty($seoData)){
	       //      array_push($returnArr,array('linkable_id'=>$seoData['linkable_id'],'linkable_type'=>'lvc_pass','action'=>$action,'url'=>$seoData['url'],'created_at'=>time(),'updated_at'=>time()) );
	       //  }
        // }
        return $returnArr;
    } // end of function

    public function uploadImageToS3($filePath){
    	  $response = array(
            'status' => 'error',
            'msg' => 'Some error occurred while uploading logo.',
            'data' => NULL,
        );
        $fileContentType = $fileInfo['type'];
        $filePath = $fileInfo['tmp_name'];
        $fileExtension = pathinfo($fileInfo['name'], PATHINFO_EXTENSION);
        $awsFilePath = ATP_LOGO_PATH . DIRECTORY_SEPARATOR . $siteInfo->getGroupId() . "_" . "logo" . '.' . $fileExtension;
        $awsFileUpload = new BaseApp_Utility_AwsFileUpload();
        try {
            $uploadStatus = $awsFileUpload->uploadFileContentToAtpAws($filePath, $awsFilePath, $fileContentType, true);
            if ($uploadStatus) {
                $response = array(
                    'status' => 'success',
                    'msg' => 'Logo uploaded successfully.',
                    'data' => $awsFilePath,
                );
            }
        } catch (Exception $e) {
            $response['data'] = $e->getMessage();
        }
        return $response;
    }

} // End of Class