<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Model_CourseEventsData extends BaseApp_Dao_CourseEventsData {

    public function SaveEventData($eventData) {
        try {
            if (!empty($eventData)) {
                unset($eventData['action']);
                unset($eventData['Save_Event_Data']);
                $eventData['status'] = 1;
                $this->setFromArray($eventData)->save();
            }
            return true;
        } catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
        //prd($eventData);
    }

}
