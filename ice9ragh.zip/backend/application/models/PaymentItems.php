<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Model_PaymentItems extends BaseApp_Model
{

    protected $_allowDelete = true;
    protected $_serial = true;
    protected $_name = 'payment_items';
    protected $_pk = 'item_id';

    static public function getTableName()
    {
        return (new self)->getName();
    }

    public static function getOnPaymentId($paymentId)
    {
        if (empty($paymentId)) {
            return [];
        }

        return (new self)->fetchAll(array('payment_id =?' => $paymentId));
    }

}
