<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Model_LecturePageUrlLog extends BaseApp_Dao_LecturePageUrlLog {

    protected $_useCache = false;
    
    public function add($data) {
        $conds = array(
            'course_name = ?' => $data['course_name'],
            'chapter_name = ?' => $data['chapter_name'],
            'section_name = ?' => $data['section_name']            
        );        
        if($this->fetchAll($conds, array(), false)) {
            return true;
        }
        $data['time_created'] = date("Y-m-d H:i:s");
        $this->setFromArray($data)->save();        
    }
}

// End of Class