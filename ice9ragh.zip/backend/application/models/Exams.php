<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_Exams extends BaseApp_Dao_Exams{	

    public function createExam($request) {
        $db = $this->getDb();
        $objExam = new self();
        $pageUrl = '';
        $db->beginTransaction();
	   try{
            if(isset($request['url'])) {
                $pageUrl = trim($request['url']);
                $checkSlash = substr($pageUrl, 0,1);
                if($checkSlash != '/'){
                    $pageUrl = trim('/'.$pageUrl);
                }
                $objExam->setPageUrl($pageUrl);
                unset($request['url']);
            }
            $objExam->setFromArray($request)->save();
            $dataSave = array(
                'controller' => self::SEO_DEFAULT_CONTROLLER,
                'action' => self::SEO_DEFAULT_ACTION,
                'params' => json_encode(array(self::SEO_DEFAULT_PARAM_KEY=>$objExam->exam_id)),
                'linkable_id' => $objExam->exam_id,
                'linkable_type' => 'exam'
            );
            $modelSeo = new Model_Seo();
            $seoData = $modelSeo->getDataByUrl($pageUrl);
            $modelSeo->setId($seoData['seo_id']);
            $modelSeo->setFromArray($dataSave)->update();
            $db->commit();
            return $objExam->exam_id;
        }
        catch (Exception $e){
            $db->rollBack();
            return false;
        }
    }
    
    public function updateExam($data) {
        $db = $this->getDb();
	$objExam = new self();
        $db->beginTransaction();
        try{
            $objExam->setId($data['exam_id']);
            $objExam->setFromArray($data)->update();  
            $db->commit();
            return true;
        }
        catch (Exception $e){
            $db->rollBack();
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }
    
    public function getForInclusion($courseId) {
        $returnData = array();
        $data = $this->fetchAll(array('course_id = ?' => $courseId));
        foreach($data as $tempId => $dataReal) {
            $returnData['exams']['exam'.$dataReal['exam_id']] = 'exam (ID-'.$dataReal['exam_id'].')';
        }
        return $returnData;
    }
    
} // End of Class