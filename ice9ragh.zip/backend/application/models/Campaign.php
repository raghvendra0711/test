<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_Campaign extends BaseApp_Dao_Campaign{
    
    public function createCampaign($data) {
        $db = $this->getDb();
        $objCampaign = new self();
        $db->beginTransaction();
	try{
            $objCampaign->setFromArray($data)->save();    
            $db->commit();
            return $objCampaign->campaign_id;
        }
        catch (Exception $e){
            $db->rollBack();
            return false;
        }
    }
    
    public function updateCampaign($data) {
        $db = $this->getDb();
        $objCampaign = new self();
        $db->beginTransaction();
	try{
            $objCampaign->setId($data['campaign_id']);
            $objCampaign->setFromArray($data)->update();  
            $db->commit();
            return true;
        }
        catch (Exception $e){
            $db->rollBack();
            return false;
        }
    }
  
    public function _afterFetchAll($data){
        $labels = array();
        $courses = array();
        $bundles = array();
        $trainings = array();
        $clusters = array();  
        $countries = array();
        
        foreach($data as $row){
           if($row['label_id']) {
                $labels = array_merge($labels, explode(",", $row['label_id']));
           }
           if($row['course_id']) {
                $courses = array_merge($courses, explode(",", $row['course_id']));
           }
           if($row['bundle_id']) {
                $bundles = array_merge($bundles, explode(",", $row['bundle_id']));
           }
           if($row['cluster_id']) {
                $clusters = array_merge($clusters, explode(",", $row['cluster_id']));
           }
           if($row['country_id']) {
                $countries = array_merge($countries, explode(",", $row['country_id']));
           }
        }
        
        $courseMdl = new Model_Courses();
        $courses = $courseMdl->getCourseByIdMultiple($courses);
        
        $bundleMD1 = new Model_Bundles();
        $bundles = $bundleMD1->getBundleByIds($bundles);
        
        $labelsMdl = new Model_Labels();
        $labels = $labelsMdl->getLabelByIds($labels);
        
        $clusterMD1 = new Model_Clusters();
        $clusters = $clusterMD1->getById($clusters);
        
        $country = new Model_Country();
        $countries = $country->getById($countries);
        
        $modelTraining = new Model_TrainingTypes();
        $trainings = $modelTraining->getTrainingTypes();
        
        foreach($data as &$row){
            $row['validFromDate'] = date('Y-m-d', $row['validFrom']);
            $row['validToDate'] = date('Y-m-d', $row['validto']);
            
            if($row['label_id']) {
                $label = explode(",", $row['label_id']);
                foreach($label as $labelId) {
                    $row['labels'][] = @$labels[$labelId];
                }
                $row['labels'] = implode(", ", $row['labels']);
            }
            
            if($row['course_id']) {
                $course = explode(",", $row['course_id']);
                foreach($course as $courseId) {
                    $row['courses'][] = @$courses[$courseId];
                }
                $row['courses'] = implode(", ", $row['courses']);
            }
            
            if($row['bundle_id']) {
                $bundle = explode(",", $row['bundle_id']);
                foreach($bundle as $bundleId) {
                    $row['bundles'][] = @$bundles[$bundleId];
                }
                $row['bundles'] = implode(", ", $row['bundles']);
            }
            
            if($row['cluster_id']) {
                $cluster = explode(",", $row['cluster_id']);
                foreach($cluster as $clusterId) {
                    $row['clusters'][] = $clusters[$clusterId];
                }
                $row['clusters'] = implode(", ", $row['clusters']);
            }
            if($row['country_id']) {
                $country = explode(",", $row['country_id']);
                foreach($country as $countryId) {
                    $row['countries'][] = $countries[$countryId];
                }
                $row['countries'] = implode(", ", $row['countries']);
            }
            if($row['training_id']) {
                $training = explode(",", $row['training_id']);
                foreach($training as $trainingId) {
                    $row['Training Types'][] = $trainings[$trainingId];
                }
                $row['Training Types'] = implode(", ", $row['Training Types']);
            }
        }
        return $data;
    }
    
} // End of Class