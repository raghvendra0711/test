<?php
class Model_B2BCartPricing extends BaseApp_Model
{

    public function createB2bCartPricing($companyId, $id, $pricingData, $flag)
    {
        $dbM = new Model_Default;
        $relatedData = $this->fetchRelatedData($pricingData);
        $preparedData = $this->prepareData($companyId, $id, $pricingData, $relatedData, $flag);
        $result = "";
        try {
            if (!empty($preparedData['type_of_price']) && $preparedData['type_of_price'] == "flat_price") {
                $result =  $dbM->b2bCartPricings->insert($preparedData);
            }
            elseif (!empty($preparedData['type_of_price']) && $preparedData['type_of_price'] == "product_price" && !empty($preparedData['product_id'])) {
                $result =  $dbM->b2bCartPricings->insert($preparedData);
            }
        } catch (Exception $e) {
            $result = $e->getMessage();
            if(!empty($result)){
                $this->log($result);
            }
        }
        return $result;
    }

    public function updateB2bCartPricing($companyId, $currentId, $updateData, $flag)
    {
        $dbM = new Model_Default;
        $relatedData = $this->fetchRelatedData($updateData);
        $preparedData = $this->prepareData($companyId, $currentId, $updateData, $relatedData, $flag);
        $condition = array(
            'pricing_id' => $currentId,
            'company_id' => intval($companyId),
        );
        try {
            $data = $dbM->b2bCartPricings->find($condition)->toArray();
            if (!empty($preparedData['type_of_price']) && $preparedData['type_of_price'] == "flat_price") {
                if (!empty($data)) {
                    $result = $dbM->b2bCartPricings->update($condition, array('$set' => $preparedData));
                } else {
                    $result =  $dbM->b2bCartPricings->insert($preparedData);
                }
            } elseif (!empty($preparedData['type_of_price']) && $preparedData['type_of_price'] == "product_price" && !empty($preparedData['product_id'])) {
                if (!empty($data)) {
                    $result = $dbM->b2bCartPricings->update($condition, array('$set' => $preparedData));
                } else {
                    $result =  $dbM->b2bCartPricings->insert($preparedData);
                }
            }
            
        } catch (Exception $e) {
            $result = $e->getMessage();
            if(!empty($result)){
                $this->log($result);
              }
        }
        return $result;
    }

    public function updatePrimaryElearningId($courseId, $primaryElearningId)
    {
        $dbM = new Model_Default;
        try {
            $condition = array(
                'product_id' => intval($courseId)
            );
            $updationData = array(
                'primary_eLearning_id' => !empty($primaryElearningId) ? $primaryElearningId : ""
            );
            $multi = array(
                "multiple" => true
            );
            $result = $dbM->b2bCartPricings->update($condition, array('$set' => $updationData), $multi);
        } catch (Exception $e) {
            $result = $e->getMessage();
            if (!empty($result)) {
                $this->log($result);
            }
        }
        return $result;
    }

    public function deleteB2bCartProductData($linkableType,$linkableId)
    {
        $linkableType = !empty($linkableType) ? strtoupper($linkableType) : "";
        $linkableId = !empty($linkableId) ? intval($linkableId) : 0;  
        $dbM = new Model_Default;
        $result = $dbM->b2bCartPricings->remove(array("product_id" => $linkableId, 'product_type' =>$linkableType));
        if ($result != true && is_array($result) && $result['err'] != null) {
            throw new BaseApp_Exception('Error occurred while Deleting data. Mongo error : ' . $result['err']);
        }
    }
    public function deleteB2bCartAgencyData($linkableType,$linkableId,$companyIds,$inclusionFlag)
    {
        $linkableType = !empty($linkableType) ? strtoupper($linkableType) : "";
        $linkableId = !empty($linkableId) ? intval($linkableId) : 0;
        $ids = array();
        if(!empty($companyIds)){
            foreach($companyIds as $key=>$value){
                $ids[] = intval($value['id']);
            }
        }
        $dbM = new Model_Default;
        $result = $dbM->b2bCartPricings->remove(array("product_id" => $linkableId, 'product_type' =>$linkableType,'company_id'=> array($inclusionFlag => $ids)));
        if ($result != true && is_array($result) && $result['err'] != null) {
            throw new BaseApp_Exception('Error occurred while Deleting data. Mongo error : ' . $result['err']);
        }
    }

    public function deleteB2bCartPricingData($companyId, $ppids)
    {
        $ppids = is_array($ppids) ? $ppids : explode(',', $ppids);
        $dbM = new Model_Default;
        $result = $dbM->b2bCartPricings->remove(array("pricing_id" => array('$in' =>$ppids), 'company_id' => intval($companyId)));
        if ($result != true && is_array($result) && $result['err'] != null) {
            throw new BaseApp_Exception('Error occurred while Deleting data. Mongo error : ' . $result['err']);
        }
    }

    public function deleteAllB2bCartPricing($companyId)
    {
        $dbM = new Model_Default;
        $result = $dbM->b2bCartPricings->remove(array('company_id' => intval($companyId)));
        if ($result != true && is_array($result) && $result['err'] != null) {
            throw new BaseApp_Exception('Error occurred while Deleting data. Mongo error : ' . $result['err']);
        }
    }

    public function deleteAgencyProductData($productData, $type, $companyId){
        $productIds = array();
        foreach($productData as $key => $value){
            $productIds[$key] = intval($value);
        }
        $dbM = new Model_Default;
        $result = $dbM->b2bCartPricings->remove(array('company_id' => intval($companyId),"product_id" => array('$in' =>$productIds),"product_type"=>$type));
        if ($result != true && is_array($result) && $result['err'] != null) {
            throw new BaseApp_Exception('Error occurred while Deleting data. Mongo error : ' . $result['err']);
        } 
    }

    public function deleteLearnersRangePricing($company_id, $learners_range_id)
    {
        $sync  = new BaseApp_Synchronizer_B2bPricings();
        $db = $sync->getDao()->getDb();
        if (!empty($learners_range_id)) {
            $learnerRange = $db
                ->select()
                ->from(array('lr' => 'b2b_learners_range'), array('lr_content' => 'content'))
                ->where('lr.id=?', $learners_range_id);
            echo $learnerRange;
            $learnerRangeData = $db->fetchAll($learnerRange);
            $learnerRangeData = !empty($learnerRangeData[0])  ? $learnerRangeData[0] : [];
        }
        $learnersRange = !empty($learnerRangeData['lr_content']) ? $learnerRangeData['lr_content'] : "";
        $dbM = new Model_Default;
        $result = $dbM->b2bCartPricings->remove(array('company_id' => intval($company_id), "learner_content" => $learnersRange));
        if ($result != true && is_array($result) && $result['err'] != null) {
            throw new BaseApp_Exception('Error occurred while Deleting data. Mongo error : ' . $result['err']);
        }
    }

    private function fetchRelatedData($pricingData)
    {
        $sync  = new BaseApp_Synchronizer_B2bPricings();
        $db = $sync->getDao()->getDb();
        $accessDayId = !empty($pricingData['access_day_id']) ? $pricingData['access_day_id'] : 0;
        $trainingId = !empty($pricingData['training_id']) ? $pricingData['training_id'] : 0;
        $countryId = !empty($pricingData['country_id']) ? $pricingData['country_id'] : 0;
        $clusterId = !empty($pricingData['cluster_id']) ? $pricingData['cluster_id'] : 0;
        $learnerRangeId = !empty($pricingData['learners_range_id']) ? $pricingData['learners_range_id'] : 0;
        $linkableType = !empty($pricingData['linkable_type']) ? $pricingData['linkable_type'] : 0;
        $linkableId = !empty($pricingData['linkable_id']) ? $pricingData['linkable_id'] : "";
        $availableFor = array('universal','private_b2b','b2b_only');
        $productInfo = array();
        $returnData = array();
        $accessDays = array();
        $trainingType = array();
        if (!empty($accessDayId)) {
            $accessDaysSql = $db
                ->select()
                ->from(array('ad' => 'accessDays'), array('*'))
                ->where('ad.status=?', 1)
                ->where('ad.day_id=?', $accessDayId)
                ->order(array('ad.day_id'));
            $accessDaysData = $db->fetchAll($accessDaysSql);
            foreach ($accessDaysData as $key => $value) {
                $accessDays[$value['day_id']] = $value['noOfDays'];
            }
        }

        if (!empty($trainingId)) {
            $trainingTypeSql = $db
                ->select()
                ->from(array('tt' => 'trainingTypes'), array('training_id', 'name'))
                ->where('tt.status=?', 1)
                ->where('tt.training_id=?', $trainingId)
                ->order(array('tt.training_id ASC'));
            $trainingTypeData = $db->fetchAll($trainingTypeSql);
            foreach ($trainingTypeData as $key => $value) {
                $trainingType[$value['training_id']] = $value['name'];
            }
        }
        if (!empty($countryId) && !empty($clusterId)) {
            $currencySql = $db->select()
                ->from(array('c' => 'country'), array('country_id', 'cluster_id', 'serviceTax', 'serviceTaxString', 'countryCode' => 'code'))
                ->joinLeft(array('cu' => 'currencies'), "c.currency_id = cu.currency_id", array('symbol_original', 'currency_id', 'code', 'symbol'))
                ->where('cu.status=?', 1)
                ->where('c.country_id=?', $countryId)
                ->where('c.cluster_id=?', $clusterId)
                ->order(array('cu.country_id'));
            $currencyData = $db->fetchAll($currencySql);
        } elseif (!empty($countryId) && empty($clusterId)) {
            $currencySql = $db->select()
                ->from(array('c' => 'country'), array('country_id', 'cluster_id', 'serviceTax', 'serviceTaxString', 'countryCode' => 'code'))
                ->joinLeft(array('cu' => 'currencies'), "c.currency_id = cu.currency_id", array('symbol_original', 'currency_id', 'code', 'symbol'))
                ->where('cu.status=?', 1)
                ->where('c.country_id=?', $countryId)
                ->order(array('cu.country_id'));
            $currencyData = $db->fetchAll($currencySql);
        } elseif (empty($countryId) && !empty($clusterId)) {
            $currencySql = $db->select()
                ->from(array('c' => 'cluster'), array('cluster_id'))
                ->where('c.status=?', 1)
                ->where('c.cluster_id=?', $clusterId);

            $currencyData = $db->fetchAll($currencySql);
        }
    
        $currencyData = !empty($currencyData[0]) ? $currencyData[0] : [];

        if (!empty($learnerRangeId)) {
            $learnerRange = $db
                ->select()
                ->from(array('lr' => 'b2b_learners_range'), array('lr_min' => 'min', 'lr_max' => 'max', 'lr_content' => 'content'))
                ->where('lr.status=?', 1)
                ->where('lr.id=?', $learnerRangeId);
            $learnerRangeData = $db->fetchAll($learnerRange);
            $learnerRangeData = !empty($learnerRangeData[0])  ? $learnerRangeData[0] : [];
        }

        if (!empty($linkableId) && !empty($linkableType) && $linkableType == 'course') {
            $course_sql = $db
                ->select()
                ->from(array('c' => 'courses'), array('course_id', 'primary_label_id', 'label_id', 'name', 'primary_eLearning_id'))
                ->join(array('s' => 'seo'), 's.linkable_id=c.course_id', array('course_url' => 'url'))
                ->where('s.linkable_type=?', "course")
                ->where('s.controller = ?', BaseApp_Dao_Courses::SEO_DEFAULT_CONTROLLER)
                ->where('s.action = ?', BaseApp_Dao_Courses::SEO_DEFAULT_ACTION)
                ->where('s.status = ?', 1)
                ->where('c.is_dummy = ?', 0)
                ->where('c.is_free = ?', 0)
                ->where('c.status = ?', 1)
                ->where('c.course_available_for in (?)',$availableFor)
                ->where('c.course_id = ?', $linkableId);

            $coursesList = $db->fetchAll($course_sql);
            $coursesList = !empty($coursesList[0]) ? $coursesList[0] : [];
            if (!empty($coursesList)) {
                $productInfo['product_id'] = !empty($coursesList['course_id']) ? $coursesList['course_id'] : 0;
                $productInfo['primary_label_id'] = !empty($coursesList['primary_label_id']) ? $coursesList['primary_label_id'] : 0;
                $productInfo['label_id'] = !empty($coursesList['label_id']) ? $coursesList['label_id'] : 0;
                $productInfo['name'] = !empty($coursesList['name']) ? $coursesList['name'] : "";
                $productInfo['primary_eLearning_id'] = !empty($coursesList['primary_eLearning_id']) ? $coursesList['primary_eLearning_id'] : 0;
                $productInfo['url'] = !empty($coursesList['course_url']) ? $coursesList['course_url'] : 0;
            }
        } elseif (!empty($linkableId) && !empty($linkableType) && $linkableType == 'bundle') {
            $bundle_sql = $db
                ->select()
                ->distinct()
                ->from(array('b' => 'bundles'), array('bundle_id', 'bundle_id_frontend' => 'CONCAT("b", bundle_id)', 'primary_label_id', 'label_id', 'title' => 'display_name', 'primary_course_id', 'payment_type_id', 'course_id'))
                ->joinLeft(array('seo' => 'seo'), 'seo.linkable_id = b.bundle_id and seo.linkable_type="bundle" AND controller="' . BaseApp_Dao_Bundles::SEO_DEFAULT_CONTROLLER . '" AND action="' . BaseApp_Dao_Bundles::SEO_DEFAULT_ACTION . '" AND seo.status = 1', array('url'))
                ->where('b.status = ?', 1)
                ->where('b.partialView = ?', 0)
                ->where('seo.status = ?', 1)
                ->where('b.bundle_available_for in (?)', $availableFor)
                ->where('b.bundle_id = ?', $linkableId);
            $bundles = $db->fetchAll($bundle_sql);
            $bundles = !empty($bundles[0]) ? $bundles[0] : [];
            if (!empty($bundles)) {
                $productInfo['product_id'] = !empty($bundles['bundle_id']) ? $bundles['bundle_id'] : 0;
                $productInfo['primary_label_id'] = !empty($bundles['primary_label_id']) ? $bundles['primary_label_id'] : 0;
                $productInfo['label_id'] = !empty($bundles['label_id']) ? $bundles['label_id'] : 0;
                $productInfo['name'] = !empty($bundles['title']) ? $bundles['title'] : "";
                $productInfo['url'] = !empty($bundles['url']) ? $bundles['url'] : "";
                $productInfo['course_id'] = !empty($bundles['course_id']) ? $bundles['course_id'] : [];
            }
        } elseif (!empty($linkableId) && !empty($linkableType) && $linkableType == 'category') {
            $categorySql = $db->select()
                ->from(array('l' => 'labels'), array('label_id', 'name'))
                ->join(array('s' => 'seo'), 's.linkable_id=l.label_id', array('label_url' => 'url'))
                ->where('s.linkable_type=?', "label")
                ->where('s.controller = ?', BaseApp_Dao_Labels::SEO_DEFAULT_CONTROLLER)
                ->where('s.action = ?', BaseApp_Dao_Labels::SEO_DEFAULT_ACTION)
                ->where('s.status = ?', 1)
                ->where('l.status = ?', 1)
                ->where('l.label_id = ?',$linkableId);
            $categoryData = $db->fetchAll($categorySql);
            $categoryData = !empty($categoryData[0]) ? $categoryData[0] : "";
            
            if(!empty($categoryData)){
                $productInfo['product_id'] = !empty($categoryData['label_id']) ? $categoryData['label_id'] : 0;
                $productInfo['name'] = !empty($categoryData['name']) ? $categoryData['name'] : "";
                $productInfo['url'] = !empty($categoryData['label_url']) ? $categoryData['label_url'] : "";
            }

        }

        $returnData['accessDaysData'] = !empty($accessDays) ? $accessDays : "";
        $returnData['trainingType'] = !empty($trainingType) ? $trainingType : "";
        $returnData['currencyData'] = !empty($currencyData) ? $currencyData : "";
        $returnData['learnerRangeData'] = !empty($learnerRangeData) ? $learnerRangeData : "";
        $returnData['productInfo'] = !empty($productInfo) ? $productInfo : "";
        // $returnData['labelData'] = $categoryData;
        return $returnData;
    }

    private function prepareData($companyId, $id, $pricingData, $relatedData, $flag)
    {
        $accessData = array();
        $accessData = !empty($relatedData['accessDaysData']) ? $relatedData['accessDaysData'] : "";
        $trainingTypeData = array();
        $trainingTypeData = !empty($relatedData['trainingType']) ? $relatedData['trainingType'] : "";
        $countryData = !empty($relatedData['currencyData']) ? $relatedData['currencyData'] : "";
        $learnerRangeData = !empty($relatedData['learnerRangeData']) ? $relatedData['learnerRangeData'] : "";
        $productInfo = !empty($relatedData['productInfo']) ? $relatedData['productInfo'] : "";
        

        $data = array();

        if (!empty($pricingData)) {
            $data['company_id'] = !empty($companyId) ? intval($companyId) : 0;
            $data['training_type_id'] = !empty($pricingData['training_id']) ? intval($pricingData['training_id']) : 0;
            if ($pricingData['linkable_type'] == BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_CATEGORY) {
                $data['product_type'] = strtoupper(BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_CATEGORY);
                $data['product_type_id'] = BaseApp_Dao_ProductTypes::TYPE_ID_CATEGORY;
            } elseif ($pricingData['linkable_type'] == BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE) {
                $data['product_type'] = strtoupper(BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE);
                $data['product_type_id'] = BaseApp_Dao_ProductTypes::TYPE_ID_COURSE;
            } elseif ($pricingData['linkable_type'] == BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES) {
                $data['product_type'] = strtoupper(BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES);
                $data['product_type_id'] = BaseApp_Dao_ProductTypes::TYPE_ID_BUNDLE;
            }

            $data['access_day_id'] = !empty($pricingData['access_day_id']) ? intval($pricingData['access_day_id']):[];
            $data['type_of_price'] = !empty($flag) ? $flag : "";
            if ( !empty($pricingData['access_day_id']) && array_key_exists($pricingData['access_day_id'], $accessData)) {
                $data['access_days'] = intval($accessData[$pricingData['access_day_id']]);
                $data['day_configs'] = array($accessData[$pricingData['access_day_id']]);
            }
            if (array_key_exists($pricingData['training_id'], $trainingTypeData)) {
                $data['type'] = $trainingTypeData[$pricingData['training_id']];
                $data['to_show_type'] = $trainingTypeData[$pricingData['training_id']];
            }
            unset($accessData);
            unset($trainingTypeData);
            if (!empty($learnerRangeData)) {
                $data['min_learner'] = !empty($learnerRangeData['lr_min']) ? intval($learnerRangeData['lr_min']) : 0;
                $data['max_learner'] = !empty($learnerRangeData['lr_max']) ? intval($learnerRangeData['lr_max']) : 0;
                $data['learner_content'] = !empty($learnerRangeData['lr_content']) ? $learnerRangeData['lr_content'] : "";
            }

            $data['pricing_id'] = !empty($id) ? $id : 0;
            $data['price'] = !empty($pricingData['price']) ? $pricingData['price'] : "";
            $data['pricing_type'] = !empty($pricingData['flat_price']) ? "flat_price" : "flat_discount";
            $data['flat_discount'] = !empty($pricingData['flat_discount']) ? $pricingData['flat_discount'] : 0; 

            if (!empty($countryData)) {
                $data['country_id'] = !empty($countryData['country_id']) ? intval($countryData['country_id']) : 0;
                $data['cluster_id'] = !empty($countryData['cluster_id']) ? $countryData['cluster_id'] : "";
                $data['pricing_country_id'] = !empty($countryData['country_id']) ? intval($countryData['country_id']) : 0;
                $data['currency'] = !empty($countryData['symbol_original']) ? $countryData['symbol_original'] : "";
                $data['currency_id'] = !empty($countryData['currency_id']) ? $countryData['currency_id'] : "";
                $data['crm_currency_code'] = !empty($countryData['code']) ? $countryData['code'] : "";
                $data['ssvc_country_code'] = !empty($countryData['countryCode']) ? $countryData['countryCode'] : "";
                $data['taxBreakup'] = array();
                $data['serviceTax'] = array();
                $data['taxBreakup'] = array(
                    'tax' => !empty($countryData['serviceTax']) ? $countryData['serviceTax'] : "",
                    'string' => !empty($countryData['serviceTaxString']) ? $countryData['serviceTaxString'] : "",
                );
                $data['serviceTax'] = array(
                    'tax' => !empty($countryData['serviceTax']) ? $countryData['serviceTax'] : "",
                    'string' => !empty($countryData['serviceTaxString']) ? $countryData['serviceTaxString'] : "",
                );
            }

            if (!empty($productInfo)) {
                $data['product_id'] = !empty($productInfo['product_id']) ? intval($productInfo['product_id']) : 0;
                $data['product_name'] = !empty($productInfo['name']) ? ($productInfo['name']) : "";
                $data['primary_label_id'] = !empty($productInfo['primary_label_id']) ? ($productInfo['primary_label_id']) : "";
                $data['url'] = !empty($productInfo['url']) ? ($productInfo['url']) : "";
                $data["primary_eLearning_id"] = !empty($productInfo['primary_eLearning_id']) ? $productInfo['primary_eLearning_id'] : "";
            }
            // if(!empty($categoryData)){
            //     $data['primary_label_id'] = !empty($categoryData['label_id']) ? ($categoryData['label_id']) : ""; 
            // }
        }
        $excludedIndex = array('max_learner');
        $resData = !empty($data) ? $this->emptyCheck($data,$excludedIndex) : array();
        return  $resData;
    }

    private function emptyCheck($data = [],$exclude=[]){
        foreach ($data as $key => $value) {
            if (!in_array($key, $exclude)) {
                if (empty($data[$key])) {
                    unset($data[$key]);
                }
            }
        }
        return $data;
    }
    private function log($message, $data = null)
    {
        $logMessage = "\n[" . date('Y-m-d H:i:s'). "]" ."B2BCartPricing"." $message";
        if (!empty($data)) {
            $logMessage .= ' [ ' . json_encode($data) . ' ]';
        }
        file_put_contents(APPLICATION_PATH . '/../../backend/error.log', $logMessage, FILE_APPEND);
    }
}
