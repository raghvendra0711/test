<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_CoursePreviewVideos extends BaseApp_Dao_CoursePreviewVideos{	


    protected $fileFormatsArr = array('.wmv'=>'.wmv','.rm'=>'.rm','.m4p'=>'.m4p','.mpg'=>'.mpg','.mpeg'=>'.mpeg','3gp'=>'3gp','.flv'=>'.flv');

    public function getFileFormats(){
            return $this->fileFormatsArr;
    }
    
    public function saveVideo($data, $courseId, $trainingId) {
        $db = $this->getDb();
	$objVideo = new self();
        $db->beginTransaction();
        try{
            $conds = array(
                'course_id=?' => $courseId,
                'training_id=?' => $trainingId
            );
            $properties = $objVideo->fetchAll($conds);
            foreach($properties as $property){
                $objVideo->clean();
                $objVideo->setId($property['preview_video_id']);
                $objVideo->delete();
            }
            foreach($data as $dataSave) {
                $dataSave['course_id'] = $courseId;
                $dataSave['training_id'] = $trainingId;
                $objVideo->setFromArray($dataSave)->save();              
            }
            
            $db->commit();
            return true;
        }
        catch (Exception $e){
            if(APPLICATION_ENV == 'development')
            prd($e->getMessage()); // message wont work in live
            $db->rollBack();
            return false;
        }
    }    
    
    public function getDataToEdit($courseId, $trainingId) {
        $return = array();
        $conds = array(
            'course_id=?' => $courseId,
            'training_id=?' => $trainingId
        );
        $opts = array(
            'columns' => array(
                'chapter_name',
                'name', 
                'url',
                'duration'
            )
        );
        $counter = -1;
        $chapterList = array();
        foreach($this->fetchAll($conds, $opts, false) as $dataReal) {
            $chapterKey = array_search($dataReal['chapter_name'], $chapterList);
            if($chapterKey === false) {
                $counter++;
                $chapterList[$counter] = $dataReal['chapter_name'];
                $return[$counter]['chapterName'] = $dataReal['chapter_name'];
                unset($dataReal['chapter_name']);
                $return[$counter][] = $dataReal;
            }
            else {
                $return[$chapterKey]['chapterName'] = $dataReal['chapter_name'];
                unset($dataReal['chapter_name']);
                $return[$chapterKey][] = $dataReal;
            }            
        }
        unset($chapterList);
        return $return;
    }
} // End of Class