<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Model_Pricings extends BaseApp_Dao_Pricings{

    public function addPricing($data){
        $db = $this->getDb();
        $objPricing = new self();
        $db->beginTransaction();
        try{
            if(isset($data['countryCityMode']) && $data['city_id']) {
                $data['country_id'] = $data['countryCityMode'];
                unset($data['countryCityMode']);
            }
            $basePrice =  floatval($data['price']);
            $maxDiscount =  floatval($data['discount']);
            $minPrice = $this->calculatePriceRange($basePrice,$maxDiscount);
            $data['minPrice'] = $minPrice;
            $objPricing->clean();
            $objPricing->setFromArray($data)->save();
            $db->commit();
            $objCourse = new Model_Courses($data['course_id']);
            $cdnPurgeData = $this->buildCdnPurgeData($data['course_id'],'course','price Added for '.$objCourse->name);
            $objCdn = new Model_CdnPurgeLog();
            if(!empty($cdnPurgeData))
                $objCdn->InsertCdnPurgeLog($cdnPurgeData);
            return $objPricing->pricing_id;
        }catch (Exception $e){
            $db->rollBack();
            prd($e->getMessage());
            return false;
        }
    }


    public function calculatePriceRange($basePrice,$maxDiscount){
        return $basePrice -($basePrice * ($maxDiscount / 100));
    }

    public function validatePricing($basePrice,$newDiscount,$minPirce){
        $newPrice = $this->calculatePriceRange($basePrice,$newDiscount);
        if( ( $newPrice <= $basePrice ) && ($newPrice >= $minPirce)){
            return $newPrice;
        }else{
            return '';
        }
    }

    public function pricingUnique($courseId,$trainindId,$dayId,$allLocation,$clusterId,$countryId,$cityId){
        $objPricing = new self();
        $selectArr = array('course_id =?'=>$courseId,'training_id'=>$trainindId,'access_day_id'=>$dayId,'status' => 1);
        if($allLocation == 0){
            $selectArr['allLocation =?'] = 0;
        }
        if(!empty($clusterId))
            $selectArr["CONCAT(',', cluster_id,',') LIKE (?)"] = '%,'.$clusterId.',%';
        if(!empty($countryId)){
            $selectArr["CONCAT(',', country_id,',') LIKE (?)"] = '%,'.$countryId.',%';
            $selectArr["city_id is NULL"] = '';
        }
        if(!empty($cityId))
            $selectArr["CONCAT(',', city_id,',') LIKE (?)"] = '%,'.$cityId.',%';
        $pricingData = $objPricing->fetchAll($selectArr);
        if(!empty($pricingData)){
            return false;
        }
        return true;
    }

    public function getByLinkable($linkableId, $linkableType) {
        return array();
    }

    public function getCourseIds($trainindIdArr,$type){
        $courseIds = array();
        $courseData = $this->fetchAll(array('training_id IN (?)'=> $trainindIdArr,'type = ?'=>$type),array('columns'=>array('course_id'),'distinct'=>true));
        if(empty($courseData))
            return $courseIds;
        foreach ($courseData as $key => $value) {
            array_push($courseIds,$value['course_id']);
        }
        return $courseIds;
    }


    public function getPricingData($countryId=false, $cityId=false, $clusterId=false, $courseId, $trainingId, $accessId) {
        $viewData = array();
        if($cityId) {
            $selectArr = array(
                'course_id =?' =>intval($courseId),
                'training_id =?' =>intval($trainingId),
                'access_day_id =?'=>$accessId,
                'city_id=?' => $cityId
            );
            if($countryId) {
                $selectArr['country_id = ?'] = $countryId;
            }
            $viewData = $this->fetchAll($selectArr);
        }
        if(empty($viewData) ){
            if($countryId) {
                $viewData = $this->fetchAll(array(
                    'course_id =?' =>intval($courseId),
                    'training_id =?' =>intval($trainingId),
                    'access_day_id =?'=>$accessId,
                    'country_id =?' => $countryId,
                    'city_id=?' => new Zend_Db_Expr('"" OR city_id IS NULL')
                ));
            }

            if(empty($viewData)){
                if(!$clusterId && $countryId) {
                    $objCountry =  new Model_Country();
                    $clusterData = current($objCountry->fetchAll(array('country_id =?'=> intval($countryId))));
                    $clusterId = $clusterData['cluster_id'];
                }
                if($clusterId){
                    $viewData = $this->fetchAll(array(
                        'course_id =?' =>intval($courseId),
                        'training_id =?' =>intval($trainingId),
                        'access_day_id =?'=>$accessId,
                        "cluster_id=?" => $clusterId
                    ));
                }
            }
        }
        $return = array();
        if(!empty($viewData)){
            $viewData = current($viewData);
            $return = array(
                'price' => $viewData['price'],
                'discount' => $viewData['discount'],
                'minPrice' => $viewData['minPrice'],
                'pricing_id' => $viewData['pricing_id']
            );
        }
        return $return;
    }

    public function getPricingByCity($countryId, $cityId, $courseId, $trainingId, $accessId) {
        $selectArr = array(
            'course_id =?' =>intval($courseId),
            'training_id =?' =>intval($trainingId),
            'access_day_id =?'=>$accessId,
            'city_id=?' => $cityId,
            'country_id = ?' => $countryId
        );
        return $this->fetchAll($selectArr);
    }

    public function getPricingByCountry($countryId, $courseId='', $trainingId='', $accessId='',$free_trial = '') {
        $selectArr = array(
            'country_id =?' => $countryId,
            'city_id=?' => new Zend_Db_Expr('"" OR city_id IS NULL')
        );
        if (!empty($courseId)) {
            $selectArr['course_id =?'] = intval($courseId);
        }
        if (!empty($accessId)) {
            $selectArr['access_day_id =?'] = $accessId;
        }
        if (!empty($free_trial)) {
            $selectArr['free_trial =?'] = 1;
        }
        if (!empty($trainingId)) {
            if (is_array($trainingId)) {
                $selectArr['training_id IN (?)'] = $trainingId;
            } else
                $selectArr['training_id =?'] = intval($trainingId);
        }
        return $this->fetchAll($selectArr);
    }

    public function getPricingByCluster($clusterId, $courseId='', $trainingId='', $accessId='',$free_trial = '') {
        $conds = array(
            "cluster_id=?" => $clusterId
        );

        if (!empty($courseId)) {
            $conds['course_id =?'] = intval($courseId);
        }

        if (!empty($accessId)) {
            $conds['access_day_id =?'] = $accessId;
        }
        if (!empty($free_trial)) {
            $conds['free_trial =?'] = 1;
        }
        if (!empty($trainingId)) {
            if (is_array($trainingId)) {
                $conds['training_id IN (?)'] = $trainingId;
            } else
                $conds['training_id =?'] = intval($trainingId);
        }
        return $this->fetchAll($conds);
    }



    public function enableFreeTrial($pricingId) {
        $db = $this->getDb();
        $objPricing = new self();
        $dataUpdate = array(
            'free_trial' => 1,
        );
        $db->beginTransaction();
        try{
            $objPricing->clean();
            $objPricing->setId($pricingId);
            if($objPricing->setFromArray($dataUpdate)->update()) {
                $db->commit();
                return true;
            }
            else {
                $db->rollBack();
                return false;
            }
        }catch (Exception $e){
            $db->rollBack();
            throw $e;
            return false;
        }
    }

    public function disableFreeTrial($data) {
        $pricingData = array();
        if (!empty($data['country_id'])) {
            if (!empty($data['label_id'])) {
                $pricingData = $this->getPricingsByLabel(array('country_id' => $data['country_id'], 'label_id' => $data['label_id']));
            } else {
                $pricingData = $this->getPricingByCountry($data['country_id'], '', '', '', 1);
            }
        } else if (!empty($data['cluster_id'])) {
            if (!empty($data['label_id'])) {
                $pricingData = $this->getPricingsByLabel(array('cluster_id' => $data['cluster_id'], 'label_id' => $data['label_id']));
            } else {
                $pricingData = $this->getPricingByCluster($data['cluster_id'], '', '', '', 1);
            }
        }
        $db = $this->getDb();
        $dataUpdate = array(
            'free_trial' => 0,
        );
        try{
            if (!empty($pricingData)) {
                foreach ($pricingData as $key => $value) {
                    if (!empty($value['pricing_id'])) {
                        $pricingId = $value['pricing_id'];
                        $objPricing = new self();

                        if ($value['free_trial'] == 1) {
                            $db->beginTransaction();
                            $objPricing->clean();
                            $objPricing->setId($pricingId);
                            if ($objPricing->setFromArray($dataUpdate)->update()) {
                                $db->commit();
                            }
                            else {
                                $db->rollBack();
                                return false;
                            }
                        }
                    }
                }
            }
            return true;
        } catch (Exception $e){
            $db->rollBack();
            throw $e;
            return false;
        }
    }

    public function deletePricing($pricingId, &$message='') {
        $objPricing = new self();
        $pricingData = current($objPricing->fetchAll(array('pricing_id=?'=>$pricingId)));
        if($pricingData['city_id']) {
            return $this->_deleteCityLevel($pricingId, $pricingData['city_id'], $pricingData['cluster_id'], $pricingData['course_id'], $pricingData['access_day_id'], $message);
        }
        else if($pricingData['country_id']) {
            return $this->_deleteCountryLevel($pricingId, $pricingData['country_id'], $pricingData['cluster_id'], $pricingData['course_id'], $pricingData['access_day_id'], $message, $pricingData['training_id']);
        }
        else if($pricingData['cluster_id']) {
            return $this->_deleteClusterLevel($pricingId, $pricingData['cluster_id'], $pricingData['course_id'], $pricingData['access_day_id'], $message, $pricingData['training_id']);
        }
        else {
            $message = 'No location data found';
            return false;
        }
    }

    private function _deleteCityLevel($pricingId, $cityId, $clusterId, $courseId, $accessDayId, &$message){
        $objPricing = new self();
        $modelCity = new Model_City();
        if(!$cityData = current($modelCity->fetchAll(array('city_id=?' => $cityId), array('columns' => array('country_id')), false))) {
            $message = 'Country missing for pricing';
            return false;
        }

        //if country level pricing exists delete price
        if(!$countryId = $cityData['country_id']) {
            $message = 'Country missing for pricing';
            return false;
        }
        $conds = array(
            'country_id=?'=>$countryId,
            'course_id=?'=>$courseId,
            'access_day_id=?'=>$accessDayId,
            'city_id=? OR city_id IS NULL'=> ''
        );
        $objPricing->fetchAll($conds);
        if($objPricing->fetchAll($conds)) {
            return $this->_deletePricing($pricingId);
        }

        //if cluster level price exists delete price
        if(!$clusterId) {
            $modelCountry = new Model_Country();
            $countryData = current($modelCountry->fetchAll(array('country_id=?'=>$countryId), array('cluster_id')));
            $clusterId = $countryData['cluster_id'];
        }
        if($clusterId) {
            if($objPricing->fetchAll(array('cluster_id=?'=>$clusterId, 'course_id=?'=>$courseId, 'access_day_id=?'=>$accessDayId))) {
                return $this->_deletePricing($pricingId);
            }
        }
        //if any workshop exists for this city then dont allow to delete
        $modelWorkshop = new Model_Workshop();
        if($modelWorkshop->fetchAll(array('city_id=?'=>$cityId, 'course_id=?'=>$courseId, 'access_day_id=?'=>$accessDayId),array(), false)) {
            $message = 'There are some workshops exists for this city';
            return false;
        }
        return $this->_deletePricing($pricingId);
    }

    private function _deleteCountryLevel($pricingId, $countryId, $clusterId, $courseId, $accessDayId, &$message, $trainingTypeId) {
        $objPricing = new self();

        //delete data from b2bPricing Table
        $objB2bProduct = new Model_B2BProductPricing();
        if(!$objB2bProduct->deleteProductPriceClusterCountryLevel($courseId,$countryId,false,'course', $trainingTypeId)){
            return false;
        }
        

        
        //if cluster level price exists delete price
        if(!$clusterId) {
            $modelCountry = new Model_Country();
            $countryData = current($modelCountry->fetchAll(array('country_id=?'=>$countryId), array('cluster_id')));
            $clusterId = $countryData['cluster_id'];
        }
        if($clusterId) {
            if($objPricing->fetchAll(array('cluster_id=?'=>$clusterId, 'course_id=?'=>$courseId, 'access_day_id=?'=>$accessDayId))) {
                return $this->_deletePricing($pricingId);
            }
        }

        //if any workshop exists for the country then donot allow to delete.
        //Note: As we save country id for city level workshop also, no need to check city level workshops (lets revisit)
        $modelWorkshop = new Model_Workshop();
        if($modelWorkshop->fetchAll(array('country_id=?'=>$countryId, 'course_id=?'=>$courseId, 'access_day_id=?'=>$accessDayId), array(), false)) {
            $message = 'There are some workshops exists for this location';
            return false;
        }
        return $this->_deletePricing($pricingId);
    }

    private function _deleteClusterLevel($pricingId, $clusterId, $courseId, $accessDayId, &$message , $trainingTypeId){
        $objPricing = new self();
        //if any cluster level workshops exists then donot allow to delete
        if(!$clusterId) {
            $message = 'Cluster missing';
            return false;
        }
        $modelWorkshop = new Model_Workshop();
        //if any workshop exists for country/city level, check if price exists for that then only allow
        $modelCountry = new Model_Country();
        $countryIds = array();
        foreach($modelCountry->fetchAll(array('cluster_id=?'=>$clusterId), array('columns'=> array('country_id'))) as $countryData) {
            $countryIds[] = $countryData['country_id'];
        }
        if(!$countryIds) {
            $message = 'No countries exists under this cluster';
            return false;
        }
        //delete data from b2bPricing Table        
        $objB2bProduct = new Model_B2BProductPricing();
        
        if(!$objB2bProduct->deleteProductPriceClusterCountryLevel($courseId,$clusterId,true,'course',$trainingTypeId)){
            return false;
        }

        if(!$workShopData = $modelWorkshop->fetchAll(array('country_id IN (?)'=>$countryIds, 'course_id=?'=>$courseId, 'access_day_id=?'=>$accessDayId), array('columns' => array('country_id', 'city_id', 'workshop_id')), false)) {            
            return $this->_deletePricing($pricingId);
        }
        foreach($workShopData as $workShopDataSingle) {
            if(!$workShopDataSingle['country_id']) {
                $message = 'Country missing for a workshop with id:'.$workShopDataSingle['workshop_id'];
                return false;
            }
            if($workShopDataSingle['city_id']) {
                if(!$objPricing->fetchAll(array('city_id=?'=>$workShopDataSingle['city_id'], 'course_id=?'=>$courseId, 'access_day_id=?'=>$accessDayId))) {
                    $message = 'City level pricing missing for the workshop:'.$workShopDataSingle['workshop_id'].'and city id:'.$workShopDataSingle['city_id'];
                    return false;
                }
            }
            elseif(!$objPricing->fetchAll(array('country_id=?'=>$workShopDataSingle['country_id'], 'course_id=?'=>$courseId, 'access_day_id=?'=>$accessDayId))) {
                $message = 'Country level pricing missing for the workshop:'.$workShopDataSingle['workshop_id'].'and country id:'.$workShopDataSingle['city_id'];
                return false;
            }
        }
        return $this->_deletePricing($pricingId);
    }

    private function _deletePricing($pricingId) {
        $objPricing = new self();
        $db = $this->getDb();
	    $db->beginTransaction();
        try{
            $objPricing->clean();
            $objPricing->setId($pricingId);
            $objPricing->delete();
            $db->commit();
            $objCourse = new Model_Courses($objPricing->course_id);
            $cdnPurgeData = $this->buildCdnPurgeData($objPricing->course_id,'course','price Deleted for '.$objCourse->name);
            $objCdn = new Model_CdnPurgeLog();
            if(!empty($cdnPurgeData))
                $objCdn->InsertCdnPurgeLog($cdnPurgeData);
            return true;
        }
        catch (Exception $e){
            $db->rollBack();
            return false;
        }
    }

    public function getAccessDaysForCourse($courseId, $trainingId) {
        $returnData = array();
        $conds = array(
            'course_id=?' => $courseId,
            'training_id=?' => $trainingId
        );
        foreach ($this->fetchAll($conds, array('columns' => array('access_day_id'))) as $days) {
            $returnData[] = $days['access_day_id'];
        }
        return $returnData;
    }

    public function buildCdnPurgeData($courseId,$action){
        $returnArr = array();
        // $config = Zend_Registry::get('config');
        // $popularCourses = $config->get('popular_courses');
        // $popularCourses = $popularCourses->toArray();
        // $objSeo = new Model_Seo();
        // $seoData = current($objSeo->fetchAll(array('linkable_id = ?'=>$courseId,'linkable_type =?'=>'course'),array('columns'=>array('url','linkable_id'))));
        // if(!empty($seoData)){
        //     array_push($returnArr,array('linkable_id'=>$seoData['linkable_id'],'linkable_type'=>'lecture','action'=>$action,'url'=>$seoData['url'],'created_at'=>time(),'updated_at'=>time()) );
        // }
        // if(in_array($courseId,$popularCourses)){
        //     array_push($returnArr,array('linkable_id'=>$courseId,'linkable_type'=>'course','action'=>$action,'url'=>'/','created_at'=>time(),'updated_at'=>time()));
        // }
        return $returnArr;
    } // end of function
    public function getPricingByCourseIds($isClusterOrCountry, $countryOrClusterId, $courseIds = array(), $trainingType = '')
    {
        if ($trainingType == BaseApp_Dao_TrainingTypes::TYPE_ELEARNING_NAME) {
            $trainingId = BaseApp_Dao_TrainingTypes::TYPE_ELEARNING;
        } else if ($trainingType == BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS_NAME) {
            $trainingId = BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS;
        }

        if ($isClusterOrCountry == BaseApp_Dao_Country::TYPE_CLUSTER) {

            $conds = array(
                "cluster_id=?" => $countryOrClusterId
            );
        } else if ($isClusterOrCountry == BaseApp_Dao_Country::TYPE_COUNTRY) {
            $conds = array(
                'country_id =?' => $countryOrClusterId,
                'city_id=?' => new Zend_Db_Expr('"" OR city_id IS NULL')
            );
        }
        if (!empty($courseIds)) {
            $conds['course_id IN (?)'] = $courseIds;
        }
        if (!empty($trainingId)) {
            if (is_array($trainingId)) {
                $conds['training_id IN (?)'] = $trainingId;
            } else
                $conds['training_id =?'] = intval($trainingId);
        }
        $data = $this->fetchAll($conds);
        if(!empty($data)){
            $data = array_column($data,'course_id');
        }
        else{

            if ($trainingType == BaseApp_Dao_TrainingTypes::TYPE_ELEARNING_NAME) {
                $trainingId = BaseApp_Dao_TrainingTypes::TYPE_ELEARNING;
            }
            else if ($trainingType == BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS_NAME) {
                $trainingId = BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS;
            }

            if ($isClusterOrCountry == BaseApp_Dao_Country::TYPE_COUNTRY) {

            $course = new Model_Courses();
            $clusterIdBasedOnCountryId = $course->getClusterId($countryOrClusterId);

            $conds = array(
                'cluster_id=?'=> $clusterIdBasedOnCountryId 
            );


            }
            if (!empty($courseIds)) {
                $conds['course_id IN (?)'] = $courseIds;
            }
            if (!empty($trainingId)) {
                if (is_array($trainingId)) {
                    $conds['training_id IN (?)'] = $trainingId;
                } 
                else
                    $conds['training_id =?'] = intval($trainingId);
            }

            $data = $this->fetchAll($conds);
            if(!empty($data)){
            $data = array_column($data,'course_id');
            }
        }
        return $data;
    }
} // End of Class
