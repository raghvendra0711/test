<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_Addons extends BaseApp_Dao_Addons{	


} // End of Class