<?php

class Model_LearnersRange extends BaseApp_Dao_LearnersRange {

    public function saveB2BLearnerRange($companyId, $dataArr) {
        try {
            if (!empty($dataArr)) {
                foreach ($dataArr as $key => $row) {
                    if (!empty($row['id'])) {
                        $this->clean();
                        $param = array('min' => $row['min'], 'max' => $row['max'], 'content' => $row['content']);
                        $this->setId($row['id']);
                        $this->setFromArray($param)->update();
                        $uLearnersRangeData = array(
                            'learnersRangeId' => $row['id'],
                            'companyId' => $companyId,
                            'min' => $row['min'],
                            'max' => $row['max']
                        );
                       /**
                        * Remove Update Learners Range.
                        */ 
                       // $this->_updateLearnersRange($uLearnersRangeData);
                    } else {
                        $value['min'] = $row['min'];
                        $value['max'] = $row['max'];
                        $value['content'] = $row['content'];
                        $value['status'] = 1;
                        $value['company_id'] = (int) $companyId;
                        $this->setFromArray($value)->save();
                    }
                }
            }
            return true;
        } catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }

    public function getByLinkable($companyId) {
        return $this->fetchAll(array("company_id = ?" => $companyId), array('columns' => array('id', 'min', 'max')));
    }

    public function updateLearnerRangeStatus($learnerRangeId) {
        if (!empty($learnerRangeId)) {
            $this->clean();
            $this->setId($learnerRangeId);
            $this->setFromArray(array('status' => 0))->update();
        }
        return true;
    }

//    private function _updateLearnersRange($params) {
//        try {
//            if (!empty($params)) {
//                /**
//                 * Update Learners Ranges In Flat Pricing
//                 */
//                $b2bPriObj = new Model_B2BFlatPricing();
//                $b2bPriObj->updateRangeDataByRangeId($params);
//                /**
//                 * Update Learners Ranges In Product Pricing
//                 */
//                $b2bProPriObj = new Model_B2BProductPricing();
//                $b2bProPriObj->updateRangeDataByRangeId($params);
//                return true;
//            }
//        } catch (Exception $e) {
//            if (APPLICATION_ENV == 'development')
//                throw $e;
//            return false;
//        }
//
//        return false;
//    }

}

?>