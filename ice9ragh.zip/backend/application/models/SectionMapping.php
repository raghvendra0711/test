<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Model_SectionMapping extends BaseApp_Dao_SectionMapping{

    const HAS_ORDER_TRUE = true;
    const HAS_ORDER_FALSE = false;
    
    public function saveProductSectionData($linkableId,$linkableType,$sectionIdArr, $is_top = FALSE, $hasOrder = Model_SectionMapping::HAS_ORDER_FALSE, $sectionType = null,$status = false) {
        try{
            $fields = array('linkable_id =?'=>$linkableId,'linkable_type =?'=>$linkableType,'status =?'=>1);
            if($is_top){
                $fields['show_at_top =?'] = 1;
            }else if($linkableType == BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_COURSE){
                $fields['show_at_top =?'] = 0;
            }
            $checkExisting = array();
            if(empty($sectionType)) {
                $checkExisting = $this->fetchAll($fields);
            } else {
                $modelProductSectionData = new Model_ProductSectionData();                
                $order = 'sm.id ASC';
                $conditions = array();
                $conditions['sm.show_at_top =?'] = $is_top ? 1 : 0;
                $checkExisting = $modelProductSectionData->getDataByType($linkableId, $linkableType, $sectionType, true, $order, $conditions);
            }
            
            $isSame = true;
            if(!empty($hasOrder)) {
                if (count($sectionIdArr) !== count($checkExisting) || (implode(',', $sectionIdArr) !== implode(',', array_column($checkExisting, 'section_id')))) {
                   $isSame = false; 
                }
            }
            if ($hasOrder && $isSame) {
                return;
            } else if ($hasOrder) {
                if(!empty($sectionType)) {
                    $this->removeProductMappingBySection($linkableId, $linkableType, $sectionType, array('is_top' => $is_top));
                } else {
                    $this->removeProductSectionData($linkableId, $linkableType);
                }
                $checkExisting = array();
            }
            if(empty($status) && $status==false){
            if(!empty($checkExisting)){
                $removeList = array();
                foreach ($checkExisting as $key => $value) {
                    if(in_array($value['section_id'], $sectionIdArr)){
                        $keySec = array_search($value['section_id'], $sectionIdArr);
                        unset($sectionIdArr[$keySec]);
                    }else{
                        if(!empty($sectionType)) {
                            $removeList[] = $value['id'];
                        } else {
                            $this->clean();
                            $this->setId($value['id']);
                            $this->setFromArray(array('status'=>0))->update();
                        }
                    }
                }
                if(!empty($removeList)) {
                    $extraData = array('is_top' => $is_top, 'section_ids' => $removeList);
                    $this->removeProductMappingBySection($linkableId, $linkableType, $sectionType, $extraData);
                }
            }
        }
            if(!empty($sectionIdArr)){
                foreach ($sectionIdArr as $key => $value) {
                    $this->clean();
                    $data['linkable_id'] = $linkableId;
                    $data['linkable_type'] = $linkableType;
                    $data['section_id'] = $value;
                    if($is_top)
                        $data['show_at_top'] = 1;
                    $this->setFromArray($data)->save();
                }
            }
            return true;
        }catch (Exception $e){
            if (APPLICATION_ENV == 'development')
                throw $e;
           return false;
        }
    }
    
    public function removeProductMappingBySection($linkableId, $linkableType, $sectionType, $extraData = array()) {
        try{
            $is_top = isset($extraData['is_top']) ? $extraData['is_top'] : null;
            $removeIds = empty($extraData['section_ids'])?array():$extraData['section_ids'];
            $fields = array('linkable_id =?'=>$linkableId,'linkable_type =?'=>$linkableType,'status =?'=>1);
            if($is_top){
                $fields['show_at_top =?'] = 1;
            }else{
                $fields['show_at_top =?'] = 0;
            }
            $sectionDataModel = new Model_ProductSectionData();
            $sectionData = $sectionDataModel->getDataByType($linkableId, $linkableType, $sectionType, true);
            $sectionIds = array_column($sectionData, 'id');
            if(!empty($removeIds) && is_array($removeIds)) {
                $sectionIds = array_intersect($removeIds, $sectionIds);
            }
            if(!empty($sectionIds)){
                foreach ($sectionIds as $id) {
                    $this->clean();
                    $this->setId($id);
                    $this->setFromArray(array('status'=>0))->update();
                }
            }
        }catch (Exception $e){
            if (APPLICATION_ENV == 'development')
                throw $e;
           return false;
        }
    }

    public function removeProductSectionData($linkableId,$linkableType,$is_top = FALSE) {
        try{
            $fields = array('linkable_id =?'=>$linkableId,'linkable_type =?'=>$linkableType,'status =?'=>1);
            if($is_top){
                $fields['show_at_top =?'] = 1;
            }else{
                $fields['show_at_top =?'] = 0;
            }

            $checkExisting = $this->fetchAll($fields);
            if(!empty($checkExisting)){
                foreach ($checkExisting as $key => $value) {
                    $this->clean();
                    $this->setId($value['id']);
                    $this->setFromArray(array('status'=>0))->update();
                }
            }
        }catch (Exception $e){
            if (APPLICATION_ENV == 'development')
                throw $e;
           return false;
        }
    }
    
    public function addProductSectionData($linkableId,$linkableType,$sectionIdArr, $is_top = FALSE) {
        try{
            if(!empty($sectionIdArr)){
                foreach ($sectionIdArr as $key => $value) {
                    $this->clean();
                    $data['linkable_id'] = $linkableId;
                    $data['linkable_type'] = $linkableType;
                    $data['section_id'] = $value;
                    if($is_top)
                        $data['show_at_top'] = 1;
                    $this->setFromArray($data)->save();
                }
            }
            return true;
        }catch (Exception $e){
            if (APPLICATION_ENV == 'development')
                throw $e;
           return false;
        }
    }

    public function saveProductSectionDataBySectionId($linkableIdArr,$linkableType,$sectionId,$type=0,$sectionMapId=0) {
        try{           
            if( in_array($type,array(BaseApp_Dao_CourseFaq::COURSE_RESOURCE_BENEFITS))){
                $checkExisting = array();
                if($linkableType == BaseApp_Dao_SectionMapping::COURSE_FAQ_LINKABLE_TYPE){
                    $checkExisting = $this->fetchAll(array('id =?'=> $sectionMapId,'section_id =?'=> $sectionId,'linkable_id=?'=>!empty($linkableIdArr[0]) ? $linkableIdArr[0] : 0,'linkable_type =?'=>$linkableType));
                }else if($linkableType == BaseApp_Dao_SectionMapping::HIRING_COMPANY_LINKABLE_TYPE){
                    $checkExisting = $this->fetchAll(array('section_id =?'=> $sectionId,'linkable_type =?'=>$linkableType));
                }                
                if(!empty($checkExisting)){
                    $existingLinkable = array();
                    foreach ($checkExisting as $key => $value) {
                        $this->clean();
                        $this->setId($value['id']);
                        $data = array();
                        $data['linkable_id'] = $value['linkable_id'];
                        $data['linkable_type'] = $linkableType;
                        $data['section_id'] = $sectionId;                                               
                        if(in_array($linkableType,array(BaseApp_Dao_SectionMapping::HIRING_COMPANY_LINKABLE_TYPE))){
                            $data = array();
                            $existingLinkable[] = $value['linkable_id'];
                            //$data['status'] = !in_array($value['linkable_id'],$linkableIdArr) ? 0:1;
                            $data['status'] = 0;
                        }                        
                        $this->setFromArray($data)->update();
                    }
                    
                    if(in_array($linkableType,array(BaseApp_Dao_SectionMapping::HIRING_COMPANY_LINKABLE_TYPE))){
                        //$toAddNew = array_diff($linkableIdArr,$existingLinkable);                        
                        $toAddNew = $linkableIdArr;                        
                        if(!empty($toAddNew)){
                            foreach ($toAddNew as $toAdd) {
                                $this->clean();
                                $data = array();
                                $data['linkable_id'] = $toAdd;
                                $data['linkable_type'] = $linkableType;
                                $data['section_id'] = $sectionId;
                                $this->setFromArray($data)->save();
                            }
                        }
                    }
                }else{
                    foreach ($linkableIdArr as $key => $value) {
                        $this->clean();
                        $data = array();
                        $data['linkable_id'] = $value;
                        $data['linkable_type'] = $linkableType;
                        $data['section_id'] = $sectionId;
                        $this->setFromArray($data)->save();
                    }
                }
            }else{
                $checkExisting = $this->fetchAll(array('linkable_type =?'=>$linkableType,'section_id =?'=> $sectionId));               
                if(!empty($checkExisting)){
                    foreach ($checkExisting as $key => $value) {
                        $this->clean();
                        $this->setId($value['id']);
                        $this->setFromArray(array('status'=>0))->update();
                    }
                }
                foreach ($linkableIdArr as $key => $value) {
                    $this->clean();
                    $data['linkable_id'] = $value;
                    $data['linkable_type'] = $linkableType;
                    $data['section_id'] = $sectionId;
                    $data['status'] = 1;
                    $this->setFromArray($data)->save();
                }
            }
            return $this->_id;
        }catch (Exception $e){
            if (APPLICATION_ENV == 'development')
                throw $e;
                return false;
        }
    }

    public function disableSecMapBySectionId($linkableId,$linkableType,$sectionId) {
        try{
            $cond = array('linkable_type =?'=>$linkableType,'section_id =?'=> $sectionId);
            if (!empty($linkableId)) {
                $cond['linkable_id =?'] = $linkableId;
            }
            $checkExisting = $this->fetchAll($cond);
            if(!empty($checkExisting)){
                foreach ($checkExisting as $key => $value) {
                    $this->clean();
                    $this->setId($value['id']);
                    $this->setFromArray(array('status'=>0))->update();
                }
            }
            return true;
        }catch (Exception $e){
            if (APPLICATION_ENV == 'development')
                throw $e;
                return false;
        }
    }
    public function getByProduct($linkableId, $linkableType,$sectionType) {

        $sql = $this->getDb()->select()
                                    ->from(array('sm' => 'sectionMapping'),array('linkable_id','linkable_type'))
                                    ->join(array('ps' => 'productSectionData'), 'sm.section_id = ps.id' ,array('*'))
                                    ->where('sm.linkable_id <> ?',$linkableId)
                                    ->where('sm.linkable_type <> ?',$linkableType)
                                    ->where('ps.sectionType <> ?',$sectionType)
                                    ->where('sm.status <> ?',0)
                                    ->where('ps.status <> ?',0);
        $sectionData = $this->getDb()->fetchAll($sql);
        return $sectionData;
    }

    public function getByProductSection($linkableType,$sectionId) {

        $sql = $this->getDb()->select()
        ->from(array('sm' => 'sectionMapping'),array('linkable_id'))
        ->where('sm.linkable_type = ?',$linkableType)
        ->where('sm.section_id = ?',$sectionId)
        ->where('sm.status <> ?',0);
//         ->order(array('sm.name ASC'));

        $sectionData = $this->getDb()->fetchAll($sql);
        if(!empty($sectionData))
        $sectionData = array_column($sectionData, 'linkable_id');
        return $sectionData;
    }
    
    public function getSectionCountByProduct($linkableIdArr,$linkableType,$sectionType) {
            $sql = $this->getDb()->select()
                ->from(array('sm' => 'sectionMapping'),array('linkable_id', 'count(*) as count'))
                ->join(array('ps' => 'productSectionData'), 'sm.section_id = ps.id' ,array())
                ->where('sm.linkable_id in (?)',$linkableIdArr)
                ->where('sm.linkable_type = ?',$linkableType)
                ->where('ps.sectionType = ?',$sectionType)
                ->where('sm.status <> ?',0)
                ->where('ps.status <> ?',0)
                ->group(array('sm.linkable_id'));
        $sectionData = $this->getDb()->fetchAll($sql);
        return $sectionData;
    }

    public function getBySectionId($sectionId) {
        $returnArr = array();
        $sql = $this->getDb()->select()
                                    ->from(array('sm' => 'sectionMapping'),array('linkable_id','linkable_type'))
                                    ->join(array('ps' => 'productSectionData'), 'sm.section_id = ps.id' ,array())
                                    ->where('sm.section_id = ?',$sectionId)
                                    ->where('sm.status <> ?',0)
                                    ->where('ps.status <> ?',0)
                                    ->order(array('ps.name ASC'));

        $sectionData = $this->getDb()->fetchAll($sql);
        if(!empty($sectionData)){
            foreach ($sectionData as $key => $value) {
                $returnArr[$value['linkable_type']][] = $value['linkable_id'];
            }
        }

        return $returnArr;
    }
    
    public function getByLinkableId($linkableId) {
        $returnArr = array();
        $sql = $this->getDb()->select()
                                    ->from(array('sm' => 'sectionMapping'),array('section_id'))
                                    ->join(array('ps' => 'productSectionData'), 'sm.section_id = ps.id' ,array('sectionType'))
                                    ->where('sm.linkable_id = ?',$linkableId)
                                    ->where('sm.status <> ?',0)
                                    ->where('ps.status <> ?',0)
                                    ->order(array('ps.name ASC'));

        $sectionData = $this->getDb()->fetchAll($sql);
        if(!empty($sectionData)){
            foreach ($sectionData as $key => $value) {
                $returnArr[$value['sectionType']][] = $value['section_id'];
            }
        }

        return $returnArr;
    }

    public function getByLinkableIdLinkableType($linkableId, $linkableType, $order = 'ps.name ASC', $conditoins = array()) {
        $returnArr = array();
        $sql = $this->getDb()->select()
        ->from(array('sm' => 'sectionMapping'),array('section_id', 'show_at_top'))
        ->join(array('ps' => 'productSectionData'), 'sm.section_id = ps.id' ,array('sectionType','sectionTitle','name','linkable_id'))
        ->where('sm.linkable_id = ?',$linkableId)
        ->where('sm.linkable_type = ?',$linkableType)
        ->where('sm.status <> ?',0)
        ->where('ps.status <> ?',0)
        ->order(array($order));
        if(!empty($conditoins)) {
            foreach ($conditoins as $cond => $value) {
                $sql->where($cond, $value);
            }
        }
        $sectionData = $this->getDb()->fetchAll($sql);
        if(!empty($sectionData)){
            foreach ($sectionData as $key => $value) {
               $returnArr[$value['sectionType']][] = $value;
            }
        }
        return $returnArr;
    }

    public function getCourseCardsByProduct($linkableId, $linkableType,$sectionType) {
        $sql = $this->getDb()->select()
                                    ->from(array('sm' => 'sectionMapping'),array('id as sm_pk','linkable_id','linkable_type','section_id'))
                                    ->join(array('ps' => 'productSectionData'), 'sm.section_id = ps.id' ,array('*'))
                                    ->where('sm.linkable_id = ?',$linkableId)
                                    ->where('sm.linkable_type = ?',$linkableType)
                                    ->where('ps.sectionType = ?',$sectionType)
                                    ->order(array('ps.name ASC'));

        $sectionData = $this->getDb()->fetchAll($sql);
        return $sectionData;
    }
    public function getpartnershipDataByProduct($linkableId, $linkableType,$sectionTitle) {
        $sql = $this->getDb()->select()
                                    ->from(array('sm' => 'sectionMapping'),array('section_id'))
                                    ->join(array('ps' => 'productSectionData'), 'sm.section_id = ps.id' ,array('name','description'))
                                    ->where('sm.linkable_id = ?',$linkableId)
                                    ->where('sm.linkable_type = ?',$linkableType)
                                    ->where('sm.status  <> ?',0)
                                    ->where('ps.sectionTitle = ?',$sectionTitle)
                                    ->where('ps.status  <> ?',0)
                                    ->order(array('ps.name ASC'));
        // prd($sql->__toString());
        $sectionData = $this->getDb()->fetchAll($sql);
        return $sectionData;
    }
    public function updateProductSectionData($linkableId) {
        try {
            $this->clean();
            $this->setId($linkableId);
            $this->setFromArray(array('status' => 1))->update();
            return true;
        } catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }

    /**
     * Deletes all the mappings of Product section data
     * This is used when you are deleting the Product Section Data
     */
    public function deleteAllBySectionId($sectionId) {
        try{
            $cond = array('section_id =?'=> $sectionId);
            
            $checkExisting = $this->fetchAll($cond);
            if(!empty($checkExisting)){
                foreach ($checkExisting as $key => $value) {
                    $this->clean();
                    $this->setId($value['id']);
                    $this->setFromArray(array('status'=>0))->update();
                }
            }
            return true;
        }catch (Exception $e){
            if (APPLICATION_ENV == 'development')
                throw $e;
                return false;
        }
    }

} // End of Class
