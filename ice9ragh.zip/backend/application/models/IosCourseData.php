<?php

	
class Model_IosCourseData extends BaseApp_Dao_IosCourseData{

    public function getAllCoursesKey() {
        $data = $this->fetchAll();
	return $data;       
// $data = $this->fetchAll(array(), array('columns'=>array('course_key')));
       // $courseModel = new self();
       // $sql=$this->getDb()->select()->from('ios_course_data', array('course_key'));
       // $data = $this->getDb()->fetchAll($sql);
//        return $return;

//	 print_r($data);
	//return $data['name'];
    }


    public function addIosData($data){
    	try{
            $this->setFromArray($data)->save();            
            return $this->course_id;
        }
        catch (Exception $e){
            return false;
        }
    }

    public function updateIosData($data){
    	try{
            $this->setId($data['ios_id']);
            $this->setFromArray($data)->update();
            return true;
        }
        catch (Exception $e){
            return false;
        }
    }


    public function ValidateUniqueCourseAccess($courseKey){
    	$data = current($this->fetchAll(array('course_key =?'=>$courseKey)));
    	if(empty($data))
    		return true;
    	else
    		return false;
    }


} // End of Class
