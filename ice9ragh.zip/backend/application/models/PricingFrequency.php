<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_PricingFrequency extends BaseApp_Dao_PricingFrequency{	
    
    public function getByToken() {
        $return = array();
        foreach($this->fetchAll() as $data) {
            $return[$data['name']] = $data;
        }
        return $return;
    }
    
    public function getByFrequencyId() {
        $return = array();
        foreach($this->fetchAll() as $data) {
            $return[$data['frequency_id']] = $data;
        }
        return $return;
    }
} // End of Class