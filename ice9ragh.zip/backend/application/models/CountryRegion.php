<?php
class Model_CountryRegion extends BaseApp_Dao_CountryRegion {

}
?>