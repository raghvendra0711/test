<?php

class Model_FrsMongo extends Model_MongoDbWrapperFrs {

    protected $collectionName = 'contents';

    const MONGO_COLLECTION_CONTENT = 'contents';
    const MONGO_COLLECTION_SEGMENT = 'segments';
    const MONGO_CONN_STR = MONGO_CONN_STR_FRS;
    const MONGO_DB = MONGO_DB_FRS;

    private function getCollection($collection = null, $db = null, $conn_str = null) {

        if ($collection === null) {
            $collection = self::MONGO_COLLECTION_CONTENT;
        }
        $db = $this->getDb($db, $conn_str);
        return $db->$collection;
    }

    private function getMongoConn($conn_str = null) {
        $m_conn = new BaseApp_Model_MongoFrs();
        return $m_conn->getClient();
    }

    private function getDB($db = null, $conn_str = null) {
        if ($db === null) {
            $db = self::MONGO_DB;
        }
        $m = $this->getMongoConn($conn_str);
        return $m->$db;
    }

    public function getAllResoursesLinks() {
        $contents = false;
        try {
            $db = new Model_DefaultFrs();
            $query = array('status' => 4);
            $fields = array('title' => true, 'type' => true, 'segments' => true, 'primary_product_id' => true, 'primary_product_type' => true);
            $contents = $db->{self::MONGO_COLLECTION_CONTENT}->find($query, $fields)->toArray();
        } catch (Exception $e) {
            $x = '';
        }
        return $contents;
    }

    public function getAllResoursesTypes() {
        $contents = false;
        try {
            $db = new Model_DefaultFrs();
            $query = array('status' => 4);
            $fields = array('type' => true);
            $contents = $db->{self::MONGO_COLLECTION_CONTENT}->distinct('type');
        } catch (Exception $e) {
            $x = '';
        }
        return $contents;
    }

    public function getAllSegments() {
        $contents = false;
        try {
            $db = new Model_DefaultFrs();
            $query = array();
            $fields = array('value' => true,'id'=>true);
            $contents = $db->{self::MONGO_COLLECTION_SEGMENT}->find($query, $fields)->toArray();
        } catch (Exception $e) {
            $x = '';
        }
        return $contents;
    }

}
