<?php

class Model_Salaries extends BaseApp_Dao_Salaries{

    public function saveSalaries($salariesArr, $sectionId, $sectionMapId) {
        $db = $this->getDb();
        $db->beginTransaction();
        try{
            if (!empty($sectionId) && !empty($salariesArr)) {
                $this->deleteSalaryBySectionMapId($sectionMapId);
                foreach($salariesArr as $key => $salary) {
                    if (!empty($salary)){ 
                        $this->clean();
                        $data = array (
                            'section_id' => $sectionId,
                            'section_map_id'=>$sectionMapId,
                            'label'=> $key,
                            'salary' => $salary
                        );
                        if (!$this->setFromArray($data)->save()) {
                            throw new BaseApp_Exception('Could not save Job salaries ');
                        }
                    }
                }
                $db->commit();
                return true;
            } else {
                throw new BaseApp_Exception('Invalid data to save salaries');
            }
        } catch (Exception $e){
            $db->rollBack();
            throw $e;
            return false;
        }        
    }

    public function getSalariesBySectionMapId($sectionMapId){
        try {
            if (!empty($sectionMapId)) {
                return $this->fetchAll(
                    array(               
                        'section_map_id = ?' => $sectionMapId
                    ));
            } else {
                throw new BaseApp_Exception('No section Id passed to getSalariesBySectionId');
            }
        } catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }    
    }

    public function deleteSalaryBySectionMapId($sectionMapId){
        if (!empty($sectionMapId)) {
            return $this->deleteWhere(array(               
                'section_map_id = ?' => $sectionMapId
            ));
        }
    }
}
?>