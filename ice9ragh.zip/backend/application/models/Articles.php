<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_Articles extends BaseApp_Dao_Articles{
    
    const MAX_COURSES_ALLOWED_LINK = 2;
    
    const MAX_CATEGORIES_ALLOWED_LINK = 2;

    const ARTICLE_ENTRIES_PER_FRS_LIMIT = 6;
    
    public function addArticle($articleData){        
        $db = $this->getDb();
        $objArticle = new self();
        $pageUrl = '';
        $db->beginTransaction();
        try{
            if(isset($articleData['url'])) {
                $pageUrl = trim($articleData['url']);
                $checkSlash = substr($articleData['url'], 0,1);
                if($checkSlash != '/'){
                    $pageUrl = trim('/'.$pageUrl);
                }
                $objArticle->setPageUrl($pageUrl);
                unset($articleData['url']);
            }
            $articleData['dateCreated'] = date('Y-m-d H:i:s');
            $objArticle->setFromArray($articleData)->save();
            if(!$pageUrl || !$objArticle->article_id) {
                return false;
            }
            $dataSave = array(
                'controller' => self::SEO_DEFAULT_CONTROLLER,
                'action' => self::SEO_DEFAULT_ACTION,
                'params' => json_encode(array(self::SEO_DEFAULT_PARAM_KEY=>$objArticle->article_id)),
                'linkable_id' => $objArticle->article_id,
                'linkable_type' => 'article'
            );
            $modelSeo = new Model_Seo();
            $seoData = $modelSeo->getDataByUrl($pageUrl);
            $modelSeo->setId($seoData['seo_id']);
            $modelSeo->setFromArray($dataSave)->update();
            $db->commit();
            return $objArticle->article_id;
        }catch (Exception $e){
            pr($e->getMessage());
            $db->rollBack();
            return false;
        }
    }
    
    public function updateArticle($data) {
        $db = $this->getDb();
	$objArticle = new self();
        $data['last_updated_time'] = date('Y-m-d H:i:s');
        $db->beginTransaction();
        try{
            $objArticle->setId($data['article_id']);
            $objArticle->setFromArray($data)->update();  
            $db->commit();
            return true;
        }
        catch (Exception $e){
            $db->rollBack();
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }
		
    public function getByPartName($partName) {
        return $this->fetchAll( array('name LIKE ?'=>'%'.$partName.'%'), array(), false);
    }
    
    public function getRelatedArticlesToShow($relatedArticles) {
        $returnData = array();
        if(!$relatedArticles) {
            return $returnData;
        }
        $conds = array('article_id IN (?)' => $relatedArticles);
        $opts = array('columns' => array('articleId' => 'article_id', 'articleName' => 'name'));
        $dbData = array();
        foreach($this->fetchAll( $conds, $opts, false) as $data) {
            $dbData[$data['articleId']] = $data;
        }
        foreach($relatedArticles as $articleId) {
            if(isset($dbData[$articleId])) {
                $returnData[] = $dbData[$articleId];
            }
        }
        return $returnData;
    }
    
    public function _afterFetchAll($data) {
        $labels = array();
        $courses = array();
        $relatedArticles = array();
        $relatedEbooks = array();
        $relatedWebinars = array();
        foreach($data as $dataSingle) {
            if(isset($dataSingle['label_id']) && $dataSingle['label_id']) {
                $labels = array_merge($labels, explode(",", $dataSingle['label_id']));
            }
            if(isset($dataSingle['course_id']) && $dataSingle['course_id']) {
                $courses = array_merge($courses, explode(",", $dataSingle['course_id']));
            }            
            if(isset($dataSingle['relatedArticles']) && $dataSingle['relatedArticles']) {
                $relatedArticles = array_merge($relatedArticles, explode(",", $dataSingle['relatedArticles']));
            }            
            if(isset($dataSingle['relatedEbooks']) && $dataSingle['relatedEbooks']) {
                $relatedEbooks = array_merge($relatedArticles, explode(",", $dataSingle['relatedEbooks']));
            }            
            if(isset($dataSingle['relatedWebinars']) && $dataSingle['relatedWebinars']) {
                $relatedWebinars = array_merge($relatedArticles, explode(",", $dataSingle['relatedWebinars']));
            }            
        }
        
        if($labels) {
            $labelsMdl = new Model_Labels();
            $labels = $labelsMdl->getLabelByIds($labels);
        }
        if($courses) {
            $courseMdl = new Model_Courses();
            $courses = $courseMdl->getCourseByIdMultiple($courses);
        }   
        if($relatedArticles) {
            $relatedArticles = $this->fetchForSelect(array('article_id IN (?)' => $relatedArticles));
        }
        
        if($relatedWebinars) {
            $webinarModel = new Model_Webinars();
            $relatedWebinars = $webinarModel->fetchForSelect(array('webinar_id IN (?)' => $relatedWebinars));
        }
        
        if($relatedEbooks) {
            $ebookModel = new Model_Ebooks();
            $relatedEbooks = $ebookModel->fetchForSelect(array('ebook_id IN (?)' => $relatedEbooks));
        }
        
        foreach($data as &$dataSingle) {            
            if($dataSingle['label_id']) {
                $label = explode(",", $dataSingle['label_id']);
                $dataSingle['labels'] = array();
                foreach($label as $labelId) {
                    if(isset($labels[$labelId])) {
                        $dataSingle['labels'][] = $labels[$labelId];
                    }                   
                }                
                $dataSingle['labels'] = implode(", ", $dataSingle['labels']);
            }            
            if($dataSingle['course_id']) {
                $course = explode(",", $dataSingle['course_id']);
                $dataSingle['courses'] = array();
                foreach($course as $courseId) {
                    if(isset($courses[$courseId])) {
                        $dataSingle['courses'][] = $courses[$courseId];
                    }                    
                }
                $dataSingle['courses'] = implode(", ", $dataSingle['courses']);                
            }
            
            if($dataSingle['relatedArticles']) {
                $rArticle = explode(",", $dataSingle['relatedArticles']);
                foreach($rArticle as $articleId) {
                    $dataSingle['relatedArticleNames'][] = @$relatedArticles[$articleId];
                }
                $dataSingle['relatedArticleNames'] = implode(", ", $dataSingle['relatedArticleNames']);
            }            
            
            if($dataSingle['relatedEbooks']) {
                $rEbooks = explode(",", $dataSingle['relatedEbooks']);
                foreach($rEbooks as $ebookId) {
                    $dataSingle['relatedEbookNames'][] = @$relatedEbooks[$ebookId];
                }
                $dataSingle['relatedEbookNames'] = implode(", ", $dataSingle['relatedEbookNames']);
            }            
            
            if($dataSingle['relatedWebinars']) {
                $rWebinars = explode(",", $dataSingle['relatedWebinars']);
                foreach($rWebinars as $webinarId) {
                    $dataSingle['relatedWebinarNames'][] = @$relatedWebinars[$webinarId];
                }
                $dataSingle['relatedWebinarNames'] = implode(", ", $dataSingle['relatedWebinarNames']);
            }                        
        }
        unset($labels);
        unset($courses);
        return $data;
    }
    
    public function getAssociatedArticlesByCourse($courseId) {        
        $conds = array(
            'FIND_IN_SET(?, course_id)>0' => $courseId
        );        
        $opts = array(
            'columns' => array(
                'article_id',
                'displayName'
            )
        );
        return $this->fetchAll($conds, $opts, false);
    }

    public function buildCdnPurgeData($articleId,$action,$isHeader = true){
        $returnArr = array();
        // $objSeo = new Model_Seo();
        // $purgeUrlArr = $objSeo->getFrsPurgeUrls();
        // foreach ($purgeUrlArr as $key => $value) {
        //     array_push($returnArr,array('linkable_id'=>$articleId,'linkable_type'=>'article','action'=>$action,'url'=>$value,'created_at'=>time(),'updated_at'=>time()) );
        // }
        // if($isHeader){
        //     $db = $this->getDb();
        //     $articleSql = $this->getDb()->select()
        //                      ->from(array('a' => 'articles'), array('article_id'))
        //                      ->where('a.status = ?', 1)
        //                      ->order('article_id DESC')
        //                      ->limit(self::ARTICLE_ENTRIES_PER_FRS_LIMIT);
        //     $articleData = $this->getDb()->fetchAll($articleSql);
        //     if(!empty($articleData)){
        //         $articleData = array_values($articleData);
        //         if(in_array($articleId, $articleData)){
        //             array_push($returnArr,array('linkable_id'=>$articleId,'linkable_type'=>'article','action'=>$action,'url'=>PURGE_WEBSITE,'created_at'=>time(),'updated_at'=>time()) );
        //         }
        //     }
        // }
        return $returnArr;
    } // end of function
} // End of Class