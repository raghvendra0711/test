<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Model_Aws
{   
    protected $_maxAgeCacheControl = "max-age=31536000";
    protected $_defaultCdnValidationUrl = "cfs22.simplicdn.net";
    protected $__imageConfigFile = '/../../configs/uploaded_image_file_settings.ini';
    protected static $_awsBucket = '';
    protected $_default_upload_cdn_bucket = 'static2.simplilearn.com';
    protected $_upload_cdn_temp_storage_path = '/../../cdn-temp';

    public function __construct() {
        if(self::$_awsBucket == '') {
            self::$_awsBucket = new BaseApp_Aws_Core(AWS_S3_ACCESS_KEY_NEW, AWS_S3_SECRET_KEY_NEW);
        }
    }

    public function uploadImageIntoAws($localPath, $awsPath, $fileName) {
        $awsPath = trim($awsPath, '/');
        $config = $this->loadAndReturnImageConfigs();
        $fileSettings = $this->getValidationParametersFromConfig($awsPath, 1);
        $imageSize = getimagesize($localPath);
        $fileSize = filesize($localPath);
        if(($fileSettings['width'] && $fileSettings['width'] != $imageSize[0]) 
            || 
            ($fileSettings['height'] && $fileSettings['height'] != $imageSize[1])
        ) {
            
            pr('Uploading File Dimensions ' . $imageSize[0] . 'x' . $imageSize[1] . ' does not suit the required dimensions ' . $fileSettings['width'] . 'x' . $fileSettings['height']);
            return false;
        }       
        if(isset($fileSettings['size']) && $fileSettings['size'] && $fileSize > $fileSettings['size']) {
            pr('Uploading File Size doesn\'t match the sizes specified in the config');
            return false;            
        }
        if(isset($fileSettings['type']) && $fileSettings['type'] && $imageSize['mime'] != $fileSettings['type']) {
            pr('Uploading File Size doesn\'t match the sizes specified in the config');
            return false;            
        }
        $awsPath = trim($awsPath, '/');
        $awsPath .= '/';
//        $awsPath .= '1';
        $objectInfo = self::$_awsBucket->getObjectInfo($this->_default_upload_cdn_bucket, $awsPath);
        if($objectInfo == false) {
            pr('Folder Path doesn\'t exist');
            return false;
        }
        $awsPath .= $fileName;
        
        return self::$_awsBucket->putObjectFile($localPath, $this->_default_upload_cdn_bucket, $awsPath);
    }

    public function validateFile($url, $fromSimpliCdn = true) {
        if($fromSimpliCdn && strpos($url, $this->_defaultCdnValidationUrl) < 0) {
            return false;
        }
        
        $uriArray = explode($this->_defaultCdnValidationUrl . '/', $url);
        $uri = $uriArray[1];
        $fileInfo = self::$_awsBucket->getObjectInfo($this->_default_upload_cdn_bucket, $uri);
        $return = false;
        if(strpos($fileInfo['type'], 'image') !== false) {
            $return = $this->validateImage($uri);
        }
        return $return;
    }
    
    /**
     * 
     * @param type $uri
     * @return boolean
     */
    public function validateImage($uri) {
        $returnAnswer = true;
        $response = $this->saveCdnObject($uri);
        if($response['Cache-Control'] != $this->_maxAgeCacheControl) {
            pr('Cache Life is not as was expected');
            $returnAnswer = false;
        }
        $dimensionsFromUrl = $this->getDimensionsFromUrl($uri);
        $dimensionsFromImage = $this->getDimensionsFromActualImage($response['storedPath']);
        if(($dimensionsFromUrl['width'] && $dimensionsFromUrl['width']!= $dimensionsFromImage['width']) 
                || 
                ($dimensionsFromUrl['height'] && $dimensionsFromUrl['height']!= $dimensionsFromImage['height'])
        ) {
            pr('The actual image dimensions do not match the dimensions provided from Uri');
            $returnAnswer = false;
        }
        $validationSettingsFromConfigFile = $this->getValidationParametersFromConfig($uri);
        if(($validationSettingsFromConfigFile['width'] && $validationSettingsFromConfigFile['width']!= $dimensionsFromImage['width']) 
                || 
                ($validationSettingsFromConfigFile['height'] && $validationSettingsFromConfigFile['height']!= $dimensionsFromImage['height'])
        ) {
            pr('The actual image dimensions do not match the dimensions provided from config file');
            $returnAnswer = false;
        }
        if(isset($response['size']) && $response['size'] && $response['size'] > $validationSettingsFromConfigFile['size']) {
            pr('The actual image size is greater than the image size provided in the config file');
            $returnAnswer = false;            
        }
        if(isset($response['type']) && $response['type'] && $response['type'] > $validationSettingsFromConfigFile['type']) {
            pr('The actual image type does not match the one provided in the config file');
            $returnAnswer = false;            
        }
        
        $this->deleteTempCdnObject($response['storedPath']);
        return $returnAnswer;
    }
    
    public function getValidationParametersFromConfig($uri, $forUpload = 0) {
        $config = $this->loadAndReturnImageConfigs();
        $config = $config->toArray();
        $explodedArray = explode('/', $uri);
//        $temp = explode('x', $explodedArray);
//        $dimensions = array('width' => $temp[0], 'height' => $temp[1]);
        $subtract = 2;
        if($forUpload == 1) {
            $subtract = 1;
        }
        $explodedArraySettings = array_slice($explodedArray, 0, (count($explodedArray) - $subtract));
        $tempConfig = $config;
        foreach($explodedArraySettings as $string) {
            if(isset($tempConfig[$string])) {
                $tempConfig = $tempConfig[$string];
            } else {
                $tempConfig = false;
                pr('Configuration is not present');
                return false;
                break;
            }
        }
        if($tempConfig != false) {
            if(!isset($tempConfig['width']) || !isset($tempConfig['height'])) {
                pr('height and width were not defined for the path');
                return false;
            }
            
        }
        
        if(isset($tempConfig['size'])) {
            
            $brokenData = explode(' ', $tempConfig['size']);
            $tempConfig['size'] = $brokenData[0];
            if($brokenData[1] == 'MB') {
                $tempConfig['size'] = $brokenData[0]*1024*1024;
            }
            if($brokenData[1] == 'KB') {
                $tempConfig['size'] = $brokenData[0]*1024;
            }
            if($brokenData[1] == 'B') {
                $tempConfig['size'] = $brokenData[0];
            }
        }
        
        return $tempConfig;
    }
    
    public function loadAndReturnImageConfigs() {
        $return = new Zend_Config_Ini(APPLICATION_PATH . $this->_imageConfigFile);
        return $return;
    }
    
    public function listFilesInABucket($rootPath = null) {
        
        if($rootPath) {            
            $buck = $this->getBucket($this->_default_upload_cdn_bucket, $rootPath);
        } else {
            $buck = $this->getBucket($this->_default_upload_cdn_bucket);
        }
        $parentFolders = array();
        $allFiles = array();
        foreach($buck as $key => $val) {
            array_push($allFiles, $key);
        }
        return $allFiles;
    }
    
    
    public function getAllFoldersFromAwsBucket($allFiles) {
        $return = array();
        foreach($allFiles as $file) {
            $explodedString = explode('/', $file);
            if(strpos($explodedString[count($explodedString) - 1], '.') === false) {
                array_push($return, $file);
            }
        }
        
        return $return;
    }
    
    public function remakeConfigFileIndex() {
        $return = array();
        $allFiles = $this->listFilesInABucket();
        
        
        foreach($allFiles as $eachFile) {
            $eachFileArray = explode('/', $eachFile);
            
        }
    }
    
    public function loadFolderStructureDefinedByCode() {
        $fileStructureConfigData = new Zend_Config_Ini(APPLICATION_PATH . '/../../configs/file_upload_conditions_another.ini');
        
        prd($fileStructureConfigData->toArray());
        
        $fileStructureConfigData = new Zend_Config_Ini(APPLICATION_PATH . '/../../configs/file_upload_conditions.ini');
        $plainArray = $fileStructureConfigData->toArray();
        prd($plainArray);
        $fileStructure = $this->getFolderStructure($plainArray);
        return $fileSetting;
    }
    
    
    public function getFolderStructure($plainArray) {
        $tempArray = array();
        $rootFolderIndex = 0;
        foreach($plainArray as $key => $value) {
            if(isset($value['root']) && $value['root'] == 1) {
                $tempArray[$key] = array();
                $this->recursiveFolderFunc($plainArray, $tempArray, $key, $value);                
                $rootFolderIndex++;
            }
        }
        prd($tempArray);
    }
    
    public function recursiveFolderFunc($plainArray, &$returnArray, $parentKey, $currentKey) {
        if(isset($currentKey['folders'])) {
            if(!isset($returnArray[$parentKey]))
                $returnArray[$parentKey] = array();
            foreach($currentKey['folders'] as $folder) {
                if(isset($plainArray[$folder])) {                    
                    $this->recursiveFolderFunc($plainArray, $returnArray[$parentKey], $folder, $plainArray[$folder]);
                } else {
                    $returnArray[$parentKey][$folder] = array();
                }
            }
        } else {
            
            if(!isset($returnArray[$parentKey]) || !is_array($returnArray[$parentKey])) {
                $returnArray[$parentKey] = array();
            }
            
            $returnArray[$parentKey] = $currentKey;
        }
    }


    
    public function getBucket($bucketString = null, $rootPath = null) {
        if($bucketString == null) {
            $bucketString = $this->_default_upload_cdn_bucket;
        }
        if($rootPath) {
            return self::$_awsBucket->getBucket($bucketString, $rootPath);            
        } else {
            return self::$_awsBucket->getBucket($bucketString, 'ice9');            
        }
    }
    
    //assuming last but one folder is the dimensions folder of format "widthxheight" format with small x
    public function getDimensionsFromUrl($uri) {
        $explodedString = explode('/', $uri);
        $dimensionString = $explodedString[count($explodedString) - 2];
        $dimensionsArray = explode('x', $dimensionString);
        return array('width' => $dimensionsArray[0], 'height' => $dimensionsArray[1]);
    }
    
    public function getActualFileName($uri) {
        $explodedString = explode('/', $uri);
        return $explodedString[count($explodedString) - 1];
    }
    
    public function getRootBasedPath($path) {
        return APPLICATION_PATH . $path;
    }
    
    public function getDimensionsFromActualImage($filePath) {
        $imageInfo = getimagesize($filePath);
        return array('width' => $imageInfo[0], 'height' => $imageInfo[1]);
    }
    
    public function saveCdnObject($uri) {
        $timestamp = time();
        $objectInfo = self::$_awsBucket->getObjectInfo($this->_default_upload_cdn_bucket, $uri);
        if($objectInfo['size'] == 0) {
            return array('status' => false, 'message' => 'The provided path is not a proper file');
        }
        $path = $this->getRootBasedPath($this->_upload_cdn_temp_storage_path);
        $filePath = $path . '/' . $timestamp . $this->getActualFileName($uri);
        $object = self::$_awsBucket->getObject($this->_default_upload_cdn_bucket, $uri, $filePath);
        
        $objectInfo['storedPath'] = $filePath;
        return $objectInfo;
    }
    
    public function deleteTempCdnObject($filePath) {
        return unlink($filePath);
        
    }
    
}

