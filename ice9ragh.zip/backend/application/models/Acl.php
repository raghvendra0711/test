<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Model_Acl extends BaseApp_Dao_Acl {

    protected $_useCache = false;
    
    public function insert($email, $roles) {
        if(!empty($roles)){
            $roles = implode(',', $roles);
        }else{
            $roles = '';
        }
        $acl = current($this->fetchAll(array('email = ?' => $email)));
        if ($acl) {
            $acl['roles'] = $roles;
            $this->setId($acl['acl_id']);
            $res = $this->setFromArray($acl)->update();
            return $res;
        }else{
            return false;
        }
    }
    
    public function create($data) {
        $db = $this->getDb();
        $objSelf = new self();
        $db->beginTransaction();
        try{
            $objSelf->setFromArray($data)->save();
            $db->commit();
            return $this->acl_id;
        }catch (Exception $e){
            $db->rollBack();
            if (APPLICATION_ENV == 'development')
                    throw $e;
            return false;
        }
    }
    
    public function getByEmail($email) {
        return current($this->fetchAll(array('email=?'=>$email), array(), false));
    }
}

// End of Class