<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_Ebooks extends BaseApp_Dao_Ebooks{	
    
    const MAX_COURSES_ALLOWED_LINK = 2;
    
    const MAX_CATEGORIES_ALLOWED_LINK = 2;

    const EBOOK_ENTRIES_PER_FRS_LIMIT = 6;

    public function addEbooks($data){
        $db = $this->getDb();
        $objEbooks = new self();
        $db->beginTransaction();
        try{            
            $data['url'] = trim($data['url']);
            if(substr($data['url'], 0,1) != '/'){
                $data['url'] = '/'.$data['url'];
            }
            $thumbImage = $data['thumb_image'];
            $seoUrl = $data['url'];
            unset($data['thumb_image']);
            unset($data['url']);
            $data['dateCreated'] = date('Y-m-d H:i:s');
            $objEbooks->setFromArray($data)->save();
            if(!$objEbooks->ebook_id) {
                $db->rollBack();
                prd('failed to create ebook');
                return false;
            }    
            $seoDataUpdate = array(
                'controller' => self::SEO_DEFAULT_CONTROLLER,
                'action' => self::SEO_DEFAULT_ACTION,
                'params' => json_encode(array(self::SEO_DEFAULT_PARAM_KEY=>$objEbooks->ebook_id)),
                'linkable_id' => $objEbooks->ebook_id,
                'linkable_type' => 'ebook',
                'thumb_image' => $thumbImage
            );
            $modelSeo = new Model_Seo();
            if(!$seoData = $modelSeo->getDataByUrl($seoUrl)) {
                $db->rollBack();
                prd('failed to get seo data');
                return false;    
            }
            $modelSeo->setId($seoData['seo_id']);
            $modelSeo->setFromArray($seoDataUpdate)->update();
            $db->commit();
            return $objEbooks->ebook_id;
        }catch (Exception $e){
            $db->rollBack();
            prd($e->getMessage());
            return false;
        }
    }

    public function updateEbooks($data){
        $db = $this->getDb();
        $objEbooks = new self();
        $data['last_updated_time'] = date('Y-m-d H:i:s');
        $db->beginTransaction();
        try{            
            $thumbImage = $data['thumb_image'];
            unset($data['thumb_image']);
            
            $objEbooks->clean();
            $objEbooks->setId($data['ebook_id']);
            $objEbooks->setFromArray($data)->update();
            $seoDataUpdate = array(
                'thumb_image' => $thumbImage
            );
            $objSeo = new Model_Seo();
            if(!$seoData = $objSeo->getDataByType($data['ebook_id'], 'ebook', self::SEO_DEFAULT_CONTROLLER, self::SEO_DEFAULT_ACTION)) {
                $db->rollBack();
                prd('failed to get seo data');
                return false;                
            }
            $objSeo->setId($seoData['seo_id']);
            $objSeo->setFromArray($seoDataUpdate)->update();
            $db->commit();
            return true;
        }catch (Exception $e){
            $db->rollBack();
            prd($e->getMessage());
            return false;
        }        
    }
    
    public function _afterFetchAll($data){   
        $urls = array();
        $courses = array();
        foreach($data as &$row) {
            if(isset($row['course_id']) && trim($row['course_id'])) {
                $courseIds = explode(",", $row['course_id']);
                foreach($courseIds as $courseId) {
                    if(!in_array($courseId, $courses)) {
                        $courses[] = $courseId;
                    }            
                }                
            }            
            $urls[] = $row['ebook_id'];
        }
        if($urls) {
            $seo = new Model_Seo();
            $conds = array(
                'controller = ?' => self::SEO_DEFAULT_CONTROLLER,
                'action = ?' => self::SEO_DEFAULT_ACTION,
                'linkable_id IN (?)' => $urls,
                'linkable_type = ?' => 'ebook'
            );
            foreach($seo->fetchAll($conds) as $seoData) {
                $urls[$seoData['linkable_id']] = $seoData['url'];
            }
        }
        if($courses) {
            $courseMdl = new Model_Courses();
            $courses = $courseMdl->getCourseByIdMultiple($courses);
        }   
        
        foreach($data as &$row) {
            if(isset($row['course_id']) && trim($row['course_id'])) {
                $row['course_id'] = explode(",", $row['course_id']);
                foreach($row['course_id'] as $courseId) {
                    $row['Course'][] = @$courses[$courseId];
                }                
                $row['Course'] = implode(", ", $row['Course']);
            }            
            $row['URL'] = @$urls[$row['ebook_id']];
        }
        return $data;
    }
    
    public function getRelatedEbooksToShow($relatedEbooks) {
        $returnData = array();
        if(!$relatedEbooks) {
            return $returnData;
        }
        $conds = array('ebook_id IN (?)' => $relatedEbooks);
        $opts = array('columns' => array('ebookId' => 'ebook_id', 'ebookName' => 'name'));
        $dbData = array();
        foreach($this->fetchAll( $conds, $opts, false) as $data) {
            $dbData[$data['ebookId']] = $data;
        }
        foreach($relatedEbooks as $ebookId) {
            if(isset($dbData[$ebookId])) {
                $returnData[] = $dbData[$ebookId];
            }
        }
        return $returnData;
    }
    
    public function getAssociatedArticlesByCourse($courseId) {
        $conds = array(
            'FIND_IN_SET(?, course_id)>0' => $courseId
        );        
        $opts = array(
            'columns' => array(
                'ebook_id',
                'displayName'
            )
        );
        $ebookData = $this->fetchAll($conds, $opts, false);
        
        $conds = array(
            'lead_course_id = ?' => $courseId
        );        
        $opts = array(
            'columns' => array(
                'ebook_id',
                'displayName'
            )
        );
        $ebookData = array_merge($ebookData, $this->fetchAll($conds, $opts, false));        
        return $ebookData;
    }

    public function buildCdnPurgeData($ebookId,$action){
        $returnArr = array();
        // $objSeo = new Model_Seo();
        // $purgeUrlArr = $objSeo->getFrsPurgeUrls();
        // foreach ($purgeUrlArr as $key => $value) {
        //     array_push($returnArr,array('linkable_id'=>$ebookId,'linkable_type'=>'ebook','action'=>$action,'url'=>$value,'created_at'=>time(),'updated_at'=>time()) );
        // }
        // $db = $this->getDb();
        // $ebookSql = $db->select()
        //                ->from(array('e' => 'ebooks'), array('ebook_id'))                       
        //                ->where('e.status = ?', 1)
        //                ->order(array('e.ebook_id DESC'))
        //                ->limit(self::EBOOK_ENTRIES_PER_FRS_LIMIT);
        // $ebookData = $this->getDb()->fetchAll($ebookSql);
        // if(!empty($ebookData)){
        //     $ebookData = array_values($ebookData);
        //     if(in_array($ebookId, $ebookData)){
        //         array_push($returnArr,array('linkable_id'=>$ebookId,'linkable_type'=>'ebook','action'=>$action,'url'=>PURGE_WEBSITE,'created_at'=>time(),'updated_at'=>time()) );
        //     }
        // }
        return $returnArr;
    } // end of function

} // End of Class