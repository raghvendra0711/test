<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_PracticeTest extends BaseApp_Dao_PracticeTest{
		

    public function createPracticeTest($data) {
        $db = $this->getDb();
	    $objPractice = new self();
        $pageUrl = '';
        $db->beginTransaction();
        try{
            if(isset($data['url'])) {
                $pageUrl = trim($data['url']);
                $checkSlash = substr($pageUrl, 0,1);
                if($checkSlash != '/'){
                    $pageUrl = trim('/'.$pageUrl);
                }
                $objPractice->setPageUrl($pageUrl);
                unset($data['url']);
            }
            $objPractice->setFromArray($data)->save();
            $dataSave = array(
                'controller' => self::SEO_DEFAULT_CONTROLLER,
                'action' => self::SEO_DEFAULT_ACTION,
                'params' => json_encode(array(self::SEO_DEFAULT_PARAM_KEY=>$objPractice->practice_test_id)),
                'linkable_id' => $objPractice->practice_test_id,
                'linkable_type' => 'practice_test'
            );
            $modelSeo = new Model_Seo();
            $seoData = $modelSeo->getDataByUrl($pageUrl);
            $modelSeo->setId($seoData['seo_id']);
            $modelSeo->setFromArray($dataSave)->update();
            $db->commit();
            return $objPractice->practice_test_id;
        }
        catch (Exception $e){
            $db->rollBack();
            return false;
        }
    }
    
    public function updatePracticeTest($data) {
        $db = $this->getDb();
	$objPractice = new self();
        $db->beginTransaction();
        try{
            $objPractice->setId($data['practice_test_id']);
            $objPractice->setFromArray($data)->update();  
            $db->commit();
            return true;
        }
        catch (Exception $e){
            $db->rollBack();
            return false;
        }
    }
    
    public function getForInclusion($courseId, $trainingId = 0) {
        $returnData = array();
        $data = $this->fetchAll(array('course_id = ?' => $courseId), array(), false);
        foreach($data as $tempId => $dataReal) {
            $returnData['practiceTests']['practice_test'.$dataReal['practice_test_id']] = 'Practice Test (ID-'.$dataReal['practice_test_id'].')';
        }
        return $returnData;
    }
    
    public function _afterFetchAll($data){
        $courses = array();
        
        foreach($data as $row){
            if($row['course_id']) {
                $courses = array_merge($courses, explode(",", $row['course_id']));
           }           
        }
        
        $courseMdl = new Model_Courses();
        $courses = $courseMdl->getCourseByIdMultiple($courses);
        
        foreach($data as &$row){            
            if($row['course_id']) {
                $row['course'] = @$courses[$row['course_id']];
            }
        }
        return $data;
    }
    
} // End of Class