<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Model_CourseFaq extends BaseApp_Dao_CourseFaq {
    private $_isCityPage = false;

    public function createCourseFaq($courseFaq, $type, $courseId, $videoLink = '', $trainingId, $imageData = '') {
        $objCourseFaq = new self();
        $db = $this->getDb();
        $db->beginTransaction();
        try {
            $conds = array(
                'course_id=?' => $courseId,
                'type=?' => $type
            );
            if ($trainingId !== false) {
                $conds['training_id=?'] = $trainingId;
            }
            $properties = $objCourseFaq->fetchAll($conds);
            foreach ($properties as $property) {
                $objCourseFaq->clean();
                $objCourseFaq->setId($property['course_faq_id']);
                $objCourseFaq->delete();
            }

            $qCounter = 1;
            $aCounter = 1;
            $arrCount = intval(count($courseFaq) / 2);
            for ($i = 0; $i < $arrCount; $i++) {
                $courseDetails = array(
                    'course_id' => $courseId,
                    'type' => $type,
                    'question' => $courseFaq['q' . $qCounter],
                    'answer' => $courseFaq['a' . $aCounter],
                    'orderNo' => $qCounter,
                    'training_id' => $trainingId
                );
                $res = $objCourseFaq->setFromArray($courseDetails)->save();
                $qCounter ++;
                $aCounter ++;
            }
            if (!empty($videoLink)) {
                $objVideos = new Model_Videos();
                $videosArr = array('course_id' => $courseId, 'name' => 'about_course', 'displayName' => 'About Course', 'videoLink' => $videoLink, 'training_id' => $trainingId);
                $res = $objVideos->setFromArray($videosArr)->save();
            }

            if (!empty($imageData)) {
                $objImaegs = new Model_Images();
                $imageDataExistsing = $objImaegs->getInclusionImages($courseId);
                foreach ($imageData as $key => $imageValue) {
                    $objImaegs->clean();
                    if (isset($imageDataExistsing[$imageValue['name']])) {
                        $objImaegs->setId($imageDataExistsing[$imageValue['name']]['image_id']);
                        $objImaegs->setFromArray($imageValue)->update();
                    } else {
                        $objImaegs->setFromArray($imageValue)->save();
                    }
                }
            }
            $db->commit();
            return true;
        } catch (Exception $e) {
            $db->rollBack();
            return false;
        }
    }

    public function saveCourseFaq($faqData, $type, $courseId, $trainingId, $certificateParams = '') {
        $db = $this->getDb();
        $objFaq = new self();
        $courseResourceMappingModel = new BaseApp_Dao_CourseResourceMapping();
        $lookupModel = new BaseApp_Dao_CourseCityLookup();
        $db->beginTransaction();
        try {
            $trainingTypeId = 0;
            if ($trainingId !== false) {
                $trainingTypeId = $trainingId;
            }
            $columns = array(
                BaseApp_Dao_CourseFaq::TABLE_COURSE_FAQ_ALIAS . '.course_faq_id',
                BaseApp_Dao_CourseFaq::TABLE_COURSE_FAQ_ALIAS . '.question',
                BaseApp_Dao_CourseFaq::TABLE_COURSE_RESOURCE_MAPPING_ALIAS . '.lookup_id',
                BaseApp_Dao_CourseFaq::TABLE_COURSE_RESOURCE_MAPPING_ALIAS . '.order'
            );
            $properties = $objFaq->getCourseResources($courseId, $type, $trainingTypeId, null, $columns);

            $lookupId = null;
            if (!empty($properties)) {
                $lookupId = $properties[0]['lookup_id'];
            } else {
                $lookupId = $lookupModel->getLookupId($courseId);
            }
            if (empty($lookupId)) {
                // Create lookup id
                $lookupId = $lookupModel->createLookupId($courseId);
            }

            if (empty($lookupId)) {
                throw new Exception("Failed to create lookup id");
            }

            $existingFaqIds = array();
            $lastOrder = $objFaq->getLastOrder($courseId, $type, $trainingId);
            $maxOrder = $lastOrder + BaseApp_Dao_CourseResourceMapping::ORDER_STEP;
            foreach ($properties as $property) {
                $existingFaqIds[] = $property['course_faq_id'];
            }
            // Update faqs
            $unprocessedIds = $existingFaqIds;
            foreach ($faqData as $indexId => $dataSave) {
                $faqId = $dataSave['course_faq_id'];
                $index = array_search($faqId, $unprocessedIds);

                if ($index !== false) {
                    // update
                    $objFaq->clean();
                    $objFaq->setId($faqId);
                    $objFaq->setFromArray($dataSave)->update();
                } else {
                    // inset new
                    unset($dataSave['course_faq_id']);
                    $objFaq->clean();
                    $dataSave['training_id'] = $trainingId;
                    $dataSave['type'] = $type;
                    $dataSave['status'] = 1;
                    $objFaq->setFromArray($dataSave)->save();
                    $faqId = $objFaq->__get($objFaq->getPk());

                    // add the mapping course_resource_mapping
                    $crmData = array(
                        'lookup_id' => $lookupId,
                        'faq_id' => $faqId,
                        'order' => $maxOrder,
                        'status' => 1,
                    );
                    $courseResourceMappingModel->clean();
                    $courseResourceMappingModel->setFromArray($crmData)->save();
                    $maxOrder += BaseApp_Dao_CourseResourceMapping::ORDER_STEP;
                    $id = $courseResourceMappingModel->__get($courseResourceMappingModel->getPk());
                }
                unset($unprocessedIds[$index]);
            }

            // Delete removed items
            foreach ($unprocessedIds as $faqId) {
                // delete from courseResourceMappingModel
                $courseResourceMappingModel->clean();
                $conds = array('faq_id = ?' => $faqId);
                $courseResourceMappingModel->deleteWhere($conds);

                // delete from courseFaq
                $objFaq->clean();
                $objFaq->setId($faqId);
                $objFaq->delete();
            }
            if (!empty($certificateParams)) {
                foreach ($certificateParams as $key => $value) {
                    $value['linkable_id'] = $courseId;
                    $value['linkable_type'] = 'course';
                    $objCertificate = new Model_Certificates();
                    $res = $objCertificate->fetchAll(array('linkable_id =?' => $courseId, 'linkable_type =?' => 'course', 'training_id =?' => $value['training_id'], 'certificateType =?' => $value['certificateType']));
                    if (!empty($res)) {
                        $objCertificate->setId($res[0]['certificate_id']);
                        $objCertificate->setFromArray($value)->update();
                    } else {
                        if (isset($value['accreditor_id']) && isset($value['pdu']) && isset($value['oneLiner']))
                            $objCertificate->setFromArray($value)->save();
                    }
                }
            }
            $db->commit();
            return true;
        } catch (Exception $e) {
            $db->rollBack();
            return false;
        }
    }
    public function getByType($type, $trainingId) {
        $returnData = array();
        $conds = array('type=?' => $type);
        if ($trainingId !== false) {
            $conds['training_id=?'] = $trainingId;
        }
        foreach ($this->fetchAll($conds) as $tempId => $dataReal) {
            $returnData[$dataReal['question']] = $dataReal['answer'];
        }
        return $returnData;
    }

    public function getByTypeNew($courseId, $type, $trainingId, $contentId = 0) {
        $returnData = array();
        if ($trainingId === false) {
            $trainingId = null;
        }
        $objCourseFaq = new self();
        if (!empty($contentId)) {
            $objCourseFaq->setFaqId($contentId);
        }
        $list = $objCourseFaq->getCourseResources($courseId, $type, $trainingId);
        foreach ($list as $tempId => $dataReal) {
            $returnData[] = array(
                'faq_id' => $dataReal['faq_id'],
                'question' => $dataReal['question'],
                'answer' => $dataReal['answer'],
                'is_b2b' => $dataReal['is_b2b'],
                'is_b2c' => $dataReal['is_b2c'],
                'jump_to_section' => $dataReal['jump_to_section'],
                'countryIds' => !empty($dataReal['countryIds']) ? $dataReal['countryIds'] : '',
                'countryName' => !empty($dataReal['countryName']) ? $dataReal['countryName'] : '',
                'clusterIds' => !empty($dataReal['clusterIds']) ? $dataReal['clusterIds'] : '',
                'clusteName' => !empty($dataReal['clusteName']) ? $dataReal['clusteName'] : '',
            );
        }
        return $returnData;
    }

    public function getDataByTypeAndContentId($productId, $productType, $type, $trainingId, $clusterId = 0, $countryId = 0, $cityId = 0, $contentId = '', $offset = 0, $limitPerPage = null, $content = array())
    {
        $productType = empty($productType) ? "course" : $productType;
        $lookupModel = new BaseApp_Dao_CourseCityLookup();
        $benefitSectionType = BaseApp_Dao_CourseFaq::COURSE_RESOURCE_BENEFITS;
        $clusterId = ($clusterId == '') ? 0 : $clusterId;
        $countryId = ($countryId == '') ? 0 : $countryId;
        $cityId = ($cityId == '') ? 0 : $cityId;
        $lookupId = 0;
        $allFlag = false;
        if ($clusterId !== 'all') {
            $lookupId = $lookupModel->getProductGlobalMapping($productId, $productType, $clusterId, $countryId, $cityId);
            $lookupId = (empty($lookupId)) ? 0 : $lookupId;
        }//pr($lookupId);
        if ($lookupId > 0 || $clusterId === 'all') {
            $db = $this->getDb();
            $queryStatement = $db
                ->select()
                ->from(array('cf' => $this->_name), '*')
                ->join(self::TABLE_COURSE_RESOURCE_MAPPING . ' as crm', 'crm.faq_id=cf.course_faq_id', array('crm.order','crmStatus'=>'crm.status','crm.faq_id','crmId' => 'crm.id'))
                ->join(self::TABLE_COURSE_CITY_LOOKUP . ' as ccl', 'ccl.id=crm.lookup_id', array('crm.lookup_id','ccl.linkable_type','ccl.course_id','ccl.city_id','cclStatus'=>'ccl.status'))
                ->joinLeft('cluster as cl', 'ccl.cluster_id = cl.cluster_id', array(new Zend_Db_Expr('GROUP_CONCAT(DISTINCT(cl.name)) as clusterName'), new Zend_Db_Expr('GROUP_CONCAT(DISTINCT(cl.cluster_id)) as clusterIds')))
                ->joinLeft('country as c', 'ccl.country_id = c.country_id', array(new Zend_Db_Expr('GROUP_CONCAT(DISTINCT (if((ccl.country_id=0 and ccl.cluster_id=0),"All Country", c.name))) AS countryName'), new Zend_Db_Expr('GROUP_CONCAT(DISTINCT (if((ccl.country_id=0 and ccl.cluster_id=0),0,c.country_id))) AS countryIds')))
                ->joinLeft('city as ci', 'ccl.city_id = ci.city_id', array(new Zend_Db_Expr('GROUP_CONCAT(DISTINCT(ci.name)) as cityName'), new Zend_Db_Expr('GROUP_CONCAT(DISTINCT(ci.city_id)) as cityIds')))
//                 ->where('crm.status=?', 1)
                ->where('cf.status=?',1)
                ->order(array('crm.order asc'))
                ->group(array('cf.course_faq_id'));

            if (!empty($productType)) {
                $queryStatement->where('ccl.linkable_type=?',$productType);
            }
            if (!empty($type)) {
                $queryStatement->where('cf.type=?', $type);
            }
            if (!empty($cityId)) {
                $queryStatement->where('ccl.city_id=?', $cityId);
            }else{
                $queryStatement->where('ccl.city_id=?', 0);
            }

            if (!empty($lookupId)) {
                $queryStatement->where('crm.lookup_id=?', $lookupId);
            } else {
                $queryStatement->where('ccl.course_id=?', $productId);
                /* if ($countryId > 0) {
                    $queryStatement->where('ccl.country_id=?', $countryId);
                } */
            }
            // if ($limitPerPage !== null) {
            //     $queryStatement->limit($limitPerPage, $offset);
            // }
            if (!empty($contentId)) {
                $queryStatement->where('crm.faq_id=?', $contentId);
                if (
                    !in_array($type, array(BaseApp_Dao_CourseFaq::COURSE_RESOURCE_BENEFITS))
                    || (in_array($type, array(BaseApp_Dao_CourseFaq::COURSE_RESOURCE_BENEFITS)) && empty($cityId))
                ) {
                    $queryStatement->where('crm.status=?', 1);
                }
                // check for all countries
                $lookupIdAll = $lookupModel->getProductGlobalMapping($productId, $productType);
                $courseResourceMappingModel = new BaseApp_Dao_CourseResourceMapping();
                $mappingIdsAll = $courseResourceMappingModel->getLookupFaqData($contentId,$lookupIdAll,true);
                if (!empty($mappingIdsAll)) {
                    $allFlag = true;
                }
            }
            if ($trainingId !== null) {
                if (is_array($trainingId)) {
                    $queryStatement->where('training_id IN(?)', $trainingId);
                } else {
                    $queryStatement->where('training_id=?', $trainingId);
                }
            }
            if(!empty($this->_isCityPage)&& $productType!='bundle'){
                $queryStatement->where('is_b2c=?', 1);
                //$queryStatement->where('crm.status=?', 1);
            }
            //echo "<li>".$queryStatement;
            $data = $db->fetchAll($queryStatement);
            //if type = "benefits" then add job information to data            
            if (!empty($data)) {                
                $faqIds = array_column($data, 'faq_id');
                $faqIdsBefore = array_column($content, 'faq_id');
                $existingFaqIds = array_intersect($faqIds, $faqIdsBefore);
                foreach ($data as $key => $value) {                    
                    $data[$key]['disabled'] = 0;
                    if (in_array($value['faq_id'], $existingFaqIds)) {
                        $data[$key]['disabled'] = 1;
                    }
                    $data[$key]['allCountries'] = ($allFlag) ? 1 : 0;                
                    if($type == $benefitSectionType || $type == BaseApp_Dao_CourseFaq::BUNDLE_INDUSTRY_ID) {
                        //get job data                        
                        if (!empty($contentId)) {
                            $benefitFaq = $data[0];//since we are passing content ID only one entry is possible);
                            if (isset($benefitFaq['course_faq_id'])){
                                $jobData = $this->_getJobsDataForBenefitType($benefitFaq['course_faq_id']);
                                $industryTrends = $this->_getTrainingDetailsBenefitType($benefitFaq['course_faq_id']);
                                $data[$key]['jobdesignation'] = (!empty($jobData)) ? $jobData : [];
                                $data[$key]['industry_trends']  = (!empty($industryTrends)) ? $industryTrends : [];
                            }                                      
                        }else{
                            if(empty($data[$key]['industry_trends'])){
                                $benefitFaq = $data[0];//since we are passing content ID only one entry is possible);                             
                                if (isset($benefitFaq['course_faq_id'])){
                                    $industryTrendsDetails = $this->_getTrainingDetailsBenefitType($benefitFaq['course_faq_id']);                                     
                                    $data[$key]['industry_trends']  = (!empty($industryTrendsDetails)) ? $industryTrendsDetails : [];
                                }
                            }                            
                        }

                    }                                         
                    $content[] = $data[$key];
                }                 
            }            
        }

        if ($clusterId != 'all' && $clusterId > 0 && $countryId==0 && $cityId == 0) {
            return $this->getDataByTypeAndContentId($productId, $productType, $type, $trainingId, 0, 0, 0, $contentId, $offset, $limitPerPage, $content);
        }

        if ($clusterId == 0 && $countryId == 0 && $cityId > 0) {
            $cityObj = new Model_City();
            $countryIdForCity = $cityObj->getCountryId($cityId);
            if (!empty($countryIdForCity)) {
                return $this->getDataByTypeAndContentId($productId, $productType, $type, $trainingId, 0, $countryIdForCity, 0, $contentId, $offset, $limitPerPage, $content);
            } else {
                return $this->getDataByTypeAndContentId($productId, $productType, $type, $trainingId, 0, 0, 0, $contentId, $offset, $limitPerPage, $content);
            }
        }

        if ($clusterId == 0 && $countryId>0 && $cityId == 0) {
            $countryObj = new Model_Country();
            $clusterIdForCountry = $countryObj->getClusterByCountry($countryId);
            if (!empty($clusterIdForCountry)) {
                return $this->getDataByTypeAndContentId($productId, $productType, $type, $trainingId, $clusterIdForCountry, 0, 0, $contentId, $offset, $limitPerPage, $content);
            } else {
                return $this->getDataByTypeAndContentId($productId, $productType, $type, $trainingId, 0, 0, 0, $contentId, $offset, $limitPerPage, $content);
            }
        }
        if(!empty($this->_isCityPage)){
            return $content;
        }
        $tempArr = array_unique(array_column($content, 'course_faq_id'));
        $contentNew = array_values(array_intersect_key($content, $tempArr));
        // filter content with mapping status = 1
        $filterBy = 1;

        /* $contentNew = array_filter($contentNew, function ($var) use ($filterBy) {
            return ($var['crmStatus'] == $filterBy);
        }); */

        if($limitPerPage != null) {
            $contentNew = array_slice($contentNew, $offset, $limitPerPage);
        }

        return $contentNew;
    }

    private function _getJobsDataForBenefitType($course_faq_id){
        $objFaq = new self();
        $objFaq->setId($course_faq_id);                    
        $contentType = $objFaq->getData('type');        
        // $benefitSectionType = BaseApp_Dao_CourseFaq::COURSE_RESOURCE_BENEFITS;
        // $benefitSectionType = 16;
        $benefitsArr = array(BaseApp_Dao_CourseFaq::COURSE_RESOURCE_BENEFITS,BaseApp_Dao_CourseFaq::BUNDLE_INDUSTRY_ID);
        $returnData = array();
        // if ($contentType == $benefitSectionType) {
        if (in_array($contentType, $benefitsArr)) {
            $sessionMapping = new Model_ProductSectionData();
            $productSessionData = $sessionMapping->getDataByType($course_faq_id, BaseApp_Dao_SectionMapping::COURSE_FAQ_LINKABLE_TYPE , BaseApp_Dao_ProductSectionData::JOB_DESIGNATION_SECTION_TYPE, true, 'sm.id ASC');
            if (!empty($productSessionData)) {
                foreach($productSessionData as $sectionDatum){
                    if (!empty($sectionDatum)){
                        $job = array();
                        $sectionId = $sectionDatum['section_id'];
                        $sectionMapId = $sectionDatum['section_map_id'];
                        $job['section_id'] = $sectionId;
                        $job['section_map_id'] = $sectionMapId;
                        $job['designation'] = $sectionDatum['name'];
                        //salaries
                        $job = array_merge($job, $this->_getSalariesOfJobDescription($sectionMapId));
                        //hiring companies
                        $job['hiring_companies'] = $this->_getHiringCompaniesOfJobDescription($sectionId);
                        $job['company_ids'] = implode(',', $this->_getHiringCompaniesOfJobDescription($sectionId));
                        array_push($returnData, $job);
                    }
                }
            }
        } 
        return $returnData;
    }

    private function _getTrainingDetailsBenefitType($course_faq_id){
        $objFaq = new self();
        $objFaq->setId($course_faq_id);           
        $contentType = $objFaq->getData('type');         
        $returnData = array();
         if ($contentType == BaseApp_Dao_CourseFaq::BUNDLE_INDUSTRY_ID) {            
            $sessionMapping = new Model_ProductSectionData();
            $productSessionDataForName = array_values($sessionMapping->getDataByType($course_faq_id, BaseApp_Dao_SectionMapping::COURSE_FAQ_LINKABLE_TYPE , BaseApp_Dao_ProductSectionData::INDUSTRY_TREND_NAME, true, 'sm.id ASC'));
            $productSessionDataForPointOne = array_values($sessionMapping->getDataByType($course_faq_id, BaseApp_Dao_SectionMapping::COURSE_FAQ_LINKABLE_TYPE , BaseApp_Dao_ProductSectionData::INDUSTRY_TREND_FIRST_POINT, true, 'sm.id ASC'));
            $productSessionDataForPointTwo = array_values($sessionMapping->getDataByType($course_faq_id, BaseApp_Dao_SectionMapping::COURSE_FAQ_LINKABLE_TYPE , BaseApp_Dao_ProductSectionData::INDUSTRY_TREND_SECOND_POINT, true, 'sm.id ASC'));            
            $productSessionDataDesignation = array_values($sessionMapping->getDataByType($course_faq_id, BaseApp_Dao_SectionMapping::COURSE_FAQ_LINKABLE_TYPE , BaseApp_Dao_ProductSectionData::INDUSTRY_TREND_DESIGNATION, true, 'sm.id ASC'));            
            $trainingDetails = array();
            
            if(!empty($productSessionDataForName[0])){                
                $sectionId = $productSessionDataForName[0]['section_id'];
                $sectionMapId = $productSessionDataForName[0]['section_map_id'];
                $trainingDetails['section_id'] = $sectionId;
                $trainingDetails['section_map_id'] = $sectionMapId;
                $trainingDetails['sectionType'] =$productSessionDataForName[0]['ps_sectiontype'];
                $trainingDetails['name'] = $productSessionDataForName[0]['name'];
                $trainingDetails['description'] = $productSessionDataForName[0]['ps_description'];                              
                array_push($returnData, $trainingDetails);
            }
            if(!empty($productSessionDataForPointOne[0])){
                $sectionId = $productSessionDataForPointOne[0]['section_id'];
                $sectionMapId = $productSessionDataForPointOne[0]['section_map_id'];
                $trainingDetails['section_id'] = $sectionId;
                $trainingDetails['section_map_id'] = $sectionMapId;
                $trainingDetails['sectionType'] =$productSessionDataForPointOne[0]['ps_sectiontype']; 
                $trainingDetails['name'] = $productSessionDataForPointOne[0]['name'];
                $trainingDetails['description'] = $productSessionDataForPointOne[0]['ps_description'];                              
                array_push($returnData, $trainingDetails);
            }
            if(!empty($productSessionDataForPointTwo[0])){
                $sectionId = $productSessionDataForPointTwo[0]['section_id'];
                $sectionMapId = $productSessionDataForPointTwo[0]['section_map_id'];
                $trainingDetails['section_id'] = $sectionId;
                $trainingDetails['section_map_id'] = $sectionMapId;
                $trainingDetails['sectionType'] =$productSessionDataForPointTwo[0]['ps_sectiontype']; 
                $trainingDetails['name'] = $productSessionDataForPointTwo[0]['name'];
                $trainingDetails['description'] = $productSessionDataForPointTwo[0]['ps_description'];                              
                array_push($returnData, $trainingDetails);                
            }
            if(!empty($productSessionDataDesignation[0])){
                $sectionId = $productSessionDataDesignation[0]['section_id'];
                $sectionMapId = $productSessionDataDesignation[0]['section_map_id'];
                $trainingDetails['section_id'] = $sectionId;
                $trainingDetails['section_map_id'] = $sectionMapId;
                $trainingDetails['sectionType'] =$productSessionDataDesignation[0]['ps_sectiontype']; 
                $trainingDetails['name'] = $productSessionDataDesignation[0]['name'];
                $trainingDetails['description'] = $productSessionDataDesignation[0]['ps_description'];                              
                array_push($returnData, $trainingDetails);                
            }
                        
        } 
        return $returnData;
    }

    private function _getSalariesOfJobDescription($jDSectionMapId){
        $salary = array();
        $objSalary = new Model_Salaries();
        $jobSalaries = $objSalary->getSalariesBySectionMapId($jDSectionMapId); 
        if (!empty($jobSalaries)){                   
            foreach($jobSalaries as $jobSalary){
                if (!empty($jobSalary)){
                    $salary[$jobSalary['label']] = $jobSalary['salary'];
                }
            }
        }
        return $salary;
    }

    private function _getHiringCompaniesOfJobDescription($jDSectionId){
        $companies = array();
        $objSectionMapping = new Model_SectionMapping();
        $jobCompanies = $objSectionMapping->getByProductSection('hiring_company', $jDSectionId);                    
        if (!empty($jobCompanies)){
            foreach($jobCompanies as $company){
                if (!empty($company)){
                    array_push($companies, $company);
                }
            }
        }
        return $companies;
    }

    public function getContentIdByTypeAndCourseId($courseId, $type,$clusterId=0,$countryId=0,$cityId=0){

        $db = $this->getDb();
        $queryStatement = $db
            ->select()
            ->from(array('crm' => self::TABLE_COURSE_RESOURCE_MAPPING), '*')
            ->join($this->_name . ' as cf', 'crm.faq_id=cf.course_faq_id', array('crm.order','crmStatus'=>'crm.status','crm.faq_id','crmId' => 'crm.id'))
            ->join(self::TABLE_COURSE_CITY_LOOKUP . ' as ccl', 'ccl.id=crm.lookup_id', array('crm.lookup_id','ccl.linkable_type','ccl.course_id','ccl.city_id','cclStatus'=>'ccl.status'))
            ->where('cf.status=?',1)
            ->where('ccl.status=?',1)
            ->where('ccl.course_id=?',$courseId)
            ->where('cf.type=?',$type);   

        $queryStatement->where('ccl.cluster_id=?', $clusterId);
        $queryStatement->where('ccl.country_id=?', $countryId);
        $queryStatement->where('ccl.city_id=?', $cityId);
        
        $data = $db->fetchAll($queryStatement);
        return current($data);
    }

    public function getByTypeAndContentId($courseId, $type, $trainingId, $countryId = '', $clusterId = '', $contentId = '', $offset = 0, $limitPerPage = 10,$linkableType="course") {
        $returnData = array();
        if ($trainingId === false) {
            $trainingId = null;
        }
        $objCourseFaq = new self();
        if (!empty($contentId)) {
            $objCourseFaq->setFaqId($contentId);
        }
        if (!empty($countryId)) {
            $objCourseFaq->setCountryId($countryId);
        }
        if (!empty($clusterId)) {
            $objCourseFaq->setClusterId($clusterId);
        }
        $objCourseFaq->setOffsetLimit($offset, $limitPerPage);
        //$objCourseFaq->setLinkableType($linkableType);
        $list = $objCourseFaq->getCourseResources($courseId, $type, $trainingId,null,array(),$linkableType);
        foreach ($list as $tempId => $dataReal) {
            $returnData[$dataReal['faq_id']] = array(
                'faq_id' => $dataReal['faq_id'],
                'question' => $dataReal['question'],
                'answer' => $dataReal['answer'],
                'is_b2b' => $dataReal['is_b2b'],
                'is_b2c' => $dataReal['is_b2c'],
                'jump_to_section' => $dataReal['jump_to_section'],
                'countryIds' => !empty($dataReal['countryIds']) ? $dataReal['countryIds'] : '',
                'countryName' => !empty($dataReal['countryName']) ? $dataReal['countryName'] : '',
                'clusterIds' => !empty($dataReal['clusterIds']) ? $dataReal['clusterIds'] : '',
                'clusterName' => !empty($dataReal['clusterName']) ? $dataReal['clusterName'] : '',
                'contentMappedCountries' => !empty($dataReal['countryIds']) ? $dataReal['countryIds'] : '',
                'contentMappedClusters' => !empty($dataReal['clusterIds']) ? $dataReal['clusterIds'] : '',
                'isProplus'=>!empty($dataReal['isProplus']) ? $dataReal['isProplus'] : 0,
            );
        }
        return $returnData;
    }

    public function getByTypeGeneric($type, $trainingId) {
        $returnData = array();
        $conds = array('type=?' => $type);
        if ($trainingId !== false) {
            $conds['training_id=?'] = $trainingId;
        }
        $counter = 1;
        foreach ($this->fetchAll($conds) as $tempId => $dataReal) {
            $returnData[$counter] = array(
                'question' => $dataReal['question'],
                'answer' => $dataReal['answer']
            );
            $counter++;
        }
        return $returnData;
    }

    public function getByLinkable($linkableId, $linkableType) {
        return $this->fetchAll(array("linkable_id = ?" => $linkableId, "linkable_type = ?" => $linkableType));
    }

    /**
     * Update Course Faq
     * @param type $faqData
     * @param type $type
     * @param type $courseId
     * @param type $trainingId
     * @return boolean
     * @throws Exception
     */
    public function updateCourseFaq($faqData, $type, $courseId, $trainingId) {
        $db = $this->getDb();
        $objFaq = new self();
        $courseResourceMappingModel = new BaseApp_Dao_CourseResourceMapping();
        $lookupModel = new BaseApp_Dao_CourseCityLookup();
        $db->beginTransaction();
        try {
            $trainingTypeId = 0;
            if ($trainingId !== false) {
                $trainingTypeId = $trainingId;
            }
            $columns = array(
                BaseApp_Dao_CourseFaq::TABLE_COURSE_FAQ_ALIAS . '.course_faq_id',
                BaseApp_Dao_CourseFaq::TABLE_COURSE_FAQ_ALIAS . '.question',
                BaseApp_Dao_CourseFaq::TABLE_COURSE_RESOURCE_MAPPING_ALIAS . '.lookup_id',
                BaseApp_Dao_CourseFaq::TABLE_COURSE_RESOURCE_MAPPING_ALIAS . '.order'
            );
            $modelCountryContentMapping = new Model_CountryContentMapping();
            $faqLinkableType = !empty($faqData['linkable_type']) ? $faqData['linkable_type'] : '';
            $faqLinkableId = !empty($faqData['linkable_id']) ? $faqData['linkable_id'] : $courseId;
            if (empty($faqLinkableType)) {
                throw new Exception("Failed Linkable Type Is Missing !");
            }
            if (isset($faqData['linkable_type'])) {
                unset($faqData['linkable_type']);
            }
            if (isset($faqData['linkable_id'])) {
                unset($faqData['linkable_id']);
            }
            foreach ($faqData as $indexId => $dataSave) {
                $faqId = $dataSave['course_faq_id'];
                $countryIds = !empty($dataSave['country_id']) ? $dataSave['country_id'] : 0;
                $clusterIds = !empty($dataSave['cluster_id']) ? $dataSave['cluster_id'] : 0;
                $linkableId = !empty($dataSave['linkable_id']) ? $dataSave['linkable_id'] : $faqLinkableId;
                $linkableType = !empty($dataSave['linkable_type']) ? $dataSave['linkable_type'] : $faqLinkableType;
                unset($dataSave['country_id']);
                unset($dataSave['cluster_id']);
                unset($dataSave['linkable_id']);
                unset($dataSave['linkable_type']);
                unset($dataSave['all_country']);
                $objFaq->clean();
                $objFaq->setId($faqId);
                $objFaq->setFromArray($dataSave)->update();
                // Update Content Resource Mapping If CountryId Or ClusterId Is Not Empty
                $detailContentMappingInfo = array(
                    'faq_id' => $faqId,
                    'countryIds' => $countryIds,
                    'clusterIds' => $clusterIds,
                    'linkableType' => $linkableType,
                    'linkableId' => $linkableId
                );
                $modelCountryContentMapping->detailContentMapping($detailContentMappingInfo);
            }
            $db->commit();
            return true;
        } catch (Exception $e) {
            $db->rollBack();
            return false;
        }
    }

    /**
     * Add New Course Faq
     * @param type $faqData
     * @param type $type
     * @param type $courseId
     * @param type $trainingId
     * @return boolean
     * @throws Exception
     */
    public function addCourseContent($faqData, $type, $courseId, $trainingId, $certificateParams = '',$isEdit = '',$linkableType="course",$editFaqOrder=0) {
        $db = $this->getDb();
        $objFaq = new self();
        $courseResourceMappingModel = new BaseApp_Dao_CourseResourceMapping();
        $lookupModel = new BaseApp_Dao_CourseCityLookup();
        $lastCreatedFaqId = array();
        $db->beginTransaction();
        $allCountriesEnable = array();
        $clusterCountriesEnable = array();
        $faqIds = array();        
        try {
            $trainingTypeId = 0;
            if ($trainingId !== false) {
                $trainingTypeId = $trainingId;
            }
            $faqLinkableType = !empty($linkableType) ? $linkableType : 'course';
            if (isset($faqData['linkable_type'])) {
                unset($faqData['linkable_type']);
            }
            if (isset($faqData['linkable_id'])) {
                unset($faqData['linkable_id']);
            }
            unset($faqData['linkable_id']);
            $prepareDataToSave = array();
            if (!empty($faqData)) {
                $fkey = 0;
                foreach ($faqData as $fData) {
                    if($type == 1){
                        $answerTmp = $fData['answer'];
                        $answerTmp = strip_tags($answerTmp);
                        $fData['answer'] = $answerTmp;
                    }
                    $countryIds = array();
                    $clusterIds = array();
                    $cityIds = array();
                    $allCountry = false;
                    // prepare mapping data for save
                    if (!empty($fData['country_id'])) {
                        if (is_array($fData['country_id'])) {
                            $countryIds = $fData['country_id'];
                        } else {
                            $countryIds = explode(',', $fData['country_id']);
                        }
                    }

                    if (!empty($fData['cluster_id'])) {
                        if (is_array($fData['cluster_id'])) {
                            $clusterIds = $fData['cluster_id'];
                        } else {
                            $clusterIds = explode(',', $fData['cluster_id']);
                        }
                    }

                    if (!empty($fData['city_id'])) {
                        if (is_array($fData['city_id'])) {
                            $cityIds = $fData['city_id'];
                        } else {
                            $cityIds = explode(',', $fData['city_id']);
                        }
                    }

                    // save or update question
                    $courseFaqId = 0;
                    if (!empty($isEdit) && $isEdit === true) {                       
                        $courseFaqId = $fData['course_faq_id'];
                        $faqIds[] = $fData['course_faq_id'];
                    }
                    $allCountry = !empty($fData['all_country']) ? true : false;
                    unset($fData['country_id']);
                    unset($fData['cluster_id']);
                    unset($fData['city_id']);
                    unset($fData['linkable_id']);
                    unset($fData['linkable_type']);
                    unset($fData['all_country']);
                    unset($fData['jobdesignation']);
                    unset($fData['industry_name']);
                    unset($fData['point_one_heading']);
                    unset($fData['point_one_text']);
                    unset($fData['point_two_heading']);
                    unset($fData['point_two_text']);
                    $objFaq->clean();
                    if (!empty($courseFaqId)) {
                        //get city lookupIds
                        $cityLookupIds = $lookupModel->getProductCityMapping($courseId, $linkableType);
                        $objFaq->setId($courseFaqId);                        
                        $objFaq->setFromArray($fData)->update();
                        if(!in_array($type,array(BaseApp_Dao_CourseFaq::COURSE_RESOURCE_BENEFITS))){
                            $courseResourceMappingModel->clean();
                            $conds = array('faq_id = ?' => $courseFaqId);
                            if (!empty($cityLookupIds)) {
                                $conds['lookup_id not IN (?)'] = $cityLookupIds;
                            }
                            $courseResourceMappingModel->deleteWhere($conds);
                        }
                    } else {
                        $fData['training_id'] = $trainingId?$trainingId:0 ;
                        $fData['type'] = $type? $type:null;
                        $fData['status'] = 1;
                        $objFaq->setFromArray($fData)->save();
                        $courseFaqId = $objFaq->__get($objFaq->getPk());
                    }
                    $lastCreatedFaqId[$fkey]=$courseFaqId;
                    //mapping data with new/old questionId
                    $dataToSave = array('course_faq_id' => $courseFaqId);
                    if (!empty($countryIds)) {
                        foreach ($countryIds as $countryId) {
                            $dataToSave['country_id'] = $countryId;
                            $dataToSave['cluster_id'] = 0;
                            $dataToSave['city_id'] =0;
                            $prepareDataToSave[$fkey][] = $dataToSave;
                        }
                    }

                    if (!empty($clusterIds)) {
                        foreach ($clusterIds as $clusterId) {
                            $dataToSave['country_id'] = 0;
                            $dataToSave['cluster_id'] = $clusterId;
                            $dataToSave['city_id'] =0;
                            $prepareDataToSave[$fkey][] = $dataToSave;
                            $clusterCountriesEnable[$courseFaqId][] = $clusterId;
                        }
                    }

                    if (!empty($cityIds)) {
                        foreach ($cityIds as $cityId) {
                            $dataToSave['country_id'] = 0;
                            $dataToSave['cluster_id'] = 0;
                            $dataToSave['city_id'] = $cityId;
                            $prepareDataToSave[$fkey][] = $dataToSave;
                        }
                    }


                    if ((empty($countryIds) && empty($clusterIds) && empty($cityIds)) || $allCountry) {
                        $dataToSave['country_id'] = 0;
                        $dataToSave['cluster_id'] = 0;
                        $dataToSave['city_id'] = 0;
                        $prepareDataToSave[$fkey][] = $dataToSave;
                        $allCountriesEnable[] = $courseFaqId;
                    }

                    $fkey++;
                }
            }
            if (!empty($prepareDataToSave) && !empty($lastCreatedFaqId)) {
                $maxOrderByFaqId = array();
                if (!empty($faqIds)) {
                    foreach ($faqIds as $key => $value) {
                        $result = $courseResourceMappingModel->getAllLookupIdByParentFaqId($value);
                        $maxOrderByFaqId[$value] = !empty($result['lookup_id']) ? $result['lookup_id']:array();
                    }
                }
                foreach ($prepareDataToSave as $key => $row) {
                    foreach ($row as $j => $dataToSave) {
                        $courseFaqId = $dataToSave['course_faq_id'];
                        $clusterId = $dataToSave['cluster_id'];
                        $countryId = $dataToSave['country_id'];
                        $cityId = $dataToSave['city_id'];
                        $lookupId = 0;
                        $maxOrder = 1;
                        if (!empty($courseFaqId)) {
                            
                            $lookupId = $lookupModel->checkProductGlobalMapping($courseId, $linkableType, $clusterId, $countryId, $cityId);
                            if (empty($lookupId)) {
                                throw new Exception("Failed to create lookup id");
                            }
                            $checkMapping = !empty($maxOrderByFaqId[$courseFaqId]) && in_array($lookupId, $maxOrderByFaqId[$courseFaqId]) ? true : false;
                            if ( !in_array($type,array(BaseApp_Dao_CourseFaq::COURSE_RESOURCE_BENEFITS)) && $checkMapping) {
                                $mappingIds = $courseResourceMappingModel->getLookupFaqData($courseFaqId,$lookupId);
                                if (!empty($mappingIds)) {
                                    foreach ($mappingIds as $key => $value) {
                                        $courseResourceMappingModel->clean();
                                        $courseResourceMappingModel->setId($value);
                                        $mappingData = array('status'=>1);
                                        $courseResourceMappingModel->setFromArray($mappingData)->update();
                                    }
                                }
                            } else {
                                $insert = true;
                                if(in_array($type,array(BaseApp_Dao_CourseFaq::COURSE_RESOURCE_BENEFITS))){
                                    $insert = false;
                                    $checkMappingExists = $courseResourceMappingModel->checkResourceMappingExists($courseFaqId, $lookupId);
                                    if(empty($checkMappingExists)) {
                                        $insert = true;
                                    }
                                }

                                if($insert){
                                    $lastOrder = $courseResourceMappingModel->getMaxOrderByLookupId($lookupId, $type, $trainingId);
                                    $maxOrder = $lastOrder + BaseApp_Dao_CourseResourceMapping::ORDER_STEP;
                                    $crmData = array(
                                        'lookup_id' => $lookupId,
                                        'faq_id' => (int)$courseFaqId,
                                        'order' => $maxOrder,
                                        'status' => 1,
                                    );
                                    $courseResourceMappingModel->clean();
                                    $courseResourceMappingModel->setFromArray($crmData)->save();
                                }
                            }
                        }
                    }
                }
            }
            $db->commit();
            if (!empty($isEdit) && $isEdit === true && (!empty($clusterCountriesEnable) || !empty($allCountriesEnable))) {
                if ($type !=BaseApp_Dao_CourseFaq::COURSE_RESOURCE_EXAM_PASS_NEW_ID){
                    $this->enableParentMapping($clusterCountriesEnable, $allCountriesEnable, $courseId, $linkableType);
                }
            }
            //IF it is just one entry return id else return true;
            //reduces a query to get id again
            if (count($faqData) == 1){
            return $objFaq->_id;
            } else {
                return true;
            }
        } catch (Exception $e) {
            $db->rollBack();            
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }

    public function enableParentMapping($clusterCountriesEnable,$allCountriesEnable, $courseId, $linkableType) {
        $db = $this->getDb();
        $courseResourceMappingModel = new BaseApp_Dao_CourseResourceMapping();
        $lookupModel = new BaseApp_Dao_CourseCityLookup();
        try {
            $resourceMappingData = array();
            //get country mapping data for clusters selected
            if (!empty($clusterCountriesEnable) && empty($allCountriesEnable)) {
                $resourceMappingData = $this->getClusterCountryMapping($clusterCountriesEnable, $courseId, $linkableType);
            }

            //get all mapping data for clusters selected
            if (!empty($allCountriesEnable)) {
                foreach ($allCountriesEnable as $key => $faqId) {
                    $objFaq = new self();
                    $objFaq->setId($faqId);
                    $trainingId = $objFaq->getData('training_id');
                    $contentType = $objFaq->getData('type');
                    $faqRM = $courseResourceMappingModel->getAllFaqData($faqId, 1);
                    foreach ($faqRM as $key => $value) {
                        $value['training_id'] = $trainingId;
                        $value['type'] = $contentType;
                        $resourceMappingData[] = $value;
                    }
                }
            }

            //enable and move to end disabled questions since all countries was selected
            $mappingIdsMoved = array();
            if (!empty($resourceMappingData)) {
                if (!empty($resourceMappingData)) {
                    $lookupIds = array_column($resourceMappingData, 'lookup_id');
                    $cityLookupIds = $lookupModel->getProductCityMapping($courseId, $linkableType);
                    foreach ($resourceMappingData as $key => $value) {
                        if ($value['status'] == 0 && !in_array($value['lookup_id'], $cityLookupIds)) {
                            $mappingIdsMoved[] = $value['id'];
                            $pageLookupId = $value['lookup_id'];
                            $lastOrder = $courseResourceMappingModel->getMaxOrderByLookupId($value['lookup_id'],$value['type'],$value['training_id']);
                            $courseResourceMappingModel->changeLookupPosition($value['lookup_id'], $value['faq_id'], $value['type'],$value['training_id'], $lastOrder, $value['order']);
                        }
                    }
                }
            }
            $db->beginTransaction();
            if (!empty($mappingIdsMoved)) {
                foreach ($mappingIdsMoved as $key => $value) {
                    $courseResourceMappingModel->clean();
                    $courseResourceMappingModel->setId($value);
                    $mappingData = array('status'=>1);
                    $courseResourceMappingModel->setFromArray($mappingData)->update();
                }
            }
            $db->commit();
            return true;
        } catch (Exception $e) {
            $db->rollBack();
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }

    public function getClusterCountryMapping($clusterCountriesEnable, $courseId, $linkableType) {
        $objFaq = new self();
        $resourceMappingData = array();
        $courseResourceMappingModel = new BaseApp_Dao_CourseResourceMapping();
        $lookupModel = new BaseApp_Dao_CourseCityLookup();
        $countryObj = new Model_Country();
        foreach ($clusterCountriesEnable as $faqId => $clusters) {
            $mappingIds = array();
            if (!empty($clusters)) {
                $objFaq = new self();
                $objFaq->setId($faqId);
                $trainingId = $objFaq->getData('training_id');
                $contentType = $objFaq->getData('type');
                $countryIdsForClusters = array_keys($countryObj->getCountriesByCluster($clusters));
                if (!empty($countryIdsForClusters)) {
                    foreach ($countryIdsForClusters as $keyCo => $valueCo) {
                        $lookupId = $lookupModel->getProductGlobalMapping($courseId, $linkableType, 0, $valueCo, 0);
                        $mappingIds = $courseResourceMappingModel->getLookupFaqData($faqId,$lookupId);
                            if (!empty($mappingIds)) {
                                foreach ($mappingIds as $key => $crmId) {
                                    $courseResourceMappingModel->clean();
                                    $courseResourceMappingModel->setId($crmId);
                                    $dataMap = array('id'=>$crmId,
                                       'order' => $courseResourceMappingModel->getData('order'),
                                       'faq_id' => $faqId,
                                       'lookup_id' => $lookupId,
                                       'training_id' => $trainingId,
                                       'type' => $contentType
                                    );
                                    $resourceMappingData[] = $dataMap;
                                }
                            }
                    }
                }
                //lookupids with course and country
                //get mappings for all lookupids and faqid
                //do we include city??


            }
        }
        return $resourceMappingData;
    }

    public function changeFaQOrder($faqData, $currentPos=0, $finalPosition=0) {
        $objFaq = new self();
        $courseResourceMappingModel = new BaseApp_Dao_CourseResourceMapping();
        $lookupModel = new BaseApp_Dao_CourseCityLookup();
        try {
            $contentId = $faqData['course_faq_id'];
            $productType = !empty($faqData['linkable_type']) ? $faqData['linkable_type'] : '';
            $productId = !empty($faqData['linkable_id']) ? $faqData['linkable_id'] : 0;
            $clusterId = !empty($faqData['cluster_id']) ? $faqData['cluster_id'] : 0;
            $countryId = !empty($faqData['country_id']) ? $faqData['country_id'] : 0;
            $cityId = !empty($faqData['city_id']) ? $faqData['city_id'] : 0;
            $contentType = !empty($faqData['content_type']) ? $faqData['content_type'] : '';
            $trainingId = !empty($faqData['training_id']) ? $faqData['training_id'] : 0;
            $pageLookupId = $lookupModel->checkProductGlobalMapping($productId, $productType, $clusterId, $countryId,$cityId);
            $faqData = $this->getDataByTypeAndContentId($productId, $productType, $contentType, $trainingId, $clusterId, $countryId, $cityId);
            if(!empty($faqData)){
                foreach($faqData as $key=>$value){
                    if(empty($value['cityIds']) && empty($value['countryIds']) && empty($value['clusterIds']) && empty($value['crmStatus'])){
                        unset($faqData[$key]);
                    }
                }
            }
            $faqData = !empty($faqData) ? array_values($faqData):array();
            if(count($faqData) == 0){
                return true;
            }
            if ($finalPosition > count($faqData))
                $finalPosition = count($faqData);
            if ($finalPosition == $currentPos) {
                return true;
            }
            $pos = 1;
            $currentLookupId = 0;
            $currentStatus = 0;
            $finalLookupId = 0;
            $lookUpIdsIncluded = array();
            foreach ($faqData as $key => $value) {
                if ($pos == $currentPos) {
                    $currentLookupId = $value['lookup_id'];
                    $currentStatus = $value['crmStatus'];
                }
                if ($pos == $finalPosition) {
                    $finalLookupId = $value['lookup_id'];
                }
                $pos++;
            }

            $lastOrder = $courseResourceMappingModel->getMaxOrderByLookupId($pageLookupId,$contentType,$trainingId);
            $maxOrder = $lastOrder + BaseApp_Dao_CourseResourceMapping::ORDER_STEP;
            // pr($currentPos, $lastOrder, $maxOrder, $finalPosition);
            $sameLookUpQuestions = 0;
            if ($maxOrder <= $finalPosition) {
                $lookupIds = array();
                $pos = 1;
                foreach ($faqData as $key => $value) {
                    if (($finalPosition < $currentPos &&  $pos < $finalPosition && $value['lookup_id'] != $pageLookupId) || ($finalPosition > $currentPos &&  $pos <= $finalPosition && $value['lookup_id'] != $pageLookupId && $value['faq_id'] != $contentId)  && $value['disabled'] != 1) {
                        $addPos = $pos;
                        if(($finalPosition < $currentPos && $pos == $finalPosition)  || ($finalPosition > $currentPos && $pos > $currentPos && $sameLookUpQuestions == 0) || ($finalPosition > $currentPos && $pos > $currentPos && $value['lookup_id'] == $currentLookupId && $sameLookUpQuestions > 0))
                            $addPos = $addPos - 1;
                        // pr($addPos,$value['faq_id']);
                        $courseResourceMappingModel->addResourceMapping($pageLookupId,$value['faq_id'], $contentType, $trainingId, $addPos, 0, $value['crmStatus']);
                        $maxOrder++;
                    } else {
                        if($finalPosition > $currentPos && $value['lookup_id'] == $pageLookupId) {
                            $sameLookUpQuestions++;
                        }
                    }
                    $pos++;
                }
            }
            if ($maxOrder >= $finalPosition) {
                if ($currentLookupId > 0 && $currentLookupId == $pageLookupId) {
                    // pr('move',$finalPosition,$currentPos);
                     $courseResourceMappingModel->changeLookupPosition($currentLookupId, $contentId, $contentType, $trainingId, $finalPosition, $currentPos);
                } elseif ($currentLookupId != $pageLookupId) {
                    // pr('add',$finalPosition);
                    $courseResourceMappingModel->addResourceMapping($pageLookupId, $contentId, $contentType, $trainingId, $finalPosition, $maxOrder, $currentStatus);
                }

            }
            return true;
        } catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }

    public function deleteCourseCitiesFaq($courseId,$type,$countryId = 0)
    {
        $cityPageModel = new Model_CityPage();
        $cityList = $cityPageModel->getCourseCities($courseId);
        if (!empty($cityList)) {
            $cityIds = array_keys($cityList);
            $countryData = $cityPageModel->countryDataByCityId($cityIds);
            $cityCountryIdMapping = array_column($countryData, 'country_id', 'city_id');
            $cities = array();
            foreach ($cityCountryIdMapping as $cityId => $country_id) {
                $cities[$country_id][] = $cityId;
            }

            //delete course city lookup
            $db = $this->getDb();
            $sqlCityFaq = $db->select()
                ->from(array('ccl' => 'course_city_lookup'), array('id', 'city_id'))
                ->join('course_resource_mapping as crm', 'ccl.id=crm.lookup_id and crm.status=1', array('faqId' => 'crm.faq_id'))
                ->join('courseFaq as cf', 'cf.course_faq_id=crm.faq_id and cf.status=1', array('faqId' => 'crm.faq_id'))
                ->where("ccl.course_id = ?", (int) $courseId)
                ->where("cf.type = ?", $type)
                ->where("ccl.status = ?", 1)
                ->where("ccl.linkable_type = ?", 'course');

            $getFaqs = false;
            $resultFaqs = array();
            if($countryId != 0){
                if(!empty($cities[$countryId])){
                    $cityCountryIdMap = $cities[$countryId];
                    $sqlCityFaq->where("ccl.city_id in (?)", $cityCountryIdMap);
                    $getFaqs = true;
                }
            }else if($countryId == 0){
                //other than Indian cities
                if(!empty($cities[INDIA_COUNTRY_ID])){
                    $cityCountryIdMap = array_diff(array_keys($cityCountryIdMapping),$cities[INDIA_COUNTRY_ID]);
                }else{
                    $cityCountryIdMap = array_keys($cityCountryIdMapping);
                }
                $sqlCityFaq->where("ccl.city_id in (?)", $cityCountryIdMap);
                $getFaqs = true;
            }

            if($getFaqs){
                $resultFaqs = $db->fetchAll($sqlCityFaq);
            }

            foreach ($resultFaqs as $cityFaq) {
                //deletefaq for country cities
                $objFaqModel = new Model_CourseFaq();
                $objFaqModel->clean();
                $conds = array('course_faq_id = ?' => $cityFaq['faqId'], 'type = ?' => $type);
                $objFaqModel->deleteWhere($conds);
                $courseResourceMappingModel = new Model_CourseResourceMapping();
                $courseResourceMappingModel->deleteCrmByFaqId($cityFaq['faqId']);
            }
        }
    }

    public function deleteCourseFaq($faqData, $type, $courseId = '') {
        $db = $this->getDb();
        $objFaq = new self();
        $courseResourceMappingModel = new BaseApp_Dao_CourseResourceMapping();
        $lookupModel = new BaseApp_Dao_CourseCityLookup();
        try {
            $db->beginTransaction();
            if ($type == (BaseApp_Dao_ProductTypes::TYPE_ID_ELIGIBILITY) || ($type == BaseApp_Dao_ProductTypes::TYPE_ID_PREREQUISITES)) {
                $faqLinkableType = !empty($faqData[0]['linkable_type']) ? $faqData[0]['linkable_type'] : '';
                $faqLinkableId = !empty($faqData[0]['linkable_id']) ? $faqData[0]['linkable_id'] : $courseId;
                if (empty($faqLinkableType)) {
                    throw new Exception("Failed Linkable Type Is Missing !");
                }
                if (isset($faqData[0]['linkable_type'])) {
                    unset($faqData[0]['linkable_type']);
                }
                if (isset($faqData[0]['linkable_id'])) {
                    unset($faqData[0]['linkable_id']);
                }
            }
            else {
                $faqLinkableType = !empty($faqData['linkable_type']) ? $faqData['linkable_type'] : '';
                $faqLinkableId = !empty($faqData['linkable_id']) ? $faqData['linkable_id'] : $courseId;
                if( in_array($type,array(BaseApp_Dao_CourseFaq::COURSE_RESOURCE_BENEFITS)) && 
                    ( (empty($faqData['country_id']) && empty($faqData['city_id'])) || !empty($faqData['country_id']) )
                ){
                    $countryDelId =  $faqData['country_id'];
                }
                if (empty($faqLinkableType)) {
                    throw new Exception("Failed Linkable Type Is Missing !");
                }
                if (isset($faqData['linkable_type'])) {
                    unset($faqData['linkable_type']);
                }
                if (isset($faqData['linkable_id'])) {
                    unset($faqData['linkable_id']);
                }
            }
            foreach ($faqData as $indexId => $dataSave) {
                $faqId = $dataSave['course_faq_id'];
                $linkableId = !empty($dataSave['linkable_id']) ? $dataSave['linkable_id'] : $faqLinkableId;
                $linkableType = !empty($dataSave['linkable_type']) ? $dataSave['linkable_type'] : $faqLinkableType;

                $trainingId = $objFaq->getData('training_id');
                $contentType = $objFaq->getData('type');
                $objFaq = new self();
                $objFaq->setId($faqId);
                $resourceMappingData = $courseResourceMappingModel->getAllFaqData($faqId, 1);

                // delete from courseResourceMappingModel
                $courseResourceMappingModel->deleteCrmByFaqId($faqId);

                //if the faw has product section data delete that as well
                if (
                    !in_array($type, array(BaseApp_Dao_CourseFaq::COURSE_RESOURCE_BENEFITS))
                    || (in_array($type, array(BaseApp_Dao_CourseFaq::COURSE_RESOURCE_BENEFITS)) && empty($faqData['city_id']))
                ) {
                    $this->_deleteProductSectionDataOfFaq($faqId);
                }
                // delete from courseFaq
                $objFaq->clean();
                $conds = array('course_faq_id = ?' => $faqId, 'type = ?' => $type);
                $objFaq->deleteWhere($conds);
                if(isset($countryDelId)){
                    $objFaq->deleteCourseCitiesFaq($faqLinkableId,$type,$countryDelId);
                }

                $db->commit();

                if (!empty($resourceMappingData)) {
                    foreach ($resourceMappingData as $key => $value) {
                        //move the mapping to position zero
                        $courseResourceMappingModel->changeLookupPosition($value['lookup_id'], $faqId, $contentType,$trainingId, 0, $value['order']);
                    }
                }
            }
            return true;
        } catch (Exception $e) {
            pr($e->getMessage());
            $db->rollBack();
            return false;
        }
    }

    private function _deleteProductSectionDataOfFaq($faqId) {
        $sessionMapping = new Model_SectionMapping();
        $productSectionObj = new Model_ProductSectionData();
        $productSessionData = $sessionMapping->getByLinkableIdLinkableType($faqId, BaseApp_Dao_SectionMapping::COURSE_FAQ_LINKABLE_TYPE );        
        if (!empty($productSessionData)) {
            foreach($productSessionData as $productSessionDatum) {
                foreach($productSessionDatum as $product) {                    
                    if (!$productSectionObj->deleteById($product['section_id'])){
                        throw new BaseApp_Exception('Error deleting job designation');
                    }           
                }
            }
        }
    }

    public function disableCourseFaq($faqData, $type, $crmStatus=1,$courseId = '') {
        $objFaq = new self();
        $courseResourceMappingModel = new BaseApp_Dao_CourseResourceMapping();
        $lookupModel = new BaseApp_Dao_CourseCityLookup();
        try {
            $faqLinkableType = !empty($faqData['linkable_type']) ? $faqData['linkable_type'] : '';
            $faqLinkableId = !empty($faqData['linkable_id']) ? $faqData['linkable_id'] : $courseId;
            $clusterId = !empty($faqData['cluster_id']) ? $faqData['cluster_id'] : 0;
            $countryId = !empty($faqData['country_id']) ? $faqData['country_id'] : 0;
            $cityId = !empty($faqData['city_id']) ? $faqData['city_id'] : 0;
            $lookupId = $lookupModel->checkProductGlobalMapping($faqLinkableId, $faqLinkableType, $clusterId, $countryId, $cityId);
            $parentLookUpIds = $lookupModel->getParentLookUpIds($faqLinkableId, $faqLinkableType, $clusterId, $countryId, $cityId);
            $clusterCountriesEnable = array();
            $allCountriesEnable = array();
            if (empty($faqLinkableType)) {
                throw new Exception("Failed Linkable Type Is Missing !");
            }
            if (empty($lookupId)) {
                throw new Exception("Failed to find the mapping !");
            }
            if (isset($faqData['linkable_type'])) {
                unset($faqData['linkable_type']);
            }
            if (isset($faqData['linkable_id'])) {
                unset($faqData['linkable_id']);
            }
            if (!empty($faqData['content_ids'])) {
                foreach ($faqData['content_ids'] as $indexId => $dataSave) {
                    $faqId = $dataSave['course_faq_id'];
                    $linkableId = !empty($dataSave['linkable_id']) ? $dataSave['linkable_id'] : $faqLinkableId;
                    $linkableType = !empty($dataSave['linkable_type']) ? $dataSave['linkable_type'] : $faqLinkableType;
                    $mappingIds = $courseResourceMappingModel->getLookupFaqData($faqId,$lookupId);
                    if (!empty($mappingIds)) {
                        // disable from courseResourceMappingModel
                        $courseResourceMappingModel->clean();
                        if($crmStatus == 1){
                            $conds = array('faq_id = ?' => $faqId, 'lookup_id = ?' => $lookupId);
                            $courseResourceMappingModel->deleteWhere($conds);
                        }else{
                            foreach ($mappingIds as $key => $crmId) {
                                $dataUpdate = array('status'=>1);
                                $courseResourceMappingModel->setId($crmId);
                                $courseResourceMappingModel->setFromArray($dataUpdate)->update();
                            }
                        }
                    } else if(!empty($parentLookUpIds)) {
                        //add disabled mapping for lookup id
                        $objFaq = new self();
                        $objFaq->setId($faqId);
                        $lastOrder = $courseResourceMappingModel->getMaxOrderByLookupId($lookupId,$objFaq->getData('type'),$objFaq->getData('training_id'));
                        $maxOrder = $lastOrder + BaseApp_Dao_CourseResourceMapping::ORDER_STEP;
                        $status = $crmStatus == 1 ? 0 : 1;
                        $courseResourceMappingModel->addResourceMapping($lookupId, $faqId, $objFaq->getData('type'),$objFaq->getData('training_id'), $maxOrder, 0, $status);
                    }
                    if ($crmStatus == 0) {
                        if (!empty($clusterId)) {
                            $clusterCountriesEnable[$faqId] = array($clusterId);
                        }
                        if ($countryId == 'all') {
                            $allCountriesEnable[] = $faqId;
                        }
                        if (!empty($clusterCountriesEnable) || !empty($allCountriesEnable)) {
                            $this->enableParentMapping($clusterCountriesEnable,$allCountriesEnable, $courseId, $linkableType);
                        }
                    }
                }
            }
            return true;
        } catch (Exception $e) {
            pr($e->getMessage());
            return false;
        }
    }

    public function checkJobAssistForIndia($courseId, $type) {
        $db = $this->getDb();
        $objFaq = new self();
        $properties = $objFaq->getJobAssistResource($courseId, $type);
        if (count($properties)) {
            return $properties[0];
        } else {
            return null;
        }
    }

    public function setIsCityPage($cityId){
        if(!empty($cityId)){
            $this->_isCityPage = true;
        }
    }

    public function updateFaqType($faqId,$crmId,$type,$order,$trainingId){
        $db = $this->getDb();
        $objFaq = new self();
        $courseResourceMappingModel = new BaseApp_Dao_CourseResourceMapping();
        if (empty($faqId)) {
            throw new Exception("Failed Faq Id Is Missing !");
        }
        if (empty($type)) {
            throw new Exception("Failed Faq Type Is Missing !");
        }
        if (empty($crmId)) {
            throw new Exception("Failed Course Resourse Mapping Id Is Missing !");
        }
        if (empty($trainingId)) {
            throw new Exception("Failed Training Type Is Missing !");
        }

        $db->beginTransaction();
        try {
            //Update Type and trainingId
            $dataSave = array('type' => $type,'training_id' => $trainingId);
            $objFaq->clean();
            $objFaq->setId($faqId);
            $objFaq->setFromArray($dataSave)->update();

            //update order
            $dataSaveCrm = array('order' => $order);
            $courseResourceMappingModel->clean();
            $courseResourceMappingModel->setId($crmId);
            $courseResourceMappingModel->setFromArray($dataSaveCrm)->update();
            $db->commit();
            return true;
        }catch (Exception $e) {
            $db->rollBack();
            return false;
        }
    }
}

// End of Class
