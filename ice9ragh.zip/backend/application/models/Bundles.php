<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Model_Bundles extends BaseApp_Dao_Bundles
{

    public function createBundle($request)
    {
        $db = $this->getDb();
        $objBundle = new self();
        $pageUrl = '';
        if ($request['payment_type_id'] == BaseApp_Dao_PaymentType::SUBSCRIPTION_PAYMENT_TYPE_ID) {
            $request['free_trail_days'] = BaseApp_Dao_Bundles::SUBSCRIPTION_FREE_TRAIL_DAYS;
        } else {
            $request['free_trail_days'] = 0;
        }
        $db->beginTransaction();
        try {
            if (isset($request['url'])) {
                $pageUrl = trim($request['url']);
                $checkSlash = substr($pageUrl, 0, 1);
                if ($checkSlash != '/') {
                    $pageUrl = trim('/' . $pageUrl);
                }
                $objBundle->setPageUrl($pageUrl);
                unset($request['url']);
            }
            $request['learners'] = rand(200, 600);
            $request['masterProgramOrder'] = $this->masterProgramOrder() + 1;
            $objBundle->setFromArray($request)->save();

            $masterType                 = $request['master_type'];
            switch ($masterType) {
                case self::MASTER_TYPE_UNIVERSITY:
                    $controller = self::SEO_DEFAULT_CONTROLLER_UNIVERSITY_MASTER;
                    $params     = array("purdue_masters_id" => $objBundle->bundle_id);
                    break;
                case self::MASTER_TYPE_COHORT:
                    $controller = self::SEO_DEFAULT_CONTROLLER_COHORT_MASTER;
                    $params     = array("bundle_id" => $objBundle->bundle_id);
                    break;
                default:
                    $controller = self::SEO_DEFAULT_CONTROLLER;
                    $params     = array(self::SEO_DEFAULT_PARAM_KEY => $objBundle->bundle_id);
                    break;
            }
            $dataSave = array(
                'controller' => $controller,
                'action' => self::SEO_DEFAULT_ACTION,
                'params' => json_encode($params),
                'linkable_id' => $objBundle->bundle_id,
                'linkable_type' => 'bundle'
            );
            $modelSeo = new Model_Seo();
            $seoData = $modelSeo->getDataByUrl($pageUrl);
            $modelSeo->setId($seoData['seo_id']);
            $modelSeo->setFromArray($dataSave)->update();
            $db->commit();
            return $objBundle->bundle_id;
        } catch (Exception $e) {
            $db->rollBack();
            throw $e;
            return false;
        }
    }

    public function convertBundleToSub($data)
    {
        $db = $this->getDb();
        $objBundle = new self();
        $objSeo = new Model_Seo();
        $objLabel = new Model_Labels();
        $oldBundleId = $data['bundle_id'];
        $seoDetails = current($objSeo->fetchAll(array('linkable_id =?' => $oldBundleId, 'linkable_type =?' => 'bundle'), array('columns =?' => array('seo_id'))));
        if (empty($seoDetails))
            return false;
        $seoId = $seoDetails['seo_id'];
        $data['free_trail_days'] = 0;
        $db->beginTransaction();
        try {
            $objBundle->setFromArray($data)->save();
            $newBundleId = $objBundle->bundle_id;

            $objUpdate = new self();
            $objUpdate->setId($oldBundleId);
            $oldBundleUpdate = array('modified_bundle_id' => $newBundleId);
            $objUpdate->setFromArray($oldBundleUpdate)->update();

            $dataSave = array(
                'params' => json_encode(array(self::SEO_DEFAULT_PARAM_KEY => $newBundleId)),
                'linkable_id' => $newBundleId,
                'linkable_type' => 'bundle'
            );
            $objSeo->clean();
            $objSeo->setId($seoId);
            $objSeo->setFromArray($dataSave)->update();

            $labelData = $objLabel->fetchAll(array('default_subscription_id =?' => $oldBundleId), array('columns' => array('label_id')));
            if (!empty($labelData)) {
                foreach ($labelData as $labelId) {
                    $objLabel->clean();
                    $objLabel->setId($labelId['label_id']);
                    $saveLabelData = array('default_subscription_id' => NULL);
                    $objLabel->setFromArray($saveLabelData)->update();
                }
            }

            $db->commit();
            return $newBundleId;
        } catch (Exception $e) {
            $db->rollBack();
            throw $e;
            return false;
        }
    }

    public function updateBundle($data)
    {
        $db = $this->getDb();
        $objBundle = new self();
        $db->beginTransaction();
        try {
            if ($data['payment_type_id'] == BaseApp_Dao_PaymentType::SUBSCRIPTION_PAYMENT_TYPE_ID) {
                $data['free_trail_days'] = BaseApp_Dao_Bundles::SUBSCRIPTION_FREE_TRAIL_DAYS;
            } else {
                $data['free_trail_days'] = 0;
            }
            $objBundle->setId($data['bundle_id']);
            if (isset($data['label_id'])) {
                $oldLabels = explode(",", trim($objBundle->label_id));
                $newLabels = explode(",", trim($data['label_id']));
                $missingLabels = array_diff($oldLabels, $newLabels);
                $courseModel = new Model_Courses();
                foreach ($missingLabels as $labelId) {
                    $courseModel->removeCourseInLabelFlyout($labelId, BaseApp_Dao_ProductTypes::PREFIX_BUNDLE . $data['bundle_id']);
                }
            }
            $objBundle->setFromArray($data)->update();
            $db->commit();
            return true;
        } catch (Exception $e) {
            $db->rollBack();
            return false;
        }
    }

    public function getBundleByIds($bundleIds)
    {
        $return = array();
        if (!$bundleIds) {
            return $return;
        }
        $objBundle = new self();
        foreach ($objBundle->fetchAll(array('bundle_id IN (?)' => $bundleIds), array(), false) as $bundleData) {
            $return[$bundleData['bundle_id']] = $bundleData['name'];
        }
        return $return;
    }

    public function _afterFetchAll($data)
    {
        $labels = array();
        $courses = array();
        $vendors = array();
        foreach ($data as $dataSingle) {
            if ($dataSingle['primary_label_id']) {
                $labels[] = $dataSingle['primary_label_id'];
            }
            if ($dataSingle['label_id']) {
                $labels = array_merge($labels, explode(",", $dataSingle['label_id']));
            }
            if ($dataSingle['primary_course_id']) {
                $courses[] = $dataSingle['primary_course_id'];
            }
            if ($dataSingle['course_id']) {
                $courses = array_merge($courses, explode(",", $dataSingle['course_id']));
            }
            if ($dataSingle['vendor_id']) {
                $vendors[] = $dataSingle['vendor_id'];
            }
        }

        if ($labels) {
            $labelsMdl = new Model_Labels();
            $labels = $labelsMdl->getLabelByIds($labels);
        }
        if ($courses) {
            $courseMdl = new Model_Courses();
            $courses = $courseMdl->getCourseByIdMultiple($courses);
        }
        if ($vendors) {
            $vendorObj = new Model_Vendors();
            $vendors = $vendorObj->fetchForSelect(array('vendor_id IN (?)' => $vendors));
        }
        foreach ($data as &$dataSingle) {
            if ($dataSingle['primary_label_id']) {
                $dataSingle['primaryLabel'] = @$labels[$dataSingle['primary_label_id']];
            }
            if ($dataSingle['label_id']) {
                $label = explode(",", $dataSingle['label_id']);
                foreach ($label as $labelId) {
                    $dataSingle['labels'][] = @$labels[$labelId];
                }
                $dataSingle['labels'] = implode(",", $dataSingle['labels']);
            }
            if ($dataSingle['primary_course_id']) {
                $dataSingle['primaryCourse'] = @$courses[$dataSingle['primary_course_id']];
            }
            if ($dataSingle['course_id']) {
                $course = explode(",", $dataSingle['course_id']);
                foreach ($course as $courseId) {
                    $dataSingle['courses'][] = @$courses[$courseId];
                }
                $dataSingle['courses'] = implode(",", $dataSingle['courses']);
            }
            if ($dataSingle['vendor_id']) {
                $dataSingle['Vendor'] = @$vendors[$dataSingle['vendor_id']];
            }
            if ($dataSingle['payment_type_id'] == BaseApp_Dao_PaymentType::SUBSCRIPTION_PAYMENT_TYPE_ID) {
                $dataSingle['pricingType'] = 'Subscription';
            } else {
                $dataSingle['pricingType'] = 'Bundle';
            }
        }
        unset($labels);
        unset($courses);
        unset($vendors);
        return $data;
    }





    public function checkBundlePricings($bundleId)
    {
        $sql = $this->getDb()->select()
            ->from('bundles', array('bundles.bundle_id'))
            ->join('subscriptionPricing', 'subscriptionPricing.linkable_id=' . 'bundles.bundle_id', array())
            ->where('subscriptionPricing.linkable_type=?', 'bundle')
            ->where('bundles.bundle_id=?', $bundleId)
            ->where('bundles.status =?', 1)
            ->where('subscriptionPricing.status =?', 1)
            ->limit(1);
        $resultData = $this->getDb()->fetchAll($sql);
        if (empty($resultData)) {
            return false;
        } else {
            return true;
        }
    }

    public function checkMomPricings($masterId)
    {
        $sql = $this->getDb()->select()
            ->from('bundles', array('bundles.bundle_id'))
            ->join('subscriptionPricing', 'subscriptionPricing.linkable_id=' . 'bundles.bundle_id', array())
            ->where('subscriptionPricing.linkable_type=?', 'master_of_masters')
            ->where('bundles.bundle_id=?', $masterId)
            ->where('bundles.status =?', 1)
            ->where('subscriptionPricing.status =?', 1)
            ->limit(1);
        $resultData = $this->getDb()->fetchAll($sql);
        if (empty($resultData)) {
            return false;
        } else {
            return true;
        }
    }

    public function getBundlesByPricings($data = array())
    {
        $result = array();
        $sql = $this->getDb()->select()
            ->from('bundles', array('bundles.bundle_id', 'bundles.name'))
            ->join('subscriptionPricing', 'subscriptionPricing.linkable_id=' . 'bundles.bundle_id', array('free_trial'))
            ->where('subscriptionPricing.linkable_type=?', 'bundle')
            ->where('bundles.status =?', 1)
            ->where('bundles.hideFromSearch=?', '0')
            ->where('subscriptionPricing.status =?', 1);
        if (!empty($data['cluster_id']) && $data['cluster_id'] != '' && empty($data['country_id'])) {
            $sql = $sql->where('subscriptionPricing.cluster_id = ?', $data['cluster_id']);
        }
        if (!empty($data['country_id']) && $data['country_id'] != '') {
            $sql = $sql->where('subscriptionPricing.country_id = ?', $data['country_id']);
        }
        if (!empty($data['training_id']) && !is_array($data['training_id'])) {
            $sql = $sql->where('subscriptionPricing.training_id=?', $data['training_id']);
        } else if (!empty($data['training_id']) && is_array($data['training_id'])) {
            $sql = $sql->where('subscriptionPricing.training_id IN (?)', $data['training_id']);
        }
        $resultData = $this->getDb()->fetchAll($sql);
        if (!empty($resultData)) {
            foreach ($resultData as $key => $value) {
                if (!empty($data['free_trial']) && $value['free_trial'] == 1) {
                    $value['name'] .= '#1';
                }
                $result[$value['bundle_id']] = $value['name'];
            }
        }
        return $result;
    }

    public function isMasterProgram($bundleId)
    {
        $sql = $this->getDb()->select()
            ->from('bundles', array('bundles.bundle_id'))
            ->where('bundles.bundle_id=?', $bundleId)
            ->where('bundles.status =?', 1)
            ->where('bundles.partialView =?', 0)
            ->limit(1);
        $resultData = $this->getDb()->fetchAll($sql);
        if (empty($resultData)) {
            return false;
        } else {
            return true;
        }
    }

    public function masterProgramOrder()
    {
        $sql = $this->getDb()->select()
            ->from('bundles', array('masterProgramOrder'))
            ->where('bundles.status =?', 1)
            ->where('bundles.partialView =?', 0)
            ->order('masterProgramOrder desc')
            ->limit(1);
        $resultData = $this->getDb()->fetchAll($sql);
        if (!empty($resultData)) {
            $resultData = current($resultData);
        }
        if (!empty($resultData) && !empty($resultData['masterProgramOrder'])) {
            return $resultData['masterProgramOrder'];
        } else {
            return false;
        }
    }

    public function buildCdnPurgeData($bundleId, $action)
    {
        $returnArr = array();
        // $objSeo = new Model_Seo();
        // $seoUrl = current($objSeo->fetchAll(array('linkable_id =?'=>$bundleId,'linkable_type =?'=>'bundle'),array('columns'=>array('url'))));
        // if(!empty($seoUrl))
        //     array_push($returnArr,array('linkable_id'=>$bundleId,'linkable_type'=>'bundle','action'=>$action,'url'=>$seoUrl['url'],'created_at'=>time(),'updated_at'=>time()) );
        // $bundleData = new self($bundleId);
        // if(!empty($bundleData->primary_label_id)){
        //     $labelId = $bundleData->primary_label_id;
        //     $seoData = current($objSeo->fetchAll(array('linkable_id = ?'=>$labelId,'linkable_type =?'=>'label'),array('columns'=>array('url','linkable_id'))));
        //     if(!empty($seoData)){
        //         array_push($returnArr,array('linkable_id'=>$seoData['linkable_id'],'linkable_type'=>'label','action'=>$action,'url'=>$seoData['url'],'created_at'=>time(),'updated_at'=>time()) );
        //     }
        //     if(!empty($labelId)){
        //         $objLabel = new Model_Labels($labelId);
        //         if(!empty($objLabel->popularCourses)){
        //             if(strpos($objLabel->popularCourses, $courseId) !== false ){
        //                 array_push($returnArr,array('linkable_id'=>$courseId,'linkable_type'=>'course','action'=>$action,'url'=>PURGE_WEBSITE,'created_at'=>time(),'updated_at'=>time()) );
        //             }
        //         }
        //     }
        // }
        return $returnArr;
    } // end of function

    public function fetchProductDetails()
    {
        $returnArr = array();
        $bundleData = $this->fetchForSelect();
        foreach ($bundleData as $key => $value) {
            $returnArr[$key] = $value . ' ( ' . $key . ' ) ';
        }
        return $returnArr;
    }
    /**
     * Function To Get Bundle List By Category Id
     * @param int $labelIds
     * @return array
     */
    public function getBundleListByLabelId($labelIds = array(), $isb2bAndHideFormSearch)
    {
        $bundleData = array();
        if (!empty($labelIds) && is_array($labelIds)) {
            $orStr = '';
            foreach ($labelIds as $key => $value) {
                $orStr .= " or find_in_set ('" . $value . "',bundles.label_id)";
            }

            $sql = "SELECT
                       `bundles`.`bundle_id`, `bundles`.`display_name`,`bundles`.`course_id`,`bundles`.`partialView`
                    FROM
                        bundles
                    WHERE
                        (`bundles`.primary_label_id IN (" . implode(",", $labelIds) . ") $orStr)
                    AND (`bundles`.`status` = 1)";

            if ($isb2bAndHideFormSearch) {
                $sql .= " AND (
                    (`bundles`.`bundle_available_for` = 'b2b_only') OR 
                    (`bundles`.`bundle_available_for` = 'universal' AND `bundles`.`partialView`=0)
                )";
            } else {
                $sql .= " AND bundles.hideFromSearch = 0 AND bundles.partialView = 0";
            }
            $sql .= " ORDER BY `bundles`.`name` ASC";

            $db = $this->getDb();
            $stmt = $db->query($sql);
            $resultData = $stmt->fetchAll();


            // $sql = $this->getDb()->select()
            //         ->from('bundles', array('bundle_id', 'display_name', 'course_id', 'partialView'))
            //         ->where('FIND_IN_SET(?, bundles.label_id)>0',new Zend_Db_Expr(implode(', bundles.label_id)>0 OR FIND_IN_SET(',$labelIds)))
            //        // ->where('FIND_IN_SET(?, bundles.label_id)>0',implode("'", $labelIds))
            //         ->where('bundles.status =?', 1)
            //         ->where('bundles.hideFromSearch =?',0)
            //         ->where('bundles.partialView =?', 0)
            //         ->order('name ASC');

            // $resultData = $this->getDb()->fetchAll($sql);

            if (!empty($resultData)) {
                foreach ($resultData as $key => $row) {
                    $bundleData[] = $row;
                }
            }
        }
        return $bundleData;
    }


    public function getClusterId($placeId)
    {
        $returnId = array();
        $sql = "SELECT
            c.cluster_id FROM country c
            WHERE c.country_id = '" . $placeId . "' ";

        $db = $this->getDb();
        $stmt = $db->query($sql);
        $result = $stmt->fetchAll();
        if (!empty($result)) {
            $returnId = array_column($result, 'cluster_id');
        }
        return $returnId[0];
    }

    public function getBundleListByLabelsHavingB2cPrice($labels = array(), $isClusterOrCountry, $placeId, $isB2b) {
        $bundleData = array();
        if(!empty($labels) && is_array($labels)) {
            $orStr = '';
            foreach ($labels as $key => $value) {
                $orStr .= " or find_in_set ('" . $value . "',b.label_id)";
            }

            $sql = "SELECT Distinct 
            b.bundle_id, b.display_name,b.course_id,b.partialView
            FROM
            bundles b,subscriptionPricing p
            WHERE 
            b.bundle_id = p.linkable_id ";

            if($isClusterOrCountry == BaseApp_Dao_Country::TYPE_CLUSTER) {
                $sql .= " AND p.cluster_id = '" . $placeId . "'  ";
            }
                
            elseif($isClusterOrCountry == BaseApp_Dao_Country::TYPE_COUNTRY) {
                $clusterIdBasedOnCountryId = $this->getClusterId($placeId);
                $sql .= " AND  ( p.country_id = '" . $placeId . "'  
                OR  p.cluster_id = '" . $clusterIdBasedOnCountryId . "' )" ;
            }

            $sql .=" AND
                (b.primary_label_id IN (" . implode(",", $labels) . ") $orStr)
                AND (b.status = 1) AND (p.status = 1)
                AND (p.subscriptionPrice > 0) ";

            if ($isB2b) {
                $sql .= " AND (
                (b.bundle_available_for = 'b2b_only') OR 
                (b.bundle_available_for = 'universal' AND b.partialView = 0) 
                )";
            }
            else {
                $sql .= " AND b.hideFromSearch = 0 AND b.partialView = 0 ";
            }
            $sql .=" ORDER BY b.name ASC";
            $db = $this->getDb();
            $stmt = $db->query($sql);
            $resultData = $stmt->fetchAll();

            if (!empty($resultData)) {
                foreach ($resultData as $key => $row) {
                    $bundleData[] = $row;
                }
            }
        }
        return $bundleData;
    }

    public function fetchBundlesByLabelsBasedOnAgency($labels = array(), $agency) {
        $returnArr = array();
        $orStr = '';
        if (!empty($labels)) {
            foreach ($labels as $key => $value) {
                $orStr .= " or find_in_set ('" . $value . "',label_id)";
            }
        }

        if(!empty($agency)) {
            $cloud6_db = CLOUD6_DB;
            $ice9_db = MONGO_DB;
            $sql = " SELECT 
            b.bundle_id as linkable_id, b.display_name
            FROM
            ". $cloud6_db .".groups g 
            JOIN
            ". $cloud6_db .".enterprise_course_mapping ff ON g.gid = ff.group_id
            JOIN
            ". $ice9_db .".bundles b ON ff.entity_id = b.bundle_id
            JOIN
            ". $cloud6_db .".group_membership gm ON g.gid = gm.gid
            JOIN
            ". $cloud6_db .".group_membership_role gmr ON gm.mid = gmr.mid
            JOIN
            ". $cloud6_db .".users u ON gm.uid = u.uid
            JOIN
            ". $cloud6_db .".field_data_field_domain d ON g.gid = d.entity_id
            JOIN
            ". $cloud6_db .".field_data_field_agreement_expiry e ON g.gid = e.entity_id

            where (primary_label_id IN (" . implode(",", $labels) . ") $orStr) 
            AND g.title = '" . $agency . "'
            AND ff.entity_type = '" . BaseApp_Dao_EntityListing::ENTITY_TYPE_BUNDLE . "' AND 
            b.bundle_available_for IN ('private_b2b') AND ff.status = 1 AND b.status = 1
            GROUP BY g.gid,b.bundle_id";
        }

        else {
            $sql = "SELECT
            `bundles`.`bundle_id` as linkable_id, `bundles`.`display_name`
            FROM
            bundles
            WHERE
            (primary_label_id IN (" . implode(",", $labels) . ") $orStr) 
            AND (status=1)
            AND `bundles`.`bundle_available_for` IN ('b2b_only','universal') 
            ORDER BY bundles.display_name ASC";
        }

        $db = $this->getDb();
        $stmt = $db->query($sql);
        $result = $stmt->fetchAll();
        if (!empty($result)) {
            foreach ($result as $key => $row) {
                $returnArr[] = $row;
            }
        }
        return $returnArr;
    }

    public function getBundlesAgency($labels = array(), $agency)
    {
        $returnArr = array();
        $orStr = '';
        if (!empty($labels)) {
            foreach ($labels as $key => $value) {
                $orStr .= " or find_in_set ('" . $value . "',label_id)";
            }
        }
        if (empty($agency)) {
            return array();
        }
        $cloud6_db = CLOUD6_DB;
        $ice9_db = MONGO_DB;
        $sql = " SELECT 
            b.bundle_id , b.display_name,b.course_id,b.partialView
            FROM
            " . $cloud6_db . ".groups g 
            JOIN
            " . $cloud6_db . ".enterprise_course_mapping ff ON g.gid = ff.group_id
            JOIN
            " . $ice9_db . ".bundles b ON ff.entity_id = b.bundle_id
            JOIN
            " . $cloud6_db . ".group_membership gm ON g.gid = gm.gid
            JOIN
            " . $cloud6_db . ".group_membership_role gmr ON gm.mid = gmr.mid
            JOIN
            " . $cloud6_db . ".users u ON gm.uid = u.uid
            JOIN
            " . $cloud6_db . ".field_data_field_domain d ON g.gid = d.entity_id
            JOIN
            " . $cloud6_db . ".field_data_field_agreement_expiry e ON g.gid = e.entity_id

            where (primary_label_id IN (" . implode(",", $labels) . ") $orStr) 
            AND g.title = '" . $agency . "'
            AND ff.entity_type = '" . BaseApp_Dao_EntityListing::ENTITY_TYPE_BUNDLE . "' AND 
            b.bundle_available_for IN ('private_b2b') AND ff.status = 1 AND b.status = 1
            GROUP BY g.gid,b.bundle_id";
        $db = $this->getDb();
        $stmt = $db->query($sql);
        $result = $stmt->fetchAll();
        if (!empty($result)) {
            foreach ($result as $key => $row) {
                $returnArr[] = $row;
            }
        }
        return $returnArr;
    }

// get agency by bundle ids
    public function getAgencyByBundleIds($bundleIds = array())
    {
        $returnArr = array();
        if (empty($bundleIds)) {
            return array();
        }
        $cloud6_db = CLOUD6_DB;
        $ice9_db = MONGO_DB;
        $sql = " SELECT 
            b.bundle_id,g.gid
            FROM
            " . $cloud6_db . ".groups g 
            JOIN
            " . $cloud6_db . ".enterprise_course_mapping ff ON g.gid = ff.group_id
            JOIN
            " . $ice9_db . ".bundles b ON ff.entity_id = b.bundle_id
            JOIN
            " . $cloud6_db . ".group_membership gm ON g.gid = gm.gid
            JOIN
            " . $cloud6_db . ".group_membership_role gmr ON gm.mid = gmr.mid
            JOIN
            " . $cloud6_db . ".users u ON gm.uid = u.uid
            JOIN
            " . $cloud6_db . ".field_data_field_domain d ON g.gid = d.entity_id
            JOIN
            " . $cloud6_db . ".field_data_field_agreement_expiry e ON g.gid = e.entity_id

            where (bundle_id IN (" . implode(",", $bundleIds) . ")) 
            AND ff.entity_type = '" . BaseApp_Dao_EntityListing::ENTITY_TYPE_BUNDLE . "' AND 
            b.bundle_available_for IN ('private_b2b') AND ff.status = 1 AND b.status = 1
            GROUP BY g.gid,b.bundle_id";
        $db = $this->getDb();
        $stmt = $db->query($sql);
        $result = $stmt->fetchAll();
        if (!empty($result)) {
            foreach ($result as $key => $row) {
                $returnArr[] = $row;
            }
        }
        return $returnArr;
    }



    //-=============================================================================================


    public function fetchBundlesByLabelsBasedOnAgencyAjax($labels = array(), $agency) {
        $returnArr = array();
        $orStr = '';
        if (!empty($labels)) {
            foreach ($labels as $key => $value) {
                $orStr .= " or find_in_set ('" . $value . "',label_id)";
            }
        }

        if (!empty($agency)) {
            $cloud6_db = CLOUD6_DB;
            $ice9_db = MONGO_DB;
            $sqlPrivate = " SELECT 
           b.bundle_id as linkable_id, b.display_name
            FROM " . $cloud6_db . ".groups g 
            JOIN
            " . $cloud6_db . ".enterprise_course_mapping ff ON g.gid = ff.group_id
            JOIN
            " . $ice9_db . ".bundles b ON ff.entity_id = b.bundle_id
            JOIN
            " . $cloud6_db . ".group_membership gm ON g.gid = gm.gid
            JOIN
            " . $cloud6_db . ".group_membership_role gmr ON gm.mid = gmr.mid
            JOIN
            " . $cloud6_db . ".users u ON gm.uid = u.uid
            JOIN
            " . $cloud6_db . ".field_data_field_domain d ON g.gid = d.entity_id
            JOIN
            " . $cloud6_db . ".field_data_field_agreement_expiry e ON g.gid = e.entity_id
            where (primary_label_id IN (" . implode(",", $labels) . ") $orStr) 
            AND ff.entity_type = '" . BaseApp_Dao_EntityListing::ENTITY_TYPE_BUNDLE . "'
            AND b.bundle_available_for = 'private_b2b' AND g.title = '" . $agency . "'
            AND ff.status = 1 AND b.status = 1
            GROUP BY g.gid,b.bundle_id";
            
            $sqlPublic = "SELECT
            `bundles`.`bundle_id` as linkable_id, `bundles`.`display_name`
            FROM
            bundles
            WHERE
            (primary_label_id IN (" . implode(",", $labels) . ") $orStr) 
            AND (status=1)
            AND `bundles`.`bundle_available_for` IN ('b2b_only','universal') 
            ORDER BY bundles.display_name ASC";

            $db = $this->getDb();
            $stmtPrivate = $db->query($sqlPrivate);
            $resultPrivate = $stmtPrivate->fetchAll();
            if (!empty($resultPrivate)) {
                foreach ($resultPrivate as $key => $row) {
                    $returnArr[] = $row;
                }
            }
            $stmtPublic = $db->query($sqlPublic);
            $resultPublic = $stmtPublic->fetchAll();
            if (!empty($resultPublic)) {
                foreach ($resultPublic as $key => $row) {
                    $returnArr[] = $row;
                }
            }
        } else {
            $sql =  "SELECT
            `bundles`.`bundle_id` as linkable_id, `bundles`.`display_name`
            FROM
            bundles
            WHERE
            (primary_label_id IN (" . implode(",", $labels) . ") $orStr) 
            AND (status=1)
            AND `bundles`.`bundle_available_for` IN ('b2b_only','universal') 
            ORDER BY bundles.display_name ASC";
            $db = $this->getDb();
            $stmt = $db->query($sql);
            $result = $stmt->fetchAll();
            if (!empty($result)) {
                foreach ($result as $key => $row) {
                    $returnArr[] = $row;
                }
            }
        }
        
        return $returnArr;
    }



    //==============================================================================================
    
    
    public function getBundleListByLabelIdArr($labelIds=array()) {
        $bundleData = array();
        if (!empty($labelIds) && is_array($labelIds)) {
            $sql = $this->getDb()->select()
                ->from('bundles', array('bundle_id', 'display_name', 'course_id', 'partialView'))
                ->where('bundles.label_id IN (?)', $labelIds)
                ->where('bundles.status =?', 1)
                ->where('bundles.partialView =?', 0)
                ->order('name ASC');
            $resultData = $this->getDb()->fetchAll($sql);
            if (!empty($resultData)) {
                foreach ($resultData as $key => $row) {
                    $bundleData[] = $row;
                }
            }
        }
        return $bundleData;
    }

    /**
     * Method to fetch course data for SSP course catalog API
     * @param array $bundleIds
     * @return array
     */
    public function getBundleDataForSSP($bundleIds = array())
    {
        $result = array(
            'status' => 'failed',
            'msg' => 'Data not found',
            'data' => NULL
        );
        if (empty($bundleIds)) {
            return $result;
        }
        try {
            $db = $this->getDb();
            $bundleType = 'bundle';
            $activeStatus = '1';

            $bundleQuery = $db->select()->from('bundles AS b', array(
                'b.bundle_id',
                'b.description AS description',
                's.keyword AS keywords',
            ))
                ->joinLeft('seo AS s', 's.linkable_id = b.bundle_id', array())
                ->where('b.bundle_id IN (?)', $bundleIds)
                ->where('b.status = ?', $activeStatus)
                ->where('s.linkable_type IN (?)', $bundleType)
                ->where('s.status = ?', $activeStatus);
            $response = $db->fetchAll($bundleQuery);

            if (!empty($response) && is_array($response)) {
                $result['status'] = 'success';
                $result['msg'] = 'Ok';
                $result['data'] = $response;
            }
        } catch (Exception $ex) {
            $result['msg'] = 'Some error occurred while fetching data.';
        }
        return $result;
    }

    public function getAllBundles($bundle)
    {
        $bundles = array();
        if ($bundle == "ALL_BUNDLE") {
            $bundles = $this->fetchForSelect(array('status = ?' => 1));
        } else if ($bundle != "NONE") {
            if ($bundle == "BUNDLE_WITH_EXAM") {
                $cond = array('has_exam = ?' => 1, 'status = ?' => 1);
            } else if ($bundle == "BUNDLE_WITHOUT_EXAM") {
                $cond = array('has_exam != ?' => 1, 'status = ?' => 1);
            }
            $bundles = $this->fetchForSelect($cond);
        }
        return $bundles;
    }

    public function getbyLables($labelIds)
    {
        $labelIdsReal = array();
        foreach ($labelIds as $labelId) {
            if (!$labelId) {
                continue;
            }
            $labelIdsReal[] = $labelId;
        }
        if (!$labelIdsReal) {
            return array();
        }
        $objCourse = new self();
        $conds = array(
            'status = ?' => 1,
            'FIND_IN_SET(?, label_id)>0' => new Zend_Db_Expr(implode(', label_id)>0 OR FIND_IN_SET(', $labelIdsReal))
        );
        return $objCourse->fetchForSelect($conds);
    }
    public function getBundleById($bundleId)
    {
        $objbundle = new self();
        return current($objbundle->fetchAll(array('bundle_id = ?' => $bundleId), array(), false));
    }

    /**
     * fetch master programs
     */

    public function fetchMasterPrograms($labelId = "")
    {
        try {
            $sql = $this->getDb()->select()
                ->from('bundles', array('bundles.bundle_id', 'bundles.name'));

            if ($labelId > 0) {
                $sql =  $sql->where('bundles.primary_label_id=?', $labelId);
            }

            $sql =  $sql->where('bundles.status =?', 1);
            $sql .= " ORDER BY bundles.name ASC";
            $resultData = $this->getDb()->fetchAll($sql);
            $result = [];
            foreach ($resultData as $val) {
                $result[$val['bundle_id']] = $val['name'];
            }
            return $result;
        } catch (Exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }
    public function fetchPrimaryLabelIdByBundleId($bundleId)
    {
        $sql = $this->getDb()->select()
            ->from("bundles", ['bundles.bundle_id', 'bundles.primary_label_id'])
            ->join('labels', 'labels.label_id = bundles.primary_label_id AND labels.status = 1', ['labels.displayName as primary_label_name'])
            ->where('bundles.bundle_id = ?', $bundleId)
            ->where('bundles.status = ?', 1)
            ->limit(1);

        $bundleData = $this->getDb()->fetchRow($sql);
        return empty($bundleData) ? null : $bundleData;
    }

    public function getMasterTypeOfBundle($bundleId)
    {
        if (empty($bundleId)) {
            return array();
        }
        $sql = $this->getDb()->select()
            ->from("bundles", ['bundles.bundle_id', 'bundles.master_type', 'bundles.linkable_type'])
            ->where('bundles.status = ?', 1)
            ->where('bundles.bundle_id =?', $bundleId);
        //        prd($sql->__toString());
        $bundleType = $this->getDb()->fetchRow($sql);
        return $bundleType;
    }
} // End of Class
