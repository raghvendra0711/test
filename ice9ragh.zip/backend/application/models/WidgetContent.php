<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_WidgetContent extends BaseApp_Dao_WidgetContent {

    public function getSectionContent($id = "")
    {
        $data = array();
        if (!empty($id)) {
            $db             = $this->getDb();
            $queryStatement = $db
                ->select()
                ->from(array('mb' => $this->_name), '*')
                ->where('mb.status=?', 1);
            $queryStatement = $queryStatement->where('mb.widget_id=?', $id);
            $queryStatement = $queryStatement->order(array('mb.position asc'));
            $data = $db->fetchAll($queryStatement);           
                        
            foreach($data as $value){  
                $deeplink = $value['deep_link'] !=null ? (" | ".$value['deep_link']): '';                 
                $data['contentitems'][$value['id']] =  $value['title'] ."  |  ". $value['content_type'].$deeplink ."  |  ".$value['image_url'] ;
            }  

            $data['content_ids']  = array_unique(array_column($data, 'content_id'));
            $data['content_ids_sorted_list'] = implode(',', $data['content_ids']); 
            $data['sequence_ids']   = array_unique(array_column($data, 'id'));
            $data['sequence_ids_sorted_list']   = implode(',',$data['sequence_ids']); 
        }        
        return $data;
    }

    public function saveContent($new, $old, $widget_id, $position = null)
    {
        $db = $this->getDb();
        $db->beginTransaction();
        $objMobileBanner = new self();        
        try {           
            $oldIdArray = array_column($old, 'key');
            foreach ($new as $key => $val) {
                $index = $key+1;
                if (!in_array($val['content_key'], $oldIdArray)) {
                    $data = array();
                    $data['widget_id']     = $widget_id;
                    $data['content_type']   = $val['key'];
                    $data['content_id']     = !empty($val['value']) ? $val['value'] : null;
                    $data['title']          = !empty($val['title']) ? $val['title'] : null;
                    $data['deep_link']      = !empty($val['deep_link']) ? $val['deep_link'] : null;
                    $data['image_url']      = !empty($val['image_url']) ? $val['image_url'] : null;                                        
                    $data['position']       = $index;
                    $data['status']       = 1;
                    $objMobileBanner->clean();
                    $objMobileBanner->setFromArray($data)->save();
                } else {
                    $data =array();
                    $newPostion = array_search($new[$key]['content_key'], $oldIdArray);
                    $data['position'] = $index;
                    $objMobileBanner->setId($old[$newPostion]['id']);
                    $objMobileBanner->setFromArray($data)->update();
                }
            }
            foreach ($oldIdArray as $key => $val) {
                $newArrayIds = array_column($new, 'content_key');
                if (!in_array($val, $newArrayIds)) {
                    $objMobileBanner->clean();
                    if (!$objMobileBanner->delete($old[$key]['id'])) {
                        $db->rollBack();
                        return false;
                    }
                }
            }
            
            //end 
            $db->commit();
            return true;
        } catch (Exception $e) {            
            $db->rollBack();
            return false;
        }        
    }

    public function saveContentAdd($new, $old, $widget_id, $position = null)
    {       
        $db = $this->getDb();
        $db->beginTransaction();
        $objMobileBanner = new self();
        try {
            $oldIdArray = array_column($old, 'key');
            $count = count($oldIdArray)+1;            
            foreach ($new as $key => $val) {
                $index = $key + 1;
                if (!in_array($val['content_key'], $oldIdArray) || $val['content_key']=='deeplink_') {
                    $data = array();
                    $data['widget_id']     = $widget_id;
                    $data['content_type']   = $val['key'];
                    $data['content_id']     = !empty($val['value']) ? $val['value'] : null;
                    $data['title']          = !empty($val['title']) ? $val['title'] : null;
                    $data['deep_link']      = !empty($val['deep_link']) ? $val['deep_link'] : null;
                    $data['image_url']      = !empty($val['image_url']) ? $val['image_url'] : null;
                    $data['position']       = !empty($position)? $position : $count;
                    $objMobileBanner->clean();
                    $objMobileBanner->setFromArray($data)->save();
                    $count++;
                }
            }
            //end 
            $db->commit();
            return true;
        } catch (Exception $e) {
            $db->rollBack();
            return false;
        }
    }
    public function delete($sId)
    {
        $db = $this->getDb();
        $objMobileHomeSequence = new self();
        $updateVal = [];
        try {
            $updateVal['status'] = '0';
            $objMobileHomeSequence->setId($sId);
            $objMobileHomeSequence->setFromArray($updateVal)->update();
            return true;
        } catch (exception $e) {
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }
    public function updateImageUrl($imgUrl,$sId) {
        $db = $this->getDb();
        $db->beginTransaction();
        $objMobileHomeSequence = new self();
        $updateVal = [];
        try{        
            $updateVal['image_url'] = $imgUrl;
            $objMobileHomeSequence->setId($sId);
            $objMobileHomeSequence->setFromArray($updateVal)->update();
            $db->commit();
            return true;
        }catch(exception $e){
            $db->rollBack();            
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }            
    }

    public function updateBannerOrder($data) {
        $db = $this->getDb();
        $db->beginTransaction();
        $objMobileHomeSequence = new self();  

        try{
            $updateVal = []; 
            foreach($data as $seqId => $position){                               
                $updateVal['position']  = $position;            
                $objMobileHomeSequence->setId($seqId);
                $objMobileHomeSequence->setFromArray($updateVal)->update();                                              
            }
            $db->commit();
            return true;  
        }catch (Exception $e){
            $db->rollBack();            
            if (APPLICATION_ENV == 'development')
                throw $e;
           return false;
        }
    }
} // End of Class
