<?php

class Model_Cart extends BaseApp_Model_BaseCart
{
    public function createNewCartForToken($token, $data)
    {
        if (empty($token)) {
            throw new BaseApp_Exception('Cannot add to cart. Token is empty');
        }

        if (empty($data) || empty($data['items']) || !is_array($data['items'])) {
            throw new BaseApp_Exception('Cannot add to cart. Item id is empty');
        }

        $formattedData = $this->_prepareCartDetailsArrV1($token, $data);
        $cart_coll = $this->getCollectionV1();
        $cart_coll->insert($formattedData);

        return $formattedData;
    }

    protected function _prepareCartDetailsArrV1($token, array $data)
    {
        $cartDetails = array();
        $quantity = 1;
        $emails = explode(",", $data['learner_email']);
        if (is_array($emails)) {
            $quantity = count($emails);
        }

        $currencyObj = new BaseApp_Dao_Currency();
        $currencyData = $currencyObj->getCurrenyByCountry($data['country_id']);

        $countryDetail = (new Model_Country)->getCountryDetailsById([$data['country_id']]);
        $countryCode = '';
        if (!empty($countryDetail['code'])) {
            $countryCode = $countryDetail['code'];
        }

        $regNo = '';
        if (!empty($currencyData)) {
            if (!empty($currencyData)) {
                $regNo = $currencyData[0]['registrationNumber'];
            }
        }

        $state = !empty($data['region_name']) ? $data['region_name'] : '';

        $cartDetails["token"] = $token;
        $cartDetails["email"] = empty($data['billing_email']) ? '' : $data['billing_email'];
        $cartDetails["learner_emails"] = empty($data['learner_email']) ? [] : explode(",", trim($data['learner_email']));
        $cartDetails["isProcessed"] = 0;
        $cartDetails["couponApplied"] = '';
        $cartDetails["countryId"] = intval($data['country_id']);
        $cartDetails["free_trial"] = null;
        $cartDetails["state"] = $state;
        $cartDetails["state_orig"] = $state;
        $cartDetails["siteName"] = null;
        $cartDetails["addDateTime"] = strtotime("now");
        $cartDetails["lastUpdateDateTime"] = strtotime("now");

        foreach ($data['items'] as $item) {    
            if($item['training_type_id'] == Model_TrainingTypes::TYPE_CLASSROOM){
                $key = $item['product_id'] . '_' . $item['training_type_id'] . '_' . $item['workshop_id'];
            }else{
                $key = $item['product_id'] . '_' . $item['training_type_id'] . '_' . $item['access_days'];
            }
            
            if ($item['product_type_id'] == Model_Payments::TYPE_BUNDLE) {
                $key = "b{$key}";
            }
            if ($item['product_type_id'] == Model_Payments::TYPE_MOM) {
                $key = "m{$key}";
            }

            $discountPercentage = $item['discount_percentage'];
            $discountAmount = round(($item['mrp'] - $item['selling_price']), 2);
            $itemParamArray = array(
                "quantity" => $quantity, "pageSource" => "",
                "discountPercent" => $discountPercentage, "discountAmount" => 0,
//                 "price_id" => isset($item['price_id']) ? $item['price_id'] : 0];
                "price_id" => (!in_array($item['training_type_id'], Model_Payments::$_allow_price_training_type)) ? 0 : $item['price_id']
            );
            if($item['product_type_id'] == Model_Payments::TYPE_MOM){
                    $itemParamArray['price_id'] = "";
                }
            $cartDetails["items"][$key] = $itemParamArray;
        }
        
        $cartDetails["isMultiple"] = 0;
        if (count($data['items']) > 1) {
            $cartDetails["isMultiple"] = 1;
        }
        
        if (in_array($data['payment_sub_type_id'], Model_Payments::$_allow_atp_payment_type)) {
            $order_id_key = 'CSTM_ATP_';
        } else if ($data['payment_sub_type_id'] == BaseApp_Dao_Melvin_Order::PAYMENT_COURSE_UPGRADATION) {
            $order_id_key = 'CSTM_UPG_';
        } else if ($data['payment_sub_type_id'] == BaseApp_Dao_Melvin_Order::PAYMENT_COURSE_EXTENSION) {
            $order_id_key = 'CSTM_EXTN_';
        } elseif ($data['payment_sub_type_id'] == BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_PARTIAL) {
            $order_id_key = BaseApp_Model_BaseCart::PAYMENT_TYPE_PARTIAL_NAME;
        } elseif ($data['payment_sub_type_id'] == BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_PARTIAL_SUBSEQUENT) {
            $order_id_key = BaseApp_Model_BaseCart::PAYMENT_TYPE_PARTIAL_SUBSEQUENT_NAME;
        } else if ($data['payment_sub_type_id'] == BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_CORPORATE) {
            $order_id_key = 'CSTM_CORP_';
        } else if ($data['payment_sub_type_id'] == BaseApp_Dao_Melvin_Order::PAYMENT_COURSE_COMPLIMENTARY) {
            $order_id_key = 'CSTM_COMPL_';
        } else {
            $order_id_key = 'CSTM_';
        }

        $cartDetails["phone"] = empty($data['contact_number']) ? '' : $data['contact_number'];
        $cartDetails["personName"] = null;
        $cartDetails["mobileAppInvocation"] = null;
        $cartDetails["paymentType"] = self::PAYMENT_TYPE_NORMAL;
        $cartDetails["ipAddress"] = $data['ip_address'];
        $cartDetails["userAgent"] = null;
        $cartDetails["regNo"] = $regNo;
        $cartDetails["utm_source"] = '';
        $cartDetails["mbsy_short_code"] = '';
        $cartDetails["phnCountryCode"] = $countryCode;
        $cartDetails["city_id"] = $data['city_id'];
        $cartDetails["cdnCountryCode"] = '';
        $cartDetails["site_module"] = '';
        $cartDetails["orderId"] = strtoupper(BaseApp_Idgenerator::GENERATE($order_id_key));
        $cartDetails["isZestMoney"] = !empty($data['is_zest_money']) ? $data['is_zest_money'] : 0;
        $cartDetails["isAffirm"] = !empty($data['is_affirm']) ? $data['is_affirm'] : 0;
        $cartDetails["isBajajFinserv"] = !empty($data['is_bajaj_finserv']) ? $data['is_bajaj_finserv'] : 0;
        $cartDetails["isEduvanz"] = !empty($data['is_eduvanz']) ? $data['is_eduvanz'] : 0;
        $cartDetails["isLiquiloan"] = !empty($data['is_liquiloan']) ? $data['is_liquiloan'] : 0;
        if(!empty($data['order_type'])){
            $cartDetails["order_type"] = $data['order_type'];
        }
        return $cartDetails;
    }
}