<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_AccessDays extends BaseApp_Dao_AccessDays{	


    public function getAccessDays($trainingId){
        $onlineClassRoomPassDays = array();
        if($trainingId == BaseApp_Dao_TrainingTypes::TYPE_LVC || $trainingId == BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM) {
            $config = Zend_Registry::get('config');   
            $onlineClassRoomPassDays = $config->get('ONLINE_CLASSROOM_PASS_ACCESS_DAYS')->toArray();
        }
        $objTt = new Model_TrainingTypes($trainingId);
	$traingtypes =  $objTt->toArray();
	$type = $traingtypes['type'];
    	$returnData = array();
    	$trainingTypes = $this->fetchAll(array('type = ?'=> $type));
    	foreach ($trainingTypes as $key => $value) {
            if(in_array($value['noOfDays'], $onlineClassRoomPassDays)) {
                continue;
            }
    	    $returnData[$value['day_id']] = $value['noOfDays'];
    	}
    	return $returnData;
    }
    public function getAccessDaysById($trainingType=false, $skipOnlineClassroomPass = false,$excludeAccessDays=false){
        $config = Zend_Registry::get('config');               
        $onlineClassRoomPassDays = $config->get('ONLINE_CLASSROOM_PASS_ACCESS_DAYS')->toArray();
        $returnData = array();
        $conds = array();
        if($trainingType) {
            $conds = array(
                'type=?' => $trainingType
            );
        }
        foreach ($this->fetchAll($conds) as $key => $value) {
            if(!$skipOnlineClassroomPass && in_array($value['noOfDays'], $onlineClassRoomPassDays)) {
                continue;
            }
            if (!empty($excludeAccessDays)) {
                $excludedAccessDays = $config->get('EXCLUDE_ACCESS_DAYS_MASTER')->toArray();
                if (in_array($value['noOfDays'], $excludedAccessDays)) {
                    continue;
                }
            }
            $returnData[$value['day_id']] = $value['noOfDays'];
        }
        return $returnData;
    }    
    
    public function getAccessDaysByTrainingType($trainingType=false){
        if($trainingType != BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS_NAME) {
            return $this->getAccessDaysById($trainingType);
        }
        // LVC
        $config = Zend_Registry::get('config');               
        $onlineClassRoomPassDays = $config->get('LVC_BUNDLE_ACCESS_DAYS')->toArray();
        $accessDays = array();
        foreach($onlineClassRoomPassDays as $temp) {
            $accessDays[$temp] = $temp;
        }
        return $accessDays;
    }
    
    public function getByIdMultiple($accessIds) {
        $return = array();
        $objCourse = new self();        
        foreach ($objCourse->fetchAll(array('day_id IN (?)'=>$accessIds)) as $accessData) {
            $return[$accessData['course_id']] = $accessData['noOfDays'];
        }
    } 

    public function getLvcAccessDays(){
        $objTt = new Model_TrainingTypes(BaseApp_Dao_TrainingTypes::TYPE_ELEARNING);
        $traingtypes =  $objTt->toArray();
        $type = $traingtypes['type'];
        $returnData = array();
        $trainingTypes = $this->fetchAll(array('type = ?'=> $type),array('order' => array('noOfDays ASC')));
        foreach ($trainingTypes as $key => $value) {
               $returnData[$value['noOfDays']] = $value['noOfDays'];
        }
        return $returnData;
    }
        
} // End of Class