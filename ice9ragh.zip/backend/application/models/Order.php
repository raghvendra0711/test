<?php

class Model_Order extends BaseApp_Model_BaseOrder
{
    public function __construct()
    {
        $this->_db = new Model_Default();
        $this->_coll = $this->_db->{self::COLLECTION};
    }

    public function saveOrder(array $cartData)
    {
        $orderData = [];
        if (empty($cartData['paymentType'])) {
            $orderData['paymentType'] = self::PAYMENT_TYPE_NORMAL;
        }

        $orderDetails = $this->_coll->find(array("token" => $cartData['token'], 'orderNumber' => $cartData['orderId']), array('_id' => false))->toArray(0);
        if (is_array($orderDetails) || !empty($orderDetails)) {
            $rm = $this->_coll->remove(array("token" => $cartData['token'], 'orderNumber' => $cartData['orderId']));
            if ($rm != true && is_array($rm) && $rm['err'] != null) {
                throw new BaseApp_Exception('Error occurred while Deleting data. Mongo error : ' . $rm['err']);
            }
        }

        $orderData['isProcessed'] = 0;
        $orderData['addDateTime'] = strtotime("now");
        $orderData['lastUpdateDateTime'] = strtotime("now");
        $orderData['token'] = $cartData['token'];
        $orderData['email'] = $cartData['email'];
        $orderData['learner_emails'] = $cartData['learner_emails'];
        $orderData['isProcessed'] = $cartData['isProcessed'];
        $orderData['countryId'] = $cartData['countryId'];
        $orderData['state'] = $cartData['state'];
        $orderData['state_orig'] = $cartData['state_orig'];
        $orderData['siteName'] = $cartData['siteName'];
        $orderData['items'] = $cartData['items'];
        $orderData['phone'] = $cartData['phone'];
        $orderData['personName'] = $cartData['personName'];
        $orderData['paymentType'] = $cartData['paymentType'];
        $orderData['ipAddress'] = $cartData['ipAddress'];
        $orderData['userAgent'] = $cartData['userAgent'];
        $orderData['regNo'] = $cartData['regNo'];
        $orderData['utm_source'] = $cartData['utm_source'];
        $orderData['phnCountryCode'] = $cartData['phnCountryCode'];
        $orderData['city_id'] = $cartData['city_id'];
        $orderData['isMultiple'] = $cartData['isMultiple'];
        $orderData['cdnCountryCode'] = $cartData['cdnCountryCode'];
        $orderData['site_module'] = $cartData['site_module'];
        $orderData['serviceTax'] = $cartData['serviceTax'];
        $orderData['IP'] = $cartData['ipAddress'];
        $orderData['currency_id'] = $cartData['currency_id'];
        $orderData['currency'] = $cartData['currency'];
        $orderData['totalAmountRaw'] = number_format($cartData['totalAmount'], 2);
        $orderData['totalAmount'] = $cartData['totalAmount'];
        $orderData['netTotalRaw'] = number_format($cartData['netTotalRaw'], 2);
        $orderData['netTotal'] = $cartData['netTotalRaw'];
        $orderData['orderNumber'] = $orderData['orderId'] = $cartData['orderId'];
        $orderData['state_changed'] = "";
        $orderData['couponAmount'] = "";
        $orderData['__utmz'] = "";
        $orderData['simplilearn_custom'] = "";
        $orderData['referral_id'] = "";
        $orderData['logo'] = "";
        $orderData['addMoreCourses'] = "";
        $orderData['couponApplied'] = "";
        $orderData['free_trial'] = NULL;
        $orderData['mobileAppInvocation'] = "";
        if(!empty($cartData['order_type'])){
            $orderData['order_type'] = $cartData['order_type'];
        }

        $rv = $this->_coll->insert($orderData);
        if ($rv != true && is_array($rv) && $rv['err'] != null) {
            throw new BaseApp_Exception('Error occurred while inserting data. Mongo error : ' . $rv['err']);
        }

        return $orderData;
    }
}