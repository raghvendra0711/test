<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
    
class Model_PromoParams extends BaseApp_Dao_PromoParams{

    
    public function addPromoParams($data){
        try{
            if(!array_key_exists('pass_id', $data))
                $data['pass_id'] = 1;
            $this->setFromArray($data)->save();            
            return $this->promo_id;
        }
        catch (Exception $e){
            return false;
        }
    }

    public function UpdatePromoParams($data,$Id){
        try{
            $this->setId($Id);
            $this->setFromArray($data)->update();
            return true;
        }
        catch (Exception $e){
            return false;
        }
    }

} // End of Class