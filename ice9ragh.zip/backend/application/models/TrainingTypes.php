<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_TrainingTypes extends BaseApp_Dao_TrainingTypes{	
    
    const TYPE_NAME_OSL = 'osl';
    
    const TYPE_NAME_ILT = 'ilt';
    
    public static $TYPE_IDS = array(
        self::TYPE_NAME_OSL => 2,
        self::TYPE_NAME_ILT => 1
    );
    
    
    public function loadAll($trainingTypes = array()) {
        $returnData = array();           
        foreach($this->fetchAll() as $indexTemp => $dataReal) {
            $returnData[$dataReal['training_id']] = $dataReal;
        }
        return $returnData;
    }
    
    public function loadById($trainingIds = array()) {
        return $this->fetchAll(array('training_id IN (?)'=>$trainingIds));
    }

    public function getMainTrainingTypes(){
    	 $returnData = array();
    	 $trainingTypes = $this->fetchAll(array('isMain = ?'=> 1));
    	 foreach ($trainingTypes as $key => $value) {
            $returnData[$value['type']] = $value['name'];
    	 }
    	 return $returnData;
    }

    public function getTrainingTypes(){
    	 $returnData = array();
    	 $trainingTypes = $this->fetchAll();
    	 foreach ($trainingTypes as $key => $value) {
            $returnData[$value['training_id']] = $value['name'];
    	 }
    	 return $returnData;
    }
    
    public function getInclusionTrainingTypes(){
    	 $returnData[] = 'Generic';
    	 $trainingTypes = $this->fetchAll();
    	 foreach ($trainingTypes as $key => $value) {
            $returnData[$value['training_id']] = $value['name'];
    	 }
         return $returnData;
    }
    
    public function getTrainingId($nameArr){
         $returnData = array();
         $trainingTypes = $this->fetchAll(array('name in (?)' => $nameArr),array('columns'=>array('training_id')));
         foreach ($trainingTypes as $key => $value) {
            array_push($returnData,$value['training_id']);
         }
         return $returnData;   
    }

} // End of Class
