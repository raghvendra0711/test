<?php

class Model_Utility
{ 
    protected $_db;
    
    public function __construct(){
        $this->_db =  Zend_Db_Table::getDefaultAdapter();        
    }    
    
    /**
     * To fetch all DB tables
     * @param type $db_name
     * @return type array
     */
    public function getDbTables($db_name){
        $sql = "SHOW TABLES FROM ".$db_name.""; 
        $res = $this->_db->query($sql);      
        $result = $res->fetchAll();
        $colName = 'Tables_in_'.$db_name;
        $tableName = array_column($result,$colName);
        $tableArray = array_combine($tableName, $tableName);
        return $tableArray;
    }    
}
