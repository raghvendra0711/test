<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Model_Payments extends BaseApp_Dao_Payments {


    private $_messages = array(BaseApp_Dao_ProductTypes::TYPE_ID_COURSE => array(BaseApp_Dao_TrainingTypes::TYPE_ELEARNING => 'freetrial_osl_desc', BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS => 'freetrial_lvc_desc'), BaseApp_Dao_ProductTypes::TYPE_ID_BUNDLE => array(BaseApp_Dao_TrainingTypes::TYPE_ELEARNING => 'freetrial_mp_osl_desc', BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS => 'freetrial_mp_lvc_desc'));
    protected $_allow_file_formats = array('jpg', 'jpeg', 'png', 'gif', 'pdf');
    protected $_allow_mime_formats = array('application/pdf', 'image/jpeg', 'image/jpg', 'image/gif', 'image/png');

    CONST MAX_FILE_SIZE = 2000000;

    const TYPE_COURSE = 1;
    const TYPE_MOM = 5;
    const TYPE_BUNDLE = 2;
    const TYPE_PASS = 3;
    const TYPE_LVC = 3;
    const TYPE_CLASSROOM = 1;
    const TYPE_OSL = 2;
    const TYPE_WEBINAR = 5;
    const TYPE_SINGLE_COURSE_LVC_PASS = 9;
    const LVC_PASS_COURSE_ID = 503;
    const SSVC_DATABASE = 'ssvc';
    const ONE_TIME_BILLING_TYPE = 1;
    const BACKEND_MESSAGE = '<p>Thank you for considering our certification training. Please make payment to enroll for the course(s)</p>';
    const CUSTOM_MESSAGE = '<p>Thank you for considering our certification training. To enroll for the course and make the payment, click the link below:</p><p style=""><a href="{url}" style="font-weight:bold;font-size:16px;text-align:center;"><img src="https://static.simplilearn.com/email_templates/template_banners/paynow_btn.jpg" style="font-weight:bold;font-size:16px;text-align:center;display:block;" border="0" alt="Pay Now" width="75" height="27"/></a></p>';
    const TAX_ROW = '<tr><td style="text-align:right; padding:10px;border-bottom:#dadada solid 1px;border-right:#dadada solid 1px;" colspan="2">{tax_str}:</td><td style="text-align:right; padding:10px;border-bottom:#dadada solid 1px;border-right:#dadada solid 1px;" colspan="2">{currency} {tax}</td></tr>';
    const APPROVAL_TAX_ROW = '<tr><td style="text-align:right; padding:10px;border-right:#dadada solid 1px;font-weight: strong;" colspan="4">{tax_str}:</td><td style="text-align:right; padding:10px;border-bottom:#dadada solid 1px;border-right:#dadada solid 1px;" colspan="2">{currency} {tax}</td></tr>';
    const APPROVAL_MESSAGE = '<p>{user_email} has requested you to approve this order. Please approve/reject this order.</p>';
    const DISCOUNT_APPROVED_MESSAGE = '<p>Your request for the Order No <b>{order_no}</b> has been <b>approved</b>. Mail with payment link has been sent to the customer.</p>';
    const DISCOUNT_REJECTED_MESSAGE = '<p>Your request for the Order No <b>{order_no}</b> has been <b>rejected</b>. Please reach out to your reporting manager to discuss rejection reasons.</p>';
    const APPROVE_REJECT_BUTTON ='<p align="center"><a href="{reject_url}"><button style="background-color:#ffffff;color:#118aef;border-radius: 2px;width: 220px;height:42px;border: solid 1px #118aef;">Reject Order</button></a>&nbsp;&nbsp;<a href="{approve_url}"><button style="background-color:#118aef;color:#ffffff;border-radius:2px;width:220px;height:42px;border:0;">Approve Order</button></a></p>';
    const ADVANCE_AMOUNT_ROW = '<tr><td style="text-align:right; padding:10px;border-bottom:0;border-right:#dadada solid 1px;" colspan="4">{adv_amt_str}:</td><td style="text-align:right; padding:10px;border-bottom:0;border-right:#dadada solid 1px;" colspan="2">{currency} {advance_amt}</td></tr>';
    const BALANCE_LEFT_ROW = '<tr><td style="text-align:right; padding:10px;border-bottom:#dadada solid 1px;border-right:#dadada solid 1px;font-weight: normal;" colspan="4">{balance_amt_str}</td><td style="text-align:right; padding:10px;border-bottom:#dadada solid 1px;border-right:#dadada solid 1px;" colspan="2">{currency} {balance_amt}</td></tr>';
    const PREV_COURSE_UPGRADE_DETAIL = '<p style="padding-top: 32px;">Previous course details:</p>
                                            <table width="100%" border="0" cellpadding="0" cellspacing="0" style="font-family:arial;font-size:13px;background:#ffffff;font-weight:bold;border:#dadada solid 1px;color:#535c61;padding:10px;">
                                            <tr>
                                                <td style="padding: 16px 20px 0 20px;color: #81868A;border-right:#dadada solid 1px;width:50%">Course name:<p style="color: #222222;">{prev_course_name}</p></td>
                                                <td style="padding: 16px 20px 0 20px;color: #81868A;border-right:#dadada solid 1px;">Purchase date:<p style="color: #222222;">{prev_paymentDate}</p></td>
                                                <td style="padding: 16px 20px 0 20px;color: #81868A;">Amount Paid:<p style="color: #222222;">{prev_currency} {prev_amount}</p></td>
                                            </tr>
                                            </table>
                                        <p style="padding-top: 32px;">Upgrade course details:</p>';

    CONST SIMPLEX_PAYMENT = 101;
    CONST SIMPLEX_PAYMENT_APPROVE = 102;
    CONST SELLING_MODE_PAID = 1;
    CONST SELLING_MODE_FREE = 2;

    public $_paymentMdl;

    public static $_roles = array(//do not change the order of the array elements decleration
        parent::B2C_SALES_DIRECTOR => 'AD',
        parent::B2C_SALES_BUSINESS_MANAGER => 'BM',
        parent::B2C_INSIDE_SALES_MANAGER => 'ISM'
    );

    private $_paymentSubTypes = array(
        BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_REGULAR => "Regular Payment",
//        BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_ATP_ADVANCE => "Reseller Regular Payment",
//        BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_ATP_ACCOUNT_OPENING => "Reseller Account Opening Payment",
        BaseApp_Dao_Melvin_Order::PAYMENT_COURSE_UPGRADATION => "Course Upgrade",
        BaseApp_Dao_Melvin_Order::PAYMENT_COURSE_EXTENSION => "Course Extension",
        BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_CORPORATE => "Corporate Payment",
        BaseApp_Dao_Melvin_Order::PAYMENT_COURSE_COMPLIMENTARY => "Complimentary Payment",
        BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_PARTIAL => "Partial Payment",
        BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_PARTIAL_SUBSEQUENT => "Partial Subsequent Payment",
    );

    private $_errorMsg = array(
        'type' => 'Payment type should not empty',
        'billing_email' => 'Billing email should not empty',
        'contact_number' => 'Contact number should not empty',
        'country_id' => 'Country should not empty',
        'country_name' => 'Country should not empty',
        'city_id' => 'City should not empty',
        'city_name' => 'City should not empty',
        'created_by' => '',
        'total_price' => 'Payment amount should not be Zero. Please add at least one paid course.'
    );

    public static $_allow_price_training_type = array(BaseApp_Dao_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS, self::TYPE_PASS);
    public static $_allow_atp_payment_type = array(BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_ATP_ADVANCE, BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_ATP_ACCOUNT_OPENING);
    //as per tiket https://simplilearn.atlassian.net/browse/SLUB-18771.
    public static $_removedCoursesException = REMOVED_COURSES_EXCEPTION;
    public static $_removedBundlesException = REMOVED_BUNDLES_EXCEPTION;
    public static $_removedClassRoomCourses = REMOVED_CLASSROOM_EXCEPTION;

    static public function isValidType($type) {
        return in_array($type, [self::TYPE_BACKEND, self::TYPE_CUSTOM]);
    }



    public function savePayment(array $data) {
        $orderNo = '';
        foreach (['type', 'billing_email', 'contact_number', 'country_id', 'country_name', 'city_id', 'city_name', 'created_by', 'user_email', 
           // 'total_price',
            'payment_sub_type_id', 'payment_sub_type'] as $field) {
            if (empty($data[$field])) {
                return array('status' => false, 'msg' => isset($this->_errorMsg[$field]) ? $this->_errorMsg[$field] : "{$field} is empty.");
            }
        }
        if($data['payment_sub_type_id']== BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_ATP_ADVANCE){
            if(empty($data['affiliate_id'])){
                return array('status' => false, 'msg' => "affiliate_id is empty.");
            }
        }

        if ($data['type'] == self::TYPE_BACKEND) {
            foreach (['country_id', 'country_name', 'city_id', 'city_name'] as $field) {
                if (empty($data[$field])) {
                    return array('status' => false, 'msg' => "{$field} is mandatory for backend payments.");
                }
            }
        }
        if ($data['approval_required'] == 1 || ($data['payment_sub_type_id'] == BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_PARTIAL && !(BaseApp_Payments_Payments::checkLoggedInUserRoleIsAD()))) {
            $data['is_approved'] = BaseApp_Datatable_Payments::PAYMENT_DISCOUNT_APPROVE_REQUESTED;
        }

        $items = $data['items'];
        unset($data['items']);
        $data['created_at'] = time();
        $data['ssvc_auth_key'] = SSVC_PROVIDER_KEY;
        $data['status'] = 0;
        if ($data['type'] == self::TYPE_BACKEND) {
            $data['status'] = 1;
        }

        /** @var Zend_Db_Adapter_Abstract $db */
        $db = $this->getDb();
        $db->beginTransaction();
        try {
            $partialItemsSP = array();
            if ($data['payment_sub_type_id'] == BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_PARTIAL || $data['payment_sub_type_id'] == BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_PARTIAL_SUBSEQUENT) {
                self::$_overallPercentage = $this->overallPercentageAfterPartialPayment($data['total_price_partial'], $data['advance_amount']);
                foreach ($items as $key => $itemValue) {
                    $sellingPrice = $itemValue['selling_price'];
                    $items[$key]['amount_paid'] = 0;
                    if ($sellingPrice > 0) {
                        $items[$key]['amount_paid'] = round($this->paymentDistributionCalculation($sellingPrice, self::$_overallPercentage), 2);
                        $partialItemsSP[$itemValue['product_id']]['partial_selling_price'] = $items[$key]['amount_paid'];
                    } else {
                      $partialItemsSP[$itemValue['product_id']]['partial_selling_price'] = 0;
                    }
                }
                $advanceAmount = $data['advance_amount'];
                unset($data['advance_amount']);
                unset($data['total_price_partial']);
            }
            $status = $db->insert($this->_name, $data);
            $paymentId = $db->lastInsertId();
            Model_Payments::log(array("ACTION" => "SAVE-IN-PAYMENTS", "REQUEST_PARAMS" => $data, "RESPONSE" => $status, "TRACE" => array('METHOD' => __METHOD__, 'LINE' => __LINE__)));
            //Unset as this column is not present in payment_items table
            if (isset($data['contract_number'])) {
                $contractNumber = $data['contract_number'];
                unset($data['contract_number']);
            }

            // Insert Payment Items
            $this->savePaymentItems($db, $paymentId, $items);
            //contract_number needed for melv1n orders entry
            if ($data['payment_sub_type_id'] == BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_PARTIAL || $data['payment_sub_type_id'] == BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_PARTIAL_SUBSEQUENT) {
                $data['contract_number'] = $contractNumber;
            }

            // Create backend order
            if ($data['type'] == self::TYPE_BACKEND) {
                $orderStatus = $this->createBackendOrder(array_merge($data, ['partialItemsSP' => $partialItemsSP]), $items);
                if (!empty($orderStatus['status']) && $orderStatus['status'] == true && !empty($orderStatus['data']['orderNo'])) {
                    $this->updateOrderNoInPayment($db, $paymentId, $orderStatus['data']['orderNo']);
                    $orderNo = $orderStatus['data']['orderNo'];
                } else {
                    $db->rollBack();
                    return array('status' => false, 'msg' => !empty($orderStatus['msg']) ? $orderStatus['msg'] : "Unable to create order");
                }
            }
            $db->commit();
        } catch (Exception $e) {
            $db->rollBack();
            return array('status' => false, 'msg' => $e->getMessage());
        }

        $data['payment_id'] = $paymentId;
        return array('status' => true, 'msg' => "Payment data received successfully.", 'data' => $data, 'paymentId' => $paymentId, 'orderNo' => $orderNo, 'partialItemsSP' => $partialItemsSP);
    }

    private function updateOrderNoInPayment($db, $paymentId, $orderNo) {
        $return = false;
        if (!empty($orderNo)) {
            $return = $db->update($this->_name, array('order_number' => $orderNo), "payment_id = $paymentId");
        }
        return $return;
    }

    /**
     * @param Zend_Db_Adapter_Abstract $db ,
     * @param int $paymentId
     * @param array $data
     *
     * @return void
     * @throws Exception
     */
    private function savePaymentItems($db, $paymentId, array $data) {
        if (empty($paymentId)) {
            Model_Payments::log(array('key' => 'CUSTOM_PAYMENT_ERROR', 'msg' => 'payment_id is empty.',
                'data' => !empty($data) ? json_encode($data) : '',
                'trace' => array('METHOD' => __METHOD__, 'LINE' => __LINE__)));
            throw new Exception('payment_id is empty.');
        }

        // Validating and preparing payment items
        foreach ($data as &$item) {
            foreach (['product_type_id', 'product_type_name', 'product_id', 'product_name', 'training_type_id', 'training_type_name', 'access_days',
        'mrp', 'selling_price', 'elearning_ids'] as $field) {
                if (empty($item[$field])) {
                    Model_Payments::log(array('key' => 'CUSTOM_PAYMENT_ERROR', 'msg' => $field . ' is empty.',
                        'data' => !empty($data) ? json_encode($data) : '',
                        'trace' => array('METHOD' => __METHOD__, 'LINE' => __LINE__)));
                    throw new Exception("{$field} is empty.");
                }
            }
        if (!in_array($item['training_type_id'], self::$_allow_price_training_type)) {
                $item['price_id'] = 0;
            }
            $item['discount_percentage'] = empty($item['discount_percentage']) ? 0 : floatval($item['discount_percentage']);
            $item['payment_id'] = $paymentId;
            $item['workshop_id'] = $item['workshop_id'];
            $item['workshop_dates'] = isset($item['workshop_dates']) ? $item['workshop_dates'] : '';
            /**
             * for free type courses, selling_mode value is 2
             * for paid type courses, selling_mode value is 1
             */
            $item['selling_mode'] = isset($item['selling_mode']) && $item['selling_mode'] == 'paid' ? self::SELLING_MODE_PAID : self::SELLING_MODE_FREE;
        }
        // Saving payment items
        foreach ($data as &$item) {
            $db->insert(Model_PaymentItems::getTableName(), $item);
        }
    }

    public function sendCustomPaymentMail($email, $paymentId) {
        $properties = [];

        $paymentData = current($this->fetchAll(array('payment_id = ? ' => $paymentId)));
        if (empty($paymentData)) {
            return false;
        }

        $paymentItems = Model_PaymentItems::getOnPaymentId($paymentData['payment_id']);

        if (empty($paymentItems)) {
            return false;
        }
        $taxProperty = json_decode($paymentData['tax_properties'], true);
        $currency = !empty($taxProperty['code']) ? $taxProperty['code'] : 'N/A';
        $price = 0;
        foreach ($paymentItems as $index => $paymentItem) {
            //partial/subsequent payment distribution in email invoice
            if ($paymentData['payment_sub_type_id'] == BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_PARTIAL || $paymentData['payment_sub_type_id'] == BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_PARTIAL_SUBSEQUENT) {
                $paymentItem['selling_price'] = (!empty($paymentItem['amount_paid'])) ? $paymentItem['amount_paid'] : 0;
            } 
            $price += $paymentItem['selling_price'];
            $paymentItems[$index]['selling_price'] = number_format($paymentItem['selling_price'], 2);
            $paymentItems[$index]['currency'] = $currency;
            if ($paymentItems[$index]['product_type_name'] == 'Course' && $paymentItems[$index]['training_type_id'] == 2) {
                $paymentItems[$index]['access_days'] = '<span style="color: #8f9498;">Self Learning: <span style="color: #535c61; font-weight:500;">Lifetime</span></span>';
            } elseif ($paymentItems[$index]['product_type_name'] == 'Course' && $paymentItems[$index]['training_type_id'] == 9) {
                $accessDays = '<b style="color: #535c61; font-weight:500;">'.$paymentItems[$index]['access_days'].' Days</b>';
                $paymentItems[$index]['access_days'] = '<span style="color: #8f9498;display:block;">Live Online Classes: ' . $accessDays . '</span><br /><span style="color: #8f9498;">Self Learning: <span style="color: #535c61; font-weight:500;">Lifetime</span></span>';
            }
        }
        $message = $this->getMessageContent($paymentData['type'], $paymentData['auth_token']);
        $taxAmt = $this->getTax($paymentData['total_price'], $paymentData['tax_percentage']);

        $bankDetails = [];
        if ($paymentData['type'] == 'backend') {
            $bankDetails = $this->getBankDetails($paymentData);
        }

        $taxStr = '';
        if ($taxProperty['totalTax'] > 0) {
            $taxStr = 'Tax ' . number_format($taxProperty['totalTax'], 2) . '% (';
            foreach ($taxProperty['tax'] as $key => $val) {
                $taxStr .= $key . '+';
            }
            $taxStr = rtrim($taxStr, '+');
            $taxStr .= ')';
            $taxStr = $this->getTaxRow($taxStr, $currency, $taxAmt);
        }
        $learnerEmail = explode(',', rtrim($paymentData['learner_email'], ','));
        $learnerEmail = array_unique($learnerEmail);
        $learnerCount = count($learnerEmail);
        $properties['items'] = $paymentItems;
        $properties['price'] = number_format($price, 2);
        $properties['quantity'] = $learnerCount;
        $properties['currency'] = $currency ;
        $properties['total'] = number_format($price, 2);
        $properties['message'] = $message;
        $properties['tax_row'] = $taxStr;
        $properties['learner_total'] = number_format($paymentData['total_price'], 2);
        $properties['learner_count'] = $learnerCount;
        $properties['net_total'] = number_format($paymentData['total_price'] + $taxAmt, 2);
        $template = BaseApp_Mailer::TEMPLATE_CUSTOM_PAYMENT_LINK_ONLINE;
        $view = new Zend_View();
        $view->setScriptPath(APPLICATION_PATH . '/views/scripts/common');
        $view->emails = $learnerEmail;
        $properties['emails'] = $view->render('customPaymentEmails.phtml');

        $view->bank_details = $bankDetails;
        $properties['bank_details'] = $view->render('smpl-account-details.phtml');

        $properties['support_string'] = EMAIL_QUERY_TEXT;
        try {
            $Identity = Zend_Auth::getInstance()->getIdentity();
            $mailer = new BaseApp_Mailer();
            $mailer->setTemplate($template);
            $mailer->addTo($email);
            if (!empty($paymentData['user_email'])) {
                $mailer->addBcc($paymentData['user_email']);
            }
            $mailer->setVariables($properties);
            $mailer->setSubject('Simplilearn Order Payment URL');

            $opts = Zend_Registry::get('config')->get('resources')->get('mail')->get('transport')->toArray();
            $mailer->setDefaultTransport(new Zend_Mail_Transport_Smtp($opts['host'], $opts));
            $mailer->send();
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    public function sendApprovePaymentMail($email, $paymentId, $status ='') {
        $properties = [];

        $paymentData = current($this->fetchAll(array('payment_id = ? ' => $paymentId)));
        if (empty($paymentData)) {
            return false;
        }

        if ($paymentData['payment_sub_type_id'] == BaseApp_Dao_Melvin_Order::PAYMENT_COURSE_UPGRADATION) {
            if (empty($paymentData['previous_reconciliation_id'])) {
                return false;
            }
            $xenia = new BaseApp_Communication_Xenia();
            $prevReconcileData = $xenia->getDataByPrevReconcileId($paymentData['previous_reconciliation_id']);
            if (empty($prevReconcileData)) {
                return false;
            }
        }

        $paymentItems = Model_PaymentItems::getOnPaymentId($paymentData['payment_id']);
        if (empty($paymentItems)) {
            return false;
        }

        $taxProperty = json_decode($paymentData['tax_properties'], true);
        $currency = !empty($taxProperty['code']) ? $taxProperty['code'] : 'N/A';
        $price = 0;
        foreach ($paymentItems as $index => $paymentItem) {
            $price += $paymentItem['selling_price'];
            $paymentItems[$index]['selling_price'] = number_format($paymentItem['selling_price'], 2);
            $paymentItems[$index]['currency'] = $currency;
            $paymentItems[$index]['allowed_discount']= $paymentItem['allowed_discount'];
            $paymentItems[$index]['discount_percentage'] = $paymentItem['discount_percentage'];
//            $paymentItems[$index]['discount_percentage_color'] = ($paymentItem['discount_percentage']==0)?'#ffffff':(($paymentItem['allowed_discount']>=$paymentItem['discount_percentage'])?'#f0f0f0':'#d9dadc');
            $paymentItems[$index]['discount_percentage_color'] = ($paymentItem['allowed_discount']>=$paymentItem['discount_percentage'])?'#ffffff':'#d9dadc';
        }

        if ($status == '') {
            $subject = 'Order Approval Request to ' . $paymentData['discount_approval_role']. ' Order no:' . $paymentData['order_number'];
            $message = self::APPROVAL_MESSAGE;
            $message = str_replace('{user_email}', $paymentData['user_email'], $message);
        } elseif ($status == 'approve') {
            $subject = 'Order Approved by ' . $paymentData['discount_approval_role'] . ' Order no:' . $paymentData['order_number'];
            $message = self::DISCOUNT_APPROVED_MESSAGE;
            $message = str_replace('{order_no}', $paymentData['order_number'], $message);
        } elseif ($status == 'reject') {
            $subject = 'Order Rejected by ' . $paymentData['discount_approval_role'] . ' Order no:' . $paymentData['order_number'];
            $message = self::DISCOUNT_REJECTED_MESSAGE;
            $message = str_replace('{order_no}', $paymentData['order_number'], $message);
        }

        $taxAmt = $this->getTax($paymentData['total_price'], $paymentData['tax_percentage']);
        $learnerEmail = explode(',', rtrim($paymentData['learner_email'], ','));
        $learnerEmail = array_unique($learnerEmail);
        $learnerCount = count($learnerEmail);

        $netTotalText = 'Net Total:';
        $taxStr = $advanceAmtStr = $balanceAmountStr = '';
        $netTotalGradientColor = '#ffffff';

        if ($paymentData['payment_sub_type_id'] == BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_PARTIAL) {
            $amtStr = 'Advance Amount';
            $netTotalText = 'Current Payment Amount:';
            $advanceAmtStr = $this->getAdvanceAmountRow($amtStr,$currency, number_format($paymentData['total_price'], 2));
            $amtStr = '<strong> Balance Amount:</strong>';
            if ($taxProperty['totalTax'] > 0) {
                $amtStr = '<strong> Balance Amount (Excluding Tax):</strong>';
            }
            $amountLeft = number_format($price * $learnerCount - $paymentData['total_price'], 2);
            $balanceAmountStr = $this->getBalanceLeftRow($amtStr, $currency, $amountLeft);
            $netTotalGradientColor = '#d9dadc';
        }


        if ($taxProperty['totalTax'] > 0) {
            $taxStr = 'Tax ' . number_format($taxProperty['totalTax'], 2) . '% (';
            foreach ($taxProperty['tax'] as $key => $val) {
                $taxStr .= $key . '+';
            }
            $taxStr = rtrim($taxStr, '+');
            $taxStr .= ')';
            $taxStr = $this->getApprovalTaxRow($taxStr, $currency, number_format($taxAmt, 2));
        }

        $prevReoncileDetailRow = '';
        if (!empty($prevReconcileData)) {
            $prevReoncileDetailRow = $this->getPrevReconcileDetail($prevReconcileData);
        }

        $properties['billing_email'] = $paymentData['billing_email'];
        $properties['payment_sub_type'] = $paymentData['payment_sub_type'];
        $properties['items'] = $paymentItems;
        $properties['price'] = number_format($price, 2);
        $properties['quantity'] = $learnerCount;
        $properties['currency'] = $currency ;
        $properties['total'] = number_format($price, 2);
        $properties['message'] = $message;
        $properties['tax_row'] = $taxStr;
        $properties['learner_total'] = number_format($price * $learnerCount, 2);
        $properties['learner_count'] = $learnerCount;
        $properties['net_total'] = number_format($paymentData['total_price'] + $taxAmt, 2);
        $properties['approve_reject_button'] = '';
        $properties['net_total_text'] = $netTotalText;
        $properties['advance_amount'] = $advanceAmtStr;
        $properties['balance_left_amount'] = $balanceAmountStr;
        $properties['net_total_background_clr'] = $netTotalGradientColor;
        $properties['previous_reconcile_detail_row'] = $prevReoncileDetailRow;

        $emails = explode(',', $email);
        if (!empty($emails)) {
            $emailTo = $emails[0];
            if (count($emails) > 1) {
                $emailsCc = array_slice($emails, 1);
            }
        }else{
            return false;
        }

        if ($status == '') {
            $payload = array('payment_id' => $paymentId, 'approver_email' => $emailTo);
            $jwtMdl = new BaseApp_Utility_JWT();
            $token = $jwtMdl->encode($payload, SSO_CLIENT_SECRET);
            $this->updateApprovalToken($paymentId, $token);
            $approvalToken = $jwtMdl->encode(array('token' => $token, 'approval' => 'approve', 'paymentId' => $paymentId, 'userEmail' => $paymentData['user_email']), SSO_CLIENT_SECRET);
            $rejectToken = $jwtMdl->encode(array('token' => $token, 'approval' => 'reject', 'paymentId' => $paymentId, 'userEmail' => $paymentData['user_email']), SSO_CLIENT_SECRET);
            $approve_url = $this->prepareButtonUrl($approvalToken);
            $reject_url = $this->prepareButtonUrl($rejectToken);

            $buttonUrl = self::APPROVE_REJECT_BUTTON;
            $buttonUrl = str_replace('{approve_url}', $approve_url, $buttonUrl);
            $buttonUrl = str_replace('{reject_url}', $reject_url, $buttonUrl);
            $properties['approve_reject_button'] = $buttonUrl;
        }
        $template = BaseApp_Mailer::TEMPLATE_CUSTOM_PAYMENT_APPROVAL_REQUEST;

        try {
            $Identity = Zend_Auth::getInstance()->getIdentity();
            $mailer = new BaseApp_Mailer();
            $mailer->setTemplate($template);
            $mailer->addTo($emailTo);
            if (!empty($emailsCc)) {
                $mailer->addCc($emailsCc);
            }
            $mailer->setVariables($properties);
            $mailer->setSubject($subject);
            $opts = Zend_Registry::get('config')->get('resources')->get('mail')->get('transport')->toArray();
            $mailer->setDefaultTransport(new Zend_Mail_Transport_Smtp($opts['host'], $opts));
            $mailer->send();
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    private function prepareButtonUrl($token) {
        return BACKEND_URL.'/sso/order-approve/order-approve?token='.$token;
    }

    private function getMessageContent($paymentType, $token = '') {
        $message = '';
        switch ($paymentType) {
            case self::TYPE_BACKEND:
                $message = self::BACKEND_MESSAGE;
                break;
            default:
                $url = rtrim(SSVC_URL, "/") . '/checkout/details?authtoken=' . $token;
                $message = self::CUSTOM_MESSAGE;
                $message = str_replace('{url}', $url, $message);
        }
        return $message;
    }

    private function getTaxRow($taxStr, $currency, $taxAmt) {
        $taxRow = self::TAX_ROW;
        $taxRow = str_replace('{tax_str}', $taxStr, $taxRow);
        $taxRow = str_replace('{currency}', $currency, $taxRow);
        $taxRow = str_replace('{tax}', $taxAmt, $taxRow);
        return $taxRow;
    }

    private function getApprovalTaxRow($taxStr, $currency, $taxAmt) {
        $taxRow = self::APPROVAL_TAX_ROW;
        $taxRow = str_replace('{tax_str}', $taxStr, $taxRow);
        $taxRow = str_replace('{currency}', $currency, $taxRow);
        $taxRow = str_replace('{tax}', $taxAmt, $taxRow);
        return $taxRow;
    }

    private function getAdvanceAmountRow($amtStr,$currency, $price) {
        $advPaymentRow = self::ADVANCE_AMOUNT_ROW;
        $advPaymentRow = str_replace('{adv_amt_str}', $amtStr, $advPaymentRow);
        $advPaymentRow = str_replace('{currency}', $currency, $advPaymentRow);
        $advPaymentRow = str_replace('{advance_amt}', $price, $advPaymentRow);
        return $advPaymentRow;
    }

    private function getBalanceLeftRow($amtLeftStr, $currency, $amountLeft) {
        $balanceLeftRow = self::BALANCE_LEFT_ROW;
        $balanceLeftRow = str_replace('{balance_amt_str}', $amtLeftStr, $balanceLeftRow);
        $balanceLeftRow = str_replace('{currency}', $currency, $balanceLeftRow);
        $balanceLeftRow = str_replace('{balance_amt}', $amountLeft, $balanceLeftRow);
        return $balanceLeftRow;
    }

    private function getPrevReconcileDetail($prevReconcileData) {
        $amount = number_format($prevReconcileData['amount'], 2);
        $paymentDate = date('jS M Y', $prevReconcileData['paymentDate']);
        $prevReconcileDataRow = self::PREV_COURSE_UPGRADE_DETAIL;
        $prevReconcileDataRow = str_replace('{prev_course_name}', $prevReconcileData['course_name'], $prevReconcileDataRow);
        $prevReconcileDataRow = str_replace('{prev_currency}', $prevReconcileData['currency'], $prevReconcileDataRow);
        $prevReconcileDataRow = str_replace('{prev_amount}', $amount, $prevReconcileDataRow);
        $prevReconcileDataRow = str_replace('{prev_paymentDate}', $paymentDate, $prevReconcileDataRow);
        return $prevReconcileDataRow;
    }

    /** Generate backend payment order number. Note. SP stands for simplex * */
    private function getOrderNumber($order, $source = 'SP') {
        if (in_array($order['payment_sub_type_id'], self::$_allow_atp_payment_type)) {
            $orderNo = "BACKEND_ATP_". $order['timestamp'] . "_$source" . $order['employee_id'];
        } else if ($order['payment_sub_type_id'] == BaseApp_Dao_Melvin_Order::PAYMENT_COURSE_UPGRADATION) {
            $orderNo = "BACKEND_UPG_". $order['timestamp'] . "_$source" . $order['employee_id'];
        } else if ($order['payment_sub_type_id'] == BaseApp_Dao_Melvin_Order::PAYMENT_COURSE_EXTENSION) {
            $orderNo = "BACKEND_EXTN_". $order['timestamp'] . "_$source" . $order['employee_id'];
        } else if ($order['payment_sub_type_id'] == BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_PARTIAL) {
            $orderNo = parent::PAYMENT_TYPE_PARTIAL_NAME. $order['timestamp'] . "_$source" . $order['employee_id'];
        } else if ($order['payment_sub_type_id'] == BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_PARTIAL_SUBSEQUENT) {
            $orderNo = parent::PAYMENT_TYPE_PARTIAL_SUBSEQUENT_NAME. $order['timestamp'] . "_$source" . $order['employee_id'];
        } else if ($order['payment_sub_type_id'] == BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_CORPORATE) {
            $orderNo = "BACKEND_CORP_". $order['timestamp'] . "_$source" . $order['employee_id'];
        } else if ($order['payment_sub_type_id'] == BaseApp_Dao_Melvin_Order::PAYMENT_COURSE_COMPLIMENTARY) {
            $orderNo = "BACKEND_COMPL_". $order['timestamp'] . "_$source" . $order['employee_id'];
        } else {
            $orderNo = "BACKEND_". $order['timestamp'] . "_$source" . $order['employee_id'];
        }
        return $orderNo;
    }

    /** Create backend order * */
    public function createBackendOrder($order, $items) {
        $return = array("status" => false, "msg" => "", "data" => array());
        $userData = BaseApp_Auth::getLoggedInUserData();
        $xeniaApi = new BaseApp_Communication_Xenia();
        $ssvc = new BaseApp_Communication_Ssvc(SSVC_PROVIDER_KEY);
        $ssvc->login();
        $order['token'] = $ssvc->getToken();
        $order['paymentGateway'] = '';
        $xeniaDB = $this->getXeniaDb();
        $countryModel = new Model_Country();
        $objCurrency = new Model_Currency();
        $cityModel = new Model_City();

        $countryDetails = $countryModel->getCountryDetails($order['country_id']);
        if ($countryDetails['status'] === true && !empty($countryDetails['data'])) {
            $countryCode = !empty($countryDetails['data']['code']) ? $countryDetails['data']['code'] : '';
            $order['currency_id'] = !empty($countryDetails['data']['currency_id']) ? $countryDetails['data']['currency_id'] : '';
            $order['country_code'] = $countryCode;
            $currencyDetails = $objCurrency->getCurrencyDetails($countryDetails['data']['country_id']);
            if (!empty($currencyDetails)) {
                $order['invoiceAddress'] = !empty($currencyDetails['invoiceAddress']) ? $currencyDetails['invoiceAddress'] : "";
                $order['invoiceString'] = !empty($currencyDetails['invoiceString']) ? $currencyDetails['invoiceString'] : "";
                $order['currencyCode'] = !empty($currencyDetails['code']) ? $currencyDetails['code'] : "";
            }
        }

        $cityDetails = $cityModel->getCityDetails($order['city_id']);
        if ($cityDetails['status'] === true && !empty($cityDetails['data'])) {
            $order['state'] = !empty($cityDetails['data']['region_name']) ? $cityDetails['data']['region_name'] : "";
        }

        $order['scanCopyUrl'] = "";
        $order['employee_id'] = $userData['id'];
        $validator = new Zend_Validate_EmailAddress();
        $orderId = '';
        if ($validator->isValid($order['billing_email'])) {
            $userData = $this->registerUserByEmail($order['billing_email'], '', $countryCode);
            $order['user_id'] = $userData['user_id'];
            $order['user_name'] = $userData['name'];
            $order['timestamp'] = $order['date'];

            if (empty($order['orderNo'])) {
                $order['orderNo'] = $this->getOrderNumber($order);
            }
            $order['email'] = trim($order['billing_email']);
            $orderArray = $this->_formatOrder($order);
            if ($orderArray['status'] === true && is_array($orderArray['data']['order']) && !empty($orderArray['data']['order'])) {
              $backendOrderResponse = $xeniaApi->createBackendOrderWithTax($orderArray['data']);
              if($backendOrderResponse['status'] && !empty($backendOrderResponse['data'])) {
                $return['data']['orderNo'] = $order['orderNo'];
                $order['order_id'] = $backendOrderResponse['data']['order_id'];
              } else {
                self::log(array('KEY' => 'CUSTOM_PAYMENT_ERROR', "ACTION" => "SAVE-IN-ORDER", "REQUEST_PARAMS" => $orderArray, "RESPONSE" => false, "TRACE" => array('METHOD' => __METHOD__, 'LINE' => __LINE__)));
                $return['status'] = false;
                $return['msg'] = "Unable to create order";
                return $return;
              }
            } else {
              $return['status'] = false;
              $return['msg'] = !empty($orderArray['msg']) ? $orderArray['msg'] : "Unable to format order data";
              return $return;
            }
        }else{
          $return['status'] = false;
          $return['msg'] = "Invalid email provided:".$order['billing_email'];
          return $return;
        }

        //insert data in order details table
        $orderDetailsData = $this->_formatOrderDetails($order, $items);
        $orderDetailsResponse = $xeniaApi->createOrderDetails($orderDetailsData);
        if(!$orderDetailsResponse['status']) {
          $xeniaRollBackResponse = $xeniaApi->rollBackBackendOrder($order['order_id']);
          if(!$xeniaRollBackResponse['status']) {
            self::log(array('KEY' => 'CUSTOM_PAYMENT_ERROR', "ACTION" => "BACKEND-ORDER-ROLLBACK-FAILED", "REQUEST_PARAMS" => $order['order_id'], "RESPONSE" => $xeniaRollBackResponse['msg'], "TRACE" => array('METHOD' => __METHOD__, 'LINE' => __LINE__)));
          }
          self::log(array('KEY' => 'CUSTOM_PAYMENT_ERROR', "ACTION" => "SAVE-IN-ORDER", "REQUEST_PARAMS" => $orderArray, "RESPONSE" => "Failed to save in Order Details", "TRACE" => array('METHOD' => __METHOD__, 'LINE' => __LINE__)));
          $return['status'] = false;
          $return['msg'] = "Unable to create order details";
          return $return;
        }
        if (!empty($order['payment_sub_type_id']) && $order['payment_sub_type_id'] == BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_PARTIAL_SUBSEQUENT) {
            $paymentOrderCostData = array('orderNo' => $order['orderNo'], 'partial_subsequent_percentage' => self::$_overallPercentage, 'contract_number' => $order['contract_number']);
            $paymentOrderCostResponse = $xeniaApi->createPaymentOrderCost($paymentOrderCostData);
            if (!$paymentOrderCostResponse['status']) {
                self::log(array('KEY' => 'CUSTOM_PAYMENT_ERROR', "ACTION" => "BACKEND-ORDER-ROLLBACK-FAILED", "REQUEST_PARAMS" => json_decode($paymentOrderCostData), "RESPONSE" => $paymentOrderCostResponse['msg'], "TRACE" => array('METHOD' => __METHOD__, 'LINE' => __LINE__)));
            }
        }
        $orderCostItems = $orderDetailsResponse['data'];
        //insert data in order cost table
        if (!empty($order['payment_sub_type_id']) && (!in_array($order['payment_sub_type_id'], self::$_allow_atp_payment_type)) && (!in_array($order['payment_sub_type_id'], parent::$_allow_partial_payment_type))){
          if (!empty($orderCostItems)) {
            //to map this data same as keys in case of SMPL and Custom Payment
            foreach ($orderCostItems as &$val) {
                $val['productType_id'] = $val['linkable_type_id'];
                $val['price_id'] = $val['priceId'];
                $val['product_id']=$val['linkable_id'];
                unset($val['linkable_type_id'],$val['priceId'],$val['linkable_id']);
            }
            $orderCostData = $this->prepareOrderCostByOrderItems($orderCostItems, $order);
            if ($orderCostData['status'] == true && !empty($orderCostData['data'])) {
              $orderCostResponse = $xeniaApi->createOrderCost($orderCostData,$order['learner_email'],$order['payment_sub_type_id']);
              if(!$orderCostResponse['status']) {
                $rollBackOrderDetails = true;
                $xeniaRollBackResponse = $xeniaApi->rollBackBackendOrder($order['order_id']);
                if(!$xeniaRollBackResponse['status']) {
                  self::log(array('KEY' => 'CUSTOM_PAYMENT_ERROR', "ACTION" => "BACKEND-ORDER-ROLLBACK-FAILED", "REQUEST_PARAMS" => $order['order_id'], "RESPONSE" => $xeniaRollBackResponse['msg'],"TRACE" => array('METHOD' => __METHOD__, 'LINE' => __LINE__)));
                }
                self::log(array('KEY' => 'CUSTOM_PAYMENT_ERROR', "ACTION" => "SAVE-IN-ORDER", "REQUEST_PARAMS" => $orderArray, "RESPONSE" => false, "TRACE" => array('METHOD' => __METHOD__, 'LINE' => __LINE__)));
                $return['status'] = false;
                $return['msg'] = "Unable to create order cost";
                return $return;
              }
            }
          }
        }
        //Insert order into SSVC Cart
        $cartData = $this->_prepareCart($order, $items);
        $ssvc = new BaseApp_Communication_Ssvc(SSVC_PROVIDER_KEY);
        $ssvc->setToken($order['token']);
        $cartStatus = $ssvc->createCart($cartData);
        self::log(array("ACTION" => "CREATE_CART", "REQUEST_PARAMS" => $cartData, "RESPONSE" => $cartStatus, "TRACE" => array('METHOD' => __METHOD__, 'LINE' => __LINE__)));
        //Update currency code in ssvc cart table
        $where = "token = '" . $order['token'] . "'";
        $xeniaDB->update(self::SSVC_DATABASE . '.cart', array('currency' => $order['currencyCode']), $where);

        //Insert data into ssvc.transaction_userdata
        $userData = $this->_prepareUserData($order);
        $uStatus = $xeniaDB->insert(self::SSVC_DATABASE . '.transaction_userdata', $userData);
        self::log(array("ACTION" => "CREATE_CART_USER", "REQUEST_PARAMS" => $userData, "RESPONSE" => $uStatus, "TRACE" => array('METHOD' => __METHOD__, 'LINE' => __LINE__)));
        $return['status'] = true;
        $return['msg'] = "Success";
        return $return;
    }

    private function _prepareUserData($order) {
        return array(
            'token' => $order['token'],
            'name' => $order['user_name'],
            'phone' => $order['contact_number'],
            'email' => $order['email'],
            'city' => $order['city_name'],
            'state' => !empty($order['region_name']) ? $order['region_name'] :'',
            'time' => $order['timestamp'],
            'gateway' => $order['paymentGateway']);
    }

    private function _prepareCart($order, $items, $isMigration = false) {
        $cartData = array();
        if ($order) {
            $cartItems = array();

            $configSection = Model_TrainingTypes::CART_STRING_ONLINE;

            $quantity = 1;
            $emails = explode(",", $order['learner_email']);
            if (is_array($emails)) {
                $quantity = count($emails);
            }
            $priceSum = 0;
            $isUniversityMaster = 0;
            foreach ($items as $item) {
                if ($item['training_type_id'] == Model_TrainingTypes::TYPE_ELEARNING || $item['training_type_id'] == Model_TrainingTypes::TYPE_TEST || $item['training_type_id'] == Model_TrainingTypes::TYPE_IDES) {
                    $trainingType = Model_TrainingTypes::CART_STRING_ONLINE;
                } else {
                    $trainingType = Model_TrainingTypes::CART_STRING_CLASSROOM;
                }

                if ($item['training_type_id'] != Model_TrainingTypes::TYPE_ELEARNING) {
                    $configSection = Model_TrainingTypes::CART_STRING_CLASSROOM;
                }
                if(!empty($order['partialItemsSP'][$item['product_id']]['partial_selling_price'])) {
                  $item['selling_price'] = $order['partialItemsSP'][$item['product_id']]['partial_selling_price'];
                }
                if($isMigration && $quantity>1){
                    $item['selling_price'] = $item['selling_price']/$quantity;
                }
                $imageUrl = $this->getProductImageUrl($item['product_id'], $item['product_type_id']);
                $productUrl = $this->getProductUrl($item['product_id'], $item['product_type_id']);
                $productInfo = $this->getProduct($item['product_id'], $item['product_type_id']);
                if(!empty($productInfo)&& !empty($productInfo['isUniversityMaster']) && intval($productInfo['isUniversityMaster'])==BaseApp_Dao_Bundles::MASTER_TYPE_UNIVERSITY){
                    $isUniversityMaster = $productInfo['isUniversityMaster'];
                }
                $trainingTypeText = $this->getTrainingTypeText($item['training_type_id']);
                $itemTax = $this->getTax($item['selling_price'], $order['tax_percentage']);
                $priceSum += ($item['selling_price'] * $quantity);
                $row = array(
                    'id' => $item['product_id'],
                    'name' => $productInfo['name'],
                    'description' => ' - ' . 1 . ' Qty',
                    'price' => ($item['selling_price'] + $itemTax),// * $quantity,
                    'basePrice' => $item['selling_price'],
                    'display_total_price' => $item['selling_price'] * $quantity,
                    'quantity' => $quantity,
                    'isEarlyBird' => 0,
                    'type' => $trainingType,
                    'workshopId' => isset($item['workshop_id']) ? intval($item['workshop_id']) : 0,
                    'accessDays' => intval($item['access_days']),
                    'trainingType_id' => $item['training_type_id'],
                    'productTypeId' => $item['product_type_id'],
                    'productTypeName' => $productInfo['type'],
                    'actual_name' => $productInfo['name'],
                    'billingType' => self::ONE_TIME_BILLING_TYPE,
                    'img_url' => $imageUrl,
                    'course_url' => $productUrl,
                    'training_type_txt' => $trainingTypeText,
                    'messageTT' => '',
                    'availedFT' => '',
                    'priceId' => (!in_array($item['training_type_id'], self::$_allow_price_training_type)) ? 0 : $item['price_id'],
                );
                if ($row['trainingType_id'] && $item['product_type_id'] == Model_ProductTypes::TYPE_ID_COURSE && in_array($row['trainingType_id'], Model_TrainingTypes::$_classroom)) {
                    unset($row['access_days']);
                } else if ($item['product_type_id'] == Model_ProductTypes::TYPE_ID_BUNDLE || ($row['trainingType_id'] && in_array($row['trainingType_id'], Model_TrainingTypes::$_online))) {
                    unset($row['workshopId']);
                } else if ($item['product_type_id'] == Model_ProductTypes::TYPE_ID_PASS || $row['trainingType_id'] && $row['trainingType_id'] == Model_TrainingTypes::TYPE_ONLINE_CLASSROOM_PASS) {
                    $row['priceId'] = (!in_array($item['training_type_id'], self::$_allow_price_training_type)) ? 0 : $item['price_id'];
                    unset($row['workshopId']);
                }

                if (!empty($item['workshop_id'])) {
                    $Workshop = new BaseApp_Dao_Workshop($item['workshop_id']);

                    $workshopArray = [];
                    if ($Workshop instanceof BaseApp_Dao_Workshop) {
                        $workshopArray = $Workshop->toArray();
                    }

                    $row['from'] = (!empty($workshopArray['startDate'])) ? $workshopArray['startDate'] : '';
                    $row['to'] = !empty($workshopArray['endDate']) ? $workshopArray['endDate'] : '';
                    $row['days'] = !empty($workshopArray['dates']) ? count(explode(",", $workshopArray['dates'])) : '';
                }
                if($item['product_type_id'] == self::TYPE_MOM){
                    $row['priceId'] = '';
                }
                $cartItems[] = $row;
            }

            $taxProperties = json_decode($order['tax_properties'], true);
            $countryMdl = new Model_Country();
            $countryDetails = $countryMdl->getCountryDetails($order['country_id']);

            $countryCode = '';
            if ($countryDetails['status'] === true && !empty($countryDetails['data'])) {
                $countryCode = !empty($countryDetails['data']['code']) ? $countryDetails['data']['code'] : '';
            }

            $taxAmount = 0;
            if (!empty($taxProperties['totalTax']) && is_numeric($taxProperties['totalTax'])) {
                $taxAmount = $this->getTax($order['total_price'], $taxProperties['totalTax']);
            }

            $taxString = '';
            if(!empty($taxAmount)){
                foreach($taxProperties['tax'] as $key=>$val){
                    $taxString .= $key. "+";
                }
                $taxString = rtrim($taxString,'+');
            }

            $currencySymbol= "";
            if (!empty($taxProperties['code'])) {
                $currencyMdl = new Model_Currency();
                $symbolArr = current($currencyMdl->fetchAll(array('code=?' => $taxProperties['code']), array('columns' => array('symbol'))));
                $currencySymbol = !empty($symbolArr['symbol']) ? $symbolArr['symbol'] : '';
            }

            if ($priceSum != $order['total_price']) {
                Model_Payments::log(array('key' => 'CUSTOM_PAYMENT_ERROR_INFO','msg' => 'Items Sum and Total Price is mismatch. ', 'emailId' => $order['billing_email'], 'trace' => array('METHOD' => __METHOD__, 'LINE' => __LINE__)));
            }

            $general = [
                'orderId' => $order['orderNo'],
                'state' => $order['region_name'],
                'state_orig' => $order['region_name'],
                'state_changed' => 0,
                'siteName' => "",
                'free_trial' => NULL,
                'free_trial_token' => "",
                'logo' => "",
                'regNo' => !empty($taxProperties['registrationNumber']) ? $taxProperties['registrationNumber'] : "",
                'taxBreakup' => !empty($taxProperties['tax']) ? $taxProperties['tax'] : "",
                'service_tax' => $taxAmount,
                'service_tax_rate' => $taxProperties['totalTax'],
                'service_tax_string' => $taxString,
                'grand_total' => $order['total_price'] + $taxAmount,
                'grand_total_number_value' => $order['total_price'] + $taxAmount,
//                'grand_total_strike' => $priceSum,
//                'grand_total_actual' => $priceSum,
                'grand_total_strike' => $order['total_price'],
                'grand_total_actual' => $order['total_price'],
                'countryId' => $order['country_id'],
                'payment_type' => Model_Cart::PAYMENT_TYPE_NORMAL,
                'remoteAddr' => isset($_SERVER['REMOTE_ADDR'])? $_SERVER['REMOTE_ADDR'] : $order['ip_address'],
                'addMoreCourses' => "",
                'person_name' => '',
                'email' => $order['billing_email'],
                'phone' => $order['contact_number'],
                'phnCountryCode' => $countryCode,
                'city_id' => $order['city_id'],
                'countryCode' => $countryCode,
                'coupon_id' => 0,
                'coupon' => '',
                'totalDiscount' => '',
                'mobileAppInvocation' => '',
                'currency' => $currencySymbol,
                'currency_symbol' => !empty($taxProperties['currency_symbol']) ? $taxProperties['currency_symbol'] : "",
                'currency_id' => !empty($taxProperties['currency_id']) ? $taxProperties['currency_id'] : "",
                'currency_code' => !empty($taxProperties['code']) ? $taxProperties['code'] : "",
                'is_zest_money' => !empty($order['is_zest_money']) ? $order['is_zest_money'] : 0,
                'is_bajaj_finserv' => !empty($order['is_bajaj_finserv']) ? $order['is_bajaj_finserv'] : 0,
                'is_eduvanz' => !empty($order['is_eduvanz']) ? $order['is_eduvanz'] : 0,
                'is_affirm' => !empty($order['is_affirm']) ? $order['is_affirm'] : 0,
                'is_liquiloan' => !empty($order['is_liquiloan']) ? $order['is_liquiloan'] : 0,
                'isUniversityMaster'=>!empty( $isUniversityMaster) ?  $isUniversityMaster : 0,
                'contract_number' => !empty($order['contract_number']) ? $order['contract_number'] : ''
            ];

            if ($order['type'] == Model_Payments::TYPE_CUSTOM) {
                $general['isCustomPayment'] = 1;
            }
            $cartData = array('general' => $general,
                'remoteAddr' => isset($_SERVER['REMOTE_ADDR'])? $_SERVER['REMOTE_ADDR'] : $order['ip_address'],
                'time' => $order['timestamp'], 'items' => $cartItems,
                'token' => $order['token'], 'status' => 0, 'configSection' => $configSection, 'countryCode' => isset($order['country_code']) ? $order['country_code'] : '', 'emailId' => $order['email'],
                'orderId' => $order['orderNo'], 'paymentGateway' => isset($order['paymentGateway']) ? $order['paymentGateway'] : '', 'contactNumber' => isset($order['contact_number']) ? $order['contact_number'] : ''
            );
            return $cartData;
        }
    }

    /**
     * Private method to get product details
     */
    private function getProduct($product_id, $productType_id) {
        $return = array();
        $pType = new Model_ProductTypes($productType_id);
        $id = 0;
        $name = '';
        $url = '';
        $isUniversityMaster = 0;
        switch ($productType_id) {
            case self::TYPE_BUNDLE:
                $product = new Model_Bundles($product_id);
                $id = isset($product['bundle_id']) ? $product['bundle_id'] : '';
                $name = isset($product['display_name']) ? $product['display_name'] : '';
                $url = isset($product['url']) ? $product['url'] : '';
                $isUniversityMaster = isset($product['master_type']) && intval($product['master_type']) == BaseApp_Dao_Bundles::MASTER_TYPE_UNIVERSITY ? intval($product['master_type']) : BaseApp_Dao_Bundles::MASTER_TYPE_CLASSIC;
                break;
            case self::TYPE_MOM:
                $product = new Model_Bundles($product_id);
                $id = isset($product['bundle_id']) ? $product['bundle_id'] : '';
                $name = isset($product['display_name']) ? $product['display_name'] : '';
                $url = isset($product['url']) ? $product['url'] : '';
                $isUniversityMaster = isset($product['master_type']) && intval($product['master_type']) == BaseApp_Dao_Bundles::MASTER_TYPE_UNIVERSITY  ? intval($product['master_type']) : BaseApp_Dao_Bundles::MASTER_TYPE_CLASSIC;
                break;
            case self::TYPE_PASS:
                $product = new Model_Pass($product_id);
                $id = isset($product->pass_id) ? $product->pass_id : '';
                $name = isset($product->displayName) ? $product->displayName : '';
                break;
            default: {
                    $product = new Model_Courses($product_id);
                    $id = isset($product['course_id']) ? $product['course_id'] : '';
                    $name = isset($product['displayName']) ? $product['displayName'] : '';
                    $url = isset($product['url']) ? $product['url'] : '';
                }
        }
        $return['id'] = $id;
        $return['name'] = $name;
        $return['url'] = $url;
        $return['type_id'] = $productType_id;
        $return['type'] = isset($pType['product_type_name']) ? $pType['product_type_name'] : '';
        $return['label_id'] = isset($product['primary_label_id']) ? $product['primary_label_id'] : '';
        $return['primary_course_id'] = isset($product['primary_course_id']) ? $product['primary_course_id'] : '';
        if ($return['label_id']) {
            $label = new Model_Labels($return['label_id']);
            $return['label'] = isset($label['displayName']) ? $label['displayName'] : '';
        } else {
            $return['label'] = '';
        }
        $return['isUniversityMaster'] = $isUniversityMaster;
        return $return;
    }

    public function getTax($amount, $tax) {
        $serviceTax = 0;
        if (!is_numeric($amount) && $amount) {
            throw new BaseApp_Exception('Amount has to be numeric.');
        }
        if ($tax > 0) {
            $serviceTax = round(($amount * $tax) / 100, 2);
        }
        return $serviceTax;
    }

    public function getBankDetails($paymentData){
        switch($paymentData['country_id']){
            case 6:// India
                $bankDetailData = [
                    'Account Number' => '132-144189-001',
                    'Account Name' => 'SIMPLILEARN SOLUTIONS PVT LTD',
                    'Bank' => 'The Hongkong and Shanghai Banking Corporation Limited',
                    'Branch address' => 'HSBC No.84,Gandhi Bazar Main Road, Basavanagudi, Bangalore - 560004',
                    'Country' => 'INDIA',
                    'IFSC' => 'HSBC0560003',
                ];
                break;
            case 34:// USA
            case 14:// UK
            case 35:// Canada
                $bankDetailData = [
                    'Account Number' => '738005916',
                    'Account Name' => 'SIMPLILEARN AMERICAS INC',
                    'Bank' => 'The Hongkong and Shanghai Banking Corporation Limited',
                    'Branch address' => '95 Washington Street, 4 South | Buffalo, NY 14203',
                    'Country' => 'United States',
                    'Swift code' => 'MRMDUS33',
                    'ACH Routing Number' => '021001088',
                    'Wire Routing Number' => '021001088',
                ];
                break;
            default: // ROW
                $bankDetailData = [
                    'Account Number' => '260-073473-178',
                    'Account Name' => 'SIMPLILEARN SINGAPORE P L',
                    'Bank' => 'The Hongkong and Shanghai Banking Corporation Limited',
                    'Branch address' => '21 Collyer Quay HSBC Building Level 7 #01-01 Singapore 049320',
                    'Country' => 'Singapore',
                    'Swift code' => 'HSBCSGSG',
                    'Bank Code' => '7232',
                ];
                break;
        }

        return $bankDetailData;
    }

    /** Format order data * */
    private function _formatOrder($orderData) {
        $response = array('status' => false, 'msg' => "", 'data' => array());
        if (empty($orderData)) {
            return $response;
        }
        $fields = array(
            'orderNo',
            'city_id',
            'user_id',
            'email',
            'token',
            'total_price',
            'contact_number',
            'currency_id',
            'country_code');
        foreach ($fields as $field) {
            if (empty($orderData[$field])) {
                return array('status' => false, 'msg' => "{$field} is empty.");
            }
        }
        $taxData = (Zend_Json_Decoder::decode($orderData['tax_properties']));
        $taxAmt = $this->getTax($orderData['total_price'], $taxData['totalTax']);
        $atpCurrencyAmount = 0;
        if (in_array($orderData['payment_sub_type_id'], self::$_allow_atp_payment_type)) {
            $atpCurrencyAmount = $orderData['total_price'];
        }
        $orderRow = array(
            'orderNumber' => $orderData['orderNo'],
            'date' => $orderData['timestamp'],
            'city_id' => $orderData['city_id'],
            'user_id' => $orderData['user_id'],
            'userIp' => $_SERVER['REMOTE_ADDR'],
            'userEmail' => $orderData['email'],
            'authToken' => $orderData['token'],
            'coupon_id' => 0,
            'couponCode' => '',
            'couponAmount' => 0,
            'totalAmount' => $orderData['total_price'],
            'orderIP' => $_SERVER['REMOTE_ADDR'],
            'status' => '1',
            'paymentStatus' => 0,
            'paymentGateway' => '',
            'currency_id' => $orderData['currency_id'],
            'isFromBackend' => ($orderData['type'] == self::TYPE_BACKEND) ? 1 : 0,
            'contactNumber' => $orderData['contact_number'],
            'scanCopyUrl' => $orderData['scanCopyUrl'],
            'serviceTax' => $taxAmt,
            'totalTaxPercent' => $taxData['totalTax'],
            'netTotal' => $orderData['total_price'] + $taxAmt,
            'paymentType_id' => !empty($orderData['payment_sub_type_id']) ? $orderData['payment_sub_type_id'] : BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_REGULAR, // order table
            'billingType' => self::ONE_TIME_BILLING_TYPE,
            'userName' => $orderData['user_name'],
            'state' => $orderData['state'],
            'countryCode' => $orderData['country_code'],
            'invoiceAddress' => $orderData['invoiceAddress'],
            'invoiceString' => $orderData['invoiceString'],
            'free_trial' => NULL,
            'type' => '', /** @todo check this */
            'atpCurrencyAmount' => empty($atpCurrencyAmount) ? 0 : $atpCurrencyAmount,
            'conversionRate' => 0, /** @todo check this */
            'regNo' => !empty($taxData['registrationNumber']) ? $taxData['registrationNumber'] : "",
            'reseller_id' => !empty($orderData['affiliate_id']) ? $orderData['affiliate_id'] : NULL,
            'previous_reconciliation_id' => !empty($orderData['previous_reconciliation_id']) ? $orderData['previous_reconciliation_id'] : NULL,
            'contract_number' => !empty($orderData['contract_number']) ? $orderData['contract_number'] : ''
        );
        $response['status'] = true;
        $response['msg'] = "Success";
        $response['data'] = array("order" => $orderRow, 'tax_property' => $taxData);
        return $response;
    }

    /** Format order details * */
    private function _formatOrderDetails($data, $items) {
        $return = array();

        $quantity = 1;
        $emails = explode(",", $data['learner_email']);
        if (is_array($emails)) {
            $quantity = count($emails);
        }
        foreach ($items as $key => $item) {
            if(!empty($data['partialItemsSP'][$item['product_id']]['partial_selling_price'])) {
              $item['selling_price'] = $data['partialItemsSP'][$item['product_id']]['partial_selling_price'];
            }

            $item['priceId'] = (!in_array($item['training_type_id'], self::$_allow_price_training_type)) ? 0 : $item['price_id'];
            $return[$key][0] = array(
                'order_id' => $data['order_id'],
                'date_id' => isset($item['workshop_id']) ? $item['workshop_id'] : 0,
                'accessDays' => isset($item['access_days']) ? $item['access_days'] : '',
                'quantity' => $quantity,
                'price' => $item['selling_price'],
                'discountedPrice' => $item['selling_price'],
                'course_id' => isset($item['product_id']) ? $item['product_id'] : '',
                'trainingType_id' => $item['training_type_id'],
                'isExamFee' => isset($item['isExamFee']) ? $item['isExamFee'] : 0,
                'priceId' => isset($item['priceId']) ? $item['priceId'] : 0,
                'selling_mode'=> isset($item['selling_mode']) ? $item['selling_mode'] : '',
            );
            if (isset($item['product_type_id']))
                $productType = $item['product_type_id'];

            if (isset($item['linkable_type_id']))
                $productType = $item['linkable_type_id'];

            switch ($productType) {
                case self::TYPE_COURSE:
                    $return[$key][0]['linkable_type_id'] = self::TYPE_COURSE;
                    $return[$key][0]['linkable_id'] = isset($item['product_id']) ? $item['product_id'] : '';
                    break;
                case self::TYPE_BUNDLE:
                    $orderDetailsData = array();
                    unset($return[$key][0]);
                    $productId = isset($item['product_id']) ? $item['product_id'] : '';
                    $bundleData = (new Model_CourseMapping)->fetchBundleCoursesAndElectives(array($productId));
                    if (!empty($bundleData[$productId])) {
                        $coursesInBundle = $bundleData[$productId];
                        if (count($coursesInBundle) > 0) {
                            $individualBundleItemPrice = !empty($item['selling_price']) ? $item['selling_price'] / count($coursesInBundle) : 0;
                            foreach ($coursesInBundle as $course => $val) {
                                $return[$key][$val] = array(
                                    'order_id' => $data['order_id'],
                                    'date_id' => isset($data['date_id']) ? $data['date_id'] : ( isset($data['workshop_id']) ? $data['workshop_id'] : ''),
                                    'accessDays' => isset($item['access_days']) ? $item['access_days'] : '',
                                    'quantity' => $quantity,
                                    'price' => $individualBundleItemPrice,
                                    'discountedPrice' => $individualBundleItemPrice, /** @todo Need to check * */
                                    'course_id' => $val,
                                    'trainingType_id' => $item['training_type_id'],
                                    'isExamFee' => isset($item['isExamFee']) ? $item['isExamFee'] : 0,
                                    'priceId' => isset($item['priceId']) ? $item['priceId'] : 0,
                                    'linkable_type_id' => self::TYPE_BUNDLE,
                                    'linkable_id' => $productId
                                );
                            }
                        }
                    }
                    break;
                case self::TYPE_PASS:
                    $oDetails['linkable_type_id'] = self::TYPE_PASS;
                    $oDetails['linkable_id'] = isset($data['product']) ? $data['product'] : ( isset($data['course_id']) ? $data['course_id'] : '');
                    $oDetails['course_id'] = self::LVC_PASS_COURSE_ID;
                    break;
                default :
                    break;
            }
        }
        return $return;
    }

    public function fetchAllCategorybundles($columnsArray = array(), $order = 'name', $bundleId = array()) {
        $return = array();
        $courseModel = new Model_Bundles();
        if ($bundleId)
            $conds = array('bundle_id in (?)' => $bundleId);
        else
            $conds = array();
        if ($columnsArray)
            $data = $courseModel->fetchAll($conds, array('columns' => $columnsArray, 'order' => $order), false);
        else
            $data = $courseModel->fetchAll($conds, array('order' => $order), false);
        if ($data) {
            if (isset($data['primary_eLearning_id'])) {
                $data['eLearning_id'] = $data['primary_eLearning_id'];
            }
            if (isset($data['freeCourses'])) {
                $data['FreeELearningId'] = $courseModel->getFreeElearningsFromFreeCourses($data['freeCourses']);
                if ($data['FreeELearningId']) {
                    $data['FreeELearningId'] = implode(",", $data['FreeELearningId']);
                }
            }
            $return = $data;
        }
        return $return;
    }

    public function uploadPaymentDocInS3($files = array(), $orderNo, $paymentId) {
        $response = array('status' => true, 'message' => "", 'data' => array());
        if (empty($files) || empty($files['file']) || $orderNo == "" || $paymentId <= 0 || $paymentId == "") {
            if (empty($files) || empty($files['file'])) {
                $response['message'] = "File is missing.";
            }
            if ($orderNo == "") {
                $response['message'] = "Invalid order number";
            }

            if ($paymentId <= 0 || $paymentId == "") {
                $response['message'] = "Invalid payment id";
            }
            return $response;
        }
        $s3Url = "";
        $fileName = $files['file']['name'];
        $currentFilePath = $files['file']['tmp_name'];
        if (file_exists($currentFilePath)) {
            $imageExt = pathinfo($fileName, PATHINFO_EXTENSION);
            $newFileName = $orderNo . "_" . $paymentId . "_" . time() . "." . $imageExt;
            $awsPath = S3_PAYMENT_DOC_PATH . $newFileName;
            $objAws = new BaseApp_Utility_AwsFileUpload();
            if ($objAws->uploadImageIntoAws($currentFilePath, $awsPath, $imageExt)) {
                $s3Url = S3_PAYMENT_AWS_PATH . "/" . $awsPath;
            } else {
                $response['message'] = "There was some problem in uploading file";
                return $response;
            }
            $response['status'] = true;
            $response['message'] = "File successfully uploaded in S3";
            $response['data'] = array('s3Url' => $s3Url);
        }
        return $response;
    }

    private function getCurrencyDetails($countryId, $countryCode) {
        $resultArray = array('status' => false, 'message' => '', 'data' => array());
        if (!empty($countryCode) && empty($countryId)) {
            $objCountry = new Model_Country();
            $countryDetails = current($objCountry->fetchAll(array('code = ?' => $countryCode)));
            if (!empty($countryDetails) && !empty($countryDetails['country_id']))
                $countryId = $countryDetails['country_id'];
        }
        if ($countryId) {
            $objCurrency = new Model_Currency();
            $currencyData = $objCurrency->getCurrencyDetails($countryId);
            if (!empty($currencyData))
                $resultArray = array('status' => true, 'message' => 'success', 'data' => $currencyData);
            else
                $resultArray = array('status' => false, 'message' => 'No data Found', 'data' => array());
        }else {
            $resultArray = array('status' => false, 'message' => 'country Id is mandatory', 'data' => array());
        }
        return $resultArray;
    }

    public function getCountryDetails($countryId) {
        $response = array('status' => false, 'msg' => '', 'data' => array());
        if (empty($countryId)) {
            return $response;
        }
        $countryModel = new Model_Country();
        $country = current($countryModel->fetchAll(array('country_id = ?' => $countryId)));
        $response['status'] = true;
        $response['msg'] = "Success";
        $response['data'] = $country;
        return $response;
    }

    public function getCityDetails($cityId) {
        $response = array('status' => false, 'msg' => '', 'data' => array());
        if (empty($cityId)) {
            return $response;
        }
        $cityModel = new Model_City();
        $cityData = $cityModel->fetchAll(array('city_id =?' => $cityId));
        if (count($cityData) > 0) {
            $data = $cityData[0];
        }
        $response['status'] = true;
        $response['msg'] = "Success";
        $response['data'] = $data;
        return $response;
    }

    public function pushToCart(array $data) {
        $ssvc = new BaseApp_Communication_Ssvc(SSVC_PROVIDER_KEY);
        $ssvc->login();
        $token = $ssvc->getToken();
        try {
            $Cart = new Model_Cart;
            $cartData = $Cart->createNewCartForToken($token, $data);
        } catch (Exception $e) {
            return false;
        }

        return $cartData;
    }

    public function createOrderFromCartData(array $cartData, array $paymentData) {
        $taxProperties = json_decode($paymentData['tax_properties'], true);
        $cartData['serviceTax'] = $this->getTax($paymentData['total_price'], $paymentData['tax_percentage']);
        $cartData['currency_id'] = $taxProperties['currency_id'];
        $cartData['currency'] = $taxProperties['code'];
        $cartData['totalAmount'] = $paymentData['total_price'];
        $cartData['netTotalRaw'] = $paymentData['total_price'] + $cartData['serviceTax'];
        $cartData['order_type'] = Model_Payments::TYPE_CUSTOM;

        try {
            $Order = new Model_Order();
            $orderData = $Order->saveOrder($cartData);
        } catch (Exception $e) {
            return false;
        }

        return $orderData;
    }

    public function saveOrderInCRM($paymentId, array $orderArr, array $paymentData, $isMigration = false) {        
        $items = [];
        $quantity = 1;
        $emails = explode(",", $paymentData['learner_email']);
        if (is_array($emails)) {
            $quantity = count($emails);
        }
        foreach ($paymentData['items'] as $item) {
            if ($item['product_type_id'] == self::TYPE_BUNDLE) {
                $courses = (new Model_CourseMapping)->fetchBundleCoursesAndElectives([$item['product_id']]);
                $courses = current($courses);
            } else if($item['product_type_id'] == self::TYPE_MOM){
                $bundles = (new Model_CourseMapping)->fetchMomCoursesAndElectives([$item['product_id']]);
                $courses = (new Model_CourseMapping)->fetchBundleCoursesAndElectivesMom($bundles);
                sort($courses);
            }else {
                $courses = [$item['product_id']];
            }
            foreach ($courses as $key => $courseId) {
                $itemPrice = 0;
                if ($paymentData['payment_sub_type_id'] == BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_PARTIAL || $paymentData['payment_sub_type_id'] == BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_PARTIAL_SUBSEQUENT) {
                    if ($item['selling_price'] > 0) {
                       $itemPrice = round($this->paymentDistributionCalculation($item['selling_price'], self::$_overallPercentage), 2);
                    }
                } else {
                    $itemPrice = $item['selling_price'];
                }

                $itemPrice = floatval($itemPrice / count($courses));
                $itemParamArray=array(
                    'accessDays' => $item['access_days'],
                    'quantity' => $quantity,
                    'course_id' => $courseId,
                    'trainingType_id' => $item['training_type_id'],
                    'product_id' => $item['product_id'],
                    'productType_id' => $item['product_type_id'],
                    'isExamFee' => isset($item['isExamFee']) ? $item['isExamFee'] : 0,
                    'amount' => $itemPrice,
                    'item_amount' => $itemPrice,
                    'billingType' => self::ONE_TIME_BILLING_TYPE,
                    'date_id' => isset($item['workshop_id']) ? $item['workshop_id'] : 0,
                    'price_id' => (!in_array($item['training_type_id'], self::$_allow_price_training_type)) ? 0 : $item['price_id'],
                    'selling_mode' => $item['selling_mode']
                );
                if($item['product_type_id'] == self::TYPE_MOM){
                    $itemParamArray['price_id'] = "";
                }
                $items[] = $itemParamArray;
            }
        }
        $taxProperties = json_decode($paymentData['tax_properties'], true);
        $taxDetailsArr = [];
        $totalTax = $totalTaxPercent = 0;
        foreach ($taxProperties['tax'] as $key => $value) {
            $tax = $this->getTax($paymentData['total_price'], $value['percentage']);
            $totalTax += $tax;
            $totalTaxPercent += $value['percentage'];

            $taxDetailsArr[$key] = ['percentage' => $value['percentage'], 'amount' => $tax];
        }

        $itemTax = $this->getTax($paymentData['total_price'], $paymentData['tax_percentage']);
        $orderSummaryArr = ['app' => "web",
            'time' => isset($paymentData['date']) ? $paymentData['date'] : time(),
            'remoteAddr' => $orderArr['ipAddress'],
            'emailId' => $orderArr['email'],
            'amount' => $paymentData['total_price'],
            'state' => $paymentData['region_name'],
            'state_orig' => $paymentData['region_name'],
            'siteName' => $orderArr['siteName'],
            'state_changed' => $orderArr['state_changed'],
            'free_trial' => $orderArr['free_trial'],
            'regNo' => $orderArr['regNo'],
            'totalTax' => $itemTax,
            'paymentStatus' => 0,
            'currency_id' => $orderArr['currency_id'],
            'countryCode' => $orderArr['phnCountryCode'],
            'city_id' => $orderArr['city_id'],
            'orderNo' => $orderArr['orderNumber'],
            'origin' => !empty($orderArr['origin']) ? $orderArr['origin'] : '',
            'firstSource' => !empty($orderArr['firstSource']) ? $orderArr['firstSource'] : '',
            'billingType' => self::ONE_TIME_BILLING_TYPE,
            'totalTaxPercent' => $totalTaxPercent,
            'coupon_id' => 0,
            'couponCode' => "",
            'couponAmount' => 0,
            'infoSource' => "",
            'contactNumber' => $orderArr['phone'],
            'netTotal' => $orderArr['netTotal'],
            'mbsy_short_code' => "",
            'cdnCountryCode' => "",
            'prefix' => "CSTM_",
            'reseller_id'=>!empty($paymentData['affiliate_id']) ? $paymentData['affiliate_id'] : NULL,
            'paymentType_id' => !empty($paymentData['payment_sub_type_id']) ? $paymentData['payment_sub_type_id'] : BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_REGULAR,
            'learner_emails'=>!empty($orderArr['learner_emails'])?$orderArr['learner_emails']:'',
            'previous_reconciliation_id' => !empty($paymentData['previous_reconciliation_id']) ? $paymentData['previous_reconciliation_id'] : NULL,
            'contract_number' => !empty($paymentData['contract_number']) ? $paymentData['contract_number'] : ''
            ];

        if (in_array($paymentData['payment_sub_type_id'], self::$_allow_atp_payment_type)) {
            $orderSummaryArr['atpCurrencyAmount'] = $orderArr['totalAmount'];
        }

        $orderArr = array('order' => $orderSummaryArr, 'tax' => $taxDetailsArr, 'items' => $items);
        $costOrderArr = array('country_code' => $orderSummaryArr['countryCode'], 'order_id' => '', 'orderNo' => $orderSummaryArr['orderNo'], 'payment_sub_type_id' => $paymentData['payment_sub_type_id'], 'contract_number' => $orderSummaryArr['contract_number']);
        if (!empty($paymentData['payment_sub_type_id']) && (!in_array($paymentData['payment_sub_type_id'],self::$_allow_atp_payment_type)) && (!in_array($paymentData['payment_sub_type_id'], parent::$_allow_partial_payment_type))){
            $costs = $this->prepareOrderCostByOrderItems($items, $costOrderArr);
            if ($costs['status'] == true && !empty($costs['data'])) {
                $orderArr['costs'] = $costs['data'];
            }
        }

        // The payment subtype is 14 or subsequent than pass percentage of the amount 
        if($paymentData['payment_sub_type_id'] == BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_PARTIAL_SUBSEQUENT){
            $orderArr['partial_subsequent_percentage'] = self::$_overallPercentage;
        }

        $xenia = new BaseApp_Communication_Xenia();
        $resultSet = $xenia->generateOrder($orderArr);
        if (empty($resultSet['status']) || strcasecmp($resultSet['status'], 'success') !== 0) {
            throw new BaseApp_Exception('CRM api generateOrder failed ! Order Number : ' . $orderArr['order']['orderNo'] . '. Message : ' . (isset($resultSet['msg']) ? $resultSet['msg'] : ''));
        }

        $this->updateOrderNoInPayment($this->getDb(), $paymentId, $orderArr['order']['orderNo']);

        $paymentData['orderNo'] = $orderArr['order']['orderNo'];
        $this->pushToSSVCCart($paymentData, $isMigration);

        return $resultSet;
    }

    public function updateToken($paymentId, $token) {
        /** @var Zend_Db_Adapter_Abstract $db */
        $this->getDb()->update($this->_name, ['auth_token' => $token], "payment_id = '" . intval($paymentId) . "'");
        return $this;
    }

    public function updateApprovalToken($paymentId, $token) {
        /** @var Zend_Db_Adapter_Abstract $db */
        $this->getDb()->update($this->_name, ['approval_token' => $token], "payment_id = '" . intval($paymentId) . "'");
        return $this;
    }

    /**
     * Need to check
     * @param type $item
     * @return int
     */
    public function getProductPricingId(&$item) {
        if ($item['training_type_id'] == BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM || ($item['product_type_id'] == self::TYPE_COURSE && $item['training_type_id'] == BaseApp_Dao_TrainingTypes::TYPE_LVC) || $item['training_type_id'] == BaseApp_Dao_TrainingTypes::TYPE_WEBINAR) {
            $item['access_days'] = null;
        }
    }

    public static function validateDiscount($productType, $productId, $discount, $sellingMode='paid') {
        if (empty($productType) || !in_array($productType, [self::TYPE_BUNDLE, self::TYPE_COURSE, self::TYPE_MOM])) {
            return ['status' => false, 'msg' => 'Invalid product type'];
        } else if (empty($productId) || !is_numeric($productId)) {
            return ['status' => false, 'msg' => 'Invalid product id'];
        }

        $loggedInUser = BaseApp_Auth::getLoggedInUserData();
        $loggedInUserRoles = $loggedInUser['roles'];
        foreach (self::$_roles as $key=>$val){
            if(in_array($key,array_values($loggedInUserRoles))){
                $userRole=$val;
                break;
            }
        }
        if(empty($userRole)){
            return ['status' => false, 'msg' => 'You do not have permissions to make payment, Please contact admin to add Roles.'];
        }
        $rolesDiscountObj = new Zend_Config_Ini(APPLICATION_PATH ."/../../configs/roles_discounts.ini", $userRole);
        $rolesDiscount = $rolesDiscountObj->toArray();
        $maxAllowedDiscount = 0;
        $maxDiscountFlag = '';
        switch ($productType) {
            case self::TYPE_BUNDLE:
                $Bundle = new Model_Bundles();
                $bundleDetails = $Bundle->fetchAll(array('bundle_id =?' => intval($productId)), array(), false);
                if (!is_array($bundleDetails) || empty($bundleDetails)) {
                    return ['status' => false, 'msg' => 'Invalid product id'];
                }

                $bundleDetails = current($bundleDetails);
                $hasExam = $bundleDetails['has_exam'];
                $maxDiscountFlag='MASTER_PROGRAM_WITH_EXAM';
                $maxAllowedDiscount = $rolesDiscount[$maxDiscountFlag];
                if (isset($bundleDetails['can_be_free']) && $bundleDetails['can_be_free'] == 1 && $sellingMode == 'free') {
                    $maxDiscountFlag = 'FREE_MASTER_PROGRAM';
                    $maxAllowedDiscount = $rolesDiscount[$maxDiscountFlag];
                } else if ($hasExam != 1 && $sellingMode == 'paid') {
                    $maxDiscountFlag = 'MASTER_PROGRAM';
                    $maxAllowedDiscount = $rolesDiscount[$maxDiscountFlag];
                }

                break;
            case self:: TYPE_MOM:
                $Bundle = new Model_Bundles();
                $momDetails = $Bundle->fetchAll(array('bundle_id =?' => intval($productId),'linkable_type = ?' => 'master_of_masters'), array(), false);
                if (!is_array($momDetails) || empty($momDetails)) {
                    return ['status' => false, 'msg' => 'Invalid product id'];
                }
                $momDetails = current($momDetails);
                $maxDiscountFlag='MOM_PROGRAM';
                $maxAllowedDiscount = $rolesDiscount[$maxDiscountFlag];
                break;
            case self::TYPE_COURSE:
                $Courses = new BaseApp_Dao_Courses();
                $courseResult = $Courses->fetchAll(array('course_id =?' => intval($productId)), array(), false);
                if (!is_array($courseResult) || empty($courseResult)) {
                    return ['status' => false, 'msg' => 'Invalid product id'];
                }
                $courseInclusionRows = (new BaseApp_Dao_CourseInclusions())->fetchAll(array('course_id =?' => intval($productId), 'linkable_type =?' => 'exam', 'status =?' => 1));
                $hasExam = 0;
                if (count($courseInclusionRows) > 0) {
                    $hasExam = 1;
                }
                $courseResult = current($courseResult);
                if (isset($courseResult['can_be_free']) && $courseResult['can_be_free'] == 1 && $sellingMode == 'free') {
                    $maxDiscountFlag='FREE_COURSES';
                    $maxAllowedDiscount = $rolesDiscount[$maxDiscountFlag];
                } elseif (((isset($courseResult['can_be_free']) && $courseResult['can_be_free'] == 0) || 
                    (isset($courseResult['can_be_free']) && $courseResult['can_be_free'] == 1 && $sellingMode == 'paid')
                    ) &&
                        (isset($courseResult['revenue_share']) && $courseResult['revenue_share'] == 0) && $hasExam == 0) {
                    $maxDiscountFlag='OTHER_COURSES';
                    $maxAllowedDiscount = $rolesDiscount[$maxDiscountFlag];
                } else if ($hasExam == 1) {
                    $maxDiscountFlag='COURSE_WITH_EXAM';
                    $maxAllowedDiscount = $rolesDiscount[$maxDiscountFlag];
                }
                else if ((isset($courseResult['revenue_share']) && $courseResult['revenue_share'] == 1)) {
                    $maxDiscountFlag='COURSES_WITH_REVENUE_SHARE';
                    $maxAllowedDiscount = $rolesDiscount[$maxDiscountFlag];
                }

                break;
            default:
                return ['status' => false, 'msg' => 'Invalid product type'];
        }
        if ($discount > $maxAllowedDiscount) {
            if ($userRole == self::$_roles[parent::B2C_SALES_DIRECTOR]) {
                return ['status' => false, 'msg' => 'Max allowed discount is ' . $maxAllowedDiscount . '%.'];
            }
            $managerRole = self::$_roles[parent::B2C_SALES_DIRECTOR];
            $rolesDiscountArr = parse_ini_file(APPLICATION_PATH . "/../../configs/roles_discounts.ini", true);
            if ($discount > ($rolesDiscountArr[self::$_roles[parent::B2C_SALES_DIRECTOR]][$maxDiscountFlag])) {
                return ['status' => false, 'msg' => 'Your Allowed discount :' . $maxAllowedDiscount . '%. Max Approval discount :'.$rolesDiscountArr[self::$_roles[parent::B2C_SALES_DIRECTOR]][$maxDiscountFlag]];
            } elseif ($discount <= ($rolesDiscountArr[self::$_roles[parent::B2C_SALES_BUSINESS_MANAGER]][$maxDiscountFlag])) {
                $managerRole = self::$_roles[parent::B2C_SALES_BUSINESS_MANAGER];
            }
            return ['status' => false, 'approval' => true, 'user_role' => $userRole, 'manager_role' => $managerRole, 'allowed_discount' => $maxAllowedDiscount, 'msg' => 'Your max allowed discount is ' . $maxAllowedDiscount . '%. Do you want to add this item for Approval?'];
        }

        return ['status' => true,'allowed_discount' => $maxAllowedDiscount, 'msg' => "Valid discount {$discount}% as paid"];
    }
    public function getCertificationBundle() {
        $Bundle = new Model_Bundles();
        $bundleDetails = $Bundle->fetchAll(array('has_exam =?' => 1,'bundle_id NOT IN (?)' => explode(',', self::$_removedBundlesException)), array('columns' => array('bundle_id')), false);
        $certificationsBundlesIds  = array();
        if(!empty($bundleDetails)) {
            $certificationsBundlesIds = array_column($bundleDetails, 'bundle_id');
        }
        return $certificationsBundlesIds;
    }
    public function getCertificationCourses() {
        $courseInclusionRows = (new BaseApp_Dao_CourseInclusions())->fetchAll(array('linkable_type =?' => 'exam', 'course_id NOT IN (?)' => explode(',',self::$_removedCoursesException) , 'status =?' => 1),array('columns' => array('course_id')));
        $courseIds = array();
        if(!empty($courseInclusionRows)) {
            $courseIds = array_column($courseInclusionRows, 'course_id');
        }
        return $courseIds;
    }
    public function getClassRoomCourses() {
        $workshop = new BaseApp_Dao_Workshop;
        $db = $workshop->getDb();
        $workshops = $db->fetchAll(
                $db
                        ->select()
                        ->distinct()
                        ->from('workshop', array('course_id'))
                        ->where('status <> ?', 0)
                        ->where('isSold <> ?', 1)
                        ->where('isCorporate <> ?', 1)
                        ->where('startDate > now()')
                        ->where('country_id = ? ', INDIA_COUNTRY_ID)
                        ->where('training_id = ? ',  BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM)
                        ->where('course_id NOT IN (?)',  explode(',',self::$_removedClassRoomCourses))
                        ->order('course_id')
        );
        $courseIds = array();
        if (!empty($workshops)) {
            $courseIds = array_column($workshops, 'course_id');
        }
        return $courseIds;
    }
    public function uploadFileInS3($params = array(), $files = array()) {
        $response = array('status' => false, 'message' => "", 'data' => array());
        if (empty($params) || empty($files)) {
            $response['message'] = "Invalid parameters passed";
            return $response;
        }
        $condition = array("payment_id IN (?) " => $params['paymentId']);
        $column = array('order_number','contract_number');

        $paymentData = $this->getPaymentDetails($column, $condition);
        if (!empty($paymentData[0]['order_number'])) {
            $orderNo = $paymentData[0]['order_number'];
        }
        $uploadFileUrl = $this->uploadPaymentDocInS3($_FILES, $orderNo, $params['paymentId']);
        if ($uploadFileUrl['status'] === true && !empty($uploadFileUrl['data'] && !empty($uploadFileUrl['data']['s3Url']))) {
            $uploadFileUrl['data']['orderNo'] = $orderNo;
            $response['status'] = $uploadFileUrl['status'];
            $response['message'] = $uploadFileUrl['message'];
            $response['data'] = $uploadFileUrl['data'];
        } else {
            $response['status'] = $uploadFileUrl['status'];
            $response['message'] = $uploadFileUrl['message'];
            $response['data'] = $uploadFileUrl['data'];
        }
        $response['data']['contract_number'] = $paymentData[0]['contract_number'];
        return $response;
    }

    public function updateS3Url($params = array(), $s3Data = array()) {
        $response = array('status' => false, 'message' => "", 'data' => array());
        if (empty($params['paymentId'])) {
            $response['message'] = "Invalid payment id.";
            return $response;
        }

        if (empty($s3Data['orderNo'])) {
            $response['message'] = "Invalid orderNo.";
            return $response;
        }

        $userData = BaseApp_Auth::getLoggedInUserData();
        $userId = !empty($userData['id']) ? $userData['id'] : 0;
        $columnToUpdatePayment = array(
            'attachment' => $s3Data['s3Url'],
            'payment_method' => $params['paymentMethod'],
            'remark' => $params['remark'],
            'reference_number' => $params['referenceNo'],
            'is_approved' => BaseApp_Datatable_Payments::PAYMENT_RECEIVED,
            'attachment_upload_by' => $userId
        );
        $conditionPayment = array("payment_id IN (?) " => $params['paymentId']);
        /**
         * Update data in payment table
         */
        $db = $this->getDb();
        $db->beginTransaction();
        try {
            $paymentResult = $this->updatePaymentDetails($db, $columnToUpdatePayment, $conditionPayment);
            if (!$paymentResult) {
                $response['message'] = "Some error occured while updating payments table for payment Id - {$params['paymentId']}";
                return $response;
            }
            $orderResult = $this->updateOrderAttachment($s3Data['s3Url'], $s3Data['orderNo']);
            if (!$orderResult) {
                $db->rollBack();
                $response['message'] = "Some error occured while updating orders table for order number - {$s3Data['orderNo']}";
                return $response;
            }
            $response['status'] = true;
            $response['message'] = "Data updated successfully";
            $response['data'] = array("paymentResult" => $paymentResult, "orderNumber" => $orderResult);
            $db->commit();
        } catch (Exception $ex) {
            $response['message'] = $ex->getMessage();
            $db->rollBack();
            return $response;
        }
        return $response;
    }

    public function updateOrderAttachment($scanCopyUrl, $orderNo) {
        $xeniaDB = $this->getXeniaDb();
        $where = "orderNumber = '" . $orderNo . "'";
        $orderResult = $xeniaDB->update('orders', array('scanCopyUrl' => $scanCopyUrl), $where);
        return $orderResult;
    }

    public function pushToSSVCCart(array $paymentData, $isMigration = false) {
        $paymentData['timestamp'] = $paymentData['date'];
        $paymentData['email'] = $paymentData['billing_email'];

        $countryMdl = new Model_Country();
        $countryDetails = $countryMdl->getCountryDetails($paymentData['country_id']);
        if ($countryDetails['status'] === true && !empty($countryDetails['data'])) {
            $countryCode = !empty($countryDetails['data']['code']) ? $countryDetails['data']['code'] : '';
            $paymentData['currency_id'] = !empty($countryDetails['data']['currency_id']) ? $countryDetails['data']['currency_id'] : '';
            $paymentData['country_code'] = $countryCode;
        }

        $cartData = $this->_prepareCart($paymentData, $paymentData['items'], $isMigration);
        $ssvc = new BaseApp_Communication_Ssvc(SSVC_PROVIDER_KEY);
        $ssvc->setToken($paymentData['token']);
        $ssvc->createCart($cartData);
    }

    protected function getProductImageUrl($productId, $type) {
        if ($type == self::TYPE_COURSE) {
            $typeLabel = 'course';
            $name = 'image_home_page';
        } else if ($type == self::TYPE_BUNDLE) {
            $typeLabel = 'bundle';
            $name = 'bundle_logo';
        } else if ($type == self:: TYPE_MOM){
            $typeLabel = 'master_of_masters';
            $name = 'mom_logo';
        }else {
            return "";
        }

        $db = Zend_Db_Table::getDefaultAdapter();
        $sql = $db->select()
                ->from('images', 'imagePath')
                ->where('linkable_id = ?', $productId)
                ->where('linkable_type = ? ', $typeLabel)
                ->where('name = ? ', $name);
        $imgurl = $db->fetchOne($sql);
        if (empty($imgurl)) {
            return "";
        }

        return $imgurl;
    }

    protected function getProductUrl($productId, $type) {
        if ($type == self::TYPE_COURSE) {
            $typeLabel = 'course';
        } else if ($type == self::TYPE_BUNDLE) {
            $typeLabel = 'bundle';
        } else if ($type == self::TYPE_MOM) {
            $typeLabel = 'master_of_masters';
        }else {
            return "";
        }

        $db = Zend_Db_Table::getDefaultAdapter();
        $sql = $db->select()
                ->from('seo', 'url')
                ->where('linkable_id = ?', $productId)
                ->where('linkable_type = ? ', $typeLabel);
        $seoUrl = $db->fetchOne($sql);
        if (empty($seoUrl)) {
            return "";
        }

        return $seoUrl;
    }

    protected function getTrainingTypeText($trainingTypeId) {
        $db = Zend_Db_Table::getDefaultAdapter();
        $sql = $db->select()
                ->from('trainingTypes', 'name')
                ->where('training_id = ?', $trainingTypeId);
        $name = $db->fetchOne($sql);
        if (empty($name)) {
            return "";
        }

        return $name;
    }

    public function getWorkshopForSelect($trainingTypeId, $countryId, $cityId, $courseId, $fromDate = null, $active = null, $notSold = null, $corporate = null) {
        $objWorkshop = new Model_Workshop();
        return $objWorkshop->getWorkshopList($trainingTypeId, $countryId, $cityId, $courseId, $fromDate, $active, $notSold, $corporate, null, 1);
    }

    public function validateUploadedFile($files = array()) {
        $response = array('status' => false, 'message' => "", 'data' => array());

        if (!is_array($files) || empty($files) || empty($files['file'])) {
            $response['message'] = "Please upload a valid file";
            return $response;
        }
        $file = $files['file'];
        //validate the file size
        if (!isset($file['size'])) {
            $response['message'] = "Invalid file size";
            return $response;
        }
        if ($file['size'] > self::MAX_FILE_SIZE || empty($file['size']) || $file['size'] == 0) {
            if ($file['size'] > self::MAX_FILE_SIZE) {
                $response['message'] = "Uploaded file should be less than " . self::MAX_FILE_SIZE;
            } else {
                $response['message'] = "Invalid file size";
            }
            return $response;
        }

        $filename = strtolower($file['name']);
        $fileExt = pathinfo($filename, PATHINFO_EXTENSION);
        if (!in_array($fileExt, $this->_allow_file_formats)) {
            $response['message'] = "{$fileExt} format is not allowed. Please upload file with jpg, jpeg, png, gif, pdf formats.";
            return $response;
        }

        $response['status'] = true;
        $response['message'] = "Success";
        $response['data'] = $files;
        return $response;
    }

    public function prepareElearnings(array &$items) {
        $courses = $bundles = $masters = [];
        foreach ($items as $item) {
            if ($item['product_type_id'] == BaseApp_Dao_ProductTypes::TYPE_ID_BUNDLE) {
                $bundles[] = $item['product_id'];
            } else if ($item['product_type_id'] == BaseApp_Dao_ProductTypes::TYPE_ID_MOM) {
                $masters[] = $item['product_id'];
            } else if ($item['product_type_id'] == 1) {
                $courses[] = $item['product_id'];
            } else {
                return ['status' => false, 'msg' => "Invalid product_type_id {$item['product_type_id']} found"];
            }
        }
        // Fectch bundles from Masters
        if(!empty($masters)){
        $masterbundles =  (new Model_CourseMapping)->fetchMomCoursesAndElectives($masters);
        foreach($masterbundles as $masterId => $value){
            foreach($value as $key => $bundleId){
              array_push($bundles,$bundleId);
            }

        }
        }
        // Fetch Courses from bundles
        $bundledCourses = (new Model_CourseMapping)->fetchBundleCoursesAndElectives($bundles);

        if (!empty($bundledCourses)) {
            foreach ($bundledCourses as $bundledCourse) {
                $courses = array_merge($courses, $bundledCourse);
            }
        }

        $courses = array_values(array_unique($courses));

        if(empty($courses)){
            return ['status' => false, 'msg' => "Course not found for selected item"];
        }
        $elearningCourses = (new Model_Courses())->fetchElearningOnIds($courses);

        $mappedElearningCourses = [];
        foreach ($elearningCourses as $elearningCourse) {
            $mappedElearningCourses[$elearningCourse['course_id']] = $elearningCourse['primary_eLearning_id'];
        }

        foreach ($items as &$item) {
            $elearnings = [];
            if ($item['product_type_id'] == 2) {
                if (empty($bundledCourses[$item['product_id']])) {
                    return ['status' => false, 'msg' => 'No mapped course found for bundle: ' . $item['product_name']];
                }

                foreach ($bundledCourses[$item['product_id']] as $courseId) {
                    if (empty($mappedElearningCourses[$courseId])) {
                        return ['status' => false, 'msg' => 'No mapped elearning found for bundle: ' . $item['product_name'] . ', course id: ' . $courseId];
                    }

                    $elearnings[$courseId] = $mappedElearningCourses[$courseId];
                }

                $item['elearning_ids'] = json_encode($elearnings);
            } else if($item['product_type_id'] == 5){
                   if (empty($masterbundles[$item['product_id']])) {
                    return ['status' => false, 'msg' => 'No mapped course found for bundle: ' . $item['product_name']];
                }
                foreach ($masterbundles[$item['product_id']] as $key => $bundleId) {
                    foreach($bundledCourses[$bundleId] as $courseId){
                    if (empty($mappedElearningCourses[$courseId])) {
                        return ['status' => false, 'msg' => 'No mapped elearning found for bundle: ' . $item['product_name'] . ', course id: ' . $courseId];
                    }

                    $elearnings[$courseId] = $mappedElearningCourses[$courseId];
                }
                }
                $item['elearning_ids'] = json_encode($elearnings);
            }else if ($item['product_type_id'] == 1) {
                if (empty($mappedElearningCourses[$item['product_id']])) {
                    return ['status' => false, 'msg' => 'No mapped elearning found for course: ' . $item['product_name']];
                }

                $item['elearning_ids'] = json_encode([$item['product_id'] => $mappedElearningCourses[$item['product_id']]]);
            }
        }
        return ['status' => true];
    }

    public function updateCart($db, $cols = array(), $condition = array()) {
        return $db->update(self::SSVC_DATABASE . '.cart', $cols, $condition);
    }

    public function updateOrder($db, $cols = array(), $condition = array()) {
        return $db->update('orders', $cols, $condition);
    }

    public function updateTablesForBackendPymentApproval($paymentDetails, $assignmentData) {
        $response = array('status' => false, 'message' => "", 'data' => array());

        if (empty($paymentDetails)) {
            $response['message'] = "empty parameters passed.";
            return $response;
        }

        if (!empty($paymentDetails[0]['payment_sub_type_id']) && !in_array($paymentDetails[0]['payment_sub_type_id'], Model_Payments::$_allow_partial_payment_type)) {
            if (empty($assignmentData)) {
                $response['message'] = "empty parameters passed.";
                return $response;
            }
        }

        $ice9DB = $this->getDb();
        $ice9DB->beginTransaction();

        $xeniaDB = $this->getXeniaDb();
        $xeniaDB->beginTransaction();
        try {
            $cartWhere = array("orderId = ? " => $paymentDetails[0]['order_number']);
            $cartCols = array('status' => 1);
            $cartResult = $this->updateCart($xeniaDB, $cartCols, $cartWhere);
            if (!$cartResult) {
                $xeniaDB->rollBack();
                $ice9DB->rollBack();
                $response['message'] = "Some error occured while updating cart table for order number - {$paymentDetails[0]['order_number']}";
                return $response;
            }

            // update orders table
            $orderWhere = array('orderNumber = ?' => $paymentDetails[0]['order_number']);
            $orderCols = array('paymentStatus' => 1);
            $orderResult = $this->updateOrder($xeniaDB, $orderCols, $orderWhere);
            if (!$orderResult) {
                $xeniaDB->rollBack();
                $ice9DB->rollBack();
                $response['message'] = "Some error occured while updating orders table for order number - {$paymentDetails[0]['order_number']}";
                return $response;
            }

            // update payments table
            $userData = BaseApp_Auth::getLoggedInUserData();
            $userId = !empty($userData['id']) ? $userData['id'] : 0;
            $paymentsWhere = array('order_number = ?' => $paymentDetails[0]['order_number']);
            $paymentsCols = array('is_approved' => 2, 'assign_log' => $assignmentData, 'approved_by' => $userId);

            $paymentsResult = $this->updatePaymentDetails($ice9DB, $paymentsCols, $paymentsWhere);
            if (!$paymentsResult) {
                $xeniaDB->rollBack();
                $ice9DB->rollBack();
                $response['message'] = "Some error occured while updating payments table for order number - {$paymentDetails[0]['order_number']}";
                return $response;
            }

            if ($cartResult && $orderResult && $paymentsResult) {
                $xeniaDB->commit();
                $ice9DB->commit();
                $response['status'] = true;
                $response['message'] = "Payment approved and courses assigned successfully.";
                if (in_array($paymentDetails[0]['payment_sub_type_id'], Model_Payments::$_allow_partial_payment_type)) {
                    $response['message'] = "Payment approved successfully.";
                }
            } else {
                $xeniaDB->rollBack();
                $ice9DB->rollBack();
                $response['status'] = false;
                $response['message'] = "Some error occured while updating the tables.";
            }
        } catch (Exception $ex) {
            $response['message'] = $ex->getMessage();
            $xeniaDB->rollBack();
            $ice9DB->rollBack();
            return $response;
        }
        return $response;
    }



    /** Remove after Migration **/
    public function migrateOldCustomPayments() {
        $startDate = strtotime(date('2018-03-01'));
        $db = Zend_Db_Table::getDefaultAdapter();
        $sql = $db->select()
                ->from('ssvc.custom_payment_crm')
                ->where('urlCreatedTime >=?', $startDate)
                ->where('new_token =? or new_token is null', '')
                ->where('paymentStatus = ?', 0)
                ->order('custom_payment_id DESC');

        $data = $db->fetchAll($sql);
        echo "Will process total " . count($data) . " payment link..." . PHP_EOL;
        $paymentMdl = new Model_Payments();
        foreach ($data as $i => $row) {
            echo "Processing item Id: " . $row['custom_payment_id'] . " country:" . $row['country_id'] . ' phone-no length:' . strlen($row['contactNumber']) . PHP_EOL;
            if ($paymentMdl->_hasMigrated($row['token'])) {
                echo "custom_payment_id: " . $row['custom_payment_id'] . " is already migrated" . PHP_EOL;
                continue;
            }
            try {
                $payment = $paymentMdl->_formatOldPaymentsMigration($row);
                if ($payment == false) {
                    continue;
                }
                $params = $payment['order'];
                $params['items'][] = $payment['items'];
                $response = $paymentMdl->_migrate($params, $row);
                if ($response == false) {
                    continue;
                }
                $status = $paymentMdl->_updateMigrateStatus($response, $row);
                if ($status) {
                    echo "URL migrated for custom_payment_id: " . $row['custom_payment_id'] . PHP_EOL;
                } else {
                    echo "Failed to migrate URL of custom_payment_id: " . $row['custom_payment_id'] . PHP_EOL;
                }
            } catch (Exception $e) {
                echo "Exception:" . $e->getMessage() . PHP_EOL;
                continue;
            }
        }
    }

    /** Remove after Migration **/
    private function _updateMigrateStatus($params, $row){
        if($params['payment']['status'] = true &&
        !empty($params['cart']['token']) &&
        !empty($params['order']['token']) &&
        $params['crm_order'] == 'Success' &&
        $params['update_token'] = 'Success'){
            return $this->getDb()->update('ssvc.custom_payment_crm', array('new_token' => $params['order']['token']), "custom_payment_id = '" . intval($row['custom_payment_id']) . "'");
        }
        return false;
    }

    /** Remove after Migration **/
    private function _hasMigrated($authkey){
        $db = $this->getDb();
        $sql = $db->select()->from($this->_name)->where('old_token=?',$authkey);
        $data = $db->fetchAll($sql);
        if(count($data)>0){
            return true;
        }
        return false;
    }

    /** Remove after Migration **/
    public function _formatOldPaymentsMigration($row) {

        if (empty($row['country_id'])) {
            echo "CountryId is empty for custom_payment_id :{$row['custom_payment_id']}" . PHP_EOL;
            return false;
        }
        if (empty($row['city_id'])) {
            echo "CityId is empty for custom_payment_id :{$row['custom_payment_id']}" . PHP_EOL;
            return false;
        }
        if (empty($row['contactNumber'])) {
            echo "Contact is empty for custom_payment_id :{$row['custom_payment_id']}" . PHP_EOL;
            return false;
        }

        $countryMdl = new BaseApp_Dao_Country($row['country_id']);
        $cityMdl = new BaseApp_Dao_City($row['city_id']);

        if (!in_array($row['productType_name'], array('course', 'bundle'))) {
            echo "Invalid product type for custom_payment_id :{$row['custom_payment_id']}" . PHP_EOL;
            return false;
        }
        $productTypeId = $this->_getProductTypeMigration($row['productType_name']);
        if (empty($productTypeId)) {
            echo "Invalid product type {$row['productType_name']} for custom_payment_id :{$row['custom_payment_id']}" . PHP_EOL;
            return false;
        }
        $wsDates = '';
        if (!empty($row['workshop_id'])) {
            $mdl = new BaseApp_Dao_Workshop($row['workshop_id']);
            $wsDates = $mdl->dates;
        }

        $learnerEmail = $row['email'];
        if(!empty($row['additionalEmail'])){
            $learnerEmail = (string)trim($row['additionalEmail']);
        }


        $cloud6 = new BaseApp_Communication_Accounts();
        $data = $cloud6->getUserDetailsByEmail($row['paymentByEmail']);
        $taxProperty = $this->_getCurrencyDetailsByCountryMigration($row['country_id'], $cityMdl->region_name);
        $basePrice = $row['amount'] - $row['serviceTax'];
        $order = array(
            'type' => 'custom',
            'date' => $row['urlCreatedTime'],
            'billing_email' => $row['email'],
            'contact_number' => $row['contactNumber'],
            'country_id' => $row['country_id'],
            'country_name' => $countryMdl->name,
            'city_id' => $row['city_id'],
            'city_name' => $cityMdl->name,
            'region_name' => $cityMdl->region_name,
            'payment_method' => '',
            'learner_email' => $learnerEmail,
            'attachment' => '',
            'remark' => 'Custom payment migration date:' . date('Y-m-d '),
            'auth_token' => '',
            'ssvc_auth_key' => '',
            'status' => 1,
            'total_price' => $basePrice,
            'tax_properties' => json_encode($taxProperty['data']),
            'created_by' => isset($data['data']['uid'])?$data['data']['uid']:'',
            'created_at' => strtotime($row['created']),
            'tax_percentage' => $taxProperty['data']['totalTax'],
            'is_approved' => '',
            'order_number' => '',
            'reference_number' => '',
            'approved_by' => '',
            'attachment_upload_by' => '',
            'assign_log' => '',
        );
        $accessDay = $row['accessDays'];
        if(empty($row['accessDays'])){
            $accessDay = 90;
        }
        $items = array(
            'payment_id' => '',
            'product_id' => $row['course_id'],
            'product_type_id' => $productTypeId,
            'product_type_name' => $row['productType_name'],
            'product_name' => $row['course_name'],
            'training_type_id' => $row['trainingType_id'],
            'training_type_name' => $row['trainingTypeName'],
            'workshop_id' => $row['workshop_id'],
            'workshop_dates' => $wsDates,
            'access_days' => $accessDay,
            'discount_percentage' => '',
            'mrp' => $basePrice,
            'selling_price' => $basePrice,
            'elearning_ids' => '',
            'price_id' => $row['priceId']
        );
        $payment = array('order' => $order, 'items' => $items);
        return $payment;
    }

    /** Remove following function after migration **/
    private function _getCurrencyDetailsByCountryMigration($countryId, $stateName){
         if($countryId){
            $objCurrency = new BaseApp_Dao_Currency();
            $dataReturn = array();
            $currencyData = $objCurrency->getCurrencyDetailsV1($countryId);
            if(!empty($currencyData)){
                $dataReturn = array(
                    'code'=>$currencyData['code'],
                    'currency_id'=>$currencyData['currency_id'],
                    'tax'=>array()
                );
                $dataReturn['totalTax'] = $currencyData['serviceTax'];
                $dataReturn['invoiceAddress'] = $currencyData['invoiceAddress'];
                $dataReturn['invoiceString'] = $currencyData['invoiceString'];
                $dataReturn['registrationNumber'] = !empty($currencyData['registrationNumber']) ?$currencyData['registrationNumber'] : '';
                $dataReturn['currency_symbol']=!empty($currencyData['symbol_original']) ? $currencyData['symbol_original'] :'';
                if (!$currencyData['serviceTaxString']) {
                    $currencyData['serviceTaxString'] = 'Service Tax';
                }
                if ($countryId == INDIA_COUNTRY_ID) {
                    $taxBreakupNew = array();
                    $state = '';
                    $cityObj = new BaseApp_Dao_City();
                    $cityData = $cityObj->getDefaultCityData($countryId);
                    if (!empty($cityData) && $cityData['region_name']) {
                        $state = $cityData['region_name'];
                    }
                    if (!empty($state) && $state == $stateName) {
                        $dataReturn['tax'][STATE_GST_STRING] = array(
                            'percentage' => $dataReturn['totalTax']/2,
                            );
                        $dataReturn['tax'][CENTRE_GST_STRING] = array(
                            'percentage' => $dataReturn['totalTax']/2,
                            );
                    } else {
                        $dataReturn['tax'][INTEGRATED_GST_STRING] = array(
                            'percentage' => $dataReturn['totalTax'],
                            );
                    }
                } else {
                    $dataReturn['tax'][$currencyData['serviceTaxString']] = array(
                        'percentage' => $currencyData['serviceTax']
                    );
                }


                $resultArray = array('status'=>'success','data'=>$dataReturn);
            }
            else {
                $resultArray = array('status'=>'fail','message'=>'No data Found','data'=>array());
            }
         }else{
            $resultArray = array('status'=>'fail','message'=>'country Id is mandatory','data'=>array());
         }
         return $resultArray;
    }

    /** Remove following function after migration */
    private function _getProductTypeMigration($type) {
        $t = '';
        switch ($type) {
            case 'course':
                $t = 1;
                break;
            case 'bundle':
                $t = 2;
                break;
        }
        return $t;
    }


    private function _migrate($requestParams, $row) {
        $return = array();
        if (empty($requestParams)) {
            echo json_encode(array('status' => false, 'msg' => 'Invalid request params.', 'responseText' => ''));
            return false;
        }

        $data = [];
        foreach (['type', 'billing_email', 'learner_email', 'contact_number', 'country_id', 'country_name', 'city_id',
    'city_name', 'created_by', 'items', 'total_price', 'region_name', 'total_price', 'tax_properties',
    'tax_percentage'] as $field) {
            $data[$field] = $requestParams[$field];
        }

        // Validating and preparing elearning ids of payment items
        if (!is_array($requestParams['items']) || count($requestParams['items']) == 0) {
            echo json_encode(array('status' => false, 'msg' => 'Invalid payment items.'));
            return false;
        }

        // Validate discount
        foreach ($requestParams['items'] as $item) {
            $discountValidateResponse = Model_Payments::validateDiscount($item['product_type_id'], $item['product_id'], $item['discount_percentage']);
            if ($discountValidateResponse['status'] === false) {
                echo json_encode($discountValidateResponse);
                return false;
            }
        }

        $Payment = new Model_Payments();
        $response = $Payment->prepareElearnings($requestParams['items']);
        if (!$response['status']) {
            echo json_encode($response);
            return false;
            //exit;
        }
        $data['learner_email'] = rtrim($data['learner_email'], ',');
        $data['items'] = $requestParams['items'];
        $data['date'] = time();

        $response = $Payment->savePayment($data);
        $return['payment'] = $response;
        if (!$response['status']) {
            echo json_encode($response);
            return false;
        }

        $data['ip_address'] = $row['userIp'];
        $data['order_type'] = Model_Payments::TYPE_CUSTOM;
        $cartData = $Payment->pushToCart($data);
        $return['cart'] = $cartData;
        if (!$cartData) {
            Model_Payments::log(array('key' => 'CUSTOM_PAYMENT_ERROR', 'msg' => 'Unable to add to cart.', 'params' => $requestParams, 'trace' => array('METHOD' => __METHOD__, 'LINE' => __LINE__)));

            echo json_encode(array('status' => false, 'msg' => 'Unable to add to cart.'));
            return false;
        }

        $orderData = $Payment->createOrderFromCartData($cartData, $data);
        $return['order'] = $orderData;
        if (!$orderData) {
            Model_Payments::log(array('key' => 'CUSTOM_PAYMENT_ERROR','msg' => 'Unable to create ice9 order.', 'params' => $requestParams, 'trace' => array('METHOD' => __METHOD__, 'LINE' => __LINE__)));

            echo json_encode(array('status' => false, 'msg' => 'Unable to create ice9 order.'));
            return false;
        }
        try {
            $Payment->saveOrderInCRM($response['paymentId'], $orderData, array_merge($data, ['token' => $cartData['token']]), true);
            $return['crm_order'] = "Success";
        } catch (Exception $e) {
            $return['crm_order'] = "Failed";
            Model_Payments::log(array('key' => 'CUSTOM_PAYMENT_ERROR','msg' => 'Unable to create order. ' . $e->getMessage(), 'params' => $requestParams, 'trace' => array('METHOD' => __METHOD__, 'LINE' => __LINE__)));
            echo json_encode(array('status' => false, 'msg' => 'Unable to create order. ' . $e->getMessage()));
            return false;
        }

        try {
            $Payment->updateToken($response['paymentId'], $cartData['token']);
            $return['update_token'] = "Success";
        } catch (Exception $e) {
            $return['update_token'] = "Failed";
            Model_Payments::log(array('key' => 'CUSTOM_PAYMENT_ERROR', 'msg' => 'Unable to update payment token. ' . $e->getMessage(), 'params' => $requestParams, 'trace' => array('METHOD' => __METHOD__, 'LINE' => __LINE__)));
            echo json_encode(array('status' => false, 'msg' => 'Unable to update payment token. ' . $e->getMessage()));
            return false;
        }
        return $return;
    }

    public function getPaymentSubTypes() {
        return $this->_paymentSubTypes;
    }

    /**
     * Validate if the user attempting to do payment for Reseller Opening Account already has a payment with status 1.
     * @param type $email
     * @return string
     */
    public function validateAtpPayment($email = '') {
        $result = array('status' => false, 'msg' => '', 'data' => array());
        if (empty($email)) {
            $result['msg'] = "Unable to validate Atp Payment. Empty params passed.";
            return $result;
        }
        $orderMdl = new BaseApp_Dao_Melvin_Order();
        $rows = $orderMdl->fetchCount(array('userEmail = ? ' => $email, 'paymentType_id = ?' => BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_ATP_ACCOUNT_OPENING, 'paymentStatus = ?' => 1));
        if ($rows) {
            $result['status'] = false;
            $result['msg'] = "Please try different email id. Reseller account with this email already exists";
            $result['data'] = $rows;
            return $result;
        }
        $result['status'] = true;
        $result['msg'] = "success";
        $result['data'] = $rows;
        return $result;
    }

    public function prepareApprovalData( &$paymentItems) {
        $loggedInUserData = BaseApp_Auth::getLoggedInUserData();
        $managerRole = '';
        foreach ($paymentItems as &$items) {
            if (array_key_exists('user_role', $items) || array_key_exists('manager_role', $items)) {
                $managerRole = ($managerRole == self::$_roles[parent::B2C_SALES_DIRECTOR]) ? (self::$_roles[parent::B2C_SALES_DIRECTOR]) : $items['manager_role'];
                unset($items['user_role'], $items['manager_role']);
            }
        }

        $approvalRequestData = array(
            'userEmail' => $loggedInUserData['email'],
            'approvarRole' => $managerRole
        );
        return $approvalRequestData;
    }

    public function preparePartialApprovalData()
    {
      $loggedInUserData = BaseApp_Auth::getLoggedInUserData();
      $managerRole = self::$_roles[parent::B2C_SALES_DIRECTOR];
      $approvalRequestData = array(
          'userEmail' => $loggedInUserData['email'],
          'approvarRole' => $managerRole
      );
      return $approvalRequestData;
    }

    public function updateManagerEmailAndRoleInPayment($paymentId, $managerEmail, $approvalRole) {
        $return = false;
        try {
            if (!empty($managerEmail) && !empty($paymentId) && !empty($approvalRole)) {
                $return = $this->getDb()->update($this->_name, array('manager_email' => $managerEmail, 'discount_approval_role' => $approvalRole), "payment_id = $paymentId");
            }
            return $return;
        } catch (Exception $e) {
            Model_Payments::log(array('key' => 'CUSTOM_PAYMENT_ERROR', 'msg' => 'Unable to update mangerEmail And Role In Payment. ' . $e->getMessage(), 'paymentId' => $paymentId, 'trace' => array('METHOD' => __METHOD__, 'LINE' => __LINE__)));
        }
    }

    public function updateIsApproved($paymentId) {
        $return = false;
        try {
            if (!empty($paymentId)) {
                $return = $this->getDb()->update($this->_name, array('is_approved'=>BaseApp_Datatable_Payments::PAYMENT_DISCOUNT_REQUEST_FAILURE),"payment_id = $paymentId");
            }
            return $return;
        } catch (Exception $e) {
            Model_Payments::log(array('key' => 'CUSTOM_PAYMENT_ERROR', 'msg' => 'Unable to update is_approved in Payment. ' . $e->getMessage(), 'paymentId' => $paymentId, 'trace' => array('METHOD' => __METHOD__, 'LINE' => __LINE__)));
            return $return;
        }
    }

    public function updateDiscountApprovalStatus($data) {

        $result = ['status' => false, 'msg' => ''];

        if (!empty($data['payment_id'])) {
            $paymentId = $data['payment_id'];
        } else {
            $result['msg'] = 'Empty data.';
            return $result;
        }
        $paymentMdl = new Model_Payments();
        $db = $paymentMdl->getDb();
//     update payment details
        try {
            $paymentWhere = array('payment_id = ?' => $paymentId, 'approval_status =?' => 0 ,'approval_required =?'=> 1);
            if ($data['status'] == 1) {
                $paymentCols = array('is_approved' => BaseApp_Datatable_Payments::PAYMENT_DEFAULT, 'approval_status' => 1);//'approval_status' => 1 i.e.approved
                $result['msg'] = 'Order approved successfully.';
            } elseif ($data['status'] == 2) {
                $paymentCols = array('is_approved' => BaseApp_Datatable_Payments::PAYMENT_DISCOUNT_APPROVE_REJECTED, 'approval_status' => 2);//'approval_status' => 2 i.e.rejected
                $result['msg'] = 'Order rejected successfully.';
            }
            $updateResult = $this->updatePaymentDetails($db, $paymentCols, $paymentWhere);
            if (empty($updateResult)) {
                $result['msg'] = 'Some Error Ocurred in Updating Order Status.';
                return $result;
            }
            $result['status'] = true;
            return $result;
        } catch (Exception $ex) {
            $result['msg'] = 'Some Error Occurred while updating approval status';
            Model_Payments::log(array('KEY' => 'CUSTOM_PAYMENT_ERROR', 'METHOD' => 'update discount approval', 'PAYMENT_ID' => $paymentId, 'ERROR' => $ex->getMessage(), 'TRACE' => array('METHOD' => __METHOD__, 'LINE' => __LINE__)));
            return $result;
        }
    }
}
