<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_Venues extends BaseApp_Dao_Venues{

	public function getVenueId($countryId,$cityId){
		$whereArr = array('country_id in (?)'=>array($countryId));
		if(!empty($cityId))
			$whereArr['city_id'] = array($cityId);
		$venueIds = array();
		$venueData = $this->fetchAll($whereArr,array('columns'=>array('venue_id')));
		if(empty($venueData))
			return $venueIds;
		foreach ($venueData as $key => $value) {
			array_push($venueIds,$value['venue_id']);
		}
		return $venueIds;
	}

} // End of Class