<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_B2bAgencyDetails extends BaseApp_Dao_B2bAgencyDetails{	

} // End of Class