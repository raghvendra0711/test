<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Model_B2bProductExclusions extends BaseApp_Dao_B2bProductExclusions {

    const OPTIONS_INCLUDE = true;
    const OPTIONS_EXCLUDE = false;

    public function saveB2BProductExclusions($companyId, $linkableType, $dataArr) {
        try {
            $fields = array('company_id =?'=>$companyId,'linkable_type =?'=>$linkableType,'status =?'=>1);

            $checkExisting = $this->fetchAll($fields);
            if(!empty($checkExisting)){
                foreach ($checkExisting as $key => $value) {
                    $this->clean();
                    $this->setId($value['id']);
                    $this->setFromArray(array('status'=>0))->update();
                }
            }
            if(!empty($dataArr)){
                foreach ($dataArr as $key => $value) {
                    $this->clean();
                    $value['linkable_type'] = $linkableType;
                    $value['company_id'] = $companyId;
                    $this->setFromArray($value)->save();
                }
            }
            return true;
        }catch (Exception $e){
            if (APPLICATION_ENV == 'development')
                throw $e;
           return false;
        }
    }

    public function saveB2bExclusionsInCompanies($linkableType, $productId, $agencyIds = array(), $agencyOption = self::OPTIONS_INCLUDE) {
        $b2bCompany = new Model_B2BCompanies();
        $query = '';
        $db = $this->getDb();
        if ($linkableType === BaseApp_Dao_ProductTypes::PRODUCT_NAME_FOR_BUNDLES) {
            if (empty($agencyIds)) {
                $query = "
                INSERT INTO b2b_product_exclusions 
                    (linkable_type, linkable_id, company_id, status) 
                select 
                    distinct '$linkableType', '$productId', category.company_id as company_id, '1'
                from companyProductMapping category 
                join bundles on (
                    bundles.primary_label_id = category.linkable_id
                    OR FIND_IN_SET(category.linkable_id, bundles.label_id) > 0
                )
                join productSectionData companyProductType on category.company_id = companyProductType.company
                where 
                    bundles.status = 1 and bundles.bundle_id = '$productId'
                    and category.linkable_type='category' and category.status = 1 
                    and companyProductType.sectionType='b2bProductType' and companyProductType.status = 1 and companyProductType.description = 'bundle'
                ";
            } else if (is_array($agencyIds)) {
                $agencyOptionStr = "in";
                if ($agencyOption == self::OPTIONS_EXCLUDE) {
                    $agencyOptionStr = "not in";
                }
                $agencyStr = '"' . implode('","', $agencyIds) . '"';
                $query = "INSERT INTO b2b_product_exclusions 
                    (linkable_type, linkable_id, company_id, status) 
                select 
                    distinct '$linkableType', '$productId', category.company_id as company_id, '1'
                from productSectionData company
                join productSectionData agency on agency.company = company.id
                join b2bAgencyDetails  agency_mapping on agency_mapping.agency_id = agency.id
                join companyProductMapping category on category.company_id = company.id
                join bundles on (
                    bundles.primary_label_id = category.linkable_id
                    OR FIND_IN_SET(category.linkable_id, bundles.label_id) > 0
                )
                join productSectionData companyProductType on category.company_id = companyProductType.company
                where 
                    bundles.status = 1 and bundles.bundle_id = '$productId' and
                    category.linkable_type='category' and category.status = 1 and
                    company.sectionType='company' and company.status = 1 and 
                    agency.sectionType='agency' and agency.status = 1 and
                    agency_mapping.status = 1 and
                    agency_mapping.gid $agencyOptionStr ($agencyStr)
                    and companyProductType.sectionType='b2bProductType' and companyProductType.status = 1 and companyProductType.description = 'bundle'
                ";
            }
            if(empty($agencyIds)){
                $sqlQuery = "
                select 
                    distinct '$linkableType', '$productId', category.company_id as company_id, '1'
                from companyProductMapping category 
                join bundles on (
                    bundles.primary_label_id = category.linkable_id
                    OR FIND_IN_SET(category.linkable_id, bundles.label_id) > 0
                )
                join productSectionData companyProductType on category.company_id = companyProductType.company
                where 
                    bundles.status = 1 and bundles.bundle_id = '$productId'
                    and category.linkable_type='category' and category.status = 1 
                    and companyProductType.sectionType='b2bProductType' and companyProductType.status = 1 and companyProductType.description = 'bundle'
                ";
                $companyData = $db->fetchAll($sqlQuery);
            } else if(is_array($agencyIds)){
                $agencyOptionStr = "in";
                if ($agencyOption == self::OPTIONS_EXCLUDE) {
                    $agencyOptionStr = "not in";
                }
                $agencyStr = '"' . implode('","', $agencyIds) . '"';
                $sqlQuery = "
                select 
                    distinct '$linkableType', '$productId', category.company_id as company_id, '1'
                from productSectionData company
                join productSectionData agency on agency.company = company.id
                join b2bAgencyDetails  agency_mapping on agency_mapping.agency_id = agency.id
                join companyProductMapping category on category.company_id = company.id
                join bundles on (
                    bundles.primary_label_id = category.linkable_id
                    OR FIND_IN_SET(category.linkable_id, bundles.label_id) > 0
                )
                join productSectionData companyProductType on category.company_id = companyProductType.company
                where 
                    bundles.status = 1 and bundles.bundle_id = '$productId' and
                    category.linkable_type='category' and category.status = 1 and
                    company.sectionType='company' and company.status = 1 and 
                    agency.sectionType='agency' and agency.status = 1 and
                    agency_mapping.status = 1 and
                    agency_mapping.gid $agencyOptionStr ($agencyStr)
                    and companyProductType.sectionType='b2bProductType' and companyProductType.status = 1 and companyProductType.description = 'bundle'
                ";
                $companyData = $db->fetchAll($sqlQuery); 
            }
            $companyIds = array();
            foreach($companyData as $key => $value){
                $companyIds[] = !empty($value['company_id']) ? $value['company_id'] : "";
            }

        } else {
            if (empty($agencyIds)) {
                $query = "
                INSERT INTO b2b_product_exclusions 
                    (linkable_type, linkable_id, company_id, status) 
                select 
                    distinct '$linkableType', '$productId', category.company_id as company_id, '1'
                from companyProductMapping category 
                join courses on (
                    courses.primary_label_id = category.linkable_id
                    OR FIND_IN_SET(category.linkable_id, courses.label_id) > 0
                )
                where 
                    courses.course_id = $productId and courses.status = 1 and
                    category.linkable_type='category' and category.status = 1";
            } else if (is_array($agencyIds)) {
                $agencyOptionStr = "in";
                if ($agencyOption == self::OPTIONS_EXCLUDE) {
                    $agencyOptionStr = "not in";
                }
                $agencyStr = '"' . implode('","', $agencyIds) . '"';
                $query = "INSERT INTO b2b_product_exclusions 
                    (linkable_type, linkable_id, company_id, status) 
                select 
                    distinct '$linkableType', '$productId', category.company_id as company_id, '1'
                from productSectionData company
                join productSectionData agency on agency.company = company.id
                join b2bAgencyDetails  agency_mapping on agency_mapping.agency_id = agency.id
                join companyProductMapping category on category.company_id = company.id
                join courses on (
                    courses.primary_label_id = category.linkable_id
                    OR FIND_IN_SET(category.linkable_id, courses.label_id) > 0
                )
                where 
                    courses.course_id = $productId and courses.status = 1 and
                    category.linkable_type='category' and category.status = 1 and
                    company.sectionType='company' and company.status = 1 and 
                    agency.sectionType='agency' and agency.status = 1 and
                    agency_mapping.status = 1 and
                    agency_mapping.gid $agencyOptionStr ($agencyStr)
                ";
            }
            if(empty($agencyIds)){
                $sqlQuery = "
                select 
                    distinct '$linkableType', '$productId', category.company_id as company_id, '1'
                from companyProductMapping category 
                join courses on (
                    courses.primary_label_id = category.linkable_id
                    OR FIND_IN_SET(category.linkable_id, courses.label_id) > 0
                )
                where 
                    courses.course_id = $productId and courses.status = 1 and
                    category.linkable_type='category' and category.status = 1";

                $companyData = $db->fetchAll($sqlQuery);

            }else if(is_array($agencyIds)){
                $agencyOptionStr = "in";
                if ($agencyOption == self::OPTIONS_EXCLUDE) {
                    $agencyOptionStr = "not in";
                }
                $agencyStr = '"' . implode('","', $agencyIds) . '"';
                $sqlQuery = "
                select 
                    distinct '$linkableType', '$productId', category.company_id as company_id, '1'
                from productSectionData company
                join productSectionData agency on agency.company = company.id
                join b2bAgencyDetails  agency_mapping on agency_mapping.agency_id = agency.id
                join companyProductMapping category on category.company_id = company.id
                join courses on (
                    courses.primary_label_id = category.linkable_id
                    OR FIND_IN_SET(category.linkable_id, courses.label_id) > 0
                )
                where 
                    courses.course_id = $productId and courses.status = 1 and
                    category.linkable_type='category' and category.status = 1 and
                    company.sectionType='company' and company.status = 1 and 
                    agency.sectionType='agency' and agency.status = 1 and
                    agency_mapping.status = 1 and
                    agency_mapping.gid $agencyOptionStr ($agencyStr)
                ";
                $companyData = $db->fetchAll($sqlQuery);
            }
            $companyIds = array();
            foreach($companyData as $key => $value){
                $companyIds[] = !empty($value['company_id']) ? strval($value['company_id']) : "";
            }
        }
        if (empty($query)) {
            throw new Exception("invalid args in saveB2bExclusionsInCompanies. " . json_encode(func_get_args()));
        }
        
        $result = $db->query($query);
        $b2bCompany->insertProductExclusionData($linkableType, $productId,$companyIds);
        return $result;
    }

    public function removeProductFromExclutions($linkableType, $linkableId, $agencyIds = array(), $agencyOption = self::OPTIONS_INCLUDE) {
        $b2bCompany = new Model_B2BCompanies();
        if (empty($agencyIds)) {
            $query = "
                update b2b_product_exclusions 
                set status = 0
                where linkable_type = '$linkableType' and linkable_id = '$linkableId' and status = 1
            ";

        } else if (is_array($agencyIds)) {
            $agencyStr = '"' . implode('","', $agencyIds) . '"';
            $agencyOptionStr = "in";
            if($agencyOption == self::OPTIONS_EXCLUDE) {
                $agencyOptionStr = "not in";
            }
            $query = "
            update b2b_product_exclusions 
                set status = 0
            where linkable_type = '$linkableType' and linkable_id = '$linkableId' and status = 1 and 
                company_id $agencyOptionStr (
                    select 
                        company.id
                    from productSectionData company
                    join productSectionData agency on agency.company = company.id
                    left join b2bAgencyDetails  agency_mapping on agency_mapping.agency_id = agency.id
                    where 
                        company.sectionType='company' and company.status = 1 and 
                        agency.sectionType='agency' and agency.status = 1 and
                        agency_mapping.status = 1 and
                        agency_mapping.gid in ($agencyStr)
                )
            ";
        }
        if (empty($query)) {
            throw new Exception("invalid args in removeProductFromExclutions. " . json_encode(func_get_args()));
        }
        $db = $this->getDb();
        $result = $db->query($query);
        $b2bCompany->updateExclusionList($linkableType, $linkableId);

        return $result;
    }
} // End of Class