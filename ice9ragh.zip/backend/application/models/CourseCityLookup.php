<?php

class Model_CourseCityLookup extends BaseApp_Dao_CourseCityLookup {

    public function getLookupIdData($courseId, $cityId, $prodcutTypeId = null) {
        $data = parent::getLookupIdData($courseId, $cityId, $prodcutTypeId);
        return $data;
    }

}
