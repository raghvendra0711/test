<?php

class Model_FptFaqs extends BaseApp_Dao_FptFaqs {

    public function getNameById($cityIds = array()) {
        $conds = array();
        $return = array();
        if ($cityIds) {
            $conds['city_id IN (?)'] = $cityIds;
        }
        $this->setFetchDisabled(true);
        foreach ($this->fetchAll($conds) as $cityData) {
            $return[$cityData['city_id']] = $cityData['name'];
        }
        $this->setFetchDisabled(false);
        return $return;
    }

    public function getCourseList() {
        $result = array();
        $courseList = parent::getSeoEnabledCourseList();
        if (!empty($courseList)) {
            $result = $courseList;
        }
        return $result;
    }

    public function getCourseFaqs($productId,$productType) {
        $reponse = $courseFaqs = $mergedCourseFaqs = $inActiveParentFaqs = array();
        if (!empty($productId) && !empty($productType)) {
            $result = parent::getCourseFaqs($productId,$productType);
            $mergedCourseFaqs = !empty($result['mergedFaqs']) ? $result['mergedFaqs'] : array();
            if (!empty($mergedCourseFaqs))
                foreach ($mergedCourseFaqs as $row) {
                    $row['is_parent'] = false;
                    $row['is_clone'] = false;
                    $row['action'] = 'Edit';
                    $courseFaqs[] = $row;
                }
        }
        $reponse = array('courseFaqs' => $courseFaqs);
        return $reponse;
    }

    public function updateFptPageFaqs($courseFaqId, $answer, $question, $type, $productId, $productType, $parentLookupId, $mapId) {
        $response = array('status' => false, 'msg' => null);
        $cityId = '';
        $dataSave = $dataDisableMapping = array();
        if (!empty($productId) && !empty($productType) && !empty($answer) && !empty($question)) {
            $db = $this->getDb();
            try {
                $db->beginTransaction();
                $objCourseCityLookUp = new Model_CourseFptLookup();
                $lookUpData = $objCourseCityLookUp->getLookupIdData($productId,$productType);
                if (!empty($lookUpData)) {
                    $lookupId = $lookUpData['id'];
                    $currentStatus = 1;
                    $jumpToSection = 0;
                    $order = 0;
                    /**
                     * Update Course City Faq
                     */
                    $updateCoursecityFaq = array(
                        'question' => $question,
                        'answer' => $answer,
                        'status' => $currentStatus,
                        'jump_to_section' => (int) $jumpToSection
                    );
                    $objCourseFaq = new Model_CourseFaq();
                    $objCourseFaq->setId($courseFaqId);
                    $objCourseFaq->setFromArray($updateCoursecityFaq)->update();
                    /**
                     * Update Order In Course Mapping 
                     */
                    /* $updateCourseMappingData = array('order' => (int) $order, 'status' => $currentStatus);
                    $objCourseResourceMapping = new Model_CourseResourceMapping();
                    $objCourseResourceMapping->setId($mapId);
                    $objCourseResourceMapping->setFromArray($updateCourseMappingData)->update(); */
                    $response = array('status' => true, 'msg' => 'Success', 'data' => array('map_id' => $mapId, 'order' => (int) $order, 'faq_id' => $courseFaqId, 'lookup_id' => $lookupId));
                    $db->commit();
                }
            } catch (Exception $e) {
                $db->rollBack();
                $response = array('status' => false, 'msg' => $e->getMessage());
            }
        }
        return $response;
    }

    public function getLinkableTypeByProductTypeId($productTypeId) {
        $linkableType = BaseApp_Dao_Courses::PRODUCT_TYPE_NAME;
        switch(strval($productTypeId)) {
            case strval(BaseApp_Dao_Bundles::PRODUCT_TYPE_ID): $linkableType = BaseApp_Dao_Bundles::PRODUCT_TYPE_NAME; break;
        }
        return $linkableType;
    }

    public function addMoreQuestionAnswer($answer, $question, $productId,$productTypeId) {
        $response = array('status' => false, 'msg' => null);
        $dataSave = $dataDisableMapping = array();
        $productType = $this->getLinkableTypeByProductTypeId($productTypeId);
        if (!empty($productId) && !empty($productType) && !empty($answer) && !empty($question)) {
            $db = $this->getDb();
            try {

                $db->beginTransaction();
                $objCourseCityLookUp = new Model_CourseCityLookup();
                $lookupResult = $objCourseCityLookUp->getLookUpIdOfCourseId($productId,$productType);
                $pLookUpId = 0;
                if (!empty($lookupResult)) {
                    $row = current($lookupResult);
                    $pLookUpId = $row['id'];
                }

                if (empty($pLookUpId)) {
                    $dataCourseCityLookup = array('course_id' => (int) $productId,'linkable_type' => $productType, 'status' => 1);
                    $res = $objCourseCityLookUp->setFromArray($dataCourseCityLookup)->save();
                    $pLookUpId = (int) $objCourseCityLookUp->id;
                }

                if ($pLookUpId) {
                    $maxExistingOrderVal = 0;
                    $objCourseResourceMapping = new Model_CourseResourceMapping();
                    $dataSave = array(
                        'type' => (int) BaseApp_Dao_FptFaqs::FPT_FAQ_TYPE,
                        'question' => $question,
                        'answer' => $answer,
                        'status' => 1,
                        'training_id' => (int) BaseApp_Dao_FptFaqs::FPT_FAQ_TRAINING_ID,
                        'is_b2c' => 1
                    );

                    $objCourseFaq = new Model_CourseFaq();
                    $status = $objCourseFaq->setFromArray($dataSave)->save();
                    if ($status) {
                        $fptFaqId = (int) $objCourseFaq->course_faq_id;
                        $courseResourceMappingModel = new BaseApp_Dao_CourseResourceMapping();
                        $lastOrder = $courseResourceMappingModel->getMaxOrderByLookupId($pLookUpId, BaseApp_Dao_FptFaqs::FPT_FAQ_TYPE, 0);
                        $maxExistingOrderVal = $lastOrder + BaseApp_Dao_CourseResourceMapping::ORDER_STEP;

                        /**
                         * Mapping Of Lookup Id and City Course Faq Id
                         */
                        if ($pLookUpId && $fptFaqId) {
                            $courseResourceMappingData = array('lookup_id' => $pLookUpId, 'faq_id' => $fptFaqId, 'status' => 1,'order' => $maxExistingOrderVal);
                            if ($objCourseResourceMapping->setFromArray($courseResourceMappingData)->save()) {
                                $mapId = (int) $objCourseResourceMapping->id;
                                $response = array('status' => true, 'msg' => 'Success', 'data' => array('map_id' => $mapId, 'faq_id' => $fptFaqId, 'lookup_id' => $pLookUpId));
                                $db->commit();
                            }
                        }
                    }
                }
            } catch (Exception $e) {
                $db->rollBack();
                $response = array('status' => false, 'msg' => $e->getMessage());
            }
            return $response;
        }
    }

    public function getAllCourseCity() {
        $result = parent::getCourseCities();
        return $result;
    }

}
