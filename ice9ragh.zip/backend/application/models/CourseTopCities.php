<?php
class Model_CourseTopCities extends BaseApp_Dao_CourseTopCities{	
    
}