<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Model_PartPaymentBreakups extends BaseApp_Dao_PartPaymentBreakups{

    public function saveBreakup($partPaymentData){
        $db = $this->getDb();
        $objSubPartPayment = new self();
        // $db->beginTransaction();
        try{
            $objSubPartPayment->clean();
            $objSubPartPayment->setFromArray($partPaymentData)->save();
            // $db->commit();
            return true;
        }
        catch (Exception $e){
            // $db->rollBack();
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }

    public function getBreakUpBySubscriptionId($subscriptionId){
        
        $conds = array(
            'subscription_id=?' => $subscriptionId,
            'status=?'=> 1
        );
        
        $options = array(
            'order' => array(
                array('installment_number')
            )
        );

        return $this->fetchAll($conds,$options);
    }

    public function deleteBreakup($subscriptionId){
        $db = $this->getDb();
        $objSubPartPayment = new self();
        // $db->beginTransaction();
        try{
            $properties = $objSubPartPayment->fetchAll(array("subscription_id = ?" => $subscriptionId, 'status=?'=>1));
            foreach($properties as $property){
                $objSubPartPayment->clean();
                $objSubPartPayment->setId($property['id']);
                $objSubPartPayment->delete();
            }
            $objSubPartPayment->clean();
            // $db->commit();
            return true;
        }
        catch (Exception $e){
            // $db->rollBack();
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }
}