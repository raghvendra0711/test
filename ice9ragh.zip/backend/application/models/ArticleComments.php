<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_ArticleComments extends BaseApp_Dao_ArticleComments{	
    
    public function _afterFetchAll($data){   
        $articles =array();
        foreach($data as $row) {
            if($row['article_id']) {
                $articles[] = $row['article_id'];
            }            
        }
        if($articles) {
            $articleMode = new Model_Articles();
            $articles = $articleMode->fetchForSelect(array('article_id IN (?)' => $articles));
        }
        
        foreach($data as &$row) {
            if($row['article_id']) {
                $row['articleName'] = isset($articles[$row['article_id']])? $articles[$row['article_id']]:'';
            }
            $row['time_created'] = date('Y-m-d H:i:s', $row['create_time']);            
        }
        return $data;
    }
} // End of Class