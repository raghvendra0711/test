<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_SearchField extends BaseApp_Dao_SearchField{	

} // End of Class