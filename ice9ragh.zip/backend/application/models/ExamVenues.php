<?php
/**
 * @author Akash Agarwal <akash.agarwal@simplilearn.net>
 */
class Model_ExamVenues extends BaseApp_Dao_ExamVenues
{

    protected function _beforeSave() {
        if(!self::isVenueExists($this->_data))
        {
            $loggedInUserData = BaseApp_Auth::getLoggedInUserData();
            $this->_data['updated_by'] = $this->_data['created_by'] = $loggedInUserData['id'];
            $this->_data['created_on'] = $this->_data['updated_on'] = time();
            unset($this->_data['country_name']);
            return true;
        }
        return false;
    }
    
    public static function isVenueExists($data) {
        $examVenueObj = new self();
        $condition = array(
            'city_id=?' => $data['city_id'],
            'venue_name=?' => $data['venue_name'],
        );
        //for edit condition
        if(!empty($data['venue_id'])){
                 $condition['venue_id !=?'] = $data['venue_id'];
        }
        $count = $examVenueObj->fetchCount($condition);
        if ($count) {
            return true;
        }
        return false;
    }

    protected function _beforeUpdate() {
        $loggedInUserData = BaseApp_Auth::getLoggedInUserData();
        $this->_data['updated_by'] = $loggedInUserData['id'];
        $this->_data['updated_on'] = time();
        unset($this->_data['country_name'], $this->_data['city_id']);
        return true;
    }

}