<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_Groups extends BaseApp_Dao_Groups{	

    public function createGroup($request) {
        $db = $this->getDb();
        $objGroup = new self();
        $pageUrl = '';
        $db->beginTransaction();
	try{
            if(isset($request['url'])) {
                $pageUrl = trim($request['url']);
                $checkSlash = substr($pageUrl, 0,1);
                if($checkSlash != '/'){
                    $pageUrl = trim('/'.$pageUrl);
                }
                $objGroup->setPageUrl($pageUrl);
                unset($request['url']);
            }
            $objGroup->setFromArray($request)->save();
            $dataSave = array(
                'controller' => self::SEO_DEFAULT_CONTROLLER,
                'action' => self::SEO_DEFAULT_ACTION,
                'params' => json_encode(array(self::SEO_DEFAULT_PARAM_KEY=>$objGroup->group_id)),
                'linkable_id' => $objGroup->group_id,
                'linkable_type' => 'group'
            );
            $modelSeo = new Model_Seo();
            $seoData = $modelSeo->getDataByUrl($pageUrl);
            $modelSeo->setId($seoData['seo_id']);
            $modelSeo->setFromArray($dataSave)->update();
            $db->commit();
            return $objGroup->group_id;
        }
        catch (Exception $e){
            $db->rollBack();
            return false;
        }
    }
    
    public function updateGroup($data) {
        $db = $this->getDb();
        $objGroup = new self();
        $db->beginTransaction();
	try{
            $objGroup->setId($data['group_id']);
            $objGroup->setFromArray($data)->update();             
            $db->commit();
            return true;
        }
        catch (Exception $e){
            $db->rollBack();
            return false;
        }
    }
    public function getEnterpriseList() {
        $accountsObj = new BaseApp_Communication_Accounts();
        $data = $accountsObj->getEnterpriseList();
        $returnArr = array();

        if(!$data) return $returnArr;
        
        foreach($data as $d) {
            $returnArr[] = array('id' => $d['gid'], 'name' => $d['lmsName'] . ' - ' . $d['gid']);
        }
        
        return $returnArr;
    }

    public function setEnterpriseList($params) {
        $accountsObj = new BaseApp_Communication_Accounts();
        $data = $accountsObj->setEnterpriseCourseMappingData($params);
        
        return $data;
    }

    public function getPrePolulateEnterpriseList($prePopulateParams) {
        $accountsObj = new BaseApp_Communication_Accounts();
        $data = $accountsObj->getEnterpriseCourseMappingData($prePopulateParams);
        
        if(empty($data)) return array();

        if(!isset($data['data'])) return array();

        $returnArr = array();

        foreach($data['data'] as $d) {
            $returnArr[] = array('id' => $d['gid'], 'name' => $d['lmsName'] . ' - ' . $d['gid']);
        }
        
        return $returnArr;
    }
    
} // End of Class