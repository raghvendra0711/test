<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_Workshop extends BaseApp_Dao_Workshop{	

	public $countryIdsList;
	
	protected $workShopStatus = array('active'=>'active','inactive'=>'inactive','complete'=>'complete');

    
	public function getStatus (){
		return $this->workShopStatus;
	}	        

    public function createWorkShop($data) {
        $db = $this->getDb();
        $objWorkshop = new self();
        $db->beginTransaction();
        try{
            $batchId = time();
            if(is_array($data['country_id'])) {
                $countryIds = $data['country_id'];
            }
            else {
                $countryIds = array($data['country_id']);
            }
            unset($data['country_id']);
            $modelCountry = new Model_Country();
            $currentTimeZone = $data['timeZone'];
            foreach($countryIds as $countryId) {                    
                $data['country_id'] = $countryId;
                $data['batch_id'] = $batchId;     
                if((!$requiredTimeZone = $modelCountry->getTimeZone($countryId)) || ($requiredTimeZone == 'UTC')) {
                    $requiredTimeZone = DEFAULT_COUNTRY_TIME_ZONE;
                }
                foreach($this->getFormatedDates($data['dates'], $data['fromTime'], $data['toTime'], $data['timeZone']) as $fieldName => $fieldValue) {
                    $data[$fieldName] = $fieldValue;
                }
                $data['timeZone'] = $requiredTimeZone;
                $data['savedTimezone'] = $currentTimeZone;
                $objWorkshop->setFromArray($data)->save();
            }
            $db->commit();
            return true;
        }
        catch (Exception $e){
            $db->rollBack();
            prd($e->getMessage());
            return false;
        }
    }

    public function updateWorkShopByBatchId($batchId, $data) {
        $db = $this->getDb();
        $objWorkshop = new self();
        $db->beginTransaction();
        $modelCountry = new Model_Country();
        try{                              
            $data['dates'] = $data['dates_edit'];                
            unset($data['dates_edit']);
            if(!empty($data['ven_id'])){
                $data['venue_id'] = $data['ven_id'];
            }
            unset($data['ven_id']);
            $conds = array('batch_id=?'=>$batchId);
            $properties = $objWorkshop->fetchAll($conds, array(), false);
            $dataOld = array();  
            $countries = $data['country_id'];
            unset($data['country_id']);
            foreach($properties as $property){
                $objWorkshop->clean();
                $objWorkshop->setId($property['workshop_id']);               
                $dataOld = $property;
                $dataSave = $data;
                if(in_array($property['country_id'], $countries)) {

                    if((!$requiredTimeZone = $modelCountry->getTimeZone($property['country_id'])) || ($requiredTimeZone == 'UTC')) {
                        $requiredTimeZone = DEFAULT_COUNTRY_TIME_ZONE;
                    }
                    foreach($this->getFormatedDates($data['dates'], $data['fromTime'], $data['toTime'], $data['timeZone']) as $fieldName => $fieldValue) {
                        $dataSave[$fieldName] = $fieldValue;
                    }
                                        $dataSave['timeZone'] = $requiredTimeZone;                                                
                    $objWorkshop->setFromArray($dataSave)->update();
                    $index = array_search($property['country_id'], $countries);
                    unset($countries[$index]);                                              
                }
                else {
                    $objWorkshop->delete();                                            
                }
            }                                 
            foreach($countries as $countryId){
                $dataSave = $dataOld;
                foreach($data as $dataField => $dataValue) {
                    $dataSave[$dataField] = $dataValue;
                }
                $dataSave['country_id'] = $countryId;
                $dataSave['trainer_id'] = $data['trainer_id'];
                $dataSave['batch_id'] = $batchId;                    
                if((!$requiredTimeZone = $modelCountry->getTimeZone($countryId)) || ($requiredTimeZone == 'UTC')) {
                    $requiredTimeZone = DEFAULT_COUNTRY_TIME_ZONE;
                }
                foreach($this->getFormatedDates($data['dates'], $data['fromTime'], $data['toTime'], $data['timeZone']) as $fieldName => $fieldValue) 
                {
                    $dataSave[$fieldName] = $fieldValue;
                }
                $dataSave['timeZone'] = $requiredTimeZone;
                $objWorkshop->clean();
                $objWorkshop->setFromArray($dataSave)->save();
            } 
            $db->commit();
            return true;
        }
        catch (Exception $e){
            $db->rollBack();
            throw $e;
            return false;
        }
    }

    public function updateWorkShopById($Id, $data) {
        $db = $this->getDb();
        $objWorkshop = new self();
        $db->beginTransaction();
        try{
            if(array_key_exists('dates_edit', $data) && !empty($data['dates_edit'])){
                $workshopDates = explode(',',$data['dates_edit']);
                $data['dates'] = $data['dates_edit'];
                $data['startDate'] = date('Y-m-d', strtotime(current($workshopDates)));
                $data['endDate'] = date('Y-m-d', strtotime(end($workshopDates)));
            }
            if(!empty($data['ven_id'])){
                $data['venue_id'] = $data['ven_id'];
            }
            unset($data['ven_id']);
            unset($data['dates_edit']);
            $objWorkshop->clean();
            $objWorkshop->setId($Id);
            if(!$objWorkshop->setFromArray($data)->update()) {
                return false;
            }           
            $db->commit();
            return true;
        }
        catch (Exception $e){
            $db->rollBack();
            throw $e;
            return false;
        }
    }

    public function markWorkshop($Id, $data) {
        // mark IsSold or InActive
        $db = $this->getDb();
        $objWorkshop = new self();
        try{
            $objWorkshop->getDb()->update($objWorkshop->getName(), 
                                          $data, 
                                          array('batch_id = ?' => $Id)
                                      );
            return true;
        }
        catch (Exception $e){
            $db->rollBack();
            throw $e;
            return false;
        }
    }

    public function _afterFetchAll($data){
        $courses = array();
        $countries = array();
        $cities = array();
        $venues = array();
        $traininers = array();
        $acessDays = array();

        foreach($data as $row){
           $courses[] = $row['course_id'];
           $countries[] = $row['country_id'];
           if($row['city_id']) {
                $cities[] = $row['city_id'];
           }
           if($row['venue_id']) {
               $venues[] = $row['venue_id'];
           }
           if($row['trainer_id']) {
               $traininers[] = $row['trainer_id'];
           }           
        }

        $courseMdl = new Model_Courses();
        $courses = $courseMdl->getCourseByIdMultiple($courses);

        $modelTraining = new Model_TrainingTypes();
        $trainings = $modelTraining->getTrainingTypes();

        $country = new Model_Country();
        $countries = $country->getById($countries);

        if($cities) {
            $city = new Model_City();
            $cities = $city->getNameById($cities);
        }        

        $access = new Model_AccessDays();
        $acessDays = $access->getAccessDaysById();

        if($venues) {
            $modelVenue = new Model_Venues();
            $venues = $modelVenue->fetchForSelect(array('venue_id IN (?)' => $venues));
        }

        if($traininers) {
            $modelTrainer = new Model_Trainers();
            $traininers = $modelTrainer->fetchForSelect(array('trainer_id IN (?)' => $traininers));
        }
        foreach($data as &$row){
            $row['Course'] = @$courses[$row['course_id']];
            unset($row['course_id']);

            $row['Country'] = @$countries[$row['country_id']];
            unset($row['country_id']);

            $row['Training Type'] = @$trainings[$row['training_id']];

            $row['City'] = @$cities[$row['city_id']];
            unset($row['city_id']);

            $row['Venue'] = @$venues[$row['venue_id']];
            unset($row['venue_id']);

            $row['Trainer'] = @$traininers[$row['trainer_id']];
            unset($row['trainer_id']);

            $row['Access Days'] = @$acessDays[$row['access_day_id']];
            unset($row['access_day_id']);
        }
        unset($courses);
        unset($countries);
        unset($trainings);
        unset($cities);
        unset($venues);
        unset($traininers);
        unset($acessDays);        
        return $data;
    }

    public function getByCourse($courseId) {
        return $this->fetchAll(array('course_id=?'=>$courseId, 'isSold = ?' => 0,'endDate >= ?'=>date('Y-m-d')), array('columns' => array('training_id', 'access_day_id')), false);
    }

    public function getDetailByCourse($country_id,$city_id=null,$course_id,$date_formate = null) {
        if($date_formate == null)
        $date_formate = 'd/m/Y';        
        $today_date = date('Y-m-d');   
        $twoWeekBack = strtotime ( '-2 week' , strtotime ( $today_date ) ) ;
        $today = date('Y-m-d',$twoWeekBack);
        $trainingType_id = BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM;
        // $package = new Model_TrainingRelations();
        // $packages = $package->fetchAll(array( 'linkable_id = ?' => $course_id,
        //                                       'linkable_type =?'=>'course',
        //                                       'training_id = ?' => $trainingType_id
        //                                     ), array(), false
        //                               );
        // prd($packages);
        // $packageIds = array_column($packages, 'linkable_id');
        $cond = array(  'course_id =?' => $course_id,
                        'country_id = ?' => $country_id,
                        'startDate > ?' => $today,
                        'training_id = ?'=> $trainingType_id,
                        'status = ?'=>1
                     );      
        // 'isSold = ?' => 0 this column was missing from workShop Table
        if($city_id){
            $otherCond = array('city_id = ?' => $city_id);
            $cond = array_merge($cond, $otherCond);
        }    
        $dates = $this->fetchAll($cond,array(),false);
        if(!empty($dates)){ 
            foreach($dates as $key=>$value){
                $datesArray[$value['workshop_id']] = $this->formatWorkshopDate($value['dates']);
            }
            $datesArray['-1'] = 'Workshop date not yet decided';
        }else{
            $datesArray['-1'] = 'Workshop date not yet decided';
        }
        return $datesArray;
    }

    private function formatWorkshopDate($dateId){
        $dateArray = explode(',',$dateId);
        foreach($dateArray as $v){
            $dr[] = date('d-m-Y',strtotime($v)) ;
        }
        return implode(",", $dr);
    }

    public function getDataForWorkshopJSObjectNew(){
        $objTr = new Model_TrainingRelations();
        $packages = $objTr->fetchAll(array('training_id = ?' => BaseApp_Dao_TrainingTypes::TYPE_CLASSROOM,'linkable_type =?'=>'course'), array( 'columns'=>array('linkable_id') ), false);
        $courseIds = array_column($packages, 'linkable_id');
        if($courseIds){
            $dates = $this->fetchAll(array('course_id in (?)' => $courseIds,'startDate > ?' => date('Y-m-d',strtotime ( '-2 week' , strtotime ( date('Y-m-d') ) ) ),'status =?' => 1,'isSold =?'=>0),array( 'columns'=>array('workshop_id','course_id','training_id','city_id','country_id','dates') ),false);
            $newDates = array();
            if(!empty($dates)){
                foreach($dates as $key => $val)
                {   
                    $newDates[$key]['d']    = $dates[$key]['workshop_id'];
                    $newDates[$key]['p']    = $dates[$key]['course_id'];
                    $newDates[$key]['t']    = $dates[$key]['training_id'];
                    $newDates[$key]['ci']= $dates[$key]['city_id']; 
                    $newDates[$key]['co'] = $dates[$key]['country_id'];
                    $newDates[$key]['c'] = $dates[$key]['course_id'];
                    $newFormate = array();
                    $dateArray = explode(',',$dates[$key]['dates']);
                    foreach($dateArray as $date){
                        $newFormate[] = date('d/m/Y',strtotime($date));
                    }
                    $newDates[$key]['da'] = implode(',',str_replace("/","-",$newFormate));
                }   
            }else{
                $newDates[] = array('date_id'=>'-1','dates'=>'Workshop date not yet decided');
            }
        }
        else
        {
            $newDates[] = array('date_id'=>'-1','dates'=>'Workshop date not yet decided');                                                   
        }
        return $newDates;
    }

    public function getNamedWorkshopId($workshopId){
        $cond = array('workshop_id IN (?)'=>$workshopId,'isNamed=(?)'=>0);
        $result = $this->fetchAll($cond);
        foreach($result as $k=>$v){
            $record[$v['workshop_id']] = $v['workshop_id'];
        }
        return $record;
    }

    public function getByBatchId($batchId) {
        $return =array();
        $workshopDataAll = $this->fetchAll(array('batch_id=?'=>$batchId), array(), false); 
        if(!$workshopDataAll) {
            return $workshopDataAll;
        }
        $countries = array();
        foreach($workshopDataAll as $workshopData) {
            $return = $workshopData;
            $countries[] = $workshopData['country_id'];
        }
        if($return['training_id'] == 3) {
            $return['countries'] = $countries;
        }
        return $return;
    }

    public function getByWorkshopId($Id) {
        $workshopDataAll = $this->fetchAll(array('workshop_id=?'=>$Id), array(), false);
        return current($workshopDataAll);
    }

    public function checkWorkShopStatus($workShopId){
        $res = $this->fetchAll(array('workshop_id=?'=>$workShopId,'isSold =?' => 0,'startDate > ?' => date("Y-m-d")), array(), false);
        if(empty($res))
            return 'failure';
        return 'success';
    }
        
    public function getActiveWorkshopByCourse($courseId) {
        $conds = array(
            'course_id=?' => $courseId,
            'workshopStatus=?' => 'active', // check with Amit and ignore this 
            'isSold=?' => 0
        );
        return $this->fetchAll($conds, array(), false);
    }

    public function buildCdnPurgeData($courseId,$linkableType,$action){
        $returnArr = array();
        // $objSeo = new Model_Seo();
        // $seoUrl = current($objSeo->fetchAll(array('linkable_id =?'=>$courseId,'linkable_type =?'=>'course'),array('columns'=>array('url','linkable_id'))));
        // if(!empty($seoUrl))
        //     array_push($returnArr,array('linkable_id'=>$seoUrl['linkable_id'],'linkable_type'=>'course','action'=>$action,'url'=>$seoUrl['url'],'created_at'=>time(),'updated_at'=>time()) );
        // if(in_array($courseId,$this->getLVCPassCourses())){
        //     $seoUrl = current($objSeo->fetchAll(array('linkable_id =?'=>1,'linkable_type =?'=>'lvc_pass'),array('columns'=>array('url','linkable_id'))));
        //     if(!empty($seoUrl))
        //         array_push($returnArr,array('linkable_id'=>$seoUrl['linkable_id'],'linkable_type'=>'lvc_pass','action'=>$action,'url'=>$seoUrl['url'],'created_at'=>time(),'updated_at'=>time()) );
        // }
        return $returnArr;
    } // end of function
        
    
    public function getWorkshopList($trainingTypeId, $countryId, $cityId, $courseId, $fromDate = null, $active = null, $notSold = null, $corporate = null, $includeWorkshopId = null, $addPrefix = 0) {
        $arrWorkshopDetail = array();
        $soldWorkshop = array();
        $includeWorkshop = array();
        
        if ($trainingTypeId > 0) {

            if ($trainingTypeId == Model_TrainingTypes::TYPE_LVC) {
                $cityId = 0;
            }

            $db = $this->getDb();
            $sql = $db->select()
                    ->from('workshop', array('workshop_id', 'dates', 'isCorporate'));

            //$fromDate = ($future_dates == NULL) ? Date("Y-m-d", strtotime(date('Y-m-d')." -2 Month")) : date('Y-m-d');

            $date_array = explode("-", $fromDate);
            if ($fromDate) {
                if (!checkdate($date_array[1], $date_array[2], $date_array[0])) {
                    return "enter valid date in yyyy-mm-dd format";
                }

                $sql->where('startDate > ?', $fromDate);
            }

            if ($trainingTypeId > 0)
                $sql->where('training_id = ?', $trainingTypeId);
            if ($countryId > 0)
                $sql->where('country_id = ?', $countryId);
            if ($cityId > 0)
                $sql->where('city_id = ?', $cityId);
            if ($courseId > 0)
                $sql->where('course_id = ?', $courseId);

            if ($active)
                $sql->where('status = ?', $active);

            if (isset($notSold) && $notSold == 1)
                $sql->where('isSold = ?', 0);

            if (isset($notSold) && $notSold == 0)
                $sql->where('isSold = ?', 1);

            //1= b2b,2= b2c
            if ($corporate > 0 && $corporate == Model_PaymentReconcile::B2B_ID)
                $sql->where('isCorporate = ?', $corporate);
            if ($corporate > 0 && $corporate == Model_PaymentReconcile::B2C_ID)
                $sql->where('isCorporate = ?', 0);
            $query = $sql->__toString();
            $arrWorkshopDetail = $db->fetchAll($sql);
            $arrWorkshopArray = array();
            $includeWorkshopArray = array();
            if (count($arrWorkshopDetail) > 0) {
                if ($addPrefix == 1) {
                    foreach ($arrWorkshopDetail as $key => $val) {
                        if ($val['isCorporate'] == 1) {
                            $arrWorkshopArray[$val['workshop_id']] = 'B2B - ' . $val['dates'];
                        } else
                            $arrWorkshopArray[$val['workshop_id']] = 'B2C - ' . $val['dates'];
                    }
                } else
                    $arrWorkshopArray = array_column($arrWorkshopDetail, 'dates', 'workshop_id');
            }
            $arrWorkshopDetail = $arrWorkshopArray;
            $checkDate = date("Y-m-d", mktime(0, 0, 0, $date_array[1], ($date_array[2] + 1), $date_array[0]));
            $toDate = date("Y-m-d");
            //prd($checkDate);
            if ($checkDate < $toDate && $active == 1 && $notSold == 1) {
                $sql = $db->select()
                        ->from('workshop', array('workshop_id', 'dates', 'isCorporate'));
                if ($trainingTypeId > 0)
                    $sql->where('training_id = ?', $trainingTypeId);
                if ($countryId > 0)
                    $sql->where('country_id = ?', $countryId);
                if ($cityId > 0)
                    $sql->where('city_id = ?', $cityId);
                if ($courseId > 0)
                    $sql->where('course_id = ?', $courseId);
                if ($active)
                    $sql->where('status = ?', $active);

                $sql->where('isSold = ?', 1);
                if ($corporate > 0 && $corporate == Model_PaymentReconcile::B2B_ID)
                    $sql->where('isCorporate = ?', $corporate);
                if ($corporate > 0 && $corporate == Model_PaymentReconcile::B2C_ID)
                    $sql->where('isCorporate = ?', 0);
                $sql->where('startDate > ?', $fromDate);
                $sql->where('startDate <= ?', $toDate);
//                print($sql->__toString());
                $soldWorkshop = $db->fetchAll($sql);

                $soldWorkshopArray = array();
                if (count($soldWorkshop) > 0) {
                    if ($addPrefix == 1) {
                        foreach ($soldWorkshop as $key => $val) {
                            if ($val['isCorporate'] == 1) {
                                $soldWorkshopArray[$val['workshop_id']] = 'B2B - ' . $val['dates'];
                            } else
                                $soldWorkshopArray[$val['workshop_id']] = 'B2C - ' . $val['dates'];
                        }
                    } else
                        $soldWorkshopArray = array_column($soldWorkshop, 'dates', 'workshop_id');
                }
                $soldWorkshop = $soldWorkshopArray;
            }

            if (is_array($includeWorkshopId) && count($includeWorkshopId) > 0) {
                $sql = $db->select()
                        ->from('workshop', array('workshop_id', 'dates', 'isCorporate'))
                        ->where('workshop_id in (?)', $includeWorkshopId);

                $includeWorkshop = $db->fetchAll($sql);
                if (count($includeWorkshop) > 0) {
                    if ($addPrefix == 1) {
                        foreach ($includeWorkshop as $key => $val) {
                            if ($val['isCorporate'] == 1) {
                                $includeWorkshopArray[$val['workshop_id']] = 'B2B - ' . $val['dates'];
                            } else
                                $includeWorkshopArray[$val['workshop_id']] = 'B2C - ' . $val['dates'];
                        }
                    } else
                        $includeWorkshopArray = array_column($includeWorkshop, 'dates', 'workshop_id');

                    $includeWorkshop = $includeWorkshopArray;
                }
                //$includeWorkshop
            }
        }
        if (is_array($soldWorkshop) && count($soldWorkshop) > 0)
            $arrWorkshopDetail = $arrWorkshopDetail + $soldWorkshop;
        if (is_array($includeWorkshop) && count($includeWorkshop) > 0)
            $arrWorkshopDetail = $arrWorkshopDetail + $includeWorkshop;
        return $arrWorkshopDetail;
    }

    // validates data for setIsSoldFlagForWorkshops() 
    public function checkForVaildWorkshopData($webx_session_id, $flag) {
        $db = $this->getDb();
        
        $sql = $db->select()
                    ->from('workshop', array('workshop_id', 'workshopStatus', 'isSold'));

        $sql->where('webx_session_id = ?', $webx_session_id);
        $sql->where('workshopStatus = ?', 'active');
        
        $workshopDetailsObj = $db->fetchAll($sql);
        
        if(empty($workshopDetailsObj[0]) || empty($workshopDetailsObj[0]['workshop_id']) ) {
            return(array('status' => false, 'message' => 'Unable to fetch Workshop details'));
        }

        foreach($workshopDetailsObj as $workshopDetail) {
            if($workshopDetail['isSold'] == $flag) {
                return(array('status' => false, 'message' => 'isSold flag is already set to ' . $flag));
            }
        }

        return(array('status' => true, 'message' => 'Validated successfully.'));
    }

    // update the isSold flag
    public function updateIsSoldFlagForWorkshops($webx_session_id, $flag) {
        $updateArray = array('isSold' => $flag);

        $db = $this->getDb();
        $db->beginTransaction();
        $objWorkshop = new self();

        try {
            $objWorkshop->getDb()->update($objWorkshop->getName(), 
                                          $updateArray, 
                                          array('webx_session_id = ?' => $webx_session_id)
                                      );

            $db->commit();
        } catch (Exception $e){
            $db->rollBack();
            return(array('status' => false, 'message' => $e->getMessage() ));
        }

        return(array('status' => true, 'message' => 'Update successful!' ));
    }

} // End of Class