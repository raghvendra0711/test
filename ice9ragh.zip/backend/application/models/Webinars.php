<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_Webinars extends BaseApp_Dao_Webinars{	

    const MAX_COURSES_ALLOWED_LINK = 2;
    
    const MAX_CATEGORIES_ALLOWED_LINK = 2;

    const WEBINAR_ENTRIES_PER_FRS_LIMIT = 6;
    
    public function createWebinar($data) {
        $db = $this->getDb();
	    $objWebinar = new self();
        $pageUrl = '';
        $db->beginTransaction();
        try{
            $searchTags = $data['searchTags'];
            unset($data['searchTags']);
            if(isset($data['url'])) {
                $pageUrl = trim($data['url']);
                $checkSlash = substr($pageUrl, 0,1);
                if($checkSlash != '/'){
                    $pageUrl = trim('/'.$pageUrl);
                }
                $objWebinar->setPageUrl($pageUrl);
                unset($data['url']);
            }
            $objWebinar->setFromArray($data)->save();
            $modelSeo = new Model_Seo();
            if(!$data['isDemo']){
                $dataSave = array(
                    'controller' => self::SEO_DEFAULT_CONTROLLER,
                    'action' => self::SEO_DEFAULT_ACTION,
                    'params' => json_encode(array(self::SEO_DEFAULT_PARAM_KEY=>$objWebinar->webinar_id)),
                    'linkable_id' => $objWebinar->webinar_id,
                    'linkable_type' => 'webinar'
                );
                $modelSeo->clean();
                $seoData = $modelSeo->getDataByUrl($pageUrl);
                $modelSeo->setId($seoData['seo_id']);
                $modelSeo->setFromArray($dataSave)->update();    
            }else{
                    $dataSave = array(
                        'url'=>$pageUrl,
                        'controller' => self::SEO_DEFAULT_CONTROLLER,
                        'action' => self::SEO_DEFAULT_ACTION,
                        'params' => json_encode(array(self::SEO_DEFAULT_PARAM_KEY=>$objWebinar->webinar_id)),
                        'linkable_id' => $objWebinar->webinar_id,
                        'linkable_type' => 'webinar',
                        'title'=>$data['name'],
                        'description'=>$data['shortDescription'],
                        'h1Tag'=>$data['name'],
                        'thumb_image'=>FRS_WEBINAR_DEFAULT_ICON,
                        'keyword'=>$searchTags,
                        'alt_text'=>$data['name'],
                        'url_type'=>'Webinars',
                        'noindex'=>1
                    );
                $modelSeo->clean();
                $modelSeo->setFromArray($dataSave)->save();
            }
            
            $db->commit();
            return $objWebinar->webinar_id;
        }
        catch (Exception $e){
            print $e->getMessage();
            $db->rollBack();
            return false;
        }
    }
    
    public function updateWebinar($data) {
        $db = $this->getDb();
	$objWebinar = new self();
        $db->beginTransaction();
        try{
            $objWebinar->setId($data['webinar_id']);
            $objWebinar->setFromArray($data)->update();  
            $db->commit();
            return true;
        }
        catch (Exception $e){
            $db->rollBack();
            if (APPLICATION_ENV == 'development')
                throw $e;
            return false;
        }
    }
    
    public function getForInclusion($courseId, $trainingId = 0) {
        $returnData = array();        
        $data = $this->fetchAll(array('FIND_IN_SET(?, course_id)>0' => $courseId), array(), false);
        foreach($data as $tempId => $dataReal) {
            $returnData['webinars']['webinars'.$dataReal['webinar_id']] = 'Webinar (ID-'.$dataReal['webinar_id'].')';
        }
        return $returnData;
    }
    
    public function _afterFetchAll($data){
        $courses = array();
        
        foreach($data as $row){
            if(isset($row['course_id']) && $row['course_id']) {
                $courses = array_merge($courses, explode(",", $row['course_id']));
           }           
        }
        
        $courseMdl = new Model_Courses();
        $courses = $courseMdl->getCourseByIdMultiple($courses);                
        foreach($data as &$row){            
            $courseNames = array();
            if(isset($row['course_id']) && $row['course_id']) {
                $row['course_id'] = explode(",", $row['course_id']);
                foreach($row['course_id'] as $courseId) {
                    if(isset($courses[$courseId])) {
                        $courseNames[] = $courses[$courseId];                        
                    }
                }
                $row['course'] = implode(", ", $courseNames);
            }
        }
        return $data;
    }
    
    public function getWebexUserslist() {
        $returnArr = array();
        $config = new Zend_Config_Ini(CONFIG_PATH .'/webinar_webx_login_details.ini');
        $webxLogins = $config->toArray();
        if(!empty($webxLogins)){
            $webxLogins = $webxLogins['webinar_webx_user_login_data'];
            foreach ($webxLogins as $key => $value) {
                $returnArr[$key] = $key;
            }
        }
        return $returnArr;
   }
   
   public function getRelatedWebinarsToShow($relatedWebinars) {
        $returnData = array();
        if(!$relatedWebinars) {
            return $returnData;
        }
        $conds = array('webinar_id IN (?)' => $relatedWebinars);
        $opts = array('columns' => array('webinarId' => 'webinar_id', 'webinarName' => 'name'));
        $dbData = array();
        foreach($this->fetchAll( $conds, $opts, false) as $data) {
            $dbData[$data['webinarId']] = $data;
        }
        foreach($relatedWebinars as $webinarId) {
            if(isset($dbData[$webinarId])) {
                $returnData[] = $dbData[$webinarId];
            }
        }
        return $returnData;
    }

    public function buildCdnPurgeData($webinarId,$action){
        $returnArr = array();
        // $objSeo = new Model_Seo();
        // $purgeUrlArr = $objSeo->getFrsPurgeUrls();
        // foreach ($purgeUrlArr as $key => $value) {
        //     array_push($returnArr,array('linkable_id'=>$webinarId,'linkable_type'=>'webinar','action'=>$action,'url'=>$value,'created_at'=>time(),'updated_at'=>time()) );
        // }
        // $db = $this->getDb();
        // $dt = new DateTime();
        // $dt = $dt->modify('-1 day');
        // $yesterDayDate = $dt->format('Y-m-d');
        
        // $webinarSql = $db->select()
        //                  ->from(array('w' => 'webinars'), array('webinar_id','date', 'time', 'timeZone'))
        //                  ->where('w.status = ?', 1)
        //                  ->where('w.date >= ?', $yesterDayDate)
        //                  ->order('w.date');
        // $webinarSet = $this->getDb()->fetchAll($webinarSql);
        // if(!empty($webinarData)){
        //     $webinars = array();
        //     foreach($webinarSet as $webinarData) {
        //         $startDate = sprintf("%s %s:00", $webinarData['date'], $webinarData['time']);
        //         if(!$this->_isUpcommingWebinar($startDate, $webinarData['timeZone'])) {
        //             continue;
        //         }
        //         array_push($webinars,$webinarData['webinar_id']);
        //         if(count($webinars) >= self::WEBINAR_ENTRIES_PER_FRS_LIMIT) {
        //             break;
        //         }
        //     }
        //     if(in_array($webinarId, $webinars)){
        //         array_push($returnArr,array('linkable_id'=>$webinarId,'linkable_type'=>'webinar','action'=>$action,'url'=>PURGE_WEBSITE,'created_at'=>time(),'updated_at'=>time()) );
        //     }
        // }
        return $returnArr;
    } // end of function

    private function _isUpcommingWebinar($webinatDate, $webinarTimeZone) {        
        $webinarDate = new DateTime( $webinatDate , new DateTimeZone($webinarTimeZone));
        $webinarDate->setTimezone(new DateTimeZone($webinarTimeZone));                        
        $webinarDate->modify(BaseApp_Dao_Webinars::UPCOMMING_WEBINAR_HEADER_MENU_TIME_STRING);
        
        $userDate = new DateTime();
        $userDate->setTimezone(new DateTimeZone($webinarTimeZone)); 
        if($webinarDate->getTimestamp() <= $userDate->getTimestamp()) {
            return false;
        }
        return true;
    }
} // End of
// Class