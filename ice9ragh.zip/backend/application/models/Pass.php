<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
	
class Model_Pass extends BaseApp_Dao_Pass{
    

    public function createPass($request) {
        $db = $this->getDb();
        $objPass = new self();
        $pageUrl = '';
        $db->beginTransaction();
        try{
            if(isset($request['url'])) {
                $pageUrl = trim($request['url']);
                $checkSlash = substr($pageUrl, 0,1);
                if($checkSlash != '/'){
                    $pageUrl = trim('/'.$pageUrl);
                }
                $objPass->setPageUrl($pageUrl);
                unset($request['url']);
            }
            $request['pass_type'] = self::PASS_TYPE;
            $request['no_of_days'] = self::PASS_ACCESS_DAYS;
            $objPass->setFromArray($request)->save();
            $dataSave = array(
                'controller' => self::SEO_DEFAULT_CONTROLLER,
                'action' => self::SEO_DEFAULT_ACTION,
                'params' => json_encode(array(self::SEO_DEFAULT_PARAM_KEY=>$objPass->pass_id)),
                'linkable_id' => $objPass->pass_id,
                'linkable_type' => 'lvc_pass'
            );
            $modelSeo = new Model_Seo();
            $seoData = $modelSeo->getDataByUrl($pageUrl);
            $modelSeo->setId($seoData['seo_id']);
            $modelSeo->setFromArray($dataSave)->update();
            $db->commit();
            return $objPass->pass_id;
        }
        catch (Exception $e){
            $db->rollBack();
            throw $e;
            return false;
        }
    }
    
    public function updatePass($data) {
        $db = $this->getDb();
        $objPass = new self();
        $db->beginTransaction();
	try{
            $objPass->setId($data['pass_id']);
            $objPass->setFromArray($data)->update();  
            $db->commit();
            return true;
        }
        catch (Exception $e){
            $db->rollBack();
            return false;
        }
    }
    
    public function deletePass($passId) {
        $db = $this->getDb();
        $passObj = new self();
                
        $db->beginTransaction();
                
        // delete pricing
        $modelPrice = new Model_PassPricings();
        foreach($modelPrice->fetchAll(array('pass_id=?'=>$passId), array('columns' => 'pass_pricings_id'), false) as $pricingData) {
            $modelPrice->clean();
            $modelPrice->setId($pricingData['pass_pricings_id']);
            if(!$modelPrice->delete()) {
                $db->rollBack();
                $message = "failed to delete pricing data:{$pricingData['pass_pricings_id']}";
                return false;
            }            
        }
        
        // delete seo
        $objSeo = new Model_Seo();        
        foreach($objSeo->fetchAll(array('linkable_id=?'=>$passId, 'linkable_type=?'=>'lvc_pass'), array('columns' => 'seo_id'), false) as $seoData) {
            $objSeo->clean();
            $objSeo->setId($seoData['seo_id']);
            if(!$objSeo->delete()) {
                $db->rollBack();
                $message = "failed to delete seo data:{$seoData['seo_id']}";
                return false;
            }            
        }
        
        //delete pass
        $passObj->clean();
        $passObj->setId($passId);
        if(!$passObj->delete()) {
            $db->rollBack();
            $message = "failed to delete pass";
            return false;
        }
        $db->commit();
        return true;
    }

    public function buildCdnPurgeData($passId,$action){
        $returnArr = array();
        // $objSeo = new Model_Seo();
        // $seoData = current($objSeo->fetchAll(array('linkable_id = ?'=>$passId,'linkable_type =?'=>'lvc_pass'),array('columns'=>array('url','linkable_id'))));
        // if(!empty($seoData)){
        //     array_push($returnArr,array('linkable_id'=>$seoData['linkable_id'],'linkable_type'=>'lvc_pass','action'=>$action,'url'=>$seoData['url'],'created_at'=>time(),'updated_at'=>time()) );
        // }
        return $returnArr;
    } // end of function
} // End of Class