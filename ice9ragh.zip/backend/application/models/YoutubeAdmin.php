<?php

class Model_YoutubeAdmin extends BaseApp_Model {

    protected $_allowDelete = false;
    protected $_serial = true;
    protected $_name = 'youtubeadmin';
    protected $_pk = 'idyoutubeadmin';

    public function getAll() {
        $sql = $this->getDb()->select()
                ->from('youtubeadmin as co', array('co.username',
            'co.password'
                )
        );
        $data = $this->getDb()->fetchAll($sql);
        return $data;
    }

}
