create table labels (
	label_id int(11) NOT NULL AUTO_INCREMENT,
	labelName text,
	displayName varchar(256),
	categoryUrl text,
	shortDescription text,
	parentLabel varchar(256) NOT NULL DEFAULT 'business' CHECK (parent_label in ('technology','business','design')),
	orderNo varchar(256),
	status int(1),
	PRIMARY KEY (label_id)
);

create table courses (
	course_id int(11) NOT NULL AUTO_INCREMENT,
	label_id int (11),
	courseName text,
	displayName varchar(256),
	courseUrl text,
	secondaryLabels varchar(256), -- seperated by ->
	searchTag varchar(256),
	accessDays varchar(30),
	shortDescription text,
	courseIntro text,
	keyFeatures text,
	faq text,
	accreditedBy varchar(256),
	status int(1),
	PRIMARY KEY (course_id),
	FOREIGN KEY (label_id) REFERENCES labels(label_id)
);

create table reviews (
	review_id int(11) NOT NULL AUTO_INCREMENT,
	course_id int (11) NOT NULL,
	reviewerName varchar(256),
	linkedinUrl text,
	company varchar(256),
	industry varchar(256),
	position varchar(256),
	rating varchar(30),
	review text,
	status int(1),
	PRIMARY KEY (review_id),
	FOREIGN KEY (course_id) REFERENCES courses(course_id)
);

create table trainingTypes (
	training_id int(11) NOT NULL AUTO_INCREMENT,
	course_id int (11) NOT NULL,
	trainingName varchar(256),
	status int(1),
	PRIMARY KEY (training_id),
	FOREIGN KEY (course_id) REFERENCES courses(course_id)
);

create table venues (
	venue_id int(11) NOT NULL AUTO_INCREMENT,
	address text,
	map text,
	contactPerson varchar(256),
	contactNumber varchar(256),
	status int(1),
	PRIMARY KEY (venue_id)
);

create table trainers(
	trainer_id int NOT NULL AUTO_INCREMENT,
	trainerName varchar(256),
	specialization varchar(256),
	trainerEmail varchar(256),
	trainerPhone varchar(30),
	country varchar(256),
	region varchar(256),
	city varchar(256),
	currency varchar(30),
	costType varchar(30),
	status int(1),
	PRIMARY KEY (trainer_id)
);

create table schedules (
	schedule_id int NOT NULL AUTO_INCREMENT,
	scheduleDate timestamp not null,
	scheduleHeadCount int(11),
	scheduleTimeZone varchar(256),
	status int(1),
	PRIMARY KEY (schedule_id)
);

create table workshop (
	workshop_id int NOT NULL AUTO_INCREMENT,
	course_id int (11) NOT NULL,
	training_id int (11),
	venue_id int (11),
	trainer_id int (11),
	schedule_id int (11),
	workshopType varchar(256),
	workshopStatus  varchar(30) NOT NULL DEFAULT 'active' CHECK (workshopStatus in ('active','inactive','complete')),
	status int(1),
	PRIMARY KEY (workshop_id),
	FOREIGN KEY (course_id) REFERENCES courses(course_id),
	FOREIGN KEY (training_id) REFERENCES trainingTypes(training_id),
	FOREIGN KEY (venue_id) REFERENCES venues(venue_id),
	FOREIGN KEY (schedule_id) REFERENCES schedules(schedule_id),
	FOREIGN KEY (trainer_id) REFERENCES trainers(trainer_id)
);

create table videos (
	video_id int NOT NULL AUTO_INCREMENT,
	course_id int (11) NOT NULL,
	videoName varchar(256),
	displayName varchar(256),
	url text,
	shortDescription text,
	longDescription text,
	fileFormat varchar(30),
	iosCompatible int(1) default 0,
	kindleCompatible int(1) default 0,
	androidCompatible int(1) default 0,
	isAddOn int(1) default 0,
	status int(1),
	PRIMARY KEY (video_id),
	FOREIGN KEY (course_id) REFERENCES courses(course_id)
);

create table ebooks (
	ebook_id int NOT NULL AUTO_INCREMENT,
	course_id int (11) NOT NULL,
	EbookName varchar(256),
	displayName varchar(256),
	url text,
	shortDescription text,
	authorName varchar(256),
	longDescription text,
	fileFormat varchar(30),
	iosCompatible int(1) default 0,
	kindleCompatible int(1) default 0,
	androidCompatible int(1) default 0,
	isInteractive int(1) default 0,
	isAddOn int(1) default 0,
	status int(1),
	PRIMARY KEY (ebook_id),
	FOREIGN KEY (course_id) REFERENCES courses(course_id)
);

create table articles (
	article_id int NOT NULL AUTO_INCREMENT,
	course_id int (11) NOT NULL,
	name varchar(256),
	displayName varchar(256),
	url text,
	shortDescription text,
	authorName varchar(256),
	articleContent text,
	searchTags text,
	status int(1),
	PRIMARY KEY (article_id),
	FOREIGN KEY (course_id) REFERENCES courses(course_id)
);

create table webinars (
	webinar_id int NOT NULL AUTO_INCREMENT,
	course_id int (11) NOT NULL,
	name varchar(256),
	displayName varchar(256),
	authorName varchar(256),
	url text,
	urlWebinar text,
	shortDescription text,
	webinarLeadDescription text,
	iosCompatible int(1) default 0,
	kindleCompatible int(1) default 0,
	androidCompatible int(1) default 0,
	isInteractive int(1) default 0,
	isAddOn int(1) default 0,
	status int(1),
	PRIMARY KEY (webinar_id),
	FOREIGN KEY (course_id) REFERENCES courses(course_id)
);

create table addons (
	addon_id int NOT NULL AUTO_INCREMENT,
	addonNo varchar(256),
	status int(1),
	PRIMARY KEY (addon_id)
);

create table exams (
	exam_id int NOT NULL AUTO_INCREMENT,
	course_id int (11) NOT NULL,
	name varchar(256),
	displayName varchar(256),
	url text,
	shortDescription text,
	certifyingBody varchar(256),
	status int(1),
	PRIMARY KEY (exam_id),
	FOREIGN KEY (course_id) REFERENCES courses(course_id)
);

create table pricings (
	pricing_id int NOT NULL AUTO_INCREMENT,
	pricing_linkable_id int(11),
	pricingType varchar(30),
	price numeric(10,2),
	discountedPrice numeric(10,2),
	discountName varchar(256),
	PRIMARY KEY (pricing_id)
);

create table coupons (
	coupon_id int(11) NOT NULL AUTO_INCREMENT,
	code varchar(30),
	course_id varchar(30),
	workshop_id varchar(30),
	country_id varchar(30),
	training_id varchar(30),
	discountType varchar(30),
	discountValue numeric(10,4),
	totalCount int(11),
	usedCount int(11),
	dateStart int(11),
	dateEnd int(11),
	minAmount numeric(10,4),
	autoApply int(11) NOT NULL default 0,
	status int(1),
	PRIMARY KEY (coupon_id)
);

create table discounts (
	discount_id int(11) NOT NULL AUTO_INCREMENT,
	name varchar(256),
	course_id varchar(30),
	workshop_id varchar(30),
	country_id varchar(30),
	training_id varchar(30),
	discountType varchar(30),
	discountValue numeric(10,2),
	totalCount int(11),
	usedCount int(11),
	dateStart int(11),
	dateEnd int(11),
	minAmount numeric(10,2),
	autoApply int(11) NOT NULL default 0,
	status int(1),
	PRIMARY KEY (discount_id)
);