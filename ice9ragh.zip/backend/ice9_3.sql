-- MySQL dump 10.13  Distrib 5.6.19, for debian-linux-gnu (x86_64)
--
-- Host: 192.168.1.16    Database: ice9
-- ------------------------------------------------------
-- Server version	5.1.73

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accessDays`
--

DROP TABLE IF EXISTS `accessDays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accessDays` (
  `day_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(256) DEFAULT NULL,
  `noOfDays` int(11) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`day_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `accreditors`
--

DROP TABLE IF EXISTS `accreditors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accreditors` (
  `accreditor_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL,
  `imagePath` varchar(512) DEFAULT NULL,
  `details` text,
  `link` varchar(256) DEFAULT NULL,
  `isPromoted` int(1) NOT NULL DEFAULT '0',
  `className` varchar(256) DEFAULT NULL,
  `isDefault` int(1) NOT NULL DEFAULT '0',
  `label` varchar(30) DEFAULT NULL,
  `eep_id` varchar(256) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`accreditor_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `acl`
--

DROP TABLE IF EXISTS `acl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `acl` (
  `acl_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` text,
  `roles` text,
  PRIMARY KEY (`acl_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `articles`
--

DROP TABLE IF EXISTS `articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `articles` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` varchar(256) DEFAULT NULL,
  `label_id` varchar(256) DEFAULT NULL,
  `vertical` varchar(256) DEFAULT NULL,
  `name` varchar(256) DEFAULT NULL,
  `displayName` varchar(256) DEFAULT NULL,
  `authorName` varchar(256) DEFAULT NULL,
  `authorDescription` text,
  `authorImage` varchar(512) DEFAULT NULL,
  `shortDescription` varchar(256) DEFAULT NULL,
  `articleContent` text,
  `h1Tag` varchar(256) DEFAULT NULL,
  `url` varchar(512) DEFAULT NULL,
  `duration` varchar(8) NOT NULL,
  `dateCreated` date DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `banners`
--

DROP TABLE IF EXISTS `banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banners` (
  `banner_id` int(11) NOT NULL AUTO_INCREMENT,
  `banner_type` varchar(30) NOT NULL DEFAULT 'home',
  `linkable_id` int(11) DEFAULT NULL,
  `linkable_type` varchar(256) DEFAULT NULL,
  `banner_path` varchar(500) DEFAULT NULL,
  `mobile_banner_path` varchar(500) DEFAULT NULL,
  `country_id` varchar(512) DEFAULT NULL,
  `cluster_id` varchar(512) DEFAULT NULL,
  `label_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`banner_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bundles`
--

DROP TABLE IF EXISTS `bundles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bundles` (
  `bundle_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL,
  `label_id` varchar(256) NOT NULL,
  `course_id` varchar(256) NOT NULL,
  `vendor_id` varchar(256) DEFAULT NULL,
  `accessDays` varchar(256) DEFAULT NULL,
  `shortDescription` varchar(256) NOT NULL,
  `url` varchar(512) NOT NULL,
  `videoLink` varchar(512) NOT NULL,
  `videoThumbImage` varchar(512) NOT NULL,
  `h1Tag` varchar(256) DEFAULT NULL,
  `learners` int(11) DEFAULT NULL,
  `rating` float(2,2) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`bundle_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `campaigns`
--

DROP TABLE IF EXISTS `campaigns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `campaigns` (
  `campaign_id` int(11) NOT NULL AUTO_INCREMENT,
  `campaignType` varchar(256) NOT NULL DEFAULT 'course',
  `displayName` varchar(256) DEFAULT NULL,
  `label_id` varchar(256) DEFAULT NULL,
  `label_type` varchar(30) DEFAULT NULL,
  `course_id` varchar(256) DEFAULT NULL,
  `course_type` varchar(30) DEFAULT NULL,
  `specialText` varchar(512) DEFAULT NULL,
  `topBannerPath` varchar(512) DEFAULT NULL,
  `smallBannerPath` varchar(512) DEFAULT NULL,
  `campaignUrl` varchar(512) NOT NULL,
  `clustersIncluded` varchar(512) DEFAULT NULL,
  `clustersExcluded` varchar(512) DEFAULT NULL,
  `validFrom` int(11) DEFAULT NULL,
  `validto` int(11) DEFAULT NULL,
  `alert` varchar(512) DEFAULT NULL,
  `percentage` decimal(10,4) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`campaign_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changeLog`
--

DROP TABLE IF EXISTS `changeLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changeLog` (
  `changeLog_id` int(11) NOT NULL AUTO_INCREMENT,
  `tableName` varchar(200) DEFAULT NULL,
  `oldValues` text,
  `newValues` text,
  `time` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `row` varchar(200) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`changeLog_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `city`
--

DROP TABLE IF EXISTS `city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `city` (
  `city_id` int(11) NOT NULL AUTO_INCREMENT,
  `country_id` int(11) DEFAULT NULL,
  `region_name` varchar(128) CHARACTER SET utf8 NOT NULL,
  `isCapital` int(1) DEFAULT NULL,
  `name` varchar(512) DEFAULT NULL,
  `orderNo` int(11) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `longitude` double(10,6) NOT NULL,
  `latitude` double(10,6) NOT NULL,
  `about_city` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `location_time_zone` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `nearByCities` varchar(500) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`city_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cluster`
--

DROP TABLE IF EXISTS `cluster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cluster` (
  `cluster_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) DEFAULT NULL,
  `currency_id` int(11) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`cluster_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `country`
--

DROP TABLE IF EXISTS `country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `country` (
  `country_id` int(11) NOT NULL AUTO_INCREMENT,
  `cluster_id` int(11) DEFAULT NULL,
  `name` varchar(512) DEFAULT NULL,
  `orderNo` int(11) DEFAULT NULL,
  `currency_code` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `currency_id` int(11) DEFAULT NULL,
  `dateFormat` varchar(256) DEFAULT NULL,
  `language` varchar(256) DEFAULT NULL,
  `code` varchar(30) DEFAULT NULL,
  `callingCode` varchar(256) DEFAULT NULL,
  `isTaxApplicable` int(1) DEFAULT NULL,
  `serviceTax` decimal(10,4) DEFAULT NULL,
  `local_currency_code` varchar(30) DEFAULT NULL,
  `timeZone` varchar(30) DEFAULT NULL,
  `istOffSet` varchar(30) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `shortCode` varchar(500) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `isCityActivated` int(11) NOT NULL DEFAULT '0',
  `defaultCity_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`country_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `couponDiscounts`
--

DROP TABLE IF EXISTS `couponDiscounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `couponDiscounts` (
  `discount_id` int(11) NOT NULL AUTO_INCREMENT,
  `coupon_id` int(11) NOT NULL,
  `label_id` varchar(256) DEFAULT NULL,
  `course_id` varchar(256) DEFAULT NULL,
  `training_id` varchar(256) DEFAULT NULL,
  `access_day_id` varchar(256) DEFAULT NULL,
  `classRoomFromDate` int(11) DEFAULT NULL,
  `classRoomToDate` int(11) DEFAULT NULL,
  `lvcFromDate` int(11) DEFAULT NULL,
  `lvcRoomToDate` int(11) DEFAULT NULL,
  `discountValue` decimal(10,4) DEFAULT NULL,
  `cluster_id` varchar(512) DEFAULT NULL,
  `country_id` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`discount_id`),
  KEY `coupon_id` (`coupon_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `coupons`
--

DROP TABLE IF EXISTS `coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coupons` (
  `coupon_id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(30) NOT NULL,
  `type` varchar(256) NOT NULL DEFAULT 'course',
  `purpose` varchar(256) NOT NULL DEFAULT 'marketing',
  `label_id` varchar(256) DEFAULT NULL,
  `course_id` varchar(256) DEFAULT NULL,
  `cluster_id` varchar(512) DEFAULT NULL,
  `country_id` varchar(512) DEFAULT NULL,
  `training_id` varchar(256) DEFAULT NULL,
  `specialText` varchar(512) DEFAULT NULL,
  `discountValue` decimal(10,4) DEFAULT NULL,
  `totalCount` int(11) DEFAULT NULL,
  `usedCount` int(11) DEFAULT NULL,
  `validFrom` int(11) DEFAULT NULL,
  `validto` int(11) DEFAULT NULL,
  `terms` text,
  `url` varchar(256) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`coupon_id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `courseFaq`
--

DROP TABLE IF EXISTS `courseFaq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `courseFaq` (
  `course_faq_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `type` int(1) DEFAULT NULL,
  `training_id` int(1) DEFAULT NULL,
  `question` varchar(512) DEFAULT NULL,
  `answer` text,
  `orderNo` int(11) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`course_faq_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `courseInclusion`
--

DROP TABLE IF EXISTS `courseInclusion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `courseInclusion` (
  `course_inclusion_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) DEFAULT NULL,
  `inclusion_id` int(11) DEFAULT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'inclusion',
  `linkable_id` int(11) DEFAULT NULL,
  `linkable_type` varchar(256) DEFAULT NULL,
  `training_id` int(1) DEFAULT NULL,
  `name` text,
  `templateIconPath` varchar(512) DEFAULT NULL,
  `templateData` text,
  PRIMARY KEY (`course_inclusion_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `courseSection`
--

DROP TABLE IF EXISTS `courseSection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `courseSection` (
  `course_section_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) DEFAULT NULL,
  `training_id` int(1) DEFAULT '0',
  `section_id` int(11) DEFAULT NULL,
  `type` int(1) DEFAULT NULL,
  `name` varchar(512) DEFAULT NULL,
  `menuItem` varchar(512) DEFAULT NULL,
  `orderNo` int(11) DEFAULT NULL,
  `isOptional` tinyint(1) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`course_section_id`),
  KEY `course_id` (`course_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `courses` (
  `course_id` int(11) NOT NULL AUTO_INCREMENT,
  `label_id` varchar(256) DEFAULT NULL,
  `type` varchar(256) DEFAULT NULL,
  `name` varchar(512) DEFAULT NULL,
  `displayName` varchar(512) DEFAULT NULL,
  `shortDescription` text,
  `courseUrl` text,
  `h1Tag` varchar(256) DEFAULT NULL,
  `vendor_id` int(11) DEFAULT NULL,
  `accreditor_id` int(11) DEFAULT NULL,
  `isCirtification` int(1) NOT NULL DEFAULT '0',
  `level` varchar(15) NOT NULL DEFAULT '',
  `eLearning_id` varchar(512) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `learners` int(11) DEFAULT NULL,
  `rating` float(2,2) DEFAULT NULL,
  `melvin_package_id` int(11) DEFAULT '0',
  `melvin_course_id` int(11) DEFAULT '0',
  `melvin_mapped_package_id` varchar(512) DEFAULT '',
  `melvin_mapped_course_id` varchar(512) DEFAULT '',
  PRIMARY KEY (`course_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `currencies`
--

DROP TABLE IF EXISTS `currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `currencies` (
  `currency_id` int(11) NOT NULL AUTO_INCREMENT,
  `country_id` int(11) DEFAULT NULL,
  `code` varchar(30) DEFAULT NULL,
  `symbol` varchar(512) DEFAULT NULL,
  `defaults` int(11) DEFAULT NULL,
  `conversionRate` decimal(10,4) DEFAULT NULL,
  `serviceTax` decimal(10,4) DEFAULT NULL,
  `countryCode` varchar(30) DEFAULT NULL,
  `serviceTaxString` varchar(50) DEFAULT NULL,
  `invoiceAddress` text,
  `registrationNumber` text,
  `invoiceString` varchar(256) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`currency_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exams`
--

DROP TABLE IF EXISTS `exams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exams` (
  `exam_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `url` varchar(512) DEFAULT NULL,
  `shortDescription` text,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`exam_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `faq`
--

DROP TABLE IF EXISTS `faq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faq` (
  `faq_id` int(11) NOT NULL AUTO_INCREMENT,
  `linkable_id` int(11) NOT NULL,
  `linkable_type` varchar(30) DEFAULT NULL,
  `question` varchar(512) DEFAULT NULL,
  `answer` text,
  `orderNo` int(11) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`faq_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `generalFaq`
--

DROP TABLE IF EXISTS `generalFaq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `generalFaq` (
  `faq_id` int(11) NOT NULL AUTO_INCREMENT,
  `linkable_id` int(11) DEFAULT NULL,
  `linkable_type` varchar(256) DEFAULT NULL,  
  `section` varchar(512) DEFAULT NULL,
  `question` varchar(512) DEFAULT NULL,
  `answer` text,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`faq_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groups` (
  `group_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL,
  `label_id` varchar(256) NOT NULL,
  `course_id` varchar(256) NOT NULL,
  `vendor_id` varchar(256) DEFAULT NULL,
  `shortDescription` varchar(256) NOT NULL,
  `learningPath` text NOT NULL,
  `url` varchar(512) NOT NULL,
  `h1Tag` varchar(256) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`group_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `homePageBanners`
--

DROP TABLE IF EXISTS `homePageBanners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `homePageBanners` (
  `banner_id` int(11) NOT NULL AUTO_INCREMENT,
  `image_name` varchar(500) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `image_link` varchar(200) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `image_order` int(11) DEFAULT NULL,
  `alt_text` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `class_name` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`banner_id`),
  KEY `country_id_idx` (`country_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `images`
--

DROP TABLE IF EXISTS `images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `images` (
  `image_id` int(11) NOT NULL AUTO_INCREMENT,
  `linkable_id` int(11) DEFAULT NULL,
  `linkable_type` varchar(256) DEFAULT NULL,
  `name` varchar(256) DEFAULT NULL,
  `imagePath` text NOT NULL,
  `imageDescription` text,
  `fileFormat` varchar(30) DEFAULT NULL,
  `fileSize` varchar(30) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`image_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `inclusionTemplates`
--

DROP TABLE IF EXISTS `inclusionTemplates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inclusionTemplates` (
  `inclusion_id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) DEFAULT NULL,
  `name` text,
  `templateIconPath` varchar(512) DEFAULT NULL,
  `templateData` text,
  `is_importatnt` tinyint(1) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`inclusion_id`),
  KEY `section_id` (`section_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `keyfeatures`
--

DROP TABLE IF EXISTS `keyfeatures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `keyfeatures` (
  `feature_id` int(11) NOT NULL AUTO_INCREMENT,
  `linkable_id` int(11) NOT NULL,
  `linkable_type` varchar(256) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `featureText` text,
  `orderNo` int(11) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`feature_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `knowledgeBankEntry`
--

DROP TABLE IF EXISTS `knowledgeBankEntry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `knowledgeBankEntry` (
  `knowledge_id` int(11) NOT NULL AUTO_INCREMENT,
  `knowledgeEntities` varchar(256) DEFAULT NULL,
  `course_id` varchar(256) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`knowledge_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `labels`
--

DROP TABLE IF EXISTS `labels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `labels` (
  `label_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(512) DEFAULT NULL,
  `displayName` varchar(256) DEFAULT NULL,
  `labelUrl` text,
  `h1Tag` varchar(256) DEFAULT NULL,
  `shortDescription` text,
  `parentLabel` varchar(256) NOT NULL DEFAULT 'business',
  `isSubsribed` tinyint(1) DEFAULT NULL,
  `popularCourses` varchar(512) DEFAULT NULL,
  `recentCourses` varchar(512) DEFAULT NULL,
  `offers` varchar(512) DEFAULT NULL,
  `orderNo` int(11) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`label_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lookUp`
--

DROP TABLE IF EXISTS `lookUp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lookUp` (
  `lookup_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(256) DEFAULT NULL,
  `name` varchar(512) DEFAULT NULL,
  `description` varchar(512) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`lookup_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mediaCoverage`
--

DROP TABLE IF EXISTS `mediaCoverage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mediaCoverage` (
  `media_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL,
  `title` varchar(256) DEFAULT NULL,
  `imagePath` varchar(512) DEFAULT NULL,
  `details` text,
  `link` varchar(256) DEFAULT NULL,
  `isPromoted` int(1) NOT NULL DEFAULT '0',
  `publishDate` int(11) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`media_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `modules`
--

DROP TABLE IF EXISTS `modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modules` (
  `module_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `url` text,
  `status` int(11) DEFAULT '1',
  PRIMARY KEY (`module_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `permission_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) DEFAULT NULL,
  `module_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  PRIMARY KEY (`permission_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `praticeTests`
--

DROP TABLE IF EXISTS `praticeTests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `praticeTests` (
  `practice_test_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `name` varchar(256) DEFAULT NULL,
  `noOfSets` int(11) NOT NULL,
  `eLearningMapping` varchar(256) DEFAULT NULL,
  `shortDescription` varchar(256) DEFAULT NULL,
  `url` varchar(512) NOT NULL,
  `h1Tag` varchar(256) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`practice_test_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pricings`
--

DROP TABLE IF EXISTS `pricings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pricings` (
  `pricing_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `type` varchar(256) NOT NULL DEFAULT 'workshop',
  `allLocation` int(1) DEFAULT NULL,
  `training_id` int(11) NOT NULL,
  `access_day_id` int(11) NOT NULL,
  `cluster_id` int(11) NOT NULL DEFAULT '0',
  `country_id` int(11) NOT NULL DEFAULT '0',
  `city_id` int(11) NOT NULL DEFAULT '0',
  `course_inclusion_id` varchar(512) DEFAULT NULL,
  `price` decimal(10,4) DEFAULT NULL,
  `discount` decimal(10,2) DEFAULT NULL,
  `minPrice` decimal(10,4) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`pricing_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recommendations`
--

DROP TABLE IF EXISTS `recommendations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recommendations` (
  `recommendation_id` int(11) NOT NULL AUTO_INCREMENT,
  `linkable_id` varchar(30) NOT NULL,
  `linkable_type` varchar(30) DEFAULT NULL,
  `applicableEntity` varchar(256) DEFAULT NULL,
  `applicableEntityId` int(11) DEFAULT NULL,
  `elementName` varchar(256) DEFAULT NULL,
  `trainingType` varchar(256) DEFAULT NULL,
  `answer` text,
  `orderNo` int(11) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`recommendation_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `referers`
--

DROP TABLE IF EXISTS `referers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `referers` (
  `referer_id` int(11) NOT NULL AUTO_INCREMENT,
  `datetime` int(11) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `phone` varchar(200) DEFAULT NULL,
  `referrals` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `country_code` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`referer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `referrals`
--

DROP TABLE IF EXISTS `referrals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `referrals` (
  `referral_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) DEFAULT NULL,
  `lead_id` int(11) DEFAULT NULL,
  `datetime` int(11) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `phone` varchar(200) DEFAULT NULL,
  `referrer_user_id` int(11) DEFAULT NULL,
  `referrer_name` varchar(200) DEFAULT NULL,
  `referrer_email` varchar(200) DEFAULT NULL,
  `hasClickedEmailLink` int(11) DEFAULT NULL,
  `orderDate` int(11) DEFAULT NULL,
  `orderNumber` varchar(100) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `moneybackApplicable` int(11) DEFAULT NULL,
  `moneybackEnddate` int(11) DEFAULT NULL,
  `moneybackClaimed` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  `country_code` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`referral_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reviews` (
  `review_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `name` varchar(256) DEFAULT NULL,
  `linkedinUrl` text,
  `company` varchar(256) DEFAULT NULL,
  `industry` varchar(256) DEFAULT NULL,
  `position` varchar(256) DEFAULT NULL,
  `rating` varchar(30) DEFAULT NULL,
  `review` text,
  `orderNo` int(11) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `city_id` int(11) DEFAULT NULL,
  `imgUrl` text,
  PRIMARY KEY (`review_id`),
  KEY `course_id` (`course_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `searchTags`
--

DROP TABLE IF EXISTS `searchTags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `searchTags` (
  `search_id` int(11) NOT NULL AUTO_INCREMENT,
  `linkable_id` int(11) DEFAULT NULL,
  `linkable_type` varchar(256) DEFAULT NULL,
  `tag` varchar(512) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`search_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sectionTemplates`
--

DROP TABLE IF EXISTS `sectionTemplates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sectionTemplates` (
  `section_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(512) DEFAULT NULL,
  `menuItem` varchar(512) DEFAULT NULL,
  `orderNo` int(11) DEFAULT NULL,
  `isOptional` tinyint(1) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`section_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `seo`
--

DROP TABLE IF EXISTS `seo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seo` (
  `seo_id` int(11) NOT NULL AUTO_INCREMENT,
  `linkable_id` int(11) DEFAULT NULL,
  `linkable_type` varchar(256) DEFAULT NULL,
  `title` varchar(256) DEFAULT NULL,
  `description` text,
  `keyword` varchar(256) DEFAULT NULL,
  `thumb_image` varchar(256) DEFAULT NULL,
  `alt_text` text,
  PRIMARY KEY (`seo_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `subscriptionPricing`
--

DROP TABLE IF EXISTS `subscriptionPricing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscriptionPricing` (
  `subscription_id` int(11) NOT NULL AUTO_INCREMENT,
  `linkable_id` varchar(30) NOT NULL,
  `linkable_type` varchar(30) DEFAULT NULL,
  `country_id` int(11) NOT NULL DEFAULT '0',
  `currency_id` int(11) NOT NULL,
  `discountValue` decimal(10,4) DEFAULT NULL,
  `accessDays` int(11) DEFAULT NULL,
  `setNumber` int(11) DEFAULT NULL,
  `subscriptionPrice` decimal(10,4) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`subscription_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `testimonials`
--

DROP TABLE IF EXISTS `testimonials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `testimonials` (
  `testimonial_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(512) NOT NULL,
  `email_id` varchar(512) NOT NULL,
  `linkedinUrl` varchar(512) NOT NULL,
  `testimonial` text NOT NULL,
  `isGeneric` int(1) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `training_id` int(11) DEFAULT NULL,
  `country` varchar(512) NOT NULL,
  `company` varchar(512) DEFAULT NULL,
  `designation` varchar(512) DEFAULT NULL,
  `createdDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`testimonial_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trainers`
--

DROP TABLE IF EXISTS `trainers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trainers` (
  `trainer_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) DEFAULT NULL,
  `specialization` varchar(256) DEFAULT NULL,
  `email` varchar(256) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `city_id` int(11) DEFAULT NULL,
  `region` varchar(256) DEFAULT NULL,
  `currency` varchar(30) DEFAULT NULL,
  `costType` varchar(30) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`trainer_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trainingRelations`
--

DROP TABLE IF EXISTS `trainingRelations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trainingRelations` (
  `training_relation_id` int(11) NOT NULL AUTO_INCREMENT,
  `training_id` int(11) DEFAULT NULL,
  `linkable_id` int(11) DEFAULT NULL,
  `linkable_type` varchar(256) DEFAULT NULL,
  `fromDate` int(11) DEFAULT NULL,
  `toDate` int(11) DEFAULT NULL,
  `accessDays` varchar(256) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`training_relation_id`),
  KEY `training_id` (`training_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trainingTypes`
--

DROP TABLE IF EXISTS `trainingTypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trainingTypes` (
  `training_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) DEFAULT NULL,
  `type` varchar(256) DEFAULT NULL,
  `isMain` int(1) NOT NULL DEFAULT '1',
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`training_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `uploadedImages`
--

DROP TABLE IF EXISTS `uploadedImages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uploadedImages` (
  `image_name` varchar(500) NOT NULL,
  `action_name` varchar(200) NOT NULL,
  `controller_name` varchar(200) NOT NULL,
  `addedDate` date NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`image_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vendors`
--

DROP TABLE IF EXISTS `vendors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vendors` (
  `vendor_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) DEFAULT NULL,
  `url` varchar(256) DEFAULT NULL,
  `isApproved` int(1) DEFAULT '1',
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`vendor_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `venues`
--

DROP TABLE IF EXISTS `venues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `venues` (
  `venue_id` int(11) NOT NULL AUTO_INCREMENT,
  `address` text,
  `map` text,
  `country_id` int(11) DEFAULT NULL,
  `city_id` int(11) DEFAULT NULL,
  `contactPerson` varchar(256) DEFAULT NULL,
  `contactNumber` varchar(256) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`venue_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `videos`
--

DROP TABLE IF EXISTS `videos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `videos` (
  `video_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `name` varchar(256) DEFAULT NULL,
  `displayName` varchar(256) DEFAULT NULL,
  `duration` varchar(8) NOT NULL DEFAULT '03:00' COMMENT 'Duration if the content is a video file',
  `videoLink` text,
  `url` text,
  `training_id` int(1) DEFAULT NULL,
  `thumbnailImage` varchar(250) NOT NULL,
  `shortDescription` text,
  `longDescription` text,
  `fileFormat` varchar(30) DEFAULT NULL,
  `fileSize` varchar(30) DEFAULT NULL,
  `iosCompatible` int(1) DEFAULT '0',
  `kindleCompatible` int(1) DEFAULT '0',
  `androidCompatible` int(1) DEFAULT '0',
  `isAddOn` int(1) DEFAULT '0',
  `h1Tag` varchar(256) DEFAULT NULL,
  `authorName` varchar(256) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`video_id`),
  KEY `course_id` (`course_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webinars`
--

DROP TABLE IF EXISTS `webinars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webinars` (
  `webinar_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  `shortDescription` varchar(256) NOT NULL,
  `longDescription` text,
  `url` varchar(512) NOT NULL,
  `h1Tag` varchar(256) DEFAULT NULL,
  `urlJoin` varchar(512) DEFAULT NULL,
  `webinar_ident` varchar(256) DEFAULT NULL,
  `authorName` varchar(256) DEFAULT NULL,
  `timeZone` varchar(256) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `time` varchar(256) DEFAULT NULL,
  `duration` varchar(256) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`webinar_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `workshop`
--

DROP TABLE IF EXISTS `workshop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workshop` (
  `workshop_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `pricing_id` int(11) NOT NULL,
  `training_id` int(11) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `city_id` int(11) DEFAULT NULL,
  `venue_id` int(11) DEFAULT NULL,
  `trainer_id` int(11) DEFAULT NULL,
  `dates` varchar(512) DEFAULT NULL,
  `startDate` date NOT NULL,
  `endDate` date NOT NULL,
  `fromTime` varchar(256) NOT NULL,
  `toTime` varchar(256) NOT NULL,
  `timeZone` varchar(256) DEFAULT NULL,
  `maxHeadCount` int(11) DEFAULT NULL,
  `minHeadCount` int(11) DEFAULT NULL,
  `noOfDays` int(11) DEFAULT NULL,
  `discountValue` decimal(10,4) NOT NULL,
  `price` decimal(10,4) NOT NULL,
  `workshopStatus` varchar(30) NOT NULL DEFAULT 'active',
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`workshop_id`),
  KEY `course_id` (`course_id`),
  KEY `training_id` (`training_id`),
  KEY `venue_id` (`venue_id`),
  KEY `trainer_id` (`trainer_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-12-22  9:00:34
