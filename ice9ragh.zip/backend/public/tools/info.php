<?php

phpinfo();

var_dump(function_exists('apc_store'));
var_dump(function_exists('apc_fetch'));
var_dump(function_exists('apc_delete'));

apc_store('key', 'value');

print apc_fetch('key');