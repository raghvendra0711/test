<?php


$mongo_str['production'] = 'mongodb://mongo-cm-1:27017,mongo-cm-2:27017,mongo-cm-3:27017/?replicaSet=ice10-mrs';
$mongo_db['production'] = 'ice9';


$mongo_str['dev'] = 'mongodb://192.168.1.16:27017';
$mongo_db['dev'] = 'ice9_oct_21';

//For Dev Environment
//$environment = 'dev';

//For Production Environment
$environment = 'production';


//Default collection
$collection_name = 'TempLeadLog';
$fields = array();
if ($_GET) {
	$condition = $_GET;
} else {
	$condition = array();
}

try {
// connect to mongodb
	$connection = new MongoClient($mongo_str[$environment]);

	$collection = $connection->{$mongo_db[$environment]}->$collection_name;

	$cursor = $collection->find($condition, $fields);
	$data_array = array();
	$header = array();
	foreach ($cursor as $id => $value) {
		$id = $value['_id']->{'$id'};
		$value['_id'] = $id;
		if (empty($header)) {
			$header = array_keys($value);
		}
		$data_array[] = array_values($value);
	}
} catch (Exception $e) {
	print_r($e);
	exit;
}
?>

<html>
	<head>
		<meta http-equiv="Content-type" content="text/html; charset=utf-8">
	  <meta name="viewport" content="width=device-width,initial-scale=1">
	  <title>Mongo Data for <?php echo  $collection_name;?></title>
		<link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css" />     
		<link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.2.1/css/buttons.dataTables.min.css" />
		
		<script src="https://code.jquery.com/jquery-1.12.4.js" type="text/javascript"></script>     
		<script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js" type="text/javascript"></script>     
		<script src="https://cdn.datatables.net/buttons/1.3.1/js/dataTables.buttons.min.js" type="text/javascript"></script>     
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js" type="text/javascript"></script>     
		<script src="https://cdn.datatables.net/buttons/1.3.1/js/buttons.html5.min.js" type="text/javascript"></script>
	</head>
	<body>
		<table id="example" class="display" cellspacing="0" width="100%">
			<thead>
        <tr>
						<?php
						foreach ($header as $head_vals) {
							echo "<th>$head_vals</th>";
						}
						?>
        </tr>
			</thead>
			<tbody>
					<?php
					foreach ($data_array as $row_vals) {
						echo "<tr>";
						foreach ($row_vals as $col_vals) {
							echo "<th>$col_vals</th>";
						}
						echo"</tr>";
					}
					?>
			</tbody>
		</table>
		<script>
      $(document).ready(function () {
          $(document).ready(function () {
              $('table').DataTable({
                  dom: 'Blfrtip',
									"lengthMenu": [ [10, 100, 1000, -1], [10, 100, 1000, "All"] ],
                  buttons: [
                      'copyHtml5',
                      'excelHtml5',
                      'csvHtml5'
                  ]
              });
          });
      });
    </script>

	</body>



</html>
