<?php
ini_set('display_errors', 'On');

$host = "i2rds.cuoivis0lb68.us-east-1.rds.amazonaws.com";
$username = "simpli_web";
$password = "SLPortal@2010";

$QUERY1="show processlist;";
$QUERY2="SHOW ENGINE INNODB STATUS;";

$mysqli = new mysqli($host, $username, $password);

/* check connection */
if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
}

printf ("System status: %s\n", $mysqli->stat());

$qry1 = $mysqli->query($QUERY1);
$qry2 = $mysqli->query($QUERY2);
$headers_printed = false;
print "<br />ProcessList : <br /><table border=1 cellpadding=5>";
while ($arr = $qry1->fetch_assoc()) {
if (!$headers_printed) {
print "<tr>";
        foreach (array_keys($arr) as $key) {
                print "<td>$key</td>";
        }
print "</tr>";
$headers_printed = true;
}
print "<tr>";
        foreach ($arr as $val) {
                print "<td>$val</td>";
        }
print "</tr>";
}
print "</table>";

print "<br /><pre>";
print $mysqli->error;
$arr = $qry2->fetch_assoc();
print $arr['Status'];

$mysqli->close();