<?php

class Model_BundlesTest extends \PHPUnit_Framework_TestCase {

    /**
     *
     * @test
     * @dataProvider getMasterTypeOfBundleProvider
     * @group getMasterTypeOfBundleTest
     */
    public function getMasterTypeOfBundleTest($bundleId, $exceptedResult) {
        $model = new Model_Bundles();
        $actualResult = $model->getMasterTypeOfBundle($bundleId);
        $this->assertSame($exceptedResult, $actualResult);
    }

    public function getMasterTypeOfBundleDataProvider() {
        return array(
            array('', array()),
            array(156, array('bundle_id' => '156', 'master_type' => 1, 'linkable_type' => 'bundle'))
        );
    }

}
