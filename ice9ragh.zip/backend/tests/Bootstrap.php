<?php
ini_set("date.timezone", "Asia/Calcutta");
ini_set('display_errors', '1');
ini_set('display_startup_errors', 1);
ini_set('memory_limit', '512M');
set_time_limit(0);
error_reporting(E_ALL & E_STRICT);
//if (function_exists('newrelic_disable_autorum')) {
//    newrelic_disable_autorum();
//}

// Define path to application directory
defined('APPLICATION_PATH') || define('APPLICATION_PATH', realpath(dirname(__FILE__) . '/../application'));

defined('PROFILE_STEP_START') || define('PROFILE_STEP_START', microtime(true));

// Define application environment

defined('APPLICATION_ENV') || define('APPLICATION_ENV', (getenv('APPLICATION_ENV') ? getenv('APPLICATION_ENV') : 'development'));
defined('CONFIG_PATH') || define('CONFIG_PATH', realpath(APPLICATION_PATH . '/../../configs'));

//setting up env variables:
if (!array_key_exists('REMOTE_ADDR', $_SERVER)) {
    $_SERVER['REMOTE_ADDR'] = '127.0.0.1';
}
if (!array_key_exists('REQUEST_METHOD', $_SERVER)) {
    $_SERVER['REQUEST_METHOD'] = '';
}
$_SERVER["APPLICATION_ENV"] = APPLICATION_ENV;
$_SERVER['SERVER_NAME'] = 'PHP.UNIT.TEST';
$_SERVER['REQUEST_URI'] = 'PHPUNITTEST';
$_SERVER['QUERY_STRING'] = 'PHPUNITTEST';

// Ensure library/ is on include_path
set_include_path(implode(PATH_SEPARATOR, array(
    realpath(APPLICATION_PATH . '/../../library'),
    get_include_path(),
)));
//echo realpath(APPLICATION_PATH . '/../../library');exit;
/** Zend_Loader_Autoloader */
require_once 'Zend/Loader/Autoloader.php';
$autoloader = Zend_Loader_Autoloader::getInstance();
//print_r($autoloader); die;
$autoloader->registerNamespace('BaseApp_');

// Create application, bootstrap, and run
$application = new Zend_Application(
    APPLICATION_ENV, APPLICATION_PATH . '/../../configs/application.php'
);

$application->bootstrap();
