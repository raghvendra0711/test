<?php
/**
 * phpunit for payments
 *
 * @author Manjunatha Devadiga <manjunatha.devadiga@simplilearn.net>
 */


 class BaseApp_Dao_PaymentsTest extends \PHPUnit_Framework_TestCase {

    /**
     * @test
     * @dataProvider providerDaoPaymentTest
     * @group daoPayment
     */
    public function daoPaymentTest($totalAmount, $advanceAmount, $expectedResult) {
        $paymentModel = new BaseApp_Dao_Payments();
        $actualResult = $paymentModel->overallPercentageAfterPartialPayment($totalAmount, $advanceAmount);
        $this->assertSame($expectedResult, $actualResult);
        unset($paymentModel);
    }

    /**
     * @test
     * @dataProvider providerdaoPaymentDistributionTest
     * @group daoPayment
     */
    public function daoPaymentDistributionTest($sellingPrice, $overallPercentage, $expectedResult) {
        $paymentModel = new BaseApp_Dao_Payments();
        $actualResult = $paymentModel->paymentDistributionCalculation($sellingPrice, $overallPercentage);
        $this->assertSame($expectedResult, $actualResult);
        unset($paymentModel);
    }

    /**
     * @test
     * @dataProvider providerDaoPaymentFailTest
     * @group daoPayment
     */
    public function daoPaymentFailTest($totalAmount, $advanceAmount, $expectedResult) {
        $paymentModel = new BaseApp_Dao_Payments();
        $actualResult = $paymentModel->overallPercentageAfterPartialPayment($totalAmount, $advanceAmount);
        $this->assertNotEquals($expectedResult, $actualResult);
        unset($paymentModel);
    }

    /**
     * @test
     * @dataProvider providerdaoPaymentDistributionFailTest
     * @group daoPayment
     */
    public function daoPaymentDistributionFailTest($sellingPrice, $overallPercentage, $expectedResult) {
        $paymentModel = new BaseApp_Dao_Payments();
        $actualResult = $paymentModel->paymentDistributionCalculation($sellingPrice, $overallPercentage);
        $this->assertNotEquals($expectedResult, $actualResult);
        unset($paymentModel);
    }

   public function providerdaoPaymentTest() {
     return array (
        array(30000, 10000, (10000/30000)*100),
        array(0, 0, 0)
     );
   }

   public function providerdaoPaymentDistributionTest() {
     return array (
        array(30000, 12, (12/100)*30000),
        array(0, 0, 0)
     );
   }

   public function providerdaoPaymentFailTest() {
     return array (
        array(30000, 10000, (1000/30000)*100),
        array(0, 0, 10)
     );
   }

   public function providerdaoPaymentDistributionFailTest() {
     return array (
        array(30000, 12, (120/100)*30000),
        array(0, 0, 10)
     );
   }

}



