<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class BaseApp_Payments_CustomTest extends \PHPUnit_Framework_TestCase {
    /**
     *
     * @test
     * @dataProvider CustomDP
     * @group BaseApp_Payments_CustomTest
     */
    public function generatePayment() {
        
    }    
    
    
    public function validateAndPrepareData(){
        return array(array('data-required'=>true),array('status' => true));
        
    }
} 