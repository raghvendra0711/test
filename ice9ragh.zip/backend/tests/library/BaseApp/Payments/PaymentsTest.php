<?php
/**
 * phpunit for payments
 *
 * @author Kalyanakannan Padivasu <kalyanakannan@simplilearn.net>
 */


 class CustomPaymentsTest extends \PHPUnit_Framework_TestCase {

   /**
    * [getPaymentStub retrun payments object mock without default constructor]
    * @return [Stub] [paymentStub]
    */
   public function getPaymentStub() {
     $paymentStub = $this->getMockBuilder('BaseApp_Payments_Payments')
              ->setMethods(null)
              ->disableOriginalConstructor()
              ->getMock();
      return $paymentStub;
   }

   /**
    * [getPaymentStubWithPaymentFields retrun payments object mock without default constructor. this mock will getPaymentFields function]
    * @return [Stub] [paymentStub]
    */
   public function getPaymentStubWithPaymentFields() {
     $paymentStub = $this->getMockBuilder('BaseApp_Payments_Payments')
              ->setMethods(array('getPaymentFields','validateDiscount'))
              ->disableOriginalConstructor()
              ->getMock();

     $paymentStub->expects($this->once())
          ->method('getPaymentFields')
            ->willReturn($this->getPaymentFields());

      return $paymentStub;
   }

   /**
    * [invokePaymentConstructor it will inkove payment mock constructor after creating object mock without constructor.
    *                           because constructor is depend with getpaymentfields function]
    */
   public function invokePaymentConstructor($payment,$data)
   {
     $reflectedClass = new ReflectionClass('BaseApp_Payments_Payments');
     $constructor = $reflectedClass->getConstructor();
     $constructor->invoke($payment, $data);
   }

   /**
    * @test
    * @dataProvider providerTestIsPartialPayment
    * @group isPartialPaymentTest
    * @group customPayment
    *
    */
   public function testIsPartialPayment($type, $exceptedResult) {
       $payment = $this->getPaymentStub();
       $payment->setPaymentSubType($type);
       $response = $payment->isPartialPayment();
       $this->assertSame($exceptedResult, $response);
   }

   /**
    * @test
    * @dataProvider providerTestIsBackendPayment
    * @group testIsBackendPayment
    * @group customPayment
    */
   public function testIsBackendPayment($type, $exceptedResult) {
     $data['type'] = $type;
     $payment = $this->getPaymentStubWithPaymentFields();
      $this->invokePaymentConstructor($payment,$data);
      $response = $payment->isBackendPayment();
      $this->assertSame($exceptedResult, $response);
   }

   /**
    * @test
    * @dataProvider providerTestSetPaymentSubType
    * @group testSetPaymentSubType
    * @group customPayment
    */
   public function testSetPaymentSubType($subType, $exceptedResult) {
     $payment = $this->getPaymentStub();
     $this->assertSame($exceptedResult, $payment->setPaymentSubType($subType));
   }

   /**
    * @test
    * @dataProvider providerTestSetPaymentId
    * @group testSetPaymentId
    * @group customPayment
    */
   public function testSetPaymentId($paymentId, $exceptedResult) {
     $payment = $this->getPaymentStub();
     $this->assertSame($exceptedResult, $payment->setPaymentId($paymentId));
   }

   /**
    * @test
    * @dataProvider providerTestGetPaymentId
    * @group testGetPaymentId
    * @group customPayment
    */
   public function testGetPaymentId($paymentId, $exceptedResult) {
     $payment = $this->getPaymentStub();
     $payment->setPaymentId($paymentId);
     $this->assertSame($exceptedResult, $payment->getPaymentId());
   }

   /**
    * @test
    * @dataProvider providerTestSetContractFields
    * @group testSetContractFields
    * @group customPayment
    */
   public function testSetContractFields($data, $exceptedResult) {
     $payment = $this->getPaymentStubWithPaymentFields();
     $this->invokePaymentConstructor($payment,$data);
     $response = $payment->setContractFields();
     $this->assertSame($exceptedResult, $response['status']);
   }

   public function providerTestSetContractFields() {
     return array (
        array($this->getRegularPaymentData(),false),
        array($this->getPartialPaymentData(),true)
     );
   }

   /**
    * @test
    * @dataProvider providerTestIsAtpAdvance
    * @group testIsAtpAdvance
    * @group customPayment
    */
   public function testIsAtpAdvance($type, $exceptedResult) {
     $payment = $this->getPaymentStub();
     $payment->setPaymentSubType($type);
     $response = $payment->isAtpAdvance();
     $this->assertSame($exceptedResult, $response);
   }

   /**
    * @test
    * @dataProvider providerTestIsAtpAccountOpening
    * @group testIsAtpAccountOpening
    * @group customPayment
    */
   public function testIsAtpAccountOpening($type, $exceptedResult) {
     $payment = $this->getPaymentStub();
     $payment->setPaymentSubType($type);
     $response = $payment->isAtpAccountOpening();
     $this->assertSame($exceptedResult, $response);
   }

   /**
    * @test
    * @dataProvider providerTestIsCourseUpgradation
    * @group testIsCourseUpgradation
    * @group customPayment
    */
   public function testIsCourseUpgradation($type, $exceptedResult) {
     $payment = $this->getPaymentStub();
     $payment->setPaymentSubType($type);
     $response = $payment->isCourseUpgradation();
     $this->assertSame($exceptedResult, $response);
   }

   /**
    * @test
    * @dataProvider providerTestIsCourseExtension
    * @group testIsCourseExtension
    * @group customPayment
    */
   public function testIsCourseExtension($type, $exceptedResult) {
     $payment = $this->getPaymentStub();
     $payment->setPaymentSubType($type);
     $response = $payment->isCourseExtension();
     $this->assertSame($exceptedResult, $response);
   }

   /**
    * @test
    * @dataProvider providerTestIsPartialSubSequent
    * @group testIsPartialSubSequent
    * @group customPayment
    */
   public function testIsPartialSubSequent($type, $exceptedResult) {
     $payment = $this->getPaymentStub();
     $payment->setPaymentSubType($type);
     $response = $payment->isPartialSubSequent();
     $this->assertSame($exceptedResult, $response);
   }

   /**
    * @test
    * @dataProvider providerTestIsReconcileIdRequire
    * @group testIsReconcileIdRequire
    * @group customPayment
    */
   public function testIsReconcileIdRequire($type, $exceptedResult) {
     $payment = $this->getPaymentStub();
     $payment->setPaymentSubType($type);
     $response = $payment->isReconcileIdRequire();
     $this->assertSame($exceptedResult, $response);
   }

   /**
    * @test
    * @dataProvider providerTestIsApprovalRequired
    * @group testIsApprovalRequired
    * @group customPayment
    */
   public function testIsApprovalRequired($type, $exceptedResult) {
     $payment = $this->getPaymentStub();
     $payment->setPaymentSubType($type);
     $response = $payment->isApprovalRequired();
     $this->assertSame($exceptedResult, $response);
   }

   /**
    * @test
    * @dataProvider providerTestValidateDiscount
    * @group testValidateDiscount
    * @group customPayment
    */
   public function testValidateDiscount($items, $exceptedResult) {
     $payment = $this->getPaymentStubWithPaymentFields();
     $map = [
            [['approval_required' => 0], ['status' => false, 'msg' => 'Some Error Occured in Sending Approval Request.']],
            [['approval_required' => 1], ['status' => true]]
        ];
     $payment->expects($this->once())
            ->method('validateDiscount')
             ->will($this->returnValueMap($map));

     $this->invokePaymentConstructor($payment,$data);
     $response = $payment->validateDiscount($items);
     $this->assertSame($exceptedResult, $response['status']);
   }

   public function providerTestValidateDiscount() {
     return array (
       array(['approval_required' => 0], false),
       array(['approval_required' => 1], true),
     );
   }

   public function providerTestIsApprovalRequired() {
     return array (
       array(BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_ATP_ACCOUNT_OPENING, false),
       array(BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_PARTIAL, true),
     );
   }

   public function providerTestIsReconcileIdRequire() {
     return array (
       array(BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_ATP_ACCOUNT_OPENING, false),
       array(BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_PARTIAL_SUBSEQUENT, false),
       array(BaseApp_Dao_Melvin_Order::PAYMENT_COURSE_EXTENSION, true),
     );
   }

   public function providerTestIsPartialSubSequent() {
     return array (
       array(BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_ATP_ACCOUNT_OPENING, false),
       array(BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_PARTIAL_SUBSEQUENT, true),
       array(BaseApp_Dao_Melvin_Order::PAYMENT_COURSE_EXTENSION, false),
     );
   }

   public function providerTestIsCourseExtension() {
     return array (
       array(BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_ATP_ACCOUNT_OPENING, false),
       array(BaseApp_Dao_Melvin_Order::PAYMENT_COURSE_EXTENSION, true),
     );
   }

   public function providerTestIsCourseUpgradation() {
     return array (
       array(BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_ATP_ACCOUNT_OPENING, false),
       array(BaseApp_Dao_Melvin_Order::PAYMENT_COURSE_UPGRADATION, true),
     );
   }

   public function providerTestIsAtpAccountOpening() {
     return array (
       array(BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_ATP_ACCOUNT_OPENING, true),
       array(BaseApp_Dao_Melvin_Order::PAYMENT_COURSE_UPGRADATION, false),
     );
   }

   public function providerTestIsAtpAdvance() {
     return array (
       array(BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_ATP_ADVANCE, true),
       array(BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_CORPORATE, false),
     );
   }

   public function providerTestIsPartialPayment() {
     return array (
        array(BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_PARTIAL,true),
        array(BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_REGULAR, false),
     );
   }

   public function providerTestSetPaymentSubType() {
     return array (
        array(BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_PARTIAL,null),
        array(BaseApp_Dao_Melvin_Order::PAYMENT_TYPE_REGULAR, null),
     );
   }

   public function providerTestSetPaymentId()
   {
     return array (
        array(1234567,null)
     );
   }

   public function providerTestGetPaymentId() {
     return array (
        array(1234567,1234567)
     );
   }

   public function providerTestIsBackendPayment() {
     return array (
        array(BaseApp_Dao_Payments::TYPE_BACKEND,true),
        array(BaseApp_Dao_Payments::TYPE_CUSTOM,false)
     );
   }

   public function getPaymentFields()
   {
     return ['type', 'billing_email', 'learner_email', 'contact_number', 'country_id', 'country_name', 'city_id',
                   'city_name', 'created_by', 'user_email', 'items', 'total_price', 'region_name', 'total_price', 'tax_properties',
                   'tax_percentage', 'payment_sub_type_id', 'payment_sub_type', 'approval_required','is_zest_money','is_affirm','is_eduvanz','is_bajaj_finserv'];
   }

   public function getRegularPaymentData() {
     return array('approval_required' => '0', 'type' => 'custom', 'billing_email' => 'kalyanakannan@simplilearn.net', 'contact_number' => '+91-1234567890', 'learner_email' => '', 'country_id' => '6', 'country_name' => 'India', 'city_id' => '27',
     'city_name' => 'Chennai', 'created_by' => '785288', 'user_email' => 'kalyanakannan@simplilearn.net', 'items' => array( '1-659' => array( 'product_type_id' => '1', 'product_type_name' => 'Course', 'product_id' => '659', 'product_name' => 'Agile Scrum Master',
     'training_type_id' => '2', 'training_type_name' => 'Online Self Learning', 'workshop_id' => '0', 'access_days' => '180', 'price_id' => '180', 'discount_percentage' => '0', 'mrp' => '17999.00', 'selling_price' => '17999.00',
     'allowed_discount' => '35', ) ), 'total_price' => '17999', 'is_zest_money' => '0', 'is_eduvanz' => '0', 'is_bajaj_finserv' => '0', 'is_affirm' => '0', 'tax_properties' => '{"code":"INR","currency_id":"1","tax":{"IGST":{"percentage":"18.0000"}},"totalTax":"18.0000","invoiceAddress":"Simplilearn Solutions Private Limited - #53/1C, Manoj Arcade, 24th Main, HSR Layout Sector 2, Bangalore- 560102","invoiceString":"SSPL","registrationNumber":"<div class=\"\"><span class=\"tax_reg\">GSTN: 29AAOCS0916L1ZU </span><span class=\"tax_reg\">, SAC Code: 999293</span></div>","currency_symbol":"₹"}', 'tax_percentage' => '18.0000',
      'region_name' => 'Tamil Nadu', 'payment_sub_type_id' => '1', 'payment_sub_type' => 'Regular Payment' );
   }

   public function getPartialPaymentData() {
     return array('approval_required' => '0', 'type' => 'custom', 'billing_email' => 'kalyanakannan@simplilearn.net', 'contact_number' => '+91-1234567890', 'learner_email' => '', 'country_id' => '6', 'country_name' => 'India', 'city_id' => '27',
     'city_name' => 'Chennai', 'created_by' => '785288', 'user_email' => 'kalyanakannan@simplilearn.net', 'items' => array( '1-659' => array( 'product_type_id' => '1', 'product_type_name' => 'Course', 'product_id' => '659', 'product_name' => 'Agile Scrum Master',
     'training_type_id' => '2', 'training_type_name' => 'Online Self Learning', 'workshop_id' => '0', 'access_days' => '180', 'price_id' => '180', 'discount_percentage' => '0', 'mrp' => '17999.00', 'selling_price' => '17999.00',
     'allowed_discount' => '35', ) ), 'total_price' => '17999', 'is_zest_money' => '0', 'is_eduvanz' => '0', 'is_bajaj_finserv' => '0', 'is_affirm' => '0', 'tax_properties' => '{"code":"INR","currency_id":"1","tax":{"IGST":{"percentage":"18.0000"}},"totalTax":"18.0000","invoiceAddress":"Simplilearn Solutions Private Limited - #53/1C, Manoj Arcade, 24th Main, HSR Layout Sector 2, Bangalore- 560102","invoiceString":"SSPL","registrationNumber":"<div class=\"\"><span class=\"tax_reg\">GSTN: 29AAOCS0916L1ZU </span><span class=\"tax_reg\">, SAC Code: 999293</span></div>","currency_symbol":"₹"}', 'tax_percentage' => '18.0000',
      'region_name' => 'Tamil Nadu', 'payment_sub_type_id' => '13', 'payment_sub_type' => 'Regular Payment', 'config_id' => '1', 'advance_amount' => '12345', 'installments' => '2');
   }
 }

 ?>
