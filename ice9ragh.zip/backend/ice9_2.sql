DROP DATABASE IF EXISTS ice9;
CREATE DATABASE ice9;
USE ice9;

create table labels (
	label_id int(11) NOT NULL AUTO_INCREMENT,
	name varchar(512),
	displayName varchar(256),
	labelUrl text,
	h1Tag varchar(256),
	shortDescription text,
	parentLabel varchar(256) NOT NULL DEFAULT 'business' CHECK (parent_label in ('technology','business','design')),
	isSubsribed tinyint(1),
    popularCourses varchar(512),
    recentCourses  varchar(512),
    offers  varchar(512),
	orderNo int(11),
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (label_id)
);

create table courses (
	course_id int(11) NOT NULL AUTO_INCREMENT,
	label_id varchar(256), -- multi select comma seperated
	type varchar(256), -- multi select comma seperated
	name varchar(512),
	displayName varchar(512),
	shortDescription text,
	courseUrl text,
	h1Tag varchar(256),
	vendor_id int(11), -- References vendor Table
	accreditor_id int(11), -- References Accreditor Table
    isCirtification int(1) NOT NULL DEFAULT '0' CHECK (isCirtification in ('0','1')),
    level varchar(15) NOT NULL DEFAULT '' CHECK (level in ('beginner','intermediate','advanced','')),
    rating float(2,2), 
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (course_id)
);

create table trainingTypes (
	training_id int(11) NOT NULL AUTO_INCREMENT,
	name varchar(256),
	type varchar(256),
	isMain int(1) NOT NULL default 1,
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (training_id)
);


-- course Images will come from generic Image table
-- course Videos will come from generic Videos table

-- LMS Data for scorm chapter Listings
-- learning eLements templates

create table courseSection(
	course_section_id int(11) NOT NULL AUTO_INCREMENT,
	course_id int(11),
	section_id int(11),
	training_id int(1),
	name varchar(512),
	menuItem varchar(512),
	orderNo int(11),
	isOptional tinyint(1),
	status int(1) NOT NULL DEFAULT 1, -- soft delete lets discuss
	PRIMARY KEY (course_section_id),
	FOREIGN KEY (course_id) REFERENCES courses(course_id)
);

create table courseInclusion(
	course_inclusion_id int(11) NOT NULL AUTO_INCREMENT,
	course_id int(11),
	inclusion_id int(11),
	type varchar(30) not null DEFAULT 'inclusion' CHECK (type in ('inclusion','learning')),
    linkable_id int(11),
	linkable_type varchar(256),
    training_id int(1),
	name text,
	templateIconPath varchar(512),
	templateData text,
	PRIMARY KEY (course_inclusion_id)
);

create table sectionTemplates(
	section_id int(11) NOT NULL AUTO_INCREMENT,
	name varchar(512),
	menuItem varchar(512),
	orderNo int(11),
	isOptional tinyint(1),
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (section_id)
);

create table inclusionTemplates(
	inclusion_id int(11) NOT NULL AUTO_INCREMENT,
	section_id int(11),
	name text,
	templateIconPath varchar(512),
	templateData text,
	is_importatnt tinyint(1),
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (inclusion_id),
	FOREIGN KEY (section_id) REFERENCES sectionTemplates(section_id)
);

create table courseFaq (
	course_faq_id int(11) NOT NULL AUTO_INCREMENT,
	course_id int (11) NOT NULL,
	type int(1),-- application.ini 1 - Course Q&A , 2 Course Exam n Cert,3 Generic FAQ
    training_id int(1),
	question varchar(512),
	answer text,
	orderNo int(11),
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (course_faq_id)
);

-- Need to review reviews table --
create table reviews (
	review_id int(11) NOT NULL AUTO_INCREMENT,
	course_id int (11) NOT NULL,
	name varchar(256),
	linkedinUrl text,
	company varchar(256),
	industry varchar(256),
	position varchar(256),
	rating varchar(30),
	review text,
	orderNo int(11),
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (review_id),
	FOREIGN KEY (course_id) REFERENCES courses(course_id)
);

create table accreditors (
	accreditor_id int(11) NOT NULL AUTO_INCREMENT,
	name varchar(256) NOT NULL,
	imagePath varchar(512),
	details text,
	link varchar(256),
	isPromoted int(1) NOT null Default 0,
	className varchar(256),
	isDefault int(1) NOT null Default 0,
	label varchar(30),
	eep_id varchar(256),
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (accreditor_id)
);

create table images (
	image_id int(11) NOT NULL AUTO_INCREMENT,
	linkable_id int(11),
	linkable_type varchar(256),
	name varchar(256),
	imagePath text not null,
    imageDescription text,
	fileFormat varchar(30),
	fileSize varchar(30),
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (image_id)
);

create table videos (
	video_id int NOT NULL AUTO_INCREMENT,
	course_id int (11) NOT NULL,
	name varchar(256),
	displayName varchar(256),
	duration varchar(8) NOT NULL DEFAULT '03:00' COMMENT 'Duration if the content is a video file',
	url text,
    h1Tag varchar(256),
    training_id int(1),
	thumbnailImage varchar(250) NOT NULL,
	shortDescription text,
	longDescription text,
	fileFormat varchar(30),
	fileSize varchar(30),
	iosCompatible int(1) default 0,
	kindleCompatible int(1) default 0,
	androidCompatible int(1) default 0,
	isAddOn int(1) default 0,
    h1Tag varchar(256),
    authorName varchar(256) not null,
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (video_id),
	FOREIGN KEY (course_id) REFERENCES courses(course_id)
);       


-- id and type
create table campaigns (
	campaign_id int(11) NOT NULL AUTO_INCREMENT,
	campaignType varchar(256) NOT NULL DEFAULT 'course' CHECK (campaignType in ('course','subscription')),
    displayName varchar(256),
	label_id varchar(256), -- multi select comma seperated list of labels available
	label_type varchar(30),
	course_id varchar(256),-- multi select comma seperated list of courses available
	course_type varchar(30),
	specialText varchar(512),
	topBannerPath varchar(512),
    smallBannerPath varchar(512),
	campaignUrl varchar(512) not null,
	clustersIncluded varchar(512), --  comma seperated cluster Ids references cluster 
	clustersExcluded varchar(512), --  comma seperated cluster Ids references cluster 
	validFrom int(11),
	validto int(11),
	alert varchar(512), -- comma seperated email Ids
	percentage numeric(10,4),
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (campaign_id)
);


create table coupons (
	coupon_id int(11) NOT NULL AUTO_INCREMENT,
	code varchar(30) NOT NULL,
	type varchar(256) NOT NULL DEFAULT 'course' CHECK (type in ('course','subscription')),
    purpose varchar(256) NOT NULL DEFAULT 'marketing' CHECK (type in ('sales','marketing')),
    label_id varchar(256), -- multi select comma seperated list of labels available
	course_id varchar(256),-- multi select comma seperated list of courses available	
    cluster_id varchar(512), --  comma seperated cluster Ids references cluster 
	country_id varchar(512), --  comma seperated cluster Ids references cluster 
    training_id varchar(256),
    specialText varchar(512),
    discountValue numeric(10,4),
	totalCount int(11),
	usedCount int(11),
	validFrom int(11),
	validto int(11),
    terms text,
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (coupon_id),
	UNIQUE(code)
);

create table couponDiscounts (
	discount_id int(11) NOT NULL AUTO_INCREMENT,
	coupon_id int(11) NOT NULL,
	label_id varchar(256), -- multi select comma seperated list of labels available
	course_id varchar(256),-- multi select comma seperated list of courses available
	training_id varchar(256), -- multi select comma seperated list of training Types available
	access_day_id varchar(256), -- multi select comma seperated list of Access Days available
	classRoomFromDate int(11),
	classRoomToDate int(11),
	lvcFromDate int(11),
	lvcRoomToDate int(11),
	discountValue numeric(10,4),
	cluster_id varchar(512), --  comma seperated cluster Ids references cluster 
	country_id varchar(512), --  comma seperated cluster Ids references cluster 
	PRIMARY KEY (discount_id),
	FOREIGN KEY (coupon_id) REFERENCES coupons(coupon_id)
);

create table trainingRelations (
	training_relation_id int(11) NOT NULL AUTO_INCREMENT,
	training_id int(11),
	linkable_id int(11),
	linkable_type varchar(256),
    fromDate int(11),
    toDate int(11), 
	accessDays varchar(256),
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (training_relation_id),
	FOREIGN KEY (training_id) REFERENCES trainingTypes(training_id)
);

create table testimonials (
	testimonial_id int(11) NOT NULL AUTO_INCREMENT,
	name varchar(512) not null,
	email_id varchar(512) not null,
	linkedinUrl varchar(512) not null,
	testimonial text not null,
	isGeneric int(1), -- if true then applicable to all courses
	course_id int(11),
	training_id int(11),
	country varchar(512) not null,
	company varchar(512),
	designation varchar(512),
	createdDate timestamp not null,
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (testimonial_id)
); -- need to store image Url

create table articles (
	article_id int NOT NULL AUTO_INCREMENT,
	course_id varchar(256),
	label_id varchar(256),
	vertical varchar(256),
	name varchar(256),
	displayName varchar(256),
	authorName varchar(256),
    authorDescription text,
    authorImage varchar(512),
	shortDescription varchar(256),
	articleContent text,
	h1Tag varchar(256),
	url varchar(512),
    duration varchar(8) NOT NULL,
    dateCreated date NOT NULL,
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (article_id)
);

-- create table clubbings (
-- 	club_id int NOT NULL AUTO_INCREMENT,
-- 	label_id varchar(256) not null,
-- 	course_id varchar(256) not null,
-- 	vendor_id varchar(256),
-- 	clubbing_type varchar(256),
-- 	shortDescription varchar(256) not null,
-- 	url varchar(512) not null,
-- 	h1Tag varchar(256),
-- 	status int(1) NOT NULL DEFAULT 1,
-- 	PRIMARY KEY (club_id)
-- )
-- OR
-- Two seperate tables with same Data Thinking of price to be kept seperate
-- pricing and Recommendations need to discuss

create table bundles(
	bundle_id int NOT NULL AUTO_INCREMENT,
    name varchar(256) not null,
	label_id varchar(256) not null,
	course_id varchar(256) not null,
	vendor_id varchar(256),
    accessDays varchar(256),
	shortDescription varchar(256) not null,
	url varchar(512) not null,
	h1Tag varchar(256),
    learners int(11),
    rating FLOAT(2,2), 
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (bundle_id)
);

create table groups (
	group_id int NOT NULL AUTO_INCREMENT,
    name varchar(256) not null,
	label_id varchar(256) not null,
	course_id varchar(256) not null,
	vendor_id varchar(256),
	shortDescription varchar(256) not null,
	learningPath text not null,
	url varchar(512) not null,
	h1Tag varchar(256),
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (group_id)
);

create table webinars(
	webinar_id int(11) NOT NULL AUTO_INCREMENT,
	course_id int(11) not null,
    name varchar(256) not null,
	shortDescription varchar(256) not null,
	longDescription text,
	url varchar(512) not null,
	h1Tag varchar(256),
    urlJoin varchar(512),
    webinar_ident varchar(256),
    authorName varchar(256) not null,
    timeZone varchar(256) not null,
    date date,
	time varchar(256),
	duration varchar(256),
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (webinar_id)
);

create table praticeTests (
	practice_test_id int NOT NULL AUTO_INCREMENT,
	course_id int(11) not null,
    name varchar(256),
	noOfSets int(11) not null,
	eLearningMapping varchar(256),
	shortDescription varchar(256),
	url varchar(512) not null,
	h1Tag varchar(256),
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (practice_test_id)
);

-- create table schedules (
-- 	schedule_id int NOT NULL AUTO_INCREMENT,
-- 	scheduleDate date not null,
-- 	scheduledFromTime varchar(256) not null,
-- 	scheduledToTime varchar(256) not null,
-- 	scheduleHeadCount int(11),
-- 	scheduleTimeZone varchar(256),
-- 	status int(1) NOT NULL DEFAULT 1,
-- 	PRIMARY KEY (schedule_id)
-- );

create table venues (
	venue_id int(11) NOT NULL AUTO_INCREMENT,
	address text,
	map text,
	country_id int(11),
	city_id int(11),
	contactPerson varchar(256),
	contactNumber varchar(256),
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (venue_id)
);

create table trainers(
	trainer_id int NOT NULL AUTO_INCREMENT,
	name varchar(256),
	specialization varchar(256),
	email varchar(256),
	phone varchar(30),
	region varchar(256),
	currency varchar(30),
	costType varchar(30),
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (trainer_id)
);

create table vendors(
	vendor_id int NOT NULL AUTO_INCREMENT,
	name varchar(256),
	url varchar(256),
	isApproved int(1) NOT NULL DEFAULT 1,
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (vendor_id)
);

create table workshop (
	workshop_id int NOT NULL AUTO_INCREMENT,
	course_id int (11) NOT NULL,
	pricing_id int (11) NOT NULL,
	training_id int (11),
    cluster_id varchar(256),
    country_id varchar(256),        
    city_id int(11),
	venue_id int (11),
	trainer_id int (11),
	dates varchar(512),
    startDate date NOT NULL,
    endDate date NOT NULL,
	fromTime varchar(256) not null,
	toTime varchar(256) not null,
    timeZone varchar(256),
	maxHeadCount int(11),
	minHeadCount int(11),
	noOfDays int(11),
	discountValue numeric(10,4) not null,
	price numeric(10,4) not null,
	workshopStatus  varchar(30) NOT NULL DEFAULT 'active' CHECK (workshopStatus in ('active','inactive','complete')),
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (workshop_id),
	FOREIGN KEY (course_id) REFERENCES courses(course_id),
	FOREIGN KEY (training_id) REFERENCES trainingTypes(training_id),
	FOREIGN KEY (venue_id) REFERENCES venues(venue_id),
	FOREIGN KEY (trainer_id) REFERENCES trainers(trainer_id)
);

create table faq(
	faq_id int(11) NOT NULL AUTO_INCREMENT,
	linkable_id int (11) NOT NULL,
	linkable_type varchar(30),
	question varchar(512),
	answer text,
	orderNo int(11),
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (faq_id)
);


create table recommendations(
	recommendation_id int(11) NOT NULL AUTO_INCREMENT,
	linkable_id varchar(30) NOT NULL,
	linkable_type varchar(30),
	applicableEntity varchar(256),
    applicableEntityId int(11),
	elementName varchar(256),
	trainingType varchar(256),
    answer text,
	orderNo int(11),
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (recommendation_id)
);

create table keyfeatures(
	feature_id int(11) NOT NULL AUTO_INCREMENT,
	linkable_id int (11) NOT NULL,
    linkable_type varchar(256),
	name varchar(30),
	featureText text,
	orderNo int(11),
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (feature_id)
);

-- where price is Zero
create table knowledgeBankEntry(
	knowledge_id int(11) NOT NULL AUTO_INCREMENT,
	knowledgeEntities varchar (256),
	course_id varchar (256),
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (knowledge_id)
);

-- create table arrangeCourses(
-- 	arrange_id int(11) NOT NULL AUTO_INCREMENT,
-- 	popularCourses varchar (512),
-- 	recentCourses varchar (512),
-- 	offeredCourses varchar (512),
-- 	status int(1) NOT NULL DEFAULT 1,
-- 	PRIMARY KEY (arrange_id)
-- );

create table subscriptionPricing(
	subscription_id int(11) NOT NULL AUTO_INCREMENT,
	linkable_id varchar(30) NOT NULL,
	linkable_type varchar(30),
    country_id int(11) NOT NULL DEFAULT 0,
    currency_id int(11) NOT NULL DEFAULT 1,
    discountValue numeric(10,4),
	accessDays int(11),
    setNumber int(11),
	subscriptionPrice numeric(10,4),
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (subscription_id)
);

create table searchTags(
	search_id int(11) NOT NULL AUTO_INCREMENT,
	linkable_id int(11),
	linkable_type varchar(256),
	tag varchar(512),
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (search_id)
);

create table pricings (
	pricing_id int NOT NULL AUTO_INCREMENT,
	course_id int(11) not null,
	type varchar(256) not null default 'workshop',
	allLocation int(1),
	training_id int(11) not null,
	access_day_id int(11) not null,
	cluster_id varchar(512),
	country_id varchar(512),
	city_id varchar(512),
	course_inclusion_id varchar(512),
	price numeric(10,4),
	discount numeric(10,2),
	minPrice numeric(10,4),
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (pricing_id)
);

create table lookUp (
	lookup_id int(11) NOT NULL AUTO_INCREMENT,
	type varchar(256),
	name varchar(512),
	description varchar(512),
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (lookup_id)
);

create table accessDays(
	day_id int(11) NOT NULL AUTO_INCREMENT,
	type varchar(256),
	noOfDays int(11),
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (day_id)
);

create table cluster (
	cluster_id int(11) NOT NULL AUTO_INCREMENT,
	name varchar(256),
    currency_id int(11) NOT NULL DEFAULT 1,
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (cluster_id)
);

create table country (
	country_id int(11) NOT NULL AUTO_INCREMENT,
	cluster_id int(11),
	name varchar(512),
	orderNo int(11),
    currency_code varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL, 
    currency_id int(11) NOT NULL DEFAULT 1,
	dateFormat varchar(256),
	language varchar(256),
	code varchar(30),
	callingCode varchar(256),
    isTaxApplicable int(1),
    serviceTax double(10,4),
    local_currency_code varchar(30),
	timeZone varchar(30),
    istOffSet varchar(30),
	shortCode varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
    isCityActivated int(11) NOT NULL DEFAULT '0',
    defaultCity_id int(11) DEFAULT NULL,
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (country_id)
);

create table city (
	city_id int(11) NOT NULL AUTO_INCREMENT,
	country_id int(11),
    region_name varchar(128) CHARACTER SET utf8 NOT NULL,        
	isCapital int(1),
	name varchar(512),
	orderNo int(11),
    longitude double(10,6) NOT NULL,
    latitude double(10,6) NOT NULL,
    about_city text COLLATE utf8_unicode_ci,
    location_time_zone varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
    nearByCities varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
    status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (city_id)
);

create table currencies(
	currency_id int(11) NOT NULL AUTO_INCREMENT,
	country_id int(11),
	code varchar(30),
	symbol varchar(512),
	defaults int(11),
	conversionRate numeric(10,4),
	serviceTax numeric(10,4),
	countryCode varchar(30),
	serviceTaxString varchar(50),
	invoiceAddress text,
	registrationNumber text,
	invoiceString varchar(256),
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (currency_id)
);

create table exams (
    exam_id int(11) NOT NULL AUTO_INCREMENT,
    course_id int(11) NOT NULL,
    url varchar(512),
    shortDescription text,
    status int(1) NOT NULL DEFAULT 1,
    PRIMARY KEY (exam_id)
);

create table changeLog (
	changeLog_id int(11) NOT NULL AUTO_INCREMENT,
	tableName varchar(200),
	oldValues text,
	newValues text,
	time int(11),
	user_id int(11),
	row varchar(200),
	status  int(11),
	PRIMARY KEY (changeLog_id)
);


create table mediaCoverage(
	media_id int(11) NOT NULL AUTO_INCREMENT,
	name varchar(256) NOT NULL,
	title varchar(256),
	imagePath varchar(512),
	details text,
	link varchar(256),
	isPromoted int(1) NOT NULL DEFAULT 0,
	publishDate int(11),
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (media_id)
);

CREATE TABLE `homePageBanners` (
  `banner_id` int(11) NOT NULL AUTO_INCREMENT,
  `image_name` varchar(500) COLLATE latin1_general_ci DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `image_link` varchar(200) COLLATE latin1_general_ci DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `image_order` int(11) DEFAULT NULL,
  `alt_text` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `class_name` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`banner_id`),
  KEY `country_id_idx` (`country_id`)
);

CREATE TABLE `uploadedImages` (
	`image_name` varchar(500) NOT NULL,
	`action_name` varchar(200) NOT NULL,
	`controller_name` varchar(200) NOT NULL,
	`addedDate` date NOT NULL,
	`status` int(11) NOT NULL DEFAULT '1',
	PRIMARY KEY (`image_name`)
);

CREATE TABLE `referrals` (
  `referral_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) DEFAULT NULL,
  `lead_id` int(11) DEFAULT NULL,
  `datetime` int(11) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `phone` varchar(200) DEFAULT NULL,
  `referrer_user_id` int(11) DEFAULT NULL,
  `referrer_name` varchar(200) DEFAULT NULL,
  `referrer_email` varchar(200) DEFAULT NULL,
  `hasClickedEmailLink` int(11) DEFAULT NULL,
  `orderDate` int(11) DEFAULT NULL,
  `orderNumber` varchar(100) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `moneybackApplicable` int(11) DEFAULT NULL,
  `moneybackEnddate` int(11) DEFAULT NULL,
  `moneybackClaimed` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  `country_code` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`referral_id`)
);

CREATE TABLE `referers` (
  `referer_id` int(11) NOT NULL AUTO_INCREMENT,
  `datetime` int(11) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `phone` varchar(200) DEFAULT NULL,
  `referrals` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `country_code` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`referer_id`)
);

create table seo(
    seo_id int(11) NOT NULL AUTO_INCREMENT,
    linkable_id int(11),
    linkable_type varchar(256),
    title  varchar(256),
    description text,  
    keyword  varchar(256),
    thumb_image  varchar(256),
    alt_text text,
    PRIMARY KEY (seo_id)
);

CREATE TABLE `banners` (
    banner_id int(11) NOT NULL AUTO_INCREMENT,
    banner_type  varchar(30) NOT NULL DEFAULT 'home' CHECK (workshopStatus in ('label','home', 'top', 'small','other')),
    linkable_id int(11),
    linkable_type varchar(256),
    country_id varchar(512),
    cluster_id varchar(512),
    label_id int(11),
    PRIMARY KEY (`banner_id`)
);

create table generalFaq (
	faq_id int(11) NOT NULL AUTO_INCREMENT,
	section varchar(512),
    question varchar(512),
	answer text,
	status int(1) NOT NULL DEFAULT 1,
	PRIMARY KEY (faq_id)
);